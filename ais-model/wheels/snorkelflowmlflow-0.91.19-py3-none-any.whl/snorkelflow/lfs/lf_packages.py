from itertools import chain
from typing import Any, Dict, Iterator, List, Optional, Union

from snorkelflow.lfs.lfs import LF

# Bump if new LF package format is incompatible
VERSION = 2


class LFPackage:
    """Set of LFs to represent an LF package.

    This class allows manipulating a package at LF-level (e.g., adding an LF)
    as well as at package-level (e.g., taking a union of packages), but remember
    that LF names should be unique within a package.

    Examples
    --------

    Initialize a package with a list of LFs.

    >>> from snorkelflow.lfs import LF, LFPackage
    >>> lf_a = LF(name="lf_a", label=0, templates=...)
    >>> lf_b = LF(name="lf_b", label=1, templates=...)
    >>> pkg = LFPackage([lf_a, lf_b])
    >>> [lf.name for lf in pkg]
    ['lf_a', 'lf_b']

    Rename all the LFs in a package.

    >>> pkg.rename_lfs(prefix="my_")
    >>> [lf.name for lf in pkg]
    ['my_lf_a', 'my_lf_b']

    Rename a single LF. Due to its immutability, an LF should be removed, recreated, and added again.

    >>> lf_config = pkg.pop("lf_a").to_dict()
    >>> lf_config["name"] = "my_lf_a_v1"
    >>> pkg.add(LF(**lf_config))
    >>> [lf.name for lf in pkg]
    ['lf_b', 'my_lf_a_v1']
    """

    __lfs: Dict[str, LF]

    def __init__(self, lfs: Optional[Union[LF, List[LF]]] = None) -> None:
        """
        Initialize a package.

        Parameters
        ----------
        lfs
            List of LFs
        """
        if lfs is None:
            lfs = []
        elif not isinstance(lfs, List):
            lfs = [lfs]
        # Check the type of lfs
        for lf in lfs:
            if not isinstance(lf, LF):
                raise TypeError(
                    f"You provided {lf.__class__.__name__}. Please provide an LF."
                )
        # Check name duplicate
        if len(lfs) != len({lf.name for lf in lfs}):
            raise ValueError("Names of given LFs are not unique.")
        # Add each LF
        self.__lfs = {lf.name: lf for lf in lfs}

    def __len__(self) -> int:
        return len(self.__lfs)

    def __contains__(self, lf: LF) -> bool:
        if not isinstance(lf, LF):
            raise TypeError(
                f"You provided {lf.__class__.__name__}. Please provide an LF."
            )
        return lf.name in self.__lfs

    def __iter__(self) -> Iterator[LF]:
        return self.__lfs.values().__iter__()

    # The built-in set's union takes multiple "others", but single "other" would be good enough here.
    def union(self, other: "LFPackage") -> "LFPackage":
        """Return a new package with LFs from the package and the other.

        Parameters
        ----------
        other
            The package to compare

        Returns
        -------
        LFPackage
            New package with LFs from the package and the other

        Raises
        ------
        ValueError
            If both packages have an LF with the same name but a different value for
            the other attributes. For example, this package has ``LF(name='lf_a', label=0, ...)``
            and the other has ``LF(name='lf_a', label=1, ...)``.
        """
        # Combine the intersection with the two differences instead of directly taking
        # the union of the two sets to leverage the name duplicate check at intersection().
        intersection = self.intersection(other)
        self_only = self.difference(other)
        other_only = other.difference(self)
        return LFPackage(list(chain(intersection, self_only, other_only)))

    def intersection(self, other: "LFPackage") -> "LFPackage":
        """Return a new package with LFs common to the package and the other.

        Parameters
        ----------
        other
            The package to compare

        Returns
        -------
        LFPackage
            New package with LFs common to the package and the other

        Raises
        ------
        ValueError
            If both packages have an LF with the same name but a different value for
            the other attributes. For example, this package has ``LF(name='lf_a', label=0, ...)``
            and the other has ``LF(name='lf_a', label=1, ...)``.
        """
        # Check if LFs with the same name exist in both sets.
        list_same_name = [lf.name for lf in self if lf in other]
        # Throw an error when LFs with same name are not identical.
        list_same_name_not_identical = [
            name for name in list_same_name if self.get(name) != other.get(name)
        ]
        if len(list_same_name_not_identical) != 0:
            raise ValueError(
                f"The following LFs exist in both sets but they are not identical: {list_same_name_not_identical}."
            )
        return LFPackage([lf for lf in self if lf in other])

    def difference(self, other: "LFPackage") -> "LFPackage":
        """Return a new package with LFs in the package that are not in the other package.

        Parameters
        ----------
        other
            The package to compare

        Returns
        -------
        LFPackage
            New package with LFs in the package that are not in the other package
        """
        # Only look at keys (LF names) when taking a difference.
        return LFPackage([lf for lf in self if lf not in other])

    def add(self, lf: LF) -> None:
        """Add an LF to the package.

        Parameters
        ----------
        lf
            LF to add
        """
        if not isinstance(lf, LF):
            raise TypeError(
                f"You provided {lf.__class__.__name__}. Please provide an LF."
            )
        if lf.name in self.__lfs:
            raise ValueError(
                "An LF with the same name exists. Please rename and try again"
            )
        self.__lfs[lf.name] = lf

    def pop(self, name: str) -> LF:
        """Remove the LF specified by name from the package and return it.

        Parameters
        ----------
        name
            Name of the LF to remove

        Returns
        -------
        LF
            LF that is removed
        """
        return self.__lfs.pop(name)

    def get(self, name: str) -> Optional[LF]:
        """Get the LF specified by name.

        Parameters
        ----------
        name
            Name of the LF to get

        Returns
        -------
        LF
            LF to get
        """
        return self.__lfs.get(name)

    def update_label(self, label_mapping: Dict[Any, Any]) -> None:
        """Update label strings.

        Parameters
        ----------
        label_mapping
            Dictionary that maps from old (raw) label to new (raw) label.

        Examples
        --------
        >>> # Find LFs whose label is 0 and update their label to 1
        >>> pkg.update_label({0: 1})
        """
        for name, lf in self.__lfs.items():
            # Check with lf.templates rather than lf.is_multipolar so that mypy won't complain the later use of lf.templates.
            if lf.templates is None:
                raise TypeError(
                    "Labels can't be updated because the package contains multi-polar LFs."
                )
            if lf.label in label_mapping:
                if (
                    len(lf.templates) == 1
                    and lf.templates[0]["template_type"] == "code"
                ):
                    raise ValueError("Label of a code LF cannot be changed.")
                lf_dict = lf.to_dict()
                lf_dict["label"] = label_mapping[lf.label]
                new_lf = LF(**lf_dict)
                self.__lfs[name] = new_lf

    def rename_lfs(self, prefix: str = "", suffix: str = "") -> None:
        """Rename all LFs in the package.

        Parameters
        ----------
        prefix
            The string to append at the beginning of each LF name
        suffix
            The string to append at the end of each LF name
        """
        # Rename LFs
        new_lfs = []
        for name, lf in self.__lfs.items():
            lf_dict = lf.to_dict()
            lf_dict["name"] = f"{prefix}{lf.name}{suffix}"
            new_lf = LF(**lf_dict)
            new_lfs.append(new_lf)
        # Replace with the renamed LFs
        self.__lfs = {lf.name: lf for lf in new_lfs}

    def __repr__(self) -> str:
        sorted_names = sorted([lf.name for lf in self])
        return f"{self.__class__.__name__}{repr(sorted_names)}"

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, LFPackage):
            return NotImplemented
        # pkg_uid is intentionally excluded.
        return self.__lfs == other.__lfs
