from typing import Dict


def _clean_label(label: str) -> str:
    return label.replace("'", "'")


def get_code_mapper(label_map: Dict[str, int], is_multi_label: bool) -> str:
    if is_multi_label:
        return _get_code_mapper_multi_label(label_map)
    else:
        return _get_code_mapper_single_label(label_map)


def _get_code_mapper_multi_label(label_map: Dict[str, int]) -> str:
    label_map_without_unk = {k: v for (k, v) in label_map.items() if k != "UNKNOWN"}
    code_mapper_prefix = """from typing import List

def map_output(prompt: str, context: str, output: str) -> List[str]:
    \"\"\"Given the prompt, field context, and model output, return the label\"\"\"
    clean_output = output.strip().lower()
    fm_labels = clean_output.split(',')
    labels = set()
    for fm_label in fm_labels:\n
        fm_label = fm_label.strip()\n
        """
    code_mapper_body = "\n        ".join(
        [
            f"if fm_label == '{_clean_label(label.lower())}':\n            labels.add('{_clean_label(label)}')\n            continue"
            for label in label_map_without_unk.keys()
        ]
    )
    code_mapper_suffix = (
        "\n        else:\n            labels.add('UNKNOWN')\n    return list(labels)"
    )
    code_mapper = code_mapper_prefix + code_mapper_body + code_mapper_suffix
    return code_mapper


def _get_code_mapper_single_label(label_map: Dict[str, int]) -> str:
    label_map_without_unk = [label for label in label_map if label != "UNKNOWN"]
    return f'''def map_output(prompt: str, context: str, output: str) -> str:
    """Given the prompt, field context, and model output, return the label"""
    from difflib import get_close_matches
    labels = {label_map_without_unk}
    clean_output = output.strip().lower()
    clean_labels = {{label.strip().lower(): label for label in labels}}
    matches = get_close_matches(clean_output, clean_labels, n=1)
    if not matches:
        return ["UNKNOWN"]
    return clean_labels[matches[0]]'''
