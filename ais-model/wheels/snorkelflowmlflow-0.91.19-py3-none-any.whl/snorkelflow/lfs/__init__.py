"""
Classes that represent LF and LF Package.
"""
from snorkelflow.lfs.lf_packages import LFPackage  # noqa: F401
from snorkelflow.lfs.lfs import LF, labeling_function  # noqa: F401
