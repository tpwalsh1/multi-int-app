import inspect
import pickle
from dataclasses import asdict, dataclass
from types import SimpleNamespace
from typing import Any, Callable, Dict, Hashable, List, Mapping, Optional, Union

import numpy as np
import pandas as pd

DataPoint = Any
MapFunction = Callable[[DataPoint], Optional[DataPoint]]


@dataclass(frozen=True)
class LF:
    """Class to represent an immutable LF.

    Examples
    --------

    Create an LF.

    >>> from snorkelflow.lfs import LF
    >>> lf_a = LF(name="lf_a", label=0, templates=...)

    Due to the immutability, a new LF should be created if you want to change its attributes.

    >>> lf_config = lf_a.to_dict()
    >>> lf_config["name"] = "lf_b"
    >>> lf_b = LF(**lf_config)
    """

    name: str
    label: Optional[Any]
    templates: Optional[List[Dict[str, Any]]]
    multipolar_template: Optional[Dict[str, Any]]
    graph: Optional[Union[str, int, List[Any]]] = None
    is_trusted: Optional[bool] = False

    # The __init__ is not required for dataclass.
    # This is explicitly defined just for Sphinx.
    def __init__(
        self,
        name: str,
        label: Optional[Any] = None,
        templates: Optional[List[Dict[str, Any]]] = None,
        multipolar_template: Optional[Dict[str, Any]] = None,
        graph: Optional[Union[str, int, List[Any]]] = None,
        is_trusted: Optional[bool] = False,
    ) -> None:
        """Initialize an LF object.

        Parameters
        ----------
        name
            Name of the LF
        label
            Label associated with the LF. This shouldn't be provided for a multi-polar LF.
        templates
            Templates for the LF. Each template is assigned with a 0-th based index that can be used in `graph`.
        multipolar_template
            Template for the multi-polar LF
        graph
            Provide this argument to construct a *compound LF*, one that's made of multiple templates. Optional if there is only one template.
            It is a list that starts with a logical operator, followed by template indexes or sub-lists.
            The logical operator can be ``"$AND"``, ``"$OR"``, or ``"$NOT"``.
            The list can be nested but the depth should be 3 or less.
            For example, a compound LF with ``["$AND", 0, ["$NOT", 1]]`` votes if the 0th template returns True and the 1st template returns False, and its depth is 2.
        is_trusted
            If True, designate the LF as trusted
        """
        if label is None:
            if templates is not None:
                raise ValueError(
                    f"templates shouldn't be provided for a multi-polar LF."
                )
            if multipolar_template is None:
                raise ValueError(
                    f"multipolar_template should be provided for a multi-polar LF."
                )
        else:
            if templates is None:
                raise ValueError(f"templates should be provided for a uni-polar LF.")
            if multipolar_template is not None:
                raise ValueError(
                    f"multipolar_template shouldn't be provided for a uni-polar LF."
                )
        # When using frozen=True, __init__() cannot use simple assignment to initialize
        # fields, and must use object.__setattr__().
        # https://docs.python.org/3/library/dataclasses.html#frozen-instances
        object.__setattr__(self, "name", name)
        object.__setattr__(self, "label", label)
        object.__setattr__(self, "templates", templates)
        object.__setattr__(self, "multipolar_template", multipolar_template)
        object.__setattr__(self, "graph", graph)
        object.__setattr__(self, "is_trusted", is_trusted)

    def to_dict(self) -> Dict[str, Any]:
        """Get a dictionary representation of the LF.

        Returns
        -------
        Dict[str, Any]
            Dictionary representation of the LF
        """
        lf_config = asdict(self)
        if self.is_multipolar:
            del lf_config["templates"]
        else:
            del lf_config["multipolar_template"]
        return lf_config

    @property
    def is_multipolar(self) -> bool:
        return self.label is None


def get_parameters(
    f: Callable[..., Any], allow_args: bool = False, allow_kwargs: bool = False
) -> List[str]:
    """Get names of function parameters."""
    params = inspect.getfullargspec(f)
    if not allow_args and params[1] is not None:
        raise ValueError(f"Function {f.__name__} should not have *args")
    if not allow_kwargs and params[2] is not None:
        raise ValueError(f"Function {f.__name__} should not have **kwargs")
    return params[0]


def is_hashable(obj: Any) -> bool:
    """Test if object is hashable via duck typing.

    NB: not using ``collections.Hashable`` as some objects
    (e.g. pandas.Series) have a ``__hash__`` method to throw
    a more specific exception.
    """
    try:
        hash(obj)
        return True
    except Exception:
        return False


def get_hashable(obj: Any) -> Hashable:
    """Get a hashable version of a potentially unhashable object.

    This helper is used for caching mapper outputs of data points.
    For common data point formats (e.g. SimpleNamespace, pandas.Series),
    produces hashable representations of the values using a ``frozenset``.
    For objects like ``pandas.Series``, the name/index indentifier is dropped.

    Parameters
    ----------
    obj
        Object to get hashable version of

    Returns
    -------
    Hashable
        Hashable representation of object values

    Raises
    ------
    ValueError
        No hashable proxy for object
    """
    # If hashable already, just return
    if is_hashable(obj):
        return obj
    # Get dictionary from SimpleNamespace
    if isinstance(obj, SimpleNamespace):
        obj = vars(obj)
    # For dictionaries or pd.Series, construct a frozenset from items
    # Also recurse on values in case they aren't hashable
    if isinstance(obj, (dict, pd.Series)):
        return frozenset((k, get_hashable(v)) for k, v in obj.items())
    # For lists, recurse on values
    if isinstance(obj, (list, tuple)):
        return tuple(get_hashable(v) for v in obj)
    # For NumPy arrays, hash the byte representation of the data array
    if isinstance(obj, np.ndarray):
        return obj.data.tobytes()
    raise ValueError(f"Object {obj} has no hashing proxy.")


class BaseMapper:
    """Base class for ``Mapper`` and ``LambdaMapper``.

    Implements nesting, memoization, and deep copy functionality.
    Used primarily for type checking.

    Parameters
    ----------
    name
        Name of the mapper
    pre
        Mappers to run before this mapper is executed
    memoize
        Memoize mapper outputs?

    Raises
    ------
    NotImplementedError
        Subclasses need to implement ``_generate_mapped_data_point``

    Attributes
    ----------
    memoize
        Memoize mapper outputs?
    """

    def __init__(self, name: str, pre: List["BaseMapper"], memoize: bool) -> None:
        self.name = name
        self._pre = pre
        self.memoize = memoize
        self.reset_cache()

    def reset_cache(self) -> None:
        """Reset the memoization cache."""
        self._cache: Dict[DataPoint, DataPoint] = {}

    def _generate_mapped_data_point(self, x: DataPoint) -> Optional[DataPoint]:
        raise NotImplementedError

    def __call__(self, x: DataPoint) -> Optional[DataPoint]:
        """Run mapping function on input data point.

        Deep copies the data point first so as not to make
        accidental in-place changes. If ``memoize`` is set to
        ``True``, an internal cache is checked for results. If
        no cached results are found, the computed results are
        added to the cache.

        Parameters
        ----------
        x
            Data point to run mapping function on

        Returns
        -------
        DataPoint
            Mapped data point of same format but possibly different fields
        """
        if self.memoize:
            # NB: don't do ``self._cache.get(...)`` first in case cached value is ``None``
            x_hashable = get_hashable(x)
            if x_hashable in self._cache:
                return self._cache[x_hashable]
        # NB: using pickle roundtrip as a more robust deepcopy
        # As an example, calling deepcopy on a pd.Series or SimpleNamespace
        # with a dictionary attribute won't create a copy of the dictionary
        x_mapped = pickle.loads(pickle.dumps(x))
        for mapper in self._pre:
            x_mapped = mapper(x_mapped)
        x_mapped = self._generate_mapped_data_point(x_mapped)
        if self.memoize:
            self._cache[x_hashable] = x_mapped
        return x_mapped

    def __repr__(self) -> str:
        pre_str = f", Pre: {self._pre}"
        return f"{type(self).__name__} {self.name}{pre_str}"


# Used for type checking only
BasePreprocessor = BaseMapper


class LambdaMapper(BaseMapper):
    """Define a mapper from a function.

    Convenience class for mappers that execute a simple
    function with no set up. The function should map from
    an input data point to a new data point directly, unlike
    ``Mapper.run``. The original data point will not be updated,
    so in-place operations are safe.

    Parameters
    ----------
    name:
        Name of mapper
    f
        Function executing the mapping operation
    pre
        Mappers to run before this mapper is executed
    memoize
        Memoize mapper outputs?
    """

    def __init__(
        self,
        name: str,
        f: MapFunction,
        pre: Optional[List[BaseMapper]] = None,
        memoize: bool = False,
    ) -> None:
        self._f = f
        super().__init__(name, pre or [], memoize)

    def _generate_mapped_data_point(self, x: DataPoint) -> Optional[DataPoint]:
        return self._f(x)


class lambda_mapper:
    """Decorate a function to define a LambdaMapper object.

    Examples
    --------
    >>> @lambda_mapper()
    ... def concatenate_text(x):
    ...     x.article = f"{x.title} {x.body}"
    ...     return x
    >>> isinstance(concatenate_text, LambdaMapper)
    True
    >>> from types import SimpleNamespace
    >>> x = SimpleNamespace(title="my title", body="my text")
    >>> concatenate_text(x).article
    'my title my text'

    Parameters
    ----------
    name
        Name of mapper. If None, uses the name of the wrapped function.
    pre
        Mappers to run before this mapper is executed
    memoize
        Memoize mapper outputs?

    Attributes
    ----------
    memoize
        Memoize mapper outputs?
    """

    def __init__(
        self,
        name: Optional[str] = None,
        pre: Optional[List[BaseMapper]] = None,
        memoize: bool = False,
    ) -> None:
        if callable(name):
            raise ValueError("Looks like this decorator is missing parentheses!")
        self.name = name
        self.pre = pre
        self.memoize = memoize

    def __call__(self, f: MapFunction) -> LambdaMapper:
        """Wrap a function to create a ``LambdaMapper``.

        Parameters
        ----------
        f
            Function executing the mapping operation

        Returns
        -------
        LambdaMapper
            New ``LambdaMapper`` executing operation in wrapped function
        """
        name = self.name or f.__name__
        return LambdaMapper(name=name, f=f, pre=self.pre, memoize=self.memoize)


class preprocessor(lambda_mapper):
    """Decorate functions to create preprocessors.

    See ``snorkel.map.core.lambda_mapper`` for details.

    Examples
    --------
    >>> @preprocessor()
    ... def combine_text_preprocessor(x):
    ...     x.article = f"{x.title} {x.body}"
    ...     return x
    >>> from snorkel.preprocess.nlp import SpacyPreprocessor
    >>> spacy_preprocessor = SpacyPreprocessor("article", "article_parsed")

    We can now add our preprocessors to an LF.

    >>> preprocessors = [combine_text_preprocessor, spacy_preprocessor]
    >>> from snorkel.labeling.lf import labeling_function
    >>> @labeling_function(pre=preprocessors)
    ... def article_mentions_person(x):
    ...     for ent in x.article_parsed.ents:
    ...         if ent.label_ == "PERSON":
    ...             return ABSTAIN
    ...     return NEGATIVE
    """

    pass


class LabelingFunction:
    """Base class for labeling functions.

    A labeling function (LF) is a function that takes a data point
    as input and produces an integer label, corresponding to a
    class. A labeling function can also abstain from voting by
    outputting ``-1``. For examples, see the Snorkel tutorials.

    This class wraps a Python function outputting a label. Extra
    functionality, such as running preprocessors and storing
    resources, is provided. Simple LFs can be defined via a
    decorator. See ``labeling_function``.

    Parameters
    ----------
    name
        Name of the LF
    f
        Function that implements the core LF logic
    resources
        Labeling resources passed in to ``f`` via ``kwargs``

    Raises
    ------
    ValueError
        Calling incorrectly defined preprocessors

    Attributes
    ----------
    name
        See above
    """

    def __init__(
        self,
        name: str,
        f: Callable[..., str],
        resources: Optional[Mapping[str, Any]] = None,
        preprocess_configs: Optional[List[Dict[str, Any]]] = None,
    ) -> None:
        self.name = name
        self._f = f
        self._resources = resources or {}
        self.preprocess_configs = preprocess_configs or []

    def __call__(self, x: DataPoint) -> Any:
        """Label data point.

        Runs all preprocessors, then passes preprocessed data point to LF.

        Parameters
        ----------
        x
            Data point to label

        Returns
        -------
        int or List[Tuple[int, int]]] for sequence tagging LFs
            Label for data point
        """
        if hasattr(self, "_pre"):
            raise ValueError(
                f"Preprocessors: {self._pre} were detected in LF {self.name}. As they are no longer supported, please add an equivalent operator to the DAG instead, or fold them into the main function."  # type: ignore
            )
        return self._f(x, **self._resources)

    def __repr__(self) -> str:
        return f"{type(self).__name__} {self.name}"


class labeling_function:
    """Decorator to create a LabelingFunction object from a user-defined function.

    Parameters
    ----------
    name
        Name of the LF
    resources
        Labeling resources passed in to ``f`` via ``kwargs``.

        .. note::
            While this can be a nested dictionary and can include functions, functions should be its direct children if any otherwise they would break when Snorkel Flow upgrades to a newer version of Python.

    preprocess_configs
        Preprocessors to run on data points before LF execution

    Examples
    --------

    ::

        # Simple example
        @labeling_function()
        def f(x):
            return "SPAM" if "drug" in x.body else "UNKNOWN"

        # Example with resources
        def find_word_index(text):
            import numpy
            try:
                idx = numpy.where(text.split(" ").index("employee"))
            except:
                idx = numpy.array([])
            return idx

        @labeling_function(name="my_lf", resources=dict(find_word_index=find_word_index))
        def lf(x, find_word_index):
            import numpy
            idx = find_word_index(x.text)
            if numpy.mean(idx) <= 1000:
                return "employment"
            else:
                return "UNKNOWN"

        # Bad example ("find_word_index" function is NOT a direct child of "resources")
        @labeling_function(name="my_lf", resources=dict(funcs=dict(find_word_index=find_word_index)))
        def bad_lf(x, funcs):
            import numpy
            idx = funcs["find_word_index"](x.text)
            if numpy.mean(idx) <= 1000:
                return "employment"
            else:
                return "UNKNOWN"
    """

    def __init__(
        self,
        name: Optional[str] = None,
        resources: Optional[Mapping[str, Any]] = None,
        preprocess_configs: Optional[List[Dict[str, Any]]] = None,
    ) -> None:
        if callable(name):
            raise ValueError("Looks like this decorator is missing parentheses!")
        self.name = name
        self.resources = resources
        self.preprocess_configs = preprocess_configs or []

    def __call__(self, f: Callable[..., str]) -> LabelingFunction:
        """Wrap a function to create a ``LabelingFunction``.

        Parameters
        ----------
        f
            Function that implements the core LF logic

        Returns
        -------
        LabelingFunction
            New ``LabelingFunction`` executing logic in wrapped function
        """
        name = self.name or f.__name__
        return LabelingFunction(
            name=name,
            f=f,
            resources=self.resources,
            preprocess_configs=self.preprocess_configs,
        )
