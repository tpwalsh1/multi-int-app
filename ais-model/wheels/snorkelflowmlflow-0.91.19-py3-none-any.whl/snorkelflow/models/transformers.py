import os
import pathlib
import urllib.parse
from abc import abstractmethod
from collections import defaultdict
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd
import torch
from pydantic import BaseModel
from tqdm import tqdm
from transformers import (
    AutoConfig,
    AutoModelForSequenceClassification,
    AutoTokenizer,
    Trainer,
    TrainingArguments,
)
from transformers.configuration_utils import PretrainedConfig
from transformers.modeling_utils import PreTrainedModel
from transformers.tokenization_utils import PreTrainedTokenizer

from api_utils.exceptions import SnorkelException, UserInputError
from file_utils.core import open_file
from snorkelflow.models.cls_model import (
    BaseManifest,
    ClassificationModelV2,
    TrainedClassificationModelV2,
)
from snorkelflow.models.model_configs import HFCacheSettings, ModelTrainingConfig
from snorkelflow.models.special_utils import (
    Dataset,
    LayoutLMDataset,
    TrainStepCallback,
    get_layoutlm_model_encodings,
)
from snorkelflow.models.utils import (
    MODEL_CONFIG_OPTION_FIELDS,
    MODEL_CONFIG_OPTION_N_CLASSES,
    MODEL_CONFIG_OPTION_USE_LF_LABELS,
    START_FEATURIZATION_PCT,
    START_TRAINING_PCT,
    ExtractionOptions,
    MockStatusHandler,
    get_decision_threshold,
    get_sequence_model_features,
)
from snorkelflow.types.model import AggregationType
from snorkelflow.utils.logging import get_logger
from snorkelflow.utils.system import is_gpu_available

LOGGING_STEPS = 10
MAX_SEQ_LEN_ALLOWED = 512
TEMP_TRANSFORMERS_FEATURE_TEXT_FIELD = "__TMP_TRANSFORMERS_FEAT_TEXT"

logger = get_logger("Models")


class TrainedTransformerClassificationModel(TrainedClassificationModelV2):
    def __init__(
        self,
        model: PreTrainedModel,
        tokenizer: PreTrainedTokenizer,
        pretrained_model_name: str,
        fields: List[str],
        max_sequence_length: int,
        decision_threshold: Optional[float],
        extraction_options: Optional[ExtractionOptions] = None,
        device: torch.device = torch.device("cpu"),
        config: Optional[PretrainedConfig] = None,
    ) -> None:
        self.model = model
        self.tokenizer = tokenizer
        self.pretrained_model_name = pretrained_model_name
        self.fields = fields
        self.max_sequence_length = max_sequence_length
        self.decision_threshold = decision_threshold
        self.extraction_options = extraction_options
        self.device = device
        self.config = config
        self.batch_size = 64

    def predict(self, df: pd.DataFrame) -> Tuple[np.ndarray, np.ndarray]:
        # Eval!
        self.model.eval()
        self.device = torch.device("cuda" if is_gpu_available() else "cpu")
        self.model.to(self.device)
        predict_logits = []

        docs = get_sequence_model_features(
            df, self.fields, self.extraction_options
        ).tolist()
        logger.info(f"***** Running predict for {self.pretrained_model_name} *****")
        logger.info(f"  Num examples = {len(docs)}")
        logger.info(f"  Batch size = {self.batch_size}")
        for doc_batch in tqdm(
            self._make_batches(docs, self.batch_size), desc="Predicting"
        ):
            input_ids = self.tokenizer(
                doc_batch,
                return_tensors="pt",
                max_length=self.max_sequence_length,
                padding="longest",
                truncation="longest_first",
            )["input_ids"]
            with torch.no_grad():
                outputs = self.model(input_ids.to(self.device))
                logits = outputs[0]  # the last hidden state
            predict_logits.append(logits.detach().cpu())

        predictions, prediction_probabilities = self._get_preds_and_probs(
            predict_logits
        )
        return predictions, prediction_probabilities

    def _get_preds_and_probs(
        self, predict_logits: List
    ) -> Tuple[np.ndarray, np.ndarray]:
        predict_logits_tensor = torch.cat(predict_logits)
        prediction_probabilities = torch.nn.functional.softmax(
            predict_logits_tensor, dim=1
        ).numpy()
        if self.decision_threshold is not None:
            predictions = (
                np.array(prediction_probabilities)[:, 1] >= self.decision_threshold
            ).astype(int)
        else:
            predictions = predict_logits_tensor.argmax(dim=1).numpy()
        return predictions, prediction_probabilities

    # NOTE: Be very careful when updating the Manifest, so as not to break
    # backwards compatibility. For example, this means only adding optional fields,
    # avoiding edits of existing fields, etc.
    class Manifest(BaseManifest):
        class ExtractionOptionsModel(BaseModel):
            left_context_len: int
            right_context_len: int
            mask_span: bool

        model: Optional[str]
        tokenizer: Optional[str]
        pretrained_model_name: Optional[str]
        extraction_options: Optional[ExtractionOptionsModel]
        max_sequence_length: Optional[int]
        decision_threshold: Optional[float]
        device: Optional[str]

    def _get_saved_component(self) -> PreTrainedModel:
        return self.model

    def save(self, dirpath: pathlib.Path) -> None:
        if self.config is None:
            raise ValueError("config cannot be None when saving")
        m = self.Manifest(type=self.__class__.__name__, model_fields=self.fields)
        # Save Transformer model
        model_dirname = "model"
        model_dirpath = dirpath / model_dirname
        model_dirpath.mkdir(parents=True, exist_ok=True)
        saved_component = self._get_saved_component()
        saved_component.save_pretrained(str(model_dirpath), safe_serialization=False)
        m.model = model_dirname
        # Save tokenizer
        self.tokenizer.save_pretrained(str(model_dirpath))
        m.tokenizer = model_dirname
        # Save config (see https://github.com/huggingface/transformers/issues/4197)
        self.config.save_pretrained(str(model_dirpath))
        # Serialize extraction options
        if self.extraction_options is None:
            m.extraction_options = None
        else:
            m.extraction_options = self.Manifest.ExtractionOptionsModel.parse_obj(
                dict(
                    left_context_len=self.extraction_options.left_context_len,
                    right_context_len=self.extraction_options.right_context_len,
                    mask_span=self.extraction_options.mask_span,
                )
            )
        # Serialize other options
        m.pretrained_model_name = self.pretrained_model_name
        m.max_sequence_length = self.max_sequence_length
        m.decision_threshold = self.decision_threshold
        # TODO: device should be dynamically set at load time
        m.device = self.device.type
        # Write manifest to disk
        with open(dirpath / "manifest.json", "w+") as mf:
            mf.write(m.json())

    @classmethod
    def _load_model(self, model_path: str) -> "AutoModelForSequenceClassification":
        return AutoModelForSequenceClassification.from_pretrained(model_path)

    @classmethod
    def load(
        cls, dirpath: str, storage_options: Optional[Dict[str, Any]] = None
    ) -> "TrainedTransformerClassificationModel":
        # Read the manifest
        storage_options = storage_options or {}
        manifest_path = os.path.join(dirpath, "manifest.json")
        with open_file(manifest_path, **storage_options) as mf:
            m = cls.Manifest.parse_raw(mf.read())
        # Load Transformer model
        assert m.model  # for mypy
        model_path = os.path.join(dirpath, m.model)
        if not urllib.parse.urlparse(model_path).scheme:
            model = cls._load_model(model_path)
        else:
            raise ValueError(
                f"Can only load local Transformer models, got {model_path}"
            )
        # Load Transformer tokenizer
        assert m.tokenizer  # for mypy
        tokenizer_path = os.path.join(dirpath, m.tokenizer)
        if not urllib.parse.urlparse(tokenizer_path).scheme:
            tokenizer = AutoTokenizer.from_pretrained(
                tokenizer_path,
                use_fast=False,
                cache_dir=HFCacheSettings.PRETRAINED_CACHE_DIR,
            )
            # We must use Python-based tokenizer for inference until we have a transformers
            # version with this fix: https://github.com/huggingface/transformers/pull/12550
        else:
            raise ValueError(
                f"Can only load local Transformer tokenizers, got {tokenizer_path}"
            )
        # Parse ExtractionOptions
        extraction_options: Optional[ExtractionOptions]
        if m.extraction_options:
            extraction_options = ExtractionOptions(
                left_context_len=m.extraction_options.left_context_len,
                right_context_len=m.extraction_options.right_context_len,
                mask_span=m.extraction_options.mask_span,
            )
        else:
            extraction_options = None
        # Construct the TrainedSklearnModel
        assert m.pretrained_model_name  # for mypy
        assert m.model_fields  # for mypy
        assert m.max_sequence_length  # for mypy
        return cls(
            model=model,
            tokenizer=tokenizer,
            pretrained_model_name=m.pretrained_model_name,
            fields=m.model_fields,
            max_sequence_length=m.max_sequence_length,
            decision_threshold=m.decision_threshold,
            extraction_options=extraction_options,
            device=torch.device(m.device),
        )


class _BaseTransformerClassificationModel(ClassificationModelV2):
    def __init__(self, model_config: ModelTrainingConfig) -> None:
        """Code adapted from HuggingFace example code:
        https://github.com/huggingface/transformers/blob/master/examples/run_ner.py"""
        super().__init__(model_config)
        if self.model_config.options[MODEL_CONFIG_OPTION_USE_LF_LABELS]:
            raise ValueError("LF labels features are not yet available for BERT models")
        # Parse model config
        self.pretrained_model_name = self.model_config.options["pretrained_model_name"]
        self.revision = self.model_config.options.get("revision", "main")
        self.train_batch_size = self.model_config.options["train_batch_size"]
        self.num_train_epochs = self.model_config.options["num_train_epochs"]
        self.weight_decay = self.model_config.options["weight_decay"]
        self.learning_rate = self.model_config.options["learning_rate"]
        self.gradient_accumulation_steps = self.model_config.options[
            "gradient_accumulation_steps"
        ]
        self.model_checkpoint_dir = self.model_config.options.get(
            "model_checkpoint_dir", HFCacheSettings.default_model_checkpoint_dir()
        )
        self.lr_warmup_steps = self.model_config.options["lr_warmup_steps"]
        self.max_grad_norm = self.model_config.options["max_grad_norm"]
        self.fields = self.model_config.options[MODEL_CONFIG_OPTION_FIELDS]
        # Dedup input fields
        self.fields = list(set(self.fields))
        self.tokenizer_kwargs = self.model_config.options["tokenizer_kwargs"]
        self.num_labels = self.model_config.options[MODEL_CONFIG_OPTION_N_CLASSES]
        self.max_sequence_length = self.model_config.options["max_sequence_length"]
        self.freeze_bert_embeddings = self.model_config.options[
            "freeze_bert_embeddings"
        ]
        if self.max_sequence_length > MAX_SEQ_LEN_ALLOWED:
            raise ValueError(
                f"Max sequence length is greater than max allowed of {MAX_SEQ_LEN_ALLOWED}."
            )
        self.extraction_options: Optional[ExtractionOptions]
        extraction_options_raw = self.model_config.options.get("extraction_options")
        if extraction_options_raw:
            # Use extraction fields
            if len(self.fields) > 1:
                raise ValueError(
                    "Multi-column training in extraction mode is currently not supported."
                )
            self.extraction_options = ExtractionOptions(
                left_context_len=extraction_options_raw["left_context_len"],
                right_context_len=extraction_options_raw["right_context_len"],
                mask_span=extraction_options_raw["mask_span"],
            )
        else:
            self.extraction_options = None

        # Initialize BERT model
        try:
            self.config = AutoConfig.from_pretrained(
                self.pretrained_model_name,
                revision=self.revision,
                num_labels=self.num_labels,
                cache_dir=HFCacheSettings.PRETRAINED_CACHE_DIR,
            )
        except OSError as e:
            raise e
        except Exception as e:
            logger.error(
                f"Unable to load (or download) pretrained model {self.pretrained_model_name} from huggingface: {e}"
            )
            msg = f"Unknown issue encountered while downloading pretrained model from huggingface.co."
            f" Please try again later. Model: {self.pretrained_model_name}."
            raise SnorkelException(
                detail=f"{msg}. Exception:{e}", user_friendly_message=msg
            )
        try:
            self.tokenizer = AutoTokenizer.from_pretrained(
                self.pretrained_model_name,
                revision=self.revision,
                cache_dir=HFCacheSettings.PRETRAINED_CACHE_DIR,
                **self.tokenizer_kwargs,
            )
        except OSError as e:
            raise e
        except Exception as e:
            logger.error(
                f"Unable to load (or download) tokenizer {self.pretrained_model_name} from huggingface:: {e}"
            )
            # TODO: add exception detail in detail msg when detail message won't show on UI
            msg = f"Unknown issue encountered while downloading pretrained tokenizer model from huggingface.co."
            f" Please try again later. Model: {self.pretrained_model_name}."
            raise SnorkelException(
                detail=f"{msg}. Exception:{e}", user_friendly_message=msg
            )

        self.decision_threshold = get_decision_threshold(self.model_config)
        self.device = torch.device("cuda" if is_gpu_available() else "cpu")
        self.torch_manual_seed = self.model_config.options.get("torch_manual_seed", 123)
        # Note: You are not guaranteed to get the same results across devices.
        torch.manual_seed(self.torch_manual_seed)
        torch.cuda.manual_seed(self.torch_manual_seed)

        # Create to pass lint-check
        self.model = self._get_model()

        if self.freeze_bert_embeddings:
            try:
                params = self.model.base_model.parameters()
            except Exception:
                raise ValueError(
                    f"Could not find {self.pretrained_model_name} attribute in model. Unable to freeze embeddings."
                )
                params = {}
            for param in params:
                param.requires_grad = False

    @abstractmethod
    def _get_model(self) -> PreTrainedModel:
        pass

    @abstractmethod
    def _preprocess_labels(self, Y: np.ndarray) -> np.ndarray:
        pass

    def _train(
        self, df: pd.DataFrame, Y: np.ndarray, status_handler: Optional[Any] = None
    ) -> None:
        if not status_handler:
            status_handler = MockStatusHandler()
        status_handler.update_status(
            "Running model featurization", START_FEATURIZATION_PCT
        )

        if self.model is None:
            raise ValueError("Model has not been created - nothing to train")

        Y = self._preprocess_labels(Y)

        train_args = TrainingArguments(
            self.model_checkpoint_dir,
            fp16=bool(self.device == "cuda"),
            learning_rate=self.learning_rate,
            per_device_train_batch_size=self.train_batch_size,
            num_train_epochs=self.num_train_epochs,
            gradient_accumulation_steps=self.gradient_accumulation_steps,
            max_grad_norm=self.max_grad_norm,
            weight_decay=self.weight_decay,
            disable_tqdm=True,
            warmup_steps=self.lr_warmup_steps,
        )

        docs = get_sequence_model_features(
            df, self.fields, self.extraction_options
        ).tolist()
        train_encodings = self.tokenizer(
            docs,
            return_tensors="pt",
            max_length=self.max_sequence_length,
            padding="max_length",
            truncation="longest_first",
        )
        train_dataset = Dataset(train_encodings, Y)  # type: ignore

        logger.info("***** Running training *****")
        logger.info("  Num examples = %d", len(train_dataset))
        logger.info("  Num Epochs = %d", self.num_train_epochs)
        logger.info("  Total train batch size  = %d", self.train_batch_size)
        logger.info(
            "  Gradient Accumulation steps = %d", self.gradient_accumulation_steps
        )
        status_handler.update_status("Training model", START_TRAINING_PCT)
        status_handler.start_end_model_training()
        trainer = Trainer(
            model=self.model, args=train_args, train_dataset=train_dataset
        )
        trainer.callback_handler.callbacks = [TrainStepCallback(status_handler)]
        trainer.train()


class TransformerClassificationModel(_BaseTransformerClassificationModel):
    label_space_cls_name = "SingleLabelSpace"

    def _get_model(self) -> PreTrainedModel:
        return AutoModelForSequenceClassification.from_pretrained(
            self.pretrained_model_name,
            revision=self.revision,
            config=self.config,
            cache_dir=HFCacheSettings.PRETRAINED_CACHE_DIR,
        )

    def _preprocess_labels(self, Y: np.ndarray) -> np.ndarray:
        return Y

    def _get_trained_model(self) -> TrainedTransformerClassificationModel:
        return TrainedTransformerClassificationModel(
            model=self.model,
            tokenizer=self.tokenizer,
            config=self.config,
            pretrained_model_name=self.pretrained_model_name,
            fields=self.fields,
            max_sequence_length=self.max_sequence_length,
            decision_threshold=self.decision_threshold,
            extraction_options=self.extraction_options,
            device=self.device,
        )


class TrainedMultiLabelTransformerClassificationModel(
    TrainedTransformerClassificationModel
):
    label_space_cls_name = "MultiLabelSpace"

    def _get_saved_component(self) -> PreTrainedModel:
        return self.model.classifier

    @classmethod
    def _load_model(self, model_path: str) -> "ModelWrapperForMLSequenceClassification":
        return ModelWrapperForMLSequenceClassification(model_path)

    def _get_preds_and_probs(
        self, predict_logits: np.ndarray
    ) -> Tuple[np.ndarray, np.ndarray]:
        predict_logits_tensor = torch.cat(predict_logits)
        prediction_probabilities = torch.nn.functional.sigmoid(
            predict_logits_tensor
        ).numpy()

        decision_threshold = self.decision_threshold or 0.5
        dense_predictions = (prediction_probabilities > decision_threshold).astype(int)
        # Infer number of classes
        dict_preds_values = [{"_default": 0} for i in range(len(dense_predictions))]

        sparse_preds = np.argwhere(dense_predictions == 1)
        for example_idx, class_int in sparse_preds:
            dict_preds_values[example_idx][str(class_int)] = 1

        predictions = np.array(dict_preds_values)

        return predictions, prediction_probabilities


class ModelWrapperForMLSequenceClassification(PreTrainedModel):
    """Class is adapted from BertForSequenceClassification to allow for abstaining labels"""

    def __init__(
        self,
        pretrained_model_name: str,
        config: PretrainedConfig = None,
        cache_dir: Any = None,
    ):
        if config is None:
            # Need for "init" when loading a pretrained model
            config = AutoConfig.from_pretrained(pretrained_model_name)

        super().__init__(config)

        self.num_labels = config.num_labels
        self.config = config

        self.classifier = AutoModelForSequenceClassification.from_pretrained(
            pretrained_model_name, config=self.config, cache_dir=cache_dir
        )

    @property
    def base_model(self) -> torch.nn.Module:
        """
        Overwrite default Transformer logic to access the actual classifier's base model.
        Default behavior defined below:
        https://github.com/huggingface/transformers/blob/master/src/transformers/modeling_utils.py#L558
        """
        return self.classifier.base_model

    def forward(
        self,
        input_ids: torch.Tensor = None,
        attention_mask: torch.Tensor = None,
        head_mask: torch.Tensor = None,
        inputs_embeds: torch.Tensor = None,
        labels: torch.Tensor = None,
        output_attentions: torch.Tensor = None,
        output_hidden_states: torch.Tensor = None,
        return_dict: bool = True,
        **kwargs: torch.Tensor,  # Additional model-specific tokenizer params
    ) -> dict:
        # Get the outputs from the original classifier -
        # returns a SequenceClassifierOutput object
        clf_output = self.classifier(
            input_ids=input_ids,
            attention_mask=attention_mask,
            head_mask=head_mask,
            inputs_embeds=inputs_embeds,
            output_attentions=output_attentions,
            output_hidden_states=output_hidden_states,
            return_dict=True,
            **kwargs,  # Additional model-specific tokenizer params
        )

        if labels is not None:
            logits = clf_output.logits
            loss_fct = torch.nn.BCEWithLogitsLoss(reduction="none")
            element_loss = loss_fct(logits, labels)
            # Abstain mask
            mask = labels > -1
            loss = (element_loss * mask).mean()
            # Rest of output stays as in the regular classifier
            clf_output["loss"] = loss

        if not return_dict:
            raise ValueError("Only dict return format is currently handled")

        return clf_output


class MultiLabelTransformerClassificationModel(_BaseTransformerClassificationModel):
    label_space_cls_name = "MultiLabelSpace"

    def _get_model(self) -> PreTrainedModel:
        return ModelWrapperForMLSequenceClassification(
            self.pretrained_model_name,
            self.config,
            HFCacheSettings.PRETRAINED_CACHE_DIR,
        )

    def _preprocess_labels(self, Y: Any) -> np.ndarray:
        """Conversion of raw dict-style label to one-hot encoding format"""
        Y_dense = np.zeros((len(Y), self.num_labels)).astype(int)
        for example_idx, example in enumerate(Y):
            for class_int in range(self.num_labels):
                Y_dense[example_idx][class_int] = example.get(
                    str(class_int), example["_default"]
                )
        Y_dense = Y_dense.astype(np.float)
        return Y_dense

    def _get_trained_model(self) -> TrainedMultiLabelTransformerClassificationModel:
        return TrainedMultiLabelTransformerClassificationModel(
            model=self.model,
            tokenizer=self.tokenizer,
            config=self.config,
            pretrained_model_name=self.pretrained_model_name,
            fields=self.fields,
            max_sequence_length=self.max_sequence_length,
            decision_threshold=self.decision_threshold,
            extraction_options=self.extraction_options,
            device=self.device,
        )


class TrainedSpanLayoutLMClassificationModel(TrainedTransformerClassificationModel):
    def predict(self, df: pd.DataFrame) -> Tuple[np.ndarray, np.ndarray]:
        # Eval!
        self.model.eval()
        self.device = torch.device("cuda" if is_gpu_available() else "cpu")
        self.model.to(self.device)
        predict_logits = []

        docs = df[self.fields]
        logger.info(f"***** Running predict for {self.pretrained_model_name} *****")
        logger.info(f"  Num examples = {len(docs)}")
        logger.info(f"  Batch size = {self.batch_size}")
        for doc_batch in tqdm(
            self._make_batches(docs, self.batch_size), desc="Predicting"
        ):
            encodings = get_layoutlm_model_encodings(
                doc_batch,
                fields=self.fields,
                tokenizer=self.tokenizer,
                max_seq_length=self.max_sequence_length,
            )
            # TODO: replace this with a call to Trainer.predict()
            input_ids = torch.stack([torch.tensor(e["input_ids"]) for e in encodings])
            bbox = torch.stack([torch.tensor(e["bbox"]) for e in encodings])
            token_type_ids = torch.stack(
                [torch.tensor(e["token_type_ids"]) for e in encodings]
            )
            attention_mask = torch.stack(
                [torch.tensor(e["attention_mask"]) for e in encodings]
            )
            with torch.no_grad():
                outputs = self.model(
                    input_ids.to(self.device),
                    bbox=bbox.to(self.device),
                    token_type_ids=token_type_ids.to(self.device),
                    attention_mask=attention_mask.to(self.device),
                )
                logits = outputs[0]
            predict_logits.append(logits.detach().cpu())

        predictions, prediction_probabilities = self._get_preds_and_probs(
            predict_logits
        )
        return predictions, prediction_probabilities


class TrainedDocLayoutLMClassificationModel(TrainedTransformerClassificationModel):
    def __init__(
        self,
        model: PreTrainedModel,
        tokenizer: PreTrainedTokenizer,
        pretrained_model_name: str,
        fields: List[str],
        max_sequence_length: int,
        decision_threshold: Optional[float],
        extraction_options: Optional[ExtractionOptions] = None,
        device: torch.device = torch.device("cpu"),
        page_aggregation: AggregationType = AggregationType.AVERAGE,
        config: Optional[PretrainedConfig] = None,
    ) -> None:
        self.model = model
        self.tokenizer = tokenizer
        self.pretrained_model_name = pretrained_model_name
        self.fields = fields
        self.max_sequence_length = max_sequence_length
        self.decision_threshold = decision_threshold
        self.extraction_options = extraction_options
        self.device = device
        self.page_aggregation = page_aggregation
        self.config = config
        self.batch_size = 64

    class Manifest(BaseManifest):
        class ExtractionOptionsModel(BaseModel):
            left_context_len: int
            right_context_len: int
            mask_span: bool

        model: Optional[str]
        tokenizer: Optional[str]
        pretrained_model_name: Optional[str]
        extraction_options: Optional[ExtractionOptionsModel]
        max_sequence_length: Optional[int]
        decision_threshold: Optional[float]
        device: Optional[str]
        page_aggregation: Optional[AggregationType]

    def save(self, dirpath: pathlib.Path) -> None:
        if self.config is None:
            raise ValueError("config cannot be None when saving")
        m = self.Manifest(type=self.__class__.__name__, model_fields=self.fields)
        # Save Transformer model
        model_dirname = "model"
        model_dirpath = dirpath / model_dirname
        model_dirpath.mkdir()
        saved_component = self._get_saved_component()
        saved_component.save_pretrained(str(model_dirpath), safe_serialization=False)
        m.model = model_dirname
        # Save tokenizer
        self.tokenizer.save_pretrained(str(model_dirpath))
        m.tokenizer = model_dirname
        # Save config (see https://github.com/huggingface/transformers/issues/4197)
        self.config.save_pretrained(str(model_dirpath))
        # Serialize extraction options
        if self.extraction_options is None:
            m.extraction_options = None
        else:
            m.extraction_options = self.Manifest.ExtractionOptionsModel.parse_obj(
                dict(
                    left_context_len=self.extraction_options.left_context_len,
                    right_context_len=self.extraction_options.right_context_len,
                    mask_span=self.extraction_options.mask_span,
                )
            )
        # Serialize other options
        m.pretrained_model_name = self.pretrained_model_name
        m.max_sequence_length = self.max_sequence_length
        m.decision_threshold = self.decision_threshold
        m.device = self.device.type
        m.page_aggregation = self.page_aggregation
        # Write manifest to disk
        with open(dirpath / "manifest.json", "w+") as mf:
            mf.write(m.json())

    @classmethod
    def load(
        cls, dirpath: str, storage_options: Optional[Dict[str, Any]] = None
    ) -> "TrainedDocLayoutLMClassificationModel":
        # Read the manifest
        storage_options = storage_options or {}
        manifest_path = os.path.join(dirpath, "manifest.json")
        with open_file(manifest_path, **storage_options) as mf:
            m = cls.Manifest.parse_raw(mf.read())
        # Load Transformer model
        assert m.model  # for mypy
        model_path = os.path.join(dirpath, m.model)
        if not urllib.parse.urlparse(model_path).scheme:
            model = cls._load_model(model_path)
        else:
            err_msg = f"Can only load local Transformer models, got {model_path}"
            raise UserInputError(
                detail=err_msg,
                user_friendly_message=err_msg,
                how_to_fix="Update the manifest.json to point to the correct model path",
            )
        # Load Transformer tokenizer
        assert m.tokenizer  # for mypy
        tokenizer_path = os.path.join(dirpath, m.tokenizer)
        if not urllib.parse.urlparse(tokenizer_path).scheme:
            tokenizer = AutoTokenizer.from_pretrained(
                tokenizer_path,
                use_fast=False,
                cache_dir=HFCacheSettings.PRETRAINED_CACHE_DIR,
            )
            # We must use Python-based tokenizer for inference until we have a transformers
            # version with this fix: https://github.com/huggingface/transformers/pull/12550
        else:
            err_msg = (
                f"Can only load local Transformer tokenizers, got {tokenizer_path}"
            )
            raise UserInputError(
                detail=err_msg,
                user_friendly_message=err_msg,
                how_to_fix="Update the manifest.json to point to the correct tokenizer path",
            )
        # Parse ExtractionOptions
        extraction_options: Optional[ExtractionOptions]
        if m.extraction_options:
            extraction_options = ExtractionOptions(
                left_context_len=m.extraction_options.left_context_len,
                right_context_len=m.extraction_options.right_context_len,
                mask_span=m.extraction_options.mask_span,
            )
        else:
            extraction_options = None
        # Construct the TrainedSklearnModel
        assert m.pretrained_model_name  # for mypy
        assert m.model_fields  # for mypy
        assert m.max_sequence_length  # for mypy
        assert m.page_aggregation  # for mypy
        return cls(
            model=model,
            tokenizer=tokenizer,
            pretrained_model_name=m.pretrained_model_name,
            fields=m.model_fields,
            max_sequence_length=m.max_sequence_length,
            decision_threshold=m.decision_threshold,
            extraction_options=extraction_options,
            page_aggregation=m.page_aggregation,
            device=torch.device(m.device),
        )

    def _predict_pages(self, df: pd.DataFrame) -> Tuple[np.ndarray, np.ndarray, Dict]:
        # Predicts per page
        self.model.eval()
        self.device = torch.device("cuda" if is_gpu_available() else "cpu")
        self.model.to(self.device)
        predict_logits = []
        doc_ids_dict = defaultdict(list)
        doc_index = 0

        docs = df[self.fields]
        logger.info(f"***** Running predict for {self.pretrained_model_name} *****")
        logger.info(f"  Num examples = {len(docs)}")
        logger.info(f"  Batch size = {self.batch_size}")
        for doc_batch in tqdm(
            self._make_batches(docs, self.batch_size), desc="Predicting"
        ):
            encodings = get_layoutlm_model_encodings(
                doc_batch,
                fields=self.fields,
                tokenizer=self.tokenizer,
                max_seq_length=self.max_sequence_length,
                token_level=False,
            )
            doc_ids = doc_index + np.array([e.pop("doc_id") for e in encodings])
            for doc_id in np.unique(doc_ids):
                doc_ids_dict[doc_id] = np.where(doc_ids == doc_id)[0].tolist()

            input_ids = torch.stack([torch.tensor(e["input_ids"]) for e in encodings])
            bbox = torch.stack([torch.tensor(e["bbox"]) for e in encodings])
            token_type_ids = torch.stack(
                [torch.tensor(e["token_type_ids"]) for e in encodings]
            )
            attention_mask = torch.stack(
                [torch.tensor(e["attention_mask"]) for e in encodings]
            )
            with torch.no_grad():
                outputs = self.model(
                    input_ids.to(self.device),
                    bbox=bbox.to(self.device),
                    token_type_ids=token_type_ids.to(self.device),
                    attention_mask=attention_mask.to(self.device),
                )
                logits = outputs[0]
            predict_logits.append(logits.detach().cpu())
            doc_index += len(doc_batch)

        preds, pred_probs = self._get_preds_and_probs(predict_logits)
        return preds, pred_probs, doc_ids_dict

    def predict(self, df: pd.DataFrame) -> Tuple[np.ndarray, np.ndarray]:
        """
        Find and aggregrate predictions for each document
        """
        page_preds, page_probs, doc_ids_dict = self._predict_pages(df)
        model_probs = []
        model_preds = []
        if len(df) == len(page_preds):
            # if single page documents, returning page predictions
            model_probs = page_probs
            model_preds = page_preds
        elif self.page_aggregation == AggregationType.MAX:
            # aggregating pages using most confident page prediction
            for doc_id in df.index:
                doc_probs = np.max(page_probs[doc_ids_dict[doc_id], :], axis=0)
                model_preds += [np.argmax(doc_probs)]
                model_probs += [list(doc_probs / np.sum(doc_probs))]
        elif self.page_aggregation == AggregationType.AVERAGE:
            # averaging confidence scores across pages by default
            for doc_id in df.index:
                doc_probs = np.mean(page_probs[doc_ids_dict[doc_id], :], axis=0)
                model_probs += [list(doc_probs)]
                model_preds += [np.argmax(doc_probs)]
        else:
            err_msg = f"page_aggregation {self.page_aggregation} not a supported type of aggregation"
            how_to_fix = f"Please set the page_aggregation in the model config to one of the following: {[AggregationType.MAX, AggregationType.AVERAGE]}"
            raise UserInputError(
                detail=err_msg, user_friendly_message=err_msg, how_to_fix=how_to_fix
            )

        return np.array(model_preds), np.array(model_probs)


class SpanLayoutLMClassificationModel(TransformerClassificationModel):
    def _train(
        self, df: pd.DataFrame, Y: np.ndarray, status_handler: Optional[Any] = None
    ) -> None:
        if not status_handler:
            status_handler = MockStatusHandler()
        status_handler.update_status(
            "Running model featurization", START_FEATURIZATION_PCT
        )

        train_args = TrainingArguments(
            self.model_checkpoint_dir,
            fp16=bool(self.device == "cuda"),
            learning_rate=self.learning_rate,
            per_device_train_batch_size=self.train_batch_size,
            num_train_epochs=self.num_train_epochs,
            gradient_accumulation_steps=self.gradient_accumulation_steps,
            max_grad_norm=self.max_grad_norm,
            weight_decay=self.weight_decay,
            disable_tqdm=True,
            warmup_steps=self.lr_warmup_steps,
        )

        train_encodings = get_layoutlm_model_encodings(
            df,
            fields=self.fields,
            tokenizer=self.tokenizer,
            max_seq_length=self.max_sequence_length,
        )
        train_dataset = LayoutLMDataset(train_encodings, Y)

        logger.info("***** Running training *****")
        logger.info("  Num examples = %d", len(train_dataset))
        logger.info("  Num Epochs = %d", self.num_train_epochs)
        logger.info("  Total train batch size  = %d", self.train_batch_size)
        logger.info(
            "  Gradient Accumulation steps = %d", self.gradient_accumulation_steps
        )
        status_handler.update_status("Training model", START_TRAINING_PCT)
        status_handler.start_end_model_training()

        trainer = Trainer(
            model=self.model, args=train_args, train_dataset=train_dataset
        )
        trainer.callback_handler.callbacks = [TrainStepCallback(status_handler)]
        trainer.train()

    def _get_trained_model(self) -> TrainedSpanLayoutLMClassificationModel:
        return TrainedSpanLayoutLMClassificationModel(
            model=self.model,
            tokenizer=self.tokenizer,
            config=self.config,
            pretrained_model_name=self.pretrained_model_name,
            fields=self.fields,
            max_sequence_length=self.max_sequence_length,
            decision_threshold=self.decision_threshold,
            extraction_options=self.extraction_options,
            device=self.device,
        )


class DocLayoutLMClassificationModel(TransformerClassificationModel):
    def __init__(self, model_config: ModelTrainingConfig) -> None:
        super().__init__(model_config)
        self.page_aggregation = self.model_config.options.get(
            "page_aggregation", AggregationType.AVERAGE
        )

    def _train(
        self, df: pd.DataFrame, Y: np.ndarray, status_handler: Optional[Any] = None
    ) -> None:
        if not status_handler:
            status_handler = MockStatusHandler()
        status_handler.update_status(
            "Running model featurization", START_FEATURIZATION_PCT
        )

        train_args = TrainingArguments(
            self.model_checkpoint_dir,
            fp16=bool(self.device == "cuda"),
            learning_rate=self.learning_rate,
            per_device_train_batch_size=self.train_batch_size,
            num_train_epochs=self.num_train_epochs,
            gradient_accumulation_steps=self.gradient_accumulation_steps,
            max_grad_norm=self.max_grad_norm,
            weight_decay=self.weight_decay,
            disable_tqdm=True,
            warmup_steps=self.lr_warmup_steps,
        )

        train_encodings = get_layoutlm_model_encodings(
            df,
            fields=self.fields,
            tokenizer=self.tokenizer,
            max_seq_length=self.max_sequence_length,
            token_level=False,
        )
        train_labels = np.array([Y[enc.pop("doc_id")] for enc in train_encodings])
        train_dataset = LayoutLMDataset(train_encodings, train_labels)

        logger.info("***** Running training *****")
        logger.info("  Num examples = %d", len(train_dataset))
        logger.info("  Num Epochs = %d", self.num_train_epochs)
        logger.info("  Total train batch size  = %d", self.train_batch_size)
        logger.info(
            "  Gradient Accumulation steps = %d", self.gradient_accumulation_steps
        )
        status_handler.update_status("Training model", START_TRAINING_PCT)
        status_handler.start_end_model_training()

        trainer = Trainer(
            model=self.model, args=train_args, train_dataset=train_dataset
        )
        trainer.callback_handler.callbacks = [TrainStepCallback(status_handler)]
        trainer.train()

    def _get_trained_model(self) -> TrainedDocLayoutLMClassificationModel:
        return TrainedDocLayoutLMClassificationModel(
            model=self.model,
            tokenizer=self.tokenizer,
            config=self.config,
            pretrained_model_name=self.pretrained_model_name,
            fields=self.fields,
            max_sequence_length=self.max_sequence_length,
            decision_threshold=self.decision_threshold,
            extraction_options=self.extraction_options,
            page_aggregation=self.page_aggregation,
            device=self.device,
        )
