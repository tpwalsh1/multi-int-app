from typing import Callable, List, Optional

from torch import Tensor
from torch.utils.data import DataLoader, Dataset

from api_utils.exceptions import SnorkelException
from snorkelflow.utils.load_image import load_cropped_minio_image, load_minio_image
from snorkelflow.utils.logging import get_logger

logger = get_logger("data loader")


class ImageDataset(Dataset):
    def __init__(
        self,
        image_paths: List[str],
        transform: Optional[Callable] = None,
        append_tensor_transform: bool = True,
    ) -> None:
        # NOTE Needs to be imported locally to not interfere with openapi
        from torchvision import transforms

        self.image_paths = image_paths
        self.transform = transform or transforms.ToTensor()

        if not isinstance(self.transform, transforms.Compose):
            self.transform = transforms.Compose([self.transform])

        # Automatically append transform.ToTensor() if missing
        if append_tensor_transform and not any(
            [isinstance(t, transforms.ToTensor) for t in self.transform.transforms]
        ):
            self.transform = transforms.Compose(
                self.transform.transforms + [transforms.ToTensor()]
            )
            logger.info("Appended ToTensor() transform to image dataset transforms")

    def __len__(self) -> int:
        return len(self.image_paths)

    def __getitem__(self, idx: int) -> Tensor:
        image = load_minio_image(self.image_paths[idx])
        return self.transform(image)


class ImageDataLoader(DataLoader):
    def __init__(
        self,
        image_paths: List[str],
        transform: Optional[Callable] = None,
        **kwargs: int,
    ) -> None:
        self.dataset = ImageDataset(image_paths=image_paths, transform=transform)
        super().__init__(self.dataset, **kwargs)


class PatchDataset(Dataset):
    def __init__(
        self,
        image_paths: List[str],
        bbox_list: List[List[float]],
        transform: Optional[Callable] = None,
        append_tensor_transform: bool = True,
    ) -> None:
        # NOTE Needs to be imported locally to not interfere with openapi
        from torchvision import transforms

        self.image_paths = image_paths
        self.bbox_list = bbox_list
        self.transform = transform or transforms.ToTensor()

        if not isinstance(self.transform, transforms.Compose):
            self.transform = transforms.Compose([self.transform])

        # Automatically append transform.ToTensor() if missing
        if append_tensor_transform and not any(
            [isinstance(t, transforms.ToTensor) for t in self.transform.transforms]
        ):
            self.transform = transforms.Compose(
                self.transform.transforms + [transforms.ToTensor()]
            )
            logger.info("Appended ToTensor() transform to patch dataset transforms")

    def __len__(self) -> int:
        return len(self.image_paths)

    def __getitem__(self, idx: int) -> Tensor:
        image = load_cropped_minio_image(self.image_paths[idx], self.bbox_list[idx])
        return self.transform(image)


class PatchDataLoader(DataLoader):
    def __init__(
        self,
        image_paths: List[str],
        bbox_list: List[List[float]],
        transform: Optional[Callable] = None,
        **kwargs: int,
    ) -> None:
        self.dataset = PatchDataset(
            image_paths=image_paths, bbox_list=bbox_list, transform=transform
        )
        super().__init__(self.dataset, **kwargs)


class TextDataset(Dataset):
    def __init__(self, texts: List[str], tokenizer: Callable) -> None:
        self.texts = texts
        self.tokenizer = tokenizer

    def __len__(self) -> int:
        return len(self.texts)

    def __getitem__(self, index: int) -> Tensor:
        if not isinstance(self.texts[index], str):
            user_friendly_message = (
                f"{self.texts[index]} is not a valid 'str'"
                "Please double check that provided data is valid."
            )
            detailed_message = (
                f"{self.texts[index]} at index={index} is not a valid 'str'"
                "Please double check that provided data is valid."
            )
            logger.error(detailed_message)
            raise SnorkelException(
                detail=detailed_message, user_friendly_message=user_friendly_message
            )
        tokens = self.tokenizer(self.texts[index])
        return tokens


class TextDataLoader(DataLoader):
    def __init__(self, texts: List[str], tokenizer: Callable, **kwargs: int) -> None:
        self.dataset = TextDataset(texts=texts, tokenizer=tokenizer)
        super().__init__(self.dataset, **kwargs)
