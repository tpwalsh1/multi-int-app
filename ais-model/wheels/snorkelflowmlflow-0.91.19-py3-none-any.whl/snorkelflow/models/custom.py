from typing import Any, Optional

import numpy as np
import pandas as pd

from snorkelflow.models.cls_model import ClassificationModelV2
from snorkelflow.models.model_configs import ModelTrainingConfig
from snorkelflow.serialization.code_asset import deserialize_asset


class CustomClassificationModelV2(ClassificationModelV2):
    def __init__(self, model_config: ModelTrainingConfig):
        super().__init__(model_config)
        self.custom_cls = None
        if model_config.model_cls == "CustomClassificationModelV2":
            assert "custom_model_info" in model_config.options
            self.custom_cls = deserialize_asset(
                model_config.options["custom_model_info"]["model_class_pickle"]
            )
        self.trained_model = None

    def _train(
        self, df: pd.DataFrame, Y: np.ndarray, status_handler: Optional[Any] = None
    ) -> None:
        assert self.custom_cls is not None
        self.trained_model = self.custom_cls.train(df, Y, status_handler)

    def _get_trained_model(self) -> Any:
        return self.trained_model
