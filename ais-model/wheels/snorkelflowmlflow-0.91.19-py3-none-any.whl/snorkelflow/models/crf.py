"""Training CRF models for SequenceTagging tasks."""
import os
import pathlib
import pickle
import sys
from typing import Any, Dict, List, Optional, Tuple, Union

import numpy as np
import pandas as pd
from numpy.random import Generator
from sklearn_crfsuite import CRF

from api_utils.exceptions import UserInputError
from file_utils.core import open_file
from snorkelflow.models.cls_model import (
    BaseManifest,
    ClassificationModelV2,
    TrainedClassificationModelV2,
)
from snorkelflow.models.model_configs import ModelTrainingConfig
from snorkelflow.models.utils import (
    LF_LABELS_COL_PREFIX,
    MODEL_CONFIG_OPTION_FIELDS,
    MODEL_CONFIG_OPTION_N_CLASSES,
    MODEL_CONFIG_OPTION_USE_LF_LABELS,
    START_FEATURIZATION_PCT,
    START_TRAINING_PCT,
    MockStatusHandler,
    preprocess_document_df,
)
from snorkelflow.utils.logging import get_logger

logger = get_logger("Models")

NEGATIVE_INDEX = 0
DEFAULT_PREDICT_BATCH_SIZE = 16
DEFAULT_FRACTION_OF_NEGATIVE_TOKENS = 0.5
MAX_TOKENS_TO_TRAIN_WITH = 1_000_000


class TrainedCRFModel(TrainedClassificationModelV2):
    def __init__(
        self,
        model: Any,
        tokenizer: Any,
        seq_task_field: str,
        c1: float,
        c2: float,
        num_neighbors: int,
        include_embedding: bool,
        max_iterations: int,
        use_lf_labels: bool,
        predict_batch_size: int,
        fraction_of_negative_tokens_to_use_for_training: float,
        num_labels: int,
    ) -> None:
        self.model = model
        self.tokenizer = tokenizer
        self.seq_task_field = seq_task_field
        self.c1 = c1
        self.c2 = c2
        self.num_neighbors = num_neighbors
        self.include_embedding = include_embedding
        self.max_iterations = max_iterations
        self.use_lf_labels = use_lf_labels
        self.predict_batch_size = predict_batch_size
        self.fraction_of_negative_tokens_to_use_for_training = (
            fraction_of_negative_tokens_to_use_for_training
        )
        self.num_labels = num_labels

    @staticmethod
    def _postprocess_model_outputs(
        tokens: Any, model_preds: List[str], model_probs: List[Dict], n_classes: int
    ) -> Tuple[List[List[Any]], List[List[Any]]]:
        # TODO refactor this function with sequence_tagging.py
        # Post-process the preds and probs for a single doc
        # Logic same to sequence_tagging.TrainedSequenceTaggingModel._postprocess_model_outputs
        preds = []
        probs = []
        current_pred_span = None
        current_prob_span = None
        # Convert string label to int label
        all_processed_preds = [int(out) for out in model_preds]
        all_processed_probs = []
        # Convert dict of probs to list of probs
        for model_prob in model_probs:
            raw_prob = [0] * n_classes
            for k, v in model_prob.items():
                raw_prob[int(k)] = v
            all_processed_probs.append(raw_prob)
        for token, token_pred, token_prob in zip(
            tokens, all_processed_preds, all_processed_probs
        ):
            char_start, char_end = token.idx, token.idx + len(token.text)
            if current_pred_span is not None and current_prob_span is not None:
                # NOTE: For the span, we keep the probability of the first token
                # Offsets should be sorted in increasing order
                assert char_start >= current_pred_span[1]
                if current_pred_span[2] == token_pred:
                    # Extend the current span
                    current_pred_span[1] = char_end
                    current_prob_span[1] = char_end
                    continue
                preds.append(current_pred_span)
                probs.append(current_prob_span)
            current_pred_span = [char_start, char_end, token_pred]
            current_prob_span = [char_start, char_end, token_prob]
        if current_pred_span is not None and current_prob_span is not None:
            # Append the last span
            preds.append(current_pred_span)
            probs.append(current_prob_span)

        if preds == []:
            # No real word tokens found, return dummy span as prediction
            preds = [[0, 1, 0]]
            probs = [[0, 1, [1 / n_classes] * n_classes]]

        return preds, probs

    def predict(self, df: pd.DataFrame) -> Tuple[np.ndarray, np.ndarray]:
        all_preds, all_probs = [], []

        for df_batch in self._make_batches(df, self.predict_batch_size):
            df_batch = preprocess_document_df(df_batch, self.seq_task_field)
            df_batch["tokens"] = df_batch.apply(
                lambda x: self.tokenizer(x[self.seq_task_field]), axis=1
            )
            X_pred = df_batch.apply(
                lambda x: _get_features(
                    x, self.include_embedding, self.num_neighbors, self.use_lf_labels
                ),
                axis=1,
            ).tolist()

            Y_pred = self.model.predict(X_pred)
            Y_prob = self.model.predict_marginals(X_pred)
            del X_pred
            n_classes = self.num_labels
            for i, (y_pred, y_prob) in enumerate(zip(Y_pred, Y_prob)):
                tokens = df_batch.tokens.iloc[i]
                preds, probs = self._postprocess_model_outputs(
                    tokens, y_pred, y_prob, n_classes
                )
                all_preds.append(preds)
                all_probs.append(probs)
        return np.array(all_preds), np.array(all_probs)

    class Manifest(BaseManifest):
        model: Optional[str]
        tokenizer: Optional[str]
        seq_task_field: Optional[str]
        c1: Optional[float]
        c2: Optional[float]
        include_embedding: Optional[bool]
        num_neighbors: Optional[int]
        max_iterations: Optional[int]
        use_lf_labels: Optional[bool]
        predict_batch_size: Optional[int]
        fraction_of_negative_tokens_to_use_for_training: Optional[float]
        num_labels: Optional[int]

    def save(self, dirpath: pathlib.Path) -> None:
        m = self.Manifest(
            type=self.__class__.__name__, model_fields=[self.seq_task_field]
        )
        m.c1 = self.c1
        m.c2 = self.c2
        m.include_embedding = self.include_embedding
        m.num_neighbors = self.num_neighbors
        m.max_iterations = self.max_iterations
        m.seq_task_field = self.seq_task_field
        m.use_lf_labels = self.use_lf_labels
        m.predict_batch_size = self.predict_batch_size
        m.fraction_of_negative_tokens_to_use_for_training = (
            self.fraction_of_negative_tokens_to_use_for_training
        )
        m.num_labels = self.num_labels
        dirpath.mkdir(parents=True, exist_ok=True)
        # Save model
        model_pickle = "model.pickle"
        with open(dirpath / model_pickle, "xb") as tf:
            pickle.dump(self.model, tf)

        # Save tokenizer
        tokenizer_pickle = "tokenizer.pickle"
        with open(dirpath / tokenizer_pickle, "xb") as tf:
            pickle.dump(self.tokenizer, tf)

        # Write manifest to disk
        with open(dirpath / "manifest.json", "w+") as mf:
            mf.write(m.json())

    @classmethod
    def load(
        cls, dirpath: str, storage_options: Optional[Dict[str, Any]] = None
    ) -> "TrainedCRFModel":
        # Read the manifest
        manifest_path = os.path.join(dirpath, "manifest.json")
        with open_file(
            manifest_path, **(storage_options if storage_options is not None else {})
        ) as mf:
            m = cls.Manifest.parse_raw(mf.read())

        model_path = os.path.join(dirpath, "model.pickle")
        with open_file(
            model_path,
            mode="rb",
            **(storage_options if storage_options is not None else {}),
        ) as tf:
            model = pickle.load(tf)

        tokenizer_path = os.path.join(dirpath, "tokenizer.pickle")
        with open_file(
            tokenizer_path,
            mode="rb",
            **(storage_options if storage_options is not None else {}),
        ) as tf:
            tokenizer = pickle.load(tf)
        assert m.seq_task_field  # for mypy
        assert m.c1 is not None  # for mypy
        assert m.c2 is not None  # for mypy
        assert m.max_iterations is not None  # for mypy
        assert m.include_embedding is not None  # for mypy
        assert m.num_neighbors is not None  # for mypy
        assert m.use_lf_labels is not None  # for mypy

        if m.predict_batch_size is None:
            m.predict_batch_size = DEFAULT_PREDICT_BATCH_SIZE
        if m.fraction_of_negative_tokens_to_use_for_training is None:
            m.fraction_of_negative_tokens_to_use_for_training = (
                DEFAULT_FRACTION_OF_NEGATIVE_TOKENS
            )
        if m.num_labels is None:
            m.num_labels = len(model.classes_)

        return cls(
            model=model,
            tokenizer=tokenizer,
            seq_task_field=m.seq_task_field,
            c1=m.c1,
            c2=m.c2,
            include_embedding=m.include_embedding,
            num_neighbors=m.num_neighbors,
            max_iterations=m.max_iterations,
            use_lf_labels=m.use_lf_labels,
            predict_batch_size=m.predict_batch_size,
            fraction_of_negative_tokens_to_use_for_training=m.fraction_of_negative_tokens_to_use_for_training,
            num_labels=m.num_labels,
        )


class CRFModel(ClassificationModelV2):
    label_space_cls_name = "SequenceLabelSpace"

    def __init__(self, model_config: ModelTrainingConfig):
        import spacy

        super().__init__(model_config)
        # Parse model config
        self.fields = self.model_config.options[MODEL_CONFIG_OPTION_FIELDS]
        self.seq_task_field = [
            field for field in self.fields if LF_LABELS_COL_PREFIX not in field
        ][0]

        self.c1 = self.model_config.options["c1"]
        self.c2 = self.model_config.options["c2"]
        self.include_embedding = self.model_config.options["include_embedding"]
        self.use_lf_labels = self.model_config.options[
            MODEL_CONFIG_OPTION_USE_LF_LABELS
        ]
        self.num_neighbors = self.model_config.options["num_neighbors"]
        if self.num_neighbors < 0:
            raise UserInputError(
                detail=f"num_neighbors must be >= 0",
                user_friendly_message=f"num_neighbors must be >= 0",
                how_to_fix=f"Set num_neighbors to be >= 0 in Model Options",
            )
        self.max_iterations = self.model_config.options["max_iterations"]
        self.predict_batch_size = self.model_config.options.get(
            "predict_batch_size", DEFAULT_PREDICT_BATCH_SIZE
        )
        self.max_tokens_to_train_with = min(
            self.model_config.options.get(
                "max_tokens_to_train_with", MAX_TOKENS_TO_TRAIN_WITH
            ),
            MAX_TOKENS_TO_TRAIN_WITH,
        )
        self.num_labels = self.model_config.options[MODEL_CONFIG_OPTION_N_CLASSES]
        self.fraction_of_negative_tokens_to_use_for_training = (
            self.model_config.options.get(
                "fraction_of_negative_tokens_to_use_for_training",
                DEFAULT_FRACTION_OF_NEGATIVE_TOKENS,
            )
        )
        self.tokenizer = spacy.load("en_core_web_sm")
        if (
            self.fraction_of_negative_tokens_to_use_for_training < 0
            or self.fraction_of_negative_tokens_to_use_for_training > 1
        ):
            err_msg = f"Fraction_of_negative_tokens_to_use_for_training must be between 0 and 1. Provided {self.fraction_of_negative_tokens_to_use_for_training}"
            raise UserInputError(
                detail=err_msg,
                user_friendly_message=err_msg,
                how_to_fix=f"Set fraction_of_negative_tokens_to_use_for_training to be between 0 and 1 in Model Options",
            )
        self.model = CRF(
            c1=self.c1,
            c2=self.c2,
            max_iterations=self.max_iterations,
            all_possible_transitions=True,
        )

    def _train(
        self, df: pd.DataFrame, Y: np.ndarray, status_handler: Optional[Any] = None
    ) -> None:
        if not status_handler:
            status_handler = MockStatusHandler()
        status_handler.update_status(
            "Running model featurization", START_FEATURIZATION_PCT
        )
        df = preprocess_document_df(df, self.seq_task_field)

        # Convert to token labels
        Y_list = []
        negative_label_filters = []
        tokens_list = []
        total_tokens = 0
        rng = np.random.default_rng(seed=123)
        for i in range(len(df)):
            tokens = self.tokenizer(df.iloc[i][self.seq_task_field])
            Y_labels = _get_token_labels(tokens, Y[i])
            Y_labels_sample, Y_labels_negative_filter = _get_subsampled_negative_labels(
                Y_labels, self.fraction_of_negative_tokens_to_use_for_training, rng
            )
            negative_label_filters.append(Y_labels_negative_filter)
            Y_list.append(Y_labels_sample)
            tokens_list.append(tokens)
            total_tokens += len(Y_labels_sample)
            if total_tokens >= self.max_tokens_to_train_with:
                break

        if i < len(df):
            df = df.head(i + 1)
            logger.info(
                f"Subsampled {i+1} docs to use for training to satisfy maximum {self.max_tokens_to_train_with} tokens limit"
            )
        df["negative_label_filter"] = negative_label_filters
        del negative_label_filters
        df["tokens"] = tokens_list
        del tokens_list
        logger.info("Fetching input features")

        X = (
            _get_features(
                df.iloc[i],
                self.include_embedding,
                self.num_neighbors,
                self.use_lf_labels,
            )
            for i in range(len(df))
        )

        logger.info("***** Running training *****")
        logger.info("  Num examples = %d", len(df))
        status_handler.update_status("Training model", START_TRAINING_PCT)
        status_handler.start_end_model_training()

        self.model.fit(X, Y_list)

    def _get_trained_model(self) -> TrainedCRFModel:
        return TrainedCRFModel(
            model=self.model,
            tokenizer=self.tokenizer,
            seq_task_field=self.seq_task_field,
            c1=self.c1,
            c2=self.c2,
            max_iterations=self.max_iterations,
            num_neighbors=self.num_neighbors,
            include_embedding=self.include_embedding,
            use_lf_labels=self.use_lf_labels,
            predict_batch_size=self.predict_batch_size,
            fraction_of_negative_tokens_to_use_for_training=self.fraction_of_negative_tokens_to_use_for_training,
            num_labels=self.num_labels,
        )


def _get_subsampled_negative_labels(
    token_labels: List[str],
    subsample_negative_labels_ratio: float,
    random_generator: Generator,
) -> Tuple[List[str], List[bool]]:
    label_filter = []
    filtered_labels = []
    # This is to make sure at least one negative label is added
    no_negative_label_added = True
    for i in range(len(token_labels)):
        if token_labels[i] == str(NEGATIVE_INDEX):
            if (
                not no_negative_label_added
                and random_generator.random() > subsample_negative_labels_ratio
            ):
                label_filter.append(False)
            else:
                no_negative_label_added = False
                label_filter.append(True)
                filtered_labels.append(token_labels[i])
        else:
            label_filter.append(True)
            filtered_labels.append(token_labels[i])
    return filtered_labels, label_filter


def _get_token_features(
    tokens: List[Any], lf_token_labels: Dict[str, List[Any]], include_embedding: bool
) -> List[List[Tuple[str, Any]]]:
    """
    For initial implementations, we use hard-coded features adapted from
    https://sklearn-crfsuite.readthedocs.io/en/latest/tutorial.html#features
    for faster iterations of model.
    The embeddings come from spacy built-in word-vectors (https://spacy.io/usage/embeddings-transformers)
    TODO (AY):
    (1) Turn the model features here into fields available for writing LFs in SF
    (2) Allow the user to select which of these features to use for modeling rather than hardcoding
    """
    features = []
    for tok_idx, token in enumerate(tokens):
        word = token.text
        feature_tuples = [
            (f"word", word),
            (f"word.lower()", word.lower()),
            (f"word[-3:]", word[-3:]),
            (f"word[-2:]", word[-2:]),
            (f"word.isupper()", word.isupper()),
            (f"word.istitle()", word.istitle()),
            (f"word.isdigit()", word.isdigit()),
            (f"word.ishyphen()", "-" in word),
            (f"pos", token.pos_),
            (f"tag", token.tag_),
            (f"dep", token.dep_),
        ]
        if include_embedding:
            embedding_vector = token.vector
            for i, val in enumerate(embedding_vector):
                feature_tuples.append((f"v_{i}", val))
        for lf_col_name, lf_labels in lf_token_labels.items():
            feature_tuples.append((f"{lf_col_name}", lf_labels[tok_idx]))
        features.append(feature_tuples)
    return features


def _get_features(
    x: pd.Series, include_embedding: bool, num_neighbors: int, use_lf_labels: bool
) -> List:
    if len(x.tokens) == 0:
        return []
    lf_label_tokens = {}
    input_data = x.to_dict()
    if use_lf_labels:
        for col, lf_raw_label in input_data.items():
            if col.startswith(LF_LABELS_COL_PREFIX):
                lf_label_tokens[col] = _get_token_labels(x.tokens, lf_raw_label)

    all_token_features = _get_token_features(
        x.tokens, lf_label_tokens, include_embedding
    )
    negative_label_filter = None
    if "negative_label_filter" in input_data:
        negative_label_filter = input_data["negative_label_filter"]

    # Add the features of the neighboring tokens
    all_token_features_w_neighbors = []
    for i in range(len(all_token_features)):
        if negative_label_filter and negative_label_filter[i] is False:
            # Ignore this token corresponding to a negative label
            continue
        token_features_w_neighbors = {"bias": 1.0}
        for offset in range(-num_neighbors, num_neighbors + 1):
            neighbor_index = i + offset
            if neighbor_index >= 0 and neighbor_index < len(all_token_features):
                for feature in all_token_features[neighbor_index]:
                    k, v = feature
                    token_features_w_neighbors[f"{offset}_{k}"] = v
        all_token_features_w_neighbors.append(token_features_w_neighbors)
    return all_token_features_w_neighbors


def _get_token_labels(
    tokens: Any, span_raw_labels: Union[np.ndarray, List]
) -> List[str]:
    # TODO refactor this function with sequence_tagging.py
    # Align span labels for a given doc to token labels, same logic as sequence.raw_labels_to_token_labels
    span_labels = _get_discretize_labels(span_raw_labels)
    token_labels = []
    if span_labels is None:
        span_labels = []
    sorted_spans = sorted(span_labels, key=lambda span: span[0])
    # Add a dummy span at the end so the while loop below terminates without going out of bounds.
    # Assume the unknown span is negative
    sorted_spans.append((sys.maxsize, sys.maxsize, NEGATIVE_INDEX))
    cur_span_idx = 0
    for token in tokens:
        token_label = NEGATIVE_INDEX
        token_start = token.idx
        token_end = token_start + len(token.text)
        span_start, span_end, span_class = sorted_spans[cur_span_idx]

        while span_end <= token_start:
            cur_span_idx += 1
            span_start, span_end, span_class = sorted_spans[cur_span_idx]
        # A token is labeled if any character is included in the labeled span
        if token_end > span_start:
            # If a token has two labels, we use the label that occurs first
            token_label = span_class
        # Convert UNKNOWN label to NEGATIVE
        if token_label < 0:
            token_label = NEGATIVE_INDEX
        token_labels.append(str(token_label))
    return token_labels


def _get_discretize_labels(raw_labels: Union[List, np.ndarray]) -> List:
    Y_span = []
    if type(raw_labels) not in {list, np.ndarray}:
        # This happens when raw_labels is None, and pd would convert None to nan
        raw_labels = []
    for span_raw_label in raw_labels:
        span_start, span_end, span_label = span_raw_label
        if type(span_label) in {list, np.ndarray}:
            # Discretize from probs to ints
            span_label = np.argmax(span_label)
        Y_span.append([span_start, span_end, span_label])
    return Y_span
