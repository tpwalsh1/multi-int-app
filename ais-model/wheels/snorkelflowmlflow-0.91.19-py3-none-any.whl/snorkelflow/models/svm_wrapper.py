from typing import Any, Tuple, Union

import numpy as np
import pandas as pd
import scipy.sparse as sp
from sklearn.svm import OneClassSVM


class SVMWrapper(OneClassSVM):
    def __init__(self, **kwargs: Any):
        self.outlier_class = kwargs.pop("outlier_class", 1)
        super().__init__(**kwargs)

    def fit(
        self, X: sp.coo_matrix, Y: Union[np.ndarray, pd.Series], **kwargs: Any
    ) -> None:
        X, Y = self._sample_one_class(X, Y, self.outlier_class)
        super().fit(X, Y)

    @staticmethod
    def _predict_proba_helper(scores: np.ndarray) -> np.ndarray:
        """Helper method to use decision function to map distance -> probabilities"""

        def sigmoid(X: np.ndarray) -> np.ndarray:
            return 1 / (1 + np.exp(X)).reshape(-1, 1)

        probs_pos_class = sigmoid(scores)
        probs_neg_class = 1 - probs_pos_class
        return np.hstack((probs_neg_class, probs_pos_class))

    def predict_proba(self, X: np.ndarray) -> np.ndarray:
        """Return probabilites for a binary classification problem"""
        # This return signed distance from hyperplane
        # Signed distance is positive for an inlier and negative for an outlier.
        scores = self.decision_function(X)
        return self._predict_proba_helper(scores)

    @staticmethod
    def _sample_one_class(
        X: sp.coo_matrix, Y: Union[np.ndarray, pd.Series], outlier_class: int = 1
    ) -> Tuple[sp.csr.csr_matrix, Union[np.ndarray, pd.Series]]:
        mask = Y != outlier_class
        if isinstance(mask, pd.core.series.Series):
            mask = mask.values
        # Convert to CSR format so that we can index
        X_csr = sp.csr_matrix(X)
        X_csr = X_csr[mask]

        if isinstance(Y, np.ndarray):
            Y = Y[mask]
        elif isinstance(Y, pd.core.series.Series):
            col_name = Y.name
            Y = Y[mask]
            Y = Y.reset_index()[col_name]
        else:
            y_type = type(Y)
            raise ValueError(f"Type of Y:{y_type} is not compatible")
        return X_csr, Y

    @staticmethod
    def _convert_to_regular_schema(y: np.ndarray) -> np.ndarray:
        """SKlearn label schema is 1 as inlier and -1 as outlier - need to convert this back"""
        if len(y) == 0:
            return np.array([])
        skl_to_reg_label_mapper = lambda x: 0 if x == 1 else 1
        skl_to_reg_func = np.vectorize(skl_to_reg_label_mapper)
        return skl_to_reg_func(y).reshape(-1, 1)

    def predict(self, X: pd.DataFrame) -> np.ndarray:
        preds = super().predict(X)
        return self._convert_to_regular_schema(preds)
