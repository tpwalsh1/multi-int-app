import os
import pathlib
import pickle
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

from api_utils.exceptions import NotSupportedException
from file_utils.core import open_file
from snorkelflow.models.cls_model import BaseManifest, TrainedClassificationModelV2


class TrainedLabelModel(TrainedClassificationModelV2):
    # NOTE: Be very careful when updating the Manifest, so as not to break
    # backwards compatibility. For example, this means only adding optional fields,
    # avoiding edits of existing fields, etc.
    class Manifest(BaseManifest):
        pass

    def __init__(self, model: Any, fields: List[str]):
        if "BaseInferenceLabelModel" not in {t.__name__ for t in type(model).__mro__}:
            raise ValueError("Model is not a BaseInferenceLabelModel")
        self.model = model
        self.model_fields = fields

    def predict(self, df: pd.DataFrame) -> Tuple[np.ndarray, Optional[np.ndarray]]:
        """Predicts model output (predictions, probabilities) from input data using trained model."""
        # ensure that the order of the model fields and dataframe columns are the same, which is
        # critical for the label model
        df = df[self.model_fields]
        label_space = self.model.get_label_space()
        if len(df) > 1 and len(df.columns) > 0:
            # This model currently only supports MultiLabelSpace and SingleLabelSpace
            # The label space in the model doesn't necessarily correspond to the label space
            # of the task (e.g. SequenceLabelSpace uses SingleLabelSpace label models), so
            # for now, directly check the labeling function output format
            lf_label_type = type(df.iloc[0][df.columns[0]])
            if lf_label_type != dict and not np.issubdtype(lf_label_type, np.integer):
                raise NotSupportedException(
                    f"TrainedLabelModel not supported for label format type {lf_label_type}."
                )

        if type(label_space).__name__ == "MultiLabelSpace":
            # Converts the RawLabel format LF labels to sparse tensor of shape
            # [num_examples, num_lfs, num_classes, 2] for label model compatibility
            df.columns = list(range(len(df.columns)))
            sparse_rows = df.to_dict(orient="records")
            L = label_space._make_sparse_L_tensor(sparse_rows, len(df.columns))
        else:
            L = np.asarray(df.to_numpy().tolist())
        # Since an end model shouldn't abtain, don't filter out uncertain labels nor unlabeled,
        # and break ties using the same policy as in training set creation with register_model=True
        return self.model.predict(
            L,
            tie_break_policy="random",
            filter_unlabeled=False,
            filter_uncertain_labels=False,
        )

    def save(self, dirpath: pathlib.Path) -> None:
        m = self.Manifest(type=self.__class__.__name__, model_fields=self.model_fields)

        model_pickle = "model.pickle"
        with open(dirpath / model_pickle, "xb") as tf:
            pickle.dump(self.model, tf)

        with open(dirpath / "manifest.json", "w+") as mf:
            mf.write(m.json())

    @classmethod
    def load(
        cls, dirpath: str, storage_options: Optional[Dict[str, Any]] = None
    ) -> "TrainedClassificationModelV2":
        """Loads model from disk."""
        storage_options = storage_options or {}

        manifest_path = os.path.join(dirpath, "manifest.json")
        with open_file(manifest_path, **storage_options) as mf:
            m = cls.Manifest.parse_raw(mf.read())

        model_path = os.path.join(dirpath, "model.pickle")
        with open_file(model_path, mode="rb", **storage_options) as tf:
            model = pickle.load(tf)
        return cls(model, m.model_fields or [])
