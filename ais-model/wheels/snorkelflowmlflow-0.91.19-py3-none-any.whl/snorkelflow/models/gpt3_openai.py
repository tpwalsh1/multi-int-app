"""Training GPT3 models for Classification tasks."""
import json
import os
import pathlib
import tempfile
import time
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import openai
import pandas as pd
import re2
from secret_clients import SecretAccessMixin, SecretClient

from api_utils.exceptions import FailedJobError, RequestTimeout, UserInputError
from file_utils.core import open_file
from snorkelflow.models.cls_model import (
    BaseManifest,
    ClassificationModelV2,
    TrainedClassificationModelV2,
)
from snorkelflow.models.model_configs import ModelTrainingConfig
from snorkelflow.models.utils import (
    MODEL_CONFIG_OPTION_FIELDS,
    MODEL_CONFIG_OPTION_N_CLASSES,
    MODEL_CONFIG_OPTION_USE_LF_LABELS,
    START_FEATURIZATION_PCT,
    START_TRAINING_PCT,
    TOTAL_TRAINING_PCT,
    MockStatusHandler,
    merge_columns,
    preprocess_document_df,
)
from snorkelflow.utils.logging import get_logger

logger = get_logger("Models")

JSONL_DATA_FILE = "_training_data.jsonl"
DEFAULT_LABEL_INT = 0
PROMPT_QUESTION = "Classify a piece of text into the following categories:"
PROMPT_QUERY_START = "\n Text: "
PROMPT_QUERY_KEY = " --> Category: "
DEFAULT_TIME_SLEEP = 30
# Max cap for OpenAI is 2048 & split tokens ~ 3/4 of GPT3 tokens - using 1400 to be safe
DEFAULT_TOKEN_CAP = 1400
DEFAULT_TOKEN_SPLIT_PROXY = " "


class TrainedGPT3Model(TrainedClassificationModelV2, SecretAccessMixin):
    def __init__(
        self,
        secret_store_key: str,
        model: str,
        model_id: str,
        fields: List[str],
        labels: List[str],
        max_text_chars: int,
        n_epochs: int,
        learning_rate_multiplier: float,
        batch_size: int,
        max_timeout_minutes: int,
        file_name: str,
    ) -> None:
        """TrainedGPT3Model
        Not all parameters are required for inference, but we keep them for model repro-ing purposes.

        Args:
            secret_store_key (str): Secret store key
            model (str): GPT3 model type (e.g., ada, babbage, curie)
            model_id (str): GPT3 model id - retrieve from openai jobs
            fields (List[str]): Fields used for inference
            labels (List[str]): List of label string converted from label_int
            max_text_chars (int): Maximum characters using for training model (to avoid token overflow)
            n_epochs (int): Number of epochs
            learning_rate_multiplier (float): OpenAI learning rate
            batch_size (int): Batch size
            max_timeout_minutes (int): Max time (minutes) before we timeout
            file_name (str): File name of the training set sent to OpenAI
        """
        self.secret_store_key = secret_store_key
        self.model = model
        self.model_id = model_id
        self.fields = fields
        self.labels = labels
        self.max_text_chars = max_text_chars
        self.n_epochs = n_epochs
        self.learning_rate_multiplier = learning_rate_multiplier
        self.batch_size = batch_size
        self.max_timeout_minutes = max_timeout_minutes
        self.file_name = file_name

    @property
    def secret_client_cls(self) -> List[str]:
        return ["OpenAIClient"]

    @property
    def secret_keys(self) -> List[Dict[str, Tuple[str, str]]]:
        return [{"openai_api_key": (self.secret_store_key, "local_store")}]

    def set_secret_clients(self, clients: List[SecretClient]) -> None:
        self.openai_client = clients[0]
        self.openai_client.add_key_to_openai_module(openai)  # type: ignore

    def _get_openai_predictions(self, prompts: List[str], n_classes: int) -> Any:
        num_prompts = len(prompts)
        try:
            openai_preds = []
            for batch in range(int(np.ceil(num_prompts / self.batch_size))):
                openai_pred = openai.Completion.create(
                    model=self.model_id,
                    prompt=prompts[
                        self.batch_size
                        * batch : min(num_prompts, self.batch_size * (batch + 1))
                    ],
                    max_tokens=1,
                    temperature=0,
                    logprobs=n_classes,
                )
                openai_preds.extend(openai_pred["choices"])

        except openai.error.AuthenticationError:
            err_msg = "Incorrect OpenAI key provided"
            raise UserInputError(
                err_msg,
                err_msg,
                how_to_fix="Please add your OpenAI credentials to use FM",
            )

        except openai.error.RateLimitError:
            err_msg = "Credit limit exceeded"
            raise UserInputError(
                err_msg,
                err_msg,
                how_to_fix="Please add more credit to your OpenAI account",
            )
        return openai_preds

    def predict(self, df: pd.DataFrame) -> Tuple[np.ndarray, np.ndarray]:
        df = _preprocess_df(df, self.labels, self.fields, self.max_text_chars)
        n_classes = len(self.labels)

        openai_preds = self._get_openai_predictions(
            prompts=list(df), n_classes=n_classes
        )
        preds, probs = _postprocess_model_outputs(
            openai_preds=openai_preds, n_classes=n_classes
        )
        return preds, probs

    class Manifest(BaseManifest):
        secret_store_key: Optional[str]
        model: Optional[str]
        model_id: Optional[str]
        fields: Optional[List[str]]
        labels: Optional[List[str]]
        max_text_chars: Optional[int]
        n_epochs: Optional[int]
        learning_rate_multiplier: Optional[float]
        batch_size: Optional[int]
        max_timeout_minutes: Optional[int]
        file_name: Optional[str]

    def save(self, dirpath: pathlib.Path) -> None:
        m = self.Manifest(type=self.__class__.__name__, model_fields=self.fields)
        m.secret_store_key = self.secret_store_key
        m.model = self.model
        m.max_text_chars = self.max_text_chars
        m.fields = self.fields
        m.labels = self.labels
        m.model_id = self.model_id
        m.n_epochs = self.n_epochs
        m.learning_rate_multiplier = self.learning_rate_multiplier
        m.batch_size = self.batch_size
        m.max_timeout_minutes = self.max_timeout_minutes
        m.file_name = self.file_name

        # Write manifest to disk
        with open(dirpath / "manifest.json", "w+") as mf:
            mf.write(m.json())

    @classmethod
    def load(
        cls, dirpath: str, storage_options: Optional[Dict[str, Any]] = None
    ) -> "TrainedGPT3Model":
        # Read the manifest
        manifest_path = os.path.join(dirpath, "manifest.json")
        with open_file(
            manifest_path, **(storage_options if storage_options is not None else {})
        ) as mf:
            m = cls.Manifest.parse_raw(mf.read())

        assert m.secret_store_key is not None  # for mypy
        assert m.model  # for mypy
        assert m.model_id is not None  # for mypy
        assert m.fields is not None  # for mypy
        assert m.labels is not None  # for mypy
        assert m.max_text_chars is not None  # for mypy
        assert m.n_epochs is not None  # for mypy
        assert m.learning_rate_multiplier is not None  # for mypy
        assert m.batch_size is not None  # for mypy
        assert m.max_timeout_minutes is not None  # for mypy
        assert m.file_name is not None  # for mypy

        return cls(
            secret_store_key=m.secret_store_key,
            model=m.model,
            model_id=m.model_id,
            fields=m.fields,
            labels=m.labels,
            max_text_chars=m.max_text_chars,
            n_epochs=m.n_epochs,
            learning_rate_multiplier=m.learning_rate_multiplier,
            batch_size=m.batch_size,
            max_timeout_minutes=m.max_timeout_minutes,
            file_name=m.file_name,
        )


class GPT3Model(ClassificationModelV2, SecretAccessMixin):
    label_space_cls_name = "SingleLabelSpace"

    def __init__(self, model_config: ModelTrainingConfig):
        """GPT3Model model_config (in addition to the default config)

        Args:
            model (str): GPT3 model type (e.g., ada, babbage, curie)
            max_text_chars (int): Maximum characters using for training model (to avoid token overflow)
            n_epochs (int): Number of epochs
            learning_rate_multiplier (float): OpenAI learning rate
            batch_size (int): Batch size
            max_timeout_minutes (int): Max time (minutes) before we timeout
            model_id (str): If provided, use this model and skip fine-tuning step
            cancel_if_timeout (bool): If provided as False, we don't cancel the fine-tune job on OpenAI when timeout
        """

        super().__init__(model_config)
        if self.model_config.options[MODEL_CONFIG_OPTION_USE_LF_LABELS]:
            raise ValueError(
                "LF labels features are not yet available for GPT-3 models"
            )

        self.secret_store_key = self.model_config.options["secret_store_key"]

        # Parse model config
        self.fields = self.model_config.options[MODEL_CONFIG_OPTION_FIELDS]
        self.num_labels = self.model_config.options[MODEL_CONFIG_OPTION_N_CLASSES]
        self.model = self.model_config.options["model"]
        self.max_text_chars = self.model_config.options["max_text_chars"]
        self.n_epochs = self.model_config.options["n_epochs"]
        self.batch_size = self.model_config.options["batch_size"]
        self.max_timeout_minutes = self.model_config.options["max_timeout_minutes"]
        self.learning_rate_multiplier = self.model_config.options[
            "learning_rate_multiplier"
        ]

        # Parameters for power user:
        # model_id allow pulling OpenAI model w/o retraining
        # cancel_in_timeout (if False) will not cancel the training job on OpenAI portal
        # User can then retrieve the model_id from OpenAI and reinject to Snorkel
        self.model_id = self.model_config.options.get("model_id", "")
        self.cancel_if_timeout = self.model_config.options.get(
            "cancel_if_timeout", True
        )

        self.labels = [str(val) for val in range(self.num_labels)]

    @property
    def secret_client_cls(self) -> List[str]:
        return ["OpenAIClient"]

    @property
    def secret_keys(self) -> List[Dict[str, Tuple[str, str]]]:
        return [{"openai_api_key": (self.secret_store_key, "local_store")}]

    def set_secret_clients(self, clients: List[SecretClient]) -> None:
        self.openai_client = clients[0]
        self.openai_client.add_key_to_openai_module(openai)  # type: ignore

    def _create_openai_dataset(self, training_data: pd.DataFrame) -> str:
        """
        OpenAI requires a JSONL formatted data set uploaded to their service.
        This function will return the file-id of the training file.
        Saved the file to tmp because we can later retrieve this from OpenAI.

        Args:
            training_data (pd.DataFrame): Training dataset

        Returns:
            file_id (str): OpenAI file id
        """
        with tempfile.TemporaryDirectory() as dir:
            tmppath = os.path.join(dir, JSONL_DATA_FILE)
            self.file_name = tmppath
            with open(self.file_name, "w") as outfile:
                for entry in training_data:
                    json.dump(entry, outfile)
                    outfile.write("\n")

            with open(self.file_name) as f:
                try:
                    file_creation_response = openai.File.create(
                        file=f, purpose="fine-tune"
                    )
                    file_id: str = file_creation_response["id"]
                except openai.error.AuthenticationError:
                    err_msg = "Incorrect OpenAI key provided"
                    raise UserInputError(
                        err_msg,
                        err_msg,
                        how_to_fix="Please add your OpenAI credentials to use FM",
                    )

        logger.info(f"***** OpenAI File ID: {file_id} *****")
        return file_id

    def _model_fine_tuning_openai(self, status_handler: Optional[Any] = None) -> str:
        """Model fine tuning via OpenAI

        Returns:
            str: Fine-tuned model id
        """
        if not status_handler:
            status_handler = MockStatusHandler()

        try:
            fine_tune_response = openai.FineTune.create(
                training_file=self.file_name,
                model=self.model,
                n_epochs=self.n_epochs,
                batch_size=self.batch_size,
                learning_rate_multiplier=self.learning_rate_multiplier,
            )
            fine_tune_id = fine_tune_response["id"]
        except openai.error.RateLimitError:
            err_msg = "Credit limit exceeded"
            raise UserInputError(
                err_msg,
                err_msg,
                how_to_fix="Please add more credit to your OpenAI account",
            )

        # Cannot let SF wait forever -> wait max_timeout_minutes minutes
        # We refresh every 30s -> max_timeout_minutes * 2 iterations
        iterations_limit = self.max_timeout_minutes * 2
        cur_pct = START_TRAINING_PCT

        while iterations_limit > 0:
            fine_tuned_response = openai.FineTune.retrieve(id=fine_tune_id)
            model_id = fine_tuned_response["fine_tuned_model"]

            # log & update_status purposes
            event_message = fine_tuned_response["events"][-1]["message"]
            logger.info(f"***** Event: {event_message} *****")
            update_message, cur_pct = _openai_message_parser(event_message, cur_pct)
            status_handler.update_status(update_message, cur_pct)

            if str(model_id) != "None":
                break

            if "Fine-tune failed" in event_message:
                simple_message = "OpenAI fine-tune jobs failed"
                raise FailedJobError(
                    detail=event_message, user_friendly_message=simple_message
                )

            iterations_limit -= 1
            time.sleep(DEFAULT_TIME_SLEEP)

        if str(model_id) == "None":
            # Model did not finished or having some issues
            tle_message = "OpenAI time limit exceeded. Please increase max_timeout_minutes or retry later"

            # Cancel the job on OpenAI if we hit timeout while waiting for model to train
            if self.cancel_if_timeout:
                openai.FineTune.cancel(id=fine_tune_id)
                status_handler.update_status("Cancelling OpenAI job", 0)

            # User specify parameter to not cancel the job
            else:
                tle_message += (
                    f". {fine_tune_id}-fine-tune job remain running on OpenAI"
                )
                status_handler.update_status("OpenAI job still running on OpenAI", 0)

            logger.info(f"***** Event: {tle_message} *****")
            status_handler.update_status(tle_message, 0)
            raise RequestTimeout(detail=tle_message, user_friendly_message=tle_message)

        logger.info(f"***** OpenAI Model ID: {model_id} *****")
        return model_id

    def _train(
        self, df: pd.DataFrame, Y: np.ndarray, status_handler: Optional[Any] = None
    ) -> None:
        if not status_handler:
            status_handler = MockStatusHandler()

        if self.model_id:
            self.file_name = ""
            status_handler.update_status("Model id registered", TOTAL_TRAINING_PCT)
            return

        status_handler.update_status(
            "Running model featurization", START_FEATURIZATION_PCT
        )
        prompt_data = _preprocess_df(df, self.labels, self.fields, self.max_text_chars)
        prompt_data_for_training = _dict_training_prompt_construction(prompt_data, Y)

        self.file_name = self._create_openai_dataset(prompt_data_for_training)

        logger.info("***** Running training *****")
        logger.info("  Num examples = %d", len(df))
        status_handler.update_status("Training model", START_TRAINING_PCT)
        status_handler.start_end_model_training()

        self.model_id = self._model_fine_tuning_openai(status_handler)

    def _get_trained_model(self) -> TrainedGPT3Model:
        return TrainedGPT3Model(
            secret_store_key=self.secret_store_key,
            model=self.model,
            fields=self.fields,
            labels=self.labels,
            model_id=self.model_id,
            max_text_chars=self.max_text_chars,
            n_epochs=self.n_epochs,
            learning_rate_multiplier=self.learning_rate_multiplier,
            batch_size=self.batch_size,
            max_timeout_minutes=self.max_timeout_minutes,
            file_name=self.file_name,
        )


def _tokens_truncate(text: str, max_text_chars: int) -> str:
    """Tokens truncating: Guardrail to over tokens overflow in GPT3"""
    text = text[:max_text_chars]
    tokens = text.split(DEFAULT_TOKEN_SPLIT_PROXY)[:DEFAULT_TOKEN_CAP]
    return DEFAULT_TOKEN_SPLIT_PROXY.join(tokens)


def _dict_training_prompt_construction(
    prompts: str, labels: List[str]
) -> List[Dict[str, Any]]:
    """Prompt construction for training:
    OpenAI requires training data as dict(prompt: "...", completion: "...)
    """
    return [
        dict(prompt=prompt, completion=str(label))
        for (prompt, label) in zip(prompts, labels)
    ]


def _prompt_construction(text: str, labels: List[str], max_text_chars: int) -> str:
    """Prompt construction in general:
    Prompt construction to made the output tokens compatible for classification:
    """
    instruction = f"{PROMPT_QUESTION} {', '.join(labels)}. {PROMPT_QUERY_START}"
    truncated_text = _tokens_truncate(text, max_text_chars)
    prompt = instruction + truncated_text + PROMPT_QUERY_KEY
    return prompt


def _preprocess_df(
    df: pd.DataFrame, labels: List[str], fields: List[str], max_text_chars: int
) -> pd.DataFrame:
    """Preprocess dataframe to be compatible with OpenAI
    Steps include: Remove index fields, convert all columns to text,
    merge relevant fields, and create prompt from the provided text.

    Args:
        df (pd.DataFrame): Dataset
        labels (List[str]): List of label_str
        fields (List[str]): Fields for training
        max_text_chars (int): Maximum characters for input fields

    Returns:
        pd.DataFrame: OpenAI compatible dataset
    """

    logger.info(
        f"***** Preprocess data: length({len(df)}, labels({labels}, fields({fields}))) *****"
    )

    if "index" in fields:
        fields.remove("index")

    for field in fields:
        df = preprocess_document_df(df, field)

    train_data = merge_columns(df, fields)
    prompt_data = train_data.apply(
        lambda x: _prompt_construction(x, labels, max_text_chars)
    )
    return prompt_data


def _postprocess_model_outputs(
    openai_preds: Any, n_classes: int
) -> Tuple[np.ndarray, np.ndarray]:
    """Model postprocessing for GPT3
    GPT3 is a free text output model, hence, we need postprocessing to fit into CLF metrics

    """

    preds_list: list = openai_preds
    preds_probs = []

    # Get each datapoint prediction
    for value in preds_list:
        # Get prediction and logprob
        pred: str = value["text"]
        pred = pred.strip().rstrip(
            "."
        )  # Sometimes, the prediction has trailing "." or extra " "
        logprob: float = value["logprobs"]["token_logprobs"][0]

        # If pred is a float and 0 <= round(pred_int) < n_classes
        if pred.isnumeric() and (0 <= int(pred) < n_classes):
            int_pred = int(pred)
            prob = np.exp(logprob)
            prob_list = _get_prob_list(prob, n_classes, int_pred)
            preds_probs.append((int_pred, prob_list))
        else:
            logger.info(f"***** prediction not compatible: {pred} *****")
            abstain_prob_list = [1 / n_classes] * n_classes
            preds_probs.append((DEFAULT_LABEL_INT, abstain_prob_list))

    preds_probs_array = np.array(preds_probs).T
    logger.info(f"***** Prediction array shape: {preds_probs_array.shape} *****")
    return preds_probs_array


def _get_prob_list(prob: float, num_classes: int, pred: int) -> List[float]:
    """As GPT3 is not a CLF model, and we are forcing it to be, the preds and probs
    might not fit to the standard settings.
    Assumption and work-around: we use the prob from the top results
    and assume the probs for other classes are equal.
    """
    avg_prob = (1 - prob) / (num_classes - 1)
    probs = [avg_prob] * num_classes
    probs[pred] = prob
    return probs


def _openai_message_parser(text: str, cur_pct: int) -> Tuple[str, int]:
    """OpenAI message parser to display into the progress bar
    Update progress when models are in queue or finish training

    Args:
        text (str): current event message from OpenAI
        cur_pct (int): current percentage progress

    Returns:
        Tuple[str, int]: Updated message & updated stats
    """
    pattern_when_in_queue = re2.findall(r"Queue number: \d+$", text)
    pattern_when_in_epoch = re2.findall(r"Completed epoch \d+\/\d+$", text)
    boolean_when_fine_tune_id_exposed = re2.findall(r"ft-\w+\b", text)

    # Status when fine_tune_id expose:
    # Replaced the ft-id = Hidden OpenAI ID
    if boolean_when_fine_tune_id_exposed:
        return re2.sub(r"ft-\w+\b", "", text), cur_pct

    # Status when model in the queue:
    # OpenAI message: Fine-tune is in the queue. Queue number: x
    if pattern_when_in_queue:
        return pattern_when_in_queue[0], cur_pct

    # Status when created fine-tune (exposed fine-tune id):
    # OpenAI message: Fine-tune is in the queue. Queue number: x
    if pattern_when_in_queue:
        return pattern_when_in_queue[0], cur_pct

    # Status when model in the epoch training:
    # OpenAI message: Completed epoch x/y
    elif pattern_when_in_epoch:
        digits = re2.findall(r"Completed epoch (\d+)\/(\d+)$", text)[0]
        numerator, denominator = int(digits[0]), int(digits[1])

        # training-dedicated progress = TOTAL_TRAINING_PCT - START_TRAINING_PCT
        # Progress done within the training-dedicated progress = x/y * training-dedicated progress
        # Total progress done = start_percentage + Progress done within the training-dedicated progress
        percentage_done = int(
            (numerator / denominator) * (TOTAL_TRAINING_PCT - START_TRAINING_PCT)
        )
        return pattern_when_in_epoch[0], START_TRAINING_PCT + percentage_done

    return text, cur_pct
