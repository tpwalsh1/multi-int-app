"""Avoid new 3rd party imports, see special_utils.py."""
__all__ = ["num_to_feature", "get_span_field", "get_extraction_features", "TrainStatus"]
from functools import partial
from typing import Any, Iterable, List, NamedTuple, Optional

import numpy as np
import pandas as pd
import scipy as sp
from pandas.api.types import is_numeric_dtype
from sklearn.feature_extraction.text import (
    CountVectorizer,
    HashingVectorizer,
    TfidfVectorizer,
)
from sklearn.preprocessing import MaxAbsScaler

from snorkelflow.extraction.span import SPAN_TOKEN, SpanCols
from snorkelflow.models.model_configs import ModelTrainingConfig
from snorkelflow.utils.logging import get_logger

logger = get_logger("Models")
VECTORIZERS_DICT = {
    "CountVectorizer": CountVectorizer,
    "HashingVectorizer": HashingVectorizer,
    "TfidfVectorizer": TfidfVectorizer,
}
SKLEARN_PREPROCESSOR_DICT = {"MaxAbsScaler": MaxAbsScaler}
START_TRAINING_PCT = 0
TOTAL_TRAINING_PCT = 100
START_FEATURIZATION_PCT = 0
DEFAULT_DECISION_THRESHOLD = 0.5
# Constants used for backend generated model config options
MODEL_CONFIG_OPTION_FIELDS = "_fields"
MODEL_CONFIG_OPTION_N_CLASSES = "_n_classes"
MODEL_CONFIG_OPTION_USE_LF_LABELS = "_use_lf_labels"
MODEL_CONFIG_OPTION_LF_UIDS = "_lf_uids"
MODEL_CONFIG_OPTION_USE_NOISE_AWARE_LABELS = "_use_noise_aware_labels"
MODEL_CONFIG_OPTION_DECISION_THRESHOLD = "_decision_threshold"
MODEL_CONFIG_OPTION_FILTER_CONFIDENCE_LABELS = "_filter_uncertain_labels"
MODEL_CONFIG_OPTION_TRAIN_ON_DEV_DATA = "_train_on_dev_data"
MODEL_CONFIG_OPTION_PREDICT_ON_DEV_DATA = "_predict_on_dev_data"
# Field name constants
EXTRACTION_CONTEXT_FIELD = "__EXTRACTION_CONTEXT"
# Field name constants for lf label
LF_LABELS_COL_PREFIX = "__LF_LABEL"


def lf_label_col_names(lf_uids: Iterable[int]) -> List[str]:
    return [f"{LF_LABELS_COL_PREFIX}_{lf_uid}" for lf_uid in lf_uids]


class TrainStatus(NamedTuple):
    """Training status for model train iterator."""

    complete: bool
    percent: int
    message: str
    failed: bool
    sub_status: bool = False
    step: int = 0


def num_to_feature(
    series: pd.Series, numeric_nan_padding: Optional[int] = 0
) -> sp.sparse.csr_matrix:
    if numeric_nan_padding is not None:
        series = series.fillna(numeric_nan_padding)
    else:
        series = series.fillna(0)
    feature = series.to_numpy()[:, np.newaxis]
    return sp.sparse.csr_matrix(np.nan_to_num(feature))


def get_span_field(df: pd.DataFrame, use_span_field: bool) -> str:
    """Fetch the name of the single span_field column to use for featurization

    If the span_field is not available then we fall back to using span_preview instead.

    WARNING: In this part of the code, we assume that all spans have the same span_field.
    Other places in the code do not require this, but we plan to soon make this the case.
    """
    if SpanCols.SPAN_FIELD in df.columns:
        if len(df[SpanCols.SPAN_FIELD].unique()) > 1:
            raise ValueError("span_field must be the same for all rows in the df.")

        span_field = df[SpanCols.SPAN_FIELD].iloc[0]
    else:
        # Set span_field to None so we fall back to span_preview below.
        span_field = None

    # If the span_field has been dropped from the dataframe (e.g.,
    # because it is a 300 page document and we don't want to make a copy of
    # that document for every candidate), use "span_preview" instead.
    if span_field is None or span_field not in df.columns:
        if use_span_field:
            raise ValueError(
                "Span field missing in DataFrame. "
                "Check if it was dropped prior to featurization."
            )
        logger.warning("Missing span field. Falling back to span_preview.")
        if "span_preview" in df.columns:
            span_field = "span_preview"
        else:
            raise ValueError(
                "To use context lengths, your dataframe must have either the "
                "`span_field` present (don't drop it from the df), or "
                "`span_preview` present (add it with the SpanPreviewPreprocessor)."
            )

    if span_field == SpanCols.SPAN_PREVIEW:
        if SpanCols.SPAN_PREVIEW_OFFSET not in df.columns:
            raise ValueError(
                f"Dataframe must have {SpanCols.SPAN_PREVIEW_OFFSET} column to use "
                f"the {SpanCols.SPAN_PREVIEW} field."
            )

    return span_field


def _get_left_context(
    row: Any, left_context_len: int, use_span_preview_offset: bool
) -> str:
    offset = row[SpanCols.SPAN_PREVIEW_OFFSET] if use_span_preview_offset else 0
    start_idx = max(0, row[SpanCols.CHAR_START] - offset - left_context_len)
    end_idx = row[SpanCols.CHAR_START] - offset
    return row[EXTRACTION_CONTEXT_FIELD][start_idx:end_idx]


def _get_right_context(
    row: Any, right_context_len: int, use_span_preview_offset: bool
) -> str:
    offset = row[SpanCols.SPAN_PREVIEW_OFFSET] if use_span_preview_offset else 0
    start_idx = row[SpanCols.CHAR_END] + 1 - offset
    end_idx = row[SpanCols.CHAR_END] + right_context_len + 1 - offset
    return row[EXTRACTION_CONTEXT_FIELD][start_idx:end_idx]


class ContextFeatures(NamedTuple):
    full: pd.Series
    left: pd.Series
    right: pd.Series


def extract_context_features(
    df: pd.DataFrame,
    extraction_data: pd.Series,
    left_context_len: int,
    right_context_len: int,
    use_span_preview_offset: bool,
    mask_span: Optional[bool] = False,
) -> ContextFeatures:
    # Copy relevant fields for computing contexts plus `extraction_data` into a small
    # DataFrame to use DataFrame.apply without mutating the input
    extraction_meta_fields = [
        SpanCols.CHAR_START,
        SpanCols.CHAR_END,
        SpanCols.SPAN_TEXT,
    ]
    if use_span_preview_offset:
        extraction_meta_fields.append(SpanCols.SPAN_PREVIEW_OFFSET)
    extraction_df = df[extraction_meta_fields].copy()
    extraction_df[EXTRACTION_CONTEXT_FIELD] = extraction_data

    # Pull out left and right contexts
    assert left_context_len > 0
    left_context = extraction_df.apply(
        partial(
            _get_left_context,
            left_context_len=left_context_len,
            use_span_preview_offset=use_span_preview_offset,
        ),
        axis=1,
    )

    assert right_context_len > 0
    right_context = extraction_df.apply(
        partial(
            _get_right_context,
            right_context_len=right_context_len,
            use_span_preview_offset=use_span_preview_offset,
        ),
        axis=1,
    )

    # Add spaces to prevent merging span with first / last word from right / left
    # context.
    if mask_span:
        full_context = left_context + SPAN_TOKEN + right_context
    else:
        full_context = left_context + " " + df[SpanCols.SPAN_TEXT] + " " + right_context
    return ContextFeatures(full=full_context, left=left_context, right=right_context)


def get_extraction_features(
    df: pd.DataFrame,
    left_context_len: int,
    right_context_len: int,
    mask_span: bool = False,
    use_span_field: bool = False,
) -> ContextFeatures:
    """Return the left, right, and full contexts for each example.

    If use_span_field is True, the span_field column must be used to get context
    (as opposed to span_preview, for example).
    """
    span_field = get_span_field(df, use_span_field)
    use_span_preview_offset = span_field == SpanCols.SPAN_PREVIEW

    extraction_data = df[span_field].fillna("")
    if len(extraction_data) == 0:
        raise ValueError(f"{span_field} column is empty.")

    logger.info("Extracting textual (context) features.")
    return extract_context_features(
        df=df,
        extraction_data=extraction_data,
        left_context_len=left_context_len,
        right_context_len=right_context_len,
        use_span_preview_offset=use_span_preview_offset,
        mask_span=mask_span,
    )


def merge_columns(
    df: pd.DataFrame, fields: List[str], sep_token: str = " "
) -> pd.Series:
    """Convert all fields to str and add them together, separated `sep_token`.
    TODO: Use a special token instead of a space character to separate between columns.
    See: https://huggingface.co/transformers/main_classes/tokenizer.html#transformers.PreTrainedTokenizer.add_special_tokens
    """
    if len(fields) < 1:
        raise ValueError("The list of fields can't be empty.")
    return df[fields].astype(str).agg((sep_token).join, axis=1)


class ExtractionOptions(NamedTuple):
    left_context_len: int
    right_context_len: int
    mask_span: bool


def get_sequence_model_features(
    df: pd.DataFrame, fields: List[str], extraction_options: Optional[ExtractionOptions]
) -> pd.Series:
    fields = fields.copy()
    extraction_feature = None
    text_feature = None
    if extraction_options:
        extraction_feature = get_extraction_features(
            df=df,
            left_context_len=extraction_options.left_context_len,
            right_context_len=extraction_options.right_context_len,
            mask_span=extraction_options.mask_span,
        ).full
        if SpanCols.SPAN_PREVIEW in fields:
            fields.remove(SpanCols.SPAN_PREVIEW)
    if fields:
        text_feature = merge_columns(df, fields)
    # Space-separate if both feature types available
    if extraction_feature is not None and text_feature is not None:
        return extraction_feature + " " + text_feature
    # Otherwise return the one we have
    return extraction_feature if extraction_feature is not None else text_feature


def get_decision_threshold(
    model_training_config: ModelTrainingConfig,
) -> Optional[float]:
    options = model_training_config.options
    decision_threshold = options.get(MODEL_CONFIG_OPTION_DECISION_THRESHOLD)
    if decision_threshold is not None and options[MODEL_CONFIG_OPTION_N_CLASSES] != 2:
        raise ValueError(
            f"{MODEL_CONFIG_OPTION_DECISION_THRESHOLD} option "
            "can only be set for binary models."
        )
    return decision_threshold


class MockStatusHandler:
    def __init__(self) -> None:
        self.statuses: List = []

    def update_status(self, message: str, percent: int) -> None:
        self.statuses.append([message, percent])

    def update_step_status(self, step_number: int, total_steps: int) -> None:
        message = f"Step {step_number} of {total_steps}"
        percent = 0 if total_steps == 0 else int(100 * step_number / total_steps)
        self.update_status(message=message, percent=percent)

    def start_end_model_training(self) -> None:
        pass


def is_text_series(x: pd.Series) -> bool:
    return x[~x.isna()].apply(type).eq(str).all()


def is_num_series(x: pd.Series) -> bool:
    return is_numeric_dtype(x)  # This includes boolean as well


def is_num_list_series(x: pd.Series) -> bool:
    if len(x) == 0 or not isinstance(x.iloc[0], list):
        return False
    first_non_empty = next((item for item in x if len(item) > 0), None)
    if first_non_empty is None:
        return False
    return isinstance(first_non_empty[0], float) or isinstance(first_non_empty[0], int)


def get_truncated_input_for_sequence_model(
    df: pd.DataFrame,
    trained_model: Any,  # keeping this type hint as Any to prevent circular imports
) -> List[str]:
    """BERT models typically support 512 tokens per datapoint. This method takes a dataframe of raw values as input
    and gives out a list of truncated text based datapoints as output to be fed into the given BERT model.
    Multi-field input df is supported.
    Although model.tokenizer should support truncation, transformers.pipeline for text classification doesn't support
    all tokenizer parameters yet.

    Args:
        df (pd.DataFrame): Input dataframe for which all datapoints need to be truncated
        trained_model (Any): Bert model for which df is to be provided as input

    Returns:
        List[str]: List of datapoints with truncated text.
    """
    input_data = get_sequence_model_features(
        df, trained_model.fields, trained_model.extraction_options
    ).tolist()
    max_tokens = 512
    num_token_decrement = 64
    for i in range(len(input_data)):
        curr_len = max_tokens
        while len(trained_model.tokenizer.encode(input_data[i])) > max_tokens:
            # truncate words from the end
            words = input_data[i].split(" ")
            input_data[i] = " ".join(words[:curr_len])
            curr_len -= num_token_decrement
    return input_data


def preprocess_document_df(df: pd.DataFrame, field: str) -> pd.DataFrame:
    # Convert all non string type rows in field column to empty string
    # Used in sequence tagging models as we do not type check the field
    df[field] = df[field].apply(lambda x: "" if type(x) is not str else x)
    return df
