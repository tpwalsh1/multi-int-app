import json
import os
import pathlib
from typing import Any, Dict, List, Optional, Union

from api_utils.exceptions import UnsupportedModelError
from file_utils.core import open_file
from snorkelflow.models.cls_model import (
    ClassificationModelV2,
    TrainedClassificationModelV2,
    models_dict,
    trained_models_dict,
)
from snorkelflow.models.model_configs import ModelTrainingConfig
from snorkelflow.serialization.code_asset import deserialize_asset
from snorkelflow.utils.file import get_path_storage_options, resolve_data_path
from snorkelflow.utils.logging import get_logger

logger = get_logger("Models")


# NOTE: Only register models when their imports are available.
try:
    from snorkelflow.models.custom import CustomClassificationModelV2  # noqa
except ImportError:
    logger.debug("Import failed for CustomClassification model. Skipping registration.")
    pass

try:
    from snorkelflow.models.sklearn import MultiLabelSklearnModel  # noqa
    from snorkelflow.models.sklearn import SklearnModel  # noqa
    from snorkelflow.models.sklearn import TrainedSklearnModel  # noqa; noqa
except ImportError:
    logger.debug(
        "Import failed for SKLearn classification model. Skipping registration."
    )
    pass

try:
    from snorkelflow.models.transformers import (  # noqa; noqa; noqa
        DocLayoutLMClassificationModel,
        MultiLabelTransformerClassificationModel,
        SpanLayoutLMClassificationModel,
        TransformerClassificationModel,
    )
except ImportError:
    logger.debug(
        "Import failed for Transformer classification model. Skipping registration."
    )
    pass

try:
    from snorkelflow.models.sequence_tagging import SequenceTaggingModel  # noqa
except ImportError:
    logger.debug("Import failed for SequenceTaggingModel. Skipping registration.")
    pass

try:
    from snorkelflow.models.crf import CRFModel  # noqa

# TODO (ENG-9982) - when this bug is fixed, change this back to ImportError from Exception
except Exception:
    logger.debug("Import failed for CRFModel. Skipping registration.")
    pass

try:
    from snorkelflow.models.label_model import TrainedLabelModel  # noqa
except ImportError:
    logger.debug("Import failed for TrainedLabelModel. Skipping registration.")
    pass

try:
    from snorkelflow.models.gpt3_openai import GPT3Model  # noqa
except ImportError:
    logger.debug("Import failed for GPT3Model. Skipping registration.")
    pass

try:
    from snorkelflow.models.form_recognizer_model import FormRecognizerModel  # noqa
except ImportError:
    logger.debug("Import failed for FormRecognizerModel. Skipping registration.")
    pass


def _load_manifest(
    dirpath: Union[pathlib.Path, str], storage_options: Dict[str, Any]
) -> Dict[str, Any]:
    manifest_path = os.path.join(dirpath, "manifest.json")
    with open_file(manifest_path, **storage_options) as f:
        m = json.load(f)
    return m


# NOTE: Be very careful when changing existing model class types, so as not to
# break backwards compatibility
def load_model(
    dirpath: Union[pathlib.Path, str], model_class_pickle: Optional[str] = None
) -> TrainedClassificationModelV2:
    dirpath_resolved = resolve_data_path(str(dirpath))
    dirpath_resolved, storage_options = get_path_storage_options(dirpath_resolved)
    if not model_class_pickle:
        m = _load_manifest(dirpath_resolved, storage_options)
        TrainedModelType = trained_models_dict.get(m["type"])
        # Backwards compatibility: "SklearnModel" was the type name before "TrainedSklearnModel"
        if TrainedModelType is None:
            if m["type"] == "SklearnModel":
                TrainedModelType = TrainedSklearnModel
            else:
                raise ValueError(f"Unrecognized model name {m['type']}")
        logger.info(f"Loading {m['type']} model")
    else:
        # TODO: need to add check here m["type"] might not exist in trained_models_dict
        #   Instead, if asset is passed as a parameter use that instead.
        TrainedModelType = deserialize_asset(model_class_pickle)
    assert TrainedModelType is not None
    model = TrainedModelType.load(dirpath_resolved, storage_options=storage_options)
    logger.info(f"Loaded {TrainedModelType.__name__} model")
    return model


def load_model_fields(dirpath: Union[pathlib.Path, str]) -> List[str]:
    dirpath = resolve_data_path(str(dirpath))
    assert isinstance(dirpath, str)  # mypy
    dirpath, storage_options = get_path_storage_options(dirpath)
    m = _load_manifest(dirpath, storage_options)
    return m["model_fields"]


def get_model_cls_from_config(model_config: ModelTrainingConfig) -> Any:
    if model_config.model_cls not in models_dict:
        err_msg = f"Training/inference is not supported for the model class {model_config.model_cls}"
        raise UnsupportedModelError(
            detail=err_msg,
            user_friendly_message=err_msg,
            how_to_fix="You can train a custom model via the notebook",
        )
    return models_dict[model_config.model_cls]


def get_model_from_config(model_config: ModelTrainingConfig) -> ClassificationModelV2:
    return models_dict[model_config.model_cls](model_config)
