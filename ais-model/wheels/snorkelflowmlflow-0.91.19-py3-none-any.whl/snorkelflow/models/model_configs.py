import os
import random
from copy import deepcopy
from typing import Any, Dict, List, Optional

import yaml
from pydantic import BaseModel, Extra

from api_utils.config import get_env_var
from snorkelflow.config.constants import (
    BASE_PRETRAINED_MODEL_CACHE_DIR,
    SHARED_PRETRAINED_MODEL_CACHE_DIR,
)
from snorkelflow.extraction.span import SpanCols
from snorkelflow.rich_docs import BBOX_COLS, RichDocCols
from snorkelflow.types.model import AggregationType
from snorkelflow.types.tasks import TaskTypes
from snorkelflow.utils.logging import get_logger

logger = get_logger("Model Configs")


class HFCacheSettings:
    if get_env_var("ENABLE_PRETRAINED_MODEL_DIRECTORY") == "True":
        PRETRAINED_CACHE_DIR = (
            f"{SHARED_PRETRAINED_MODEL_CACHE_DIR}/.transformer-models"
        )
    else:
        PRETRAINED_CACHE_DIR = f"{BASE_PRETRAINED_MODEL_CACHE_DIR}/.transformer-models"
    TRANSFORMER_MODEL_REVISION_FILE = os.path.join(
        os.path.dirname(__file__), "transformers_revisions.yaml"
    )
    with open(TRANSFORMER_MODEL_REVISION_FILE) as f:
        REVISIONS = yaml.safe_load(f)

    @classmethod
    def default_model_checkpoint_dir(cls) -> str:
        """Generates an output directory for storing model checkpoints"""
        return cls.PRETRAINED_CACHE_DIR + "/" + str(random.getrandbits(128))


class ModelTrainingConfig(BaseModel):
    # The model class name to instantiate
    model_cls: str
    # Options for configuring the model
    options: Dict[str, Any]
    # param to select large engine queue for training
    is_large: Optional[bool] = False

    # Explicitly setting extra field handling to ignore as many
    # DB entries have "config_name"
    class Config:
        extra = Extra.ignore


class ModelConfig(ModelTrainingConfig):
    # The user-facing name for this model config
    config_name: str


SKLEARN_LOGISTIC_REGRESSION_CLASSIFIER_KWARGS = {
    "C": 10,
    "penalty": "l2",
    "solver": "liblinear",
    "random_state": 123,
}


SKLEARN_LOGISTIC_REGRESSION_CONFIG = ModelConfig(
    config_name="Logistic Regression",
    model_cls="SklearnModel",
    options={
        "classifier": {
            "classifier_cls": "LogisticRegression",
            "classifier_kwargs": SKLEARN_LOGISTIC_REGRESSION_CLASSIFIER_KWARGS,
        },
        "text_vectorizer": {
            "vectorizer_cls": "CountVectorizer",
            "vectorizer_kwargs": {
                "ngram_range": (1, 2),
                "max_features": 250000,
                "lowercase": False,
            },
        },
    },
)


SKLEARN_AUTOMATIC_LOGISTIC_REGRESSION_CONFIG = ModelConfig(
    config_name="Logistic Regression Automatic",
    model_cls="SklearnModel",
    options={
        "classifier": {
            "classifier_cls": "LogisticRegression",
            "classifier_kwargs": {
                "C": 10,
                "penalty": "l2",
                "solver": "liblinear",
                "max_iter": 10000,
                "warm_start": True,
                "random_state": 123,
            },
        },
        "text_vectorizer": {
            "vectorizer_cls": "CountVectorizer",
            "vectorizer_kwargs": {
                "ngram_range": (1, 2),
                "max_features": 250000,
                "lowercase": False,
            },
        },
    },
)


SKLEARN_LOGISTIC_REGRESSION_MULTI_LABEL_CONFIG = ModelConfig(
    config_name="Logistic Regression",
    model_cls="MultiLabelSklearnModel",
    options={
        "classifier": {
            "classifier_cls": "LogisticRegression",
            "classifier_kwargs": SKLEARN_LOGISTIC_REGRESSION_CLASSIFIER_KWARGS,
        },
        "text_vectorizer": {
            "vectorizer_cls": "CountVectorizer",
            "vectorizer_kwargs": {
                "ngram_range": (1, 2),
                "max_features": 250000,
                "lowercase": False,
            },
        },
        "n_jobs": 1,
    },
)


SKLEARN_LOGISTIC_REGRESSION_WITH_PREPROCESSOR_CONFIG = ModelConfig(
    config_name="Logistic Regression (MaxAbsScaler)",
    model_cls="SklearnModel",
    options={
        "classifier": {
            "classifier_cls": "LogisticRegression",
            "classifier_kwargs": SKLEARN_LOGISTIC_REGRESSION_CLASSIFIER_KWARGS,
        },
        "text_vectorizer": {
            "vectorizer_cls": "CountVectorizer",
            "vectorizer_kwargs": {
                "ngram_range": (1, 2),
                "max_features": 250000,
                "lowercase": False,
            },
        },
        "sklearn_preprocessor": {
            "sklearn_preprocessor_cls": "MaxAbsScaler",
            "sklearn_preprocessor_kwargs": {"copy": True},
        },
    },
)


SKLEARN_LOGISTIC_REGRESSION_WITH_PREPROCESSOR_MULTI_LABEL_CONFIG = ModelConfig(
    config_name="Logistic Regression (MaxAbsScaler)",
    model_cls="MultiLabelSklearnModel",
    options={
        "classifier": {
            "classifier_cls": "LogisticRegression",
            "classifier_kwargs": SKLEARN_LOGISTIC_REGRESSION_CLASSIFIER_KWARGS,
        },
        "text_vectorizer": {
            "vectorizer_cls": "CountVectorizer",
            "vectorizer_kwargs": {
                "ngram_range": (1, 2),
                "max_features": 250000,
                "lowercase": False,
            },
        },
        "sklearn_preprocessor": {
            "sklearn_preprocessor_cls": "MaxAbsScaler",
            "sklearn_preprocessor_kwargs": {"copy": True},
        },
        "n_jobs": 1,
    },
)


SKLEARN_LOGISTIC_REGRESSION_HASHING_VECTORIZER_CONFIG = ModelConfig(
    config_name="Logistic Regression (Memory Optimized)",
    model_cls="SklearnModel",
    options={
        "classifier": {
            "classifier_cls": "LogisticRegression",
            "classifier_kwargs": SKLEARN_LOGISTIC_REGRESSION_CLASSIFIER_KWARGS,
        },
        "text_vectorizer": {
            "vectorizer_cls": "HashingVectorizer",
            "vectorizer_kwargs": {
                "ngram_range": (1, 2),
                "n_features": 250000,
                "lowercase": False,
            },
        },
    },
)


SKLEARN_LOGISTIC_REGRESSION_HASHING_VECTORIZER_MULTI_LABEL_CONFIG = ModelConfig(
    config_name="Logistic Regression (Memory Optimized)",
    model_cls="MultiLabelSklearnModel",
    options={
        "classifier": {
            "classifier_cls": "LogisticRegression",
            "classifier_kwargs": SKLEARN_LOGISTIC_REGRESSION_CLASSIFIER_KWARGS,
        },
        "text_vectorizer": {
            "vectorizer_cls": "HashingVectorizer",
            "vectorizer_kwargs": {
                "ngram_range": (1, 2),
                "n_features": 250000,
                "lowercase": False,
            },
        },
        "n_jobs": 1,
    },
)

AZURE_FORM_RECOGNIZER_CONFIG = ModelConfig(
    config_name="Azure Form Recognizer",
    model_cls="FormRecognizerModel",
    options={
        "model_id": "my-model-id",
        "azure_blob_storage_connection_string": "blob_storage_key",
        "azure_blob_storage_container": "my-container",
        "blob_prefix": None,
        "endpoint": "https://test.cognitiveservices.azure.com/",
        "form_recognizer_key": "azure_fr_key",
        "default_fields": BBOX_COLS
        + [
            SpanCols.SPAN_TEXT,
            SpanCols.CHAR_START,
            SpanCols.CHAR_END,
            RichDocCols.DOC_COL,
            RichDocCols.PDF_URL_COL,
        ],
    },
)


SKLEARN_LOGISTIC_REGRESSION_TFIDF_VECTORIZER_CONFIG = ModelConfig(
    config_name="Logistic Regression (TFIDF)",
    model_cls="SklearnModel",
    options={
        "classifier": {
            "classifier_cls": "LogisticRegression",
            "classifier_kwargs": SKLEARN_LOGISTIC_REGRESSION_CLASSIFIER_KWARGS,
        },
        "text_vectorizer": {
            "vectorizer_cls": "TfidfVectorizer",
            "vectorizer_kwargs": {
                "ngram_range": (1, 2),
                "max_features": 250000,
                "lowercase": False,
            },
        },
    },
)


SKLEARN_LOGISTIC_REGRESSION_TFIDF_VECTORIZER_MULTI_LABEL_CONFIG = ModelConfig(
    config_name="Logistic Regression (TFIDF)",
    model_cls="MultiLabelSklearnModel",
    options={
        "classifier": {
            "classifier_cls": "LogisticRegression",
            "classifier_kwargs": SKLEARN_LOGISTIC_REGRESSION_CLASSIFIER_KWARGS,
        },
        "text_vectorizer": {
            "vectorizer_cls": "TfidfVectorizer",
            "vectorizer_kwargs": {
                "ngram_range": (1, 2),
                "max_features": 250000,
                "lowercase": False,
            },
        },
        "n_jobs": 1,
    },
)


SKLEARN_LOGISTIC_REGRESSION_EXTRACTION_CONFIG = ModelConfig(
    config_name="Logistic Regression (Span Aware)",
    model_cls="SklearnModel",
    options={
        "classifier": {
            "classifier_cls": "LogisticRegression",
            "classifier_kwargs": SKLEARN_LOGISTIC_REGRESSION_CLASSIFIER_KWARGS,
        },
        "text_vectorizer": {
            "vectorizer_cls": "CountVectorizer",
            "vectorizer_kwargs": {
                "ngram_range": (1, 2),
                "max_features": 250000,
                "lowercase": False,
            },
        },
        "extraction_options": {
            "left_context_len": 200,
            "right_context_len": 200,
            "mask_span": False,
        },
    },
)


SKLEARN_LOGISTIC_REGRESSION_EXTRACTION_MULTI_LABEL_CONFIG = ModelConfig(
    config_name="Logistic Regression (Span Aware)",
    model_cls="MultiLabelSklearnModel",
    options={
        "classifier": {
            "classifier_cls": "LogisticRegression",
            "classifier_kwargs": SKLEARN_LOGISTIC_REGRESSION_CLASSIFIER_KWARGS,
        },
        "text_vectorizer": {
            "vectorizer_cls": "CountVectorizer",
            "vectorizer_kwargs": {
                "ngram_range": (1, 2),
                "max_features": 250000,
                "lowercase": False,
            },
        },
        "extraction_options": {
            "left_context_len": 200,
            "right_context_len": 200,
            "mask_span": False,
        },
    },
)


SKLEARN_XGBOOST_CLASSIFIER_KWARGS = {
    "n_estimators": 100,
    "max_depth": None,
    "random_state": 123,
}


SKLEARN_XGBOOST_CONFIG = ModelConfig(
    config_name="XGBoost",
    model_cls="SklearnModel",
    options={
        "classifier": {
            "classifier_cls": "XGBoostClassifier",
            "classifier_kwargs": SKLEARN_XGBOOST_CLASSIFIER_KWARGS,
        },
        "text_vectorizer": {
            "vectorizer_cls": "CountVectorizer",
            "vectorizer_kwargs": {
                "ngram_range": (1, 2),
                "max_features": 250000,
                "lowercase": False,
            },
        },
    },
)


SKLEARN_XGBOOST_MULTI_LABEL_CONFIG = ModelConfig(
    config_name="XGBoost",
    model_cls="MultiLabelSklearnModel",
    options={
        "classifier": {
            "classifier_cls": "XGBoostClassifier",
            "classifier_kwargs": SKLEARN_XGBOOST_CLASSIFIER_KWARGS,
        },
        "text_vectorizer": {
            "vectorizer_cls": "CountVectorizer",
            "vectorizer_kwargs": {
                "ngram_range": (1, 2),
                "max_features": 250000,
                "lowercase": False,
            },
        },
    },
)


SKLEARN_XGBOOST_HASHING_VECTORIZER_CONFIG = ModelConfig(
    config_name="XGBoost (Memory Optimized)",
    model_cls="SklearnModel",
    options={
        "classifier": {
            "classifier_cls": "XGBoostClassifier",
            "classifier_kwargs": SKLEARN_XGBOOST_CLASSIFIER_KWARGS,
        },
        "text_vectorizer": {
            "vectorizer_cls": "HashingVectorizer",
            "vectorizer_kwargs": {
                "ngram_range": (1, 2),
                "n_features": 250000,
                "lowercase": False,
            },
        },
    },
)


SKLEARN_XGBOOST_HASHING_VECTORIZER_MULTI_LABEL_CONFIG = ModelConfig(
    config_name="XGBoost (Memory Optimized)",
    model_cls="MultiLabelSklearnModel",
    options={
        "classifier": {
            "classifier_cls": "XGBoostClassifier",
            "classifier_kwargs": SKLEARN_XGBOOST_CLASSIFIER_KWARGS,
        },
        "text_vectorizer": {
            "vectorizer_cls": "HashingVectorizer",
            "vectorizer_kwargs": {
                "ngram_range": (1, 2),
                "n_features": 250000,
                "lowercase": False,
            },
        },
    },
)


SKLEARN_XGBOOST_TFIDF_VECTORIZER_CONFIG = ModelConfig(
    config_name="XGBoost (TFIDF)",
    model_cls="SklearnModel",
    options={
        "classifier": {
            "classifier_cls": "XGBoostClassifier",
            "classifier_kwargs": SKLEARN_XGBOOST_CLASSIFIER_KWARGS,
        },
        "text_vectorizer": {
            "vectorizer_cls": "TfidfVectorizer",
            "vectorizer_kwargs": {
                "ngram_range": (1, 2),
                "max_features": 250000,
                "lowercase": False,
            },
        },
    },
)


SKLEARN_XGBOOST_TFIDF_VECTORIZER_MULTI_LABEL_CONFIG = ModelConfig(
    config_name="XGBoost (TFIDF)",
    model_cls="MultiLabelSklearnModel",
    options={
        "classifier": {
            "classifier_cls": "XGBoostClassifier",
            "classifier_kwargs": SKLEARN_XGBOOST_CLASSIFIER_KWARGS,
        },
        "text_vectorizer": {
            "vectorizer_cls": "TfidfVectorizer",
            "vectorizer_kwargs": {
                "ngram_range": (1, 2),
                "max_features": 250000,
                "lowercase": False,
            },
        },
    },
)


SKLEARN_XGBOOST_EXTRACTION_CONFIG = ModelConfig(
    config_name="XGBoost (Span Aware)",
    model_cls="SklearnModel",
    options={
        "classifier": {
            "classifier_cls": "XGBoostClassifier",
            "classifier_kwargs": SKLEARN_XGBOOST_CLASSIFIER_KWARGS,
        },
        "text_vectorizer": {
            "vectorizer_cls": "CountVectorizer",
            "vectorizer_kwargs": {
                "ngram_range": (1, 2),
                "max_features": 250000,
                "lowercase": False,
            },
        },
        "extraction_options": {
            "left_context_len": 200,
            "right_context_len": 200,
            "mask_span": False,
        },
    },
)

# region KNN Configs

SKLEARN_KNN_CLASSIFIER_KWARGS = {
    "n_neighbors": 5,
    "weights": "uniform",
    "algorithm": "auto",
    "p": 2,
}

SKLEARN_KNN_CONFIG = ModelConfig(
    config_name="K-Nearest Neighbors",
    model_cls="SklearnModel",
    options={
        "classifier": {
            "classifier_cls": "KNeighborsClassifier",
            "classifier_kwargs": SKLEARN_KNN_CLASSIFIER_KWARGS,
        },
        "text_vectorizer": {
            "vectorizer_cls": "CountVectorizer",
            "vectorizer_kwargs": {
                "ngram_range": (1, 2),
                "max_features": 250000,
                "lowercase": False,
            },
        },
    },
)


SKLEARN_KNN_MULTI_LABEL_CONFIG = ModelConfig(
    config_name="K-Nearest Neighbors",
    model_cls="MultiLabelSklearnModel",
    options={
        "classifier": {
            "classifier_cls": "KNeighborsClassifier",
            "classifier_kwargs": SKLEARN_KNN_CLASSIFIER_KWARGS,
        },
        "text_vectorizer": {
            "vectorizer_cls": "CountVectorizer",
            "vectorizer_kwargs": {
                "ngram_range": (1, 2),
                "max_features": 250000,
                "lowercase": False,
            },
        },
    },
)


SKLEARN_KNN_WITH_PREPROCESSOR_CONFIG = ModelConfig(
    config_name="K-Nearest Neighbors (MaxAbsScaler)",
    model_cls="SklearnModel",
    options={
        "classifier": {
            "classifier_cls": "KNeighborsClassifier",
            "classifier_kwargs": SKLEARN_KNN_CLASSIFIER_KWARGS,
        },
        "text_vectorizer": {
            "vectorizer_cls": "CountVectorizer",
            "vectorizer_kwargs": {
                "ngram_range": (1, 2),
                "max_features": 250000,
                "lowercase": False,
            },
        },
        "sklearn_preprocessor": {
            "sklearn_preprocessor_cls": "MaxAbsScaler",
            "sklearn_preprocessor_kwargs": {"copy": True},
        },
    },
)


SKLEARN_KNN_WITH_PREPROCESSOR_MULTI_LABEL_CONFIG = ModelConfig(
    config_name="K-Nearest Neighbors (MaxAbsScaler)",
    model_cls="MultiLabelSklearnModel",
    options={
        "classifier": {
            "classifier_cls": "KNeighborsClassifier",
            "classifier_kwargs": SKLEARN_KNN_CLASSIFIER_KWARGS,
        },
        "text_vectorizer": {
            "vectorizer_cls": "CountVectorizer",
            "vectorizer_kwargs": {
                "ngram_range": (1, 2),
                "max_features": 250000,
                "lowercase": False,
            },
        },
        "sklearn_preprocessor": {
            "sklearn_preprocessor_cls": "MaxAbsScaler",
            "sklearn_preprocessor_kwargs": {"copy": True},
        },
    },
)

# endregion
# The config's params are unique to our wrapper class for this SKLearn model
# If using directly with SKLearn, you need to remove "outlier_class"
SKLEARN_ONE_CLASS_SVM_CLASSIFIER_WRAPPER_KWARGS = {
    "kernel": "rbf",
    "gamma": "auto",
    "nu": 0.001,
    "outlier_class": 1,
}

SKLEARN_ONE_CLASS_SVM_CONFIG = ModelConfig(
    config_name="One Class SVM",
    model_cls="SklearnModel",
    options={
        "classifier": {
            "classifier_cls": "OneClassSVMClassifier",
            "classifier_kwargs": SKLEARN_ONE_CLASS_SVM_CLASSIFIER_WRAPPER_KWARGS,
        }
    },
)


DISTILBERT_FREEZE_EMBEDDINGS_CONFIG = ModelConfig(
    config_name="DistilBERT (Finetune Classifier)",
    model_cls="TransformerClassificationModel",
    is_large=True,
    options={
        "pretrained_model_name": "distilbert-base-uncased",
        "revision": HFCacheSettings.REVISIONS["distilbert-base-uncased"],
        "tokenizer_kwargs": {"do_lower_case": True},
        "learning_rate": 5e-5,
        "weight_decay": 0.0,
        "freeze_bert_embeddings": True,
        "max_sequence_length": 32,
        "num_train_epochs": 1,
        "train_batch_size": 64,
        "max_grad_norm": 1.0,
        "gradient_accumulation_steps": 1,
        "lr_warmup_steps": 0,
        "predict_batch_size": 64,
        "torch_manual_seed": 123,
    },
)

DISTILBERT_CLASSIFICATION_CONFIG = ModelConfig(
    config_name="DistilBERT (Finetune All)",
    model_cls="TransformerClassificationModel",
    is_large=True,
    options={
        "pretrained_model_name": "distilbert-base-uncased",
        "revision": HFCacheSettings.REVISIONS["distilbert-base-uncased"],
        "tokenizer_kwargs": {"do_lower_case": True},
        "learning_rate": 5e-5,
        "weight_decay": 0.0,
        "freeze_bert_embeddings": False,
        "max_sequence_length": 32,
        "num_train_epochs": 1,
        "train_batch_size": 64,
        "max_grad_norm": 1.0,
        "gradient_accumulation_steps": 1,
        "lr_warmup_steps": 0,
        "predict_batch_size": 64,
        "torch_manual_seed": 123,
    },
)

DISTILBERT_EXTRACTION_CONFIG = ModelConfig(
    config_name="DistilBERT (Span Aware)",
    model_cls="TransformerClassificationModel",
    is_large=True,
    options={
        "pretrained_model_name": "distilbert-base-uncased",
        "revision": HFCacheSettings.REVISIONS["distilbert-base-uncased"],
        "tokenizer_kwargs": {"do_lower_case": True},
        "learning_rate": 5e-5,
        "weight_decay": 0.0,
        "freeze_bert_embeddings": True,
        "max_sequence_length": 32,
        "num_train_epochs": 1,
        "train_batch_size": 64,
        "max_grad_norm": 1.0,
        "gradient_accumulation_steps": 1,
        "lr_warmup_steps": 0,
        "predict_batch_size": 64,
        "extraction_options": {
            "left_context_len": 200,
            "right_context_len": 200,
            "mask_span": False,
        },
        "torch_manual_seed": 123,
    },
)

DISTILBERT_MULTI_LABEL_FREEZE_EMBEDDINGS_CONFIG = ModelConfig(
    config_name="DistilBERT (Finetune Classifier)",
    model_cls="MultiLabelTransformerClassificationModel",
    is_large=True,
    options={
        "pretrained_model_name": "distilbert-base-uncased",
        "revision": HFCacheSettings.REVISIONS["distilbert-base-uncased"],
        "tokenizer_kwargs": {"do_lower_case": True},
        "learning_rate": 5e-5,
        "weight_decay": 0.0,
        "freeze_bert_embeddings": True,
        "max_sequence_length": 32,
        "num_train_epochs": 1,
        "train_batch_size": 64,
        "max_grad_norm": 1.0,
        "gradient_accumulation_steps": 1,
        "lr_warmup_steps": 0,
        "predict_batch_size": 64,
        "torch_manual_seed": 123,
    },
)

DISTILBERT_MULTI_LABEL_CONFIG = ModelConfig(
    config_name="DistilBERT (Finetune All)",
    model_cls="MultiLabelTransformerClassificationModel",
    is_large=True,
    options={
        "pretrained_model_name": "distilbert-base-uncased",
        "revision": HFCacheSettings.REVISIONS["distilbert-base-uncased"],
        "tokenizer_kwargs": {"do_lower_case": True},
        "learning_rate": 5e-5,
        "weight_decay": 0.0,
        "freeze_bert_embeddings": False,
        "max_sequence_length": 32,
        "num_train_epochs": 1,
        "train_batch_size": 64,
        "max_grad_norm": 1.0,
        "gradient_accumulation_steps": 1,
        "lr_warmup_steps": 0,
        "predict_batch_size": 64,
        "torch_manual_seed": 123,
    },
)

BERT_CLASSIFICATION_CONFIG = ModelConfig(
    config_name="BERT",
    model_cls="TransformerClassificationModel",
    is_large=True,
    options={
        "pretrained_model_name": "bert-base-uncased",
        "revision": HFCacheSettings.REVISIONS["bert-base-uncased"],
        "tokenizer_kwargs": {"do_lower_case": True},
        "learning_rate": 5e-5,
        "weight_decay": 0.0,
        "freeze_bert_embeddings": False,
        "max_sequence_length": 32,
        "num_train_epochs": 1,
        "train_batch_size": 64,
        "max_grad_norm": 1.0,
        "gradient_accumulation_steps": 1,
        "lr_warmup_steps": 0,
        "predict_batch_size": 64,
        "torch_manual_seed": 123,
    },
)

BERT_MULTI_LABEL_CONFIG = ModelConfig(
    config_name="BERT",
    model_cls="MultiLabelTransformerClassificationModel",
    is_large=True,
    options={
        "pretrained_model_name": "bert-base-uncased",
        "revision": HFCacheSettings.REVISIONS["bert-base-uncased"],
        "tokenizer_kwargs": {"do_lower_case": True},
        "learning_rate": 5e-5,
        "weight_decay": 0.0,
        "freeze_bert_embeddings": False,
        "max_sequence_length": 32,
        "num_train_epochs": 1,
        "train_batch_size": 64,
        "max_grad_norm": 1.0,
        "gradient_accumulation_steps": 1,
        "lr_warmup_steps": 0,
        "predict_batch_size": 64,
        "torch_manual_seed": 123,
    },
)

XLNET_CLASSIFICATION_CONFIG = ModelConfig(
    config_name="XLNet",
    model_cls="TransformerClassificationModel",
    is_large=True,
    options={
        "pretrained_model_name": "xlnet-base-cased",
        "revision": HFCacheSettings.REVISIONS["xlnet-base-cased"],
        "tokenizer_kwargs": {},
        "learning_rate": 5e-5,
        "weight_decay": 0.0,
        "freeze_bert_embeddings": False,
        "max_sequence_length": 32,
        "num_train_epochs": 1,
        "train_batch_size": 64,
        "max_grad_norm": 1.0,
        "gradient_accumulation_steps": 1,
        "lr_warmup_steps": 0,
        "predict_batch_size": 64,
        "torch_manual_seed": 123,
    },
)


LAYOUTLM_CLASSIFICATION_CONFIG = ModelConfig(
    config_name="LayoutLM (Span Text)",
    model_cls="SpanLayoutLMClassificationModel",
    is_large=True,
    options={
        "pretrained_model_name": "microsoft/layoutlm-base-uncased",
        "revision": HFCacheSettings.REVISIONS["microsoft/layoutlm-base-uncased"],
        "tokenizer_kwargs": {"do_lower_case": True},
        "learning_rate": 5e-5,
        "weight_decay": 0.0,
        "freeze_bert_embeddings": False,
        "max_sequence_length": 32,
        "num_train_epochs": 1,
        "train_batch_size": 64,
        "max_grad_norm": 1.0,
        "gradient_accumulation_steps": 1,
        "lr_warmup_steps": 0,
        "predict_batch_size": 64,
        "torch_manual_seed": 123,
        "default_fields": BBOX_COLS + [RichDocCols.DOC_COL, SpanCols.SPAN_TEXT],
    },
)

LAYOUTLM_FOR_SEQUENCE_CLASSIFICATION_CONFIG = ModelConfig(
    config_name="LayoutLM (Sequence Classification)",
    model_cls="DocLayoutLMClassificationModel",
    is_large=True,
    options={
        "pretrained_model_name": "microsoft/layoutlm-base-uncased",
        "revision": HFCacheSettings.REVISIONS["microsoft/layoutlm-base-uncased"],
        "tokenizer_kwargs": {"do_lower_case": True},
        "learning_rate": 5e-5,
        "weight_decay": 0.0,
        "freeze_bert_embeddings": False,
        "max_sequence_length": 32,
        "num_train_epochs": 1,
        "train_batch_size": 64,
        "max_grad_norm": 1.0,
        "gradient_accumulation_steps": 1,
        "lr_warmup_steps": 0,
        "predict_batch_size": 64,
        "torch_manual_seed": 123,
        "page_aggregation": AggregationType.AVERAGE,
        "default_fields": [RichDocCols.PAGE_DOCS],
    },
)


AUTO_MODEL_FOR_TOKEN_CLASSIFICATION_CONFIG = ModelConfig(
    config_name="[BETA] DistilBERT (Sequence)",
    model_cls="SequenceTaggingModel",
    is_large=True,
    options={
        "pretrained_model_name": "distilbert-base-uncased",
        "revision": HFCacheSettings.REVISIONS["distilbert-base-uncased"],
        "train_batch_size": 64,
        "num_train_epochs": 3,
        "max_sequence_length": 32,
        "stride_length": 4,
        "torch_manual_seed": 123,
        "class_weights": {},
        "label_smoothing_regularization": 0.1,
        "fraction_of_negative_subsequences_to_use_for_training": 0,
    },
)

TINY_BERT_MODEL_FOR_TOKEN_CLASSIFICATION_CONFIG = ModelConfig(
    config_name="[BETA] BERT Tiny (Sequence)",
    model_cls="SequenceTaggingModel",
    is_large=True,
    options={
        "pretrained_model_name": "prajjwal1/bert-tiny",
        "revision": HFCacheSettings.REVISIONS["prajjwal1/bert-tiny"],
        "train_batch_size": 64,
        "num_train_epochs": 3,
        "max_sequence_length": 32,
        "stride_length": 4,
        "torch_manual_seed": 123,
        "class_weights": {},
        "label_smoothing_regularization": 0.1,
        "fraction_of_negative_subsequences_to_use_for_training": 0,
    },
)

AUTO_MODEL_FOR_TOKEN_CLASSIFICATION_ROBERTA_CONFIG = ModelConfig(
    config_name="[BETA] RoBerta (Sequence)",
    model_cls="SequenceTaggingModel",
    is_large=True,
    options={
        "pretrained_model_name": "roberta-base",
        "revision": HFCacheSettings.REVISIONS["roberta-base"],
        "train_batch_size": 64,
        "num_train_epochs": 3,
        "max_sequence_length": 32,
        "stride_length": 4,
        "torch_manual_seed": 123,
        "class_weights": {},
        "add_prefix_space": True,
        "label_smoothing_regularization": 0.1,
        "fraction_of_negative_subsequences_to_use_for_training": 0,
    },
)

AUTO_MODEL_FOR_TOKEN_CLASSIFICATION_DISTILBERT_MULTI_LINGUAL_CONFIG = ModelConfig(
    config_name="[BETA] DistilBERT multilingual (Sequence)",
    model_cls="SequenceTaggingModel",
    is_large=True,
    options={
        "pretrained_model_name": "distilbert-base-multilingual-cased",
        "revision": HFCacheSettings.REVISIONS["distilbert-base-multilingual-cased"],
        "train_batch_size": 64,
        "num_train_epochs": 3,
        "max_sequence_length": 32,
        "stride_length": 4,
        "torch_manual_seed": 123,
        "class_weights": {},
        "label_smoothing_regularization": 0.1,
        "fraction_of_negative_subsequences_to_use_for_training": 0,
    },
)

AUTO_MODEL_FOR_TOKEN_CLASSIFICATION_BERT_MULTI_LINGUAL_CONFIG = ModelConfig(
    config_name="[BETA] BERT multilingual (Sequence)",
    model_cls="SequenceTaggingModel",
    is_large=True,
    options={
        "pretrained_model_name": "bert-base-multilingual-cased",
        "revision": HFCacheSettings.REVISIONS["bert-base-multilingual-cased"],
        "train_batch_size": 64,
        "num_train_epochs": 3,
        "max_sequence_length": 32,
        "stride_length": 4,
        "torch_manual_seed": 123,
        "class_weights": {},
        "label_smoothing_regularization": 0.1,
        "fraction_of_negative_subsequences_to_use_for_training": 0,
    },
)

# Model mockup for classification app demo
GPT3_CLASSIFICATION_GPT_CONFIG = ModelConfig(
    config_name="GPT-3 Fine-tuning (OpenAI)",
    model_cls="GPT3Model",
    is_large=True,
    options={
        "description": "GPT-3 Fine-tuning via OpenAI",
        "model": "ada",
        "n_epochs": 4,
        "batch_size": 256,
        "learning_rate_multiplier": 0.2,
        "max_text_chars": 1000,
        "max_timeout_minutes": 30,
        "secret_store_key": "openai_api_key",
    },
)

CRF_MODEL_FOR_TOKEN_CLASSIFICATION_CONFIG = ModelConfig(
    config_name="[BETA] CRF (Sequence)",
    model_cls="CRFModel",
    is_large=True,
    options={
        "c1": 0.2,
        "c2": 0.5,
        "max_iterations": 100,
        "include_embedding": False,
        "num_neighbors": 1,
        "fraction_of_negative_tokens_to_use_for_training": 0.5,
    },
)

AUTO_ML_LOGREG_SEARCH_CONFIG = ModelConfig(
    config_name="AutoML Logistic Regression",
    model_cls="SklearnModel",
    options={
        "classifier": {
            "classifier_cls": "LogisticRegression",
            "classifier_kwargs": {
                "C": {"SEARCH": [0.01, 0.1, 1, 10, 100]},
                "penalty": "l2",
                "solver": "liblinear",
                "random_state": 123,
            },
        },
        "text_vectorizer": {
            "vectorizer_cls": "TfidfVectorizer",
            "vectorizer_kwargs": {
                "ngram_range": {"SEARCH": [[1, 2], [1, 3]]},
                "max_features": {"SEARCH": [250000, 400000]},
                "lowercase": {"SEARCH": [True, False]},
            },
        },
    },
)

FAST_AUTO_ML_LOGREG_SEARCH_CONFIG = ModelConfig(
    config_name="AutoML Logistic Regression (Fast)",
    model_cls="SklearnModel",
    options={
        "classifier": {
            "classifier_cls": "LogisticRegression",
            "classifier_kwargs": {
                "C": {"SEARCH": [0.01, 1, 100]},
                "penalty": "l2",
                "solver": "liblinear",
                "random_state": 123,
            },
        },
        "text_vectorizer": {
            "vectorizer_cls": "TfidfVectorizer",
            "vectorizer_kwargs": {
                "ngram_range": [1, 3],
                "max_features": 250000,
                "lowercase": {"SEARCH": [True, False]},
            },
        },
    },
)


AUTO_ML_LOGREG_MULTI_LABEL_CONFIG = ModelConfig(
    config_name="AutoML Logistic Regression",
    model_cls="MultiLabelSklearnModel",
    options={
        "classifier": {
            "classifier_cls": "LogisticRegression",
            "classifier_kwargs": {
                "C": {"SEARCH": [0.01, 0.1, 1, 10, 100]},
                "penalty": "l2",
                "solver": {"SEARCH": ["liblinear", "lbfgs"]},
                "random_state": 123,
            },
        },
        "text_vectorizer": {
            "vectorizer_cls": "TfidfVectorizer",
            "vectorizer_kwargs": {
                "ngram_range": [1, 2],
                "max_features": 250000,
                "lowercase": {"SEARCH": [True, False]},
            },
        },
        "n_jobs": 1,
    },
)

# TODO:(vm) at some point need to retrofit this to bayesOpt range search
# https://towardsdatascience.com/xgboost-fine-tune-and-optimize-your-model-23d996fab663
AUTO_ML_XGBOOST_SEARCH_CONFIG = ModelConfig(
    config_name="AutoML XGBoost",
    model_cls="SklearnModel",
    options={
        "classifier": {
            "classifier_cls": "XGBoostClassifier",
            "classifier_kwargs": {"n_estimators": 500, "random_state": 123},
        },
        "text_vectorizer": {
            "vectorizer_cls": "TfidfVectorizer",
            "vectorizer_kwargs": {
                "ngram_range": {"SEARCH": [[1, 2], [1, 3]]},
                "max_features": {"SEARCH": [250000, 400000]},
                "lowercase": {"SEARCH": [True, False]},
            },
        },
        "learning_rate": 0.05,
        "subsample": 0.8,
        "colsample_by_tree": {"SEARCH": [0.4, 0.5, 0.6, 0.7]},
    },
)


AUTO_ML_SEQUENCE_ROBERTA_CONFIG = ModelConfig(
    config_name="[BETA] AutoML RoBerta (Sequence)",
    model_cls="SequenceTaggingModel",
    is_large=True,
    options={
        "pretrained_model_name": "roberta-base",
        "revision": HFCacheSettings.REVISIONS["roberta-base"],
        "train_batch_size": 64,
        "num_train_epochs": {"SEARCH": [2, 3, 4]},
        "max_sequence_length": 32,
        "stride_length": 4,
        "torch_manual_seed": 123,
        "class_weights": {},
        "add_prefix_space": True,
        "label_smoothing_regularization": 0.1,
        "fraction_of_negative_subsequences_to_use_for_training": {"SEARCH": [0, 0.5]},
    },
)


AUTO_ML_SEQUENCE_CRF_CONFIG = ModelConfig(
    config_name="[BETA] AutoML CRF (Sequence)",
    model_cls="CRFModel",
    is_large=True,
    options={
        "c1": 0.1,
        "c2": 0.5,
        "max_iterations": 100,
        "include_embedding": False,
        "num_neighbors": {"SEARCH": [0, 1]},
        "fraction_of_negative_tokens_to_use_for_training": {"SEARCH": [0, 0.5]},
    },
)


AUTO_ML_SEQUENCE_TINY_BERT_CONFIG = ModelConfig(
    config_name="[BETA] AutoML BERT Tiny (Sequence)",
    model_cls="SequenceTaggingModel",
    is_large=True,
    options={
        "pretrained_model_name": "prajjwal1/bert-tiny",
        "revision": HFCacheSettings.REVISIONS["prajjwal1/bert-tiny"],
        "train_batch_size": 64,
        "num_train_epochs": {"SEARCH": [2, 3]},
        "max_sequence_length": 32,
        "stride_length": 4,
        "torch_manual_seed": 123,
        "class_weights": {},
        "label_smoothing_regularization": 0.1,
        "fraction_of_negative_subsequences_to_use_for_training": {"SEARCH": [0, 0.5]},
    },
)

AUTO_ML_XGBOOST_MULTI_LABEL_CONFIG = ModelConfig(
    config_name="XGBoost",
    model_cls="MultiLabelSklearnModel",
    options={
        "classifier": {
            "classifier_cls": "XGBoostClassifier",
            "classifier_kwargs": {"n_estimators": 500, "random_state": 123},
        },
        "text_vectorizer": {
            "vectorizer_cls": "TfidfVectorizer",
            "vectorizer_kwargs": {
                "ngram_range": {"SEARCH": [[1, 2], [1, 3]]},
                "max_features": {"SEARCH": [250000, 400000]},
                "lowercase": {"SEARCH": [True, False]},
            },
        },
        "learning_rate": 0.05,
        "subsample": 0.8,
        "colsample_by_tree": {"SEARCH": [0.4, 0.5, 0.6, 0.7]},
    },
)

# https://arxiv.org/pdf/1810.04805.pdf, Appendix A.3
AUTO_ML_DISTILBERT_CLASSIFICATION_CONFIG = ModelConfig(
    config_name="AutoML DistilBERT (Finetune All)",
    model_cls="TransformerClassificationModel",
    is_large=True,
    options={
        "pretrained_model_name": "distilbert-base-uncased",
        "revision": HFCacheSettings.REVISIONS["distilbert-base-uncased"],
        "tokenizer_kwargs": {"do_lower_case": {"SEARCH": [True, False]}},
        "learning_rate": {"SEARCH": [5e-5, 2e-5]},
        "weight_decay": 0.0,
        "freeze_bert_embeddings": False,
        "max_sequence_length": 32,
        "num_train_epochs": {"SEARCH": [1, 2, 3]},
        "train_batch_size": 32,
        "max_grad_norm": 1.0,
        "gradient_accumulation_steps": 1,
        "lr_warmup_steps": 0,
        "predict_batch_size": 64,
        "torch_manual_seed": 123,
    },
)

AUTO_ML_SEQUENCE_DISTILBERT_CONFIG = ModelConfig(
    config_name="[BETA] AutoML DistilBERT (Sequence)",
    model_cls="SequenceTaggingModel",
    is_large=True,
    options={
        "pretrained_model_name": "distilbert-base-uncased",
        "revision": HFCacheSettings.REVISIONS["distilbert-base-uncased"],
        "train_batch_size": 64,
        "num_train_epochs": {"SEARCH": [1, 2, 3]},
        "max_sequence_length": 32,
        "stride_length": 4,
        "torch_manual_seed": 123,
        "class_weights": {},
        "label_smoothing_regularization": 0.1,
        "fraction_of_negative_subsequences_to_use_for_training": {"SEARCH": [0, 1]},
    },
)

# TODO(sg): Use Enum instead of a string as the key, get enum from FE.
AUTOML_MODEL_CONFIG_MAP = {
    "Logistic Regression": AUTO_ML_LOGREG_SEARCH_CONFIG,
    "XGBoost": AUTO_ML_XGBOOST_SEARCH_CONFIG,
    "DistilBERT": AUTO_ML_DISTILBERT_CLASSIFICATION_CONFIG,
    "DistilBERT (Sequence)": AUTO_ML_SEQUENCE_DISTILBERT_CONFIG,
    "CRF (Sequence)": AUTO_ML_SEQUENCE_CRF_CONFIG,
    "RoBerta (Sequence)": AUTO_ML_SEQUENCE_ROBERTA_CONFIG,
    "Logistic Regression (Multilabel)": AUTO_ML_LOGREG_MULTI_LABEL_CONFIG,
    "XGBoost (Multilabel)": AUTO_ML_XGBOOST_MULTI_LABEL_CONFIG,
    "Fast Logistic Regression": FAST_AUTO_ML_LOGREG_SEARCH_CONFIG,
    "Tiny BERT (Sequence)": AUTO_ML_SEQUENCE_TINY_BERT_CONFIG,
}

MODEL_CONFIG_MAP = {
    "logistic_regression": [
        SKLEARN_LOGISTIC_REGRESSION_CONFIG,
        SKLEARN_LOGISTIC_REGRESSION_WITH_PREPROCESSOR_CONFIG,
        SKLEARN_LOGISTIC_REGRESSION_HASHING_VECTORIZER_CONFIG,
        SKLEARN_LOGISTIC_REGRESSION_TFIDF_VECTORIZER_CONFIG,
    ],
    "logistic_regression_multilabel": [
        SKLEARN_LOGISTIC_REGRESSION_MULTI_LABEL_CONFIG,
        SKLEARN_LOGISTIC_REGRESSION_WITH_PREPROCESSOR_MULTI_LABEL_CONFIG,
        SKLEARN_LOGISTIC_REGRESSION_HASHING_VECTORIZER_MULTI_LABEL_CONFIG,
        SKLEARN_LOGISTIC_REGRESSION_TFIDF_VECTORIZER_MULTI_LABEL_CONFIG,
    ],
    "logistic_regression_extraction": [SKLEARN_LOGISTIC_REGRESSION_EXTRACTION_CONFIG],
    "bert_logistic_regression": [
        DISTILBERT_FREEZE_EMBEDDINGS_CONFIG,
        DISTILBERT_CLASSIFICATION_CONFIG,
        BERT_CLASSIFICATION_CONFIG,
        GPT3_CLASSIFICATION_GPT_CONFIG,
    ],
    "bert_multilabel": [
        DISTILBERT_MULTI_LABEL_CONFIG,
        DISTILBERT_MULTI_LABEL_FREEZE_EMBEDDINGS_CONFIG,
        BERT_MULTI_LABEL_CONFIG,
    ],
    "bert": [
        DISTILBERT_FREEZE_EMBEDDINGS_CONFIG,
        DISTILBERT_EXTRACTION_CONFIG,
        DISTILBERT_CLASSIFICATION_CONFIG,
        GPT3_CLASSIFICATION_GPT_CONFIG,
    ],
    "bert_extraction": [DISTILBERT_EXTRACTION_CONFIG],
    "bert_sequence": [
        AUTO_MODEL_FOR_TOKEN_CLASSIFICATION_CONFIG,
        AUTO_MODEL_FOR_TOKEN_CLASSIFICATION_ROBERTA_CONFIG,
        CRF_MODEL_FOR_TOKEN_CLASSIFICATION_CONFIG,
        TINY_BERT_MODEL_FOR_TOKEN_CLASSIFICATION_CONFIG,
    ],
    "xgboost": [
        SKLEARN_XGBOOST_CONFIG,
        SKLEARN_XGBOOST_HASHING_VECTORIZER_CONFIG,
        SKLEARN_XGBOOST_TFIDF_VECTORIZER_CONFIG,
    ],
    "xgboost_multilabel": [
        SKLEARN_XGBOOST_MULTI_LABEL_CONFIG,
        SKLEARN_XGBOOST_HASHING_VECTORIZER_MULTI_LABEL_CONFIG,
        SKLEARN_XGBOOST_TFIDF_VECTORIZER_MULTI_LABEL_CONFIG,
    ],
    "xgboost_extraction": [SKLEARN_XGBOOST_EXTRACTION_CONFIG],
    "knn": [SKLEARN_KNN_CONFIG, SKLEARN_KNN_WITH_PREPROCESSOR_CONFIG],
    "knn_multilabel": [
        SKLEARN_KNN_MULTI_LABEL_CONFIG,
        SKLEARN_KNN_WITH_PREPROCESSOR_MULTI_LABEL_CONFIG,
    ],
    "layoutlm_span": [LAYOUTLM_CLASSIFICATION_CONFIG],
    "layoutlm_sequence": [LAYOUTLM_FOR_SEQUENCE_CLASSIFICATION_CONFIG],
    "one_class_svm": [SKLEARN_ONE_CLASS_SVM_CONFIG],
    "azure_form_recognizer": [AZURE_FORM_RECOGNIZER_CONFIG],
}


def get_model_configs_from_settings(settings_models: List[str]) -> List[ModelConfig]:
    model_configs: List[ModelConfig] = []
    for model in settings_models:
        if model in MODEL_CONFIG_MAP:
            for config in MODEL_CONFIG_MAP[model]:
                model_configs.append(config)
        else:
            raise ValueError(f"{model} is not a valid model type")
    return model_configs


def get_model_configs(task_type: str) -> List[ModelConfig]:
    if task_type == TaskTypes.CLASSIFICATION:
        return [
            SKLEARN_LOGISTIC_REGRESSION_CONFIG,
            SKLEARN_LOGISTIC_REGRESSION_WITH_PREPROCESSOR_CONFIG,
            SKLEARN_LOGISTIC_REGRESSION_HASHING_VECTORIZER_CONFIG,
            SKLEARN_LOGISTIC_REGRESSION_TFIDF_VECTORIZER_CONFIG,
            SKLEARN_XGBOOST_CONFIG,
            SKLEARN_XGBOOST_HASHING_VECTORIZER_CONFIG,
            SKLEARN_XGBOOST_TFIDF_VECTORIZER_CONFIG,
            SKLEARN_KNN_CONFIG,
            SKLEARN_KNN_WITH_PREPROCESSOR_CONFIG,
            DISTILBERT_FREEZE_EMBEDDINGS_CONFIG,
            DISTILBERT_CLASSIFICATION_CONFIG,
            BERT_CLASSIFICATION_CONFIG,
            XLNET_CLASSIFICATION_CONFIG,
            LAYOUTLM_CLASSIFICATION_CONFIG,
            LAYOUTLM_FOR_SEQUENCE_CLASSIFICATION_CONFIG,
            SKLEARN_ONE_CLASS_SVM_CONFIG,
            GPT3_CLASSIFICATION_GPT_CONFIG,
            AZURE_FORM_RECOGNIZER_CONFIG,
        ]
    if task_type == TaskTypes.MULTILABEL_CLASSIFICATION:
        return [
            SKLEARN_LOGISTIC_REGRESSION_MULTI_LABEL_CONFIG,
            SKLEARN_LOGISTIC_REGRESSION_WITH_PREPROCESSOR_MULTI_LABEL_CONFIG,
            SKLEARN_LOGISTIC_REGRESSION_HASHING_VECTORIZER_MULTI_LABEL_CONFIG,
            SKLEARN_LOGISTIC_REGRESSION_TFIDF_VECTORIZER_MULTI_LABEL_CONFIG,
            SKLEARN_XGBOOST_MULTI_LABEL_CONFIG,
            SKLEARN_XGBOOST_HASHING_VECTORIZER_MULTI_LABEL_CONFIG,
            SKLEARN_XGBOOST_TFIDF_VECTORIZER_MULTI_LABEL_CONFIG,
            SKLEARN_KNN_MULTI_LABEL_CONFIG,
            SKLEARN_KNN_WITH_PREPROCESSOR_MULTI_LABEL_CONFIG,
            DISTILBERT_MULTI_LABEL_CONFIG,
            DISTILBERT_MULTI_LABEL_FREEZE_EMBEDDINGS_CONFIG,
            BERT_MULTI_LABEL_CONFIG,
        ]
    sequence_tagging_models = [
        AUTO_MODEL_FOR_TOKEN_CLASSIFICATION_CONFIG,
        CRF_MODEL_FOR_TOKEN_CLASSIFICATION_CONFIG,
        TINY_BERT_MODEL_FOR_TOKEN_CLASSIFICATION_CONFIG,
    ]
    if task_type == TaskTypes.SEQUENCE_TAGGING:
        return sequence_tagging_models
    entity_classification_models = [
        SKLEARN_LOGISTIC_REGRESSION_CONFIG,
        SKLEARN_LOGISTIC_REGRESSION_WITH_PREPROCESSOR_CONFIG,
        SKLEARN_LOGISTIC_REGRESSION_HASHING_VECTORIZER_CONFIG,
        SKLEARN_LOGISTIC_REGRESSION_TFIDF_VECTORIZER_CONFIG,
        SKLEARN_LOGISTIC_REGRESSION_EXTRACTION_CONFIG,
        SKLEARN_XGBOOST_CONFIG,
        SKLEARN_XGBOOST_HASHING_VECTORIZER_CONFIG,
        SKLEARN_XGBOOST_TFIDF_VECTORIZER_CONFIG,
        SKLEARN_XGBOOST_EXTRACTION_CONFIG,
        SKLEARN_KNN_CONFIG,
        SKLEARN_KNN_WITH_PREPROCESSOR_CONFIG,
        DISTILBERT_FREEZE_EMBEDDINGS_CONFIG,
        DISTILBERT_EXTRACTION_CONFIG,
        DISTILBERT_CLASSIFICATION_CONFIG,
        BERT_CLASSIFICATION_CONFIG,
        XLNET_CLASSIFICATION_CONFIG,
        LAYOUTLM_CLASSIFICATION_CONFIG,
        SKLEARN_ONE_CLASS_SVM_CONFIG,
        AZURE_FORM_RECOGNIZER_CONFIG,
    ]
    if task_type == TaskTypes.TEXT_ENTITY_CLASSIFICATION:
        return entity_classification_models
    if task_type == TaskTypes.TEXT_EXTRACTION:
        return entity_classification_models + sequence_tagging_models
    raise ValueError(f"{task_type} is not a valid task type")


def use_high_cardinality_settings(model_config: ModelConfig) -> ModelConfig:
    options = deepcopy(model_config.options)
    # 'liblinear' solver does not support high cardinality tasks and 'saga' solver must be used instead
    classifier_kwargs = options.get("classifier", {}).get("classifier_kwargs", {})
    if "solver" in classifier_kwargs and classifier_kwargs["solver"] == "liblinear":
        # changes dict in-place as dicts are mutable
        classifier_kwargs["solver"] = "saga"
        logger.info("'saga' is being used instead of 'liblinear' solver")
    model_config.options = options
    return model_config
