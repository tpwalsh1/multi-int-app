import os
import pathlib
import pickle
from abc import abstractmethod
from functools import partial
from typing import Any, Dict, List, Optional, Tuple, Union

import numpy as np
import pandas as pd
import scipy as sp
from sklearn.base import BaseEstimator
from sklearn.exceptions import NotFittedError
from sklearn.linear_model import LogisticRegression

from api_utils.exceptions import UserInputError
from file_utils.core import open_file
from snorkelflow.extraction.span import SpanCols
from snorkelflow.models.cls_model import (
    BaseManifest,
    ClassificationModelV2,
    TrainedClassificationModelV2,
)
from snorkelflow.models.model_configs import ModelTrainingConfig
from snorkelflow.models.multi_output_classifier import MultiOutputClassifier
from snorkelflow.models.utils import (
    MODEL_CONFIG_OPTION_FIELDS,
    MODEL_CONFIG_OPTION_N_CLASSES,
    MODEL_CONFIG_OPTION_USE_LF_LABELS,
    SKLEARN_PREPROCESSOR_DICT,
    START_FEATURIZATION_PCT,
    START_TRAINING_PCT,
    TOTAL_TRAINING_PCT,
    VECTORIZERS_DICT,
    ExtractionOptions,
    MockStatusHandler,
    get_decision_threshold,
    get_extraction_features,
    is_num_list_series,
    is_num_series,
    is_text_series,
    num_to_feature,
)
from snorkelflow.utils.logging import get_logger

logger = get_logger("Models")

LIBLINEAR_MAX_CARDINALITY = 16

CLASSIFIERS = {"LogisticRegression": LogisticRegression}
try:
    from xgboost.sklearn import XGBClassifier  # type: ignore

    CLASSIFIERS["XGBoostClassifier"] = XGBClassifier
except ImportError:
    logger.debug(
        "Import failed for XGBoost classification model. Skipping registration in SkLearn."
    )
    pass

try:
    from sklearn.neighbors import KNeighborsClassifier

    CLASSIFIERS["KNeighborsClassifier"] = KNeighborsClassifier
except ImportError:
    logger.debug(
        "Import failed for KNeighborsClassifier classification model. Skipping registration in SkLearn."
    )
    pass

try:
    from snorkelflow.models.svm_wrapper import SVMWrapper

    CLASSIFIERS["OneClassSVMClassifier"] = SVMWrapper
except ImportError:
    logger.debug(
        "Import failed for OneClassSVM classification model. Skipping registration in SkLearn."
    )
    pass

EMPTY_SPAN_MARKER = "__EMPTY__"


class ThresholdHolder:
    # this is a copy of ThresholdHolder from label_space.base
    # due to backwards compatibility issues for existing deployments, we can't import this class
    def __init__(self, data: Union[float, Dict[str, float]]) -> None:
        self._data = data

    def get_threshold(self, class_name: Optional[str] = None) -> float:
        if isinstance(self._data, float):
            return self._data
        else:
            assert class_name is not None  # mypy
            return self._data[class_name]

    def round(self, ndigits: int) -> Union[float, Dict[str, float]]:
        if isinstance(self._data, float):
            return round(self._data, ndigits)
        else:
            return {k: round(v, ndigits) for k, v in self._data.items()}


class SklearnTextAndNumericalVectorizer:
    _EXT_FIELD = "__TMP_SKLEARN_EXT_FEAT_TEXT"

    def __init__(
        self,
        vectorizers: Dict[str, Optional[BaseEstimator]],
        extraction_options: Optional[ExtractionOptions] = None,
        extraction_vectorizer: Optional[BaseEstimator] = None,
    ) -> None:
        """
        Vectorization handler for mixed-type DataFrame inputs.

        Parameters
        ----------
        vectorizers
            Mapping from field name to a vectorizer or None if the field does
            not require transformation. Transform will raise an error if a field of the
            input DataFrame is not compatible with the field's vectorizer (e.g. a text
            field whose entry in `vectorizers` is None). Vectorizers can be provided
            unfit; they can be fit using `fit_transform`.
        extraction_options:
            For extraction models, options for text field manipulation.
        extraction_vectorizer:
            For extraction models, vectorizer used for text field.
        """
        assert self._EXT_FIELD not in vectorizers
        if (extraction_options is None) != (extraction_vectorizer is None):
            raise ValueError(
                "Must provide both extractions_options and extraction_vectorizer, or neither"
            )
        self.extraction_options = extraction_options
        self.extraction_vectorizer = extraction_vectorizer
        # HACK: span_preview is frequently specified as a field when we actually just
        # want to use it for extraction featurization. If so, skip the vectorizer.
        # TODO: consolidate special handling of conditional extraction featurization
        self.vectorizers = {
            k: v
            for k, v in vectorizers.items()
            if (k != SpanCols.SPAN_PREVIEW) or (self.extraction_options is None)
        }
        if not (self.vectorizers or self.extraction_vectorizer):
            raise ValueError("No vectorizers")

        self.feature_names: List[str] = []  # vectorized feature names
        self.extraction_feature_names: List[str] = []
        self.generic_feature_names: List[str] = []

    def fit_transform(self, df: pd.DataFrame) -> sp.sparse.csr_matrix:
        return self._maybe_fit_transform(df, fit=True)

    def transform(self, df: pd.DataFrame) -> sp.sparse.csr_matrix:
        return self._maybe_fit_transform(df, fit=False)

    def _maybe_fit_transform(self, df: pd.DataFrame, fit: bool) -> sp.sparse.csr_matrix:
        self.feature_names = []
        extraction_features = None
        features = None
        if self.extraction_options:
            extraction_features = self._get_extraction_features(df, fit=fit)
            self.feature_names.extend(self.extraction_feature_names)
        features = self._get_generic_features(df, fit=fit)
        if features is not None:
            self.feature_names.extend(self.generic_feature_names)
        return sp.sparse.hstack([extraction_features, features])

    def _get_vectorizer_feature_names(
        self, vectorizer: BaseEstimator, field_str: str
    ) -> Optional[List[str]]:
        # making features names more readable by appending field name
        try:
            return [
                feature + " - " + field_str
                for feature in vectorizer.get_feature_names_out()
            ]
        except Exception as e:
            logger.warning(
                f"Exception while getting vectorizer {self.extraction_vectorizer} feature names for extraction fields: {e}"
            )
        return None

    def _get_extraction_features(
        self, df: pd.DataFrame, fit: bool
    ) -> sp.sparse.csr_matrix:
        assert self.extraction_options is not None
        assert self.extraction_vectorizer is not None
        extraction_features = get_extraction_features(
            df,
            left_context_len=self.extraction_options.left_context_len,
            right_context_len=self.extraction_options.right_context_len,
            mask_span=self.extraction_options.mask_span,
        )
        if fit:
            self.extraction_vectorizer.fit(extraction_features.full)

        left_context_feature_names = self._get_vectorizer_feature_names(
            self.extraction_vectorizer, "left_context"
        )
        right_context_feature_names = self._get_vectorizer_feature_names(
            self.extraction_vectorizer, "right_context"
        )

        if self.extraction_options.mask_span:
            if left_context_feature_names and right_context_feature_names:
                self.extraction_feature_names = (
                    left_context_feature_names + right_context_feature_names
                )
            return sp.sparse.hstack(
                [
                    self.extraction_vectorizer.transform(extraction_features.left),
                    self.extraction_vectorizer.transform(extraction_features.right),
                ]
            )

        span_text_feature_names = self._get_vectorizer_feature_names(
            self.extraction_vectorizer, "span_context"
        )
        if (
            left_context_feature_names
            and right_context_feature_names
            and span_text_feature_names
        ):
            self.extraction_feature_names = (
                left_context_feature_names
                + span_text_feature_names
                + right_context_feature_names
            )
        return sp.sparse.hstack(
            [
                self.extraction_vectorizer.transform(extraction_features.left),
                self.extraction_vectorizer.transform(df[SpanCols.SPAN_TEXT]),
                self.extraction_vectorizer.transform(extraction_features.right),
            ]
        )

    def _get_generic_features(
        self, df: pd.DataFrame, fit: bool
    ) -> Optional[sp.sparse.csr_matrix]:
        num_features, text_features = [], []
        numerical_feature_names, text_feature_names = [], []

        df = df.loc[:, ~df.columns.duplicated()]

        for field in self.vectorizers:
            if field not in df.columns:
                err_msg = (
                    f"The field {field} cannot be found in the dataframe's columns"
                )
                raise UserInputError(
                    detail=err_msg,
                    user_friendly_message=err_msg,
                    how_to_fix="Add this field to your data sources or deselect this field for training",
                )
            if is_num_series(df[field]):
                num_features.append(num_to_feature(df[field]))
                numerical_feature_names.append(field)
            elif isinstance(df[field].iloc[0], sp.sparse.csr_matrix):
                num_features.append(sp.sparse.vstack(df[field]))
                numerical_feature_names.append(field)
            elif is_num_list_series(df[field]):
                try:
                    feat = sp.sparse.vstack(df[field].map(sp.sparse.csr_matrix))
                except ValueError as e:
                    err_msg = f"Failed to convert field {field} to features."
                    how_to_fix = f"Please deselect field {field} for training."
                    if "incompatible dimensions" in str(e):
                        err_msg += f"Field {field} is list like and may have inconsistent number of elements."
                        how_to_fix += f" Or make sure field {field} has consistent number of elements."
                    raise UserInputError(
                        detail=err_msg,
                        user_friendly_message=err_msg,
                        how_to_fix=how_to_fix,
                    )
                num_features.append(feat)
                numerical_feature_names.append(field)
            elif is_text_series(df[field]):
                vectorizer = self.vectorizers.get(field)
                if vectorizer is None:
                    err_msg = f"Field {field} was detected as a text field, and no text vectorizer was found. If this is a numeric column, ensure there are no string representation of values or NaNs."
                    raise UserInputError(detail=err_msg, user_friendly_message=err_msg)
                field_data = df[field].fillna("")
                field_prefix_feature_names = self._get_vectorizer_feature_names(
                    vectorizer, field
                )
                if field_prefix_feature_names:
                    text_feature_names.extend(field_prefix_feature_names)
                if fit:
                    # At train time, we ensure that there won't be an empty vocabulary
                    if any(x for x in field_data):
                        try:
                            feats = vectorizer.fit_transform(field_data)
                        except ValueError as e:
                            if "empty vocabulary; perhaps the documents only" in str(e):
                                raise ValueError(
                                    f"Can't train on field {field} as it contains only stop words. First 5 values in {field}: {field_data.head().tolist()}"
                                )
                            raise e
                    else:
                        feats = vectorizer.fit_transform([EMPTY_SPAN_MARKER] * len(df))
                else:
                    feats = vectorizer.transform(field_data)
                text_features.append(feats)
            else:
                err_msg = f"Field {field} does not contain string or numeric type"
                raise UserInputError(detail=err_msg, user_friendly_message=err_msg)
        if not text_features and not num_features:
            return None

        self.generic_feature_names = numerical_feature_names + text_feature_names
        return sp.sparse.hstack(num_features + text_features)

    def save_vectorizers(self, dirpath: pathlib.Path) -> Dict[str, str]:
        vectorizer_paths = {}
        for field, vectorizer in self.vectorizers.items():
            if vectorizer is not None:
                try:
                    # HashingVectorizer always fails check_is_fitted(...)
                    vectorizer.transform(["quack like a duck"])
                except NotFittedError:
                    raise NotFittedError(
                        f"Cannot save {self.__class__.__name__}: vectorizer for field "
                        f"{field} is not fit"
                    )
                vectorizer_pickle = f"vectorizer_{field}.pickle"
                vectorizer_paths[field] = vectorizer_pickle
                with open(dirpath / vectorizer_pickle, "xb") as vf:
                    pickle.dump(vectorizer, vf)
        if self.extraction_vectorizer:
            vectorizer_pickle = f"vectorizer_{self._EXT_FIELD}.pickle"
            vectorizer_paths[self._EXT_FIELD] = vectorizer_pickle
            try:
                # HashingVectorizer always fails check_is_fitted(...)
                self.extraction_vectorizer.transform(["quack like a duck"])
            except NotFittedError:
                raise NotFittedError(
                    f"Cannot save {self.__class__.__name__}: extraction vectorizer "
                    f"is not fit."
                )
            with open(dirpath / vectorizer_pickle, "xb") as vf:
                pickle.dump(self.extraction_vectorizer, vf)
        return vectorizer_paths

    @classmethod
    def from_saved_vectorizers(
        cls,
        vectorizer_paths: Dict[str, str],
        dirpath: str,
        fields: List[str],
        extraction_options: Optional[ExtractionOptions],
        storage_options: Optional[Dict[str, Any]] = None,
    ) -> "SklearnTextAndNumericalVectorizer":
        vectorizers = {}
        extraction_vectorizer = None
        for field, v in vectorizer_paths.items():
            v_path = os.path.join(dirpath, v)
            with open_file(
                v_path,
                mode="rb",
                **(storage_options if storage_options is not None else {}),
            ) as vf:
                vectorizer = pickle.load(vf)
            if field == cls._EXT_FIELD:
                extraction_vectorizer = vectorizer
            else:
                vectorizers[field] = vectorizer
        for field in fields:
            if field not in vectorizers:
                vectorizers[field] = None
        return cls(
            vectorizers,
            extraction_options=extraction_options,
            extraction_vectorizer=extraction_vectorizer,
        )


class SklearnPreprocessor:
    """
    This class implememts Sklearn Preprocessors; specifically the following -
    1. fit_transform related methods
    2. saving and loading the sklearn object for inference time
    This class currently supports only one preprocessor for all columns in the data.
    MaxAbsScaler -
    https://scikit-learn.org/stable/modules/generated/sklearn.preprocessing.MaxAbsScaler.html
    """

    all_columns = "_ALL_COLUMNS"

    def __init__(self, sklearn_preprocessor: Optional[BaseEstimator] = None) -> None:
        self.sklearn_preprocessor = sklearn_preprocessor

    def fit_transform(
        self, input_sparse_matrix: sp.sparse.csr_matrix
    ) -> sp.sparse.csr_matrix:
        return self._maybe_fit_transform(input_sparse_matrix, fit=True)

    def transform(
        self, input_sparse_matrix: sp.sparse.csr_matrix
    ) -> sp.sparse.csr_matrix:
        return self._maybe_fit_transform(input_sparse_matrix, fit=False)

    def _maybe_fit_transform(
        self, input_sparse_matrix: sp.sparse.csr_matrix, fit: bool
    ) -> sp.sparse.csr_matrix:
        assert self.sklearn_preprocessor is not None
        if fit:
            return self.sklearn_preprocessor.fit_transform(input_sparse_matrix)
        else:
            return self.sklearn_preprocessor.transform(input_sparse_matrix)

    def save_sklearn_preprocessor(self, dirpath: pathlib.Path) -> Dict[str, List[str]]:
        sklearn_preprocessor_path_all_columns = (
            f"sklearn_preprocessor{self.all_columns}.pickle"
        )
        with open(dirpath / sklearn_preprocessor_path_all_columns, "xb") as sp:
            pickle.dump(self.sklearn_preprocessor, sp)

        # making the return type a dictionary to support a generalized Manifest
        # even though currently only one preprocessor is supported
        sklearn_preprocessor_pickle = {
            self.all_columns: [sklearn_preprocessor_path_all_columns]
        }
        return sklearn_preprocessor_pickle

    @classmethod
    def from_saved_sklearn_preprocessors(
        cls,
        sklearn_preprocessor_path: Dict[str, List[str]],
        dirpath: str,
        storage_options: Optional[Dict[str, Any]] = None,
    ) -> "SklearnPreprocessor":
        # expecting sklearn_preprocessor_path as a dictionary to support a generalized
        # Manifest even though currently only one preprocessor is supported
        # Assuming that the dictionary and the internal list contain only one item
        sklearn_preprocessor_path_all_columns = sklearn_preprocessor_path[
            cls.all_columns
        ][0]

        path = os.path.join(dirpath, sklearn_preprocessor_path_all_columns)
        with open_file(
            path, mode="rb", **(storage_options if storage_options is not None else {})
        ) as sp:
            sklearn_preprocessor = pickle.load(sp)
        return cls(sklearn_preprocessor)


class _BaseTrainedSklearnModel(TrainedClassificationModelV2):
    """ABC for sklearn-based TrainedClassificationModelV2s."""

    def __init__(
        self,
        model: BaseEstimator,
        fields: List[str],
        vectorizer: SklearnTextAndNumericalVectorizer,
        sklearn_preprocessor: Optional[SklearnPreprocessor],
        decision_threshold: Optional[Union[float, Dict[str, float]]] = None,
        use_lf_labels: Optional[bool] = None,
        n_classes: Optional[int] = None,
        prob_idx_to_label_int: Optional[Dict[int, int]] = None,
    ) -> None:
        self.model = model
        self.vectorizer = vectorizer
        self.sklearn_preprocessor = sklearn_preprocessor
        self.fields = fields
        self.decision_threshold = decision_threshold
        self.use_lf_labels = use_lf_labels
        self.n_classes = n_classes
        self.prob_idx_to_label_int = prob_idx_to_label_int

    def predict(self, df: pd.DataFrame) -> Tuple[np.ndarray, Optional[np.ndarray]]:
        if not len(df):
            logger.info("Received empty dataframe, returning empty predictions.")
            return np.empty([0], "int64"), np.empty([0, self.n_classes], "float64")
        logger.info("Featurizing data fields.")
        X = self.vectorizer.transform(df)

        if self.sklearn_preprocessor is not None:
            logger.info("Applying sklearn preprocessor.")
            X = self.sklearn_preprocessor.transform(X)

        logger.info(f"Performing inference on {X.shape} shape features.")
        probs = self.model.predict_proba(X)
        return self._postprocess(probs)

    @abstractmethod
    def _postprocess(self, probs: Any) -> Tuple[np.ndarray, Any]:
        """Postprocess predictions so they can be returned in a RawLabel values format."""
        pass

    @classmethod
    def load(
        cls, dirpath: str, storage_options: Optional[Dict[str, Any]] = None
    ) -> "_BaseTrainedSklearnModel":
        # Read the manifest
        storage_options = storage_options or {}
        manifest_path = os.path.join(dirpath, "manifest.json")
        with open_file(
            manifest_path, **(storage_options if storage_options is not None else {})
        ) as mf:
            m = cls.Manifest.parse_raw(mf.read())
        # Load the sklearn predictor
        assert m.trainer is not None
        model_path = os.path.join(dirpath, m.trainer)
        with open_file(
            model_path,
            mode="rb",
            **(storage_options if storage_options is not None else {}),
        ) as tf:
            model = pickle.load(tf)
        # Parse ExtractionOptions
        extraction_options: Optional[ExtractionOptions]
        if m.is_extraction:
            assert m.extraction_left_context_len is not None
            assert m.extraction_right_context_len is not None
            assert m.extraction_mask_span is not None
            extraction_options = ExtractionOptions(
                left_context_len=m.extraction_left_context_len,
                right_context_len=m.extraction_right_context_len,
                mask_span=m.extraction_mask_span,
            )
        else:
            extraction_options = None
        # Construct the vectorizer
        assert m.vectorizers is not None
        assert m.model_fields is not None
        vectorizer = SklearnTextAndNumericalVectorizer.from_saved_vectorizers(
            vectorizer_paths=m.vectorizers,
            dirpath=dirpath,
            fields=m.model_fields,
            extraction_options=extraction_options,
            storage_options=storage_options,
        )

        # Construct the Sklearn Preprocessor if present
        sklearn_preprocessor: Optional[SklearnPreprocessor]
        if m.sklearn_preprocessor:
            sklearn_preprocessor = SklearnPreprocessor.from_saved_sklearn_preprocessors(
                sklearn_preprocessor_path=m.sklearn_preprocessor,
                dirpath=dirpath,
                storage_options=storage_options,
            )
        else:
            sklearn_preprocessor = None

        # Construct the TrainedSklearnModel
        return cls._load(
            m,
            model=model,
            vectorizer=vectorizer,
            sklearn_preprocessor=sklearn_preprocessor,  # None if not present
            fields=m.model_fields,
            decision_threshold=m.decision_threshold,
            use_lf_labels=m.use_lf_labels or False,
            n_classes=m.n_classes,
            prob_idx_to_label_int=m.prob_idx_to_label_int,
        )

    @classmethod
    @abstractmethod
    def _load(cls, m: BaseManifest, **kwargs: Any) -> "_BaseTrainedSklearnModel":
        pass

    # NOTE: Be very careful when updating the Manifest, so as not to break
    # backwards compatibility. For example, this means only adding optional fields,
    # avoiding edits of existing fields, etc.
    class Manifest(BaseManifest):
        trainer: Optional[str]
        vectorizers: Optional[Dict[str, str]]
        sklearn_preprocessor: Optional[
            Dict[str, List[str]]
        ]  # keeping it very generalizable
        is_extraction: Optional[bool]
        extraction_left_context_len: Optional[int]
        extraction_right_context_len: Optional[int]
        extraction_mask_span: Optional[bool]
        decision_threshold: Optional[Union[float, Dict[str, float]]]
        use_lf_labels: Optional[bool]
        n_classes: Optional[int]
        prob_idx_to_label_int: Optional[Dict[int, int]]


class TrainedSklearnModel(_BaseTrainedSklearnModel):
    def save(self, dirpath: pathlib.Path) -> None:
        m = self.Manifest(type=self.__class__.__name__, model_fields=self.fields)
        # Pickle sklearn predictor
        dirpath.mkdir(parents=True, exist_ok=True)
        model_pickle = "model.pickle"
        model_dirpath = dirpath / model_pickle
        with open(model_dirpath, "xb") as tf:
            pickle.dump(self.model, tf)
        m.trainer = model_pickle
        # Serialize underlying vectorizers
        m.vectorizers = self.vectorizer.save_vectorizers(dirpath)
        if self.sklearn_preprocessor is not None:
            # Serialize Sklearn Preprocessors
            m.sklearn_preprocessor = (
                self.sklearn_preprocessor.save_sklearn_preprocessor(dirpath)
            )
        # Serialize extraction options
        extraction_options = self.vectorizer.extraction_options
        m.is_extraction = extraction_options is not None
        if extraction_options is not None:
            m.extraction_left_context_len = extraction_options.left_context_len
            m.extraction_right_context_len = extraction_options.right_context_len
            m.extraction_mask_span = extraction_options.mask_span
        # Serialize other options
        m.decision_threshold = self.decision_threshold
        m.use_lf_labels = self.use_lf_labels
        m.prob_idx_to_label_int = self.prob_idx_to_label_int
        m.n_classes = self.n_classes

        # Write manifest to disk
        with open(dirpath / "manifest.json", "w+") as mf:
            mf.write(m.json())

    @classmethod
    def _load(cls, m: BaseManifest, **kwargs: Any) -> "_BaseTrainedSklearnModel":
        return cls(**kwargs)

    def _postprocess(self, probs: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
        """Predict and return in the raw label values format for SingleLabelSpace.

        A 4-class prediction task might only have labels for 0, 1, and 3.
        sklearn will output a model with probability of dim [num_samples, 3],
        when our downstream code requires it to be dim [num_samples, n_classes].
        This inserts empty columns appropriately for missing labels.

        NOTE: These values will get zipped with x_uids to return a RawLabel format.
        """
        if self.prob_idx_to_label_int is not None:
            raw_probs_values = np.zeros((len(probs), self.n_classes))
            for output_label, real_label in self.prob_idx_to_label_int.items():
                raw_probs_values[:, real_label] = probs[:, output_label]
        else:
            raw_probs_values = probs

        if self.decision_threshold is not None:
            raw_preds_values = (
                np.array(raw_probs_values)[:, 1] >= self.decision_threshold
            ).astype(int)
        else:
            raw_preds_values = np.argmax(raw_probs_values, axis=1)

        return raw_preds_values, raw_probs_values


class TrainedMultiLabelSklearnModel(_BaseTrainedSklearnModel):
    def __init__(
        self,
        invalid_class_default_prob: Optional[Dict[int, float]] = None,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.invalid_class_default_prob = invalid_class_default_prob

    def save(self, dirpath: pathlib.Path) -> None:
        m = self.Manifest(type=self.__class__.__name__, model_fields=self.fields)
        # Pickle sklearn predictor
        model_pickle = "model.pickle"
        with open(dirpath / model_pickle, "xb") as tf:
            pickle.dump(self.model, tf)
        m.trainer = model_pickle
        # Serialize underlying vectorizers
        m.vectorizers = self.vectorizer.save_vectorizers(dirpath)
        if self.sklearn_preprocessor is not None:
            # Serialize Sklearn Preprocessors
            m.sklearn_preprocessor = (
                self.sklearn_preprocessor.save_sklearn_preprocessor(dirpath)
            )
        # Serialize extraction options
        extraction_options = self.vectorizer.extraction_options
        m.is_extraction = extraction_options is not None
        if extraction_options is not None:
            m.extraction_left_context_len = extraction_options.left_context_len
            m.extraction_right_context_len = extraction_options.right_context_len
            m.extraction_mask_span = extraction_options.mask_span
        # Serialize other options
        m.decision_threshold = self.decision_threshold
        m.use_lf_labels = self.use_lf_labels
        m.prob_idx_to_label_int = self.prob_idx_to_label_int
        m.n_classes = self.n_classes
        m.invalid_class_default_prob = self.invalid_class_default_prob
        # Write manifest to disk
        with open(dirpath / "manifest.json", "w+") as mf:
            mf.write(m.json())

    # NOTE: Be very careful when updating the Manifest, so as not to break
    # backwards compatibility. For example, this means only adding optional fields,
    # avoiding edits of existing fields, etc.
    class Manifest(BaseManifest):
        trainer: Optional[str]
        vectorizers: Optional[Dict[str, str]]
        sklearn_preprocessor: Optional[
            Dict[str, List[str]]
        ]  # keeping it very generalizable
        is_extraction: Optional[bool]
        extraction_left_context_len: Optional[int]
        extraction_right_context_len: Optional[int]
        extraction_mask_span: Optional[bool]
        decision_threshold: Optional[Union[float, Dict[str, float]]]
        use_lf_labels: Optional[bool]
        n_classes: Optional[int]
        prob_idx_to_label_int: Optional[Dict[int, int]]
        invalid_class_default_prob: Optional[Dict[int, float]]

    @classmethod
    def _load(cls, m: BaseManifest, **kwargs: Any) -> "TrainedMultiLabelSklearnModel":
        return cls(**kwargs, invalid_class_default_prob=m.invalid_class_default_prob)  # type: ignore

    def predict(self, df: pd.DataFrame) -> Tuple[np.ndarray, Optional[np.ndarray]]:
        if not len(df):
            logger.info("Received empty dataframe, returning empty predictions.")
            return np.empty([0], "object"), np.empty([0, self.n_classes], "float64")
        logger.info("Featurizing data fields.")
        X = self.vectorizer.transform(df)

        if self.sklearn_preprocessor is not None:
            logger.info("Applying sklearn preprocessor.")
            X = self.sklearn_preprocessor.transform(X)

        logger.info(f"Performing inference on {X.shape} shape features.")
        probs = self.model.predict_proba(X)
        if probs:
            return self._postprocess(probs)
        # De-generate labels, use default probs for all classes.
        n_examples = len(df)
        dense_probs = np.zeros((n_examples, self.n_classes))
        assert self.invalid_class_default_prob is not None  # mypy
        for class_int, default_prob in self.invalid_class_default_prob.items():
            dense_probs[:, class_int] = default_prob
        preds = self._probs_to_preds(dense_probs)
        return preds, np.array(dense_probs)

    def _postprocess(self, probs: List) -> Tuple[np.ndarray, List]:
        """Predict and return in the raw label values format for MultiLabelSpace.

        NOTE: These values will get zipped with x_uids to return a RawLabel format.
        """
        assert self.n_classes  # Optional in Manifest, it *should* be there.
        n_examples = len(probs[0])
        prob_idx_to_label_int = self.prob_idx_to_label_int or {
            i: i for i in range(self.n_classes)
        }
        dense_probs = np.zeros((n_examples, self.n_classes))
        for prob_idx, label_int in prob_idx_to_label_int.items():
            dense_probs[:, label_int] = probs[prob_idx][:, 1]

        assert self.invalid_class_default_prob is not None
        for class_int, default_prob in self.invalid_class_default_prob.items():
            dense_probs[:, class_int] = default_prob
        preds = self._probs_to_preds(dense_probs)
        return preds, np.array(dense_probs)

    def _probs_to_preds(self, dense_probs: np.ndarray) -> np.ndarray:
        n_examples = len(dense_probs)
        decision_threshold = (
            0.5 if self.decision_threshold is None else self.decision_threshold
        )
        threshold_holder = ThresholdHolder(decision_threshold)
        raw_preds_values = [{"_default": 0} for _ in range(n_examples)]
        for prob, preds in zip(dense_probs, raw_preds_values):
            for class_int, class_prob in enumerate(prob):
                threshold = threshold_holder.get_threshold(str(class_int))
                if class_prob >= threshold:
                    preds[str(class_int)] = 1
        return np.array(raw_preds_values)


def _xgb_callback(env: Any, status_handler: Any) -> None:
    # Using Any to avoid expensive imports.
    # type(env) is xgboost.core.XGBoostCallbackEnv
    # XGBoostCallbackEnv(model=<xgboost.core.Booster object at 0x7f41440589a0>, cvfolds=None, iteration=2, begin_iteration=0, end_iteration=100, rank=0, evaluation_result_list=[])
    msg = f"Iteration {env.iteration} / {env.end_iteration}"
    logger.info(msg)
    if hasattr(status_handler, "update_status"):
        # TODO(ENG-12800): status_handler should be TrainingStatusHandler, and we
        # should use its higher level methods instead of re-compting percentage
        # here.
        pct = START_TRAINING_PCT + int(
            (TOTAL_TRAINING_PCT - START_TRAINING_PCT)
            * env.iteration
            / env.end_iteration
        )
        status_handler.update_status(msg, pct)


class _BaseSklearnModel(ClassificationModelV2):
    """Provide base functionality for an sklearn ClassificationModelV2."""

    HIGH_CARDINALITY_MAX_ITER = 10

    def __init__(
        self, model_config: ModelTrainingConfig, check_high_cardinality: bool = True
    ) -> None:
        """Initialize class for all sklearn-based models."""
        super().__init__(model_config)
        self.prob_idx_to_label_int: Optional[Dict[int, int]] = None
        # Vectorizer will be created at train time
        self.vectorizer: Optional[SklearnTextAndNumericalVectorizer] = None
        # Sklearn preprocessor will be created at train time
        self.sklearn_preprocessor: Optional[SklearnPreprocessor] = None
        self.invalid_class_default_prob: Dict[int, float] = {}
        # Parse the model config
        self._parse_model_config(self.model_config)
        self.n_classes = self.model_config.options[MODEL_CONFIG_OPTION_N_CLASSES]

        # Check if num_classes is > 3 to account for unknown class
        # Note: this check should live with the classifier definition, not this base class
        classifier_cls_name = self.model_config.options["classifier"]["classifier_cls"]
        if self.n_classes > 3 and classifier_cls_name == "OneClassSVMClassifier":
            err_msg = (
                "OneClassSVMClassifier is not supported for multinomial classification"
            )
            raise UserInputError(detail=err_msg, user_friendly_message=err_msg)

        if self.n_classes > LIBLINEAR_MAX_CARDINALITY and check_high_cardinality:
            if (
                self.model_config.options["classifier"]["classifier_kwargs"].get(
                    "solver"
                )
                == "liblinear"
            ):
                err_msg = (
                    f"The 'liblinear' solver for high cardinality tasks with more than {LIBLINEAR_MAX_CARDINALITY} "
                    f"classes is not supported due to slow performance. Please use the 'saga' solver instead."
                )
                raise UserInputError(detail=err_msg, user_friendly_message=err_msg)

            self.model_config.options["classifier"]["classifier_kwargs"][
                "max_iter"
            ] = self.model_config.options["classifier"]["classifier_kwargs"].get(
                "max_iter", self.HIGH_CARDINALITY_MAX_ITER
            )
            if (
                self.model_config.options["classifier"]["classifier_kwargs"]["max_iter"]
                > self.HIGH_CARDINALITY_MAX_ITER
            ):
                msg = f"`max_iter` > {self.HIGH_CARDINALITY_MAX_ITER} might cause significant slowdown for cardinality > {LIBLINEAR_MAX_CARDINALITY}."
                logger.warning(msg)

    def _train(
        self, df: pd.DataFrame, Y: np.ndarray, status_handler: Optional[Any] = None
    ) -> None:
        if not status_handler:
            status_handler = MockStatusHandler()

        status_handler.update_status(
            "Running model featurization", START_FEATURIZATION_PCT
        )

        # Create vectorizers for text fields
        vectorizers = {
            field: self._get_vectorizer() if is_text_series(df[field]) else None
            for field in self.fields
        }
        # Create special vectorizer for extraction field
        ext_vectorizer = self._get_vectorizer() if self.extraction_options else None
        # Build and fit SklearnTextAndNumericalVectorizer
        self.vectorizer = SklearnTextAndNumericalVectorizer(
            vectorizers,
            extraction_options=self.extraction_options,
            extraction_vectorizer=ext_vectorizer,
        )
        X = self.vectorizer.fit_transform(df)

        # Normalize all features using Sklearn Preprocessing Utility
        if self.sklearn_preprocessor_cls:
            sklearn_preprocessor = self._get_sklearn_preprocessor()
            self.sklearn_preprocessor = SklearnPreprocessor(sklearn_preprocessor)
            X = self.sklearn_preprocessor.fit_transform(X)

        status_handler.update_status("Training model", START_TRAINING_PCT)
        status_handler.start_end_model_training()
        sample_weight = None
        # Repeat data with sample weights if data has probabilistic labels
        if (
            isinstance(Y[0], list)
            or isinstance(Y[0], np.ndarray)
            and not self.label_space_cls_name == "MultiLabelSpace"
        ):
            X, Y, sample_weight = self._generate_weighted_samples(X, Y)

        Y = self._preprocess_labels(Y)

        kwargs: Dict[str, Any] = {}
        if sample_weight is not None:
            kwargs["sample_weight"] = sample_weight
        # XGBoost models take a callbacks argument to the fit method.
        if (
            self.model_config.options["classifier"]["classifier_cls"]
            == "XGBoostClassifier"
        ):
            kwargs["callbacks"] = [
                partial(_xgb_callback, status_handler=status_handler)
            ]

        logger.info(
            f"Training model on {X.shape} shape features and {Y.shape} shape labels."
        )
        logger.info(f"Passing kwargs {kwargs.keys()} to model fit method.")
        self.model.fit(X, Y, **kwargs)

    @abstractmethod
    def _generate_weighted_samples(
        self, X: sp.sparse.csr_matrix, Y: np.ndarray
    ) -> Tuple[sp.sparse.csr_matrix, np.ndarray, np.ndarray]:
        pass

    @abstractmethod
    def _preprocess_labels(self, Y: np.ndarray) -> np.ndarray:
        """Modify Y so that the model can safely ingest for train/predict."""
        pass

    @abstractmethod
    def _get_trained_model(self) -> Any:
        pass

    def _get_classifier_class(self, classifier_cls: str) -> BaseEstimator:
        if classifier_cls in CLASSIFIERS:
            return CLASSIFIERS[classifier_cls]
        else:
            raise ValueError(
                f"Classifier class {classifier_cls} is not available. "
                f"Available classes: {', '.join(CLASSIFIERS.keys())}."
            )

    def _parse_model_config(self, model_config: ModelTrainingConfig) -> None:
        # Initialize Sklearn model
        classifier_options = model_config.options["classifier"]
        self.model = self._get_classifier_class(classifier_options["classifier_cls"])(
            **classifier_options["classifier_kwargs"]
        )
        # Get options for text vectorization
        self.text_vectorizer_cls = None
        self.text_vectorizer_kwargs: Optional[Dict[str, Any]] = None
        text_vectorizer_options = model_config.options.get("text_vectorizer")
        if text_vectorizer_options:
            self.text_vectorizer_cls = text_vectorizer_options["vectorizer_cls"]
            self.text_vectorizer_kwargs = text_vectorizer_options["vectorizer_kwargs"]
        # Get fields for training
        self.fields = model_config.options[MODEL_CONFIG_OPTION_FIELDS]
        # Get text extraction options
        self.extraction_options: Optional[ExtractionOptions]
        extraction_options_raw = model_config.options.get("extraction_options")
        if extraction_options_raw:
            self.extraction_options = ExtractionOptions(
                extraction_options_raw["left_context_len"],
                extraction_options_raw["right_context_len"],
                extraction_options_raw["mask_span"],
            )
        else:
            self.extraction_options = None
        # Get decision threshold if preset
        self.decision_threshold = get_decision_threshold(model_config)
        # Get LF label featurization options
        self.use_lf_labels = model_config.options.get(
            MODEL_CONFIG_OPTION_USE_LF_LABELS, False
        )
        # Get Sklearn Preprocessor options
        self.sklearn_preprocessor_cls = None
        self.sklearn_preprocessor_kwargs = None
        sklearn_preprocessor_options = model_config.options.get("sklearn_preprocessor")
        if sklearn_preprocessor_options:
            self.sklearn_preprocessor_cls = sklearn_preprocessor_options[
                "sklearn_preprocessor_cls"
            ]
            self.sklearn_preprocessor_kwargs = sklearn_preprocessor_options[
                "sklearn_preprocessor_kwargs"
            ]

    def _get_vectorizer(self) -> BaseEstimator:
        if self.text_vectorizer_cls in VECTORIZERS_DICT:
            if (
                self.text_vectorizer_kwargs
                and "ngram_range" in self.text_vectorizer_kwargs
                and not isinstance(self.text_vectorizer_kwargs["ngram_range"], tuple)
            ):
                # scikit-learn 1.2.0 requires ngram_range to be a tuple
                self.text_vectorizer_kwargs["ngram_range"] = tuple(
                    self.text_vectorizer_kwargs["ngram_range"]
                )
            ret = VECTORIZERS_DICT[self.text_vectorizer_cls](
                **self.text_vectorizer_kwargs
            )
            if (
                self.text_vectorizer_kwargs
                and "ngram_range" in self.text_vectorizer_kwargs
            ):
                # convert the tuple back to list in order to be json serializable
                self.text_vectorizer_kwargs["ngram_range"] = list(
                    self.text_vectorizer_kwargs["ngram_range"]
                )
            return ret
        else:
            raise ValueError(
                f"Vectorizer class {self.text_vectorizer_cls} is not available. "
                f"Available classes: {', '.join(VECTORIZERS_DICT.keys())}."
            )

    def _get_sklearn_preprocessor(self) -> BaseEstimator:
        if self.sklearn_preprocessor_cls in SKLEARN_PREPROCESSOR_DICT:
            return SKLEARN_PREPROCESSOR_DICT[self.sklearn_preprocessor_cls](
                **self.sklearn_preprocessor_kwargs
            )
        else:
            raise ValueError(
                f"Sklearn Preprocessor class {self.sklearn_preprocessor_cls} is not available. "
                f"Available classes: {', '.join(SKLEARN_PREPROCESSOR_DICT.keys())}."
            )


class SklearnModel(_BaseSklearnModel):
    """This would be more appropriately named SingleLabelSklearnModel since it only handles that LabelSpace type, but left as SklearnModel to remain backcompat."""

    label_space_cls_name = "SingleLabelSpace"

    def _get_trained_model(self) -> TrainedSklearnModel:
        assert self.vectorizer  # Created at train which base class ensures already run.
        return TrainedSklearnModel(
            model=self.model,
            vectorizer=self.vectorizer,
            sklearn_preprocessor=self.sklearn_preprocessor,
            fields=self.fields,
            decision_threshold=self.decision_threshold,
            use_lf_labels=self.use_lf_labels,
            n_classes=self.n_classes,
            prob_idx_to_label_int=self.prob_idx_to_label_int,
        )

    def _preprocess_labels(self, Y: np.ndarray) -> np.ndarray:
        """No-op on Y, simply stores the self.prob_idx_to_label_int if necessary."""
        unique_labels = np.unique(Y)  # unique_labels is sorted in ascending order
        assert all(
            unique_labels[i] <= unique_labels[i + 1]
            for i in range(len(unique_labels) - 1)
        )
        if len(unique_labels) < self.n_classes:
            self.prob_idx_to_label_int = {
                int(i): int(label) for i, label in enumerate(unique_labels)
            }
            Y_processed = np.zeros(shape=Y.shape, dtype=Y.dtype)
            logger.info(
                f"Found fewer unique labels than classes. Remapping {self.prob_idx_to_label_int}"
            )
            for idx, label in self.prob_idx_to_label_int.items():
                Y_processed[Y == label] = idx
        else:
            self.prob_idx_to_label_int = None
            logger.info(f"Skipping remapping prob idxs to labels.")
            Y_processed = Y
        return Y_processed

    def _generate_weighted_samples(
        self, X: sp.sparse.csr_matrix, Y: np.ndarray
    ) -> Tuple[sp.sparse.csr_matrix, np.ndarray, np.ndarray]:
        X_augmented: sp.sparse.csr_matrix = []
        Y_augmented: List[int] = []
        sample_weight: List[float] = []
        X_augmented_list: List[sp.sparse.csr_matrix] = [X_augmented]
        logger.info("Generating weighted samples...")
        for row, probs in zip(X.tocsr(), Y):
            for label, prob_label in enumerate(probs):
                if prob_label > 0:
                    X_augmented_list.append(row)
                    Y_augmented.append(label)
                    sample_weight.append(prob_label)
        X_augmented = sp.sparse.vstack(X_augmented_list)
        logger.info("Weighted samples generated!")
        return (
            X_augmented.tocsr()[1:, :],
            np.array(Y_augmented),
            np.array(sample_weight),
        )


class MultiLabelSklearnModel(_BaseSklearnModel):
    label_space_cls_name = "MultiLabelSpace"

    def __init__(self, model_config: ModelTrainingConfig) -> None:
        """
        Initialize class for all sklearn-based models. Currently, `n`-class
        multilabel end models are `n` binary models, so the high cardinality
        check is disabled.
        """
        super().__init__(model_config, check_high_cardinality=False)
        n_jobs = self.model_config.options.get("n_jobs", None)
        self.model = MultiOutputClassifier(self.model, n_jobs=n_jobs)

    def _get_trained_model(self) -> TrainedMultiLabelSklearnModel:
        assert self.vectorizer  # Created at train which base class ensures already run.
        return TrainedMultiLabelSklearnModel(
            model=self.model,
            vectorizer=self.vectorizer,
            sklearn_preprocessor=self.sklearn_preprocessor,
            fields=self.fields,
            decision_threshold=self.decision_threshold,
            use_lf_labels=self.use_lf_labels,
            n_classes=self.n_classes,
            prob_idx_to_label_int=self.prob_idx_to_label_int,
            invalid_class_default_prob=self.invalid_class_default_prob,
        )

    def _preprocess_labels(self, Y: Any) -> np.ndarray:
        """Conversion of raw label format to an sklearn-compatible format."""
        Y_dense = np.zeros((len(Y), self.n_classes)).astype(int)
        for example_idx, example in enumerate(Y):
            for class_int in range(self.n_classes):
                Y_dense[example_idx][class_int] = example.get(
                    str(class_int), example["_default"]
                )

        valid_class_ints = []
        # Store labels for classes we can't train a model on.
        # - All 1/-1 => always predict 1 for this class.
        # - All 0/-1 => always predict 0 for this class.
        # - All -1 => always predict 0 for this class.
        # TODO: Allow passing in GT and use that to estimate a predicted label for the all -1 case.

        for class_int in range(self.n_classes):
            class_presence_ints = set(Y_dense[:, class_int])
            if class_presence_ints.issubset({-1, 0}):
                self.invalid_class_default_prob[class_int] = 0.0
            elif class_presence_ints.issubset({-1, 1}):
                self.invalid_class_default_prob[class_int] = 1.0
            elif class_presence_ints.issubset({-1}):
                self.invalid_class_default_prob[
                    class_int
                ] = 0.499  # Forces all negative preds.
            else:
                valid_class_ints.append(class_int)

        self.prob_idx_to_label_int = {
            int(idx): int(class_int) for idx, class_int in enumerate(valid_class_ints)
        }
        return Y_dense[:, valid_class_ints]

    def _generate_weighted_samples(
        self, X: sp.sparse.csr_matrix, Y: np.ndarray
    ) -> Tuple[sp.sparse.csr_matrix, np.ndarray, np.ndarray]:
        raise NotImplementedError
