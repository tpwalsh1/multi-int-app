"""This is a custom implementation of sklearn.MultiOutputClassifier.

We need this custom code because we will be passing -1 (abstain) labels
within y. On a per-class level the model should not train on these examples.

Examples
--------
x_uid_1: {class_1: 1, class_2: 1}
x_uid_2: {class_1: 0, class_2: 0}
x_uid_3: {class_1: -1, class_2: 1}

We train n-binary models where,
the class_1 model is trained on just x_uid_1 and x_uid_2, but
the class_2 model can train on all 3 examples.

We should not pass data for classes where we do not have both 0 examples and 1 examples,
since the model will not be able to learn anything.
"""
import traceback
from abc import ABCMeta, abstractmethod
from pickle import PicklingError
from typing import Any, Callable, Iterable, List, Optional, Union

import numpy as np
import pandas as pd
from joblib import Parallel, delayed  # type: ignore
from scipy.sparse import coo_matrix
from sklearn.base import BaseEstimator, ClassifierMixin, MetaEstimatorMixin, clone
from sklearn.utils.validation import (
    _check_fit_params,
    check_is_fitted,
    has_fit_parameter,
)

from api_utils.exceptions import SnorkelException
from snorkelflow.utils.logging import get_logger

logger = get_logger("MultiOutputClassifier")


class _CustomMultiOutputEstimator(MetaEstimatorMixin, BaseEstimator, metaclass=ABCMeta):
    @abstractmethod
    def __init__(
        self, estimator: BaseEstimator, *, n_jobs: Optional[int] = None
    ) -> None:
        self.estimator = estimator
        self.n_jobs = n_jobs

    def fit(
        self,
        X: Union[Iterable, coo_matrix],
        y: np.ndarray,
        sample_weight: Any = None,
        **fit_params: Any,
    ) -> None:
        """Fit the model to data.

        Fit a separate model for each output variable.
        Parameters
        ----------
        X : np.ndarray of shape (n_samples, n_features)
            Data.
        y : List of np.ndarrays of shape (n_samples, n_outputs).
            Values should be in {-1, 0, 1}.
        **fit_params : dict of string -> object
            Parameters passed to the ``estimator.fit`` method of each step.
        Returns
        -------
        self : object
        """
        if not hasattr(self.estimator, "fit"):
            raise ValueError("The base estimator should implement" " a fit method")
        if sample_weight is not None and not has_fit_parameter(
            self.estimator, "sample_weight"
        ):
            raise ValueError("Underlying estimator does not support" " sample weights.")
        fit_params_validated = _check_fit_params(X, fit_params)
        num_classes = y.shape[1]
        X = coo_matrix(X)  # if not already sparse, make it sparse.

        # Parallelizing on dataset greater than 1M datapoints causes OOMs currently, disable it using n_jobs=1.
        if X.shape[0] > 500_000:
            logger.warn(
                "Received a model training request with {X.shape[0]} datapoints and n_jobs={self.n_jobs}. Falling back to n_jobs=1"
            )
            self.n_jobs = 1

        # Assume:
        # y = [[1, 1, 1], [0, 0, -1], [-1, -1, 0]]
        valid_examples = np.argwhere(y != -1)
        # This returns 2 col matrix where each row contains (example_idx, class_int).
        # valid_examples == [[0, 0], [0, 1], [0, 2], [1, 0], [1, 1], [2, 2]]
        # We get the valid examples per class with valid_examples[valid_examples[:, 1] == class_int][:, 0]
        # e.g. class_2_valid_examples = valid_examples[valid_examples[:, 1] == 2][:, 0]
        # class_2_valid_examples == [0, 2]
        per_class_valid_examples = [
            valid_examples[valid_examples[:, 1] == class_int][:, 0]
            for class_int in range(num_classes)
        ]
        try:
            X_csr = X.tocsr()
            self.estimators_ = Parallel(n_jobs=self.n_jobs)(
                delayed(self._fit_estimator)(
                    self.estimator,
                    X_csr[per_class_valid_examples[class_int]],
                    y[:, class_int][per_class_valid_examples[class_int]],
                    sample_weight,
                    **fit_params_validated,
                )
                for class_int in range(num_classes)
            )
        except PicklingError as exp:
            no_space_msg = "No space left on device"
            exp_str = traceback.format_exc()
            if no_space_msg in exp_str:
                raise SnorkelException(
                    detail="Memory map for joblib Parallel larger than size of /dev/shm.",
                    user_friendly_message="Model training allocating more memory than available. Try again by setting n_jobs to 1 in model options.",
                )
            raise exp
        return

    @staticmethod
    def _fit_estimator(
        estimator: BaseEstimator,
        X: np.ndarray,
        y: np.ndarray,
        sample_weight: Optional[np.ndarray] = None,
        **fit_params: Any,
    ) -> BaseEstimator:
        estimator = clone(estimator)
        if sample_weight is not None:
            estimator.fit(X, y, sample_weight=sample_weight, **fit_params)
        else:
            estimator.fit(X, y, **fit_params)
        return estimator

    def predict(self, X: np.ndarray) -> np.ndarray:
        """Predict multi-output variable using a model trained for each target variable.

        Parameters
        ----------
        X : np.ndarray of shape (n_samples, n_features)
            Data.
        Returns
        -------
        y : np.ndarray of shape (n_samples, n_outputs)
            Multi-output targets predicted across multiple predictors.
            Note: Separate models are generated for each predictor.
        """
        check_is_fitted(self)
        if not hasattr(self.estimators_[0], "predict"):
            raise ValueError("The base estimator should implement" " a predict method")

        y = Parallel(n_jobs=self.n_jobs)(
            delayed(e.predict)(X) for e in self.estimators_
        )
        return np.asarray(y).T


class _DecisionFunctionMixin(_CustomMultiOutputEstimator):
    @property
    def decision_function(self) -> Callable:
        check_is_fitted(self)
        if not all(
            [hasattr(estimator, "decision_function") for estimator in self.estimators_]
        ):
            raise AttributeError(
                "The base estimator should implement decision_function method"
            )
        return self._decision_function

    def _decision_function(self, X: pd.DataFrame) -> List[np.ndarray]:
        results = [estimator.decision_function(X) for estimator in self.estimators_]
        return results


class MultiOutputClassifier(ClassifierMixin, _DecisionFunctionMixin):
    """Multi target classification.

    This strategy consists of fitting one classifier per target. This is a
    simple strategy for extending classifiers that do not natively support
    multi-target classification.
    """

    def __init__(
        self, estimator: BaseEstimator, *, n_jobs: Optional[int] = None
    ) -> None:
        super().__init__(estimator, n_jobs=n_jobs)

    def fit(
        self,
        X: Union[Iterable, coo_matrix],
        y: np.ndarray,
        sample_weight: Any = None,
        **fit_params: Any,
    ) -> None:
        """Fit the model to data matrix X and targets Y.

        Fit a separate model for each output variable.
        Parameters
        ----------
        X : {array-like, sparse matrix} of shape (n_samples, n_features)
            Data.
        y : np.ndarray of shape (n_samples, n_outputs).
            Values should be in {-1, 0, 1}.
        **fit_params : dict of string -> object
            Parameters passed to the ``estimator.fit`` method of each step.
        Returns
        -------
        self : object
        """
        super().fit(X, y, sample_weight, **fit_params)
        self.classes_ = [estimator.classes_ for estimator in self.estimators_]
        return

    @property
    def predict_proba(self) -> Callable:
        """Probability estimates.

        Returns prediction probabilities for each class of each output.
        This method will raise a ``ValueError`` if any of the
        estimators do not have ``predict_proba``.
        """
        check_is_fitted(self)
        if not all(
            [hasattr(estimator, "predict_proba") for estimator in self.estimators_]
        ):
            raise AttributeError(
                "The base estimator should implement predict_proba method"
            )
        return self._predict_proba

    def _predict_proba(self, X: pd.DataFrame) -> List[np.ndarray]:
        results = [estimator.predict_proba(X) for estimator in self.estimators_]
        return results

    def score(self, X: pd.DataFrame, y: np.ndarray) -> None:
        raise NotImplementedError
