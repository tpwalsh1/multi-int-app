"""A separate module to keep sklearn models (and mlflow_requirements.txt) from requiring new 3rd party imports."""
from typing import Any, Dict, List

import numpy as np
import pandas as pd
import torch
from transformers import AutoTokenizer, TrainerCallback

from api_utils.exceptions import UserInputError
from snorkelflow.extraction.span import SpanCols
from snorkelflow.models.utils import START_TRAINING_PCT
from snorkelflow.rich_docs import BOTTOM, LEFT, RIGHT, TEXT, TOP, RichDocCols
from snorkelflow.rich_docs.rich_doc_utils import normalize_bbox
from snorkelflow.utils.logging import get_logger

logger = get_logger("Models")


class Dataset(torch.utils.data.Dataset):
    def __init__(self, encodings: Dict, labels: List):
        self.encodings = encodings
        self.labels = labels

    def __getitem__(self, idx: int) -> Dict:
        item = {key: torch.tensor(val[idx]) for key, val in self.encodings.items()}
        item["labels"] = self.labels[idx]
        return item

    def __len__(self) -> int:
        return len(self.labels)


class LayoutLMDataset(torch.utils.data.Dataset):
    def __init__(self, encodings: List, labels: np.ndarray):
        self.encodings = encodings
        self.labels = labels

    def __getitem__(self, idx: int) -> Dict:
        item = {key: torch.tensor(val) for key, val in self.encodings[idx].items()}
        item["labels"] = self.labels[idx]
        return item

    def __len__(self) -> int:
        return len(self.labels)


class TrainStepCallback(TrainerCallback):
    def __init__(self, status_handler: Any):
        self._status_handler = status_handler
        self._progress_percent = START_TRAINING_PCT

    def on_step_end(self, args, state, control, **kwargs) -> None:  # type: ignore
        self._status_handler.update_step_status(
            step_number=state.global_step, total_steps=state.max_steps
        )


def get_layoutlm_model_encodings(
    df: pd.DataFrame,
    fields: List[str],
    tokenizer: AutoTokenizer,
    max_seq_length: int,
    token_level: bool = True,
) -> List[Dict[str, torch.tensor]]:
    """Generate features for LayoutLMDataset and uses bbox features from
    span_text and its associated RichDoc object.
    """

    def _check_required_cols(cols: List[str], req_cols: List[str]) -> None:
        if not all(x in cols for x in req_cols):
            missing_cols = set(req_cols).difference(set(cols))
            raise UserInputError(
                detail=f"Missing LayoutLM columns: {missing_cols}",
                user_friendly_message=f"Missing LayoutLM columns: {missing_cols}",
                how_to_fix=f"Add {missing_cols} to Input Fields",
            )

    def get_token_encodings(
        record: pd.Series, tokenizer: AutoTokenizer, max_seq_length: int
    ) -> Dict:
        text = record[SpanCols.SPAN_TEXT]
        encoding = tokenizer(
            text, max_length=max_seq_length, padding="max_length", truncation=True
        )
        rd = record[RichDocCols.DOC_COL]
        page_width = max(rd.pages[RIGHT].iloc[0], rd.words[RIGHT].max())
        page_height = max(rd.pages[BOTTOM].iloc[0], rd.words[BOTTOM].max())
        normalized_bbox = normalize_bbox(
            record[TOP],
            record[LEFT],
            record[RIGHT],
            record[BOTTOM],
            page_height,
            page_width,
        )
        num_attention_tokens = sum(encoding["attention_mask"])
        num_real_tokens = num_attention_tokens - 2
        num_pad_tokens = max_seq_length - num_attention_tokens
        encoding["bbox"] = (
            [[0, 0, 0, 0]]
            + [normalized_bbox] * num_real_tokens
            + [[1000, 1000, 1000, 1000]]
            + [[0, 0, 0, 0]] * num_pad_tokens
        )

        return encoding

    def get_page_encodings(
        record: pd.Series, tokenizer: AutoTokenizer, max_seq_length: int
    ) -> Dict:
        page_docs = record[RichDocCols.PAGE_DOCS]
        encodings: Dict[str, Any] = {
            "input_ids": [],
            "token_type_ids": [],
            "attention_mask": [],
            "bbox": [],
        }
        for idx in range(len(page_docs)):
            rd = page_docs[idx]
            page_width = max(rd.pages[RIGHT].iloc[0], rd.words[RIGHT].max())
            page_height = max(rd.pages[BOTTOM].iloc[0], rd.words[BOTTOM].max())
            token_boxes = []
            token_words = []
            for _, word in rd.words.iterrows():
                word_tokens = tokenizer.tokenize(word[TEXT])
                normalized_bbox = normalize_bbox(
                    word[TOP],
                    word[LEFT],
                    word[RIGHT],
                    word[BOTTOM],
                    page_height,
                    page_width,
                )
                token_words.append(word[TEXT])
                token_boxes.extend([normalized_bbox] * len(word_tokens))
            page_encoding = tokenizer(
                " ".join(token_words),
                max_length=max_seq_length,
                padding="max_length",
                truncation=True,
            )
            num_attention_tokens = sum(page_encoding["attention_mask"])
            num_real_tokens = num_attention_tokens - 2
            num_pad_tokens = max_seq_length - num_attention_tokens
            encodings["bbox"] += [
                (
                    [[0, 0, 0, 0]]
                    + token_boxes[:num_real_tokens]
                    + [[1000, 1000, 1000, 1000]]
                    + [[0, 0, 0, 0]] * num_pad_tokens
                )
            ]

            for k in ["input_ids", "token_type_ids", "attention_mask"]:
                encodings[k] += [page_encoding[k]]
        return encodings

    if token_level:
        _check_required_cols(
            fields, [SpanCols.SPAN_TEXT, RichDocCols.DOC_COL, LEFT, TOP, RIGHT, BOTTOM]
        )
        encodings_list = df.apply(
            lambda x: get_token_encodings(x, tokenizer, max_seq_length), axis=1
        ).tolist()
    else:
        _check_required_cols(fields, [RichDocCols.PAGE_DOCS])
        doc_encodings_list = df.apply(
            lambda x: get_page_encodings(x, tokenizer, max_seq_length), axis=1
        ).tolist()
        # Flatten list to be per page
        encodings_list = []
        for doc_id, doc_enc in enumerate(doc_encodings_list):
            for page_id in range(len(doc_enc["input_ids"])):
                enc: Dict[str, Any] = {
                    "input_ids": doc_enc["input_ids"][page_id],
                    "token_type_ids": doc_enc["token_type_ids"][page_id],
                    "attention_mask": doc_enc["attention_mask"][page_id],
                    "bbox": doc_enc["bbox"][page_id],
                    "doc_id": doc_id,
                }
                encodings_list.append(enc)
    return encodings_list
