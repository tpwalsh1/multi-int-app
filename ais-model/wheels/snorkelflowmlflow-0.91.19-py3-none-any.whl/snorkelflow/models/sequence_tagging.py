"""Training models for SequenceTagging tasks."""
import os
import pathlib
import random
import urllib.parse
from typing import Any, Dict, List, Optional, Tuple, Union

import numpy as np
import pandas as pd
import torch
from transformers import (
    AutoModelForTokenClassification,
    AutoTokenizer,
    DataCollatorForTokenClassification,
    Trainer,
    TrainingArguments,
)
from transformers.modeling_utils import PreTrainedModel
from transformers.tokenization_utils import PreTrainedTokenizer

from api_utils.exceptions import SnorkelException
from file_utils.core import open_file
from snorkelflow.models.cls_model import (
    BaseManifest,
    ClassificationModelV2,
    TrainedClassificationModelV2,
)
from snorkelflow.models.model_configs import HFCacheSettings, ModelTrainingConfig
from snorkelflow.models.special_utils import Dataset, TrainStepCallback
from snorkelflow.models.utils import (
    MODEL_CONFIG_OPTION_FIELDS,
    MODEL_CONFIG_OPTION_N_CLASSES,
    MODEL_CONFIG_OPTION_USE_LF_LABELS,
    START_FEATURIZATION_PCT,
    START_TRAINING_PCT,
    MockStatusHandler,
    get_decision_threshold,
    preprocess_document_df,
)
from snorkelflow.utils.logging import get_logger
from snorkelflow.utils.system import is_gpu_available

IGNORE_INDEX = -100

logger = get_logger("Models")


class TrainedSequenceTaggingModel(TrainedClassificationModelV2):
    def __init__(
        self,
        model: "PreTrainedModel",
        tokenizer: "PreTrainedTokenizer",
        pretrained_model_name: str,
        seq_task_field: str,
        max_sequence_length: int,
        stride_length: int,
        predict_batch_size: int,
        predict_num_docs: int,
        decision_threshold: Optional[float],
    ) -> None:
        self.model = model
        self.tokenizer = tokenizer
        self.pretrained_model_name = pretrained_model_name
        self.seq_task_field = seq_task_field
        self.max_sequence_length = max_sequence_length
        self.stride_length = stride_length
        self.predict_batch_size = predict_batch_size
        self.predict_num_docs = predict_num_docs
        self.decision_threshold = decision_threshold

    def _postprocess_model_outputs(
        self, model_outputs: torch.Tensor, model_offsets: List[torch.Tensor]
    ) -> Tuple[List, List]:
        preds = []
        probs = []
        current_pred_span = None
        current_prob_span = None
        # NOTE: This assumes the tokens for model predictions and offsets
        # are sorted and represent consecutive neighboring tokens, which they
        # do in the HuggingFace libraries we support
        model_softmax = (
            torch.nn.functional.softmax(model_outputs, dim=1).float().tolist()
        )
        model_argmax = torch.argmax(model_outputs, dim=1).tolist()
        for i in range(len(model_offsets)):
            off = model_offsets[i]
            if off[1] - off[0] == 0:
                continue  # [CLS] or [PAD] token
            char_start, char_end = off[0], off[1]
            token_probs = model_softmax[i]
            if self.decision_threshold is not None:
                token_pred = int(token_probs[1] >= self.decision_threshold)
            else:
                token_pred = model_argmax[i]
            if current_pred_span is not None and current_prob_span is not None:
                # NOTE: For the span, we keep the probability of the first token
                # Offsets should be sorted in increasing order
                if char_start < current_pred_span[1]:
                    # Tokenizers can return overlapping offsets, either because they're buggy
                    # or because the document contains tokens that aren't supported. In this case,
                    # drop the second one.
                    logger.warn("Dropping a token as it overlaps with a previous one")
                    continue
                if current_pred_span[2] == token_pred:
                    # Extend the current span
                    current_pred_span[1] = char_end
                    current_prob_span[1] = char_end
                    continue
                preds.append(current_pred_span)
                probs.append(current_prob_span)
            current_pred_span = [char_start, char_end, token_pred]
            current_prob_span = [char_start, char_end, token_probs]
        if current_pred_span is not None and current_prob_span is not None:
            # Append the last span
            preds.append(current_pred_span)
            probs.append(current_prob_span)
        return preds, probs

    def predict(self, df: pd.DataFrame) -> Tuple[np.ndarray, np.ndarray]:
        with torch.no_grad():
            self.model.eval()
            device = torch.device("cuda" if is_gpu_available() else "cpu")
            self.model.to(device)
            logger.info(f"***** Running predict for {self.pretrained_model_name} *****")
            all_preds, all_probs = [], []
            df = preprocess_document_df(df, self.seq_task_field)
            docs = df[self.seq_task_field].tolist()
            # predict_num_docs controls the number of docs we predict on at a time
            # This roughly correlates with CPU memory, since we need to keep predictions for
            # all docs in memory to aggregate across subsequences
            doc_batches = self._make_batches(docs, self.predict_num_docs)
            total_doc_batches = len(doc_batches)
            for doc_batch_num, docs_batch in enumerate(doc_batches):
                logger.info(
                    f"Predicting on doc batch {doc_batch_num} / {total_doc_batches}"
                )
                doc_batch_inputs = self.tokenizer(
                    docs_batch,
                    return_tensors="pt",
                    max_length=self.max_sequence_length,
                    padding="longest",
                    truncation="longest_first",
                    stride=self.stride_length,
                    return_overflowing_tokens=True,
                    return_offsets_mapping=True,
                )
                # Predict batch size controls the size of the predict batch we use for model inference
                # This roughly correlates with GPU memory
                doc_batch_logits = []
                model_batches = self._make_batches(
                    doc_batch_inputs["input_ids"], self.predict_batch_size
                )
                for model_batch in model_batches:
                    doc_batch_logits.extend(self.model(model_batch.to(device)).logits)
                doc_batch_logits = torch.stack(doc_batch_logits)
                overflow_to_subsequence_mapping = doc_batch_inputs[
                    "overflow_to_sample_mapping"
                ]
                for doc_idx in range(len(docs_batch)):
                    subsequence_mapping = torch.where(
                        overflow_to_subsequence_mapping == doc_idx
                    )[0]
                    # Gives us all subsequences which belong to doc_idx.
                    doc_logits = doc_batch_logits[subsequence_mapping]
                    doc_offset_mapping = doc_batch_inputs["offset_mapping"][
                        subsequence_mapping
                    ]
                    doc_token_info: Dict[tuple, tuple] = dict()
                    # Key, tuple: token offset within that doc, e.g. (15, 28)
                    # Values, tuple: (minimum context length, token logits)
                    for subsequence_logits, subsequence_offset_mapping in zip(
                        doc_logits, doc_offset_mapping
                    ):
                        for token_logits, token_offset in zip(
                            subsequence_logits, subsequence_offset_mapping
                        ):
                            # A single token can be in multiple subsequences because of striding.
                            # We take the prediction of the token with the most context.
                            # NOTE: Need to convert from pytorch tensor to tuple, so that offsets
                            # with the same char_start and char_end hash to each other in doc_token_info
                            token_offset = tuple(token_offset.tolist())
                            context_char_start = subsequence_offset_mapping[0][0]
                            context_char_end = subsequence_offset_mapping[-1][1]
                            min_context = min(
                                token_offset[0] - context_char_start,
                                context_char_end - token_offset[1],
                            )
                            if token_offset not in doc_token_info:
                                doc_token_info[token_offset] = (
                                    min_context,
                                    token_logits,
                                )
                                continue

                            prev_min_context = doc_token_info[token_offset][0]
                            if min_context > prev_min_context:
                                doc_token_info[token_offset] = (
                                    min_context,
                                    token_logits,
                                )

                    # These will be ordered on char_start since insertion order is preserved.
                    logits = torch.stack(
                        [token_logits for (_, token_logits) in doc_token_info.values()]
                    )
                    offset_mapping = list(doc_token_info.keys())

                    preds, probs = self._postprocess_model_outputs(
                        logits, offset_mapping
                    )
                    if preds == []:
                        # No real word tokens found.
                        preds = [[0, 1, 0]]
                        # the shape of doc_logits is (number of batches, batch size, number of classes)
                        n_classes = doc_logits.shape[2]
                        probs = [[0, 1, [1 / n_classes] * n_classes]]
                    all_preds.append(preds)
                    all_probs.append(probs)
            return np.array(all_preds), np.array(all_probs)

    class Manifest(BaseManifest):
        model: Optional[str]
        tokenizer: Optional[str]
        pretrained_model_name: Optional[str]
        max_sequence_length: Optional[int]
        seq_task_field: Optional[str]
        predict_batch_size: Optional[int]
        predict_num_docs: Optional[int]
        stride_length: Optional[int]
        decision_threshold: Optional[float]

    def save(self, dirpath: pathlib.Path) -> None:
        m = self.Manifest(
            type=self.__class__.__name__, model_fields=[self.seq_task_field]
        )
        # Save model
        model_dirname = "model"
        model_dirpath = dirpath / model_dirname
        model_dirpath.mkdir(parents=True)
        self.model.save_pretrained(str(model_dirpath), safe_serialization=False)
        m.model = model_dirname
        # Save tokenizer
        self.tokenizer.save_pretrained(str(model_dirpath))
        m.tokenizer = model_dirname
        m.pretrained_model_name = self.pretrained_model_name
        m.max_sequence_length = self.max_sequence_length
        m.seq_task_field = self.seq_task_field
        m.predict_batch_size = self.predict_batch_size
        m.predict_num_docs = self.predict_num_docs
        m.stride_length = self.stride_length
        m.decision_threshold = self.decision_threshold
        # Write manifest to disk
        with open(dirpath / "manifest.json", "w+") as mf:
            mf.write(m.json())

    @classmethod
    def load(
        cls, dirpath: str, storage_options: Optional[Dict[str, Any]] = None
    ) -> "TrainedSequenceTaggingModel":
        # Read the manifest
        storage_options = storage_options or {}
        manifest_path = os.path.join(dirpath, "manifest.json")
        with open_file(manifest_path, **storage_options) as mf:
            m = cls.Manifest.parse_raw(mf.read())
        # Load Transformer model
        assert m.model  # for mypy
        model_path = os.path.join(dirpath, m.model)
        if not urllib.parse.urlparse(model_path).scheme:
            model = AutoModelForTokenClassification.from_pretrained(model_path)
        else:
            raise ValueError(
                f"Can only load local Transformer models, got {model_path}"
            )
        # Load Transformer tokenizer
        assert m.tokenizer  # for mypy
        tokenizer_path = os.path.join(dirpath, m.tokenizer)
        if not urllib.parse.urlparse(tokenizer_path).scheme:
            tokenizer = AutoTokenizer.from_pretrained(
                tokenizer_path, cache_dir=HFCacheSettings.PRETRAINED_CACHE_DIR
            )
        else:
            raise ValueError(
                f"Can only load local Transformer tokenizers, got {tokenizer_path}"
            )
        # Construct the TrainedModel
        assert m.pretrained_model_name  # for mypy
        assert m.seq_task_field  # for mypy
        assert m.max_sequence_length  # for mypy
        assert m.predict_batch_size  # for mypy
        assert m.stride_length  # for mypy
        assert m.model_fields  # for mypy
        assert m.predict_num_docs  # for mypy
        return cls(
            model=model,
            tokenizer=tokenizer,
            pretrained_model_name=m.pretrained_model_name,
            max_sequence_length=m.max_sequence_length,
            seq_task_field=m.seq_task_field,
            predict_batch_size=m.predict_batch_size,
            predict_num_docs=m.predict_num_docs,
            stride_length=m.stride_length,
            decision_threshold=m.decision_threshold,
        )


class SequenceTaggingModel(ClassificationModelV2):
    label_space_cls_name = "SequenceLabelSpace"

    def __init__(self, model_config: ModelTrainingConfig) -> None:
        super().__init__(model_config)
        if self.model_config.options[MODEL_CONFIG_OPTION_USE_LF_LABELS]:
            raise ValueError(
                "LF labels features are not yet available for Sequence models"
            )
        # Parse model config
        self.pretrained_model_name = self.model_config.options["pretrained_model_name"]
        self.revision = self.model_config.options.get("revision", "main")
        self.seq_task_field = self.model_config.options[MODEL_CONFIG_OPTION_FIELDS][0]
        self.train_batch_size = self.model_config.options.get("train_batch_size", 16)
        self.predict_batch_size = self.model_config.options.get(
            "predict_batch_size", 16
        )
        self.predict_num_docs = self.model_config.options.get("predict_num_docs", 256)
        self.num_train_epochs = self.model_config.options.get("num_train_epochs", 3)
        self.max_sequence_length = self.model_config.options.get(
            "max_sequence_length", 128
        )
        self.stride_length = self.model_config.options.get("stride_length", 4)
        self.stride_length = min(self.stride_length, self.max_sequence_length - 2)
        self.model_checkpoint_dir = self.model_config.options.get(
            "model_checkpoint_dir", HFCacheSettings.default_model_checkpoint_dir()
        )
        self.learning_rate = self.model_config.options.get("learning_rate", 2e-5)
        self.tokenizer = AutoTokenizer.from_pretrained(
            self.pretrained_model_name,
            revision=self.revision,
            cache_dir=HFCacheSettings.PRETRAINED_CACHE_DIR,
            add_prefix_space=self.model_config.options.get("add_prefix_space", False),
        )
        self.device = torch.device("cuda" if is_gpu_available() else "cpu")
        self.num_labels = self.model_config.options[MODEL_CONFIG_OPTION_N_CLASSES]
        class_weights_dict = self.model_config.options.get(
            "class_weights", {str(i): 1 for i in range(self.num_labels)}
        )
        self.class_weights = torch.tensor(
            [class_weights_dict.get(str(i), 1) for i in range(self.num_labels)]
        ).to(self.device)
        self.torch_manual_seed = self.model_config.options.get("torch_manual_seed", 123)
        self.label_smoothing_regularization = self.model_config.options[
            "label_smoothing_regularization"
        ]
        self.fraction_of_negative_subsequences_to_use_for_training = (
            self.model_config.options.get(
                "fraction_of_negative_subsequences_to_use_for_training", 0.0
            )
        )
        if (
            self.fraction_of_negative_subsequences_to_use_for_training < 0
            or self.fraction_of_negative_subsequences_to_use_for_training > 1.0
        ):
            raise ValueError(
                "fraction_of_negative_subsequences_to_use_for_training input should be between [0, 1]"
            )
        # Note: You are not guaranteed to get the same results across devices.
        torch.manual_seed(self.torch_manual_seed)
        torch.cuda.manual_seed(self.torch_manual_seed)
        # Set the random seed before loading the model or you will not reproduce weight init.
        self.model = AutoModelForTokenClassification.from_pretrained(
            self.pretrained_model_name,
            revision=self.revision,
            cache_dir=HFCacheSettings.PRETRAINED_CACHE_DIR,
            num_labels=self.num_labels,
        )
        self.model.to(self.device)
        self.decision_threshold = get_decision_threshold(self.model_config)

    class CustomLossTrainer(Trainer):
        def __init__(
            self,
            class_weights: torch.Tensor,
            label_smoothing_regularization: int,
            **kwargs: Dict[str, Any],
        ) -> None:
            self._class_weights = class_weights
            self._label_smoothing_regularization = label_smoothing_regularization
            super().__init__(**kwargs)

        def compute_loss(
            self, model: PreTrainedModel, inputs: Dict, return_outputs: bool = False
        ) -> Union[Tuple, float]:
            # This overrides the default compute_loss found on HF's Trainer.
            labels = inputs.pop("labels")
            try:
                outputs = model(**inputs)
            except Exception as e:
                if "out of memory" in str(e).lower():
                    err_msg = f"{str(e)}. Try reducing the train_batch_size parameter in model options"
                    raise SnorkelException(
                        detail=err_msg, user_friendly_message=err_msg
                    )
                else:
                    raise e from None

            if self.args.past_index >= 0:
                self._past = outputs[self.args.past_index]

            loss = self._label_smoother(outputs, labels)
            return (loss, outputs) if return_outputs else loss

        def _label_smoother(
            self, model_output: torch.Tensor, labels: torch.Tensor
        ) -> float:
            # This is adapted from huggingface.co/transformers/_modules/transformers/trainer_pt_utils.html.
            logits = model_output[0]

            log_probs = -torch.nn.functional.log_softmax(logits, dim=-1)
            if labels.dim() == log_probs.dim() - 1:
                labels = labels.unsqueeze(-1)

            padding_mask = labels.eq(IGNORE_INDEX)
            # If IGNORE_INDEX is -100, the gather will fail, so we replace labels by 0. The padding_mask
            # will be ignored in any case.
            labels.clamp_min_(0)

            flat_labels = labels.view(-1)
            num_inactive_elements = padding_mask.long().sum()
            num_active_elements = padding_mask.numel() - num_inactive_elements

            nll_loss = log_probs.gather(dim=-1, index=labels).view(-1) * torch.gather(
                self._class_weights, 0, flat_labels
            )
            smoothed_loss = log_probs.sum(dim=-1, keepdim=True)
            nll_loss.masked_fill_(padding_mask.view(-1), 0.0)
            smoothed_loss.masked_fill_(padding_mask, 0.0)

            # Take the mean over the label dimensions, then divide by the number of active elements (i.e. not-padded):
            num_active_elements = padding_mask.numel() - padding_mask.long().sum()
            nll_loss = nll_loss.sum() / num_active_elements
            smoothed_loss = smoothed_loss.sum() / (
                num_active_elements * log_probs.shape[-1]
            )
            return (
                1 - self._label_smoothing_regularization
            ) * nll_loss + self._label_smoothing_regularization * smoothed_loss

    def _train(
        self, df: pd.DataFrame, Y: np.ndarray, status_handler: Optional[Any] = None
    ) -> None:
        if not status_handler:
            status_handler = MockStatusHandler()
        status_handler.update_status(
            "Running model featurization", START_FEATURIZATION_PCT
        )
        logger.info("***** data collector *****")
        data_collator = DataCollatorForTokenClassification(self.tokenizer)

        logger.info("***** preprocess df *****")
        df = preprocess_document_df(df, self.seq_task_field)

        docs = df[self.seq_task_field].tolist()

        logger.info("***** tokenize_and_align_labels *****")
        encodings, labels = _tokenize_and_align_labels(
            docs,
            Y,
            self.tokenizer,
            self.max_sequence_length,
            self.stride_length,
            self.fraction_of_negative_subsequences_to_use_for_training,
        )
        del Y, df
        logger.info("***** Create dataset with encodings and labels *****")
        train_dataset = Dataset(encodings, labels)
        logger.info("***** Running training *****")
        logger.info("  Num examples = %d", len(docs))
        logger.info("  Num Epochs = %d", self.num_train_epochs)
        status_handler.update_status("Training model", START_TRAINING_PCT)
        status_handler.start_end_model_training()
        train_args = TrainingArguments(
            self.model_checkpoint_dir,
            fp16=True if self.device == "cuda" else False,
            learning_rate=self.learning_rate,
            per_device_train_batch_size=self.train_batch_size,
            num_train_epochs=self.num_train_epochs,
            weight_decay=0.01,
            disable_tqdm=True,
        )
        self.trainer = self.CustomLossTrainer(
            model=self.model,
            args=train_args,
            train_dataset=train_dataset,
            data_collator=data_collator,
            tokenizer=self.tokenizer,
            class_weights=self.class_weights,
            label_smoothing_regularization=self.label_smoothing_regularization,
        )
        self.trainer.callback_handler.callbacks = [TrainStepCallback(status_handler)]
        self.trainer.train()

    def _get_trained_model(self) -> TrainedSequenceTaggingModel:
        return TrainedSequenceTaggingModel(
            model=self.model,
            tokenizer=self.tokenizer,
            pretrained_model_name=self.pretrained_model_name,
            max_sequence_length=self.max_sequence_length,
            seq_task_field=self.seq_task_field,
            predict_batch_size=self.predict_batch_size,
            predict_num_docs=self.predict_num_docs,
            stride_length=self.stride_length,
            decision_threshold=self.decision_threshold,
        )


def _tokenize_and_align_labels(
    docs: List[str],
    Y: np.ndarray,
    tokenizer: PreTrainedTokenizer,
    max_length: int,
    stride_length: int,
    fraction_of_negative_subsequences_to_use_for_training: float,
) -> Tuple[Dict, List]:
    # TODO: Discretization should be handled by the TrainSampler in load_xuids_and_labels
    X_span, Y_span = _get_spans_and_discretize_labels(docs, Y)
    return _align_labels(
        X_span,
        Y_span,
        tokenizer,
        max_length,
        stride_length,
        fraction_of_negative_subsequences_to_use_for_training,
    )


def _get_spans_and_discretize_labels(docs: List, raw_labels: np.ndarray) -> Tuple:
    # Conversion from []
    X_span, Y_span = [], []
    # check if label is already discretized, then skip.
    logger.info("***** Running tokenization and label alignment *****")
    for doc, doc_labels in zip(docs, raw_labels):
        x, y = [], []
        for span_raw_label in doc_labels:
            span_char_start, span_char_end, span_label = span_raw_label
            x.append(doc[span_char_start:span_char_end])
            if type(span_label) is list:
                # Discretize from probs to ints
                span_label = (
                    IGNORE_INDEX  # Ignore UNKNOWN label tokens.
                    if np.max(span_label) == np.min(span_label)
                    else np.argmax(span_label)
                )
            y.append(span_label)
        X_span.append(x)
        Y_span.append(y)

    logger.info("***** Finished tokenization and label alignment *****")
    return X_span, Y_span


def _align_labels(
    all_docs_text_spans: List,
    all_docs_label_spans: List,
    tokenizer: "PreTrainedTokenizer",
    max_length: int,
    stride_length: int,
    fraction_of_negative_subsequences_to_use_for_training: float,
) -> Tuple[Dict, List]:
    # Align span labels to BERT tokenization.
    negative_input_ids, nonnegative_input_ids = [], []
    negative_attention_masks, nonnegative_attention_masks = [], []
    negative_tokenized_labels, nonnegative_tokenized_labels = [], []
    for text_spans, label_spans in zip(all_docs_text_spans, all_docs_label_spans):
        inputs = tokenizer(
            text_spans,
            is_split_into_words=True,  # We are actually split into spans.
            padding="max_length",
            truncation="longest_first",
            max_length=max_length,
            stride=stride_length,
            return_overflowing_tokens=True,
        )
        for j in range(len(inputs["input_ids"])):
            # A single doc will be broken into several subsequences if the doc is longer than the max sequence length.
            span_ids = inputs.word_ids(batch_index=j)
            # "word_ids" returns tokens belonging to span_ids since we passed spans to `is_split_into_words`.
            subsequence_labels = []  # Labels for a single training subsequence.
            for span_idx in span_ids:
                if (
                    span_idx
                    is None  # Any helper token that isn't a real word. CLS, SEP, etc.
                ):
                    subsequence_labels.append(IGNORE_INDEX)
                else:
                    subsequence_labels.append(label_spans[span_idx])
            # The negative label is assumed to be 0, and IGNORE_INDEX is assumed to
            # be less than 0
            contains_nonnegative_tokens = np.any(np.array(subsequence_labels) > 0)
            if contains_nonnegative_tokens:
                nonnegative_tokenized_labels.append(subsequence_labels)
                nonnegative_input_ids.append(inputs["input_ids"][j])
                nonnegative_attention_masks.append(inputs["attention_mask"][j])
            else:
                negative_tokenized_labels.append(subsequence_labels)
                negative_input_ids.append(inputs["input_ids"][j])
                negative_attention_masks.append(inputs["attention_mask"][j])
    num_of_negative_subsequences_to_include = int(
        (
            fraction_of_negative_subsequences_to_use_for_training
            * len(negative_input_ids)
        )
    )
    if num_of_negative_subsequences_to_include == 0 or len(negative_input_ids) == 0:
        return (
            {
                "input_ids": nonnegative_input_ids,
                "attention_mask": nonnegative_attention_masks,
            },
            nonnegative_tokenized_labels,
        )
    negative_input_ids, negative_attention_masks, negative_tokenized_labels = [
        [*x]
        for x in zip(
            *random.sample(
                list(
                    zip(
                        negative_input_ids,
                        negative_attention_masks,
                        negative_tokenized_labels,
                    )
                ),
                num_of_negative_subsequences_to_include,
            )
        )
    ]
    return (
        {
            "input_ids": nonnegative_input_ids + negative_input_ids,
            "attention_mask": nonnegative_attention_masks + negative_attention_masks,
        },
        nonnegative_tokenized_labels + negative_tokenized_labels,
    )
