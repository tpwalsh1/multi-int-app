"""Avoid new 3rd party imports, see special_utils.py"""
import abc
import pathlib
from typing import Any, Dict, List, Optional, Tuple, Type

import numpy as np
import pandas as pd
from pydantic import BaseModel

from snorkelflow.models.model_configs import ModelTrainingConfig

models_dict: Dict[str, Type["ClassificationModelV2"]] = {}
trained_models_dict: Dict[str, Type["TrainedClassificationModelV2"]] = {}


class BaseManifest(BaseModel):
    # All model manifest types should inherit from this base class.
    # These fields are required for various helpers.
    type: Optional[str]
    model_fields: Optional[List[str]]


class TrainedClassificationModelV2:
    def __init_subclass__(cls, **kwargs: Any) -> None:
        """Registers all subclasses in trained_models_dict."""
        super(cls).__init_subclass__(**kwargs)  # type: ignore
        trained_models_dict[cls.__name__] = cls

    @abc.abstractmethod
    def predict(self, df: pd.DataFrame) -> Tuple[np.ndarray, Optional[np.ndarray]]:
        """Predicts model output (predictions, probabilities) from input data using trained model."""

    @abc.abstractmethod
    def save(self, dirpath: pathlib.Path) -> None:
        """Saves model to disk."""

    @classmethod
    @abc.abstractmethod
    def load(
        cls, dirpath: str, storage_options: Optional[Dict[str, Any]] = None
    ) -> "TrainedClassificationModelV2":
        """Loads model from disk."""

    @staticmethod
    def _make_batches(seq: Any, size: int) -> List[Any]:
        return [seq[pos : pos + size] for pos in range(0, len(seq), size)]


class ClassificationModelV2:
    """Base class from which all classification models inherit."""

    def __init_subclass__(cls, **kwargs: Any) -> None:
        """Registers all subclasses in models_dict."""
        super(cls).__init_subclass__(**kwargs)  # type: ignore
        models_dict[cls.__name__] = cls

    def __init__(self, model_config: ModelTrainingConfig) -> None:
        """Initialize model class from model config, if specified."""
        self.model_config = model_config
        self._is_trained = False

    @abc.abstractmethod
    def _train(
        self, df: pd.DataFrame, Y: np.ndarray, status_handler: Optional[Any] = None
    ) -> None:
        pass

    def train(
        self, df: pd.DataFrame, Y: np.ndarray, status_handler: Optional[Any] = None
    ) -> None:
        """Trains model on input data and labels."""
        self._train(df, Y, status_handler)
        self._is_trained = True
        pass

    def predict(self, df: pd.DataFrame) -> Tuple[np.ndarray, Optional[np.ndarray]]:
        """Predicts model output (predictions, probabilities) from input data using trained model."""
        if not self._is_trained:
            raise TypeError("This model is not trained yet. Call 'train' first.")
        trained_model = self.get_trained_model()
        return trained_model.predict(df)

    def get_trained_model(self) -> TrainedClassificationModelV2:
        """Get corresponding TrainedClassificationModelV2 object for this model."""
        if not self._is_trained:
            raise TypeError("This model is not trained yet. Call 'train' first.")
        return self._get_trained_model()

    @abc.abstractmethod
    def _get_trained_model(self) -> TrainedClassificationModelV2:
        pass

    @property
    def label_space_cls_name(self) -> str:
        """Get label space class name that defines format for model input and output labels."""
