import abc
import gc
import os
import pickle
import time
from typing import Any, Callable, List, Optional, Tuple

import torch
from filelock import FileLock

from api_utils.config import get_env_var
from api_utils.exceptions import SnorkelException
from snorkelflow.config.constants import (
    BASE_PRETRAINED_MODEL_CACHE_DIR,
    SHARED_PRETRAINED_MODEL_CACHE_DIR,
)
from snorkelflow.models.image_data_loader import (
    ImageDataLoader,
    PatchDataLoader,
    TextDataLoader,
)
from snorkelflow.operators.featurizer import OpProgressCallback, no_op_progress_callback
from snorkelflow.utils.logging import get_logger
from snorkelflow.utils.system import is_gpu_available

logger = get_logger("image model")


if get_env_var("ENABLE_PRETRAINED_MODEL_DIRECTORY") == "True":
    CLIP_CACHE_DIR = f"{SHARED_PRETRAINED_MODEL_CACHE_DIR}/.clip-models"
else:
    CLIP_CACHE_DIR = f"{BASE_PRETRAINED_MODEL_CACHE_DIR}/.clip-models"
MODEL_LOCK = f"/tmp/clip-model-lock"
TRANSFORM_LOCK = f"/tmp/clip-transform-lock"

# This LOCK_TIMEOUT is increased because when 20 Ray Tasks that need CLIP are scheduled in parallel
# and we have a mutex here on reading the CLIP model weights, if each read takes 6 seconds, then a 60
# second timeout would cause some of these Tasks to fail.

# The simplest solution here is to increase the timeout, but better solutions that are outside the
# scope of this PR might involve:
# * Adding a sentinel file to indicate if the model weights have already been written to disk
# * Having a shorter lock timeout but retrying in a loop
# * Some sort of disk-rw-lock implementation
LOCK_TIMEOUT = 60 * 60


class CLIPModel(abc.ABC):
    backbone_configs = {"RN50x16": {"batch_size": 24}, "ViT-B/32": {"batch_size": 512}}

    def __init__(
        self,
        backbone: str = "ViT-B/32",
        batch_size: Optional[int] = None,
        device: Optional[str] = None,
        num_data_workers: int = 0,
    ):
        # When changing the backbone, increment operator_impl_version
        # for CLIPModel dependent operators to force feature store recomputation
        # e.g. ImageEmbeddingFeaturizer and EmbeddingFeaturizer
        if backbone not in self.backbone_configs:
            message = (
                f"CLIP backbone '{backbone}' not supported. "
                f"Supported backbones are '{self.backbone_configs.keys()}'"
            )
            raise SnorkelException(detail=message, user_friendly_message=message)

        if device is None:
            self.device = "cuda" if is_gpu_available() else "cpu"
        else:
            self.device = device

        if batch_size is None:
            # Ideally we dynamically figure out the largest batch we can fit in
            # memory based on the GPU memory available and the size of the data,
            # but for now we hard-code it.
            batch_size = (
                self.backbone_configs[backbone]["batch_size"]
                if self.device == "cuda"
                else 1
            )
        elif batch_size > self.backbone_configs[backbone]["batch_size"]:
            message = (
                f"Maximum batch size of '{self.backbone_configs[backbone]['batch_size']}' "
                f"for CLIP backbone '{backbone}' exceeded. Please choose a smaller batch size."
            )
            raise SnorkelException(detail=message, user_friendly_message=message)
        self.batch_size = batch_size

        self.num_data_workers = num_data_workers

        self.model, self.image_transform, self.text_tokenizer = CLIPModel.load_model(
            backbone, self.device, CLIP_CACHE_DIR
        )

    def __del__(self) -> None:
        if hasattr(self, "text_tokenizer"):
            del self.text_tokenizer
        if hasattr(self, "image_transform"):
            del self.image_transform
        if hasattr(self, "model"):
            del self.model
        gc.collect()
        if self.device == "cuda":
            torch.cuda.empty_cache()

    @staticmethod
    def load_model(
        backbone: str, device: str, download_root: str
    ) -> Tuple[Any, Callable, Callable]:
        import clip

        os.makedirs(download_root, exist_ok=True)

        backbone_path = backbone.replace("/", "-", 1).replace("@", "-", 1)
        model_path = os.path.join(download_root, f"{backbone_path}_{device}.pt")
        transform_path = os.path.join(
            download_root, f"{backbone_path}_{device}_transform.pkl"
        )

        # Load model from cache
        model_loaded = False
        if os.path.isfile(model_path) and os.path.isfile(transform_path):
            try:
                start = time.time()

                with FileLock(MODEL_LOCK, timeout=LOCK_TIMEOUT):
                    logger.info(f"File read lock '{MODEL_LOCK}' acquired")
                    model = torch.load(model_path)
                logger.info(f"File read lock '{MODEL_LOCK}' released")

                with FileLock(TRANSFORM_LOCK, timeout=LOCK_TIMEOUT), open(
                    transform_path, "rb"
                ) as f:
                    logger.info(f"File read lock '{TRANSFORM_LOCK}' acquired")
                    image_transform = pickle.load(f)
                logger.info(f"File read lock '{TRANSFORM_LOCK}' released")

                logger.info(
                    f"Loading CLIP model from cache took {time.time() - start}s."
                )
                model_loaded = True
            except RuntimeError:
                logger.warning(
                    f"Unable to load CLIP model with backbone='{backbone}' and device='{device}' from cache "
                    f"with model_path={model_path} and transform_path={transform_path}.",
                    exc_info=True,
                )

        # Load model from web
        if not model_loaded:
            try:
                start = time.time()
                model, image_transform = clip.load(
                    backbone, device=device, download_root=download_root
                )
                with FileLock(MODEL_LOCK, timeout=LOCK_TIMEOUT):
                    logger.info(f"File write lock '{MODEL_LOCK}' acquired")
                    torch.save(model, model_path)
                logger.info(f"File write lock '{MODEL_LOCK}' released")

                with FileLock(TRANSFORM_LOCK, timeout=LOCK_TIMEOUT), open(
                    transform_path, "wb"
                ) as f:
                    logger.info(f"File write lock '{TRANSFORM_LOCK}' acquired")
                    pickle.dump(image_transform, f)
                logger.info(f"File write lock '{TRANSFORM_LOCK}' released")

                logger.info(
                    f"Downloading and caching CLIP model took {time.time() - start}s."
                )
                model_loaded = True
            except Exception as e:
                user_friendly_message = (
                    "Unable to load CLIP model. Check your internet connection."
                )
                detail = f"Unable to load CLIP model with backbone='{backbone}' and device='{device}' from cache and web. "
                f"Check your internet connection or file system at '{download_root}'."
                raise SnorkelException(
                    detail=detail, user_friendly_message=user_friendly_message
                ) from e

        text_tokenizer = lambda x: torch.squeeze(clip.tokenize(x, truncate=True), dim=0)

        return model, image_transform, text_tokenizer


class ImageModel(abc.ABC):
    @abc.abstractmethod
    def train(self, image_paths: List[str], labels: List[Any]) -> None:
        raise NotImplementedError

    @abc.abstractmethod
    def predict(self, image_paths: List[str]) -> List[Any]:
        raise NotImplementedError

    @abc.abstractmethod
    def featurize(self, image_paths: List[str]) -> List[Any]:
        raise NotImplementedError


class CLIPImageEncoder(CLIPModel, ImageModel):
    def _featurize_batch(self, images: torch.Tensor) -> List[List[float]]:
        start_time = time.time()
        features = (
            self.model.encode_image(images.to(self.device))
            .cpu()
            .detach()
            .numpy()
            .tolist()
        )
        logger.info(
            f"CLIP image encoder took {time.time() - start_time} s to process {len(images)} images on device '{self.device}'"
        )
        return features

    def featurize(
        self,
        image_paths: List[str],
        callback: OpProgressCallback = no_op_progress_callback,
    ) -> List[List[float]]:
        features = []
        images_processed = 0
        for images in ImageDataLoader(
            image_paths=image_paths,
            transform=self.image_transform,
            batch_size=self.batch_size,
            num_workers=self.num_data_workers,
        ):
            features.extend(self._featurize_batch(images))
            images_processed = min(images_processed + self.batch_size, len(image_paths))
            callback(images_processed, len(image_paths))
        return features

    def train(self, image_paths: List[str], labels: List[Any]) -> None:
        # TODO ENG-9850
        raise NotImplementedError

    def predict(self, image_paths: List[str]) -> List[Any]:
        # TODO ENG-9850
        raise NotImplementedError


class PatchModel(abc.ABC):
    @abc.abstractmethod
    def train(
        self, image_paths: List[str], bbox_list: List[List[float]], labels: List[Any]
    ) -> None:
        raise NotImplementedError

    @abc.abstractmethod
    def predict(
        self, image_paths: List[str], bbox_list: List[List[float]]
    ) -> List[Any]:
        raise NotImplementedError

    @abc.abstractmethod
    def featurize(
        self, image_paths: List[str], bbox_list: List[List[float]]
    ) -> List[Any]:
        raise NotImplementedError


class CLIPPatchEncoder(CLIPModel, PatchModel):
    def _featurize_batch(self, images: torch.Tensor) -> List[List[float]]:
        start_time = time.time()
        features = (
            self.model.encode_image(images.to(self.device))
            .cpu()
            .detach()
            .numpy()
            .tolist()
        )
        logger.info(
            f"CLIP image encoder took {time.time() - start_time} s to process {len(images)} images on device '{self.device}'"
        )
        return features

    def featurize(
        self,
        image_paths: List[str],
        bbox_list: List[List[float]],
        callback: OpProgressCallback = no_op_progress_callback,
    ) -> List[List[float]]:
        features = []
        images_processed = 0
        for images in PatchDataLoader(
            image_paths=image_paths,
            bbox_list=bbox_list,
            transform=self.image_transform,
            batch_size=self.batch_size,
            num_workers=self.num_data_workers,
        ):
            features.extend(self._featurize_batch(images))
            images_processed = min(images_processed + self.batch_size, len(image_paths))
            callback(images_processed, len(image_paths))
        return features

    def train(
        self, image_paths: List[str], bbox_list: List[List[float]], labels: List[Any]
    ) -> None:
        # TODO ENG-9850
        raise NotImplementedError

    def predict(
        self, image_paths: List[str], bbox_list: List[List[float]]
    ) -> List[Any]:
        # TODO ENG-9850
        raise NotImplementedError


class CLIPTextEncoder(CLIPModel):
    def _featurize_batch(self, tokens: torch.Tensor) -> List[List[float]]:
        start_time = time.time()
        features = (
            self.model.encode_text(tokens.to(self.device))
            .cpu()
            .detach()
            .numpy()
            .tolist()
        )
        logger.info(
            f"CLIP text encoder took {time.time() - start_time} s to process {len(tokens)} texts on device '{self.device}'"
        )
        return features

    def featurize(
        self, texts: List[str], callback: OpProgressCallback = no_op_progress_callback
    ) -> List[List[float]]:
        features = []
        tokens_processed = 0
        for tokens in TextDataLoader(
            texts=texts,
            tokenizer=self.text_tokenizer,
            batch_size=self.batch_size,
            num_workers=self.num_data_workers,
        ):
            features.extend(self._featurize_batch(tokens))
            tokens_processed = min(tokens_processed + self.batch_size, len(texts))
            callback(tokens_processed, len(texts))
        return features
