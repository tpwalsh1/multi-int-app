from dask import dataframe as dd
from dask.dataframe.multi import align_partitions

from snorkelflow.utils.logging import get_logger

logger = get_logger("dask_dataframe")


def cull_known_empty_partitions(ddf: dd.DataFrame) -> dd.DataFrame:
    """Preferred over cull_empty_partitions when possible. This method sacrifices guarantees on culling
    empty partitions in exchange for almost instantaneous-culling of divisions of width 0.
    See https://docs.dask.org/en/latest/dataframe-design.html#partitions for background.
    """
    if not ddf.known_divisions:
        # To prevent edge cases, no-op if divisions are unknown - no easy way to know
        # whether partitions are empty
        logger.warn("DDF has unknown divisions, no-op")
        return ddf
    # Our main intent for using this function is just to remove duplicate division boundaries
    # There are some edge cases though, so just use the method dask uses to do the same thing
    ddfs, _, _ = align_partitions(ddf)
    return ddfs[0]


def cull_empty_partitions(ddf: dd.DataFrame) -> dd.DataFrame:
    """Guarantees culling of empty partitions.
    Warning: This method COMPUTES the DDF, so it can cause significant computation overhead if DDF is complex.
    """
    ll = list(ddf.map_partitions(len).compute())
    df_delayed = ddf.to_delayed()
    df_delayed_new = []
    pempty = None
    for ix, n in enumerate(ll):
        if 0 == n:
            pempty = df_delayed[ix]
        else:
            df_delayed_new.append(df_delayed[ix])
    if pempty is not None:
        if len(df_delayed_new) > 0:
            ddf = dd.from_delayed(df_delayed_new)
        else:
            ddf = dd.from_delayed([pempty])
    return ddf
