"""Collection of helpers for Pydantic BaseModel
"""
import json
from typing import Any, Dict, Optional, Union, get_type_hints

# Python >= 3.8
try:
    from typing import get_args, get_origin
# Compatibility w/ Python 3.6
except ImportError:
    get_args = lambda t: getattr(t, "__args__", ())
    get_origin = lambda t: getattr(t, "__origin__", None)

import yaml
from pydantic import BaseModel, Extra, validate_model


class StrictBaseModel(BaseModel):
    """Pydantic BaseModel with some commonly-used defaults."""

    class Config:
        extra = Extra.forbid


class InvalidPath(Exception):
    pass


def yaml_safe_dump(model: BaseModel) -> str:
    # YAML can't handle enums, this is the suggested workaround
    # in https://github.com/samuelcolvin/pydantic/issues/1409#issuecomment-616902980
    # Other solutions in thread were rejected due to depending on fastapi, which
    # is not available in our wheel (and shouldn't be)
    safe_dict = json.loads(model.json())
    return yaml.safe_dump(safe_dict)


def update_model_at_path(model: BaseModel, path: str, val: Optional[str]) -> BaseModel:
    """Updates the Pydantic model at the given path/val
    Attempting to make a nested path for a non-dict value will throw an InvalidPath() exception
    Passing in val=None will unset the value (meaning it'll use whatever the BaseModel's default is)
        Attempting to unset a nonexistent value will throw a InvalidPath() exception
    Attempting to set a complex type will throw a TypeError
    Any updates that result in an invalid BaseModel will throw a ValidationException
    Examples:
        update_model_at_path(model=BaseModel<a=1>, path="a", val=2) => BaseModel<a=2>
        update_model_at_path(model=BaseModel<a=1>, path="a.b", val=2) => InvalidPath thrown
        update_model_at_path(model=BaseModel<a=1>, path="a", val=None) => BaseModel<>
        update_model_at_path(model=BaseModel<b=1>, path="a", val=None) => InvalidPath thrown
        update_model_at_path(model=BaseModel<a={b: 1}>, path="a.b", val=2) => BaseModel<a={b: 2}>
        update_model_at_path(model=BaseModel<a={c=1}>, path="a.b.c", val=2) => InvalidPath thrown
        update_model_at_path(model=BaseModel<a={b: 1}>, path="a", val="{b: 3}") => TypeError thrown
    """
    updated_model = _update_model_at_path(model, path, val)

    # Run validation on updated model
    _, _, error = validate_model(updated_model.__class__, updated_model.dict())
    if error:
        raise error
    return updated_model


def _update_model_at_path(model: BaseModel, path: str, val: Optional[str]) -> BaseModel:
    if "." not in path:
        config_dict = model.dict()
        if path not in config_dict:
            raise InvalidPath()
        _update_config_dict(config_dict, path, val, get_type_hints(model)[path])  # type: ignore
        return model.__class__.construct(**config_dict)
    else:
        section, subpath = path.split(".", 1)

        subsection = getattr(model, section)
        subsection_type_hint = get_type_hints(model)[section]  # type: ignore

        # If value is a str-str dict, add the subpath into the dict
        if subsection_type_hint in [Dict[str, str], Optional[Dict[str, str]]]:
            if subsection is None:
                subsection = {}
                setattr(model, section, subsection)
            _update_config_dict(subsection, subpath, val, str)
        elif isinstance(subsection, BaseModel):
            setattr(model, section, _update_model_at_path(subsection, subpath, val))
        else:
            # Cannot go deeper
            raise InvalidPath()
        return model


def _update_config_dict(
    config_dict: Dict[str, Any], path: str, val: Optional[str], type_hint: Any
) -> None:
    if val is None:
        # We're attempting to unset
        if path in config_dict:
            del config_dict[path]
        else:
            raise InvalidPath()
    else:
        typed_val = _cast_to_type(val, type_hint)
        config_dict[path] = typed_val


# TODO: If we were starting from scratch, we would be able to use pydantic
# to do the casting for us.
# We've left this method alone for now due to the custom values we've chosen
# to support for the string -> bool parsing. Pydantic probably has some way to
# accept those values and casting them to false as well.
def _cast_to_type(val: Optional[str], annotation: Any) -> Any:
    """Cast val to type specified by annotation."""
    if val is None or annotation == Any:
        return val
    # If annotation is Optional[basic_type], cast to X.
    # TODO: When python 3.8 is the minimum supported version, use get_origin() and get_args()
    if getattr(annotation, "__origin__", None) == Union:
        args = annotation.__args__
        if (
            len(args) == 2
            and isinstance(None, args[1])
            and args[0] in [int, float, str, bool]
        ):
            annotation = args[0]

    # More user-friendly string to boolean casting.
    if annotation == bool:
        return val.lower() not in {"false", "f", "0", ""}
    if annotation in [int, float, str]:
        return annotation(val)
    raise TypeError(f"Unsupported type {annotation} for {val}.")


def is_optional_field(field_type: Any) -> bool:
    """Checks if field type is optional"""
    return get_origin(field_type) is Union and type(None) in get_args(field_type)
