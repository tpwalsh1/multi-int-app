import math
from typing import Any, Callable, Optional

import dask
from dask.base import unpack_collections
from dask.diagnostics import ProgressBar
from dask.system import CPU_COUNT

from snorkelflow.utils.logging import get_logger
from snorkelflow.utils.statsd import stats

try:
    # MLFlow uses this code, and they don't like having services code
    from services.observability.trace import start_trace_span
except ImportError:
    from contextlib import contextmanager
    from typing import Iterator

    @contextmanager
    def start_trace_span(*args: Any, **kwargs: Any) -> Iterator[None]:
        yield


logger = get_logger("snorkelflow")


def _get_num_workers(
    parallel_core_fraction: Optional[float],
    max_workers: Optional[int],
    npartitions: Optional[int],
    scheduler: Optional[str],
) -> int:
    # dask.system.CPU_COUNT is cgroup aware and returns the correct number of cpus when
    # inside a container pod.
    n_workers = CPU_COUNT
    # Apply parallel_core_fraction to limit the access to entire CPU_COUNT
    if parallel_core_fraction is not None:
        n_workers = min(n_workers, math.ceil(parallel_core_fraction * n_workers))
    # Apply max_workers if provided
    if max_workers:
        n_workers = min(n_workers, max_workers)
    # Limit num workers to npartitions, since more workers would not provide additional gains.
    if npartitions:
        n_workers = min(n_workers, npartitions)
    if scheduler == "threads":
        # For threads scheduler, use at most 4 workers in all cases. This is partly to
        # be compatible with defaults that used to exist in the platform previously, and
        # partly because most of the heavy dask computations we do acquire the GIL, so
        # more threads do not scale performance.
        THREADS_MAX_WORKERS = 4
        n_workers = min(n_workers, THREADS_MAX_WORKERS)
    return max(1, n_workers)


ProgressCallback = Callable[[float, float], None]


class CallbackProgressBar(ProgressBar):
    def __init__(self, callback: ProgressCallback, *args: Any, **kwargs: Any):
        self._custom_callback = callback
        super().__init__(*args, **kwargs)

    def _draw_bar(self, frac: float, elapsed: float) -> None:
        # NB: don't love overriding a hidden method, but CI will catch any breaks
        # on a Dask version update
        self._custom_callback(frac, elapsed)
        super()._draw_bar(frac, elapsed)


def group_compute(
    *dask_ops: Any,
    callback: Optional[ProgressCallback] = None,
    is_expensive: bool = False,
    **kwargs: Any,
) -> Any:
    from snorkelflow.dask.client import compute as sfdask_compute

    logger.info(f"Using ray-partitioned scheduler, op is_expensive={is_expensive}")
    return sfdask_compute(
        *dask_ops, progress_callback=callback, is_expensive=is_expensive, **kwargs
    )


def dask_compute(
    *dask_ops: Any,
    scheduler: Optional[str] = None,
    parallel_core_fraction: Optional[float] = None,
    max_workers: Optional[int] = None,
    callback: Optional[ProgressCallback] = None,
    is_expensive: bool = False,
    **kwargs: Any,
) -> Any:
    with start_trace_span(
        f"dask_compute - {scheduler}", data={"is_expensive": is_expensive}
    ):
        return _dask_compute(
            *dask_ops,
            scheduler=scheduler,
            parallel_core_fraction=parallel_core_fraction,
            max_workers=max_workers,
            callback=callback,
            is_expensive=is_expensive,
            **kwargs,
        )


def _dask_compute(
    *dask_ops: Any,
    scheduler: Optional[str],
    parallel_core_fraction: Optional[float],
    max_workers: Optional[int],
    callback: Optional[ProgressCallback],
    is_expensive: bool,
    **kwargs: Any,
) -> Any:
    # Compute the maximum number of partitions in dask_ops. We only need as many workers
    # as the maximum number of partitions in any op. Using more workers will just lead
    # to idling. If npartitions is not available in any dask_op, assume that it may want
    # take up maximum possible parallelism.
    npartitions: Optional[int] = 1
    unpacked_dask_ops, _ = unpack_collections(*dask_ops)

    # We no longer have a group scheduler, so force to ray-partitioned instead.
    if scheduler == "group":
        scheduler = "ray-partitioned"

    for dask_op in unpacked_dask_ops:
        try:
            op_npartitions = dask_op.npartitions
            if type(op_npartitions) != int:
                npartitions = None
                break
        except AttributeError:
            npartitions = None
            break
        assert npartitions is not None  # for mypy
        npartitions = max(npartitions, op_npartitions)

    # If there is only a single partition, just use the threads scheduler instead of
    # kicking of new processes to save some overhead. This might mean that multiple dask
    # computation running in the same main process contend for GIL, but we
    # run most dask computations in jobs which are isolated processes to begin with.
    if not scheduler:
        scheduler = "threads"

    if scheduler != "ray-partitioned":
        if npartitions == 1:
            logger.warning(f"Using threads scheduler since there is only 1 partition.")
            scheduler = "threads"
        if max_workers == 1:
            logger.warning(f"Using threads scheduler since there is only 1 worker.")
            scheduler = "threads"

    stats.counter_incr("dask.compute", tags={"scheduler": scheduler})

    if scheduler == "ray-partitioned":
        try:
            return group_compute(
                *dask_ops, callback=callback, is_expensive=is_expensive, **kwargs
            )
        except ImportError:
            raise ValueError(f"Cannot use {scheduler} scheduler outside of engine")

    num_workers = _get_num_workers(
        parallel_core_fraction, max_workers, npartitions, scheduler
    )
    logger.info(
        f"Using dask {scheduler} scheduler with {num_workers} workers."
        f" cpu_count: {CPU_COUNT}, parallel_core_fraction: {parallel_core_fraction},"
        f" max_workers: {max_workers}, npartitions: {npartitions}"
    )

    if scheduler == "threads":
        # Start progress bar. We don't set the dt parameter as it also becomes the
        # minimum time of the computation.
        if callback:
            pb = CallbackProgressBar(callback, minimum=10.0)
        else:
            pb = ProgressBar(minimum=10.0)
        with pb:
            return dask.compute(
                *dask_ops,
                scheduler="threads",
                num_workers=num_workers,
                optimize_graph=False,
            )
    else:
        raise ValueError(
            f"Invalid scheduler {scheduler}. Must be 'threads', or 'ray-partitioned'."
        )
