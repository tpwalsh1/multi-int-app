import yaml


class CustomDumper(yaml.Dumper):
    def str_presenter(dumper: yaml.Dumper, data: str) -> yaml.ScalarNode:
        if len(data.splitlines()) > 1:  # check for multiline string
            return dumper.represent_scalar("tag:yaml.org,2002:str", data, style="|")
        return dumper.represent_scalar("tag:yaml.org,2002:str", data)


CustomDumper.add_representer(str, CustomDumper.str_presenter)
