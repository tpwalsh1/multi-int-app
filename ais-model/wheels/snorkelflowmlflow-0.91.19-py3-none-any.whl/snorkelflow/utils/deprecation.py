import functools
import re
import sys
import warnings
from typing import Callable, Optional


def _is_valid_lts_release(release: str) -> bool:
    return bool(re.match(r"202\d\.R[1-4]", release))


def deprecated(deprecate_in: str, remove_in: str, details: str = "") -> Callable:
    """This is a decorator which can be used to mark functions as deprecated"""

    if not (_is_valid_lts_release(deprecate_in) and _is_valid_lts_release(remove_in)):
        raise ValueError(
            "Release names for deprecation and removal must be of the form "
            '"YYYY.RN" (e.g., 2023.R1). '
            f"Received: {deprecate_in} and {remove_in}."
        )

    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        def new_func(*args, **kwargs):  # type: ignore
            # PEP 565 is only effective as of py3.7
            if sys.version_info < (3, 7):
                warnings.filterwarnings(
                    "default", category=DeprecationWarning, module="__main__"
                )
            message = (
                f"{func.__name__} "
                f"is deprecated as of the {deprecate_in} release "
                f"and will be removed by the {remove_in} release. "
                f"{details}"
            )
            warnings.warn(message, category=DeprecationWarning, stacklevel=2)
            return func(*args, **kwargs)

        return new_func

    return decorator


def _deprecated_arg(
    deprecate_in: str, remove_in: str, old: str, new: Optional[str], details: str = ""
) -> Callable:
    """This is a decorator to wrap a function that has deprepcated arguments

    1. to raise a deprecation warning if the old argument is passed, and
    2. to translate the old arg to the new one for backward compatibility.
    3. Note that new=None means that the old is deprecated w/o any new param.
    """

    if not (_is_valid_lts_release(deprecate_in) and _is_valid_lts_release(remove_in)):
        raise ValueError(
            "Release names for deprecation and removal must be of the form "
            '"Season YYYY" (e.g., Spring 2021). '
            f"Received: {deprecate_in} and {remove_in}."
        )

    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        def new_func(*args, **kwargs):  # type: ignore
            # PEP 565 is only effective as of py3.7
            if sys.version_info < (3, 7):
                warnings.filterwarnings(
                    "default", category=DeprecationWarning, module="__main__"
                )
            if new is None:
                message = (
                    f'The argument "{old}" is deprecated'
                    f" as of the {deprecate_in} release and will be removed by the {remove_in} release. {details}"
                )
                warnings.warn(message, category=DeprecationWarning, stacklevel=2)
            elif old in kwargs:
                kwargs[new] = kwargs.pop(old)
                message = (
                    f'The argument "{old}" is deprecated in favor of "{new}"'
                    f" as of the {deprecate_in} release and will be removed by the {remove_in} release. {details}"
                )
                warnings.warn(message, category=DeprecationWarning, stacklevel=2)
            return func(*args, **kwargs)

        return new_func

    return decorator
