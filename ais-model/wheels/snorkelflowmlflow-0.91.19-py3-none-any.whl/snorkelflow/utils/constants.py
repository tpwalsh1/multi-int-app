VENDOR_PRODUCT_NAME = "SnorkelAI_SnorkelFlow"
