from typing import Optional

import boto3
from botocore.client import Config

from .file import get_path_storage_options
from .logging import get_logger

logger = get_logger("SnorkelFlow Minio Utils")


def create_bucket_if_not_exists(bucket_name: Optional[str] = None) -> None:
    """
    Some services *do not* have access to the shared disk (i.e. /data).
    We use the boto SDK here to ensure the bucket exists instead of
    manipulating the shared disk
    """
    _, storage_options = get_path_storage_options(f"minio://{bucket_name}")
    minio_url = storage_options["client_kwargs"]["endpoint_url"]
    minio_access_key = storage_options["key"]
    minio_secret_key = storage_options["secret"]

    if not bucket_name or not minio_url:
        return
    s3 = boto3.resource(
        "s3",
        endpoint_url=minio_url,
        aws_access_key_id=minio_access_key,
        aws_secret_access_key=minio_secret_key,
        config=Config(signature_version="s3v4"),  # no-op
        region_name="us-west-1",  # no-op
    )
    try:
        s3.create_bucket(Bucket=bucket_name)
        logger.info(f"Initialized MinIO bucket '{bucket_name}' at {minio_url}")
    except s3.meta.client.exceptions.BucketAlreadyOwnedByYou:
        # Bucket already exists
        pass
