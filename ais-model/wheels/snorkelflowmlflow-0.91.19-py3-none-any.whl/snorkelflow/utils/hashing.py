import hashlib
from typing import Any


def consistent_hash(val: Any) -> int:
    """A consistent way to hash values across python sessions"""
    byte_string = str(val).encode("utf-8")
    return int(hashlib.sha1(byte_string).hexdigest(), 16)


def hashable_dict(d: dict) -> tuple:
    """Returns a deterministic tuple from a (potentially nested) dict to be used for hashing"""
    new_d = {}

    for key, val in d.items():
        # Recursive call to hash nested dicts
        if isinstance(val, dict):
            new_d[key] = hashable_dict(val)
        elif isinstance(val, (list, set)):
            hashed_items = []
            for item in val:
                if isinstance(item, dict):
                    hashed_items.append(hashable_dict(item))
                elif isinstance(item, (list, set)):
                    hashed_items.append(hashable_dict({"tmp": item})[0][1])
                else:
                    hashed_items.append(item)
            try:
                hashed_items = sorted(hashed_items)
            except TypeError as e:
                raise ValueError(
                    f"Cannot compute consistent hash for dictionary because items cannot be compared for sorting - {hashed_items}"
                ) from e
            new_d[key] = tuple(hashed_items)
        else:
            new_d[key] = val

    try:
        hashed_d = sorted(new_d.items())
    except TypeError as e:
        raise ValueError(
            f"Cannot compute consistent hash for dictionary because items cannot be compared for sorting - {new_d}"
        ) from e
    return tuple(hashed_d)


def hash_dict(d: dict) -> int:
    """Returns the consistent_hash value for a (snapshot of a) dict"""
    return consistent_hash(hashable_dict(d))
