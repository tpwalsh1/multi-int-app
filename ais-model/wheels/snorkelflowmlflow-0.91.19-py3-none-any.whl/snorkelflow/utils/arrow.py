import json
import math
import os
import pickle
from typing import Any, Collection, Dict, Iterable, List, Optional, Tuple

import dask.dataframe as dd
import fsspec
import numpy as np
import pandas as pd
import pyarrow as pa
import pyarrow.fs
from dask import delayed
from fsspec.utils import infer_storage_options

from snorkelflow.types.load import DATAPOINT_UID_COL, TYPES_COL
from snorkelflow.utils.file import _open_file, resolve_data_path
from snorkelflow.utils.logging import get_logger

try:
    # MLFlow uses this code, and they don't like having services code
    from services.observability.trace import start_trace_span
except ImportError:
    from contextlib import contextmanager
    from typing import Iterator

    @contextmanager
    def start_trace_span(*args: Any, **kwargs: Any) -> Iterator[None]:
        yield


ARROW_META_FILENAME = "arrow_meta"
logger = get_logger("Arrow")

ARROW_WRITE_CHUNK_SIZE_MB = 256  # Arbitrary value.
ARROW_READ_CHUNK_SIZE_MB = 256  # Arbitrary value.


def write_arrow_file(
    df: pd.DataFrame,
    arrow_file: str,
    chunk_size_mb: int = ARROW_WRITE_CHUNK_SIZE_MB,
    storage_options: Optional[Dict[str, Any]] = None,
) -> None:
    """We want to write the dataframe in chunks because creating a pyarrow.Table from the raw
    dataframe blows our memory through the roof.

    We also don't necessarily want to write according to the Arrow partitions because we can handle
    larger page sizes in the main process used for writing, whereas the Arrow partitions consider
    the memory limits of Dask workers used for reading.
    """
    # Try each column individually to determine the columns that have mixed types or another issue
    bad_col_to_exp = {}
    for col in df.columns:
        try:
            pa.Schema.from_pandas(pd.DataFrame(df[col]), preserve_index=True)
        except Exception as e:
            bad_col_to_exp[col] = e
    if len(bad_col_to_exp) > 0:
        logger.info(
            f"The provided DataFrame has datatype mismatches within columns {bad_col_to_exp=}."
        )
        raise ValueError(
            f"The provided DataFrame has datatype mismatches within columns {bad_col_to_exp.keys()}. Please make sure that all data within a column is of the same type, and try again."
        )

    schema = pa.Schema.from_pandas(df, preserve_index=True)
    schema = schema.with_metadata(
        {
            **schema.metadata,
            "serialized_columns": json.dumps(df.attrs.get("serialized_columns", [])),
        }
    )

    num_rows = len(df)
    df_memory_mb = df.memory_usage(deep=True).sum() / 1_000_000
    num_chunks = math.ceil(df_memory_mb / chunk_size_mb)
    num_chunks = min(num_chunks, num_rows)

    f = get_sink_for_arrow_path(arrow_file, storage_options=storage_options)
    with f as sink:
        with pa.ipc.RecordBatchFileWriter(sink, schema) as writer:
            for chunk_i in range(num_chunks):
                start = int(chunk_i / num_chunks * num_rows)
                end = int((chunk_i + 1) / num_chunks * num_rows)

                chunk = pa.Table.from_pandas(
                    df.iloc[start:end], preserve_index=True, schema=schema
                )

                writer.write_table(chunk)
                del chunk  # Manual GC may not be necessary.
    logger.info(f"Finished writing chunks to {arrow_file} with size {df_memory_mb} MB.")


def _get_pa_s3_filesystem(
    storage_options: Optional[Dict[str, Any]] = None
) -> pa.fs.S3FileSystem:
    # Pyarrow S3FileSystem requires storage options in a different format than dask, remap as needed here
    mapped_storage_options = {}
    if storage_options is not None:
        mapped_storage_options["access_key"] = storage_options.get("key")
        mapped_storage_options["secret_key"] = storage_options.get("secret")
        mapped_storage_options["endpoint_override"] = storage_options.get(
            "client_kwargs", {}
        ).get("endpoint_url")
        mapped_storage_options["scheme"] = "http"
    return pa.fs.S3FileSystem(**mapped_storage_options)


def _get_s3_arrow_output_stream(
    path: str, storage_options: Optional[Dict[str, Any]] = None
) -> Any:
    protocol = infer_storage_options(path).get("protocol")
    path = path.replace(f"{protocol}://", "", 1)
    return _get_pa_s3_filesystem(storage_options).open_output_stream(path)


def _get_s3_arrow_input_file(
    path: str, storage_options: Optional[Dict[str, Any]] = None
) -> Any:
    protocol = infer_storage_options(path).get("protocol")
    path = path.replace(f"{protocol}://", "", 1)
    return _get_pa_s3_filesystem(storage_options).open_input_file(path)


def get_sink_for_arrow_path(
    path: str, storage_options: Optional[Dict[str, Any]] = None
) -> Any:
    protocol = infer_storage_options(path).get("protocol")

    if protocol == "s3":
        path = path.replace("s3://", "", 1)
        return _get_s3_arrow_output_stream(path, storage_options=storage_options)
    if protocol == "file":
        path = path.replace("file://", "", 1)
    return pa.OSFile(path, "wb")


def get_source_for_arrow_path(
    path: str,
    protocol: Optional[str] = None,
    storage_options: Optional[Dict[str, Any]] = None,
) -> Any:
    if protocol is None:
        protocol = infer_storage_options(path).get("protocol")
    if protocol == "s3":
        path = path.replace("s3://", "", 1)
        return _get_s3_arrow_input_file(path, storage_options=storage_options)
    if protocol == "file":
        path = path.replace("file://", "", 1)
    return pa.memory_map(path, "rb")


def _to_arrow(
    df: pd.DataFrame,
    path: str,
    partition_info: Any = None,
    storage_options: Optional[Dict[str, Any]] = None,
) -> None:
    if not partition_info:
        return
    part_num = partition_info["number"]
    write_arrow_file(
        df, f"{path}/part_{part_num}.arrow", storage_options=storage_options
    )


def to_arrow(
    ddf: dd.DataFrame,
    path: str,
    compute: bool = True,
    storage_options: Optional[Dict[str, Any]] = None,
) -> dd.DataFrame:
    """Persist the ddf to disk in the arrow format"""
    resolved_path = resolve_data_path(path)
    write_arrow_metadata(path, storage_options, ddf.npartitions, ddf.divisions)
    ddf = ddf.map_partitions(
        _to_arrow, resolved_path, storage_options=storage_options, meta=ddf
    )
    if compute:
        return ddf.compute()
    return ddf


def table_to_arrow_dir(
    table: pa.Table,
    path: str,
    npartitions: int,
    storage_options: Optional[Dict[str, Any]] = None,
) -> None:
    path = resolve_data_path(path)
    logger.info(f"Writing {npartitions} partitions to {path}")
    index_df = table.select([DATAPOINT_UID_COL]).to_pandas()
    division_idxs = np.linspace(0, len(index_df) - 1, npartitions + 1).astype(int)
    if len(index_df) > 0:
        divisions = tuple(index_df.index[idx] for idx in division_idxs)
    else:
        divisions = ("doc::0", "doc::9999")
    write_arrow_metadata(path, storage_options, npartitions, divisions)

    division_idxs[-1] += 1
    table.slice(0, 1).to_pandas()

    for part_num, (start, end) in enumerate(zip(division_idxs[:-1], division_idxs[1:])):
        chunk = table.slice(start, end - start)
        arrow_file = f"{path}/part_{part_num}.arrow"
        f = get_sink_for_arrow_path(arrow_file, storage_options=storage_options)
        with f as sink:
            with pa.ipc.RecordBatchFileWriter(sink, table.schema) as writer:
                writer.write_table(chunk)


def read_arrow_metadata(
    path: str, storage_options: Optional[Dict[str, Any]] = None
) -> Dict[str, Any]:
    resolved_path = resolve_data_path(path)
    with _open_file(
        f"{resolved_path}/{ARROW_META_FILENAME}", "rb", **(storage_options or {})
    ) as f:
        arrow_meta = pickle.load(f)
    return arrow_meta


def write_arrow_metadata(
    arrow_dir: str,
    storage_options: Optional[Dict[str, Any]],
    npartitions: int,
    divisions: tuple,
) -> None:
    resolved_path = resolve_data_path(arrow_dir)
    protocol = infer_storage_options(resolved_path)["protocol"]
    fs = fsspec.filesystem(protocol)
    arrow_meta_file_path = f"{resolved_path}/{ARROW_META_FILENAME}"
    if fs.exists(arrow_meta_file_path):
        raise ValueError(
            f"Arrow meta file already exists at path: {arrow_meta_file_path}"
        )
    with _open_file(
        arrow_meta_file_path,
        "wb",
        **(storage_options if storage_options is not None else {}),
    ) as fh:
        pickle.dump({"npartitions": npartitions, "divisions": divisions}, fh)


def approx_arrow_row_size(
    arrow_file: str, storage_options: Optional[Dict[str, Any]] = None
) -> int:
    """Approx number of bytes per a row in arrow file"""
    table = read_arrow_as_table(arrow_file=arrow_file, storage_options=storage_options)
    return table.nbytes // max(1, table.num_rows)


def read_arrow_as_table(
    arrow_file: str,
    cols_to_load: Optional[Collection[str]] = None,
    storage_options: Optional[Dict[str, Any]] = None,
    row_offsets: Optional[Collection[int]] = None,
    row_indices: Optional[Collection[str]] = None,
    pos_x_uids: Optional[pd.DataFrame] = None,
) -> pa.Table:
    """Reads an arrow file as a pyarrow table.

    If row_offsets is not None, we seek those offsets of the Arrow file.
    If row_indices is not None, we seek those row of the Arrow file.
    If row_offsets and row_indices are both None, then we default to reading all rows.

    If we try to read columns that are not in the Arrow file, we will not read those columns.

    Note that if row_indices is specified, the table returned will be
       ordered by the offset in the file, rather than sorted according to the
       indexes ordering. Use `read_arrow_as_df` or manually sort if ordering acording
       to row index is required.

    Parameters
    ----------
    arrow_file : str
        Path to the arrow file
    cols_to_load : List[str], optional
        List of column names. If None, then we default to reading all columns.
    storage_options : Dict[str, Any], optional
        Storage options to pass to get_source_for_arrow_path.
    row_offsets : List[int], optional
        List of numeric row offsets. Mutually exclusive with row_indices.
    row_indices : List[str], optional
        List of indexes of the rows to read. Mutually exclusive with row_offests.
    pos_x_uids : pd.DataFrame, optional
        For caching the expensive get_pos_x_uids() first and passing in the result here.
    Returns
    -------
    pa.Table
        The resulting pyarrow Table."""

    if row_offsets is not None and row_indices is not None:
        raise ValueError("Only one of row_offsets or row_indices can be present.")

    if row_offsets is not None:
        read_subset = True
        num_rows = len(row_offsets)
    elif row_indices is not None:
        read_subset = True
        num_rows = len(row_indices)
    else:
        read_subset = False
        num_rows = None

    with start_trace_span(
        f"Read Arrow file as table: {arrow_file}",
        op_type="disk",
        data={
            "cols_to_load": cols_to_load,
            "num_rows": num_rows,
            "pos_x_uids_is_cached": pos_x_uids is not None,
        },
    ):
        f = get_source_for_arrow_path(arrow_file, storage_options=storage_options)
        with f as source:
            table = pa.ipc.RecordBatchFileReader(source).read_all()
            # Sample columns to load if requested
            if cols_to_load is not None:
                index_columns = _get_index_columns(table)
                cols_to_load_and_index = list(set(list(cols_to_load) + index_columns))
                table = table.select(cols_to_load_and_index)

            # Subsample rows if requested
            if read_subset:
                # If row indices were specified, then use those instead.
                if row_indices is not None:
                    pos_x_uids = (
                        pos_x_uids if pos_x_uids is not None else get_pos_x_uids(table)
                    )
                    row_offsets_to_read = pos_x_uids.loc[
                        pos_x_uids.index.intersection(row_indices), "pos"
                    ].tolist()
                else:
                    row_offsets_to_read = row_offsets
                    # This is just casting in case someone threw us something weird.
                    if isinstance(row_offsets, pd.DataFrame):
                        row_offsets_to_read = row_offsets.squeeze()
                    if isinstance(row_offsets, pd.Series):
                        row_offsets_to_read = row_offsets.tolist()

                if (
                    row_offsets_to_read is None
                ):  # This will never happen due to the above checks but mypy doesn't know this!
                    row_offsets_to_read = []

                if len(row_offsets_to_read) == 0:
                    return table.slice(0, 0)

                # Not using take due to https://issues.apache.org/jira/browse/ARROW-9773
                # Using slices like here instead: https://github.com/huggingface/datasets/pull/645]
                deduped_row_index = sorted(list(set(row_offsets_to_read)))
                ranges = get_ranges_for_positional_index(deduped_row_index)
                tables = []
                for offset, length in ranges:
                    tables.append(table.slice(offset, length))

                table = pa.concat_tables(tables)

            return table


def _get_index_columns(table: pa.Table) -> List[str]:
    return table.schema.pandas_metadata["index_columns"]


def table_to_pandas(
    table: pa.Table, convert_categorical_to_object: bool = True
) -> pd.DataFrame:
    """Convert Table to DataFrame
    Note that if a table is empty it can't be coverted directly to a pandas dataframe"""
    serialized_columns = []
    if table.schema.metadata is not None:
        serialized_columns = json.loads(
            table.schema.metadata.get(b"serialized_columns", "[]")
        )
    if len(table) == 0:
        # https://github.com/pandas-dev/pandas/issues/35436
        df = table.schema.empty_table().to_pandas(self_destruct=True)
    else:
        df = table.to_pandas(split_blocks=True, self_destruct=True)

    if convert_categorical_to_object:
        for col in serialized_columns:
            if col in df.columns:
                if df[col].dtype.name == "category":
                    df[col] = df[col].astype(df[col].cat.categories.dtype)
                else:
                    df[col] = df[col].astype("object")
    return df


def get_ranges_for_positional_index(
    positional_index: List[int], positions_are_sorted: bool = False
) -> List[List[int]]:
    """This function takes a sorted List[int] of positional indices and generates tuples of [offset, length].
    These tuples allow us to turn seeks into chunks of scans. We're doing this to scan as much as possible.
    """
    if not positions_are_sorted:
        positional_index = sorted(positional_index)

    start, pointer = None, None
    ranges = []

    for i in positional_index:
        if pointer is None:
            start = i
        elif i != pointer + 1:
            # Either i == pointer, or i > pointer + 1.
            # In either case, we need to cut the range.
            ranges.append([start, pointer - start + 1])
            start = i

        pointer = i

    if start is not None and pointer is not None:
        ranges.append([start, pointer - start + 1])

    return ranges


def read_arrow_as_df(
    arrow_file: str,
    cols_to_load: Optional[List[str]] = None,
    storage_options: Optional[Dict[str, Any]] = None,
    row_offsets: Optional[List[int]] = None,
    row_indices: Optional[List[str]] = None,
    pos_x_uids: Optional[pd.DataFrame] = None,
    convert_categorical_to_object: bool = True,
) -> pd.DataFrame:
    """Reads an arrow file as a pandas DataFrame.

    If row_offsets is not None, we seek those offsets of the Arrow file.
    If row_indices is not None, we seek those row of the Arrow file.
    If row_offsets and row_indices are both None, then we default to reading all rows.

    If we try to read columns that are not in the Arrow file, we will not read those columns.

    Parameters
    ----------
    arrow_file : str
        Path to the arrow file
    cols_to_load : List[str], optional
        List of column names. If None, then we default to reading all columns.
    storage_options : Dict[str, Any], optional
        Storage options to pass to get_source_for_arrow_path.
    row_offsets : List[int], optional
        List of numeric row offsets. Mutually exclusive with row_indices.
    row_indices : List[str], optional
        List of indexes of the rows to read. Mutually exclusive with row_offests.
    pos_x_uids : pd.DataFrame, optional
        For caching the expensive get_pos_x_uids() first and passing in the result here.
    Returns
    -------
    pd.DataFrame
        The resulting pandas DataFrame."""
    if pos_x_uids is None and row_indices is not None:
        table = read_arrow_as_table(arrow_file)
        pos_x_uids = get_pos_x_uids(table)

    table = read_arrow_as_table(
        arrow_file,
        cols_to_load,
        storage_options=storage_options,
        row_offsets=row_offsets,
        row_indices=row_indices,
        pos_x_uids=pos_x_uids,
    )

    # Reorder the data according to original row_offsets or row_indices because
    # read_arrow_as_table returns rows sorted according to their row offset in
    # the arrow file.
    if row_offsets is not None:
        if len(row_offsets) == 0:
            return table_to_pandas(table, convert_categorical_to_object)
        # Get row_offsets ordering as in read_arrow_as_table
        row_offsets_read = {
            row_offset: offset
            for offset, row_offset in enumerate(sorted(set(row_offsets)))
        }
        # Map the sorted and deduplicated results from `read_arrow_as_table` back
        # to the ordering specified by row_offsets
        orig_row_offsets_reindex = [
            row_offsets_read[row_offset] for row_offset in row_offsets
        ]
        return table_to_pandas(table, convert_categorical_to_object).iloc[
            orig_row_offsets_reindex
        ]
    elif row_indices is not None:
        if len(row_indices) == 0:
            return table_to_pandas(table, convert_categorical_to_object)
        df = table_to_pandas(table, convert_categorical_to_object)
        return df.loc[list(filter(lambda x: x in df.index, row_indices))]
    return table_to_pandas(table, convert_categorical_to_object)


def get_pos_x_uids(table: pa.Table, offset: int = 0) -> pd.DataFrame:
    """
    Expensive computation to get the position of each uid in the arrow file.
    Primarily called in order to save time if calling read_arrow_as_df multiple times.
    """
    table = table.select(_get_index_columns(table))
    pos_x_uids = table_to_pandas(table)
    pos_x_uids["pos"] = pd.RangeIndex(start=offset, stop=offset + len(pos_x_uids))
    return pos_x_uids


def _get_arrow_file_paths(
    path: str, protocol: Optional[str], storage_options: Optional[Dict[str, Any]] = None
) -> List[str]:
    fs = fsspec.filesystem(
        protocol, **(storage_options if storage_options is not None else {})
    )
    if path.endswith("/"):
        path = path[:-1]
    return fs.glob(f"{path}/*.arrow")


def read_schema_df(
    path: str, storage_options: Optional[Dict[str, Any]] = None
) -> pd.DataFrame:
    """Get an empty dataframe with correct columns and dtypes."""
    resolved_path = resolve_data_path(path)
    protocol = infer_storage_options(
        resolved_path, inherit_storage_options=storage_options
    )["protocol"]
    arrow_file_paths = _get_arrow_file_paths(
        resolved_path, protocol, storage_options=storage_options
    )
    if len(arrow_file_paths) == 0:
        raise ValueError(f"Unable to find arrow files at path: {path}")
    schemas = {}
    # Make sure all partitions share the same column names
    for part_path in arrow_file_paths:
        # fs.glob strips the protocol (like s3://), define explictly
        f = get_source_for_arrow_path(
            part_path, protocol=protocol, storage_options=storage_options
        )
        with f as source:
            reader = pa.ipc.RecordBatchFileReader(source)
            schema = reader.schema
            serialized_columns = json.loads(
                schema.metadata.get(b"serialized_columns", "[]")
            )
            for col in serialized_columns:
                schema = schema.set(
                    schema.get_field_index(col), pa.field(col, pa.string())
                )
            schemas[part_path] = schema
    first_schema = schemas[arrow_file_paths[0]]
    if not all(_schema_compatible(first_schema, s) for s in schemas.values()):
        raise ValueError(f"Partitions do not share the same schemas: {schemas}")
    schema_df = first_schema.empty_table().to_pandas()
    if b"serialized_columns" in first_schema.metadata:
        schema_df.attrs["serialized_columns"] = json.loads(
            schema.metadata.get(b"serialized_columns")
        )
    return schema_df


def _schema_compatible(schema1: pa.Schema, schema2: pa.Schema) -> bool:
    # Ideally this would check the field types, but there are a lot of edge cases
    # like int8 vs int16, dictionary key types being different, etc.
    if schema1.names != schema2.names:
        return False
    return True


def read_arrow_columns(
    path: str, storage_options: Optional[Dict[str, Any]] = None
) -> List[str]:
    """Read the column for a file in the arrow format"""
    schema_df = read_schema_df(path, storage_options=storage_options)
    return schema_df.columns.to_list()


# For easy mocking
def _get_reader_num_batches(reader: pa.ipc.RecordBatchFileReader) -> int:
    return reader.num_record_batches


def _set_dict_idx_to_int32(field: pa.Field) -> pa.Field:
    if not isinstance(field.type, pa.DictionaryType):
        return field
    return pa.field(
        field.name,
        pa.dictionary(pa.int32(), field.type.value_type),
        field.nullable,
        field.metadata,
    )


def get_upcasted_categorical_schema(df: pd.DataFrame) -> pa.Schema:
    """Get a schema for a dataframe with categorical columns 'upcasted' to int32
    so we can safely concat multiple similar tables together"""
    schema = pa.Schema.from_pandas(df, preserve_index=True)
    # Use int32 for categorical so we can unify parts without running out of indexes.
    return pa.schema(
        [_set_dict_idx_to_int32(field) for field in schema], metadata=schema.metadata
    )


def read_arrow_col_types(
    path: str, storage_options: Optional[Dict[str, Any]] = None
) -> Optional[Any]:
    """Read the column types for a file in the arrow format"""
    resolved_path = resolve_data_path(path)
    protocol = infer_storage_options(
        resolved_path, inherit_storage_options=storage_options
    )["protocol"]
    paths = _get_arrow_file_paths(
        resolved_path, protocol, storage_options=storage_options
    )
    for path in paths:
        f = get_source_for_arrow_path(path, storage_options=storage_options)
        with f as source:
            reader = pa.ipc.RecordBatchFileReader(source)
            if _get_reader_num_batches(reader) == 0:
                continue
            rb = reader.get_record_batch(0)
            if rb.num_rows == 0:
                continue
            df_types = table_to_pandas(rb.take([0]))
        if TYPES_COL not in df_types:
            logger.warning(
                f"Unable to find types column in df_types={df_types} at path={path}. Returning None"
            )
            return None
        df_types = df_types[TYPES_COL].iloc[0]
        if len(df_types):
            return json.loads(df_types)
    return None


def read_arrow(
    path: str, storage_options: Optional[Dict[str, Any]] = None, **kwargs: Any
) -> dd.DataFrame:
    """Read an ddf from disk that is stored in the arrow format"""
    cols_to_load = kwargs.get("reader_kwargs", {}).get("columns", None)
    convert_categorical_to_object = kwargs.get("convert_categorical_to_object", True)
    resolved_path = resolve_data_path(path)
    with _open_file(
        f"{resolved_path}/{ARROW_META_FILENAME}",
        "rb",
        **(storage_options if storage_options is not None else {}),
    ) as f:
        arrow_meta = pickle.load(f)
    partitions = arrow_meta["npartitions"]
    divisions = arrow_meta["divisions"]
    parts = []
    cols_to_load = kwargs.get("reader_kwargs", {}).get("columns", None)
    resolved_path = resolve_data_path(path)
    for part_num in range(partitions):
        parts.append(
            delayed(read_arrow_as_df)(
                f"{resolved_path}/part_{part_num}.arrow",
                cols_to_load,
                storage_options=storage_options,
                convert_categorical_to_object=convert_categorical_to_object,
            )
        )
    meta = read_schema_df(str(path), storage_options)
    ddf = dd.from_delayed(parts, meta=meta, divisions=divisions, verify_meta=False)
    ddf.attrs = meta.attrs
    return ddf


def get_engine_arrow_file_paths(
    arrow_dir: str, storage_options: Optional[Dict[str, Any]] = None
) -> List[str]:
    fs, path = fsspec.core.url_to_fs(arrow_dir, **(storage_options or {}))
    if fs.isdir(path):
        arrow_files = fs.glob(os.path.join(path, f"part_*.arrow"))
        arrow_files = sorted(
            arrow_files, key=lambda x: int(x.split(".")[-2].split("_")[-1])
        )
    else:
        arrow_files = [path]

    return arrow_files


def get_engine_arrow_metadata(
    arrow_dir: str, storage_options: Optional[Dict[str, Any]] = None
) -> Tuple[int, int, int]:
    """Gets metadata for an Engine Arrow datasource.

    Returns
    -------
    Tuple[int, int, int]
        Tuple of (number of rows, step size in number of rows, average row size). "Step size in number of rows"
        refers to the average number of rows needed to achieve a ARROW_READ_CHUNK_SIZE_MB sized
        chunk.
    """
    arrow_files = get_engine_arrow_file_paths(arrow_dir, storage_options)
    num_rows, row_sizes_bytes = 0, []

    for arrow_file in arrow_files:
        table: pa.Table = read_arrow_as_table(arrow_file, None, storage_options)
        num_rows += table.num_rows
        row_sizes_bytes.append(approx_arrow_row_size(arrow_file, storage_options))

    row_size_bytes = int(sum(row_sizes_bytes) / len(row_sizes_bytes))

    # Not ternary for readability.
    if row_size_bytes:
        step_size = max(ARROW_READ_CHUNK_SIZE_MB * 1_000_000 // row_size_bytes, 1)
    else:
        step_size = num_rows

    return num_rows, step_size, row_size_bytes


def get_engine_arrow_pos_x_uids(
    arrow_dir: str, storage_options: Optional[Dict[str, Any]] = None
) -> pd.DataFrame:
    """Gets the position of all x_uids across all arrow files for an arrow dir.

    Returns
    -------
    pd.DataFrame
        A DataFrame with columns "pos" and "x_uid" containing the position and x_uid
        of all x_uids across all arrow files in the arrow_dir.
    """
    arrow_files = get_engine_arrow_file_paths(arrow_dir, storage_options)
    all_pos_x_uids = []
    offset = 0

    for arrow_file in arrow_files:
        table: pa.Table = read_arrow_as_table(arrow_file, None, storage_options)
        all_pos_x_uids.append(get_pos_x_uids(table, offset=offset))
        offset += table.num_rows

    if all_pos_x_uids:
        return pd.concat(all_pos_x_uids)
    else:
        return pd.DataFrame()


def read_engine_arrow_range(
    start: int,
    stop: int,
    columns: Optional[List[str]],
    arrow_dir: str,
    convert_categorical_to_object: bool = True,
    storage_options: Optional[Dict[str, Any]] = None,
) -> pd.DataFrame:
    """Given a range, returns the slice across partitions of Arrow files.

    Returns
    -------
    pd.DataFrame
        The DataFrame from the range provided by start, stop as if the range were read
        from a contiguous Arrow file.


    Raises
    ------
    Exception
        if start > stop
    Exception
        if start < 0
    """
    if start > stop:
        raise Exception(f"start ({start}) cannot be greater than stop ({stop}).")

    if start < 0:
        raise Exception(f"start ({start}) must be at least 0.")

    start_stop_ranges = [(start, stop)]
    return _read_engine_arrow_ranges(
        start_stop_ranges,
        columns,
        arrow_dir,
        convert_categorical_to_object,
        storage_options,
    )


def read_engine_arrow_x_uids(
    x_uids: Iterable[str],
    arrow_dir: str,
    columns: Optional[List[str]],
    convert_categorical_to_object: bool = True,
    storage_options: Optional[Dict[str, Any]] = None,
    fail_fast: bool = False,
) -> pd.DataFrame:
    """Given a set of x_uids, returns grouped slices across a set of Arrow files.

    Returns
    -------
    pd.DataFrame
        The DataFrame with rows indexed by given x_uids in the set of Arrow files.
    """
    positions = get_engine_arrow_pos_x_uids(arrow_dir, storage_options)
    if fail_fast and positions.empty:
        return pd.DataFrame(columns=columns)
    filtered_x_uids = positions.index.intersection(x_uids)
    positions_to_read = positions.loc[filtered_x_uids, "pos"].tolist()
    df = read_engine_arrow_positions(
        positions_to_read,
        arrow_dir,
        columns,
        convert_categorical_to_object,
        storage_options,
    )
    return df


def read_engine_arrow_positions(
    positions_to_read: List[int],
    arrow_dir: str,
    columns: Optional[List[str]],
    convert_categorical_to_object: bool = True,
    storage_options: Optional[Dict[str, Any]] = None,
    positions_are_sorted: bool = False,
) -> pd.DataFrame:
    offset_length_ranges = get_ranges_for_positional_index(
        positions_to_read, positions_are_sorted
    )

    start_stop_ranges = [
        (offset, offset + length) for offset, length in offset_length_ranges
    ]

    return _read_engine_arrow_ranges(
        start_stop_ranges,
        columns,
        arrow_dir,
        convert_categorical_to_object,
        storage_options,
    )


def _read_engine_arrow_ranges(
    start_stop_ranges: List[Tuple[int, int]],
    columns: Optional[List[str]],
    arrow_dir: str,
    convert_categorical_to_object: bool = True,
    storage_options: Optional[Dict[str, Any]] = None,
) -> pd.DataFrame:
    """Given a List of ranges, returns concatenated slices across all Arrow files.

    CAUTION: These are start-stop ranges, NOT offset-length ranges! I have named
    the parameter to make this extra clear.
    """
    if len(start_stop_ranges) == 0:
        start_stop_ranges = [(0, 0)]

    tables = []
    cursor = 0
    arrow_files = get_engine_arrow_file_paths(arrow_dir, storage_options)

    if not arrow_files:
        raise Exception(
            f"Your directory {arrow_dir} doesn't have any Arrow files. Please check this!"
        )

    done = False

    ptr = 0
    start, stop = start_stop_ranges[ptr]

    for arrow_file in arrow_files:
        table: pa.Table = read_arrow_as_table(arrow_file, columns, storage_options)
        num_rows = table.num_rows

        while start < cursor + num_rows and not done:
            offset = max(cursor, start) - cursor

            if cursor + num_rows < stop:
                read_len = num_rows
                start = cursor + num_rows
            else:
                read_len = min(stop - cursor, num_rows) - offset
                ptr += 1

                if ptr == len(start_stop_ranges):
                    done = True
                else:
                    start, stop = start_stop_ranges[ptr]

            tables.append(table.slice(offset, read_len))

        if done:
            break

        cursor += num_rows

    # If there was at least one Arrow file, then "table" exists.
    if not tables and len(arrow_files) > 0:
        tables.append(table.slice(0, 0))

    # There's an incredibly low chance that the schemas across the tables differ.
    # If this happens, pa.concat_tables will raise an Exception. This means that
    # Arrow files within a datasource have different schemas, which we can't do
    # anything about here other than convert to Pandas first before concatenating.
    try:
        return table_to_pandas(
            pa.concat_tables(tables),
            convert_categorical_to_object=convert_categorical_to_object,
        )
    except pa.lib.ArrowInvalid:
        logger.error(
            f"read_engine_arrow_range at {arrow_dir} raised pyarrow.lib.ArrowInvalid. "
            "Retrying with a different concatenation technique."
        )

        dfs = []
        for table in tables:
            df = table_to_pandas(
                table, convert_categorical_to_object=convert_categorical_to_object
            )

            if not convert_categorical_to_object:
                for col in df.columns:
                    if df[col].dtype.name == "category":
                        df[col] = df[col].cat.remove_unused_categories()

            dfs.append(df)

        return pd.concat(dfs)
