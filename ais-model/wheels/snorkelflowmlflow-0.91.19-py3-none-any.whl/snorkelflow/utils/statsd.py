import json
import os
import socket
import time
from contextlib import contextmanager
from typing import Any, Dict, Generator, List, Optional, Tuple

import re2
import statsd
from pydantic import BaseModel

from snorkelflow.utils.logging import get_logger

logger = get_logger("statsd")
_HOST = os.environ.get("HOSTNAME", "n/a")


class DebugMetric(BaseModel):
    point_type: str
    metric_name: str
    metric: str
    tags: Dict[str, Any]
    value: int


class StatsdClient:
    """
    StatsdClient singleton class, used to interact with the metrics stack.

    The class supports 3 types of metrics: counters, gauges, and timers:

        Counters: Counters are treated as a count of a type of event per second.
            Raw counter values are usually not used -- counters are typically averaged
            over a period of time to produce meaningful statistics. Counters cannot
            be decremented.
            Example: rate of endpoint calls per second.

        Gauges: Gauges are a constant data type. They are not subject to averaging
            and won't change unless the user changes them. Raw gauge number is the
            meaningful metric.
            Example: number of active WebSocket connections.

        Timers: Timers are meant to track how long something took, generally used for
            tracking application performance. The statsd server will calculate averages
            and percentiles for timers.
            Example: elapsed time for job execution.

    TODO: Implement a ttl and eviction pattern for timers.
    TODO: Once we horizontally scale, ensure metric names don't conflict (ensure
        request_id is being sent as a label).
    """

    _instance: Optional["StatsdClient"] = None
    _debug_enabled = False
    _debug_collected_calls: List[DebugMetric] = []

    def __init__(self) -> None:
        """Initialize a StatsdClient object. If the TELEGRAF_URL is None,
        we are not using the metrics stack and each metric function in this
        class will be a no-op.

        This method should never be used directly, use StatsdClient.instance()
        instead.
        """
        self._statsd_client = None
        url, enable_ipv6 = self._get_env_vars()
        if url:
            url, port = self._parse_url_scheme(url)
            try:
                self._statsd_client = self._create_statsd_client(
                    url, int(port), enable_ipv6
                )
            # This catches an error if the ip version is set incorrectly.
            except socket.gaierror as e:
                logger.exception(
                    f"Error with ip version, please confirm the correct IP version is set: {e.strerror}"
                )

        else:
            logger.debug(
                "No value for TELEGRAF_URL configured, will not send metrics to statsd endpoint"
            )

    def _parse_url_scheme(self, url: str) -> Tuple[str, str]:
        URL_SCHEMES = ["http://", "https://"]
        for scheme in URL_SCHEMES:
            if url.startswith(scheme):
                url = url[len(scheme) :]
        # We rpartition here as ipv6 addresses contain colons in them. This will break if an ipv6 address with no port is specified.
        url, _, port = url.rpartition(":")
        return url, port

    # Separated out for better mocking
    def _get_env_vars(self) -> Tuple[Optional[str], bool]:
        """Returns the environment variables for the StatsdClient.

        Returns:
            Tuple[str, bool]: Tuple of (TELEGRAF_URL, ENABLE_IPV6)
        """
        url = os.environ.get("TELEGRAF_URL", None)
        enable_ipv6: bool = os.environ.get("ENABLE_IPV6", "False").lower() == "true"
        return url, enable_ipv6

    # Separated out for better mocking
    def _create_statsd_client(
        self, url: str, port: int, enable_ipv6: bool
    ) -> statsd.StatsClient:
        return statsd.StatsClient(url, port, ipv6=enable_ipv6)

    @classmethod
    def instance(cls) -> "StatsdClient":
        """Creates and returns a new StatsdClient if it doesn't yet exist. If
        an instance already exists, return it.

        Returns:
            StatsdClient: An instance of the StatsdClient
        """
        if cls._instance is None:
            cls._instance = StatsdClient()
        return cls._instance

    def _dict_to_str(self, tags: Dict[str, Any]) -> str:
        def _clean(value: str) -> str:
            # Colons and commas are reserved characters in statsd tags
            return re2.sub(r"[:,]", "_", str(value))

        return ",".join([f"{key}={_clean(value)}" for key, value in tags.items()])

    def _metric_name(
        self, name: str, tags: Dict[str, Any], include_hostname: bool
    ) -> str:
        if include_hostname:
            tags["hostname"] = _HOST
        if not tags:
            return name
        metric_name = f"{name},{self._dict_to_str(tags)}"
        metric_name_clean = re2.sub(r"[^\x00-\x7f]", "-", metric_name)
        return metric_name_clean

    def counter_incr(
        self,
        metric: str,
        amount: int = 1,
        tags: Optional[Dict[str, Any]] = None,
        include_hostname: bool = False,
    ) -> None:
        """Increment a counter.

        Args:
            metric: The name of the metric being incremented
            tags: A dict of tags attached to the metric (e.g. job_id: 1)
            amount: Amount to increment the metric by
            include_hostname_tag: Whether to include the hostname as a tag
        Returns:
            None
        """
        if tags is None:
            tags = {}
        counter_set = self._metric_name(metric, tags, include_hostname)
        logger.debug(f"sending counter {counter_set} {amount}")
        if self._debug_enabled:
            self._debug_collected_calls.append(
                DebugMetric(
                    point_type="counter",
                    metric_name=counter_set,
                    metric=metric,
                    tags=tags,
                    value=amount,
                )
            )
        if self._statsd_client:
            self._statsd_client.incr(counter_set, amount)

    def gauge_set(
        self,
        metric: str,
        amount: float,
        tags: Optional[Dict[str, Any]] = None,
        include_hostname_tag: bool = False,
    ) -> None:
        """Set a gauge to a value.

        Args:
            metric: The name of the gauge metric being set
            tags: A dict of tags attached to the metric (e.g. job_id: 1)
            amount: Amount to set the metric to
            include_hostname_tag: Whether to include the hostname as a tag
        Returns:
            None
        """
        if tags is None:
            tags = {}
        gauge_set = self._metric_name(metric, tags, include_hostname_tag)
        logger.debug(f"sending gauge {gauge_set} {amount}")
        if self._debug_enabled:
            self._debug_collected_calls.append(
                DebugMetric(
                    point_type="gauge",
                    metric_name=gauge_set,
                    metric=metric,
                    tags=tags,
                    value=amount,
                )
            )
        if self._statsd_client:
            self._statsd_client.gauge(gauge_set, amount)

    def timer_set(
        self,
        metric: str,
        milliseconds: int,
        tags: Optional[Dict[str, Any]] = None,
        include_hostname_tag: bool = False,
    ) -> None:
        """Set a timer to a value.

        Args:
            metric: The name of the timer metric being set
            tags: A dict of tags attached to the metric (e.g. job_id: 1)
            milliseconds: Time in milliseconds to set the timer metric to
            include_hostname_tag: Whether to include the hostname as a tag
        Returns:
            None
        """
        if tags is None:
            tags = {}
        timing_str = self._metric_name(metric, tags, include_hostname_tag)
        logger.debug(f"sending timing {timing_str} {milliseconds}")
        if self._debug_enabled:
            self._debug_collected_calls.append(
                DebugMetric(
                    point_type="timer",
                    metric_name=timing_str,
                    metric=metric,
                    tags=tags,
                    value=milliseconds,
                )
            )
        if self._statsd_client:
            self._statsd_client.timing(timing_str, milliseconds)

    @contextmanager
    def timer(
        self,
        *,
        metric: str,
        tags: Optional[Dict[str, Any]] = None,
        include_hostname_tag: bool = False,
    ) -> Generator:
        if tags is None:
            tags = {}
        logger.debug(f" start: {tags}")
        start = time.time()
        try:
            yield
        finally:
            logger.debug(f" end: {tags}")
            total_time = round((time.time() - start) * 1000)
            self.timer_set(metric, total_time, tags, include_hostname_tag)

    def toggle_debug(self, debug: bool) -> None:
        self._debug_enabled = debug
        self._debug_collected_calls = []

    def debug_flush(self, file_: str) -> None:
        if self._debug_enabled:
            with open(file_, "w") as f:
                f.write(json.dumps([c.metric for c in self._debug_collected_calls]))


stats = StatsdClient.instance()
