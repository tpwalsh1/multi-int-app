import gzip
import json
from typing import Any, Callable, Dict, Optional

import requests

MIN_SIZE_FOR_COMPRESSION = 100_000
METHOD_TO_FN: Dict[str, Callable] = {
    "GET": requests.get,
    "PATCH": requests.patch,
    "POST": requests.post,
    "PUT": requests.put,
    "DELETE": requests.delete,
}


def request_with_gzip(
    url: str,
    data: Any = None,
    headers: Optional[dict] = None,
    files: Any = None,
    method: str = "POST",
    params: Optional[Dict[str, str]] = None,
) -> requests.Response:
    headers = headers or {}
    data = data or {}
    headers["accept-encoding"] = "gzip"
    if method == "GET":
        response = METHOD_TO_FN[method](url, headers=headers, data=data, params=params)
    elif method == "DELETE":
        response = METHOD_TO_FN[method](url, headers=headers, data=data)
    elif method in {"PATCH", "POST", "PUT"}:
        if files is None:
            data_str = json.dumps(data).encode()
            headers["content-type"] = "application/json"
            if len(data_str) > MIN_SIZE_FOR_COMPRESSION:
                data_str = gzip.compress(data_str)  # type: ignore
                headers["content-encoding"] = "gzip"
            data = data_str
        response = METHOD_TO_FN[method](url, headers=headers, data=data, files=files)
    else:
        raise ValueError(f"Unsupported method {method}")
    return response
