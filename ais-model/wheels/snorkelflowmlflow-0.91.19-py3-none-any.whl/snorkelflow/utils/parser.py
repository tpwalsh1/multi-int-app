from typing import Dict


# Split the function to make mypy happy
def parse_label_map_str(map_str: str) -> Dict[str, int]:
    """Parse map str in form 'SPAM=1,HAM=0,UNKNOWN=-1' into a dict."""
    label_map: Dict[str, int] = {}
    format_error_msg = "Must consist of comma separated <str>=<int> pairs."
    for kv in map_str.split(","):
        pair = kv.split("=")
        assert len(pair) == 2, format_error_msg
        try:
            label_map[pair[0]] = int(pair[1])
        except ValueError:
            # Raise error if pair[1] is not castable to int.
            raise ValueError(format_error_msg)

    return label_map


# Split the function to make mypy happy
def parse_str_to_str_map(map_str: str) -> Dict[str, str]:
    """Parse map str in form 'OLD_LABEL=NEW_LABEL' into a dict."""
    label_map: Dict[str, str] = {}
    format_error_msg = "Must consist of comma separated <str>=<str> pairs."
    for kv in map_str.split(","):
        pair = kv.split("=")
        assert len(pair) == 2, format_error_msg
        label_map[pair[0]] = pair[1]
    return label_map
