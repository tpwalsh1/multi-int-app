from typing import List

from PIL import Image

from api_utils.exceptions import SnorkelException
from snorkelflow.utils.file import resolve_data_path
from snorkelflow.utils.logging import get_logger

logger = get_logger("load_image")


def load_minio_image(minio_url: str) -> Image.Image:
    try:
        image = Image.open(resolve_data_path(minio_url))
    except Exception as e:
        user_friendly_message = (
            f"Could not open image path '{minio_url}'. "
            "Please double check if image at path exists and is valid."
        )
        detailed_message = (
            f"Could not open image path '{minio_url}' "
            f"which resolves to path '{resolve_data_path(minio_url)}'. "
            "Please double check if image at path exists and is valid."
        )
        logger.error(detailed_message)
        raise SnorkelException(
            detail=detailed_message, user_friendly_message=user_friendly_message
        ) from e

    return image


def load_cropped_minio_image(minio_url: str, coords: List[float]) -> Image.Image:
    return load_minio_image(minio_url).crop(coords)
