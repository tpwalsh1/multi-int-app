import copy
import logging
import logging.handlers
import os
from logging import LogRecord

try:
    # this is much faster, not sure why it doesn't work for importing
    import re2 as re
except Exception:
    import re  # type: ignore
import sys
import time
import warnings
from contextlib import contextmanager, nullcontext
from contextvars import ContextVar
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Generator, Iterator, List, Optional, Tuple, Union

from snorkelflow.utils.file import CONTAINER_VOLUME_DATA_PATH
from snorkelflow.utils.logging_event import FilteredLogReader, LogEvent, LogFilter

try:
    from filelock import FileLock

    ROTATION_LOCK_ENABLED = True
except ImportError:
    ROTATION_LOCK_ENABLED = False

warnings.filterwarnings(action="ignore", category=SyntaxWarning)

warnings.filterwarnings(action="ignore", category=FutureWarning)

# To suppress redis warning
warnings.filterwarnings(action="ignore", message="redis-py works best with hiredis")

_log_ctx: Any = ContextVar("log_ctx", default=[])
_log_immutable_ctx: ContextVar[Dict[str, Any]] = ContextVar(
    "log_immutable_ctx", default=dict()
)

MAX_SINGLE_LINE_LENGTH = 1024 * 200  # 200KB


def managed_log_directory() -> Path:
    """
    Directory where logs are expected to live. set_up_logging will accept
    a path to any location, however logs are strongly encouraged to live
    somewhere in the filetree under this directory.
    """
    return Path(CONTAINER_VOLUME_DATA_PATH) / ".logs"


def job_log_directory() -> Path:
    """
    Directory where job logs live. Note that the structure of this directory
    is subject to change.
    """
    return managed_log_directory() / "jobs"


def job_log_file(job_id: str) -> Path:
    """
    Return the log file location associated with a job. Note this may change
    in the future if using an obscured filepath.
    """
    return job_log_directory() / job_id


@dataclass(frozen=True)
class IgnoredRoute:
    method: str
    path: str
    # If set to true, will check if request path is prefixed with the given path
    # If set to false, will check for exact match
    match_prefix: bool = True

    def should_ignore(self, request_method: str, request_path: str) -> bool:
        if self.method != request_method:
            return False
        if self.match_prefix:
            return request_path.startswith(self.path)
        else:
            return self.path == request_path


def _get_ignored_routes() -> List[IgnoredRoute]:
    # Ideally this would be a global var, but sphinx-build errors out due to mocking issues
    return [
        IgnoredRoute("GET", "/", match_prefix=False),
        IgnoredRoute("GET", "/jobs/"),
        IgnoredRoute("GET", "/current-user"),
        IgnoredRoute("GET", "/license"),
        IgnoredRoute("GET", "/healthcheck"),
    ]


@contextmanager
def log_ctx(**kwargs: Any) -> Iterator[Any]:
    old_ctx = _log_ctx.get()
    _log_ctx.set(old_ctx + list(kwargs.items()))
    try:
        yield
    finally:
        _log_ctx.set(old_ctx)


def from_log_ctx(key: str) -> Any:
    for k, v in reversed(_log_ctx.get()):
        if k == key:
            return v
    return None


def get_log_context_vars() -> Generator[Tuple[str, Any], None, None]:
    yield from _log_ctx.get()
    yield from _log_immutable_ctx.get().items()


def set_immutable_log_ctx(**kwargs: Any) -> None:
    """
    For immutable context vars that once set, last for the entire
    lifetime of the API request or engine job. Differs from
    contextmanager-based log_ctx in that log_ctx removes context
    vars once the scope of the contextmanager is exited.
    """
    # https://docs.python.org/3/library/contextvars.html
    # default in contextvar references to the same object so we need to
    # make a copy to prevent polluting the contextvar
    old_immutable_ctx = copy.deepcopy(_log_immutable_ctx.get())
    for key, value in kwargs.items():
        old_immutable_ctx[key] = value
    _log_immutable_ctx.set(old_immutable_ctx)


def clear_immutable_log_ctx() -> None:
    _log_immutable_ctx.set(dict())


# for testing
def get_immutable_log_ctx() -> Dict[str, Any]:
    return _log_immutable_ctx.get()


def set_up_logging(
    log_file_path: Optional[Path] = None,
    level: int = int(os.getenv("SNORKELFLOW_LOGLEVEL", logging.INFO)),
    remove_existing_handlers: bool = True,
) -> None:
    # Check that data path matches log file location
    data_path = Path(CONTAINER_VOLUME_DATA_PATH)

    if log_file_path is not None and data_path not in Path(log_file_path).parents:
        raise RuntimeError(
            f"log file path {log_file_path} not in data volume {data_path}, cannot configure logging"
        )

    "Configure root logger"
    logger = logging.getLogger()

    # Filter function to ignore specific endpoint logs from spamming the logs
    def filter_ignores(record: logging.LogRecord) -> bool:
        record_dict = record.__dict__
        request_path: Optional[str] = record_dict.get("path")

        # Log message not involved with START/END_REQUEST
        if request_path is None:
            return True

        request_method = record_dict["method"]
        # If status_code not set, this is a request start log
        # Always log END_REQUEST's for error responses
        if record_dict.get("status_code", 0) >= 400:
            return True

        for ignored_route in _get_ignored_routes():
            if ignored_route.should_ignore(request_method, request_path):
                return False
        return True

    def add_context_filter(record: Any) -> bool:
        record.context = ", ".join(f"{k}:{v}" for k, v in get_log_context_vars())
        return True

    def _configure_handler(handler: logging.Handler) -> None:
        handler.setLevel(level)
        handler.addFilter(filter_ignores)
        handler.addFilter(add_context_filter)
        # NOTE: The reason for the two '|' bars between %(context)s is deliberate, and is used
        # in the logic of "parse_context_vars"
        fmt = (
            "%(levelname)s %(asctime)s.%(msecs).03d %(process)d %(threadName)s %(filename)s:%(lineno)d"
            " | %(context)s | %(message)s"
        )

        class Formatter(logging.Formatter):
            """override logging.Formatter to use UTC time"""

            def converter(self, timestamp: Optional[float]) -> Any:
                return time.gmtime(timestamp)

        formatter = Formatter(fmt, datefmt="%Y-%m-%d %H:%M:%S")
        handler.setFormatter(formatter)

    logger.setLevel(level)
    # Remove existing handlers except for test-related handlers
    # TODO: Is there a better way to remove all handlers except the one that may be injected into tests?
    if remove_existing_handlers:
        logger.handlers = [
            handler
            for handler in logger.handlers
            if type(handler).__name__ == "LogCaptureHandler"
        ]

    # Configure stdout logging
    stdout_handler = logging.StreamHandler(sys.stdout)
    logger.addHandler(stdout_handler)

    if log_file_path is not None:
        if data_path.exists():
            # make both the logs subdirectories.
            Path(log_file_path).parent.mkdir(exist_ok=True)

            # Rotate log file when it reaches 100MB, keep 7 logs around
            file_logger = get_file_handler(log_file_path)
            logger.addHandler(file_logger)
        else:
            # This is possible if we don't mount the data volume. This should only happen
            # if we're running a python script in the engine container
            logger.warning("Unable to find log volume. Not logging to file.")

    for handler in logger.handlers:
        _configure_handler(handler)


def get_logger(name: Optional[str] = None) -> logging.Logger:
    logger = logging.getLogger(name)
    # Remove log handlers and propagate to root logger.
    logger.handlers = []
    logger.propagate = True
    return logger


def get_file_handler(log_file_path: Union[str, Path]) -> logging.Handler:
    return _NFSLogFileHandler(log_file_path, maxBytes=100 * 1000**2, backupCount=7)


def parse_context_vars(logline: str) -> Dict[str, str]:
    # Edge cases:
    # If an extra space or "|" is used somewhere in the context args, which
    # would break assumptions made by this parser

    # However, this should be safe, since we filter out every line by default,
    # that is, this won't cause us to expose logs that we don't intend to,
    # but rather to not expose logs that we did intend to
    begin_contexts = 0
    while begin_contexts < len(logline):
        if logline[begin_contexts] == "|":
            break
        begin_contexts += 1

    # account for the space that comes after the "|"
    begin_contexts += 2

    end_contexts = begin_contexts
    while end_contexts < len(logline):
        if logline[end_contexts] == "|":
            break
        end_contexts += 1

    # Failed to parse the conetxt_vars properly for this logline
    if end_contexts == len(logline):
        return {}

    # account for the second space that comes before the second "|"
    end_contexts -= 1

    res = {}
    entries = logline[begin_contexts:end_contexts].split(", ")
    for entry in entries:
        pairs = entry.split(":")
        if len(pairs) == 2:
            key, val = pairs
            res[key] = val

    return res


def match_regexes(grep_regexes: Optional[List[str]], logline: str) -> bool:
    if grep_regexes is None:
        return True
    for grep_regex in grep_regexes:
        if not re.search(grep_regex, logline):
            return False
    else:
        return True


def match_workspace_uid(workspace_uid: Optional[int], context: Dict[str, str]) -> bool:
    if workspace_uid is None:
        return True
    if "workspace_uid" in context:
        return context["workspace_uid"] == str(workspace_uid)
    return False


def match_job_id(job_id: Optional[str], context: Dict[str, str]) -> bool:
    if job_id is None:
        return True
    if "job_id" in context:
        return context["job_id"] == job_id
    return False


def is_log_within_start_and_end_time(
    start_time: Optional[datetime],
    end_time: Optional[datetime],
    context: Dict[str, str],
) -> bool:
    curr_time = _timestamp_to_datetime(context.get("timestamp"))
    if curr_time is None:
        return False
    if start_time is not None and curr_time < start_time:
        return False
    if end_time is not None and curr_time > end_time:
        return False
    return True


def format_log_event(log_event: LogEvent) -> str:
    logline = log_event.logline
    log_path = log_event.log_path
    return f"[{log_path.name}] {_maybe_truncate(logline)}"


def _maybe_truncate(line: str) -> str:
    if len(line) > MAX_SINGLE_LINE_LENGTH:
        return line[:MAX_SINGLE_LINE_LENGTH] + "... \n"
    return line


def _timestamp_to_datetime(timestamp: Optional[str]) -> Optional[datetime]:
    if timestamp is None:
        return None
    return datetime.strptime(timestamp, "%Y-%m-%d %H:%M:%S.%f")


def is_timestamp_earlier_than_start(
    start_time: Optional[datetime], event: LogEvent
) -> bool:
    curr_timestamp = _timestamp_to_datetime(event.context.get("timestamp"))
    if start_time is None or curr_timestamp is None:
        return False
    return curr_timestamp < start_time


def filter_log_file(
    path: str,
    grep_regexes: Optional[List[str]] = None,
    workspace_uid: Optional[int] = None,
    tail_n: Optional[int] = None,
    rotate_logs: bool = True,
) -> str:
    # handle default args
    if all(x is None for x in [grep_regexes, workspace_uid, tail_n]):
        # if all args None, return entire log
        res = _filter_log_file(path)
    else:
        if grep_regexes is not None and tail_n is None:
            tail_n = 10

        if grep_regexes is None:
            grep_regexes = []

        res = _filter_log_file(path, grep_regexes, workspace_uid, tail_n, rotate_logs)

    return "".join(res)


def _filter_log_file(
    path: str,
    grep_regexes: Optional[List[str]] = None,
    workspace_uid: Optional[int] = None,
    tail_n: Optional[int] = None,
    rotate_logs: bool = True,
) -> List[str]:
    # create filters:
    grep_regexes_filter = lambda logline: match_regexes(grep_regexes, logline)
    workspace_uid_filter = lambda context: match_workspace_uid(workspace_uid, context)

    log_filter = LogFilter(
        context_filters=[workspace_uid_filter], line_filters=[grep_regexes_filter]
    )
    log_reader = FilteredLogReader(
        path, logging_filter=log_filter, rotate_logs=rotate_logs
    )

    # eventually deprecate tail_n
    i = 0
    filtered_logs = []
    filtered_log_iterator = log_reader.get_filtered_log_event()
    while tail_n is None or i < tail_n:
        try:
            filtered_log_event = next(filtered_log_iterator)
            filtered_logs.append(format_log_event(filtered_log_event))
            i += 1
        except StopIteration:
            return list(reversed(filtered_logs))
    return list(reversed(filtered_logs))


def filter_log_file_v2(
    path: str,
    start_time: Optional[datetime] = None,
    end_time: Optional[datetime] = None,
    job_id: Optional[str] = None,
) -> str:
    return "".join(_filter_log_file_v2(path, start_time, end_time, job_id))


def _filter_log_file_v2(
    path: str,
    start_time: Optional[datetime] = None,
    end_time: Optional[datetime] = None,
    job_id: Optional[str] = None,
) -> List[str]:
    # create filters:
    time_filter = lambda context: is_log_within_start_and_end_time(
        start_time, end_time, context
    )
    job_id_filter = lambda context: match_job_id(job_id, context)
    should_terminate_early = lambda event: is_timestamp_earlier_than_start(
        start_time, event
    )

    log_filter = LogFilter(
        context_filters=[job_id_filter, time_filter], line_filters=[]
    )
    log_reader = FilteredLogReader(
        path,
        logging_filter=log_filter,
        rotate_logs=True,
        should_terminate_early=should_terminate_early,
    )

    filtered_logs = []
    for filtered_log_event in log_reader.get_filtered_log_event():
        filtered_logs.append(format_log_event(filtered_log_event))

    return list(reversed(filtered_logs))


class _NFSLogFileHandler(logging.handlers.RotatingFileHandler):
    """Wrapper around rotating log file handler that can handle NFS OSErrors
    The two we are aware of are
    116 - Stale file handle
    16 - Device or resource busy

    Only 116 appears to stay around once it starts, while 16 goes away by itself.

    The handleError method override is inspired by logging.handlers.SocketHandler, which closes the socket
    on error

    While SocketHandler closes the socket on ANY error and swallows the exception, we chose to limit the scope
    to the particular OSErrors we've noticed just to limit the impact of our change.
    """

    def __init__(self, filename: Union[str, Path], *args: Any, **kwargs: Any):
        super().__init__(filename, *args, **kwargs)

        # A FileLock should be safe for Unix environments, even if the process gets killed
        if ROTATION_LOCK_ENABLED:
            self._rotate_lock = FileLock(str(filename) + ".lock")
        else:
            self._rotate_lock = nullcontext()

    def handleError(self, record: logging.LogRecord) -> None:
        _, e, _ = sys.exc_info()
        if isinstance(e, OSError) and self.stream and e.errno in [116]:
            self._closeStream()
        super().handleError(record)

    def emit(self, record: LogRecord) -> None:
        """Perform record emission with minimal file-locking"""
        try:
            if self.shouldRollover(record):
                self._doSafeRollover(record)
            logging.FileHandler.emit(self, record)
        except Exception:
            self.handleError(record)

    def _doSafeRollover(self, record: LogRecord) -> None:
        """A multiprocess-safe version of RotatingFileHandler.doRollover

        When we occasionally decide to rotate logs, acquire a lock to make sure we don't rotate the file
        multiple times
        """

        # Reset the stream to the most recent version of the file. Since we've hit this method, we've already
        # determined the current file is definitely too large
        self._closeStream()

        # With the rotation lock, check whether the current new version of the file actually needs to be rotated
        with self._rotate_lock:
            if self.shouldRollover(record):
                super().doRollover()

    def _closeStream(self) -> None:
        if not self.stream:
            return

        try:
            self.stream.close()
        except Exception:
            pass
        self.stream = None  # type: ignore
