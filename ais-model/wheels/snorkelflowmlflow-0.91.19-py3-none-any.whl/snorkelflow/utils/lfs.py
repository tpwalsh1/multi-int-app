import copy
from collections import OrderedDict
from typing import Any, Dict, List, Optional

import pandas as pd

from snorkelflow.lfs import LF


class LFWrapper:
    def __init__(self, lf: Any, fault_tolerant: bool, label_space: Any):
        self.lf = lf
        self.fault_tolerant = fault_tolerant
        self.fault_value: Any = label_space.get_raw_unknown_label()

    def _apply_to_row(self, x: Any) -> Any:
        if not self.fault_tolerant:
            return self.lf(x)
        try:
            return self.lf(x)
        except Exception:
            return self.fault_value

    def apply(self, df: pd.DataFrame) -> pd.Series:
        return df.apply(self._apply_to_row, 1)


def get_lf_sig(lf_config: Dict[str, Any], standardize_case: bool = False) -> int:
    # Get an LF "signature" that can be used to compare LFs.
    # This is not meant to be __hash__() because we ignore its name here.

    # Convert lf_config templates to be all lower (case insensitive)
    lf_config_for_hash = copy.deepcopy(lf_config)
    if standardize_case is True and "templates" in lf_config_for_hash:
        for template in lf_config_for_hash["templates"]:
            for key, val in template.items():
                if isinstance(val, str):
                    template[key] = val.lower()
                elif isinstance(val, list):
                    template[key] = [
                        v.lower() if isinstance(v, str) else v for v in val
                    ]

    # Sort keys in each template to become insensitive to the order
    sorted_templates: Optional[List[Dict[str, Any]]] = (
        [
            OrderedDict(sorted(template.items()))
            for template in lf_config_for_hash["templates"]
        ]
        if "templates" in lf_config_for_hash
        else None
    )
    sorted_multipolar_template: Optional[Dict[str, Any]] = (
        OrderedDict(sorted(lf_config_for_hash["multipolar_template"].items()))
        if "multipolar_template" in lf_config_for_hash
        else None
    )

    lf = LF(
        name="dummy",  # Don't factor in name
        label=lf_config_for_hash.get("label", None),
        templates=sorted_templates,
        multipolar_template=sorted_multipolar_template,
        graph=lf_config_for_hash.get("graph", ["$OR", 0]),
        is_trusted=lf_config_for_hash.get("is_trusted", False),
    )
    return hash(lf.__repr__())
