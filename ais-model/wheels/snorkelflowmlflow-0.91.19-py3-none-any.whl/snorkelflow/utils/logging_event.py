from pathlib import Path
from typing import Callable, Dict, Iterator, List, Optional, Tuple

try:
    import re2 as re
except Exception:
    import re  # type: ignore

ContextFilter = Callable[[Dict[str, str]], bool]
LineFilter = Callable[[str], bool]


class LogEvent:
    def __init__(self, logline: str, path: Path):
        self.context = self.parse_context_vars(logline)
        timestamp = self._parse_timestamp(logline)
        if timestamp is not None:
            self.context["timestamp"] = timestamp

        self.logline = logline
        self.log_path = path

    def _parse_timestamp(self, logline: str) -> Optional[str]:
        # Extract timestamp using a regular expression
        timestamp_regex = r"\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}\.\d{3}"
        timestamp_match = re.search(timestamp_regex, logline)

        if timestamp_match:
            return timestamp_match.group(0)
        else:
            return None

    def parse_context_vars(self, logline: str) -> Dict[str, str]:
        # find the start and end positions of the context variables
        begin_contexts = logline.find("|") + 2
        end_contexts = logline.find("|", begin_contexts) - 1

        # since find returns -1 on failure, if either fails we should quit out
        if begin_contexts == 1 or end_contexts == -2:
            return {}

        # extract the context variables and store them in a dictionary
        res = {}
        entries = logline[begin_contexts:end_contexts].split(", ")
        for entry in entries:
            # split on only the first colon
            split_entry = entry.split(":", 1)
            if len(split_entry) == 2:
                key, val = split_entry
                res[key] = val

        return res


class LogFilter:
    def __init__(
        self,
        context_filters: Optional[List[ContextFilter]] = None,
        line_filters: Optional[List[LineFilter]] = None,
    ) -> None:
        if context_filters is not None:
            self.context_filters = context_filters
        else:
            self.context_filters = []
        if line_filters is not None:
            self.line_filters = line_filters
        else:
            self.line_filters = []

    def _apply_line_filters(self, line: str) -> bool:
        return all(map(lambda filter: filter(line), self.line_filters))

    def _apply_context_filters(self, context: Dict[str, str]) -> bool:
        return all(map(lambda filter: filter(context), self.context_filters))

    def apply_all_filters(self, log: LogEvent) -> bool:
        return self._apply_line_filters(log.logline) and self._apply_context_filters(
            log.context
        )


EarlyTermination = Callable[[LogEvent], bool]


# Basically, we have three streams
# Stream 1: reading in from the files
# Stream 2: ingests from stream 1, yields new multiline
# Stream 3: ingests from stream 2, applies filter
# Early termination takes in a LogEvent and tells the iterator when to close
class FilteredLogReader:
    def __init__(
        self,
        path: str,
        logging_filter: LogFilter,
        rotate_logs: bool = True,
        should_terminate_early: Optional[EarlyTermination] = None,
    ):
        self.path = path
        self.logging_filter = logging_filter
        self.all_paths = self._get_all_log_paths(rotate_logs)
        self.should_terminate_early = should_terminate_early

    def _get_all_log_paths(self, rotate_logs: bool) -> List[Path]:
        current_path = Path(self.path)
        # deprecate rotate_logs later
        if not rotate_logs:
            return [current_path]
        glob_str = f"{current_path.name}.*"
        all_paths = sorted(
            current_path.parent.glob(glob_str),
            key=lambda path: path.name.split(".")[-1],
        )
        return [current_path] + all_paths

    # parse log file into log lines
    def _parse_log_files(self) -> Iterator[Tuple[Path, str]]:
        for path in self.all_paths:
            try:
                with open(path, "r") as f:
                    for line in reversed(f.readlines()):
                        yield (path, line)
            except UnicodeDecodeError:
                pass

    # expects logs to be in reversed order
    def _get_multiline_logs(self) -> Iterator[LogEvent]:
        # A single logging statement output may span multiple lines. We gather
        # them into a single line_group and join before filtering
        # NOTE: We are processing the log in reverse!
        line_group: List[str] = []
        loglevels = ["DEBUG", "INFO", "WARN", "ERROR", "CRITICAL"]
        for path, line in self._parse_log_files():
            line_group.append(line)
            if any(line.startswith(x) for x in loglevels):
                yield LogEvent("".join(reversed(line_group)), path)
                line_group = []

    # expects multiline logs
    def get_filtered_log_event(self) -> Iterator[LogEvent]:
        for event in self._get_multiline_logs():
            if self.should_terminate_early is not None and self.should_terminate_early(
                event
            ):
                break
            if self.logging_filter.apply_all_filters(event):
                yield event
