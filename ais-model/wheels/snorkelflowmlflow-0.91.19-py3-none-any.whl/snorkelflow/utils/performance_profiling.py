import time
from collections import OrderedDict
from logging import Logger
from typing import Any, Callable, Dict, Optional, Tuple

import numba  # type: ignore

_TIME_SEC = "time (sec)"
_TIME_PERCENT = "% total time"


def logging_jit(logger: Optional[Logger] = None) -> Any:
    """Decorator for logging JIT (just in time) compilation events and times

    Args:
        logger (Optional[Logger], optional): Logger instance. Defaults to None, in which case information is simply printed out.

    """
    stdout_func = print if logger is None else logger.info

    def recording_jit(func: Callable) -> Any:
        def inner(*args, **kwargs) -> Any:  # type: ignore
            dt = 0.0
            num_compilations = 0
            oldcomp = numba.core.registry.CPUDispatcher.compile

            def newcomp(*args, **kwargs) -> None:  # type: ignore
                nonlocal num_compilations, dt
                num_compilations += 1
                t0 = time.time()
                comp = oldcomp(*args, **kwargs)
                dt += time.time() - t0
                return comp

            numba.core.registry.CPUDispatcher.compile = newcomp
            result = func(*args, **kwargs)

            stdout_func(f"Number JIT compilations in numba: {num_compilations}")  # type: ignore
            stdout_func(f"Est total JIT compilation time in numba (sec): {round(dt,2)}")  # type: ignore
            return result

        return inner

    return recording_jit


class PerfTimeLog:
    def __init__(self, name: str = "", decimal_places: int = 2) -> None:
        """Simple utility for flexibly profiling code blocks and summarizing results in the log.

        Args:
            name (str, optional): Name of the profiler (gets printed to log). Defaults to "".
            decimal_places (int, optional): For rounding results in printout. Defaults to 2.

        Example use:

        >>> from snorkelflow.utils.performance_profiling import PerfTimeLog
        >>> perf_time_log = PerfTimeLog("Example", decimal_places=2)
        >>> x = "Hello world"
        >>> perf_time_log.update("Assignment of hello world to x")
        >>> x = [True]*100_000
        >>> perf_time_log.update("Creation of pointless list")
        >>> time.sleep(1)
        # Ignoring the sleep as we might want to ignore some code blocks
        # or get a precise read-out of the next block. But it will get factored
        # into total.
        >>> perf_time_log.reset()
        >>> x = [True]*100_000
        >>> perf_time_log.update("Creation of pointless list again")
        >>> print(perf_time_log.pretty_summary())
        Example PERF LOG (total time=1.0 sec)
                                        time (sec)  % total time
        Assignment of hello world to x           0.0          0.16
        Creation of pointless list               0.0          0.02
        Creation of pointless list again         0.0          0.06
        """
        self.name = name
        self.decimal_places = decimal_places
        self.perf = OrderedDict()  # type: ignore
        self.t0 = time.time()
        self.step = 0
        self.reset()

    def reset(self) -> None:
        self.t_prev = time.time()

    def update(self, description: str) -> None:
        if description not in self.perf:
            self.perf[description] = {_TIME_SEC: 0}

        t_curr = time.time()
        dt = t_curr - self.t_prev
        self.perf[description][_TIME_SEC] += dt
        self.t_prev = t_curr

    def summary(self) -> Tuple[Dict, float]:
        self.reset()
        total_time = time.time() - self.t0

        perf = {
            k: {_TIME_SEC: v[_TIME_SEC], _TIME_PERCENT: 100 * v[_TIME_SEC] / total_time}
            for k, v in self.perf.items()
        }
        return perf, total_time

    def pretty_summary(self) -> str:
        perf, total_time = self.summary()
        max_key_length = max([len(k) for k in perf.keys()]) if perf else 0
        header = f"\n{self.name} PERF TIME LOG (total time={round(total_time, self.decimal_places)} sec)\n"
        header += f"{'':<{max_key_length}}  {_TIME_SEC}  {_TIME_PERCENT}\n"
        return header + "\n".join(
            [
                f"{k:<{max_key_length}}  {round(v[_TIME_SEC], self.decimal_places):>{len(_TIME_SEC)}}  {round(v[_TIME_PERCENT], self.decimal_places):>{len(_TIME_PERCENT)}}"
                for k, v in perf.items()
            ]
        )
