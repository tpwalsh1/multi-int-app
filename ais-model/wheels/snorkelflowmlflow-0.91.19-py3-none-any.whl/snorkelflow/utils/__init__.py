"""Other general utilities."""
from .file import open_file, resolve_data_path  # noqa: F401
