from copy import copy
from typing import Any, Dict, Iterable, List, Optional, Tuple, Type, Union

import dask.dataframe as dd
import pandas as pd

from snorkelflow.extraction.span import SpanCols
from snorkelflow.types.load import DATAPOINT_UID_COL

DATAPOINT_TYPES: Dict[str, Type["DatapointType"]] = {}
# NOTE: using DELIMITER constant was a partial change, changing from comma to something else
# will require additional test fixes
DATAPOINT_UID_DELIMITER = ","
COLS_NOT_CONTAINING_DELIMITER = [
    SpanCols.SPAN_FIELD,
    SpanCols.SPAN_FIELD_VALUE_HASH,
    SpanCols.SPAN_ENTITY,
]


class InvalidUIDError(ValueError):
    pass


class InferrenceError(ValueError):
    pass


class DatapointType:
    """Defines a single datapoint types, including the required columns for
    that datapoint type and methods to parse and generate x_uids for that datapoint
    type

    datapoint_uid format:
        name::<delimiter-separated list of values for columns>

    NOTE: any set of columns can be passed to the constructor. The default columns will
    be used if none are passed.
    """

    # The name used when creating x_uids or indexing into dictionaries
    name: str

    # Columns that appear in the datapoint
    columns: List[str] = []

    def __init_subclass__(cls, **kwargs: Any) -> None:
        """Define init subclass to register all subclasses in DATAPOINT_TYPES."""
        super(cls).__init_subclass__(**kwargs)  # type: ignore
        # Skip the base class, it can't be initialized below
        if cls.__name__ == DatapointType.__name__:
            return

        DATAPOINT_TYPES[cls().name] = cls

    def __init__(self, columns: Optional[List[str]] = None):
        self.columns = copy(self.columns) if columns is None else columns

    def __repr__(self) -> str:
        return f"name={self.name}, columns={self.columns}"

    def __eq__(self, other: Any) -> bool:
        if isinstance(other, DatapointType):
            return self.name == other.name and self.columns == other.columns
        return False

    @staticmethod
    def get_escaped_value(x: str) -> str:
        return x.replace(DATAPOINT_UID_DELIMITER, f"\\{DATAPOINT_UID_DELIMITER}")

    @staticmethod
    def get_unescaped_value(x: str) -> str:
        return x.replace(f"\\{DATAPOINT_UID_DELIMITER}", DATAPOINT_UID_DELIMITER)

    def get_datapoint_uid(self, **kwargs: Any) -> str:
        return (
            self.name
            + "::"
            + DATAPOINT_UID_DELIMITER.join(
                DatapointType.get_escaped_value(str(kwargs[col]))
                for col in self.columns
            )
        )

    def check_and_get_datapoint_uid_from_value(self, uids: List[str]) -> List[str]:
        prefix = self.name + "::"
        if any(prefix in value for value in uids):
            return uids
        else:
            return [self.get_datapoint_uid_from_values([raw_uid]) for raw_uid in uids]

    def get_datapoint_uid_from_values(self, values: Iterable[Any]) -> str:
        return (
            self.name
            + "::"
            + DATAPOINT_UID_DELIMITER.join(
                DatapointType.get_escaped_value(str(x)) for x in values
            )
        )

    @classmethod
    def _get_new_division(
        cls, division: str, num_cols_new_datapoint: int, fake_col_value: str
    ) -> str:
        current_values_str = division.split("::", 1)[1]
        current_values = cls.get_datapoint_values(division)
        num_current_values = len(current_values)

        if num_current_values == num_cols_new_datapoint:
            return cls.name + "::" + current_values_str
        elif num_current_values > num_cols_new_datapoint:
            return (
                cls.name
                + "::"
                + DATAPOINT_UID_DELIMITER.join(current_values[:num_cols_new_datapoint])
            )
        else:
            extra_values = DATAPOINT_UID_DELIMITER.join(
                [fake_col_value] * (num_cols_new_datapoint - num_current_values)
            )
            return (
                cls.name
                + "::"
                + current_values_str
                + DATAPOINT_UID_DELIMITER
                + extra_values
            )

    @classmethod
    def get_min_division(cls, division: str, num_cols_new_datapoint: int) -> str:
        return cls._get_new_division(division, num_cols_new_datapoint, "!!")

    @classmethod
    def get_max_division(cls, division: str, num_cols_new_datapoint: int) -> str:
        return cls._get_new_division(division, num_cols_new_datapoint, "~~")

    @classmethod
    def get_new_divisions(
        cls, divisions: Tuple[str, ...], num_cols_new_datapoint: int
    ) -> Tuple[str, ...]:
        if num_cols_new_datapoint == 0:
            raise ValueError("datapoint_uid has to contain at least 1 column!")
        new_divisions = [
            cls.get_min_division(x, num_cols_new_datapoint) for x in divisions[:-1]
        ]
        new_divisions.append(
            cls.get_max_division(divisions[-1], num_cols_new_datapoint)
        )
        return tuple(new_divisions)

    def get_new_datapoint_uid_from_old(
        self, old_datapoint_uid: str, col_to_value: Dict[str, Any]
    ) -> str:
        """NOTE: assumes no overlap between old_datapoint_uid and self.columns"""
        old_values = self.get_datapoint_values(old_datapoint_uid)
        new_values = [
            DatapointType.get_escaped_value(str(col_to_value[x])) for x in self.columns
        ]
        return self.name + "::" + DATAPOINT_UID_DELIMITER.join(old_values + new_values)

    def get_datapoint_uid_col_from_old_pandas(self, df: pd.DataFrame) -> pd.Series:
        return df.apply(
            lambda row: self.get_new_datapoint_uid_from_old(row.name, row.to_dict()),
            axis=1,
        )

    def parse_datapoint_uid(
        self, datapoint_uid: str, return_escaped: bool = False
    ) -> Dict[str, str]:
        values = DatapointType.get_datapoint_values(
            datapoint_uid, return_escaped=return_escaped
        )
        return {
            column: value
            for value, column in zip(reversed(values), reversed(self.columns))
        }

    @staticmethod
    def get_datapoint_values(
        datapoint_uid: str, return_escaped: bool = False
    ) -> List[str]:
        values_str = datapoint_uid.split("::", 1)[1]
        escaped_values = []
        start_idx = 0
        for i, char in enumerate(values_str):
            if char == DATAPOINT_UID_DELIMITER and values_str[i - 1] != "\\":
                escaped_values.append(values_str[start_idx:i])
                start_idx = i + 1
        if start_idx != len(values_str):
            escaped_values.append(values_str[start_idx:])

        if return_escaped:
            return escaped_values
        return [DatapointType.get_unescaped_value(x) for x in escaped_values]

    @staticmethod
    def get_datapoint_type(datapoint_uid: str) -> Type["DatapointType"]:
        if "::" not in datapoint_uid:
            raise InvalidUIDError(
                f"Invalid x_uid {datapoint_uid}. Must have format <datapoint_type>::<values>"
            )
        return get_datapoint_cls(datapoint_uid.split("::", 1)[0])

    def get_datapoint_uid_col_pandas(
        self, df: Union[pd.DataFrame, dd.DataFrame]
    ) -> pd.Series:
        """Returns Pandas series containing the UID for the given Pandas DataFrame."""
        # Backwards compatibility: CONTEXT_UID could be index and not a column
        if (
            df.index.name
            and df.index.name != DATAPOINT_UID_COL
            and df.index.name not in df.columns
        ):
            df = df.assign(**{df.index.name: df.index})

        result = self.name + "::"
        for i, col in enumerate(self.columns):
            if i:
                result += DATAPOINT_UID_DELIMITER
            value = df[col].astype(str)
            if (
                not pd.api.types.is_numeric_dtype(df[col])
                and col not in COLS_NOT_CONTAINING_DELIMITER
            ):
                value = value.apply(DatapointType.get_escaped_value)
            result += value

        return result

    def get_datapoint_uid_col(self, ddf: dd.DataFrame) -> dd.Series:
        """Returns Dask series containing the UID for the given Dask DataFrame."""
        return ddf.map_partitions(
            self.get_datapoint_uid_col_pandas, meta=(DATAPOINT_UID_COL, str)
        )


class Datapoint(DatapointType):
    name: str = "datapoint"


class DocDatapoint(DatapointType):
    name: str = "doc"

    columns: List[str] = [SpanCols.CONTEXT_UID]

    def get_datapoint_uid_col_pandas(
        self, df: Union[pd.DataFrame, dd.DataFrame]
    ) -> pd.Series:
        # Special case for backwards compatibility of doc type, which could sometimes
        # not have context_uid. We use the index in that case.
        if (
            SpanCols.CONTEXT_UID not in df.columns
            and SpanCols.CONTEXT_UID in self.columns
        ):
            df = df.assign(**{SpanCols.CONTEXT_UID: df.index})
        return super().get_datapoint_uid_col_pandas(df)


class SpanDatapoint(DatapointType):
    name: str = "span"
    columns: List[str] = [
        SpanCols.CONTEXT_UID,
        SpanCols.SPAN_FIELD,
        SpanCols.SPAN_FIELD_VALUE_HASH,
        SpanCols.CHAR_START,
        SpanCols.CHAR_END,
    ]

    @classmethod
    def is_span_dataframe(cls, col_names: List[str]) -> bool:
        """Returns True if dataframe matches Span datapoint type based on required columns"""
        # For backcompat, rows can be spans and still lack a context UID column
        columns_to_compare = [col for col in cls.columns if col != SpanCols.CONTEXT_UID]
        return all(col in col_names for col in columns_to_compare)


class PageCols:
    """Base class for page datapoint cols"""

    PAGE_IDX = "page_index"


class PageDatapoint(DatapointType):
    name: str = "page"
    columns: List[str] = [SpanCols.CONTEXT_UID, PageCols.PAGE_IDX]


class EntityDatapoint(DatapointType):
    name: str = "entity"
    columns: List[str] = [SpanCols.CONTEXT_UID, SpanCols.SPAN_ENTITY]


def get_datapoint_cls(datapoint_cls: str) -> Type[DatapointType]:
    if datapoint_cls not in DATAPOINT_TYPES:
        raise ValueError(f"Datapoint type {datapoint_cls} has not been registered")
    return DATAPOINT_TYPES[datapoint_cls]


def get_formatted_datapoint_uid(
    datapoint_uid: str, num_values: int, new_datapoint_type: Optional[str] = None
) -> str:
    """changes the type of the datapoint_uid to the provided and keeps the first (up to) num_values
    assumes that datapoint_uid is properly escaped
    """
    if new_datapoint_type is None:
        new_datapoint_type = DatapointType.get_datapoint_type(datapoint_uid).name
    values = DatapointType.get_datapoint_values(datapoint_uid, return_escaped=True)
    return new_datapoint_type + "::" + DATAPOINT_UID_DELIMITER.join(values[:num_values])


def get_datapoint_instance_from_uid(datapoint_uid: str) -> DatapointType:
    datapoint_type = DatapointType.get_datapoint_type(datapoint_uid)
    datapoint_values = DatapointType.get_datapoint_values(datapoint_uid)
    if len(datapoint_type.columns) != len(datapoint_values):
        raise InferrenceError(
            f"Can't infer datapoint_instance for datapoint_uid (={datapoint_uid}) with non-default columns"
        )
    return datapoint_type()


def parse_datapoint_type(datapoint_uid: str) -> Type[DatapointType]:
    if "::" not in datapoint_uid:
        raise InvalidUIDError(
            f"Invalid x_uid {datapoint_uid}. Must have format <datapoint_type>::<values>"
        )
    datapoint_name = DatapointType.get_datapoint_type(datapoint_uid).name
    datapoint_type = get_datapoint_cls(datapoint_name)
    return datapoint_type


def parse_datapoint_uid(
    datapoint_uid: str, datapoint_cols: List[str]
) -> Tuple[Type[DatapointType], Dict[str, Any]]:
    """Parses a datapoint UID into its type and column values."""
    datapoint_type = parse_datapoint_type(datapoint_uid)
    datapoint_instance = datapoint_type(datapoint_cols)
    datapoint_values = datapoint_instance.get_datapoint_values(datapoint_uid)
    if len(datapoint_cols) != len(datapoint_values):
        raise ValueError(f"Data point UID {datapoint_uid} is not properly formatted.")
    datapoint_cols_dict = dict(zip(datapoint_cols, datapoint_values))
    return datapoint_type, datapoint_cols_dict


def set_datapoint_uid_as_index(
    ddf: dd.DataFrame,
    datapoint_cols: Optional[List[str]] = None,
    datapoint_cls: Optional[Type[DatapointType]] = None,
) -> dd.DataFrame:
    """any combination of datapoint_cols/datapoint_cls can be passed"""
    if ddf.index.name == DATAPOINT_UID_COL:
        return ddf
    if datapoint_cols is None:
        if datapoint_cls is None:
            if SpanDatapoint().is_span_dataframe(ddf):
                datapoint_cols = SpanDatapoint.columns
                datapoint_uid_col = SpanDatapoint().get_datapoint_uid_col(ddf)
            else:
                datapoint_cols = DocDatapoint.columns
                datapoint_uid_col = DocDatapoint().get_datapoint_uid_col(ddf)
        else:
            datapoint_cols = datapoint_cls.columns
            datapoint_uid_col = datapoint_cls().get_datapoint_uid_col(ddf)
    elif datapoint_cls is None:
        datapoint_uid_col = Datapoint(datapoint_cols).get_datapoint_uid_col(ddf)
    else:
        datapoint_uid_col = datapoint_cls(datapoint_cols).get_datapoint_uid_col(ddf)
    ddf[DATAPOINT_UID_COL] = datapoint_uid_col
    # NOTE: unfortunately, we have to sort here since arbitrary columns are being passed
    # (we would have to for context_uid as well as sort order changes when converted to string)
    return ddf.set_index(DATAPOINT_UID_COL)


def set_datapoint_index(df: pd.DataFrame) -> None:
    if df.index.name == DATAPOINT_UID_COL:
        if SpanCols.CONTEXT_UID not in df.columns:
            # Datasources pre generalized datapoint changes don't include context_uid but
            # have the index set to DATAPOINT_UID_COL
            # TODO: don't require passing context_uid
            df[SpanCols.CONTEXT_UID] = [
                DatapointType.get_datapoint_values(x)[0] for x in df.index
            ]
            df[SpanCols.CONTEXT_UID] = df[SpanCols.CONTEXT_UID].astype("int64")
        return
    if SpanCols.CONTEXT_UID not in df.columns:
        df[SpanCols.CONTEXT_UID] = range(len(df))
    datapoint_instance = DocDatapoint()
    df.index = pd.Series(
        [datapoint_instance.get_datapoint_uid_from_values([x]) for x in df.context_uid],
        name=DATAPOINT_UID_COL,
    )
    df.sort_index(inplace=True)


def get_datapoint_uid_from_row_for_pdf_extraction(row: pd.Series) -> str:
    """Gets the datapoint UID for a row in a DataFrame for PDF extraction applications."""
    if hasattr(row, PageCols.PAGE_IDX) and getattr(row, PageCols.PAGE_IDX) is not None:
        return f"page::{getattr(row, SpanCols.CONTEXT_UID)},{getattr(row, PageCols.PAGE_IDX)}"
    return f"doc::{getattr(row, SpanCols.CONTEXT_UID)}"
