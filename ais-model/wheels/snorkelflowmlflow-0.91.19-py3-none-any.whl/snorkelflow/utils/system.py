import math
import os
import sys

import psutil


def cpu_count() -> int:
    """Get the available CPU count for this system.

    Takes the minimum value from the following locations:

    - Total system cpus available on the host.
    - CPU Affinity (if set)
    - Cgroups limit (if set)
    """
    count = os.cpu_count()
    assert count

    # Check CPU affinity if available
    if psutil is not None:
        try:
            affinity_count = len(psutil.Process().cpu_affinity())
            if affinity_count > 0:
                count = min(count, affinity_count)
        except Exception:
            pass

    # Check cgroups if available
    # The directory name isn't standardized across linux distros, check both
    for dirname in ["cpuacct,cpu", "cpu,cpuacct"]:
        try:
            with open("/sys/fs/cgroup/%s/cpu.cfs_quota_us" % dirname) as f:
                quota = int(f.read())
            with open("/sys/fs/cgroup/%s/cpu.cfs_period_us" % dirname) as f:
                period = int(f.read())
            # We round up on fractional CPUs
            cgroups_count = math.ceil(quota / period)
            if cgroups_count > 0:
                count = min(count, cgroups_count)
            break
        except Exception:
            pass

    return count


CPU_COUNT = cpu_count()


def memory_limit() -> int:
    """Get the memory limit (in bytes) for this system.
    Takes the minimum value from the following locations:
    - Total system host memory
    - Cgroups limit (if set)
    """
    limit = psutil.virtual_memory().total

    # Check cgroups if available
    if sys.platform == "linux":
        try:
            with open("/sys/fs/cgroup/memory/memory.limit_in_bytes") as f:
                cgroups_limit = int(f.read())
            if cgroups_limit > 0:
                limit = min(limit, cgroups_limit)
        except Exception:
            pass

    return limit


def is_gpu_available() -> bool:
    if not int(os.environ.get("IS_GPU_ENABLED", 0)):
        return False
    try:
        import torch

        return torch.cuda.is_available()
    except Exception:
        return False


MEMORY_LIMIT = memory_limit()
