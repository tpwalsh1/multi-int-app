from typing import Any

from tenacity import RetryError, Retrying, stop_after_attempt


def retry(cmd: Any, attempts: int = 5) -> Any:
    try:
        for attempt in Retrying(stop=stop_after_attempt(attempts)):
            with attempt:
                return cmd()
    except RetryError as e:
        raise e
