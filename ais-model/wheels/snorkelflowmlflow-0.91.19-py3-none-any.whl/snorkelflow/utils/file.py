import os
import pathlib
import warnings
from typing import Any, Dict, Optional, Tuple
from urllib.parse import ParseResult, urlparse

import fsspec
from fsspec.core import OpenFile

from snorkelflow.types.load import MinioArgs
from snorkelflow.utils.deprecation import deprecated

MINIO_URL_ENVVAR = "MINIO_URL"
MINIO_ACCESS_KEY_ENVVAR = "MINIO_ACCESS_KEY"
MINIO_SECRET_KEY_ENVVAR = "MINIO_SECRET_KEY"

MINIO_SCHEME = "minio://"
S3_SCHEME = "s3://"
# This env var is used to mock the data volume.
# This is needed for testing code that's running multiprocessing, as mocks don't apply
# to forked code
CONTAINER_VOLUME_DATA_PATH_TEST_OVERRIDE_ENV_VAR = (
    "CONTAINER_VOLUME_DATA_PATH_TEST_OVERRIDE"
)
CONTAINER_VOLUME_DATA_PATH = "/data"
CUSTOM_PIP_PATH = f"{CONTAINER_VOLUME_DATA_PATH}/.snorkel-flow-pip"
CUSTOM_NLTK_PATH = f"{CONTAINER_VOLUME_DATA_PATH}/.nltk_data"
BIND_MOUNT_DIR_ENV_VAR = "SNORKELFLOW_MOUNT_DIR"
TEMP_PREFIX = "tmp"
LOCAL_SCHEMES = {"file", ""}
SNORKEL_FLOW_MODELS_BUCKET = "snorkel-flow-models"
SNORKEL_FLOW_CACHE = os.path.join(MINIO_SCHEME, ".snorkel-flow-cache")


@deprecated(
    deprecate_in="2022.R2",
    remove_in="2023.R1",
    details="Use snorkelflow.utils.open_file to interact with files in MinIO.",
)
def resolve_data_path(path: str) -> str:
    """
    Resolve a MinIO path to a local file path.

    This method can resolve a MinIO path only if it is called from the in-app notebook.

    Parameters
    ----------
    path
        MinIO path (e.g., "minio://path/to/file.parquet")

    Returns
    -------
    str
        File path

    Examples
    --------
    >>> import pandas as pd
    >>> from snorkelflow.utils import resolve_data_path
    >>> minio_path = "minio://path/to/file.parquet"
    >>> resolved_path = resolve_data_path(minio_path)
    >>> df = pd.read_parquet(resolved_path)
    """
    bind_mount_dir = os.environ.get(BIND_MOUNT_DIR_ENV_VAR)
    if bind_mount_dir is None:
        # We are outside a service
        return path
    # We are inside a service
    data_volume_path = os.environ.get(
        CONTAINER_VOLUME_DATA_PATH_TEST_OVERRIDE_ENV_VAR, CONTAINER_VOLUME_DATA_PATH
    )
    if path.startswith(MINIO_SCHEME):
        return os.path.join(data_volume_path, path[len(MINIO_SCHEME) :])
    PASSTHRU_SCHEMES = ["file", "s3", "http", "https"]
    path_url = urlparse(path)
    if path_url.scheme in PASSTHRU_SCHEMES:
        return path
    if path_url.scheme:
        raise ValueError(
            f"Unknown URL scheme {path_url.scheme}. Allowed schemes: "
            "s3://, http://, https://, minio://, file://"
        )
    if path.startswith(bind_mount_dir):
        remaining_path = path[len(bind_mount_dir) :]
        # Strip off preceding slash if there, otherwise paths won't join
        if remaining_path.startswith("/"):
            remaining_path = remaining_path[1:]
        return os.path.join(data_volume_path, remaining_path)
    # Other paths pass thru.
    return path


def open_file(
    path: str, mode: str = "r", **kwargs: Optional[Dict[str, Any]]
) -> OpenFile:
    """Opens a file at the specified path and returns the corresponding file object.

    Currently supports MinIO URLs in the following format: ``minio://{bucket}/{key}``, local file paths, and S3 URLs.

    Examples
    --------

    >>> # Open a file in MinIO
    >>> f = open_file("minio://my-bucket/my-key")

    >>> # Open a file in MinIO outside of the in-platform Notebook
    >>> f = open_file(
            "minio://my-bucket/my-key",
            key={MINIO-ACCESS-KEY},
            secret={MINIO-SECRET-KEY},
            client_kwargs={"endpoint_url": {MINIO-URL}}
        )

    >>> # Open a local file
    >>> f = open_file("./path/to/file")

    >>> # Open a file in S3
    >>> f = open_file("s3://my-bucket/my-key", key={YOUR-S3-ACCESS-KEY}, secret={YOUR-S3-ACCESS-KEY})

    Parameters
    ----------
    path
        The path of the file to be opened
    mode
        ``'w'``, ``'rb'``, etc.
    kwargs
        Extra options that make sense to a particular storage connection, e.g. host, port, username, password, etc.
        These options are passed directly to ``fsspec.open``.

    Returns
    -------
    OpenFile
        A file object opened in the specified mode
    """
    helpful_err_msg = (
        "If referencing remote storage, the path parameter must be passed as a string in the format {scheme}://{bucket}/{key}. "
        "If using a path from the local file system, both relative and absolute paths are supported."
    )

    if not isinstance(path, str):
        raise ValueError(helpful_err_msg)
    if path.startswith(MINIO_SCHEME):
        minio_path, minio_configs = get_path_storage_options(path)
        return _open_file(minio_path, mode, **{**minio_configs, **kwargs})
    else:
        return _open_file(path, mode, **kwargs)


def _open_file(path: str, mode: str = "r", **kwargs: Any) -> OpenFile:
    # fsspec expands files with brackets when it shouldn't with the open api
    # open_files is able to handle this correctly and respects the expand kwarg
    # if a single file path is passed in opposed to a list, tuple, or set
    return fsspec.open_files(path, mode, expand=False, **kwargs)[0]


def get_relative_data_path(container_path: str) -> str:
    """
    Return a relative path for a container file path by stripping off the
    container volume mount prefix. This allows the path to be portable when accessed
    from inside or outside the platform (SDK). For now, the relative path always have a
    minio:// scheme since it will be accessible over minio, but can switch to another
    scheme like snorkelflow:// and resolve the path every time depending on context.
    """
    if BIND_MOUNT_DIR_ENV_VAR not in os.environ:
        # Do not modify the path if operating outside a service, for example in
        # unittests.
        return container_path
    data_volume_path = os.environ.get(
        CONTAINER_VOLUME_DATA_PATH_TEST_OVERRIDE_ENV_VAR, CONTAINER_VOLUME_DATA_PATH
    )
    # Check that the container path is in the root directory
    # (which is mapped to mounted dir)
    if not container_path.startswith(data_volume_path):
        raise ValueError(
            f"Container path {container_path} does not start "
            f"with {data_volume_path}"
        )
    remaining_path = container_path[len(data_volume_path) :]
    # Strip off preceeding slash if there, otherwise paths won't join
    if remaining_path.startswith("/"):
        remaining_path = remaining_path[1:]
    return os.path.join(MINIO_SCHEME, remaining_path)


def get_path_storage_options(
    path: str, minio_args: Optional[MinioArgs] = None
) -> Tuple[str, Dict[str, Any]]:
    # For MinIO paths, swap scheme to S3 and supply storage options to enable
    # reading via MinIO API
    path_url = urlparse(path)
    storage_options = {}
    if path_url.scheme == "minio":
        if minio_args:
            minio_url = minio_args.endpoint_url
            access_key = minio_args.access_key
            secret_key = minio_args.secret_key
        else:
            try:
                minio_url = os.environ[MINIO_URL_ENVVAR]
                access_key = os.environ[MINIO_ACCESS_KEY_ENVVAR]
                secret_key = os.environ[MINIO_SECRET_KEY_ENVVAR]
            except KeyError as e:
                raise ValueError(
                    f"{e}: minio connection parameter not found. Please provide minio"
                    " args via SnorkelFlowContext or environment variables."
                )
        storage_options = {
            "client_kwargs": {"endpoint_url": minio_url},
            "key": access_key,
            "secret": secret_key,
        }
        path = ParseResult("s3", *path_url[1:]).geturl()
    return path, storage_options


def _is_jupyterhub() -> bool:
    # True if it is JPH notebook rather than Legacy one
    return True if "JUPYTERHUB_USER" in os.environ else False


def _check_local_path(path: str) -> None:
    path_url = urlparse(path)
    if path_url.scheme not in LOCAL_SCHEMES:
        raise ValueError(f'Only local path is supported but "{path}" is provided.')
    if path_url.path.startswith(CONTAINER_VOLUME_DATA_PATH) and _is_jupyterhub():
        warnings.warn(f"Note that {path} is only present in Notebook and not in MinIO.")


def _get_model_dir(data_dir: str, node_uid: int, model_uuid: str) -> pathlib.Path:
    return (
        pathlib.Path(data_dir)
        / SNORKEL_FLOW_MODELS_BUCKET
        / f"task_{node_uid}"
        / f"model_{model_uuid}"
    )


def get_lock_filepath(filepath: str, create_dirs: bool = True) -> str:
    """Returns a filepath to lock given a unique file path to represent"""
    # Remove remote path if necessary
    filepath = filepath.replace(MINIO_SCHEME, "/tmp/").replace(S3_SCHEME, "/tmp/")

    if create_dirs:
        os.makedirs(filepath[: filepath.rfind("/")], exist_ok=True)

    return filepath + ".lock"
