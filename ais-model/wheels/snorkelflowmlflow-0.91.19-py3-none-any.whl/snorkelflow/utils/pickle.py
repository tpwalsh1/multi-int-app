import pickle
from typing import Any

import dask.dataframe as dd
import pandas as pd
from dask import delayed
from fsspec.utils import infer_storage_options

from snorkelflow.utils.file import _open_file, resolve_data_path

PICKLE_META_FILENAME = "pickle_meta"


def _write_pickle_file(df: pd.DataFrame, pickle_file: str) -> None:
    if infer_storage_options(pickle_file)["protocol"] == "file":
        # Workaround: pandas to_pickle does not understand file:// protocol.
        # Change to raw file path.
        pickle_file = pickle_file.replace("file://", "", 1)
    df.to_pickle(pickle_file)


def _to_pickle(df: pd.DataFrame, path: str, partition_info: Any = None) -> None:
    if not partition_info:
        return

    part_num = partition_info["number"]
    _write_pickle_file(df, f"{path}/pkl.{part_num}")


def to_pickle(ddf: dd.DataFrame, path: str, compute: bool = True) -> dd.DataFrame:
    resolved_path = resolve_data_path(path)

    with _open_file(f"{resolved_path}/{PICKLE_META_FILENAME}", "wb") as fh:
        pickle.dump({"npartitions": ddf.npartitions, "divisions": ddf.divisions}, fh)

    ddf = ddf.map_partitions(_to_pickle, resolved_path, meta=ddf)

    if compute:
        return ddf.compute()

    return ddf


def _read_pickle_file(pickle_file: str) -> pd.DataFrame:
    with _open_file(pickle_file, "rb") as f:
        return pickle.load(f)


def read_pickle(path: str, **kwargs: Any) -> dd.DataFrame:
    resolved_path = resolve_data_path(path)
    with _open_file(f"{resolved_path}/{PICKLE_META_FILENAME}", "rb") as f:
        pickle_meta = pickle.load(f)
    partitions = pickle_meta["npartitions"]
    divisions = pickle_meta["divisions"]
    parts = []
    for i in range(partitions):
        parts.append(delayed(_read_pickle_file)(f"{resolved_path}/pkl.{i}"))
    ddf = dd.from_delayed(parts, divisions=divisions, verify_meta=False)
    return ddf
