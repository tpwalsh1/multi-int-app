import socket
import time
from typing import Callable, Optional
from urllib.error import URLError
from urllib.request import urlopen


def poll_url(
    url: str,
    fail_callback: Optional[Callable[[], None]] = None,
    timeout_secs: int = 300,
) -> None:
    for _ in range(timeout_secs):
        try:
            urlopen(url, timeout=5)
            return
        except (ConnectionResetError, ConnectionRefusedError, URLError, socket.timeout):
            time.sleep(1)
    if fail_callback:
        fail_callback()
    raise ConnectionError(f"Snorkel Flow container failed to start on {url}")
