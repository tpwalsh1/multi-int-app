from typing import Dict, List

import pandas as pd

from snorkelflow.operators.featurizer import Featurizer
from snorkelflow.operators.operator import ColSchema
from snorkelflow.rich_docs import RichDoc, RichDocCols
from snorkelflow.rich_docs.rich_doc import RichDocList


class BaseRichDocParser(Featurizer):
    @property
    def output_schema(self) -> ColSchema:
        return {
            RichDocCols.TEXT_COL: str,
            RichDocCols.JSON_COL: str,
            RichDocCols.PAGE_DOCS: RichDocList,
            RichDocCols.PAGE_CHAR_STARTS: List[int],
        }

    def _rich_doc_to_columns(self, rich_doc: RichDoc) -> pd.Series:
        return pd.Series(
            {
                RichDocCols.TEXT_COL: rich_doc.text,
                RichDocCols.JSON_COL: rich_doc.to_json(),
                RichDocCols.PAGE_DOCS: rich_doc.split_pages(),
                RichDocCols.PAGE_CHAR_STARTS: rich_doc.page_char_starts,
            }
        )

    def column_docs(self) -> Dict[str, str]:
        return {
            RichDocCols.TEXT_COL: "a stripped raw text representation of the rich doc",
            RichDocCols.JSON_COL: "a serialized RichDoc that corresponds to rich_doc_text",
            RichDocCols.PAGE_DOCS: "a serialized list of RichDoc objects, one per page",
            RichDocCols.PAGE_CHAR_STARTS: "Character offsets of text starting on each page",
        }
