"""
Functionality for writing custom operators (preprocessors and postprocessors) in Python.

In addition to :ref:`built-in operators <operators>`, one can develop a custom operator like below and use it as part of an application.
In a nutshell, a custom operator is a Python function that accepts and outputs dataframes, decorated by one of Snorkel Flow operator decorators.

.. testcode::

    @pandas_featurizer(
        name="add_num", input_schema={}, output_schema={"added_num": int},
        resources={"num": 7})
    def add_num(df: pd.DataFrame, num: int) -> pd.DataFrame:
        df["added_num"] = num
        return df

Generally, parameters for custom operators are hard-coded within the user-defined function when they are developed for simplicity, e.g., ``"num": 7`` in the example above.
To create custom operators that take in parameters when they are used, you can instead create custom operator classes.
The diagram below should help you decide which approach to take and which decorator/class to use.

.. mermaid::

    flowchart TD
        start([Start]) --> B{{Parameters can be hard-coded?}}
        B -->|Yes| decorators(Decorators)
        decorators -->A{{Any special decorator that suits your need?}}
        A -->|Yes| special(Special decorators)
        A -->|No| generic(Generic decorators)
        generic -->E{{Only add columns?}}
        E -->|Yes| pandas_featurizer(pandas_featurizer)
        E -->|No| pandas_operator(pandas_operator)
        B -->|No| classes(Classes)
        classes -->C{{Only add columns?}}
        C -->|Yes| featurizer(Featurizer)
        C -->|No| operator(Operator)

.. note::

    Custom operators can only be developed and registered from the in-platform Notebook server.
    See also :ref:`Custom Operators` for tutorials.

.. rubric:: Special decorators

It's recommended to use special decorators rather than generic decorators whenever possible as the former is easier to use and less error-prone.
For example, use ``field_extractor`` rather than ``dask_extractor``.

.. autosummary::
    :toctree: _autosummary
    :template: custom-class-templates.rst

    field_extractor
    page_splitter
    row_filter
    span_normalizer
    span_reducer
    reducer

.. rubric:: Generic decorators

If none of the special decorators above suits your need, you can use one of the generic decorators below.
In Snorkel Flow, operators, whether built-in or custom, are applied to a Dask dataframe, which is composed of many smaller Pandas dataframes (see `here <https://docs.dask.org/en/stable/dataframe.html>`_ for more details).
It's recommended to use ``pandas_featurizer`` or ``pandas_operator``, which allows the user-defined function to deal with each Pandas dataframe at a time for simplicity unless you have to work with the whole Dask dataframe.

.. autosummary::
    :toctree: _autosummary
    :template: custom-class-templates.rst

    pandas_featurizer
    pandas_operator
    dask_operator
    dask_combiner
    dask_extractor

.. rubric:: Classes

.. autosummary::
    :toctree: _autosummary
    :template: custom-class-templates.rst

    Featurizer
    Operator

"""

from snorkelflow.operators.featurizer import Featurizer  # noqa: F401
from snorkelflow.operators.operator import Operator  # noqa: F401
from snorkelflow.operators.udf import (  # noqa: F401
    DaskCombiner,
    DaskExtractor,
    DaskOperator,
    FieldExtractor,
    PandasFeaturizer,
    PandasOperator,
    RowFilter,
    SpanNormalizer,
    UDFPageSplitter,
    UDFReducer,
    UDFSpanReducer,
    dask_combiner,
    dask_extractor,
    dask_operator,
    field_extractor,
    page_splitter,
    pandas_featurizer,
    pandas_operator,
    reducer,
    row_filter,
    span_normalizer,
    span_reducer,
)
