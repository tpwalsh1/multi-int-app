from collections import UserList, defaultdict
from typing import List, Optional


class Table(UserList):
    def __init__(self, initlist: Optional[List] = None):
        super().__init__(initlist)
        self._validate()

    def _validate(self) -> None:
        if len(self.data) == 0:
            return
        if not isinstance(self.data[0], dict):
            raise ValueError("Array elements are not dictionaries")
        # Get the set of keys for this array
        elem_col_to_type = defaultdict(set)
        for k in self.data[0]:
            elem_col_to_type[k].add(type(None))

        # Iterate through all elem to check if it has the correct keys and key type
        for elem in self.data:
            if not isinstance(elem, dict):
                raise ValueError("Array elements are not dictionaries")
            if elem.keys() != elem_col_to_type.keys():
                raise ValueError("All elements in the array do not have the same keys")
            for k, v in elem.items():
                elem_col_to_type[k].add(type(v))
                # We allow the actual type and a nonetype
                # Short cuicuit if the length exceed 2
                if len(elem_col_to_type[k]) > 2:
                    raise ValueError(
                        f"Element field: {k} does not have the same type for all elements"
                    )
