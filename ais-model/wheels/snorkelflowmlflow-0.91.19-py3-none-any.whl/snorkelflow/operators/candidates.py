import hashlib
import random
from abc import ABC, abstractmethod
from collections import Counter, defaultdict
from typing import Any, Dict, Iterable, List, Optional, Tuple, Type

import pandas as pd
from dask import dataframe as dd

from api_utils.exceptions import NotSupportedException
from snorkelflow.extraction.span import SpanCols
from snorkelflow.operators.featurizer import Featurizer, OpProgressCallback
from snorkelflow.operators.operator import (
    ColSchema,
    Operator,
    OpWithPartitionInfoProgressCallback,
    no_op_progress_callback,
)
from snorkelflow.operators.reducer import Reducer
from snorkelflow.types.load import DATAPOINT_UID_COL
from snorkelflow.types.model import ModelCols
from snorkelflow.utils.datapoint import (
    DatapointType,
    SpanDatapoint,
    get_formatted_datapoint_uid,
)
from snorkelflow.utils.logging import get_logger

logger = get_logger("Extractor")


def get_span_value_col(df: pd.DataFrame) -> str:
    """Returns either normalized_span or span_text column, based on availability."""
    return (
        SpanCols.NORMALIZED_SPAN
        if (
            # Check that column exists and that there are valid values
            SpanCols.NORMALIZED_SPAN in df.columns
            and not all(df[SpanCols.NORMALIZED_SPAN].isnull())
        )
        else SpanCols.SPAN_TEXT
    )


def get_span_field_value_hash(span_field_value: str) -> str:
    """Returns the MD5 hash of the span field value for use in span"""
    # NOTE: Be careful about changing this for backwards compatibility
    return hashlib.md5(span_field_value.encode("utf-8")).hexdigest()


class SpanExtractor(Operator, ABC):
    """Extracts spans (slices of documents) of interest.

    An abstract class that maps a DataFrame row to 0+ Span candidates

    Parameters
    ----------
    field
        The field to search for Candidates
    lowercase
        If True, lowercase all fields before attempting to extract from them
    """

    col_suffix: Optional[str] = None

    # columns that uniquely identify a span given the context
    new_datapoint_cols: List[str] = [
        x for x in SpanDatapoint.columns if x != SpanCols.CONTEXT_UID
    ]

    def __init__(self, field: str, col_suffix: Optional[str] = None) -> None:
        self.field = field
        self.col_suffix = col_suffix
        self.new_datapoint_cols = [
            self.get_suffixed_output_col_name(x) for x in self.new_datapoint_cols
        ]

    @property
    def input_schema(self) -> Optional[ColSchema]:
        return {self.field: str}

    @property
    def output_schema(self) -> Optional[ColSchema]:
        base_output_schema: ColSchema = {
            SpanCols.SPAN_FIELD: str,
            SpanCols.SPAN_FIELD_VALUE_HASH: str,
            SpanCols.CHAR_START: int,
            SpanCols.CHAR_END: int,
            SpanCols.SPAN_TEXT: str,
            SpanCols.INITIAL_LABEL: int,
            SpanCols.SPAN_ENTITY: str,
        }
        return self.get_suffixed_dict(base_output_schema)

    def column_docs(self) -> Dict[str, str]:
        base_descriptions = super().column_docs()

        schema_description = {
            SpanCols.SPAN_FIELD: "The name of the field that the span is extracted from",
            SpanCols.SPAN_FIELD_VALUE_HASH: "The hash of the value of the field that the spanis extracted from",
            SpanCols.CHAR_START: "The index of the first character of the span for this candidate",
            SpanCols.CHAR_END: "the index of the last character of the span for this candidate",
            SpanCols.SPAN_TEXT: "The text of the span (extracted from the context using char_start, char_end)",
            SpanCols.INITIAL_LABEL: "The label assigned to a span at creation time (if available)",
            SpanCols.SPAN_ENTITY: "The entity linked to the span_text",
        }
        suffixed = self.get_suffixed_dict(schema_description)
        schema_description = suffixed if suffixed else schema_description
        return {**base_descriptions, **schema_description}

    def get_suffixed_output_col_name(self, col: str) -> str:
        return f"{col}{self.col_suffix}" if self.col_suffix else col

    def get_suffixed_dict(self, dict: Optional[Dict]) -> Optional[Dict]:
        """returns the dictionary after adding the suffix to each key in it"""
        if dict is None or self.col_suffix is None:
            return dict
        return {self.get_suffixed_output_col_name(k): v for k, v in dict.items()}

    def get_datapoint_type(
        self, input_datapoint_types: List[Type[DatapointType]]
    ) -> Type[DatapointType]:
        """Get datapoint_type for output DataFrame of the operator, given types for inputs."""
        return SpanDatapoint

    def _execute(self, input_ddfs: List[dd.DataFrame]) -> dd.DataFrame:
        """Override base class method"""
        ddf = input_ddfs[0]
        if self.output_schema is None:
            raise ValueError("Output schema is found none")
        cols_to_drop = (
            set(self.output_schema.keys())
            .intersection(set(ddf.columns))
            .difference(self.field)
        )
        ddf = ddf.drop(labels=cols_to_drop, axis=1)
        return self.extract_from_ddf(ddf)

    def _execute_pandas(self, input_df: pd.DataFrame) -> pd.DataFrame:
        assert self.output_schema is not None  # mypy
        cols_to_drop = (
            set(self.output_schema.keys())
            .intersection(set(input_df.columns))
            .difference(self.field)
        )
        input_df = input_df.drop(labels=cols_to_drop, axis=1)
        num_spans: List[int] = []
        spans: List[Dict[str, Any]] = []
        for idx, (datapoint_uid, row) in enumerate(input_df.iterrows()):
            row_selected_fields = (
                row[list(self.input_schema)] if self.input_schema else row
            )
            row_spans = self.extract_span_list_from_row(
                datapoint_uid, row_selected_fields
            )
            # Probabilistically record number of spans.
            if len(num_spans) < 100:
                num_spans.append(len(row_spans))
            else:
                i = int((1 + idx) * random.random())
                if i < 100:
                    num_spans[i] = len(row_spans)
            datapoint_instance = SpanDatapoint(self.new_datapoint_cols)
            for row_span in row_spans:
                span = row.to_dict()
                span.update(self.get_suffixed_dict(row_span))
                span[
                    DATAPOINT_UID_COL
                ] = datapoint_instance.get_new_datapoint_uid_from_old(
                    datapoint_uid, span
                )
                spans.append(span)
        logger.info(f"Num spans per row (100 row sample): {Counter(num_spans)}")
        # Columns need to be set below in case spans is empty.
        if self.output_schema is None:
            raise ValueError("Output schema is found none")
        df = pd.DataFrame(
            spans,
            columns=[DATAPOINT_UID_COL]
            + list(self.output_schema)
            + input_df.columns.tolist(),
        )
        return df.set_index(DATAPOINT_UID_COL).sort_index()

    def extract_from_ddf(self, ddf: dd.DataFrame) -> dd.DataFrame:
        """Return a ddf indicating Span candidates extracted from the given ddf

        Parameters
        ----------
        ddf:
            The dataframe to extract candidates from

        Returns
        -------
        dd.DataFrame
            A dataframe of candidate information (metadata)
        """

        def map_fn(part: pd.DataFrame) -> pd.DataFrame:
            num_spans: List[int] = []
            spans: List[Dict[str, Any]] = []
            for idx, (datapoint_uid, row) in enumerate(part.iterrows()):
                row_selected_fields = (
                    row[list(self.input_schema)] if self.input_schema else row
                )
                row_spans = self.extract_span_list_from_row(
                    datapoint_uid, row_selected_fields
                )
                # Probabilistically record number of spans.
                if len(num_spans) < 100:
                    num_spans.append(len(row_spans))
                else:
                    i = int((1 + idx) * random.random())
                    if i < 100:
                        num_spans[i] = len(row_spans)
                datapoint_instance = SpanDatapoint(self.new_datapoint_cols)
                for row_span in row_spans:
                    span = row.to_dict()
                    span.update(self.get_suffixed_dict(row_span))
                    span[
                        DATAPOINT_UID_COL
                    ] = datapoint_instance.get_new_datapoint_uid_from_old(
                        datapoint_uid, span
                    )
                    spans.append(span)
            logger.info(f"Num spans per row (100 row sample): {Counter(num_spans)}")
            # Columns need to be set below in case spans is empty.
            if self.output_schema is None:
                raise ValueError("Output schema is found none")
            return (
                pd.DataFrame(
                    spans,
                    columns=[DATAPOINT_UID_COL]
                    + list(self.output_schema)
                    + part.columns.tolist(),
                )
                .set_index(DATAPOINT_UID_COL)
                .sort_index()
            )

        return self._execute_avoiding_set_index(ddf, map_fn, SpanDatapoint)

    def extract_span_list_from_row(
        self, datapoint_uid: str, row: pd.Series
    ) -> List[Dict[str, Any]]:
        """Return a list of Span candidates extracted from the given row's fields"""
        spans: List[Dict[str, Any]] = []
        for field, content in row.items():
            if not isinstance(content, str):
                continue
            content = row[field]
            content_hash = get_span_field_value_hash(content)
            for char_start, char_end, span_entity in self.extract_from_str(
                content, datapoint_uid
            ):
                span_text = content[char_start : char_end + 1]
                spans.append(
                    {
                        SpanCols.SPAN_FIELD: field,
                        SpanCols.SPAN_FIELD_VALUE_HASH: content_hash,
                        SpanCols.CHAR_START: char_start,
                        SpanCols.CHAR_END: char_end,
                        SpanCols.SPAN_TEXT: span_text,
                        SpanCols.SPAN_ENTITY: span_entity,
                        SpanCols.INITIAL_LABEL: -1,
                    }
                )
        return spans

    def extract_from_str(
        self, content: str, datapoint_uid: Optional[str] = None
    ) -> Iterable[Tuple[int, int, Optional[str]]]:
        """Yield 0+ (char_start, char_end, span_entity) tuples representing spans"""
        raise NotImplementedError

    def get_predictions(
        self, input_df: pd.DataFrame, output_df: pd.DataFrame
    ) -> Dict[str, Any]:
        """Note: In the future if spaces other than the SequenceLabelSpace are required, we can
        add that parameter here, however try-catch blocks will be required at import time to
        avoid circular dependencies.
        """
        predictions: Dict[str, Any] = defaultdict(list)
        if input_df.empty:
            return predictions

        def add_pred(spans: List[int], datapoint_uid: str) -> None:
            predictions[datapoint_uid].append(spans)

        example_input_datapoint_uid = input_df.index[0]
        num_values_in_input_datapoint_uid = len(
            DatapointType.get_datapoint_values(example_input_datapoint_uid)
        )
        input_datapoint_type = DatapointType.get_datapoint_type(
            example_input_datapoint_uid
        )
        doc_index_col = "_doc_index_col"
        output_df[doc_index_col] = output_df.apply(
            lambda row: get_formatted_datapoint_uid(
                row.name, num_values_in_input_datapoint_uid, input_datapoint_type.name
            ),
            axis=1,
        )

        span_field_lens = dict(
            zip(output_df[doc_index_col], output_df[self.field].map(len))
        )

        for datapoint_uid in output_df[doc_index_col].unique():
            tdf = output_df[output_df[doc_index_col] == datapoint_uid].sort_values(
                by=SpanCols.CHAR_START
            )
            datapoint_uid = str(datapoint_uid)
            prev_end = 0
            for start_idx, end_idx in zip(
                tdf[SpanCols.CHAR_START], tdf[SpanCols.CHAR_END]
            ):
                if prev_end != 0 or start_idx != 0:
                    char_start = (
                        0 if prev_end == 0 else prev_end
                    )  # char_start is the ending idx of previous extracted span
                    if char_start != start_idx:
                        # Only add unextracted span when it has non-zero length
                        add_pred(
                            [char_start, start_idx, 0], datapoint_uid=datapoint_uid
                        )

                add_pred([start_idx, end_idx + 1, 1], datapoint_uid=datapoint_uid)
                prev_end = end_idx + 1
            if prev_end != span_field_lens[datapoint_uid]:
                add_pred(
                    [prev_end, span_field_lens[datapoint_uid], 0],
                    datapoint_uid=datapoint_uid,
                )
        return predictions


class SpanReducer(Reducer, ABC):
    """
    Maps rows of spans to a subset (eg: to get document or entity-level predictions from span-level predictions)

    Parameters
    ----------
    preds_col
        The field contains (integer representation) prediction
    probs_col
        The field contains the model prediction probabilities
    """

    show_args_in_gui: bool = False

    def __init__(
        self,
        preds_col: str = ModelCols.PREDICTION_INT,
        probs_col: str = ModelCols.PREDICTION_PROBABILITY,
    ) -> None:
        self._preds_col = preds_col
        self._probs_col = probs_col

    @property
    def input_schema(self) -> Optional[ColSchema]:
        return {
            SpanCols.CHAR_START: int,
            SpanCols.CHAR_END: int,
            SpanCols.SPAN_TEXT: str,
        }

    @property
    def output_schema(self) -> Optional[ColSchema]:
        return {
            SpanCols.CHAR_START: int,
            SpanCols.CHAR_END: int,
            SpanCols.SPAN_TEXT: str,
        }


class SpanNormalizer(Featurizer, ABC):
    """
    Adds a column with span text converted to a standard format."""

    input_schema: ColSchema = {SpanCols.SPAN_TEXT: str}

    output_schema: ColSchema = {SpanCols.NORMALIZED_SPAN: str}

    def _compute_features(
        self,
        input_df: pd.DataFrame,
        callback: OpProgressCallback = no_op_progress_callback,
    ) -> pd.DataFrame:
        return input_df.assign(
            **{
                SpanCols.NORMALIZED_SPAN: input_df[SpanCols.SPAN_TEXT].map(
                    self._normalize
                )
            }
        )

    @abstractmethod
    def _normalize(self, span_text: str) -> dd.DataFrame:
        """Maps span_text to normalized span_text"""
        raise NotImplementedError

    def column_docs(self) -> Dict[str, str]:
        return {
            SpanCols.NORMALIZED_SPAN: f"Normalized from '{SpanCols.SPAN_TEXT}' in original dataframe"
        }


class SpanFeaturizer(Featurizer, ABC):
    """Adds a column with 0+ spans (slices of documents) of interest.

    Parameters
    ----------
    field
        The field to search for Candidates
    """

    col_suffix: Optional[str] = None

    def __init__(self, field: str, col_suffix: Optional[str] = None) -> None:
        self.field = field
        self.col_suffix = col_suffix

    @property
    def input_schema(self) -> Optional[ColSchema]:
        return {self.field: str}

    @property
    def output_schema(self) -> Optional[ColSchema]:
        output_schema: ColSchema = {
            SpanCols.SPAN_FIELD: object,
            SpanCols.SPAN_FIELD_VALUE_HASH: object,
            SpanCols.CHAR_START: object,
            SpanCols.CHAR_END: object,
            SpanCols.SPAN_TEXT: object,
            SpanCols.INITIAL_LABEL: object,
            SpanCols.SPAN_ENTITY: object,
        }
        return self.get_suffixed_dict(output_schema)

    def column_docs(self) -> Dict[str, str]:
        base_descriptions = super().column_docs()
        schema_description = {
            SpanCols.SPAN_FIELD: "List of the field names that the spans were extracted from",
            SpanCols.SPAN_FIELD_VALUE_HASH: "The hashes of the values of the fields that the spans were extracted from",
            SpanCols.CHAR_START: "List of indices of the first characters of the extracted spans",
            SpanCols.CHAR_END: "List of indices of the last characters of the extracted spans",
            SpanCols.SPAN_TEXT: "List of the text values for the extracted spans (extracted from the context using char_start, char_end)",
            SpanCols.INITIAL_LABEL: "List of the labels assigned to different spans at creation time (if available)",
            SpanCols.SPAN_ENTITY: "List of the entities linked to the span_text",
        }
        suffixed = self.get_suffixed_dict(schema_description)
        schema_description = suffixed if suffixed else schema_description
        return {**base_descriptions, **schema_description}

    def get_suffixed_output_col_name(self, col: str) -> str:
        return f"{col}{self.col_suffix}" if self.col_suffix else col

    def get_suffixed_dict(self, dict: Optional[Dict]) -> Optional[Dict]:
        """returns the dictionary after adding the suffix to each key in it"""
        if dict is None or self.col_suffix is None:
            return dict
        return {self.get_suffixed_output_col_name(k): v for k, v in dict.items()}

    def get_datapoint_type(
        self, input_datapoint_types: List[Type[DatapointType]]
    ) -> Type[DatapointType]:
        """Get datapoint_type for output DataFrame of the operator, given types for inputs."""
        return SpanDatapoint

    def _compute_features(
        self,
        input_df: pd.DataFrame,
        callback: OpProgressCallback = no_op_progress_callback,
    ) -> pd.DataFrame:
        spans = []
        if self.output_schema is None:
            raise ValueError("Output schema is found none")
        cols_to_drop = (
            set(self.output_schema.keys())
            .intersection(set(input_df.columns))
            .difference(self.field)
        )
        input_df = input_df.drop(labels=cols_to_drop, axis=1)
        for datapoint_uid, row in input_df.iterrows():
            row_selected_fields = (
                row[list(self.input_schema)] if self.input_schema else row
            )
            span_list: List[Dict[str, Any]] = self.extract_span_list_from_row(
                datapoint_uid, row_selected_fields
            )
            suffixed_span_list = []
            for span in span_list:
                # can't do list comprehension because of mypy
                suffixed_span = self.get_suffixed_dict(span)
                assert suffixed_span is not None  # mypy
                suffixed_span_list.append(suffixed_span)
            spans.append(
                {
                    key: [d[key] for d in suffixed_span_list]
                    for key in self.output_schema
                }
            )
        return input_df.assign(
            **{key: [d[key] for d in spans] for key in self.output_schema}
        )

    def extract_span_list_from_row(
        self, datapoint_uid: str, row: pd.Series
    ) -> List[Dict[str, Any]]:
        """Return a list of Span candidates extracted from the given row's fields"""
        spans: List[Dict[str, Any]] = []
        for field, content in row.items():
            if not isinstance(content, str):
                continue
            content = row[field]
            content_hash = get_span_field_value_hash(content)
            for char_start, char_end, span_entity in self.extract_span_list_from_str(
                content, datapoint_uid
            ):
                span_text = content[char_start : char_end + 1]
                span_dict = {
                    SpanCols.SPAN_FIELD: field,
                    SpanCols.SPAN_FIELD_VALUE_HASH: content_hash,
                    SpanCols.CHAR_START: char_start,
                    SpanCols.CHAR_END: char_end,
                    SpanCols.SPAN_TEXT: span_text,
                    SpanCols.SPAN_ENTITY: span_entity,
                    SpanCols.INITIAL_LABEL: -1,
                }
                spans.append(span_dict)
        return spans

    def extract_span_list_from_str(
        self, content: str, datapoint_uid: Optional[str] = None
    ) -> Iterable[Tuple[int, int, Optional[str]]]:
        """Yield 0+ (char_start, char_end, span_entity) tuples representing spans"""
        raise NotImplementedError


class SpanFeaturizerExtractor(SpanExtractor):
    def execute(
        self,
        input_ddfs: List[dd.DataFrame],
        callback: OpWithPartitionInfoProgressCallback = no_op_progress_callback,
    ) -> dd.DataFrame:
        return SpanExtractor.execute(self, input_ddfs, callback)

    def extract_from_str(
        self, content: str, datapoint_uid: Optional[str] = None
    ) -> Iterable[Tuple[int, int, Optional[str]]]:
        if not hasattr(self, "extract_span_list_from_str"):
            raise NotSupportedException(
                detail=f"SpanFeaturizerExtractor requires the extract_span_list_from_str method. Consider subclassing from a SpanFeaturizer",
                user_friendly_message=f"{self.__class__.__name__} is not a supported operator",
            )
        return self.extract_span_list_from_str(content, datapoint_uid)  # type: ignore

    @staticmethod
    def is_featurizer() -> bool:
        return False

    # Add base class method here so it has higher resolution priority than SpanFeaturizer.
    def get_datapoint_instance(
        self, input_datapoint_instances: List[DatapointType]
    ) -> DatapointType:
        return Operator.get_datapoint_instance(self, input_datapoint_instances)
