__all__ = [
    "pandas_featurizer",
    "pandas_operator",
    "field_extractor",
    "span_reducer",
    "span_normalizer",
    "dask_combiner",
    "dask_operator",
    "dask_extractor",
]

import inspect
from abc import abstractmethod
from copy import deepcopy
from types import FunctionType
from typing import Any, Callable, Dict, Iterable, List, Optional, Tuple

import pandas as pd
from dask import dataframe as dd

from api_utils.exceptions import UserInputError
from snorkelflow.operators.candidates import SpanExtractor, SpanNormalizer, SpanReducer
from snorkelflow.operators.featurizer import Featurizer, OpProgressCallback
from snorkelflow.operators.operator import (
    ColSchema,
    Operator,
    OpWithPartitionInfoProgressCallback,
    df_operator_error_wrapper,
    generic_error_wrapper,
    no_op_progress_callback,
    operators_dict,
)
from snorkelflow.operators.page_splitter import BasePageSplitter
from snorkelflow.operators.reducer import Reducer
from snorkelflow.operators.row_filter import BaseRowFilter
from snorkelflow.serialization.code_asset import deserialize_asset, serialize_asset
from snorkelflow.utils.datapoint import DatapointType, SpanDatapoint, get_datapoint_cls
from snorkelflow.utils.logging import get_logger

logger = get_logger("Snorkelflow operators")


def _serialize_dict(x: Optional[Dict[str, Any]]) -> Optional[Dict[str, str]]:
    if x is None:
        return None
    return {k: serialize_asset(v) for k, v in x.items()}


def _deserialize_dict(x: Optional[Dict[str, str]]) -> Optional[Dict[str, Any]]:
    if x is None:
        return None
    return {k: deserialize_asset(v) for k, v in x.items()}


class UserDefinedOperator(Operator):
    """Class for defining custom operators. Operators compute on DataFrames as input and output."""

    name: str

    def __init__(
        self,
        name: str,
        f: Callable,
        resources: Optional[Dict[str, Any]] = None,
        resources_fn: Optional[Callable[[], Dict[str, Any]]] = None,
    ) -> None:
        self.name = name
        self._f = f
        self._resources = resources if resources else {}
        self._resources_fn = resources_fn

    def _get_resource_kwargs(self) -> Dict[str, Any]:
        kwargs = self._resources.copy()
        if self._resources_fn is not None:
            kwargs.update(**self._resources_fn())
        return kwargs

    @abstractmethod
    def to_json(self) -> Dict[str, Any]:
        raise NotImplementedError

    @classmethod
    @abstractmethod
    def from_json(cls, config: Dict[str, Any]) -> "UserDefinedOperator":
        raise NotImplementedError

    def get_source(self) -> Dict[str, Any]:
        funcs = filter(lambda x: isinstance(getattr(self, x), FunctionType), dir(self))
        code: Dict[str, Any] = {
            func: inspect.getsource(getattr(self, func)) for func in funcs
        }
        code["_resources"] = {}
        if self._resources:
            for k, v in self._resources.items():
                if isinstance(v, FunctionType):
                    code["_resources"][f"_{k}"] = inspect.getsource(v)
        return code


class DaskOperator(UserDefinedOperator):
    """Base class for a DaskOperator.

    This class wraps a function that accepts a dask DataFrame as input
    and produces another dask DataFrame into a Snorkel Flow Operator.

    Parameters
    ----------
    name
        Name of the Operator
    f
        Function that accepts a ``dask.DataFrame``, performs a transformation,
        and returns the resulting ``dask.DataFrame``.

        Internally, Snorkel Flow will reflect any changes to indexing/partitioning
        in dask.

        If ``output_schema`` is specified, the function may add new columns (with
        type specified in ``output_schema``), or modify existing columns (without
        changing their type), but not delete any columns.
    resources
        Resources passed in to ``f`` via ``kwargs``
    resources_fn
        A function for generating a dictionary of values passed to ``f``
        via ``kwargs``, that are too expensive to serialize as resources.
    input_schema
        Dictionary mapping from column to dtype, used to validate the
        dtypes of the input dataframe.
    output_schema
        Dictionary mapping from column to dtype, used to validate the
        dtypes of the output dataframe.

        If not ``None``, then ``f`` must not delete any dataframe columns, and all
        new columns must be specified along with types in ``output_schema``.
    """

    def __init__(
        self,
        name: str,
        f: Callable[..., pd.DataFrame],
        resources: Optional[Dict[str, Any]] = None,
        resources_fn: Optional[Callable[[], Dict[str, Any]]] = None,
        input_schema: Optional[ColSchema] = None,
        output_schema: Optional[ColSchema] = None,
    ) -> None:
        super(DaskOperator, self).__init__(name, f, resources, resources_fn)
        self._input_schema = input_schema
        self._output_schema = output_schema

    @property
    def input_schema(self) -> Optional[ColSchema]:
        return self._input_schema

    @property
    def output_schema(self) -> Optional[ColSchema]:
        return self._output_schema

    def execute_df(self, input_data: pd.DataFrame) -> pd.DataFrame:
        """Apply an operator to a Pandas DataFrame.

        Parameters
        ----------
        input_data : pd.DataFrame
            input DataFrame

        Returns
        -------
        pd.DataFrame
            The output of the operator
        """
        ddf = dd.from_pandas(input_data, npartitions=1)
        return self._execute([ddf]).compute()

    def _execute(self, input_ddfs: List[dd.DataFrame]) -> dd.DataFrame:
        input_ddf = input_ddfs[0]
        output_ddf = self._f(input_ddf, **self._get_resource_kwargs())
        return output_ddf

    def to_json(self) -> Dict[str, Any]:
        """Save JSON config needed to serialize this class.

        Returns
        -------
        dict
            Dictionary from name to properties
        """
        return dict(
            name=self.name,
            f=serialize_asset(self._f),
            resources=_serialize_dict(self._resources),
            resources_fn=serialize_asset(self._resources_fn),
            input_schema=_serialize_dict(self._input_schema),
            output_schema=_serialize_dict(self._output_schema),
        )

    @classmethod
    def from_json(cls, config: Dict[str, Any]) -> "DaskOperator":
        """Deserialize this class from a JSON config.

        Returns
        -------
        DaskOperator
            Operator deserialized from JSON.
        """
        return cls(
            name=config["name"],
            f=deserialize_asset(config["f"]),
            resources=_deserialize_dict(config.get("resources", {})),
            # Default to None for versions before resources_fn was added.
            resources_fn=deserialize_asset(config["resources_fn"])
            if "resources_fn" in config
            else None,
            input_schema=_deserialize_dict(config.get("input_schema")),
            output_schema=_deserialize_dict(config.get("output_schema")),
        )


class dask_operator:
    """Decorator that wraps a function mapping a ``dask.dataframe.DataFrame`` to another ``dask.dataframe.DataFrame``.

    Warning
    -------
    Using ``@dask_operator`` is only recommended for advanced users, as changes to
    indexes/partitions in the operator will be reflected internally in the Snorkel Flow
    execution pipeline. For most use cases, ``@pandas_operator`` should be sufficient.

    Examples
    --------
    The following example is a function that adds a new column ``newcol``.

    .. testcode::

        import dask.dataframe as dd
        from snorkelflow.operators import dask_operator

        @dask_operator(name="set_newcol", input_schema={})
        def set_newcol(ddf: dd.DataFrame) -> dd.DataFrame:
            import pandas as pd
            import numpy as np
            from dask import dataframe as dd
            import random
            meta = ddf.dtypes.to_dict()
            meta['newcol'] = np.dtype(float)
            def _set_newcol(df: pd.DataFrame) -> pd.DataFrame:
                df['newcol'] = [random.random() for _ in range(len(df))]
                return df
            ddf = dd.map_partitions(_set_newcol, ddf, meta=meta)
            return ddf

        sf.add_operator(set_newcol)


    Parameters
    ----------
    name
        Name of the Operator
    resources
        Resources passed in to ``f`` via ``kwargs``
    resources_fn
        A function for generating a dictionary of values passed to ``f``
        via ``kwargs``, that are too expensive to serialize as resources.
    input_schema
        Dictionary mapping from column to dtype, used to validate the
        dtypes of the input dataframe.
    output_schema
        Dictionary mapping from column to dtype, used to validate the
        dtypes of the output dataframe.

        If not ``None``, then ``f`` must not delete any dataframe columns, and all
        new columns must be specified along with types in ``output_schema``.
    """

    def __init__(
        self,
        *,
        input_schema: ColSchema,
        name: Optional[str] = None,
        resources: Optional[Dict[str, Any]] = None,
        resources_fn: Optional[Callable[[], Dict[str, Any]]] = None,
        output_schema: Optional[ColSchema] = None,
    ) -> None:
        if callable(name):
            raise ValueError("Looks like this decorator is missing parentheses.")
        self.name = name
        self.resources = resources
        self.resources_fn = resources_fn
        self.input_schema = input_schema
        self.output_schema = output_schema

    def __call__(self, f: Callable[..., pd.DataFrame]) -> DaskOperator:
        """Wrap around the callable."""
        name = self.name or f.__name__
        name = f"custom_{name}"
        return DaskOperator(
            name=name,
            f=f,
            resources=self.resources,
            resources_fn=self.resources_fn,
            input_schema=self.input_schema,
            output_schema=self.output_schema,
        )


class DaskCombiner(DaskOperator):
    """Subclass of DaskOperator whose function operates on multiple dataframes."""

    def execute(
        self,
        input_ddfs: List[dd.DataFrame],
        callback: OpWithPartitionInfoProgressCallback = no_op_progress_callback,
    ) -> dd.DataFrame:
        return self._f(input_ddfs, **self._get_resource_kwargs())


class dask_combiner(dask_operator):
    """Decorator to define Dask Combiner from a function.

    Parameters
    ----------
    name
        Name of the Operator
    resources
        Resources passed in to ``f`` via ``kwargs``
    resources_fn
        A function for generating a dictionary of values passed to ``f``
        via ``kwargs``, that are too expensive to serialize as resources.
    input_schema
        Dictionary mapping from column to dtype, used to validate the
        dtypes of the first input dataframe.
    output_schema
        Dictionary mapping from column to dtype, used to validate the
        dtypes of the output dataframe.

        If not ``None``, then ``f`` must not delete any dataframe columns, and all
        new columns must be specified along with types in ``output_schema``.
    """

    def __call__(self, f: Callable[..., pd.DataFrame]) -> DaskOperator:
        """Wrap around the callable."""
        name = self.name or f.__name__
        name = f"custom_{name}"
        return DaskCombiner(
            name=name,
            f=f,
            resources=self.resources,
            resources_fn=self.resources_fn,
            input_schema=self.input_schema,
            output_schema=self.output_schema,
        )


class DaskExtractor(DaskOperator, SpanExtractor):
    def __init__(
        self,
        name: str,
        f: Callable[..., pd.DataFrame],
        resources: Optional[Dict[str, Any]] = None,
        resources_fn: Optional[Callable[[], Dict[str, Any]]] = None,
        input_schema: Optional[ColSchema] = None,
        output_schema: Optional[ColSchema] = None,
    ) -> None:
        super(DaskExtractor, self).__init__(
            name=name,
            f=f,
            resources=resources,
            resources_fn=resources_fn,
            input_schema=input_schema,
            output_schema=output_schema,
        )


class dask_extractor(dask_operator):
    """Decorator to define Dask Extractor from a function.

    Parameters
    ----------
    name
        Name of the Operator
    resources
        Resources passed in to ``f`` via ``kwargs``
    resources_fn
        A function for generating a dictionary of values passed to ``f``
        via ``kwargs``, that are too expensive to serialize as resources.
    input_schema
        Dictionary mapping from column to dtype, used to validate the
        dtypes of the input dataframe.
    output_schema
        Dictionary mapping from column to dtype, used to validate the
        dtypes of the output dataframe.

        If not ``None``, then ``f`` must not delete any dataframe columns, and all
        new columns must be specified along with types in ``output_schema``.
    """

    def __call__(self, f: Callable[..., pd.DataFrame]) -> DaskOperator:
        """Wrap around the callable."""
        name = self.name or f.__name__
        name = f"custom_{name}"
        return DaskExtractor(
            name=name,
            f=f,
            resources=self.resources,
            resources_fn=self.resources_fn,
            input_schema=self.input_schema,
            output_schema=self.output_schema,
        )


class PandasOperator(DaskOperator):
    """Base class for a PandasOperator.

    This class wraps a function that accepts a pandas DataFrame as input
    and produces another DataFrame and converts it into a Snorkel Flow Operator,
    which operates over dask Data Frames.

    Parameters
    ----------
    name
        Name of the Operator
    f
        Function that accepts a ``pandas.DataFrame``, performs a transformation,
        and returns the resulting ``pandas.DataFrame``.

        Internally, Snorkel Flow will reflect any changes to indexing/partitioning
        in pandas.

        If ``output_schema`` is specified, the function may add new columns (with
        type specified in ``output_schema``), or modify existing columns (without
        changing their type), but not delete any columns.
    resources
        Resources passed in to ``f`` via ``kwargs``
    resources_fn
        A function for generating a dictionary of values passed to ``f``
        via ``kwargs``, that are too expensive to serialize as resources.
    input_schema
        Dictionary mapping from column to dtype, used to validate the
        dtypes of the input dataframe.
    output_schema
        Dictionary mapping from column to dtype, used to validate the
        dtypes of the output dataframe.

        If not ``None``, then ``f`` must not delete any dataframe columns, and all
        new columns must be specified along with types in ``output_schema``.
    """

    def __init__(
        self,
        name: str,
        f: Callable[..., pd.DataFrame],
        resources: Optional[Dict[str, Any]] = None,
        resources_fn: Optional[Callable[[], Dict[str, Any]]] = None,
        input_schema: Optional[ColSchema] = None,
        output_schema: Optional[ColSchema] = None,
    ) -> None:
        super(PandasOperator, self).__init__(
            name, f, resources, resources_fn, input_schema, output_schema
        )

        if "meta" in self._resources:
            raise ValueError(
                "Cannot specify 'meta' as a resource; this is a reserved kwarg."
            )
        self._use_meta = output_schema is not None

    @property
    def input_schema(self) -> Optional[ColSchema]:
        return self._input_schema

    @property
    def output_schema(self) -> Optional[ColSchema]:
        return self._output_schema

    def _execute(self, input_ddfs: List[dd.DataFrame]) -> dd.DataFrame:
        input_ddf = input_ddfs[0]
        kwargs = self._get_resource_kwargs()
        if self._use_meta:
            # Note: We are assuming that the operator only adds columns
            # (specified in output schema), but doesn't delete any columns.
            dtypes = input_ddf.dtypes.to_dict()
            dtypes.update(self.output_meta)
            kwargs["meta"] = dtypes
        else:
            logger.warning(
                f"Operator {self.name} is missing output_schema. Because of this, the input dataframe should contain only strings, ints, floats, and bools, no custom types like RichDocs"
            )

        def _wrapped_executor(
            df: pd.DataFrame, partition_info: Any = None, **kwargs: Any
        ) -> pd.DataFrame:
            # Handle Empty dataframe
            if len(df) == 0 and self.output_schema:
                return pd.DataFrame(columns=self.output_schema.keys())
            ret = df_operator_error_wrapper(
                self._f, self.name, getattr(self, "node_uid", None)
            )(df, partition_info=partition_info, **kwargs)
            if self._use_meta:
                # pandas schema mismatch cannot be validated by validate_df_schema in operator base class
                output_columns = set(ret.columns)
                expected_columns = set(dtypes.keys())
                extra_columns = output_columns.difference(expected_columns)
                missing_columns = expected_columns.difference(output_columns)
                if extra_columns or missing_columns:
                    err_msg = f"Mismatch between output_schema and dataframe columns. Extra columns: {extra_columns}; Missing columns: {missing_columns}"
                    raise UserInputError(user_friendly_message=err_msg, detail=err_msg)
            return ret

        output_ddf = input_ddf.map_partitions(_wrapped_executor, **kwargs)
        return output_ddf


class pandas_operator:
    """Decorator that wraps a function mapping a ``pandas.DataFrame`` to another ``pandas.DataFrame``.

    While ``@pandas_operator`` allows you to define custom operators using simple Pandas
    syntax, they are automatically executed and parallelized using Dask under the hood.

    Examples
    --------
    In the following example, a function that adds a random number to each row is defined.
    An ``output_schema`` is explicitly added to indicate the column schema of the resulting
    DataFrame.

    This is used for validation and may provide you with helpful error messages.

    .. testcode::

        from snorkelflow.operators import pandas_operator

        @pandas_operator(name="Add Random Number", input_schema={}, output_schema={"rand_num": float})
        def add_rand_num(df: pd.DataFrame) -> pd.DataFrame:
            import random
            df["rand_num"] = [random.random() for _ in range(len(df))]
            return df

        sf.add_operator(add_rand_num)

    Parameters
    ----------
    name
        Name of the Operator
    resources
        Resources passed in to ``f`` via ``kwargs``
    resources_fn
        A function for generating a dictionary of values passed to ``f``
        via ``kwargs``, that are too expensive to serialize as resources.
    input_schema
        Dictionary mapping from column to dtype, used to validate the
        dtypes of the input dataframe.
    output_schema
        Dictionary mapping from column to dtype, used to validate the
        dtypes of the output dataframe.

        If not ``None``, then ``f`` must not delete any dataframe columns, and all
        new columns must be specified along with types in ``output_schema``.
    """

    def __init__(
        self,
        *,
        input_schema: ColSchema,
        name: Optional[str] = None,
        resources: Optional[Dict[str, Any]] = None,
        resources_fn: Optional[Callable[[], Dict[str, Any]]] = None,
        output_schema: Optional[ColSchema] = None,
    ) -> None:
        if callable(name):
            raise ValueError("Looks like this decorator is missing parentheses.")
        self.name = name
        self.resources = resources
        self.resources_fn = resources_fn
        self.input_schema = input_schema
        self.output_schema = output_schema
        self.resources_fn = resources_fn

    def __call__(self, f: Callable[..., pd.DataFrame]) -> PandasOperator:
        """Wrap around the callable."""
        name = self.name or f.__name__
        name = f"custom_{name}"
        return PandasOperator(
            name=name,
            f=f,
            resources=self.resources,
            resources_fn=self.resources_fn,
            input_schema=self.input_schema,
            output_schema=self.output_schema,
        )


class FieldExtractor(SpanExtractor, UserDefinedOperator):
    """Base class for a ``FieldExtractor``.

    See ``field_extractor`` decorator for usage.

    Parameters
    ----------
    name
        Name of the Extractor
    field
        Dataframe field that the extraction is operating over
    f
        Function that accepts as input from ``row[field]: str`` and outputs a
        tuple ``(char_start, char_end, span_entity): Tuple(int, int, Optional[str])``.

        Note that ``char_end`` represents the inclusive bounds of the span
        (the index of the last character in the span). To access the span with python
        indexing would require ``content[char_start: char_end+1]``.
    resources
        Resources passed in to ``f`` via ``kwargs``
    resources_fn
        A function for generating a dictionary of values passed to ``f``
        via ``kwargs``, that are too expensive to serialize as resources.
    """

    def __init__(
        self,
        name: str,
        field: str,
        f: Callable[..., pd.DataFrame],
        resources: Optional[Dict[str, Any]] = None,
        resources_fn: Optional[Callable[[], Dict[str, Any]]] = None,
    ) -> None:
        UserDefinedOperator.__init__(self, name, f, resources, resources_fn)
        # Override field that is operated over
        self.field = field

    def to_json(self) -> Dict[str, Any]:
        """Subclass method to save field instead of input and output schemas."""
        return dict(
            name=self.name,
            field=self.field,
            f=serialize_asset(self._f),
            resources=_serialize_dict(self._resources),
            resources_fn=serialize_asset(self._resources_fn),
        )

    @classmethod
    def from_json(cls, config: Dict[str, Any]) -> "FieldExtractor":
        """Deserialize this class from a JSON config."""
        return cls(
            name=config["name"],
            field=config["field"],
            f=deserialize_asset(config["f"]),
            resources=_deserialize_dict(config["resources"]),
            resources_fn=None
            if "resources_fn" not in config
            else deserialize_asset(config["resources_fn"]),
        )

    def extract_from_str(
        self, content: str, datapoint_uid: Optional[str] = None
    ) -> Iterable[Tuple[int, int, Optional[str]]]:
        return generic_error_wrapper(
            self._f, self.name, getattr(self, "node_uid", None)
        )(content, **self._get_resource_kwargs())


class field_extractor:
    """Decorator for generating candidate spans for extraction tasks.

    The field over which candidates should be extracted is specified in the decorator.
    The wrapped function accepts a string input (which is text in the specified field for a
    single row of the DataFrame) and outputs a list of tuples
    ``[(char_start, char_end, span_entity)]`` (using type annotation syntax:
    ``List[Tuple[int, int, Optional[str]]]``).
    Each tuple represents the index of the starting character of the span, the index of the
    ending character of the span, and a canonical identifier string for the entity
    represented by the span (if applicable).

    Warning
    -------
    ``char_end`` represents the inclusive bounds of the span (the index of the
    last character in the span).
    In Python syntax, the span substring is ``content[char_start : char_end + 1]``.

    Examples
    --------
    The following example demonstrate how to use a custom regex to extract candidates:

    .. testcode::

        import re
        from snorkelflow.operators import field_extractor

        regex = re.compile(r"(?:hello|good morning)", flags=re.IGNORECASE)

        @field_extractor(
            name="greetings_extractor",
            field="body",
            resources=dict(compiled_regex=regex),
        )
        def greetings_extractor(content: str, compiled_regex: re.Pattern) -> List[Tuple[int, int, Optional[str]]]:
            spans: List[Tuple[int, int, Optional[str]]] = []
            for match in compiled_regex.finditer(content):
                char_start, char_end = match.span(0)
                spans.append((char_start, char_end - 1, None))
            return spans

        sf.add_operator(greetings_extractor)

    Parameters
    ----------
    name
        Name of the Extractor
    field
        Dataframe field that the extraction is operating over
    resources
        Resources passed in to ``f`` via ``kwargs``
    resources_fn
        A function for generating a dictionary of values passed to ``f``
        via ``kwargs``, that are too expensive to serialize as resources.
    """

    def __init__(
        self,
        field: str,
        name: Optional[str] = None,
        resources: Optional[Dict[str, Any]] = None,
        resources_fn: Optional[Callable[[], Dict[str, Any]]] = None,
    ) -> None:
        if callable(name):
            raise ValueError("Looks like this decorator is missing parentheses.")
        self.name = name
        self.field = field
        self.resources = resources
        self.resources_fn = resources_fn

    def __call__(self, f: Callable[..., pd.DataFrame]) -> FieldExtractor:
        """Wrap around the callable."""
        name = self.name or f.__name__
        name = f"custom_{name}"
        return FieldExtractor(
            name=name,
            field=self.field,
            f=f,
            resources=self.resources,
            resources_fn=self.resources_fn,
        )


class RowFilter(BaseRowFilter, UserDefinedOperator):
    """Base class for a RowFilter.

    This class wraps a function that accepts a pandas DataFrame as input
    and produces a DataFrame with some rows filtered. This function is then converted
    to an operator in the DAG.

    See the ``@row_filter`` decorator for usage.

    Parameters
    ----------
    name
        Name of the row filter
    f
        Function that accepts as input from ``pd.DataFrame`` and outputs
        a ``pd.Series`` used to filter the input DataFrame.
    resources
        Resources passed in to ``f`` via ``kwargs``
    resources_fn
        A function for generating a dictionary of values passed to ``f``
        via ``kwargs``, that are too expensive to serialize as resources.
    """

    def __init__(
        self,
        name: str,
        f: Callable[..., pd.DataFrame],
        resources: Optional[Dict[str, Any]] = None,
        resources_fn: Optional[Callable[[], Dict[str, Any]]] = None,
    ) -> None:
        UserDefinedOperator.__init__(self, name, f, resources, resources_fn)

    def to_json(self) -> Dict[str, Any]:
        """Subclass method to save field instead of input and output schemas."""
        return dict(
            name=self.name,
            f=serialize_asset(self._f),
            resources=_serialize_dict(self._resources),
            resources_fn=serialize_asset(self._resources_fn),
        )

    @classmethod
    def from_json(cls, config: Dict[str, Any]) -> "RowFilter":
        """Deserialize this class from a JSON config."""
        return cls(
            name=config["name"],
            f=deserialize_asset(config["f"]),
            resources=_deserialize_dict(config["resources"]),
            resources_fn=None
            if "resources_fn" not in config
            else deserialize_asset(config["resources_fn"]),
        )

    def _filter_condition(self, df: pd.DataFrame) -> pd.Series:
        return df_operator_error_wrapper(
            self._f, self.name, getattr(self, "node_uid", None)
        )(df, **self._get_resource_kwargs())


class row_filter:
    """Decorator for filtering rows of a dataframe.

    The decorator wraps a function that takes a Pandas DataFrame as input and returns a
    Pandas Series that's used to filter the input dataframe.

    Examples
    --------
    The following examples demonstrate how to create a custom filter:

    .. testcode::

        from snorkelflow.operators import row_filter
        import pandas as pd

        # Keep all spans that have more than 5 words
        @row_filter(name="greater_than_five_words")
        def greater_than_five_words(df: pd.DataFrame) -> pd.Series:
            return df["span_text"].str.split().str.len() > 5

        # Keep all PDFs with greater than 5 pages
        @row_filter(name="greater_than_five_pages")
        def greater_than_five_pages(df: pd.DataFrame) -> pd.Series:
            from snorkelflow.rich_docs import RichDoc, RichDocCols
            page_docs = df[RichDocCols.PAGE_DOCS]
            return page_docs.apply(lambda x: len(x) > 5)

        # Filter rows based on compiled regex pattern
        import re
        pattern = re.compile(r"(?:hello|good morning)", flags=re.IGNORECASE)

        @row_filter(
            name="greetings_filter",
            resources=dict(compiled_rgx=pattern),
        )
        def greetings_filter(df: pd.DataFrame, compiled_rgx: re.Pattern) -> pd.Series:
            text_col = df["text"]
            return text_col.apply(lambda x: bool(compiled_rgx.match(x)))

        # Register any one of the row_filters above
        sf.add_operator(greetings_filter)

    Parameters
    ----------
    name
        Name of the row_filter
    resources
        Resources passed in to ``f`` via ``kwargs``
    resources_fn
        A function for generating a dictionary of values passed to ``f``
        via ``kwargs``, that are too expensive to serialize as resources.
    """

    def __init__(
        self,
        name: str,
        resources: Optional[Dict[str, Any]] = None,
        resources_fn: Optional[Callable[[], Dict[str, Any]]] = None,
    ) -> None:
        if callable(name):
            raise ValueError(
                "First argument to row_filter must be a string. Did you forget to add parentheses?"
            )
        self.name = name
        self.resources = resources
        self.resources_fn = resources_fn

    def __call__(self, f: Callable[..., pd.DataFrame]) -> RowFilter:
        """Wrap around the callable."""
        name = self.name or f.__name__
        name = f"custom_{name}"
        return RowFilter(
            name=name, f=f, resources=self.resources, resources_fn=self.resources_fn
        )


# Featurizer must occur before PandasOperator so we use its _execute function.
class PandasFeaturizer(Featurizer, PandasOperator):
    """Base class for a Pandas Featurizer.

    This class wraps a function that accepts a pandas DataFrame as input
    and produces a dataframe with additional feature columns, and converts it
    into a Snorkel Flow Operator.

    The wrapped fn to applied to a specific *partition* of the underlying dask dataframe
    via ``map_partitions``.

    Parameters
    ----------
    name
        Name of the Featurizer
    f
        Function that accepts as input from ``pd.DataFrame`` and outputs
        a ``pd.DataFrame`` containing the same rows with one column per feature.
    resources
        Resources passed in to ``f`` via ``kwargs``
    resources_fn
        A function for generating a dictionary of values passed to ``f``
        via ``kwargs``, that are too expensive to serialize as resources.
    input_schema
        Dictionary mapping from column to dtype. This must include **all** the
        columns required by ``f``.
    output_schema
        Dictionary mapping from column to dtype. ``f`` must add exactly the
        columns specified here to the dataframe.
    """

    def __init__(
        self,
        name: str,
        f: Callable[..., pd.DataFrame],
        resources: Optional[Dict[str, Any]] = None,
        resources_fn: Optional[Callable[[], Dict[str, Any]]] = None,
        input_schema: Optional[ColSchema] = None,
        output_schema: Optional[ColSchema] = None,
    ) -> None:
        if output_schema is None:
            raise ValueError(f"output_schema must be non-None for featurizers")
        Featurizer.__init__(self)
        PandasOperator.__init__(
            self, name, f, resources, resources_fn, input_schema, output_schema
        )

    def _compute_features(
        self,
        input_df: pd.DataFrame,
        callback: OpProgressCallback = no_op_progress_callback,
    ) -> pd.DataFrame:
        return self._f(input_df, **self._get_resource_kwargs())


class pandas_featurizer:
    """Decorator for adding columns to a dataframe.

    It can be used a create a ``Featurizer``, namely an operator
    that only adds columns (features) to a dataframe, but does not add or delete any rows.

    A pandas_featurizer **must** include an output schema, which should contain all the new
    columns added by the wrapped function. If it has an input schema, it should include all
    the columns needed by the function.

    While ``@pandas_featurizer`` allows you to define custom operators using simple Pandas
    syntax, they are automatically executed and parallelized using Dask under the hood.

    Examples
    --------
    In the following example, a function that adds one to an integer column to produce another
    column is defined and wrapped with a ``@pandas_featurizer``.

    .. testcode::

        from snorkelflow.operators import pandas_featurizer

        @pandas_featurizer(name="Add 1", input_schema={"mycol": int}, output_schema={"mycol2": int})
        def add_one(df: pd.DataFrame) -> pd.DataFrame:
            return df.assign(mycol2=df.mycol + 1)

        sf.add_operator(add_one)

    Parameters
    ----------
    name
        Name of the Featurizer
    f
        Function that accepts as input from ``pd.DataFrame`` and outputs
        a ``pd.DataFrame``.
    resources
        Resources passed in to ``f`` via ``kwargs``
    resources_fn
        A function for generating a dictionary of values passed to ``f``
        via ``kwargs``, that are too expensive to serialize as resources.
    input_schema
        Dictionary mapping from column to dtype. This must include **all** the
        columns required by ``f``.
    output_schema
        Dictionary mapping from column to dtype. ``f`` must add exactly the
        columns specified here to the dataframe.
    is_join_featurizer
        If True, then the join of the documents and candidates dataframes is
        given to is as input. Should be False for classification tasks.
    """

    def __init__(
        self,
        *,
        input_schema: ColSchema,
        name: Optional[str] = None,
        resources: Optional[Dict[str, Any]] = None,
        resources_fn: Optional[Callable[[], Dict[str, Any]]] = None,
        output_schema: Optional[ColSchema] = None,
        is_join_featurizer: bool = False,
    ) -> None:
        if callable(name):
            raise ValueError("Looks like this decorator is missing parentheses.")
        if not output_schema:
            raise ValueError(f"output_schema must be non-empty for featurizers")
        self.name = name
        self.resources = resources
        self.resources_fn = resources_fn
        self.input_schema = input_schema
        self.output_schema = output_schema
        self.is_join_featurizer = is_join_featurizer

    def __call__(self, f: Callable[..., pd.DataFrame]) -> PandasOperator:
        """Wrap around the callable."""
        name = self.name or f.__name__
        name = f"custom_{name}"
        return PandasFeaturizer(
            name=name,
            f=f,
            resources=self.resources,
            resources_fn=self.resources_fn,
            input_schema=self.input_schema,
            output_schema=self.output_schema,
        )


class UDFReducer(Reducer, PandasOperator):
    """Base class for a UDFReducer.

    This class wraps a function that accepts a pandas DataFrame as input
    and produces reduced dataframe, and converts it into a Snorkel Flow Operator.

    Normally, reducers are specified to aggregate rows into some higher level constructs
    like docs or pages. They generally group data points based on columns that uniquely identify the
    higher-level construct (e.g. ``context_uid``)

    Parameters
    ----------
    name
        Name of the Reducer
    f
        Function that accepts as input from ``pd.DataFrame`` and outputs
        a ``pd.DataFrame``.
    datapoint_instance
        The instance of the datapoint to reduce to. For example if you are reducing from spans to docs,
        this should be an instance of DocDatapoint
    resources
        Resources passed in to ``f`` via ``kwargs``
    input_schema
        Dictionary mapping from column to dtype, used to validate the
        dtypes of the input dataframe.
    output_schema
        Dictionary mapping from column to dtype, used to validate the
        dtypes of the output dataframe.
    """

    def __init__(
        self,
        name: str,
        f: Callable[..., pd.DataFrame],
        datapoint_instance: Optional[DatapointType] = None,
        resources: Optional[Dict[str, Any]] = None,
        input_schema: Optional[ColSchema] = None,
        output_schema: Optional[ColSchema] = None,
    ) -> None:
        Reducer.__init__(self)
        PandasOperator.__init__(
            self,
            name,
            f,
            resources,
            input_schema=input_schema,
            output_schema=output_schema,
        )
        # Verify datapoint cls is valid
        datapoint_cls = getattr(datapoint_instance, "name", "")
        self._datapoint_cls = get_datapoint_cls(datapoint_cls)
        self._datapoint_instance = datapoint_instance

    def to_json(self) -> Dict[str, Any]:
        """Subclass method to save field instead of input and output schemas."""
        return dict(
            name=self.name,
            f=serialize_asset(self._f),
            datapoint_instance=serialize_asset(self._datapoint_instance),
            resources=_serialize_dict(self._resources),
            input_schema=_serialize_dict(self._input_schema),
            output_schema=_serialize_dict(self._output_schema),
        )

    @classmethod
    def from_json(cls, config: Dict[str, Any]) -> "UDFReducer":
        """Deserialize this class from a JSON config."""
        return cls(
            name=config["name"],
            f=deserialize_asset(config["f"]),
            datapoint_instance=deserialize_asset(config["datapoint_instance"])
            if "datapoint_instance" in config
            else None,
            resources=_deserialize_dict(config["resources"]),
            input_schema=_deserialize_dict(config["input_schema"])
            if "input_schema" in config
            else None,
            output_schema=_deserialize_dict(config["output_schema"])
            if "output_schema" in config
            else None,
        )

    @property
    def _reduced_datapoint_instance(self) -> DatapointType:
        if self._datapoint_instance:
            return self._datapoint_instance
        return self._datapoint_cls()

    def _reduce_inner(self, df: pd.DataFrame) -> pd.DataFrame:
        return df_operator_error_wrapper(
            self._f, self.name, getattr(self, "node_uid", None)
        )(df, **self._resources)

    @property
    def input_schema(self) -> Optional[ColSchema]:
        return self._input_schema

    @property
    def output_schema(self) -> Optional[ColSchema]:
        return self._output_schema


class reducer:
    """Decorator for aggregating lower-level model predictions to higher-level predictions.

    The decorator wraps a function that takes a Pandas DataFrame as input and returns a new
    Pandas DataFrame. The index of the new DataFrame must be the same as the original DataFrame,
    unless the ``datapoint_instance`` is specified. The available datapoints can be found in ``DATAPOINT_TYPES``
    imported from ``snorkelflow.utils.datapoint``.

    Warning
    -------
    Using custom reducers is only recommended for advanced users as it currently requires
    knowledge of internal fields and index handling. The ``datatpoint_instance`` must also
    be specified.

    Examples
    --------
    This example, finds the first span in the doc by ``char_start``

    .. testcode::

        from snorkelflow.operators import reducer
        from snorkelflow.utils.datapoint import DocDatapoint
        from snorkelflow.extraction.span import SpanCols

        # Getting the first span per doc
        @reducer(name="first_span_reducer", datapoint_instance=DocDatapoint())
        def first_span_reducer(df: pd.DataFrame) -> pd.DataFrame:
            df = df.loc[df.groupby([SpanCols.CONTEXT_UID])[SpanCols.CHAR_START].idxmin()]
            return df

        # Geting the first page per doc (PDF apps)
        @reducer(name="first_page_reducer", datapoint_instance=DocDatapoint())
        def first_page_reducer(df: pd.DataFrame) -> pd.DataFrame:
            from snorkelflow.extraction.span import SpanCols
            # Gets the first page from each doc
            index_col = df.index.name
            df = df.reset_index()
            df = df.groupby([SpanCols.CONTEXT_UID]).first()
            df = df.reset_index().set_index(index_col)
            return df

        # Getting multiple spans per doc
        @reducer(name="multi_span_reducer", datapoint_instance=DocDatapoint())
        def multi_span_reducer(df: pd.DataFrame) -> pd.DataFrame:
            index_col = df.index.name
            df = df.reset_index()
            df = df.groupby([SpanCols.CONTEXT_UID]).agg(list)
            df[index_col] = df[index_col].str[0]
            df = df.reset_index().set_index(index_col)
            return df

        sf.add_operator(multi_span_reducer)

    Parameters
    ----------
    name
        Name of the Reducer
    f
        Function that accepts as input from ``pd.DataFrame`` and outputs
        a ``pd.DataFrame``.
    datapoint_instance
        An instance of the datapoint type to reduce to. For example if you are reducing from spans to docs, this
        should be DocDatapoint
    resources
        Resources passed in to ``f`` via ``kwargs``
    input_schema
        Dictionary mapping from column to dtype, used to validate the
        dtypes of the input dataframe.
    output_schema
        Dictionary mapping from column to dtype, used to validate the
        dtypes of the output dataframe.
    """

    def __init__(
        self,
        name: Optional[str] = None,
        datapoint_instance: Optional[DatapointType] = None,
        resources: Optional[Dict[str, Any]] = None,
        input_schema: Optional[ColSchema] = None,
        output_schema: Optional[ColSchema] = None,
    ) -> None:
        if callable(name):
            raise ValueError("Looks like this decorator is missing parentheses.")
        self.name = name
        self.resources = resources
        self._datapoint_instance = datapoint_instance
        self._input_schema = input_schema
        self._output_schema = output_schema

    def __call__(self, f: Callable[..., pd.DataFrame]) -> UDFReducer:
        """Wrap around the callable."""
        name = self.name or f.__name__
        name = f"custom_{name}"
        return UDFReducer(
            name=name,
            f=f,
            datapoint_instance=self._datapoint_instance,
            resources=self.resources,
            input_schema=self._input_schema,
            output_schema=self._output_schema,
        )


class UDFSpanReducer(SpanReducer, UDFReducer):
    """Base class for a UDFSpanReducer.

    This class wraps a function that accepts a pandas DataFrame as input
    and produces reduced dataframe, and converts it into a Snorkel Flow Operator.

    The wrapped fn is applied to a specific *partition* of the underlying dask dataframe
    via ``map_partitions``. Normally, reducers are specified _after_ Snorkel Flow
    extractors, which partition span-level data points based on ``context_uid``
    (e.g. the document).

    Parameters
    ----------
    name
        Name of the Reducer
    f
        Function that accepts as input from ``pd.DataFrame`` and outputs
        a ``pd.DataFrame``.
    datapoint_instance
        An instance of the datapoint type to reduce to. For example if you are reducing from spans to docs, this
        should be DocDatapoint
    resources
        Resources passed in to ``f`` via ``kwargs``
    input_schema
        Dictionary mapping from column to dtype, used to validate the
        dtypes of the input dataframe. This is add-on in addition to (char_start, char_end and span_text) in SpanReducer
    output_schema
        Dictionary mapping from column to dtype, used to validate the
        dtypes of the output dataframe. This is add-on in addition to (char_start, char_end and span_text) in SpanReducer
    """

    def __init__(
        self,
        name: str,
        f: Callable[..., pd.DataFrame],
        datapoint_instance: Optional[DatapointType] = SpanDatapoint(),
        resources: Optional[Dict[str, Any]] = None,
        input_schema: Optional[ColSchema] = None,
        output_schema: Optional[ColSchema] = None,
    ) -> None:
        SpanReducer.__init__(self)
        UDFReducer.__init__(
            self, name, f, datapoint_instance, resources, input_schema, output_schema
        )
        base_input_schema = super(UDFSpanReducer, self).input_schema
        base_output_schema = super(UDFSpanReducer, self).output_schema
        new_input_schema = deepcopy(base_input_schema) or {}
        new_output_schema = deepcopy(base_output_schema) or {}
        if self._input_schema is not None:
            new_input_schema.update(self._input_schema)

        if self._output_schema is not None:
            new_output_schema.update(self._output_schema)

        self._input_schema = new_input_schema
        self._output_schema = new_output_schema

    @property
    def input_schema(self) -> Optional[ColSchema]:
        return self._input_schema

    @property
    def output_schema(self) -> Optional[ColSchema]:
        return self._output_schema


class span_reducer:
    """Decorator for aggregating span-level model predictions to document-level predictions for extraction tasks.

    The decorator wraps a function that takes a Pandas DataFrame as input and returns a new
    Pandas DataFrame. The index of the new DataFrame must be the same as the original DataFrame,
    unless the ``datapoint_instance`` is specified. The available datapoints can be found in ``DATAPOINT_TYPES``
    imported from ``snorkelflow.utils.datapoint``.

    Warning
    -------
    Using custom span reducers is only recommended for advanced users as it currently requires
    knowledge of internal fields and index handling.

    Examples
    --------
    The following pattern of grouping by and reducing over the ``"context_uid"`` index is common.

    .. testcode::

        from snorkelflow.operators import span_reducer
        from snorkelflow.extraction.span import SpanCols

        # Get the first span in each document
        @span_reducer(name="first_reducer")
        def first_reducer(df: pd.DataFrame) -> pd.DataFrame:
            df = df.loc[df.groupby([SpanCols.CONTEXT_UID])[SpanCols.CHAR_START].idxmin()]
            return df

        # Get the last span in the doc and convert to a DocDatapoint
        from snorkelflow.utils.datapoint import DocDatapoint
        @span_reducer(name="last_reducer", datapoint_instance=DocDatapoint())
        def last_reducer(df: pd.DataFrame) -> pd.DataFrame:
            df = df.loc[df.groupby([SpanCols.CONTEXT_UID])[SpanCols.CHAR_START].idxmin()]
            return df

        # Get multiple spans per doc expressed as a list
        @span_reducer(name="multi_reducer", datapoint_instance=DocDatapoint())
        def multi_reducer(df: pd.DataFrame) -> pd.DataFrame:
            from snorkelflow.extraction.span import SpanCols
            index_col = df.index.name
            df = df.reset_index()
            df = df.groupby([SpanCols.CONTEXT_UID]).agg(list)
            df[index_col] = df[index_col].str[0]
            df = df.reset_index().set_index(index_col)
            return df

        # Register any of the above reducers to make them available to add in the DAG
        sf.add_operator(multi_reducer)

    Parameters
    ----------
    name
        Name of the Reducer
    f
        Function that accepts as input from ``pd.DataFrame`` and outputs
        a ``pd.DataFrame``.
    datapoint_instance
        An instance of the datapoint type to reduce to. For example if you are reducing from spans to docs, this
        should be DocDatapoint
    resources
        Resources passed in to ``f`` via ``kwargs``
    input_schema
        Dictionary mapping from column to dtype, used to validate the
        dtypes of the input dataframe.
    output_schema
        Dictionary mapping from column to dtype, used to validate the
        dtypes of the output dataframe.
    """

    def __init__(
        self,
        name: Optional[str] = None,
        datapoint_instance: Optional[DatapointType] = SpanDatapoint(),
        resources: Optional[Dict[str, Any]] = None,
        input_schema: Optional[ColSchema] = None,
        output_schema: Optional[ColSchema] = None,
    ) -> None:
        if callable(name):
            raise ValueError("Looks like this decorator is missing parentheses.")
        self.name = name
        self.resources = resources
        self.datapoint_instance = datapoint_instance
        self._input_schema = input_schema
        self._output_schema = output_schema

    def __call__(self, f: Callable[..., pd.DataFrame]) -> UDFSpanReducer:
        """Wrap around the callable."""
        name = self.name or f.__name__
        name = f"custom_{name}"
        return UDFSpanReducer(
            name=name,
            f=f,
            datapoint_instance=self.datapoint_instance,
            resources=self.resources,
            input_schema=self._input_schema,
            output_schema=self._output_schema,
        )


class UDFSpanNormalizer(SpanNormalizer, UserDefinedOperator):
    """Base class for a SpanNormalizer.

    This class wraps a function that accepts a ``span_text`` str and returns
    the normalized ``span_text``.

    Parameters
    ----------
    name
        Name of the Normalizer
    f
        Function that accepts as input from ``span_text`` str and outputs
        a normalized str.
    resources
        Resources passed in to ``f`` via ``kwargs``
    """

    def __init__(
        self,
        name: str,
        f: Callable[..., pd.DataFrame],
        resources: Optional[Dict[str, Any]] = None,
    ) -> None:
        SpanNormalizer.__init__(self)
        UserDefinedOperator.__init__(self, name, f, resources)

    def to_json(self) -> Dict[str, Any]:
        """Subclass method to save field instead of input and output schemas.

        Returns
        -------
        dict
            Deserialized JSON of the normalizer.
        """
        return dict(
            name=self.name,
            f=serialize_asset(self._f),
            resources=_serialize_dict(self._resources),
        )

    @classmethod
    def from_json(cls, config: Dict[str, Any]) -> "UDFSpanNormalizer":
        """Deserialize this class from a JSON config.

        Returns
        -------
        dict
            Normalizer created from the JSON.
        """
        return cls(
            name=config["name"],
            f=deserialize_asset(config["f"]),
            resources=_deserialize_dict(config["resources"]),
        )

    def _normalize(self, span_text: str) -> str:
        return generic_error_wrapper(
            self._f, self.name, getattr(self, "node_uid", None)
        )(span_text, **self._resources)


class span_normalizer:  # noqa E301
    """Decorator for converting span text to a standard format.

    The decorator wraps a function that takes a string of the span text (e.g. ``"Jan. 1, 2020"``)
    as input and outputs the normalized string (e.g. ``"2020-01-01"``).

    Normalization is useful before reduction so that the reducer can aggregate over
    different forms of the same entity.

    Examples
    --------
    For example, a date normalizer can be used when trying to extract dates from a document
    to ensure that a reducer will aggregate all forms of the same date (e.g. the spans
    ``"Jan. 1, 2020"`` and ``"2020-01-01"`` are treated as the same date and the model
    predictions can be aggregated).

    .. testcode::

        from snorkelflow.operators import span_normalizer

        @span_normalizer(name="date_normalizer")
        def date_normalizer(span_text: str) -> str:
            import re
            from dateutil.parser import parse

            pattern = re.compile(r"([0-9]{1,2})(?:st|nd|rd|th)? day of")
            sub_pattern = pattern.sub(r"\\1", span_text)
            if isinstance(sub_pattern, int):
                return sub_pattern
            try:
                parsed = str(parse(sub_pattern).date())
            except ValueError:
                return span_text
            return parsed

        sf.add_operator(date_normalizer)

    Parameters
    ----------
    name
        Name of the Normalizer
    f
        Function that accepts as input a string and outputs a string.
    resources
        Resources passed in to ``f`` via ``kwargs``
    """

    def __init__(
        self, name: Optional[str] = None, resources: Optional[Dict[str, Any]] = None
    ) -> None:
        if callable(name):
            raise ValueError("Looks like this decorator is missing parentheses.")
        self.name = name
        self.resources = resources

    def __call__(self, f: Callable[..., pd.DataFrame]) -> UDFSpanNormalizer:
        """Wrap around the callable."""
        name = self.name or f.__name__
        name = f"custom_{name}"
        return UDFSpanNormalizer(name=name, f=f, resources=self.resources)


class UDFPageSplitter(BasePageSplitter, UserDefinedOperator):
    """Base class for a user-defined ``PageSplitter``.

    See the ``@page_splitter`` decorator for usage.

    Parameters
    ----------
    name
        Name of the user-defined page splitter
    f
        Function that accepts ``row: pd.Series`` as input and outputs a
        list of lists ``page_ids: List[List[int]]``, corresponding to the
        page indices of each split.
    resources
        Resources passed in to ``f`` via ``kwargs``
    resources_fn
        A function for generating a dictionary of values passed to ``f``
        via ``kwargs``, that are too expensive to serialize as resources.
    """

    def __init__(
        self,
        name: str,
        f: Callable[..., pd.DataFrame],
        resources: Optional[Dict[str, Any]] = None,
        resources_fn: Optional[Callable[[], Dict[str, Any]]] = None,
    ) -> None:
        UserDefinedOperator.__init__(self, name, f, resources, resources_fn)

    def to_json(self) -> Dict[str, Any]:
        """Subclass method to save field instead of input and output schemas."""
        return dict(
            name=self.name,
            f=serialize_asset(self._f),
            resources=_serialize_dict(self._resources),
            resources_fn=serialize_asset(self._resources_fn),
        )

    @classmethod
    def from_json(cls, config: Dict[str, Any]) -> "UDFPageSplitter":
        """Deserialize this class from a JSON config."""
        return cls(
            name=config["name"],
            f=deserialize_asset(config["f"]),
            resources=_deserialize_dict(config["resources"]),
            resources_fn=None
            if "resources_fn" not in config
            else deserialize_asset(config["resources_fn"]),
        )

    def _split_pages(self, row: pd.Series) -> List[List[int]]:
        return generic_error_wrapper(
            self._f, self.name, getattr(self, "node_uid", None)
        )(row, **self._get_resource_kwargs())


class page_splitter:
    """Decorator for splitting PDFs into groups of pages.

    Each row's features can be used to detemine how the document is split.
    The wrapped function accepts a DataFrame row (which generally corresponds to a
    single document) and outputs a list of page splits. Each page split is a list of page
    indices in the document corresponding to the split. For example, if you want to split
    the even and odd pages of a 5 page document, the output would look like [[0,2,4], [1,3]].

    Warning
    -------
    Each page can only be in one of the page splits (i.e. you can't have duplicate page indices in
    different items in the list). Each page split MUST also be in sorted order.

    Examples
    --------
    The following examples demonstrate how to use the decorator:

    .. testcode::

        # Getting the first and last page of each doc
        from snorkelflow.operators import page_splitter
        @page_splitter(name="first_last_page")
        def first_last_page(row: pd.Series) -> List[List[int]]:
            from snorkelflow.rich_docs.rich_doc import RichDocCols
            page_docs = row[RichDocCols.PAGE_DOCS]
            return [[0, len(page_docs) - 1]]

        # Splitting the even/odd pages in the document
        @page_splitter(name="even_odd_pages")
        def even_odd_pages(row: pd.Series) -> List[List[int]]:
            from snorkelflow.rich_docs.rich_doc import RichDocCols
            page_docs = row[RichDocCols.PAGE_DOCS]
            even_splits = list(range(0, len(page_docs), 2))
            odd_splits = list(range(1, len(page_docs), 2))
            return [even_splits, odd_splits]

        # Split documents into batches of 5 pages
        @page_splitter(name="batch_five_pages")
        def batch_five_pages(row: pd.Series) -> List[List[int]]:
            from snorkelflow.rich_docs.rich_doc import RichDocCols
            page_docs = row[RichDocCols.PAGE_DOCS]
            page_ids = list(range(len(page_docs)))
            return [page_ids[i:i + 5] for i in range(0, len(page_ids), 5)]

        # Finding all pages that have the compiled regex pattern
        import re
        pattern = re.compile(r"(?:hellog|good morning)", flags=re.IGNORECASE)

        @page_splitter(name="greetings_splitter",
            resources=dict(compiled_pattern=pattern),
        )
        def greetings_splitter(row: pd.Series, compiled_pattern: re.Pattern) -> List[List[int]]:
            # Find all pages that have the pattern
            from snorkelflow.rich_docs.rich_doc import RichDocCols
            # Enumerates over each page's RichDoc to find matches
            page_docs = row[RichDocCols.PAGE_DOCS]
            page_ids = []
            for page_idx, page_rd in enumerate(page_docs):
                result = compiled_pattern.findall(page_rd.text)
                if len(result) != 0:
                    page_ids.append(page_idx)
            return [page_ids]

        # Register any one of the operators above to the dataset
        sf.add_operator(greetings_splitter)

    Parameters
    ----------
    name
        Name of the page splitter
    resources
        Resources passed in to ``f`` via ``kwargs``
    resources_fn
        A function for generating a dictionary of values passed to ``f``
        via ``kwargs``, that are too expensive to serialize as resources.
    """

    def __init__(
        self,
        name: str,
        resources: Optional[Dict[str, Any]] = None,
        resources_fn: Optional[Callable[[], Dict[str, Any]]] = None,
    ) -> None:
        if callable(name):
            raise ValueError("Looks like this decorator is missing parentheses.")
        self.name = name
        self.resources = resources
        self.resources_fn = resources_fn

    def __call__(self, f: Callable[..., pd.DataFrame]) -> UDFPageSplitter:
        """Wrap around the callable."""
        name = self.name or f.__name__
        name = f"custom_{name}"
        return UDFPageSplitter(
            name=name, f=f, resources=self.resources, resources_fn=self.resources_fn
        )


def is_user_defined(cls_name: str) -> bool:
    """Return True if ``cls_name`` is user-defined.

    Parameters
    ----------
    cls_name
        Name of the class you want to check.
    """
    try:
        return (
            # Client passes 'UserDefinedOperator' as operator name in processor configs.
            # It does NOT (as may be expected) pass the subclass's cls name.
            cls_name == UserDefinedOperator.__name__
            or issubclass(get_udf_class(cls_name), UserDefinedOperator)
        )
    except ValueError:
        return False


def get_udf_class(cls: str) -> Any:
    """Return the user-defined functions associated with a class name.

    Parameters
    ----------
    cls
        Name of the class.

    Returns
    -------
    Any
       Class associated with this class name.
    """
    # this has an assumption that udf operators are built on top of built-in operators
    if cls not in operators_dict:
        raise ValueError(
            f"Operator class not found: {cls}. Make sure the class file is imported above."
        )
    return operators_dict[cls]


def get_user_defined_operator(cls: str, config: Dict[str, Any]) -> UserDefinedOperator:
    """Return the user-defined function of a certain class with a certain config.

    Parameters
    ----------
    cls
        Name of the class.
    config
        Configuration for a function you want.

    Returns
    -------
    UserDefinedOperator
       An UDF instance of this class with this config.
    """
    operator_cls = get_udf_class(cls)
    return operator_cls.from_json(config)  # type: ignore
