from typing import List

from snorkelflow.operators.operator import Operator
from snorkelflow.utils.datapoint import DatapointType


class FixedDatapointOperator(Operator):
    """Abstract operator class that preserves datapoint instance."""

    def get_datapoint_instance(
        self, input_datapoint_instances: List[DatapointType]
    ) -> DatapointType:
        """Return datapoint_instance of first input."""
        return input_datapoint_instances[0]


# TODO: Find way to enforce row preservation.
class ChangeColumns(FixedDatapointOperator):
    """Abstract operator class that preserves rows."""


# TODO: Find way to enforce column preservation.
class ChangeRows(FixedDatapointOperator):
    """Abstract operator class that preserves columns."""


class Filter(ChangeRows):
    """Class that's only meant to be sub-classed by LabelFilter/RowFilter classes"""

    pass
