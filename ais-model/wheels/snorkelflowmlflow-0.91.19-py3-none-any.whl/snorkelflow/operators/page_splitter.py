from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional, Type

import pandas as pd
from dask import dataframe as dd

from api_utils.exceptions import UserInputError
from snorkelflow.extraction.span import SpanCols
from snorkelflow.operators.operator import ColSchema, Operator
from snorkelflow.rich_docs.rich_doc import RichDoc, RichDocCols, RichDocList
from snorkelflow.types.load import DATAPOINT_UID_COL
from snorkelflow.utils.datapoint import DatapointType, PageCols, PageDatapoint


class BasePageSplitter(Operator, ABC):
    """
    Base class for specifying page splitter that split PDF docs by pages
    """

    operator_impl_version: int = 1
    # Columns that uniquely identify a span given the context
    new_datapoint_cols: List[str] = [
        x for x in PageDatapoint.columns if x != SpanCols.CONTEXT_UID
    ]

    @property
    def input_schema(self) -> Optional[ColSchema]:
        return {RichDocCols.PAGE_DOCS: RichDocList}

    @property
    def output_schema(self) -> Optional[ColSchema]:
        return {
            RichDocCols.TEXT_COL: str,
            RichDocCols.JSON_COL: str,
            PageCols.PAGE_IDX: str,
            RichDocCols.CONTEXT_PAGES: List[int],
            RichDocCols.PAGE_CHAR_STARTS: List[int],
            RichDocCols.PAGE_DOCS: RichDocList,
        }

    def get_datapoint_type(
        self, input_datapoint_types: List[Type[DatapointType]]
    ) -> Type[DatapointType]:
        """Get datapoint_type for output DataFrame of the operator, given types for inputs."""
        return PageDatapoint

    @abstractmethod
    def _split_pages(self, row: pd.Series) -> List[List[int]]:
        """ "Returns list of pages that belong to each split"""
        raise NotImplementedError

    def _validate_page_splits(self, page_splits: List[List[int]]) -> None:
        page_ids = [page_id for split in page_splits for page_id in split]
        if len(page_ids) != len(set(page_ids)):
            err_msg = "Page indices in each split need to be unique"
            raise UserInputError(
                detail=err_msg,
                user_friendly_message=err_msg,
                how_to_fix="Change the page splitter logic to separate pages uniquely",
            )
        for pages in page_splits:
            if pages != sorted(pages):
                err_msg = "Page indicies in each split need to be sorted"
                raise UserInputError(
                    detail=err_msg,
                    user_friendly_message=err_msg,
                    how_to_fix="Ensure each page split is sorted",
                )

    def _execute(self, input_ddfs: List[dd.DataFrame]) -> dd.DataFrame:
        def map_fn(df: pd.DataFrame) -> pd.DataFrame:
            pages: List[Dict[str, Any]] = []
            assert self.output_schema is not None  # mypy
            unmodified_input_cols = [
                x for x in df.columns.tolist() if x not in self.output_schema
            ]
            output_cols = list(self.output_schema) + unmodified_input_cols

            for datapoint_uid, row in df.iterrows():
                # Extracting pages from docs
                page_docs = row[RichDocCols.PAGE_DOCS]
                datapoint_instance = PageDatapoint(self.new_datapoint_cols)
                page_splits = self._split_pages(row)
                self._validate_page_splits(page_splits)

                for page_ids in page_splits:
                    # Skipping empty splits
                    if len(page_ids) == 0:
                        continue
                    # Get the page datapoint identifier - uniquely identified by start page/end page
                    start_page = page_ids[0]
                    end_page = page_ids[-1]
                    page_datapoint_id = (
                        f"{start_page}"
                        if start_page == end_page
                        else f"{start_page}-{end_page}"
                    )

                    row_dict = row.to_dict()
                    # Creating a new RichDoc object using the page_ids
                    context_pages = RichDocList([page_docs[_id] for _id in page_ids])
                    context_doc = RichDoc.from_page_docs(context_pages)

                    # Normalizing word char_start/char_end to match extracted spans
                    # Since spans are extracted from context_doc.text the char_start/char_end
                    # start from 0, whereas context_doc.words starts from context_doc.page_char_starts[0]
                    context_doc.normalize_char_starts()

                    page_row = {
                        RichDocCols.TEXT_COL: context_doc.text,
                        RichDocCols.JSON_COL: context_doc.to_json(),
                        PageCols.PAGE_IDX: page_datapoint_id,
                        RichDocCols.CONTEXT_PAGES: page_ids,
                        RichDocCols.PAGE_CHAR_STARTS: context_doc.page_char_starts,
                        RichDocCols.PAGE_DOCS: context_doc.split_pages(),
                    }
                    row_dict[
                        DATAPOINT_UID_COL
                    ] = datapoint_instance.get_new_datapoint_uid_from_old(
                        datapoint_uid, page_row
                    )
                    # New row set to one with updated cols
                    row_dict.update(page_row)
                    pages.append(row_dict)
            return (
                pd.DataFrame(pages, columns=[DATAPOINT_UID_COL] + output_cols)
                .set_index(DATAPOINT_UID_COL)
                .sort_index()
            )

        return self._execute_avoiding_set_index(input_ddfs[0], map_fn, PageDatapoint)
