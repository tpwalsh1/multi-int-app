import csv
import inspect
import os
import time
import traceback
import uuid
from abc import abstractmethod
from collections import defaultdict
from inspect import Parameter
from typing import Any, Callable, Dict, List, Optional, Type

import numpy as np
import pandas as pd
import psutil
from dask import dataframe as dd
from pydantic import BaseModel

from api_utils.exceptions import (
    NotSupportedException,
    OperatorExecutionError,
    SnorkelException,
    UserInputError,
)
from regex_utils.selector import select_compiled_regex
from snorkelflow.types.performance import Performance
from snorkelflow.utils.datapoint import DatapointType
from snorkelflow.utils.file import MINIO_SCHEME
from snorkelflow.utils.logging import get_logger, log_ctx
from snorkelflow.utils.pydantic import get_args, is_optional_field

OPERATOR_CLASS_KEY = "cls"
OPERATOR_KWARGS_KEY = "kwargs"

operators_dict: Dict[str, Any] = {}
prediction_ops_dict: Dict[str, Any] = {}

ColSchema = Dict[str, Any]

logger = get_logger("Operators")


ARTIFACTS_BASE_PATH = "minio://sf_internal_models"

RowsProcessed = int
TotalRows = int
PartitionNum = int
IsDone = bool
OpWithPartitionInfoProgressCallback = Callable[
    [PartitionNum, RowsProcessed, TotalRows, IsDone], None
]


def get_operator_data_dir() -> str:
    uuid_str = str(uuid.uuid4())
    return MINIO_SCHEME + f"snorkel-flow-artifacts/operator_{uuid_str}"


def no_op_progress_callback(*args: Any, **kwargs: Any) -> None:
    pass


class OperatorExample(BaseModel):
    kwargs: Dict[str, Any]
    input_df: Dict[str, Any]
    description: Optional[str] = None


class Operator:
    """Operator class that performs some transformation on dask dataframes.

    See `Using custom data points <https://support.snorkel.ai/hc/en-us/articles/18742255710868-Using-custom-data-points>`_ as one of the example usages.
    """

    """
    Note for devs on Docstrings + Annotations

    Operator docstrings + __init__ args are parsed/returned to the frontend
    to render associated input components in the GUI. Make sure you add a clear,
    user-facing one-liner in the class-level docstring + type-hints in __init__.

    * Special Arg Names:
        * field: str
            Translates to Dropdown for selection of a single DF column
        * fields: List[str]
            Translates to Dropdown for selection of multiple DF columns
    * Special Class Properties:
        * get_options: Callable
            Static method that returns the options for any args in __init__
            as a dictionary of arg_name: List[<option>].
        * show_args_in_gui: bool
            Whether to show args in GUI - if False, rely on defaults from backend
            rather than user-defined args specified via GUI
        * is_deprecated: bool
            Whether this operator is deprecated and should be hidden from the frontend
            NOTE: we may keep a deprecated operator around for backcompat
        * artifact_config_keys: List[str]
            Keys in the input config (i.e. __init__ parameter names) that represent
            paths to files or directories that contain data which back the operator.
            For example, paths to a model pickle file.

    See tdm/api/routers/defaults.py for more.
    """

    show_args_in_gui: bool = True
    is_deprecated: bool = False
    artifact_config_keys: List[str] = []
    operator_impl_version: int = 0

    # if one bump operator_impl_version, it means that DAG needs to be refreshed.
    # we want to avoid expensive refreshing. If possible, accompany with a datasource migration that is cheap to
    # run and solve any backward compatibility issue, an example PR is https://github.com/snorkel-ai/strap/pull/23324
    # if operator_impl_version_to_ds_migration[operator_impl_version] is True,
    # we will automatically refresh for the user on tdm_start.
    # Default is False for all versions (i.e., has to rerun operator).
    operator_impl_version_to_ds_migration: Dict[int, bool] = defaultdict(lambda: False)

    # TODO: There's many more robust ways to do this.
    # Right now, we can only say whether an Operator class is expensive or not, regardless
    # of its parameters or input data. In the future, we'll want to take those factors into account
    is_expensive: bool = False

    init_params: Optional[Dict[Any, Any]] = None
    fit_params: Optional[Dict[Any, Any]] = None

    new_datapoint_cols: List[str] = []
    # for error logging purpose
    node_uid: Optional[int] = None
    errors_file_path: Optional[str] = None

    def __init_subclass__(cls, **kwargs: Any) -> None:
        """Define init subclass to register all subclasses in operators_dict."""
        super(cls).__init_subclass__(**kwargs)  # type: ignore
        # cannot redefine built-in operators. udf classes should have unique names
        op_modules = (
            "operators",
            "snorkelflow.operators",
            "snorkelflow.ocr.featurizer",
            "snorkelflow.ocr.parser",
        )
        prediction_op_modules = "operators.inference"
        if (
            cls.__name__ in operators_dict
            and operators_dict[cls.__name__].__module__.startswith(op_modules)
        ) or (
            cls.__name__ in prediction_ops_dict
            and prediction_ops_dict[cls.__name__].__module__.startswith(
                prediction_op_modules
            )
        ):
            err_msg = (
                f"Can't redefine built-in or reserved internal operator {cls.__name__}"
            )
            raise UserInputError(detail=err_msg, user_friendly_message=err_msg)
        # only registering built-in operators in operators_dict
        elif cls.__module__.startswith(prediction_op_modules):
            prediction_ops_dict[cls.__name__] = cls
        elif cls.__module__.startswith(op_modules):
            operators_dict[cls.__name__] = cls

    @property
    def shuffle_cols(self) -> List[str]:
        """Used to tell whether operator requires shuffle before execution.
        The specified cols will be shuffled into the same partition"""
        return []

    @property
    def use_gpu_if_available(self) -> bool:
        """Whether this operator will run on GPU if one is available."""
        return False

    def _execute_pandas(self, input_df: pd.DataFrame) -> pd.DataFrame:
        """Private method for operating on a Pandas DataFrame."""
        raise NotImplementedError

    def _execute(self, input_ddfs: List[dd.DataFrame]) -> dd.DataFrame:
        """Private method for reading Contexts DataFrame and returning Candidates DataFrame."""
        ddf = input_ddfs[0]
        try:
            return ddf.map_partitions(
                df_operator_error_wrapper(
                    self._execute_pandas,
                    self.__class__.__name__,
                    getattr(self, "node_uid", None),
                )
            )
        except Exception as e:
            if "UserInputError" in str(e):
                error_pattern = select_compiled_regex(
                    'UserInputError\(detail="(.*?)", user_friendly_message="(.*?)"\)\n\nTraceback'
                )
                error_msg = error_pattern.findall(str(e))
                if error_msg and len(error_msg) > 0:
                    raise UserInputError(
                        detail=error_msg[0][0], user_friendly_message=error_msg[0][1]
                    )
            raise e from None

    def _execute_avoiding_set_index(
        self, ddf: dd.DataFrame, map_fn: Callable, datapoint_type: Type[DatapointType]
    ) -> dd.DataFrame:
        """Runs execute on each dataframe partition and manually sets divisions.

        This works because the dataframe is already sorted, so as long as the partition
        is sorted before returning, the resulting dataframe will also be sorted.

        Note that we're not setting the divisions to the "correct" values, but to values
        that guarantee that every entry that would have been found in [divisions[i], divisions[i+1])
        in a dataframe obtained by set_index, will still be found in the same partition.

        To do this, we set every new division to the minimum possible possible value given
        the current value. The only exception is the last division, which needs to be set
        to the maximum possible value.
        """
        assert self.output_meta is not None  # mypy

        col_dict = ddf.dtypes.to_dict()
        ddf = dd.map_partitions(
            df_operator_error_wrapper(
                map_fn, self.__class__.__name__, getattr(self, "node_uid", None)
            ),
            ddf,
            meta={**self.output_meta, **col_dict},
        )
        if all(x is not None for x in ddf.divisions):
            num_cols_new_datapoint = len(
                datapoint_type.get_datapoint_values(ddf.divisions[0])
            ) + len(self.new_datapoint_cols)
            ddf.divisions = datapoint_type.get_new_divisions(
                ddf.divisions, num_cols_new_datapoint
            )

        return ddf

    @property
    @abstractmethod
    def input_schema(self) -> Optional[ColSchema]:
        """Col to dtype map to validate the dtypes of the input dataframe.

        * If value is `None`, any schema is allowed.
        * These are the _minimum_ required fields. Other fields are allowed by default.
        * If type is `None`, any type will be allowed for this field.
        """
        raise NotImplementedError

    @property
    @abstractmethod
    def output_schema(self) -> Optional[ColSchema]:
        """Col to dtype map to validate the dtypes of the output dataframe.

        * If value is `None`, any schema is allowed.
        * These are the _minimum_ required fields. Other fields are allowed by default.
        * If type is `None`, any type will be allowed for this field.

        Don't sort the keys in the output_schema if using the cache_features decorator if the
        order of features could change depending on the initialization.
        """
        raise NotImplementedError

    @property
    def output_meta(self) -> Optional[ColSchema]:
        if self.output_schema is None:
            return None
        return {k: get_dtype(v) for k, v in self.output_schema.items()}

    @property
    def drop_schema(self) -> Optional[List[str]]:
        """List of cols that are dropped as a result of this operator.

        * If value is `None`, does NOT drop any columns.
        """
        return None

    def get_datapoint_type(
        self, input_datapoint_types: List[Type[DatapointType]]
    ) -> Type[DatapointType]:
        """Get datapoint_type for output DataFrame of the operator, given types for inputs."""
        return input_datapoint_types[0]

    def get_datapoint_cols(self, input_datapoint_cols: List[List[str]]) -> List[str]:
        """Get datapoint_cols for output DataFrame of the operator, given columns for inputs."""
        assert input_datapoint_cols  # mypy
        for new_datapoint_col in self.new_datapoint_cols:
            if new_datapoint_col in input_datapoint_cols[0]:
                raise ValueError(
                    f"{new_datapoint_col} is already in the datapoint columns"
                )
        return input_datapoint_cols[0] + self.new_datapoint_cols

    def get_datapoint_instance(
        self, input_datapoint_instances: List[DatapointType]
    ) -> DatapointType:
        """Get datapoint_instance for output DataFrame of the operator, given datapoint_instances for inputs."""
        datapoint_type = self.get_datapoint_type(
            [type(x) for x in input_datapoint_instances]
        )
        datapoint_cols = self.get_datapoint_cols(
            [x.columns for x in input_datapoint_instances]
        )
        return datapoint_type(datapoint_cols)

    def get_artifact_config(self) -> Dict[str, str]:
        """Mapping from operator config keys to data artifact paths.

        Keys correspond to artifact_config_keys property.
        """
        return {k: getattr(self, k) for k in self.artifact_config_keys}

    @classmethod
    def fit_arguments(cls) -> Optional[Dict[str, Any]]:
        """Return fit argument types if operator implements _fit method, and None otherwise."""
        sig = inspect.signature(cls._fit)
        fit_args = {}
        for k in sig.parameters.keys():
            # **kwargs still present; No fit method defined so return None
            if any(
                param
                for param in sig.parameters.values()
                if param.kind == param.VAR_KEYWORD
            ):
                return None
            # Ignore DF as part of fit_arguments
            if k == "df":
                continue
            fit_args[k] = {
                "annotation": sig.parameters[k].annotation,
                "default": sig.parameters[k].default,
            }
        return fit_args

    @classmethod
    def check_fit_arguments(cls, **kwargs: Any) -> None:
        """Check fit arguments."""
        fit_args = cls.fit_arguments()
        if fit_args is not None:
            # Check given arguments
            for k, v in kwargs.items():
                if k not in fit_args:
                    err_msg = f"{k} is not a valid fit argument"
                    raise UserInputError(detail=err_msg, user_friendly_message=err_msg)
                try:
                    if not isinstance(v, fit_args[k]["annotation"]):
                        # if not hasattr(self, )
                        if cls.fit_params is None:
                            err_msg = f"{k} expected of type {fit_args[k]['annotation']} but given value {v} of type {type(v)}"
                            raise UserInputError(
                                detail=err_msg, user_friendly_message=err_msg
                            )
                        elif not isinstance(v, cls.fit_params[k]["annotation"]):
                            err_msg = f"{k} expected of type {cls.fit_params[k]['annotation']} but given value {v} of type {type(v)}"
                            raise UserInputError(
                                detail=err_msg, user_friendly_message=err_msg
                            )
                except TypeError:
                    # TODO(ENG-11810): Use pydantic somehow to take care of type checking for
                    # generic / subscripted types. isinstance doesn't work for those.
                    logger.info(f"Skipping type check for {k}, {fit_args[k]}")

            # Check any missing required argument
            required_fit_args = {
                k: v for k, v in fit_args.items() if v["default"] == Parameter.empty
            }
            diff_args = set(required_fit_args.keys()) - set(kwargs.keys())
            if len(diff_args) != 0:
                err_msg = f"Inputs: {diff_args} are missing"
                raise UserInputError(detail=err_msg, user_friendly_message=err_msg)
            return
        else:
            err_msg = "Operator does not have fit method implemented"
            raise UserInputError(detail=err_msg, user_friendly_message=err_msg)

    @classmethod
    def _fit(cls, df: pd.DataFrame, **kwargs: Any) -> Dict[str, Any]:
        """Trainable operators can subclass this to define how they fit to data."""
        raise NotImplementedError

    @classmethod
    def fit(cls, df: pd.DataFrame, **kwargs: Any) -> Dict[str, Any]:
        """Error handling wrapper for _fit method to fit operator to training data."""
        # Run check_fit_arguments here for back-compat
        cls.check_fit_arguments(**kwargs)
        return cls._fit(df, **kwargs)

    @classmethod
    def _fit_input_schema(cls, **kwargs: Any) -> Optional[ColSchema]:
        """Method that returns expected input_schema of operator after fitting."""
        return None

    @classmethod
    def fit_input_schema(cls, **kwargs: Any) -> Optional[ColSchema]:
        """Error handling wrapper for _fit_input_schema method."""
        cls.check_fit_arguments(**kwargs)
        return cls._fit_input_schema(**kwargs)

    @classmethod
    def get_op_impl_version(cls) -> int:
        return cls.operator_impl_version

    @classmethod
    def get_operator_impl_version_to_ds_migration(cls) -> Dict[int, bool]:
        return cls.operator_impl_version_to_ds_migration

    def execute(
        self,
        input_ddfs: List[dd.DataFrame],
        callback: OpWithPartitionInfoProgressCallback = no_op_progress_callback,
    ) -> dd.DataFrame:
        """Public method for validating + executing operator. Must return dataframe."""

        if self.input_schema:
            # TODO: Support validation for all ddfs, not just the first one.
            validate_df_schema(
                expected_schema=self.input_schema,
                received_schema=input_ddfs[0].dtypes.to_dict(),
                operator_name=self.__class__.__name__,
                missing_col_err_msg_template="'{col_name}' column expected by '{operator_name}', but is not present in downstream dataframe columns {received_schema}. Please update operator input schema or data.",
            )

        output_ddf = self._execute(input_ddfs)

        if self.output_schema:
            validate_df_schema(
                expected_schema=self.output_schema,
                received_schema=output_ddf.dtypes.to_dict(),
                operator_name=self.__class__.__name__,
            )

        return output_ddf

    def get_predictions(
        self, input_df: pd.DataFrame, output_df: pd.DataFrame
    ) -> Dict[str, Any]:
        """Operators capable of producting predictions, such as Models and Extractors,
        can subclass this to define how they return their predictions. df should be the input df
        to the operator. In the future, if spaces other than the SequenceLabelSpace are required, we can
        add that parameter here, however try-catch blocks will be required at import time to
        avoid circular dependencies."""
        err_msg = f"Operator evaluation is not supported for {self.__class__.__name__} operator"
        raise NotSupportedException(detail=err_msg, user_friendly_message=err_msg)

    def estimate_perf(self, df: pd.DataFrame) -> Performance:
        raise NotImplementedError

    def estimate_gpu_perf(self, df: pd.DataFrame) -> Performance:
        raise NotImplementedError

    # Operator documentation.
    def column_docs(self) -> Dict[str, str]:
        def _type_str(dtype: Any) -> str:
            if dtype is None:
                return "Object"
            if hasattr(dtype, "__name__"):
                return dtype.__name__
            return str(dtype)

        return (
            {}
            if self.output_schema is None
            else {
                col: f"{_type_str(dtype)} output of {self.__class__.__name__} operator"
                for col, dtype in self.output_schema.items()
            }
        )

    @staticmethod
    def examples() -> List[OperatorExample]:
        """List of examples (pairs of input df and operator kwargs)."""
        return []

    @staticmethod
    def is_disabled_by_feature_flag() -> bool:
        """
        Returns a boolean indicating whether this operator is disabled by a feature flag.
        """
        return False


class OperatorSchemaViolation(UserInputError):
    """Exception for validation errors on operator schemas."""


def validate_df_schema(
    expected_schema: ColSchema,
    received_schema: ColSchema,
    cast_numpy_dtypes: bool = False,
    operator_name: Optional[str] = None,
    missing_col_err_msg_template: Optional[str] = None,
) -> None:
    """Performs validation for dataframes column types.

    NOTE: We currently do not support EXCLUDED fields.
    That is, we only confirm "What columns are expected?", and
    we don't support "What columns are NOT expected?"
    This level of validation will come with support of column removal Operators.
    """
    error_prefix = f"({operator_name}) " if operator_name else ""

    if expected_schema is None:
        return

    for col_name, expected_col_type in expected_schema.items():
        if col_name not in received_schema:
            # Don't raise an error if its an optional field
            if is_optional_field(expected_col_type):
                continue
            if missing_col_err_msg_template is not None:
                err_msg = missing_col_err_msg_template.format_map(
                    dict(
                        col_name=col_name,
                        operator_name=operator_name,
                        received_schema=set(received_schema.keys()),
                    )
                )
            else:
                err_msg = f"{error_prefix}{col_name} column is expected, but not present in {set(received_schema.keys())}"
            raise OperatorSchemaViolation(detail=err_msg, user_friendly_message=err_msg)
        received_col_type = received_schema[col_name]
        # Get the true expected type for Optional fields
        if is_optional_field(expected_col_type):
            expected_col_type = get_args(expected_col_type)[0]

        # Don't validate type if value is `None`
        if (
            expected_col_type is None
            or received_col_type is None
            or f"{received_col_type}" == "category"
        ):
            continue

        if expected_schema[col_name] == np.number:
            if np.issubdtype(received_col_type, np.number):
                continue
            else:
                err_msg = f"{error_prefix}{col_name} is type: {received_col_type}, expected: {expected_col_type}"
                raise OperatorSchemaViolation(
                    detail=err_msg, user_friendly_message=err_msg
                )

        # With explicit casting, dataframe will cast to broader object anyways...
        if expected_col_type == str or type(expected_col_type) == pd.StringDtype:
            expected_col_type = object
        if received_col_type == str or type(received_col_type) == pd.StringDtype:
            received_col_type = object

        try:
            received_col_type = np.dtype(received_col_type)
            expected_col_type = np.dtype(expected_col_type)
            # Check only the kind of the dtype, not the itemsize, to be compatible with pandas-dev/pandas#40908
            if received_col_type.kind != expected_col_type.kind:
                err_msg = f"{error_prefix}{col_name} is type: {received_col_type}, expected: {expected_col_type}"
                raise OperatorSchemaViolation(
                    detail=err_msg, user_friendly_message=err_msg
                )
        except TypeError as e:
            logger.info(f"Could not cast type to mypy type; ignoring validation: {e}")


def df_operator_error_wrapper(
    f: Callable,
    operator_name: str,
    node_uid: Optional[int] = None,
    partition_progress_callback: OpWithPartitionInfoProgressCallback = no_op_progress_callback,
    reports_row_level_progress: bool = False,
) -> Callable:
    """Wrap a function that runs on a Pandas DataFrame so that it catches
    exceptions and adds a operator name and stack trace to the Exception.
    """

    def g(
        df: dd.DataFrame, partition_info: Any = None, *args: Any, **kwargs: Any
    ) -> Any:
        p = psutil.Process()
        node_uid_str = "None" if not node_uid else f"{node_uid}"
        start_time = time.time()
        partition_number = (
            partition_info.get("number", "Unknown") if partition_info else "Unknown"
        )
        with log_ctx(partition=partition_number, operator=f"{operator_name}"):
            logger.info(
                f" Memory before executing operator={operator_name}, partition number={partition_number}, node_uid={node_uid_str} (RSS): {p.memory_info().rss / 1000_000:.2f} MB, (VMS): {p.memory_info().vms / 1000_000:.2f} MB"
            )

            def progress_callback(rows_processed: int, total_rows: int) -> None:
                partition_progress_callback(
                    partition_number, rows_processed, total_rows, False
                )

            if reports_row_level_progress:
                kwargs["callback"] = progress_callback
            try:
                return f(df, *args, **kwargs)
            except SnorkelException as e:
                err_msg = (
                    f"Error running operator={operator_name}, node_uid={node_uid_str}"
                )
                logger.error(
                    f"{err_msg}. {e.detail}\nStack Trace: {traceback.format_exc()}"
                )
                raise OperatorExecutionError(
                    detail=f"{err_msg}. {e.detail}",
                    user_friendly_message=f"{err_msg}. {e.user_friendly_message}"
                    if e.user_friendly_message
                    else f"{err_msg}. {e.detail}",
                ) from e
            except Exception as e:
                err_msg = (
                    f"Error running operator={operator_name}, node_uid={node_uid_str}: "
                    + repr(e)
                )
                logger.error(f"{err_msg}\nStack Trace: {traceback.format_exc()}")
                raise OperatorExecutionError(
                    detail=err_msg, user_friendly_message=err_msg
                ) from e
            finally:
                # The partition is completely processed and progress will counted at op level, so null out the row level progress.
                partition_progress_callback(partition_number, 0, 0, True)
                logger.info(
                    f" Memory after executing operator={operator_name}, partition number={partition_number}, node_uid={node_uid_str} (RSS): {p.memory_info().rss / 1000_000:.2f} MB, (VMS): {p.memory_info().vms / 1000_000:.2f} MB . Execution time={(time.time() - start_time):.3f}"
                )

    # So that the operator name is displayed in Dask
    g.__name__ = operator_name
    return g


def generic_error_wrapper(
    f: Callable, operator_name: str, node_uid: Optional[int] = None
) -> Callable:
    """Wrap a function that runs on any args."""

    def g(*args: Any, **kwargs: Any) -> Any:
        p = psutil.Process()
        node_uid_str = "None" if not node_uid else f"{node_uid}"
        start_time = time.time()
        logger.info(
            f" Memory before executing operator={operator_name} node_uid={node_uid_str} (RSS): {p.memory_info().rss / 1000_000:.2f} MB"
        )
        try:
            return f(*args, **kwargs)
        except Exception as e:
            err_msg = (
                f"Error running operator={operator_name} node_uid={node_uid_str}: "
                + repr(e)
            )
            logger.error(f"{err_msg}\nStack Trace: {traceback.format_exc()}")
            raise OperatorExecutionError(
                detail=err_msg, user_friendly_message=err_msg
            ) from e
        finally:
            logger.info(
                f" Memory after executing operator={operator_name} node_uid={node_uid_str} (RSS): {p.memory_info().rss / 1000_000:.2f} MB. Execution time={(time.time() - start_time):.3f}"
            )

    # So that the operator name is displayed in Dask
    g.__name__ = operator_name
    return g


def get_dtype(t: Any) -> Any:
    if t is None:
        return object
    # For generic types from typing, e.g. List[int]
    if not isinstance(t, type):
        return object
    for dtype in (np.number, np.character, np.bool, np.datetime64):
        if np.issubdtype(t, dtype):
            return t
    return object


def write_skipped_datapoints(
    datapoints: List[str], error_msgs: List[str], errors_file_path: Optional[str] = None
) -> None:
    """Writes errors (skipped datapoints for now) to errors_file_path"""

    # Lazily import OS-specific python module to avoid import errors on Windows
    # Long term fix should be to used OS agnostic file locking
    import fcntl

    if not errors_file_path:
        return
    os.makedirs(os.path.dirname(errors_file_path), exist_ok=True)

    # Check if file exists and has not 2 columns (pre-saving error msgs), then delete
    if os.path.exists(errors_file_path):
        with open(errors_file_path, "r+") as f:
            fcntl.lockf(f, fcntl.LOCK_EX)
            reader = csv.reader(f)
            for row in reader:
                if len(row) != 2:
                    os.remove(errors_file_path)
                break

    with open(errors_file_path, "a") as f:
        fcntl.lockf(f, fcntl.LOCK_EX)
        logger.info(
            f"Lock acquired, writing in {errors_file_path} the following skipped datapoints: {datapoints}"
        )

        writer = csv.writer(f)
        # Create file with headers if it doesn't exist
        if os.stat(errors_file_path).st_size == 0:
            logger.info("Empty file detected, writing header")
            writer.writerow(["skipped_datapoint", "error_msg"])

        # Write each datapoint and unlock the file
        for datapoint, error_msg in zip(datapoints, error_msgs):
            writer.writerow([datapoint, error_msg])
