from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional

import pandas as pd
from dask import dataframe as dd

from snorkelflow.operators.operator import (
    ColSchema,
    Operator,
    df_operator_error_wrapper,
)
from snorkelflow.types.load import DATAPOINT_UID_COL
from snorkelflow.utils.datapoint import DatapointType


class Reducer(Operator, ABC):
    """
    Maps rows of any daatapoint type to another higher-level datatpoint type. This can
    include things like span to doc, page to doc, span to page, etc.
    """

    operator_impl_version: int = 2

    @property
    def input_schema(self) -> Optional[ColSchema]:
        return None

    @property
    def output_schema(self) -> Optional[ColSchema]:
        return None

    @property
    def shuffle_cols(self) -> List[str]:
        return self._reduced_datapoint_instance.columns

    def get_datapoint_instance(
        self, input_datapoint_instances: List[DatapointType]
    ) -> DatapointType:
        return self._reduced_datapoint_instance

    def _execute(self, input_ddfs: List[dd.DataFrame]) -> dd.DataFrame:
        ddf = input_ddfs[0]

        def _wrapped_reduce(
            df: pd.DataFrame, partition_info: Any = None
        ) -> pd.DataFrame:
            if len(df) == 0:
                return df
            return df_operator_error_wrapper(
                self._reduce, self.__class__.__name__, getattr(self, "node_uid", None)
            )(df, partition_info=partition_info)

        meta: Dict[str, Any] = {}
        meta.update(**{k: v for k, v in ddf.dtypes.to_dict().items()})
        # Output schema types take preference
        if self.output_schema:
            meta.update(**{k: v for k, v in self.output_schema.items()})
        ddf = ddf.map_partitions(_wrapped_reduce, meta=meta)
        reduced_datapoint_cls = self._reduced_datapoint_instance.__class__
        if all(x is not None for x in ddf.divisions):
            ddf.divisions = reduced_datapoint_cls.get_new_divisions(ddf.divisions, 1)
        return ddf

    def _reduce(self, df: pd.DataFrame) -> pd.DataFrame:
        """Reduces one partition of the dask DataFrame."""
        input_cols = df.columns.tolist()
        df = self._reduce_inner(df)

        # Make sure that columns are in the same order s.t. meta matches up
        if self.output_schema:
            input_col_set = set(input_cols)
            output_schema_cols = [
                col for col in self.output_schema if col not in input_col_set
            ]
            input_cols.extend(output_schema_cols)
        df = df[input_cols]

        # Set to the new datapoint instance
        df[
            DATAPOINT_UID_COL
        ] = self._reduced_datapoint_instance.get_datapoint_uid_col_pandas(df)
        return df.set_index(DATAPOINT_UID_COL).sort_index()

    @property
    @abstractmethod
    def _reduced_datapoint_instance(self) -> DatapointType:
        raise NotImplementedError

    @abstractmethod
    def _reduce_inner(self, df: pd.DataFrame) -> pd.DataFrame:
        raise NotImplementedError
