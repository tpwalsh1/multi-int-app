import hashlib
import time
import traceback
from functools import partial
from typing import Any, Callable, Final, List, Optional, Union

import numpy as np
import pandas as pd
from dask import dataframe as dd

from api_utils.config import get_env_var
from api_utils.exceptions import UserInputError
from snorkelflow.operators.fixed_datapoint import ChangeColumns
from snorkelflow.operators.operator import (
    OpWithPartitionInfoProgressCallback,
    df_operator_error_wrapper,
    no_op_progress_callback,
)
from snorkelflow.types.load import DATAPOINT_UID_COL
from snorkelflow.utils.logging import get_logger

logger = get_logger("Featurizer")

RowsProcessed = int
TotalRows = int
OpProgressCallback = Callable[[RowsProcessed, TotalRows], None]


class Featurizer(ChangeColumns):
    """Operator class that adds one or more columns (features) to a DataFrame.

    See `here <https://support.snorkel.ai/hc/en-us/articles/23189377077396>`_ for examples.
    """

    # Featurizers cannot drop any columns.
    drop_schema: Final = None

    def _check_schemas(self) -> None:
        if self.drop_schema is not None:
            raise ValueError(
                f"Unable to execute Featurizer {self.__class__.__name__}. "
                "drop_schema must be None."
            )

        if self.output_schema is None:
            raise ValueError(
                f"Unable to execute Featurizer {self.__class__.__name__}. "
                "output_schema must not be None."
            )

    def _compute_features(
        self,
        input_df: pd.DataFrame,
        callback: OpProgressCallback = no_op_progress_callback,
    ) -> pd.DataFrame:
        raise NotImplementedError

    def _compute_features_embedding(
        self, input_df: pd.DataFrame, embeddings: Optional[np.ndarray] = None
    ) -> pd.DataFrame:
        raise NotImplementedError

    def _execute_pandas(self, input_df: pd.DataFrame) -> pd.DataFrame:
        assert self.output_schema is not None  # Needed for mypy
        unique_df_cols = input_df.columns.difference(self.output_schema).tolist()
        if len(input_df) == 0:
            return pd.DataFrame(
                columns=unique_df_cols
                + list(self.output_schema.keys())
                + [DATAPOINT_UID_COL]
            ).set_index(DATAPOINT_UID_COL)

        # Copy df to prevent accidental addition/deletions of columns.
        # This doesn't prevent in-place modifications, but those are rarer.
        features_df = self._compute_features(input_df.copy(deep=False))[
            self.output_schema.keys()
        ]
        if not input_df.index.identical(features_df.index):
            raise ValueError(
                f"Featurizer {getattr(self, 'name', self.__class__.__name__)} node_uid={getattr(self, 'node_uid', 'None')} should not change dataframe index."
            )
        return input_df[unique_df_cols].assign(
            **{col: features_df[col] for col in self.output_schema}
        )

    def _get_workflow_resource_cache_key(self) -> str:
        raise NotImplementedError

    def _compute_features_ddf(
        self,
        ddf: dd.DataFrame,
        partition_progress_callback: OpWithPartitionInfoProgressCallback = no_op_progress_callback,
    ) -> dd.DataFrame:
        def wrapper(df: pd.DataFrame, **kwargs: Any) -> pd.DataFrame:
            assert self.output_schema is not None  # Needed for mypy
            start_time = time.time()
            logger.info(
                f"Executing Featurizer={getattr(self, 'name', self.__class__.__name__)}, node_uid={getattr(self, 'node_uid', 'None')} - InputDF {df.shape[0]} rows, {df.shape[1]} cols"
            )
            if len(df) == 0:
                return pd.DataFrame(columns=self.output_schema.keys())

            features_df = pd.DataFrame()
            # sending a copy of the df to prevent accidental addition/deletions of columns
            # NOTE: this doesn't prevent in-place modifications, but those are more rare
            try:
                features_df = self._compute_features(df.copy(deep=False), **kwargs)[
                    self.output_schema.keys()
                ]
            except TypeError as t:
                logger.error(
                    f"Encountered Type error while running operator {self.__class__.__name__}, retrying without passing progress callback"
                )
                if "got an unexpected keyword argument" not in str(t):
                    raise t
                kwargs.pop("callback", None)
                features_df = self._compute_features(df.copy(deep=False), **kwargs)[
                    self.output_schema.keys()
                ]

            logger.info(
                f"Finished Executing Featurizer={getattr(self, 'name', self.__class__.__name__)}, node_uid={getattr(self, 'node_uid', 'None')}. ExecutionTime={(time.time() - start_time):.3f} seconds. OutputDF {features_df.shape[0]} rows, {features_df.shape[1]} cols"
            )
            if len(df) != len(features_df) or set(df.index) != set(features_df.index):
                raise ValueError(
                    f"Featurizer {getattr(self, 'name', self.__class__.__name__)} node_uid={getattr(self, 'node_uid', 'None')} should not change dataframe index."
                )
            features_df = features_df.reindex(df.index)
            return features_df

        ddf = ddf.map_partitions(
            df_operator_error_wrapper(
                wrapper,
                self.__class__.__name__,
                getattr(self, "node_uid", None),
                partition_progress_callback,
                reports_row_level_progress=True,
            ),
            meta=self.output_meta,
        )
        return ddf

    def execute(
        self,
        input_ddfs: List[dd.DataFrame],
        callback: OpWithPartitionInfoProgressCallback = no_op_progress_callback,
    ) -> dd.DataFrame:
        ddf = input_ddfs[0]
        self._check_schemas()
        features_ddf = self._compute_features_ddf(ddf, callback)
        assert self.output_schema is not None  # Needed for mypy
        # the columns in features_ddf take precedence if they're already in ddf
        unique_ddf_cols = ddf.columns.difference(self.output_schema).tolist()
        if all(x is not None for x in ddf.divisions) and all(
            x is not None for x in features_ddf.divisions
        ):
            return ddf[unique_ddf_cols].assign(
                **{col: features_ddf[col] for col in self.output_schema}
            )
        else:
            # use merge instead of assign if we have any None divisions
            # since assign can add nan values instead of values in features_ddf in this case
            output_cols = list(self.output_schema.keys())
            return ddf[unique_ddf_cols].merge(
                features_ddf[output_cols], how="left", left_index=True, right_index=True
            )

    @staticmethod
    def is_featurizer() -> bool:
        return True

    def get_featurizer_hash(self) -> str:
        """Used as part of hash when storing features. Has to be overwritten in order to use the
        cache_features decorator.
        """
        raise NotImplementedError

    def get_row_hashes(self, df: Union[pd.DataFrame, dd.DataFrame]) -> pd.Series:
        """Returns a unique hash for each row in the input_df. Only relevant if doing caching using
        the cache_features decorator.
        """
        features = list(self.input_schema.keys()) if self.input_schema else []
        hash_prefix = self.get_featurizer_hash()

        def handle_nan(x: Any) -> str:
            is_nan = pd.isna(x)
            if not isinstance(is_nan, bool):
                is_nan = is_nan.all()
            return "nan" if is_nan else str(x)

        return df.apply(
            lambda row: hash_prefix
            + "".join(
                hashlib.md5(handle_nan(row[x]).encode("utf-8")).hexdigest()
                for x in features
            ),
            axis=1,
        )


def cache_features(func: Callable) -> Callable:
    """Decorator that can be used with _compute_features to check for the features in the on disk
    key value storage, reuse the ones with values, and compute/store the rest.
    """

    def inner_compute_features(
        featurizer: Featurizer,
        input_df: pd.DataFrame,
        callback: OpProgressCallback = no_op_progress_callback,
        load_from_cache_only: bool = False,
    ) -> pd.DataFrame:
        if len(input_df) == 0:
            columns = input_df.columns.to_list()
            if featurizer.output_schema is not None:
                columns += list(featurizer.output_schema)
            return pd.DataFrame(columns=columns)
        df_compute_fn = partial(func, featurizer, input_df, callback)

        feature_store = _get_feature_store(load_from_cache_only=load_from_cache_only)
        if feature_store is None:
            return df_compute_fn()
        import psycopg2
        from psycopg2.pool import PoolError

        from features.features import generate_features

        output_features = (
            list(featurizer.output_schema.keys()) if featurizer.output_schema else []
        )
        computation_fn = partial(func, featurizer)
        row_hashes = featurizer.get_row_hashes(input_df)

        try:
            return generate_features(
                input_df,
                output_features=output_features,
                computation_fn=computation_fn,
                feature_store=feature_store,
                row_hashes=row_hashes,
                callback=callback,
                load_from_cache_only=load_from_cache_only,
            )
        except PoolError:
            logger.info(
                "Postgres connection pool exhausted, not using the feature store"
            )
            check_for_error(load_from_cache_only)
            return df_compute_fn()
        except psycopg2.Error:
            logger.warning("Postgres error, not using the feature store")
            logger.warning(traceback.format_exc())
            check_for_error(load_from_cache_only)
            return df_compute_fn()

    return inner_compute_features


def check_for_error(load_from_cache_only: bool) -> None:
    if load_from_cache_only:
        err_msg = "You cannot use the featurizer in a cache only setting without a valid postgres connection"
        raise UserInputError(user_friendly_message=err_msg, detail=err_msg)


def _get_feature_store(load_from_cache_only: bool = False) -> Any:
    try:
        import psycopg2
        from psycopg2.pool import PoolError

        from features.feature_store import PostgresFeatureStore
        from postgres_utils.pool import out_of_request_fs_db_conn

        with out_of_request_fs_db_conn():
            pass
    except ModuleNotFoundError:
        logger.warning("Postgres not available, not using the feature store")
        check_for_error(load_from_cache_only)
        return None
    except AssertionError:
        # db connection pool is not initialized in dask workers
        dsn = get_env_var("TDM_CONN_STR")
        if dsn is None:
            logger.warning(
                "Failed to connect to Postgres: dsn is None. Resuming without feature store."
            )
            check_for_error(load_from_cache_only)
            return None
        from postgres_utils.pool import init_feature_store_conn_pool

        logger.info("Initializing postgres connection pool")
        init_feature_store_conn_pool(dsn, maxconn=10)
    except PoolError:
        logger.warning(
            "Postgres connection pool exhausted, not using the feature store"
        )
        check_for_error(load_from_cache_only)
        return None
    except ConnectionError:
        logger.warning("Timed out waiting for a postgres connection")
        check_for_error(load_from_cache_only)
        return None
    except psycopg2.Error:
        logger.warning("Postgres error, not using the feature store")
        logger.warning(traceback.format_exc())
        check_for_error(load_from_cache_only)
        return None
    except Exception:
        logger.warning("Unknown error, not using the feature store")
        logger.warning(traceback.format_exc())
        check_for_error(load_from_cache_only)
        return None
    from postgres_utils.pool import out_of_request_fs_db_conn

    return PostgresFeatureStore(out_of_request_fs_db_conn)
