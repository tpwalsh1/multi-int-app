from abc import ABC, abstractmethod
from typing import List, Optional

import pandas as pd
from dask import dataframe as dd

from api_utils.exceptions import UserInputError
from regex_utils.selector import select_compiled_regex
from snorkelflow.operators.fixed_datapoint import Filter
from snorkelflow.operators.operator import ColSchema, df_operator_error_wrapper


class BaseRowFilter(Filter, ABC):
    operator_impl_version: int = 1

    @property
    def input_schema(self) -> Optional[ColSchema]:
        return None

    @property
    def output_schema(self) -> Optional[ColSchema]:
        return None

    def _execute_pandas(self, df: pd.DataFrame) -> pd.DataFrame:
        return df[self._filter_condition(df)]

    def _execute(self, input_ddfs: List[dd.DataFrame]) -> dd.DataFrame:
        ddf = input_ddfs[0]
        try:
            return ddf.map_partitions(
                df_operator_error_wrapper(
                    self._execute_pandas,
                    self.__class__.__name__,
                    getattr(self, "node_uid", None),
                ),
                # Why dont we just do this for all operators?
                meta=ddf.dtypes.to_dict(),
            )
        except Exception as e:
            if "UserInputError" in str(e):
                error_pattern = select_compiled_regex(
                    'UserInputError\(detail="(.*?)", user_friendly_message="(.*?)"\)\n\nTraceback'
                )
                error_msg = error_pattern.findall(str(e))
                if error_msg and len(error_msg) > 0:
                    raise UserInputError(
                        detail=error_msg[0][0], user_friendly_message=error_msg[0][1]
                    )
            raise e from None

    @abstractmethod
    def _filter_condition(self, df: pd.DataFrame) -> pd.Series:
        """Return a series the helps filter the rows of the df"""
        raise NotImplementedError
