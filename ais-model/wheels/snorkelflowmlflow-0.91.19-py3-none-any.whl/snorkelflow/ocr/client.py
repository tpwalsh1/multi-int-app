# Create an OCR client with a registry that allows users to add their own OCR clients
# The client takes in PDF URLs and outputs the OCR output
from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional, Type

from snorkelflow.rich_docs import RichDoc

# registry for OCR clients
ocr_clients: Dict[str, Type["OCRClient"]] = {}


class OCRClient(ABC):
    """Base class for OCR clients."""

    def __init_subclass__(cls, **kwargs: Any) -> None:
        """Registers the OCR client."""
        super().__init_subclass__(**kwargs)
        ocr_clients[cls.__name__] = cls

    @abstractmethod
    def apply_ocr(
        self, pdf_urls: List[str], datapoint_uids: Optional[List[str]] = None
    ) -> Any:
        """Applies OCR to the given PDF URLs.
        datapoint_uids are the corresponding datapoint uids for each PDF URL - used for logging on error.
        """
        pass

    @abstractmethod
    def ocr_to_hocr(self, ocr_result: Any) -> List[str]:
        """Converts the OCR output to hOCR."""
        pass

    @abstractmethod
    def ocr_to_rich_doc(self, ocr_result: Any) -> RichDoc:
        """Converts the OCR output to a RichDoc object."""
        pass
