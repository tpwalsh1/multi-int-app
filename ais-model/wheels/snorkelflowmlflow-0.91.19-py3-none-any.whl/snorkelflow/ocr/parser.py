from abc import ABC, abstractmethod
from typing import Any, List, Optional

import pandas as pd

from snorkelflow.operators.base_rich_doc_parser import BaseRichDocParser
from snorkelflow.operators.featurizer import OpProgressCallback
from snorkelflow.operators.operator import ColSchema, no_op_progress_callback


class OCRParser(BaseRichDocParser, ABC):
    """Base class that takes in a pdf url field and outputs the RichDoc object."""

    is_expensive = True
    hidden_ocr_col: str = "_ocr_output"

    def __init__(self, pdf_url_field: str):
        self.pdf_url_field = pdf_url_field

    @property
    def input_schema(self) -> Optional[ColSchema]:
        return {self.pdf_url_field: str}

    @property
    @abstractmethod
    def ocr_client(self) -> Any:
        """Creates a client using the underlying OCR engine."""
        pass

    def _apply_ocr_to_files(self, pdf_urls: pd.Series) -> List[Any]:
        """Apply OCR to the given PDF URLs and convert the output to a RichDoc object."""
        result = self.ocr_client.apply_ocr(pdf_urls)
        return result

    def _parse_ocr(self, ocr_output: Any) -> pd.Series:
        rich_doc = self.ocr_client.ocr_to_rich_doc(ocr_output)
        return self._rich_doc_to_columns(rich_doc)

    def _compute_features(
        self,
        input_df: pd.DataFrame,
        callback: OpProgressCallback = no_op_progress_callback,
    ) -> pd.DataFrame:
        input_df[self.hidden_ocr_col] = self._apply_ocr_to_files(
            input_df[self.pdf_url_field]
        )
        return input_df.apply(
            lambda row: self._parse_ocr(ocr_output=row[self.hidden_ocr_col]), axis=1
        )
