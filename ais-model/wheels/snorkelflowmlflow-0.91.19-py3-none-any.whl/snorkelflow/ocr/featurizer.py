from abc import ABC, abstractmethod
from typing import List, Optional

import pandas as pd

from snorkelflow.operators.featurizer import Featurizer, OpProgressCallback
from snorkelflow.operators.operator import ColSchema, no_op_progress_callback

from .client import OCRClient


# Create base class that takes in a pdf url field and outputs the OCR output
class OCRFeaturizer(Featurizer, ABC):
    """Base class that takes in a pdf url field and outputs the OCR output."""

    is_expensive = True

    def __init__(self, pdf_url_field: str, output_field: str):
        self.pdf_url_field = pdf_url_field
        self.output_field = output_field

    @property
    def input_schema(self) -> Optional[ColSchema]:
        return {self.pdf_url_field: str}

    @property
    def output_schema(self) -> Optional[ColSchema]:
        return {self.output_field: str}

    @property
    @abstractmethod
    def ocr_client(self) -> OCRClient:
        """Creates a client using the underlying OCR engine."""
        pass

    def _apply_ocr_to_files(
        self, pdf_urls: pd.Series, datapoint_uids: List[str]
    ) -> List[str]:
        result = self.ocr_client.apply_ocr(pdf_urls, datapoint_uids)
        return self.ocr_client.ocr_to_hocr(result)

    def _compute_features(
        self,
        input_df: pd.DataFrame,
        callback: OpProgressCallback = no_op_progress_callback,
    ) -> pd.DataFrame:
        input_df[self.output_field] = self._apply_ocr_to_files(
            input_df[self.pdf_url_field], input_df.index.tolist()
        )
        return input_df
