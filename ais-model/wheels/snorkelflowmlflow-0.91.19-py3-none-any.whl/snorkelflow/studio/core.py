import inspect
from types import FunctionType
from typing import Any, Callable, Dict, Mapping, Optional

from snorkelflow.lfs.lfs import LabelingFunction, labeling_function


class resources_fn_labeling_function(labeling_function):
    """
    Subclass of :class:`@labeling_function<snorkelflow.lfs.lfs.labeling_function>` decorator that allows passing resources as functions.

    Parameters
    ----------
    name
        Name of the LF
    resources
        Labeling resources passed in to ``f`` via ``kwargs``
    resources_fn
        A function that takes no arguments and returns a dict of resources,
        which is passed as kwargs to the underlying function. Expensive
        dependencies (like spacy nlp) and imports should be passed here to
        avoid serializing or repeatedly computing them.

    Examples
    --------
    >>> from snorkelflow.studio import resources_fn_labeling_function
    >>> def get_nlp() -> Dict[str, Any]:
    ...     import spacy
    ...     return {"nlp": spacy.load("en_core_web_sm")}
    >>> @resources_fn_labeling_function(name="my_lf", resources_fn=get_nlp)
    ... def many_entities(x, nlp) -> str:
    ...     return "LABEL" if len(nlp(x).ents) > 5 else "UNKNOWN"
    """

    def __init__(
        self,
        name: Optional[str] = None,
        resources: Optional[Mapping[str, Any]] = None,
        resources_fn: Optional[Callable[[], Dict[str, Any]]] = None,
    ) -> None:
        self.resources_fn = resources_fn
        self.fn_resources: Optional[Dict[str, Any]] = None
        super().__init__(name, resources)

    def __call__(self, f: Callable[..., str]) -> LabelingFunction:
        """Wrap around the callable."""

        def f_wrapper(func: Callable) -> Callable:
            def f_with_resources(*args: Any, **kwargs: Any) -> Any:
                # Compute resources_fn if not already computed.
                if self.fn_resources is None:
                    self.fn_resources = (
                        {} if self.resources_fn is None else self.resources_fn()
                    )
                kwargs.update(self.fn_resources)
                return func(*args, **kwargs)

            return f_with_resources

        # Set the name of the LF to the name of the wrapped function here
        # otherwise it would be "f_with_resources" after the wrapper function.
        self.name = self.name or f.__name__
        return super().__call__(f_wrapper(f))


def is_decorated_by_resources_fn_labeling_function(lf: LabelingFunction) -> bool:
    # If the wrapped func has two closures and the outer one is "resources_fn_labeling_function",
    # the UDF is very likely decorated by resources_fn_labeling_function.
    wrapped_func = lf._f
    if wrapped_func.__closure__ is not None and len(wrapped_func.__closure__) == 2:
        outer_obj = wrapped_func.__closure__[1].cell_contents
        # Note that resources_fn_labeling_function is a class.
        if isinstance(outer_obj, resources_fn_labeling_function):
            return True
    return False


def get_lf_source(lf: LabelingFunction) -> Dict[str, Any]:
    code: Dict[str, Any] = {"_resources": {}}
    if lf._resources:
        for k, v in lf._resources.items():
            if isinstance(v, FunctionType):
                code["_resources"][k] = inspect.getsource(v)
    if is_decorated_by_resources_fn_labeling_function(lf):
        # The first closure is the wrapped function
        wrapped_func = lf._f
        assert wrapped_func.__closure__ is not None  # mypy
        udf = wrapped_func.__closure__[0].cell_contents
        code["_f"] = inspect.getsource(udf)
        outer_func: resources_fn_labeling_function = wrapped_func.__closure__[
            1
        ].cell_contents
        if outer_func.resources_fn:
            code["_resources_fn"] = inspect.getsource(outer_func.resources_fn)
    else:
        code["_f"] = inspect.getsource(lf._f)
    return code


def _get_spacy_nlp() -> Dict[str, Any]:
    import spacy

    return {"nlp": spacy.load("en_core_web_sm")}


class spacy_labeling_function(resources_fn_labeling_function):
    """Convenience decorator for spacy based labeling functions.

    The decorated function must have an additional `nlp` argument which represents
    the spacy en-core-web-sm model.

    Parameters
    ----------
    name
        Name of the LF
    resources
        Labeling resources passed in to ``f`` via ``kwargs``

    Examples
    --------
    >>> from snorkelflow.studio import spacy_labeling_function
    >>> @spacy_labeling_function(name="my_spacy_lf")
    ... def many_entities(x, nlp) -> int:
    ...     return 0 if len(nlp(x.txt).ents) > 5 else -1
    """

    def __init__(
        self,
        name: Optional[str] = None,
        resources: Optional[Mapping[str, Any]] = None,
    ) -> None:
        super().__init__(name, resources, resources_fn=_get_spacy_nlp)


def _get_stanza_nlp() -> Dict[str, Any]:
    import stanza  # type: ignore

    return {
        "nlp": stanza.Pipeline(
            lang="en",
            processors="tokenize,pos,lemma,ner",
            model_dir="/var/lib/snorkel/.stanza_resources",
            download_method="reuse_resources",
        )
    }


class stanza_labeling_function(resources_fn_labeling_function):
    """Convenience decorator for stanza based labeling functions.

    The decorated function must have an additional `nlp` argument which represents
    the stanza en model.

    Parameters
    ----------
    name
        Name of the LF
    resources
        Labeling resources passed in to ``f`` via ``kwargs``

    Examples
    --------
    >>> from snorkelflow.studio import stanza_labeling_function
    >>> @stanza_labeling_function(name="my_stanza_lf")
    ... def many_entities(x, nlp) -> int:
    ...     return 0 if len(nlp(x.txt).ents) > 5 else -1
    """

    def __init__(
        self,
        name: Optional[str] = None,
        resources: Optional[Mapping[str, Any]] = None,
    ) -> None:
        super().__init__(name, resources, resources_fn=_get_stanza_nlp)
