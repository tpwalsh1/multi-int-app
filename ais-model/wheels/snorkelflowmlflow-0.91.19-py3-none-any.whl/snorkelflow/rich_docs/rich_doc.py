import base64
import json
import pickle
from typing import Any, Dict, List, Optional, Tuple, Union

import numpy as np
import pandas as pd

from snorkelflow.extraction.span import SpanCols
from snorkelflow.serialization.serializable import Serializable
from snorkelflow.utils.logging import get_logger

logger = get_logger("RichDoc")

CHAR_START = SpanCols.CHAR_START
CHAR_END = SpanCols.CHAR_END

# Structural
PAGE_ID = "page_id"
AREA_ID = "area_id"
PAR_ID = "par_id"
LINE_ID = "line_id"
WORD_ID = "word_id"

# Tabular
ROW_ID = "row_id"

# VISUAL
LEFT = "left"
TOP = "top"
RIGHT = "right"
BOTTOM = "bottom"
MIDDLE = "middle"

# Text
TEXT = "text"
FONT_SIZE = "font_size"

# Column groups
BBOX_COLS = [LEFT, TOP, RIGHT, BOTTOM]
PAGE_COLS = [PAGE_ID] + BBOX_COLS
AREA_COLS = [AREA_ID] + BBOX_COLS
PAR_COLS = [PAR_ID] + BBOX_COLS
LINE_COLS = [LINE_ID, FONT_SIZE] + BBOX_COLS
ID_COLS = [PAGE_ID, AREA_ID, PAR_ID, LINE_ID, WORD_ID]
WORD_COLS = ID_COLS + BBOX_COLS + [TEXT]

DF_TO_ID = dict(pages=PAGE_ID, areas=AREA_ID, pars=PAR_ID, lines=LINE_ID, words=WORD_ID)


HOCR_START_STR = "<?xml version='1.0' encoding='UTF-8'?>\n<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Transitional//EN'\n 'http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd'>\n<html xmlns='http://www.w3.org/1999/xhtml' xml:lang='en' lang='en'>\n <head>\n  <title></title>\n  <meta http-equiv='Content-Type' content='text/html;charset=utf-8'/>\n  <meta name='ocr-system' content='tesseract 4.1.1' />\n  <meta name='ocr-capabilities' content='ocr_page ocr_carea ocr_par ocr_line ocrx_word ocrp_wconf'/>\n </head>\n <body>\n"
HOCR_END_STR = "\n </body>\n</html>"

Index = int
FontSize = float
BboxCoord = int
Text = str
PagesType = List[Tuple[Index, BboxCoord, BboxCoord, BboxCoord, BboxCoord]]
AreasType = List[Tuple[Index, BboxCoord, BboxCoord, BboxCoord, BboxCoord]]
ParsType = List[Tuple[Index, BboxCoord, BboxCoord, BboxCoord, BboxCoord]]
LinesType = List[Tuple[Index, FontSize, BboxCoord, BboxCoord, BboxCoord, BboxCoord]]
WordsType = List[
    Tuple[
        Index,
        Index,
        Index,
        Index,
        Index,
        BboxCoord,
        BboxCoord,
        BboxCoord,
        BboxCoord,
        Text,
    ]
]


class RichDocCols:
    """Base class that specifies Rich Doc columns."""

    PKL_COL = "rich_doc_pkl"  #: Serialized version of the RichDoc object
    TEXT_COL = "rich_doc_text"  #: Extracted plain text from the PDF
    JSON_COL = "rich_doc_json"
    CONTEXT_PAGES = "context_pages"
    """JSON dump containing the positions of words, lines, etc"""
    DOC_COL = "rich_doc"  #: The RichDoc object, which can be used to extract properties of the document
    PDF_URL_COL = "rich_doc_pdf_url"  #: The URL/file location of the PDF
    SPAN_START_WORD_ID = "rich_doc_span_start_word_id"  #: The id of the word at the start of the span, relative to all other words in the document
    SPAN_START_CHAR_OFFSET = "rich_doc_span_start_char_offset"  #: The offset from the char_start of the first word in a span
    SPAN_END_WORD_ID = "rich_doc_span_end_word_id"  #: The id of the word at the end of the span, relative to all other words in the document
    SPAN_END_CHAR_OFFSET = "rich_doc_span_end_char_offset"  #: The offset from the char_end of the last word in a span
    SPAN_PAGE_ID = "rich_doc_span_page_id"  #: The page # that the span belongs to
    PAGE_CHAR_STARTS = "page_char_starts"  #: A list of character offsets that denote where in the rich_doc_text each page starts
    PAGE_DOCS = "page_docs"  #: A list of RichDoc objects where each item corresponds to the RichDoc of a single page, in order
    SPAN_NGRAM = "rich_doc_span_ngram"  #: An n-gram of the words in the span; See :py:meth:`Ngram <rich_doc_wrapper.rich_doc_wrapper.Ngram>` for more
    HV_LINES = "hv_lines"  #: A :py:meth:`HVLines <snorkelflow.rich_docs.HVLines>` object that captures the vertical/horiztonal lines in a doc; requires a `LinesFeaturizer` in the DAG
    TEXT_CLUSTERS = "text_clusters"  #: A :py:meth:`TextClusters <snorkelflow.rich_docs.TextClusters>` object object that captures horizontal clusters of words; requires a `TextClusterer` in the DAG
    TEXT_CLUSTER_ID = "text_cluster_id"
    """A global cluster id associated with each text cluster"""
    TEXT_REGION_ID = "text_region_id"  #: When `LinesFeaturizer` is added, the user can group vertical and horizontal lines into regions; this field denotes which region is associate with a span
    LAYOUT_STRUCTURE_BBOXS = "layout_structure_bboxs"  #: When `DocumentLayoutFeaturizer` is added, the user can group layout structures into regions


class MissingRichDocException(Exception):
    """An Exception raised when a RichDoc was expected and could not be found."""


class RowNotFoundException(Exception):
    """An Exception raised when the text for a given row_id is expected and could not be found."""


class NoWordsFoundInSpanException(Exception):
    """An Exception raised when no spans were extracted from a document."""


class RichDoc(Serializable):
    """An object representing a document with rich formatting preserved.

    For additional utilities for operating on a RichDoc document, see the RichDocWrapper class.

    Types of signals available via RichDoc:

    * textual:
        * A text-only representation of the document (no markup present)
    * structural:
        * All words are assigned a line, par(agraph), area, and page. Lines may include font size information
    * visual:
        * Objects of all granularities contain bounding box coordinates
    * tabular:
        * Currently expressed primarily via visual signals (e.g., vertical and horizontal alignments)

    Other Notes:

    * [0, 0] is in the top-left corner (so bottom > top and right > left)

    Parameters
    ----------
    pages:
        A DataFrame of page objects
    areas:
        A DataFrame of area objects
    pars:
        A DataFrame of paragraph objects
    lines:
        A DataFrame of line objects
    words:
        A DataFrame of word objects, with bounding boxes, parent obj. assignments, etc.
    text:
        The derived text representation of the RichDoc if it is known.
        Typically this is None and the text is auto-generated to ensure consistency.
        It may be passed, however, when serializing/deserializing, for efficiency.
    """

    def __init__(
        self,
        pages: pd.DataFrame,
        areas: pd.DataFrame,
        pars: pd.DataFrame,
        lines: pd.DataFrame,
        words: pd.DataFrame,
        text: Optional[str] = None,
        text_by_row: Optional[pd.DataFrame] = None,
    ):
        self.pages = pages
        self.areas = areas
        self.pars = pars
        self.lines = lines
        self.words = words

        # Note that this __init__ method is called on deserialization, so all active
        # computation in this method should either be lightweight or be able to be
        # skipped if its effects are already present (e.g., a derived field is already
        # calculated).

        # Drop empty words (i.e. words whose text is empty or whitespace only)
        # Do this mostly for more intuitive rows that match what users see on the page
        # e.g., invisible rows throw off what row ranges are appropriate for features
        # This may also save space (a secondary benefit)
        # On sec100, this is up to 20% of words (~4% on average)
        non_empty_words = self.words.text.apply(lambda x: bool(x.strip()))

        self.words = self.words.loc[non_empty_words]

        # Additionally drop areas, pars and lines that contained only empty words
        self.areas = self.areas[self.areas.index.isin(self.words["area_id"])]
        self.pars = self.pars[self.pars.index.isin(self.words["par_id"])]
        self.lines = self.lines[self.lines.index.isin(self.words["line_id"])]

        if CHAR_START not in self.words.columns or CHAR_END not in self.words.columns:
            self._add_word_offsets()

        if CHAR_START not in self.pages.columns:
            self._add_page_offsets()

        # On sec100, this step takes about 0.01s/doc
        if ROW_ID not in self.words.columns:
            self._add_row_ids()

        # Greedily calculate text derived from the structural assignments of the doc,
        # as it is only ~10% of the size of the other attributes on average and
        # prevents potential accidental recomputation for every span.
        # Allow it to be passed so that it won't be recreated on (de)serialization
        # On sec100, this step takes < 0.001s/doc
        self.text = text if text is not None else self._to_text()

        # Pre-group and compute the text corresponding to each visual row in the doc
        # to avoid redundant computation at the span level.
        # Allow it to be passed so that it won't be recreated on (de)serialization
        # On sec100, this step takes XXX s/doc.
        self.text_by_row = (
            text_by_row if text_by_row is not None else self._add_text_by_row()
        )

    def __repr__(self) -> str:
        return f"RichDoc({len(self.pages)} page(s), {len(self.words)} words)"

    @classmethod
    def deserialize(cls, serialized: str) -> "RichDoc":
        """Deserialize the RichDoc instance from the encoded pickle representation.

        Parameters
        ----------
        serialized
            A base64-encoded string representation of the RichDoc pickle.
        """
        # base64 encoding is used to convert bytes to str so they can be json
        # serializable when written to file.
        return cls(**pickle.loads(base64.b64decode(serialized)))

    def serialize(self) -> str:
        """Serialize the RichDoc instance into an encoded pickle representation."""
        if not np.all(np.diff(self.words.char_start) >= 0):
            raise ValueError("RichDoc.words must be in sorted order by char_start.")
        return base64.b64encode(
            pickle.dumps(
                dict(
                    pages=self.pages,
                    areas=self.areas,
                    pars=self.pars,
                    lines=self.lines,
                    words=self.words,
                    text=self.text,
                    text_by_row=self.text_by_row,
                )
            )
        ).decode("ascii")

    @property
    def page_char_starts(self) -> List[int]:
        """Get an array of the char_start for all pages in the RichDoc.

        NOTE: If the RichDoc has been trimmed to a subset of pages, then only the
        char_start values for those pages will be present in this attribute.
        """
        if not hasattr(self, "_page_char_starts"):
            self._page_char_starts = self.pages[CHAR_START].to_list()
        return self._page_char_starts

    @property
    def word_char_starts(self) -> np.ndarray:
        """Get an array of the char_start for all words in the RichDoc."""
        if not hasattr(self, "_word_char_starts"):
            self._word_char_starts = self.words[CHAR_START].values
        return self._word_char_starts

    @property
    def word_char_ends(self) -> np.ndarray:
        """Get an array of the char_end for all words in the RichDoc."""
        if not hasattr(self, "_word_char_ends"):
            self._word_char_ends = self.words[CHAR_END].values
        return self._word_char_ends

    def get_span_location_fields(
        self, char_start: int, char_end: int, span_words: Optional[pd.DataFrame] = None
    ) -> Dict[str, Any]:
        """Get the location of a span of words in the rich doc in terms of word_ids.

        These fields are used by the frontend for rendering.

        Parameters
        ----------
        char_start
            The inclusive start index of the span in RichDoc.text.
        char_end
            The inclusive end index of the span in RichDoc.text.
        span_words
            The dataframe of words associated with the span. If not specified,
            it is computed using char start and char end.
        """
        if span_words is None:
            span_words = self._get_span_words(char_start, char_end)
        if span_words.empty:
            raise NoWordsFoundInSpanException(
                f"Requested span ({char_start}, {char_end}) does not contain any words. Please try using a different span extractor"
            )
        span_page_idx = span_words.page_id.values[0]
        span_page_num = span_page_idx + 1
        page_filter = self.words[PAGE_ID] == span_page_idx
        span_words_index = span_words.index

        first_page_word_idx = self.words.index[
            self.words[CHAR_START][page_filter].values.argmin()
        ]
        span_start_word_idx = span_words_index[span_words[CHAR_START].values.argmin()]
        span_start_word_num = int(span_start_word_idx - first_page_word_idx + 1)
        span_start_word_id = f"word_{span_page_num}_{span_start_word_num}"
        span_start_char = char_start - span_words[CHAR_START].values.min()
        span_end_word_idx = span_words_index[span_words[CHAR_END].values.argmax()]
        span_end_word_num = int(span_end_word_idx - first_page_word_idx + 1)
        span_end_word_id = f"word_{span_page_num}_{span_end_word_num}"
        span_end_char = char_end - span_words[CHAR_START].values.max()
        return {
            # TODO: Rename this RichDocCols.SPAN_PAGE_IDX (since it's an index, not the page id)
            RichDocCols.SPAN_PAGE_ID: span_page_idx,
            RichDocCols.SPAN_START_WORD_ID: span_start_word_id,
            RichDocCols.SPAN_START_CHAR_OFFSET: span_start_char,
            RichDocCols.SPAN_END_WORD_ID: span_end_word_id,
            RichDocCols.SPAN_END_CHAR_OFFSET: span_end_char,
            LEFT: span_words[LEFT].values.min(),
            TOP: span_words[TOP].values.min(),
            RIGHT: span_words[RIGHT].values.max(),
            BOTTOM: span_words[BOTTOM].values.max(),
        }

    def _get_span_page(self, char_start: int) -> int:
        """Return the 0-indexed index of the page that contains char_start."""
        idx = np.searchsorted(self.page_char_starts, char_start, side="right") - 1
        return self.pages.iloc[idx].name

    def _get_span_words(
        self, char_start: int, char_end: int, one_page: bool = True
    ) -> pd.DataFrame:
        """Find the word rows that overlap by at least one char with the specified span.

        Parameters
        ----------
        char_start
            The inclusive start index of the span in RichDoc.text.
        char_end
            The inclusive end index of the span in RichDoc.text.
        one_page
            If one_page == True, only those words occuring on the same page as the first
            word of the span will be returned. This allows us to make assumptions downstream
            about all words (and bbox coordinates) coming from the same page.
        """
        left_idx = int(np.searchsorted(self.word_char_ends, char_start))
        right_idx = int(np.searchsorted(self.word_char_starts, char_end, side="right"))
        words = self.words.iloc[left_idx:right_idx]
        if one_page and len(set(words.page_id.values)) > 1:
            logger.info(
                f"Found a span ({' '.join(words.text.values)}, "
                f"({char_start}, {char_end})) that extends over multiple pages. "
                f"All visual features will be calculated using the first page "
                f"({words.iloc[0].page_id}) only."
            )
            words = words[words.page_id == words.iloc[0].page_id]
        if len(words) == 0:
            logger.warning(
                f"Requested span {(char_start, char_end)} does not contain any words. "
                f"Confirm that it is a valid [inclusive, inclusive] span."
            )
        return words

    def split_pages(self) -> "RichDocList":
        """Split a RichDoc document into a list of RichDocs, one page per doc."""
        return RichDocList(
            [self._extract_page(page_id) for page_id in self.pages.index]
        )

    def normalize_char_starts(self) -> None:
        """Normalize char offsets for pages and words dfs inplace.

        This is needed when a RichDoc is constructed from disjoint pages (e.g. from_page_docs)
        """
        self._add_word_offsets()
        self._add_page_offsets()

    @classmethod
    def from_page_docs(cls, page_docs: "RichDocList") -> "RichDoc":
        """Construct a Richdoc from the page richdoc.

        Parameters
        ----------
        page_docs
            RichDocList datastructure.
        """
        pages = []
        lines = []
        pars = []
        areas = []
        words = []
        for doc in page_docs.rich_docs:
            pages.append(doc.pages)
            lines.append(doc.lines)
            pars.append(doc.pars)
            areas.append(doc.areas)
            words.append(doc.words)
        return cls(
            pd.concat(pages),
            pd.concat(areas),
            pd.concat(pars),
            pd.concat(lines),
            pd.concat(words),
        )

    def extract_span_page(self, char_start: int, char_end: int) -> "RichDoc":
        """Create a RichDoc with only objects on the same page as the requested span.

        Because visual signals are only guaranteed for words on a span's page, dropping
        the other pages can save a significant amount of space, especially in documents
        with many pages.

        Parameters
        ----------
        char_start
            The inclusive start index of the span in RichDoc.text.
        char_end
            The inclusive end index of the span in RichDoc.text.
        """
        span_page_id = self._get_span_page(char_start)
        return self._extract_page(span_page_id)

    def _extract_page(self, page_id: int) -> "RichDoc":
        """Return a RichDoc with only objects on the requested page.

        NOTE: We track the offset for each RichDoc page so that it can continue to use
        offsets with respect to the whole doc, even while indexing into text that was
        created from just a portion of the doc.
        """
        # Keep only words from the span's page. Use np.searchsorted because it's
        # a lot faster than filtering on equality with page_id.
        left_idx = int(np.searchsorted(self.words.page_id.values, page_id))
        right_idx = int(np.searchsorted(self.words.page_id.values, page_id + 1))
        page_words = self.words.iloc[left_idx:right_idx]
        # Keep only lines/pars/areas/pages corresponding to words from the page to keep
        # NOTE: This could be optimized by grabbing the first and last line from words
        # and using np.searchsorted as above to slice out just the relevant lines, then
        # repeat for pars and areas.
        page_lines = self.lines[self.lines.index.isin(page_words.line_id)]
        page_pars = self.pars[self.pars.index.isin(page_words.par_id)]
        page_areas = self.areas[self.areas.index.isin(page_words.area_id)]
        page_pages = self.pages[self.pages.index == page_id]
        # Skip row_ids calculation because they already exist
        return RichDoc(page_pages, page_areas, page_pars, page_lines, page_words)

    def _add_row_ids_per_page(self, df_page_words: pd.DataFrame) -> pd.DataFrame:
        df_page_words[MIDDLE] = (
            (df_page_words[BOTTOM].values + df_page_words[TOP].values) / 2
        ).astype(np.uint16)
        df_page_words = df_page_words.sort_values(by=MIDDLE)
        # Calculating word height per page allows for differently formatted pages
        median_word_height = np.median(
            (df_page_words[BOTTOM] - df_page_words[TOP]).values
        )
        # Space between rows of words makes median_word_height a good lower bound
        # Prepend 0 to account for the off-by-one issue of np.diff
        line_gaps = np.diff(df_page_words[MIDDLE], prepend=0) > median_word_height
        # Subtract 1 so rows are 0-indexed like word/line/par/area/page are
        df_page_words[ROW_ID] = np.cumsum(line_gaps) - 1
        return df_page_words

    def _add_row_ids(self) -> None:
        if not self.words.empty:
            # Only calculate row_ids over non-empty words (since empty words can correspond
            # to large regions that mess with row calculations)
            # All empty words will be assigned to row_id -1
            is_nonempty_word = self.words.text.apply(lambda x: bool(x.strip()))
            nonempty_words = self.words[is_nonempty_word]

            row_ids = (
                nonempty_words[[PAGE_ID, TOP, BOTTOM]]
                .groupby(PAGE_ID, group_keys=False)
                .apply(self._add_row_ids_per_page)[ROW_ID]
            )
            self.words = self.words.join(row_ids)
            self.words[ROW_ID] = self.words[ROW_ID].fillna(-1).astype(np.int16)
        else:
            # This happens e.g., when Dask infers metadata of HocrToRichDocParser's output.
            # For Dask's meta inference, ROW_ID should have a dtype.
            # TODO: Explicitly pass meta to Dask at `Operator._execute()`.
            self.words[ROW_ID] = pd.Series(None).astype(np.int16)

    def _add_word_offsets(self) -> None:
        # Prepend -1 so that the first par/line is also recognized as new
        is_new_par = (np.diff(self.words.par_id, prepend=-1) != 0).astype(int)
        is_new_line = (np.diff(self.words.line_id, prepend=-1) != 0).astype(int)
        word_lens = self.words.text.map(len).values
        # Add 1 to account for the space after each word
        chars_in_line = is_new_par + is_new_line + word_lens + 1
        # Subtract 2 to account for the space after each word and char_end being inclusive
        char_ends = np.cumsum(chars_in_line) - 2
        # Add 1 to account for char_end being inclusive
        self.words[CHAR_START] = char_ends - word_lens + 1
        self.words[CHAR_END] = char_ends

    def _add_page_offsets(self) -> None:
        # Prepend -1 so that the first par/line is also recognized as new
        is_new_page = np.diff(self.words.page_id, prepend=-1).astype(bool)
        first_words = (
            self.words[is_new_page].reset_index(drop=False).set_index("page_id")
        )

        self.pages[CHAR_START] = 0
        for idx in self.pages.index:
            try:
                # Subtract 2 to account for the two newlines at the start of each page since
                # Each page begins a new par and new line
                char_start = first_words.at[idx, CHAR_START] - 2
            except KeyError:
                if idx == 0 or (idx - 1 not in self.pages.index):
                    # This is first page or no previous pages are present, so char_start is 0
                    char_start = 0
                else:
                    # This page has no words on it, so use char_start of previous page
                    char_start = self.pages.at[idx - 1, CHAR_START]
            self.pages.at[idx, CHAR_START] = int(char_start)

    def _extract_row_text(self, df_row_words: pd.DataFrame) -> str:
        """Concatenate the words in a row into a single space-separated string."""
        return " ".join(df_row_words.sort_values(by=LEFT).text)

    def _add_text_by_row(self) -> pd.DataFrame:
        """Return a df containing the full text for each (page, row-id) combination."""
        return self.words.groupby([PAGE_ID, ROW_ID]).apply(self._extract_row_text)

    def get_row_text(self, page: int, row: int) -> str:
        """Return the text corresponding to a given row_id and page_id."""
        try:
            return self.text_by_row[page, row]
        except KeyError:
            raise RowNotFoundException(
                f"Row not found with row_id {row} on page {page}."
            )

    def _to_text(self) -> str:
        """Create the text-only representation of a RichDoc.

        In this representation:
        - A newline precedes every paragraph
        - A newline precedes every line
        - A space follows every word
        """
        # Using window function (diff) and vectorizable operations for speed.
        par_endlines = (self.words.par_id.diff(1) != 0.0).map(
            lambda x: "\n" if x else ""
        )
        line_endlines = (self.words.line_id.diff(1) != 0.0).map(
            lambda x: "\n" if x else ""
        )
        # In parallel, add newlines before each line/par and a space after each word,
        # then join them all together into a single string.
        return "".join(par_endlines + line_endlines + self.words.text + " ")

    def to_text(self) -> str:
        """Return a text-only representation of a RichDoc (without markup)."""
        return self.text

    def to_json(self, start_page: int = 0) -> str:
        """Convert a RichDoc document into a JSON formatted string."""
        if self.words.empty:
            return ""
        pages: List[Dict[str, Union[str, List]]] = []
        areas: List[Dict[str, Union[str, List]]] = []
        pars: List[Dict[str, Union[str, List]]] = []
        lines: List[Dict[str, Union[str, List]]] = []
        words: List[Dict[str, str]] = []

        def _get_row_bbox(df_row_words: pd.DataFrame) -> Dict[str, str]:
            """Compute the bbox of a row."""
            row_id = df_row_words[ROW_ID].iloc[0]
            left = df_row_words[LEFT].min()
            top = df_row_words[TOP].min()
            right = df_row_words[RIGHT].max()
            bottom = df_row_words[BOTTOM].max()
            return {"id": f"row_{row_id+1}", "bbox": f"{left} {top} {right} {bottom}"}

        rows = (
            self.words.groupby([PAGE_ID, ROW_ID])
            .apply(_get_row_bbox)
            .groupby(PAGE_ID)
            .apply(list)
        )

        # Local 1-indexed index per page for hocr compatibility.
        area_page_start_id = 0
        par_page_start_id = 0
        line_page_start_id = 0
        word_page_start_id = 0
        # Global indexes to detect when a word has reached a new line / par / etc.
        cur_page = -1
        cur_area = -1
        cur_par = -1
        cur_line = -1
        for word in self.words.itertuples():
            if cur_line != getattr(word, LINE_ID):
                if cur_line != -1:
                    lines[-1]["words"] = words
                    words = []  # End line.
                if cur_par != getattr(word, PAR_ID):
                    if cur_par != -1:
                        pars[-1]["lines"] = lines
                        lines = []  # End par.
                    if cur_area != getattr(word, AREA_ID):
                        if cur_area != -1:
                            areas[-1]["pars"] = pars
                            pars = []  # End area
                        if cur_page != getattr(word, PAGE_ID):
                            if cur_page != -1:
                                pages[-1]["areas"] = areas
                                areas = []  # End page
                            prev_page_num = getattr(word, PAGE_ID)
                            page = self.pages.loc[prev_page_num]
                            # Start page.
                            page_num = prev_page_num + 1
                            pages.append(
                                {
                                    "id": f"page_{page_num}",
                                    "bbox": f"{page.left} {page.top} {page.right} {page.bottom}",
                                    "rows": rows.loc[prev_page_num],
                                }
                            )
                            cur_page = getattr(word, PAGE_ID)
                            # Reset per-page counters.
                            area_page_start_id = getattr(word, AREA_ID)
                            par_page_start_id = getattr(word, PAR_ID)
                            line_page_start_id = getattr(word, LINE_ID)
                            word_page_start_id = word.Index
                        area = self.areas.loc[getattr(word, AREA_ID)]
                        # Start area.
                        cur_area = getattr(word, AREA_ID)
                        area_num = cur_area - area_page_start_id + 1
                        areas.append(
                            {
                                "id": f"block_{page_num}_{area_num}",
                                "bbox": f"{area.left} {area.top} {area.right} {area.bottom}",
                            }
                        )
                    par = self.pars.loc[getattr(word, PAR_ID)]
                    # Start par.
                    cur_par = getattr(word, PAR_ID)
                    par_num = cur_par - par_page_start_id + 1
                    pars.append(
                        {
                            "id": f"par_{page_num}_{par_num}",
                            "bbox": f"{par.left} {par.top} {par.right} {par.bottom}",
                        }
                    )
                line = self.lines.loc[getattr(word, LINE_ID)]
                # Start line.
                cur_line = getattr(word, LINE_ID)
                line_num = cur_line - line_page_start_id + 1
                lines.append(
                    {
                        "id": f"line_{page_num}_{line_num}",
                        "bbox": f"{line.left} {line.top} {line.right} {line.bottom}",
                    }
                )
            # Add word string
            word_num = word.Index - word_page_start_id + 1
            words.append(
                {
                    "id": f"word_{page_num}_{word_num}",
                    "bbox": f"{word.left} {word.top} {word.right} {word.bottom}",
                    "text": word.text,
                }
            )
        # End final line, par, area, page
        lines[-1]["words"] = words
        pars[-1]["lines"] = lines
        areas[-1]["pars"] = pars
        pages[-1]["areas"] = areas
        return json.dumps({"pages": pages})

    def to_hocr(self) -> str:
        """Convert a RichDoc document into an hOCR formatted string."""
        hocr = HOCR_START_STR
        # Local 1-indexed index per page for hocr compatibility.
        page_num = 0
        area_page_start_id = 0
        par_page_start_id = 0
        line_page_start_id = 0
        word_page_start_id = 0
        # Global indexes to detect when a word has reached a new line / par / etc.
        cur_page = -1
        cur_area = -1
        cur_par = -1
        cur_line = -1
        for i, row in self.words.iterrows():
            if cur_line != row[LINE_ID]:
                if cur_line != -1:
                    hocr += "</span>"  # End line.
                if cur_par != row[PAR_ID]:
                    if cur_par != -1:
                        hocr += "</p>"  # End par.
                    if cur_area != row[AREA_ID]:
                        if cur_area != -1:
                            hocr += "</div>"  # End area
                        if cur_page != row[PAGE_ID]:
                            if cur_page != -1:
                                hocr += "</div>"  # End page
                            page = self.pages.loc[row[PAGE_ID]]
                            # Start page.
                            page_num += 1
                            hocr += f"<div class='ocr_page' id='page_{page_num}' title='bbox {page.left} {page.top} {page.right} {page.bottom}'>"
                            cur_page = row[PAGE_ID]
                            # Reset per-page counters.
                            area_page_start_id = row[AREA_ID]
                            par_page_start_id = row[PAR_ID]
                            line_page_start_id = row[LINE_ID]
                            word_page_start_id = i
                        area = self.areas.loc[row[AREA_ID]]
                        # Start area.
                        cur_area = row[AREA_ID]
                        area_num = cur_area - area_page_start_id + 1
                        hocr += f"<div class='ocr_carea' id='block_{page_num}_{area_num}' title='bbox {area.left} {area.top} {area.right} {area.bottom}'>"
                    par = self.pars.loc[row[PAR_ID]]
                    # Start par.
                    cur_par = row[PAR_ID]
                    par_num = cur_par - par_page_start_id + 1
                    hocr += f"<p class='ocr_par' id='par_{page_num}_{par_num}' title='bbox {par.left} {par.top} {par.right} {par.bottom}'>"
                line = self.lines.loc[row[LINE_ID]]
                # Start line.
                cur_line = row[LINE_ID]
                line_num = cur_line - line_page_start_id + 1
                hocr += f"<span class='ocr_line' id='line_{page_num}_{line_num}' title='bbox {int(line.left)} {int(line.top)} {int(line.right)} {int(line.bottom)}; x_size {line.font_size};'>"
            # Add word string
            word_num = i - word_page_start_id + 1
            hocr += f"<span class='ocrx_word' id='word_{page_num}_{word_num}' title='bbox {row.left} {row.top} {row.right} {row.bottom}'>{row.text}</span>"
        # End final line, par, area, page
        hocr += "</span> </p> </div> </div>"
        # End hocr body.
        hocr += HOCR_END_STR
        return hocr

    @classmethod
    def from_records(
        cls,
        *,
        pages: PagesType,
        areas: AreasType,
        pars: ParsType,
        lines: LinesType,
        words: WordsType,
        convert_to_int: bool = True,
    ) -> pd.Series:
        """Construct RichDoc object from records lists."""
        df_pages = pd.DataFrame.from_records(pages, columns=PAGE_COLS, index=PAGE_ID)
        df_areas = pd.DataFrame.from_records(areas, columns=AREA_COLS, index=AREA_ID)
        df_pars = pd.DataFrame.from_records(pars, columns=PAR_COLS, index=PAR_ID)
        df_lines = pd.DataFrame.from_records(lines, columns=LINE_COLS, index=LINE_ID)
        # Since our ints are always positive and small, save space by using smaller types.
        if convert_to_int:
            dtypes = {
                **{
                    k: "uint16" for k in BBOX_COLS + [PAGE_ID, AREA_ID, PAR_ID, LINE_ID]
                },
                **{k: "uint32" for k in [WORD_ID]},
            }
            df_words = (
                pd.DataFrame.from_records(words, columns=WORD_COLS)
                .astype(dtypes)
                .set_index(WORD_ID)
            )
        else:
            df_words = pd.DataFrame.from_records(words, columns=WORD_COLS).set_index(
                WORD_ID
            )

        return RichDoc(df_pages, df_areas, df_pars, df_lines, df_words)


class RichDocList(Serializable):
    """Serializable wrapper for list of RichDoc's."""

    def __init__(self, rich_docs: List[RichDoc]):
        self.rich_docs = rich_docs

    def __getitem__(self, i: int) -> RichDoc:
        return self.rich_docs[i]

    def __len__(self) -> int:
        return len(self.rich_docs)

    def serialize(self) -> str:
        """Serialize instance to string."""
        return json.dumps([rd.serialize() for rd in self.rich_docs])

    @classmethod
    def deserialize(cls, serialized: str) -> Any:
        """Deserialize instance to string."""
        return cls([RichDoc.deserialize(rd_str) for rd_str in json.loads(serialized)])


class HVLines(Serializable):
    """Serializable wrapper for lists of horizontal and vertical lines in image."""

    def __init__(self, dfs_horz: List[pd.DataFrame], dfs_vert: List[pd.DataFrame]):
        self.dfs_horz = dfs_horz
        self.dfs_vert = dfs_vert

    def serialize(self) -> str:
        """Serialize instance to string."""
        return base64.b64encode(pickle.dumps((self.dfs_horz, self.dfs_vert))).decode(
            "ascii"
        )

    @classmethod
    def deserialize(cls, serialized: str) -> Any:
        """Deserialize instance to string."""
        return cls(*pickle.loads(base64.b64decode(serialized)))


class DocumentLayout(Serializable):
    """Serializable wrapper for PDF structures detected from DocumentLayoutFeaturizer."""

    def __init__(self, structures: List[pd.DataFrame]):
        self.structures = structures

    def serialize(self) -> str:
        """Serialize instance to string."""
        return base64.b64encode(pickle.dumps((self.structures))).decode("ascii")

    @classmethod
    def deserialize(cls, serialized: str) -> Any:
        """Deserialize instance to string."""
        return cls(pickle.loads(base64.b64decode(serialized)))


class TextClusters(Serializable):
    """Serializable wrapper for horizontal clusters of words."""

    def __init__(self, word_to_cluster: Dict[int, int], df_clusters: pd.DataFrame):
        self.word_to_cluster = word_to_cluster
        self.df_clusters = df_clusters

    def serialize(self) -> str:
        """Serialize instance to string."""
        return base64.b64encode(
            pickle.dumps((self.word_to_cluster, self.df_clusters))
        ).decode("ascii")

    # TODO: Create a subclass of serializable that pickles a tuple of its args (or kwargs).
    # Create args / kwargs properties for it that subclasses can inherit.
    @classmethod
    def deserialize(cls, serialized: str) -> Any:
        """Deserialize instance to string."""
        return cls(*pickle.loads(base64.b64decode(serialized)))
