import contextlib
import os
import shutil
import subprocess
import tempfile
import warnings
from typing import Any, Iterator, List, Optional

import cv2
import numpy as np
import pandas as pd
from PIL import Image

from snorkelflow.rich_docs.rich_doc import RichDoc, RichDocCols
from snorkelflow.utils.datapoint import PageCols
from snorkelflow.utils.file import open_file
from snorkelflow.utils.logging import get_logger

logger = get_logger("Rich Doc Utils")


def normalize_bbox(
    top: int, left: int, right: int, bottom: int, page_height: int, page_width: int
) -> List[int]:
    left = int(1000 * left / page_width)
    top = int(1000 * top / page_height)
    right = int(1000 * right / page_width)
    bottom = int(1000 * bottom / page_height)
    normalized_bbox = [left, top, right, bottom]
    return normalized_bbox


def get_normalized_word_boxes(rich_doc: RichDoc) -> List[Any]:
    """
    Normalizing word bounding boxes to scale required by Document VQA model
    """
    word_boxes = []
    page_width = rich_doc.pages.right.values[0]
    page_height = rich_doc.pages.bottom.values[0]

    for word in rich_doc.words.itertuples():
        text = word.text

        normalized_bbox = normalize_bbox(
            left=word.left,
            right=word.right,
            top=word.top,
            bottom=word.bottom,
            page_height=page_height,
            page_width=page_width,
        )

        truncated_norm_bbox = []
        for value in normalized_bbox:
            if value < 0 or value > 1000:
                warnings.warn(
                    f"Word {text} with dimensions ({word.left}, {word.top}, {word.right}, {word.bottom}) is outside the page boundaries"
                )
            truncated_norm_bbox.append(max(min(value, 1000), 0))

        word_boxes.append([text, tuple(truncated_norm_bbox)])

    return word_boxes


def draw_bboxes(
    image: np.ndarray,
    bboxes: List[List[int]],
    draw_filled_boxes: Optional[bool] = False,
    box_info: Optional[List] = None,
    **kwargs: Any,
) -> np.ndarray:
    """
    Function to draw boxes on PDF image
    """
    color = kwargs.get("color", (0, 0, 139))

    if draw_filled_boxes:
        # Drawing semi-opaque boxes
        shapes = np.zeros_like(image, np.uint8)
        for index in range(len(bboxes)):
            xmin, ymin, xmax, ymax = bboxes[index]
            shapes = cv2.rectangle(
                shapes, (xmin, ymin), (xmax, ymax), color, cv2.FILLED
            )

        # Combining mask with image
        alpha = kwargs.get("alpha", 0.5)
        mask = shapes.astype(bool)
        image[mask] = cv2.addWeighted(image, alpha, shapes, 1 - alpha, 0)[mask]
    else:
        # Drawing boxes with outline only
        thickness = kwargs.get("thickness", 5)
        for index in range(len(bboxes)):
            xmin, ymin, xmax, ymax = bboxes[index]
            image = cv2.rectangle(image, (xmin, ymin), (xmax, ymax), color, thickness)

    # Adding text associated with boxes
    if box_info is not None:
        text_offset = kwargs.get("text_offset", 10)
        font = kwargs.get("font", cv2.FONT_HERSHEY_DUPLEX)
        font_scale = kwargs.get("font_scale", 0.9)
        line_type = kwargs.get("line_type", cv2.LINE_AA)
        thickness = kwargs.get("thickness", 2)

        for index in range(len(bboxes)):
            xmin, ymin, xmax, ymax = bboxes[index]
            text = box_info[index]
            # text origin is bottom left corner of text
            text_size = cv2.getTextSize(text, font, font_scale, thickness)
            text_origin = (max(xmax - text_size[0][0], 0), max(ymin - text_offset, 0))
            image = cv2.putText(
                image, text, text_origin, font, font_scale, color, thickness, line_type
            )

    return image


def parse_pdf_page_image(
    pdf_file_url: str, page_idx: int, use_rgb_image: Optional[bool] = False
) -> np.ndarray:
    page_num = page_idx + 1
    try:
        with convert_pdf_to_image(
            pdf_file_url,
            dpi=300,
            start_page=page_num,
            end_page=page_num,
            grayscale=True,
        ) as img_dir:
            img_path = os.path.join(img_dir, f"{page_num}.jpg")
            with open(img_path, "rb") as img_stream:
                image_bytes = np.asarray(bytearray(img_stream.read()), dtype=np.uint8)

            image = cv2.imdecode(image_bytes, cv2.IMREAD_COLOR)
            if use_rgb_image:
                image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)

            return image
    except Exception as e:
        logger.error(str(e))
        raise IOError(e)


def load_pdf_file_url_as_image(pdf_file_url: str, page_idx: int) -> Image:
    """
    Function downloads PDFs to local temp path and converts PDF to image.
    """
    with tempfile.NamedTemporaryFile() as tmp_path:
        dest_file = tmp_path.name
        with open_file(pdf_file_url, "rb") as src_f, open(dest_file, "wb") as dest_f:
            shutil.copyfileobj(src_f, dest_f)

        image_arr = parse_pdf_page_image(dest_file, page_idx)
        image = Image.fromarray(image_arr)
        return image


@contextlib.contextmanager
def convert_pdf_to_image(
    pdf_path: str,
    dpi: Optional[int] = None,
    start_page: Optional[int] = None,
    end_page: Optional[int] = None,
    grayscale: Optional[bool] = False,
    format: Optional[str] = None,
) -> Iterator[str]:
    """
    From a single pdf, converts many images (one image per page) in the
    given directory. TODO: ENG-11362 (Convert via PDF to image operator)

    Usage: this is a context manager that will return a directory where the converted images are located

    with convert_pdf_to_image(pdf_path, dpi=100) as img_dir:
        # Now can access images in img_dir
    """
    temp_dir = tempfile.mkdtemp()

    command = [
        "java",
        "-Djava.awt.headless=true",
        "-jar",
        "/usr/local/bin/pdfbox.jar",
        "PDFToImage",
        pdf_path,
        "-outputPrefix",
        os.path.join(temp_dir, ""),
    ]

    if start_page:
        command.extend(["-startPage", str(start_page)])
    if end_page:
        command.extend(["-endPage", str(end_page)])
    if grayscale:
        command.extend(["-color", "gray"])
    if dpi:
        command.extend(["-dpi", str(dpi)])
    command.extend(["-format", "jpg" if format is None else format])

    proc = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    _, stderr = proc.communicate()
    if proc.returncode:
        raise Exception(
            f"Error converting the PDF to image. Empty dataframe added. Err={stderr.decode()}"
        )
    try:
        yield temp_dir
    finally:
        shutil.rmtree(temp_dir)


def check_pagesplitter_columns(row: pd.Series) -> bool:
    # The PageSplitter adds the RichDocCols.CONTEXT_PAGES and PageCols.PAGE_IDX fields
    if hasattr(row, RichDocCols.CONTEXT_PAGES) and hasattr(row, PageCols.PAGE_IDX):
        return True
    else:
        return False


def get_context_pages_index(row: pd.Series, page_index: int) -> int:
    """
    If pages are split - the page_docs object contains metadata for a subset of pages.
    Mapping the RichDocCols.SPAN_PAGE_ID to the page_docs index
    """
    # If PageSplitter is applied, we return the page_docs index
    # Users can manually edit the RichDocCols.CONTEXT_PAGES field for filtering - we return the input page index.
    if check_pagesplitter_columns(row) and page_index in row[RichDocCols.CONTEXT_PAGES]:
        return row[RichDocCols.CONTEXT_PAGES].index(page_index)

    return page_index
