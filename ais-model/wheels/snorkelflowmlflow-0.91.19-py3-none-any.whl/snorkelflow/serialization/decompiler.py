import ast
import inspect
import textwrap
from io import StringIO
from types import FunctionType
from typing import Any, Callable, Dict, Optional

import astunparse
from decompyle3.semantics.pysource import code_deparse

from snorkelflow.lfs.lfs import LabelingFunction
from snorkelflow.studio.core import (
    is_decorated_by_resources_fn_labeling_function,
    resources_fn_labeling_function,
)

from .code_asset import (
    FIELDS_TO_RECOMPILE,
    ProblematicCodeRemover,
    deserialize_asset,
    serialize_asset,
)


class _NeedsManualRecompile(Exception):
    pass


DEBUG_OPTS = {
    "asm": False,
    "tree": {"before": False, "after": False},
    "grammar": {
        "rules": False,
        "transition": False,
        "reduce": False,
        "errorstack": False,
        "context": False,
        "dups": False,
    },
}


def decompile(old_func: Callable) -> str:
    func_name = old_func.__name__
    # Source code is missing, attempt to parse bytecode
    # Get function body code from bytecode
    new_code_in = StringIO()
    try:
        code_deparse(
            old_func.__code__, out=new_code_in, version=(3, 8), debug_opts=DEBUG_OPTS
        )
    except Exception:
        raise _NeedsManualRecompile(f"Failed to decompile byte code, {func_name}")
    new_func_body = new_code_in.getvalue()

    # Use inspect to generate function header
    signature = inspect.signature(old_func)
    func_signature = f"def {func_name}{signature}:\n"
    code = func_signature + textwrap.indent(new_func_body, prefix="\t")

    source = ast.parse(code)
    transformed = ProblematicCodeRemover().visit(source)
    return astunparse.unparse(transformed)


def decompile_operator(
    op_config: Dict[str, Any], code: Optional[Dict[str, Any]] = None, depth: int = 0
) -> Dict[str, Any]:
    """Decompile a custom operator.

    The output should be a dictionary with the following keys:
        "_f": str, the decompiled main user-defined function. Required.
        "_resources": Dict[str, str], the decompiled resources. The key is required but the valud could be an empty dictionary {}.
        "_resources_fn": str, decompiled resources_fn. Optional (ie the key doesn't exist if the operator doesn't have resources_fn).
    """
    # If not at the root, loop through all the keys in op_config
    fields_to_decompile = FIELDS_TO_RECOMPILE if depth == 0 else list(op_config)
    new_code = code.copy() if code else {}
    for field_name in fields_to_decompile:
        code_field_name = f"_{field_name}"
        # Skip if code exists or bytecode doesn't exist.
        if code_field_name in new_code or field_name not in op_config:
            continue
        # If the field is a dictionary at the root, we need to decompile its children
        if depth == 0 and isinstance(op_config.get(field_name), dict):
            new_code[code_field_name] = decompile_operator(
                op_config[field_name], new_code.get(code_field_name), depth + 1
            )
            continue
        f = deserialize_asset(op_config[field_name])
        if isinstance(f, FunctionType):
            new_code[code_field_name] = decompile(f)
    return new_code


def attempt_to_decompile_code_lf(config: Dict[str, Any], lf_uid: int) -> Dict[str, Any]:
    """
    1. Change the schema of "code".
         Currently: template["code"]: str
         New: template["code"]: Dict[str, str]. E.g., {"_f": "xxx", "resources_fn: "xxx"}
    2. Decompile the main UDF and resources_fn of resources_fn_labeling_function
    """
    if "templates" in config:
        templates = config["templates"]
    elif "multipolar_template" in config:
        templates = [config["multipolar_template"]]
    else:
        raise ValueError(f"No template is found.")
    for template in templates:
        # Skip if it is not a code LF or it is in the new schema
        if "serialized_lf" not in template or isinstance(template["code"], dict):
            continue
        lf: LabelingFunction = deserialize_asset(template["serialized_lf"])
        code: Dict[str, Any] = {"_resources": {}}
        # Deserialize the main UDF if it's a string (this is a bug from 130.py)
        if isinstance(lf._f, str):
            lf._f = deserialize_asset(lf._f)
            template["serialized_lf"] = serialize_asset(lf)
        # Decompile the main UDF if decorated by resources_fn_labeling_function
        if is_decorated_by_resources_fn_labeling_function(lf):
            wrapped_func = lf._f
            assert wrapped_func.__closure__ is not None  # mypy
            closures = wrapped_func.__closure__
            udf = closures[0].cell_contents
            outer: resources_fn_labeling_function = closures[1].cell_contents
            # Correct the LF name if the current name was not specified by user.
            # This is a fix for existing LFs affected by ENG-21275.
            if config["name"] == "f_with_resources":
                config["name"] = template["name"] = udf.__name__
            code["_f"] = decompile(udf)
            if outer.resources_fn:
                code["_resources_fn"] = decompile(outer.resources_fn)
        else:
            code["_f"] = template["code"]
        # Check resource, decompile if possible
        if lf._resources:
            for k, v in lf._resources.items():
                if isinstance(v, FunctionType):
                    code["_resources"][k] = decompile(v)
        template["code"] = code
    return config
