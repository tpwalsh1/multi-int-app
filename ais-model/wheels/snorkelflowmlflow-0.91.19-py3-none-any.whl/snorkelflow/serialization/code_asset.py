import ast
import base64
import re
import textwrap
from typing import Any, Callable, Dict, List, Mapping

import dill

from snorkelflow.lfs.lfs import LabelingFunction
from snorkelflow.studio.core import (
    is_decorated_by_resources_fn_labeling_function,
    resources_fn_labeling_function,
)

# Regex to remove comments from code
p = re.compile(r"^\s*#.*$", re.MULTILINE)

FIELDS_TO_RECOMPILE: List[str] = ["f", "resources_fn", "resources"]
CODE_FIELDS_TO_RECOMPILE = [f"_{k}" for k in FIELDS_TO_RECOMPILE]


class ProblematicCodeRemover(ast.NodeTransformer):
    def visit_FunctionDef(self, node: ast.FunctionDef) -> ast.FunctionDef:
        # Source from https://stackoverflow.com/a/42734810
        # Remove type annotations in function declaration
        node.returns = None
        if node.args.args:
            for arg in node.args.args:
                arg.annotation = None
        # Remove decorators
        node.decorator_list = []
        return node


def serialize_asset(asset: Any) -> str:
    """Encode an asset into a JSON-compatible string

    Parameters
    ----------
    asset
        A CodeAsset (LabelingFunction, Operator, or resource (dict)).
        We avoid an explicit type annotation here to avoid making Snorkel as
        an artifact of previous build system issues.
        # TODO: proper typing for asset

    Steps:
    asset -> dill pickle -> base64 str -> ascii str

    - dill is necessary to recursively pickle resources/preprocessors
    - base64 is necessary to convert bytes into a valid string
    - string is required to jsonify (json can't serialize bytes)

    """
    asset_pkl: bytes = dill.dumps(asset)
    asset_pkl_b64: bytes = base64.b64encode(asset_pkl)
    asset_pkl_ascii: str = asset_pkl_b64.decode("ascii")
    return asset_pkl_ascii


def deserialize_asset(asset_pkl_ascii: str) -> Any:
    """Decode a serialized LF into a CodeAsset.

    Reverses the steps in `serialize_asset()`.
    """
    asset_pkl: bytes = base64.b64decode(asset_pkl_ascii)
    asset = dill.loads(asset_pkl)
    return asset


def recompile(old_func: Callable, code: str) -> Callable:
    """Recompile codebyte from source"""
    filename = old_func.__code__.co_filename
    func_name = old_func.__name__

    # Remove comments and dedent code
    code = p.sub("", code)
    code = textwrap.dedent(code)

    # Remove problematic parts of the code
    source = ast.parse(code)
    transformed = ProblematicCodeRemover().visit(source)
    # Run the function-defining code and return the resulting function
    loc: Mapping[str, Any] = {}
    # Override module so that we don't encounter deserializing issues
    exec(
        compile(transformed, filename=filename, mode="exec"),
        {"__name__": "__main__"},
        loc,
    )
    return loc[func_name]


class RecompileError(ValueError):
    pass


def recompile_operator(
    op_config: Dict[str, Any], code: Dict[str, Any], depth: int = 0
) -> Dict[str, Any]:
    """Recompile custom operator bytecodes from source

    Parameters
    ----------
    op_config
        The operator configuration dictionary
    code
        A dictionary containing the source code for the operator
    depth
        The depth in the nested dictionary. The 0th level is the root of the dictionary.

    Returns
    -------
    Dict[str, Any]
        The recompiled operator configuration
    """
    # If not at the root, loop through all the keys in code.
    # Note that keys in op_config on the other hand can have non-function values.
    code_fields_to_recompile = CODE_FIELDS_TO_RECOMPILE if depth == 0 else list(code)
    new_config = op_config.copy()
    for code_field_name in code_fields_to_recompile:
        field_name = code_field_name[1:]

        # "resources_fn" was introduced later, so it might not be present in all operators
        if field_name not in op_config:
            continue

        # If the field is "_resources" at the root, which should be a dictionary, we need to recompile its children
        if depth == 0 and code_field_name == "_resources":
            op_config[field_name] = recompile_operator(
                op_config[field_name], code.get(code_field_name, {}), depth + 1
            )
            continue

        old_asset = deserialize_asset(op_config[field_name])
        # The "field_name" key is always present in op_config, but could be empty. Skipping.
        if old_asset is None:
            continue

        try:
            new_config[field_name] = serialize_asset(
                recompile(old_asset, code[code_field_name])
            )
        except Exception:
            raise RecompileError(
                f"Encountered error while recompiling asset at {field_name}"
            )
    return new_config


def recompile_lf(template_config: Dict[str, Any]) -> LabelingFunction:
    lf = deserialize_asset(template_config["serialized_lf"])

    try:
        # Recompile
        code = template_config["code"]
        if lf._resources:
            for k, v in code["_resources"].items():
                lf._resources[k] = recompile(lf._resources[k], v)
        if is_decorated_by_resources_fn_labeling_function(lf):
            # Essentially, we stitch pieces together to construct the same LF object.
            wrapped_func = lf._f
            assert wrapped_func.__closure__ is not None  # mypy
            closures = wrapped_func.__closure__

            # Compile the main UDF
            udf = closures[0].cell_contents
            udf = recompile(udf, code["_f"])

            # Compile resources_fn if any
            outer_func: resources_fn_labeling_function = closures[1].cell_contents
            resources_fn = (
                recompile(outer_func.resources_fn, code["_resources_fn"])
                if outer_func.resources_fn
                else None
            )

            # Finally recreate the LF object
            decorator = resources_fn_labeling_function(
                lf.name, resources=lf._resources, resources_fn=resources_fn
            )
            lf = decorator(udf)
        else:
            lf._f = recompile(lf._f, code["_f"])
        return lf
    except Exception:
        raise RecompileError(f"Failed to recompile LF {lf.name}")
