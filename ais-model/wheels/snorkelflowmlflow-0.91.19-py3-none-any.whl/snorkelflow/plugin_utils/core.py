import os
import pkgutil
from typing import List


def find_all_modules(path: str, prefix: str = "") -> List[str]:
    all_modules = []
    for module in pkgutil.iter_modules([path], prefix):
        if module.ispkg:
            all_modules.extend(
                find_all_modules(
                    os.path.join(path, module.name.split(".")[-1]), f"{module.name}."
                )
            )
        else:
            all_modules.append(module.name)
    return all_modules


def find_all_packages(path: str, prefix: str = "") -> List[str]:
    all_packages = []
    for module in pkgutil.iter_modules([path], prefix):
        if module.ispkg:
            all_packages.extend(
                find_all_packages(
                    os.path.join(path, module.name.split(".")[-1]), f"{module.name}."
                )
            )
            all_packages.append(module.name)
    return all_packages
