from typing import Iterable

import pandas as pd

from snorkelflow.data_loaders import get_data_loader_type
from snorkelflow.data_loaders.core import (
    BatchSizeMode,
    BatchStreamDataLoaderMixin,
    data_loader_can_stream,
)
from snorkelflow.types.load import LoadConfig


def create_df_generator_from_config(config: LoadConfig) -> Iterable[pd.DataFrame]:
    data_loader = get_data_loader_type(config.type).from_config(config.dict())
    if data_loader_can_stream(data_loader):
        assert isinstance(data_loader, BatchStreamDataLoaderMixin)  # mypy
        generator = data_loader.iter_batches(500, mode=BatchSizeMode.MEGABYTES)
    else:
        # No streaming, just load 1 partition at a time
        ddf = data_loader.load()
        generator = (partition.compute() for partition in ddf.partitions)
    return generator
