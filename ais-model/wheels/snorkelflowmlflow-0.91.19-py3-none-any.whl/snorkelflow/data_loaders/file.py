import abc
import copy
import os
from typing import Any, Dict, Generator, List, Optional, Set, Tuple

import dask.dataframe as dd
import fsspec
import pandas as pd
import pyarrow as pa
from fsspec.utils import infer_storage_options
from pyarrow.parquet import ParquetFile
from pydantic import BaseModel

from snorkelflow.types.load import MinioArgs, SourceType
from snorkelflow.utils.arrow import (
    get_engine_arrow_file_paths,
    get_source_for_arrow_path,
    read_arrow,
    read_arrow_columns,
    table_to_pandas,
)
from snorkelflow.utils.file import (
    _open_file,
    get_path_storage_options,
    resolve_data_path,
)
from snorkelflow.utils.pickle import read_pickle

from .core import (
    BaseDataLoader,
    BatchStreamDataLoaderMixin,
    ColumnsDataLoaderMixin,
    FileSizeDataLoaderMixin,
    MinimumMemoryFootprint,
    logger,
)


class FileConfig(BaseModel):
    path: str
    reader_kwargs: Dict[str, Any]
    minio_args: Optional[MinioArgs] = None


all_extensions: Set[str] = set()


class BaseFileDataLoader(BaseDataLoader, FileSizeDataLoaderMixin):
    valid_extensions: Tuple[str, ...]

    def __init__(self, path: str, dask_kwargs: Dict[str, Any]) -> None:
        self.path = path
        self.dask_kwargs = dask_kwargs
        self.storage_options = self.dask_kwargs.get("storage_options")

    def __init_subclass__(cls, **kwargs: Any) -> None:
        super().__init_subclass__(**kwargs)  # type: ignore
        all_extensions.update(cls.valid_extensions)

    @abc.abstractmethod
    def _load(self) -> dd.DataFrame:
        pass

    @classmethod
    def check_extension(cls, path: str) -> bool:
        exts = all_extensions.difference(cls.valid_extensions)
        return not any(path.endswith(ext) for ext in exts)

    def load(self) -> dd.DataFrame:
        logger.info(f"Loading DataFrame from path: {self.path}")
        try:
            return self._load()
        # Add path information to common exceptions.
        except OSError:
            raise FileNotFoundError(f"File not found: {self.path}")
        except PermissionError as e:
            raise PermissionError(f"Access denied for {self.path}: {e}")

    def file_size(self) -> Optional[int]:
        fs, _, _ = fsspec.core.get_fs_token_paths(
            self.path, mode="rb", storage_options=self.storage_options
        )
        try:
            return fs.du(self.path)
        except Exception as e:
            logger.warn(
                f"Error reading file size for {self.path}: {e}. Skipping file size.",
                exc_info=True,
            )
            return None

    @staticmethod
    def get_path_and_load_config(
        path: str, dask_kwargs: Dict[str, Any], minio_args: Optional[MinioArgs] = None
    ) -> Tuple[str, Dict[str, Any]]:
        dask_kwargs = copy.deepcopy(dask_kwargs)
        path = resolve_data_path(path)
        protocol = infer_storage_options(path).get("protocol")
        path, storage_options = get_path_storage_options(path, minio_args=minio_args)
        if storage_options:
            dask_kwargs["storage_options"] = storage_options
        # Invalidate cache in case a file is added to S3 after Snorkel Flow started.
        # NB: this should likely be done elsewhere
        try:
            # We also want to invalidate the cache if it's in minio as we switch to using the s3 scheme in get_path_storage_options
            # However, this only applies if resolve_data_path doesn't convert a minio path to a local path, which only happens if this code
            # is run outside of engine (notebook for ex.).
            if protocol in {"s3", "minio"}:
                fsspec.get_filesystem_class("s3")().invalidate_cache(path)
        except ValueError:
            pass
        return path, dask_kwargs

    @classmethod
    def from_config(cls, config: Dict[str, Any]) -> "BaseFileDataLoader":
        parsed_config = FileConfig.parse_obj(config)
        path, dask_kwargs = cls.get_path_and_load_config(
            parsed_config.path, parsed_config.reader_kwargs, parsed_config.minio_args
        )
        return cls(path=path, dask_kwargs=dask_kwargs)


class CSVDataLoader(BaseFileDataLoader, BatchStreamDataLoaderMixin):
    identifier: SourceType = SourceType.CSV
    valid_extensions: Tuple[str, ...] = (".csv", ".tsv")

    def _load(self) -> dd.DataFrame:
        return dd.read_csv(self.path, sample_rows=None, **self.dask_kwargs)

    def _iter_batches(self) -> Generator[pd.DataFrame, int, None]:
        with _open_file(self.path, "rb", **(self.storage_options or {})) as f:
            chunksize = yield
            it = pd.read_csv(f, chunksize=chunksize)
            while True:
                try:
                    it.chunksize = chunksize
                    chunksize = yield next(it)

                except StopIteration:
                    break


class ParquetDataLoader(
    BaseFileDataLoader, BatchStreamDataLoaderMixin, MinimumMemoryFootprint
):
    identifier: SourceType = SourceType.PARQUET
    valid_extensions: Tuple[str, ...] = (".parquet",)

    def min_memory_footprint(self) -> int:
        """
        For a parquet file, we must read the entire row group, so we return the size of the largest row group.
        """
        fs, paths = self._file_paths()
        max_rg_byte_size = 0
        for path in paths:
            with fs.open(path, "rb", **(self.storage_options or {})) as f:
                pf = ParquetFile(f, pre_buffer=True)
                num_row_groups = pf.metadata.num_row_groups
                for row_group_idx in range(num_row_groups):
                    rg = pf.metadata.row_group(row_group_idx)
                    byte_size = rg.total_byte_size
                    max_rg_byte_size = max(max_rg_byte_size, byte_size)
        return max_rg_byte_size

    def _load(self) -> dd.DataFrame:
        try:
            if "gather_statistics" not in self.dask_kwargs:
                self.dask_kwargs["gather_statistics"] = True
            return dd.read_parquet(self.path, engine="pyarrow", **self.dask_kwargs)
        except pa.lib.ArrowInvalid as e:
            msg = (
                f"Error occurred when loading Parquet file. Path: {self.path}."
                f"This file is likely corrupted. Please considering deleting corresponding datasource."
            )
            logger.error(f"{msg}. Exception: {e}")
            raise ValueError(msg)

    def _file_paths(self) -> Tuple[fsspec.AbstractFileSystem, List[str]]:
        fs, path = fsspec.core.url_to_fs(self.path, **(self.storage_options or {}))
        if fs.isdir(path):
            paths = fs.glob(os.path.join(path, f"part.*.parquet"))
            paths = sorted(paths, key=lambda x: int(x.split(".")[-2]))
        else:
            paths = [path]
        return fs, paths

    def _iter_batches(self) -> Generator[pd.DataFrame, int, None]:
        fs, paths = self._file_paths()

        batch_size = yield
        for path in paths:
            with fs.open(path, "rb", **(self.storage_options or {})) as f:
                pf = ParquetFile(f, pre_buffer=True)
                # Note: We tried using pf.iter_batches, but it would occasionally
                # hang for some reason.
                for current_row_group in range(pf.num_row_groups):
                    table = _read_row_group(pf, row_group=current_row_group)
                    cur_idx = 0
                    while cur_idx < table.num_rows:
                        batch = table_to_pandas(table.slice(cur_idx, batch_size))
                        cur_idx += len(batch)
                        batch_size = yield batch


def _read_row_group(pf: ParquetFile, row_group: int) -> pa.Table:
    return pf.read_row_group(row_group, use_pandas_metadata=True)


class PickleDataLoader(BaseFileDataLoader):
    identifier: SourceType = SourceType.PICKLE
    valid_extensions: Tuple[str, ...] = (".pkl", ".pickle")

    def _load(self) -> dd.DataFrame:
        return read_pickle(self.path, **self.dask_kwargs)


class ArrowDataLoader(
    BaseFileDataLoader, BatchStreamDataLoaderMixin, ColumnsDataLoaderMixin
):
    identifier: SourceType = SourceType.ARROW_IPC
    valid_extensions: Tuple[str, ...] = (".arrow",)

    def _load(self) -> dd.DataFrame:
        return read_arrow(self.path, **self.dask_kwargs)

    def columns(self) -> List[str]:
        return read_arrow_columns(self.path, storage_options=self.storage_options)

    def _iter_batches(self) -> Generator[pd.DataFrame, int, None]:
        protocol = infer_storage_options(self.path).get("protocol")
        paths = get_engine_arrow_file_paths(self.path, self.storage_options)

        batch_size = yield
        for path in paths:
            f = get_source_for_arrow_path(
                path, protocol=protocol, storage_options=self.storage_options
            )
            # We re-memmap the file after each batch to avoid memory usage
            # from growing as more pages are accessed. The memory usage isn't
            # necessarily a problem because memory is released when there is
            # high memory pressure, but this may still be a problem if e.g.
            # we have a thread that's proactively killing processes that exceed
            # allowed memory limits.
            # The re-memmapping is near instant, so its not a problem. If it
            # becomes a bottleneck, we can switch to doing it after each n
            # batches.
            with f:
                reader = pa.ipc.RecordBatchFileReader(f)
                num_record_batches = reader.num_record_batches
            for batch_idx in range(num_record_batches):
                f = get_source_for_arrow_path(
                    path, protocol=protocol, storage_options=self.storage_options
                )
                with f:
                    reader = pa.ipc.RecordBatchFileReader(f)
                    batch = reader.get_batch(batch_idx)
                    table = pa.Table.from_batches([batch])

                    i = 0
                    while i < table.num_rows:
                        batch = table_to_pandas(table.slice(i, batch_size))
                        i += len(batch)
                        batch_size = yield batch
