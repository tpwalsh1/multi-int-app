import importlib
import inspect
import os
from typing import Dict, List, Type

from snorkelflow.plugin_utils import find_all_packages
from snorkelflow.types.load import SourceType

from .core import (  # noqa: F401
    BaseDataLoader,
    FileSizeDataLoaderMixin,
    JSONSecretMixin,
    logger,
)
from .file import (  # noqa: F401
    ArrowDataLoader,
    BaseFileDataLoader,
    CSVDataLoader,
    ParquetDataLoader,
    PickleDataLoader,
)


def _discover_data_loader_plugins() -> List[Type[BaseDataLoader]]:
    data_loader_plugins: List[Type[BaseDataLoader]] = []
    all_data_loader_packages = find_all_packages(
        os.path.dirname(__file__), "snorkelflow.data_loaders."
    )
    for package_name in all_data_loader_packages:
        added_data_loader = False
        if package_name.startswith("data_loader_"):
            logger.info(f"Importing package {package_name}")
        try:
            package = importlib.import_module(package_name)
            for name, v in package.__dict__.items():
                if inspect.isclass(v) and issubclass(v, BaseDataLoader):
                    added_data_loader = True
                    data_loader_plugins.append(v)
            if not added_data_loader:
                logger.warning(
                    f"No data loader implementations found in {package_name}."
                )
        except ImportError as e:
            logger.warning(f"Skipping import for {package_name}: {e}")
    return data_loader_plugins


def _get_all_data_loaders(
    base_data_loaders: List[Type[BaseDataLoader]],
) -> Dict[SourceType, Type[BaseDataLoader]]:
    all_data_loaders: Dict[SourceType, Type[BaseDataLoader]] = {}
    all_data_loader_classes = base_data_loaders + _discover_data_loader_plugins()
    for data_loader in all_data_loader_classes:
        existing_data_loader = all_data_loaders.get(data_loader.identifier)
        if existing_data_loader is not None:
            raise ValueError(
                f"Two data loader types with the same identifier were found. Identifier: {data_loader.identifier.name}. Data loaders: {data_loader.__name__}, {existing_data_loader.__name__}."
            )
        all_data_loaders[data_loader.identifier] = data_loader
    return all_data_loaders


DATA_LOADERS: Dict[SourceType, Type[BaseDataLoader]] = _get_all_data_loaders(
    [CSVDataLoader, ParquetDataLoader, PickleDataLoader, ArrowDataLoader]
)


def get_data_loader_type(source_type: SourceType) -> Type[BaseDataLoader]:
    DataLoaderType = DATA_LOADERS.get(source_type)
    if DataLoaderType is None:
        available_source_types = [st.name for st in DATA_LOADERS]
        raise ValueError(
            f"No data loader for {source_type.name} available. Available types: {available_source_types}."
        )
    return DataLoaderType
