import abc
import json
import uuid
from enum import Enum, auto
from typing import Any, Dict, Generator, List, Optional

import dask.dataframe as dd
import pandas as pd

from snorkelflow.types.load import SourceType
from snorkelflow.utils.logging import get_logger

logger = get_logger("Data loaders")


class BaseDataLoader(abc.ABC):
    # NB: ideally we just use a string here and not depend on this
    # We can auto-gen the known source types from known DataLoaders
    # for use elsewhere
    identifier: SourceType

    @abc.abstractmethod
    def load(self) -> dd.DataFrame:
        pass

    @classmethod
    @abc.abstractmethod
    def from_config(cls, config: Dict[str, Any]) -> "BaseDataLoader":
        pass


class FileSizeDataLoaderMixin(abc.ABC):
    @abc.abstractmethod
    def file_size(self) -> Optional[int]:
        pass


class BatchSizeMode(Enum):
    """
    Describes how the batch size should be interpreted
    """

    # Number of rows in the batch. Every data loader supports this
    ROWS = auto()
    # Number of bytes in the batch. Some loaders don't have great support for this,
    # and may overshoot the target size.
    MEGABYTES = auto()


class BatchStreamDataLoaderMixin(abc.ABC):
    def iter_batches(
        self, max_batch_size: int, mode: BatchSizeMode
    ) -> Generator[pd.DataFrame, None, None]:
        """
        Yields dataframe with specified max size.
        For row mode, the dataframe will have at most max_batch_size rows.

        For megabyte mode, loaders will do a best effort to respect the specified size. If a single
        row is larger than the max_batch_size, a single row will be returned instead.
        Data loaders will first yield 10 rows in order to sample the size of a row.
        If the rows are very uneven, there is a chance that the batch will take more memory than specified.
        """
        if mode == BatchSizeMode.ROWS:
            batch_size = max_batch_size
        elif mode == BatchSizeMode.MEGABYTES:
            batch_size = 10
        else:
            raise ValueError(f"Unknown batch size mode {mode}")

        batch_generator = self._iter_batches()
        # Prime the coroutine
        next(batch_generator)

        running_size_mb = 0
        running_rows = 0
        while True:
            try:
                batch = batch_generator.send(batch_size)
            except StopIteration:
                break

            # If the batch's index is a RangeIndex, make sure the index is non-overlapping with other batches
            # If the index has a name, we assume that the user knows what they're doing
            if isinstance(batch.index, pd.RangeIndex) and not batch.index.name:
                batch = batch.set_index(
                    pd.RangeIndex(start=running_rows, stop=running_rows + len(batch))
                )

            running_rows += len(batch)
            running_size_mb += (
                batch.memory_usage(index=True, deep=True).sum() / 1024**2
            )
            yield batch
            if mode == BatchSizeMode.MEGABYTES:
                average_row_size_mb = running_size_mb / running_rows
                batch_size = max(1, int(max_batch_size / average_row_size_mb))

    @abc.abstractmethod
    def _iter_batches(self) -> Generator[pd.DataFrame, int, None]:
        """
        Returns a generator that yields the specified number of rows back
        Example:
        gen = loader._iter_batches()
        next(gen)
        batch = gen.send(chunksize)
        batch = gen.send(another_chunksize)

        See any existing data loader for how this is done.
        """
        pass


class JSONSecretMixin:
    # Implement this so we can remove the Snowflake check in datasources.py
    # Can we move that logic in here?

    @classmethod
    def put_json_secret(
        cls, secret_store_id: str, cred_kwargs: Dict[str, Any], workspace_uid: int
    ) -> str:
        from secret_store import get_secret_store

        secret_key = f"secret_{str(uuid.uuid4())[:8]}"
        secret_store = get_secret_store(secret_store_id, cred_kwargs)
        secret_store.put_secret(secret_key, json.dumps(cred_kwargs), workspace_uid)
        return secret_key

    @classmethod
    def get_json_secret(
        cls,
        secret_store_id: str,
        secret_key: str,
        reader_kwargs: Dict[str, Any],
        workspace_uid: int,
    ) -> Dict[str, Any]:
        from secret_store import get_secret_store

        secret_store = get_secret_store(secret_store_id, reader_kwargs)
        return json.loads(secret_store.get_secret(secret_key, workspace_uid))


class ColumnsDataLoaderMixin(abc.ABC):
    @abc.abstractmethod
    def columns(self) -> List[str]:
        """List of columns for dataframe"""
        pass


# Separate method for easy mocking.
def data_loader_can_stream(data_loader: BaseDataLoader) -> bool:
    return isinstance(data_loader, BatchStreamDataLoaderMixin)


class MinimumMemoryFootprint(abc.ABC):
    @abc.abstractmethod
    def min_memory_footprint(self) -> int:
        """The finest granularity the data can be loaded into memory in bytes.
        For example, if the data loader can only load rows in 10 mb chunks the minimum memory footprint is 10 mb.
        """
        pass
