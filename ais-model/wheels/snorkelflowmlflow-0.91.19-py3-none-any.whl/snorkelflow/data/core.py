import json
from timeit import default_timer as timer
from typing import (
    Any,
    Callable,
    Dict,
    Generator,
    Iterable,
    List,
    Optional,
    Set,
    Tuple,
    TypeVar,
    Union,
)

import dask.dataframe as dd
import numpy as np
import pandas as pd
import pyarrow as pa

from snorkelflow.data_loaders import ArrowDataLoader, get_data_loader_type
from snorkelflow.data_loaders.core import (
    BaseDataLoader,
    BatchSizeMode,
    BatchStreamDataLoaderMixin,
    ColumnsDataLoaderMixin,
)
from snorkelflow.serialization.get_serializable import (
    get_serializable_class,
    get_serialization_type,
)
from snorkelflow.serialization.pandas import (
    CATEGORICAL_REPEAT_THRESHOLD,
    _series_is_arrow_compatible,
    deserialize_dataframe_series,
    serialize_dataframe_series,
    serialize_series,  # noqa: F401 (for mlflow model backwards compatibility)
)
from snorkelflow.types.load import (
    DATAPOINT_UID_COL,
    TYPES_COL,
    LoadConfig,
    LoadConfigs,
    MinioArgs,
    SourceType,
)
from snorkelflow.utils.arrow import to_arrow
from snorkelflow.utils.dask_dataframe import cull_empty_partitions
from snorkelflow.utils.datapoint import DocDatapoint
from snorkelflow.utils.file import resolve_data_path
from snorkelflow.utils.logging import get_logger
from snorkelflow.utils.pickle import to_pickle

PEEK_HEAD_NUM_ROWS = 20  # Default number of rows for peeking
PEEK_HEAD_NUM_CHARS = 500  # Default char truncate limit per string element


DUMMY_COL = "__DUMMY_COL"
INVALID_CSV_ERROR_MSG = (
    "Failed to read CSV. This is often due to line break characters in "
    "quoted strings or file not being encoded in UTF-8. Consider using Parquet format "
    "(https://pandas.pydata.org/pandas-docs/stable/reference/api/pandas.DataFrame.to_parquet.html) "
    'or using {"blocksize": null, "sample": false} for Reader Kwargs.'
)

logger = get_logger("Data")


def get_arrow_schema(df: pd.DataFrame) -> pa.Schema:
    schema = pa.Table.from_pandas(df).schema
    for col in df.select_dtypes(include="object").columns:
        # Make sure to set all the object columns as Categorical
        # to force dictionary encoding. This is needed as we store
        # repetitive large strings in the dataframe.
        schema = schema.set(
            schema.get_field_index(col),
            pa.field(
                col,
                pa.dictionary(value_type=pa.string(), index_type=pa.int32(), ordered=0),
            ),
        )
    return schema


def get_suffix_for_source_type(source_type: SourceType) -> str:
    mapping = {
        SourceType.CSV: ".csv",
        SourceType.PARQUET: ".parquet",
        SourceType.PICKLE: ".pickle",
        SourceType.ARROW_IPC: ".arrow",
    }
    return mapping[source_type]


def get_load_type_value(type_name: str) -> int:
    name_to_val = {st.name: st.value for st in SourceType}
    if type_name not in name_to_val:
        raise ValueError(
            f"Invalid type: {type_name}. Must be in {', '.join(name_to_val)}"
        )
    return name_to_val[type_name]


DF = TypeVar("DF", bound=Union[pd.DataFrame, dd.DataFrame])


def populate_types_col(df: DF, all_string_cols: Optional[Set[str]] = None) -> DF:
    """
    If all_string_cols is not set, will perform expensive type-check of expensive columns
    This is fine if not performing multiple operations that need to check whether object column is string-type.
    """
    col_to_types = {}

    for col in df.columns:
        if _series_is_arrow_compatible(col, df[col], all_string_cols):
            continue

        col_types = df[col].map(get_serialization_type)
        if col_types.isna().all():
            continue
        col_to_types[col] = col_types
    types_df = pd.DataFrame(col_to_types)
    # Weird assign syntax to avoid modifying the original dataframe underlying the dask dataframe in tests.
    if types_df.empty:
        # Optimization for DFs with no special-type columns
        df = df.assign(**{TYPES_COL: "{}"})
    else:
        df = df.assign(
            **{
                TYPES_COL: types_df.apply(
                    lambda row: json.dumps(
                        {col: row[col] for col in row.index if row[col] is not None}
                    ),
                    1,
                )
            }
        )
    df[TYPES_COL] = df[TYPES_COL].astype("string")
    return df


def get_file_type_by_extension(path: str) -> SourceType:
    if path.endswith(".csv"):
        return SourceType.CSV
    elif path.endswith(".parquet"):
        return SourceType.PARQUET
    elif path.endswith(".pickle"):
        return SourceType.PICKLE
    elif path.endswith(".arrow"):
        return SourceType.ARROW_IPC
    else:
        raise ValueError(f"Unsupported file type for path: {path}")


def maybe_serialize_cols_and_save_ddf(
    ddf: dd.DataFrame,
    load_type: SourceType,
    path: str,
    coerce_object_as_category: bool = False,
) -> List[Any]:
    # Save dataframe to a path relative to container. Conversion to
    # host-relative path is done before saving the path to a config.
    # Use compute=False to return a delayed object instead of serializing
    # immediately so we can do all writes at once, with a scheduler of our
    # choice.
    # TODO - this ^ comment no longer reflects the state of this method.
    # Update is to correctly reflect both the `path` requirements and the
    # compute=True/False missing parameter.
    ddf = ddf.map_partitions(
        populate_types_col, meta={**ddf.dtypes.to_dict(), TYPES_COL: "string"}
    )

    ddf = ddf.map_partitions(
        serialize_dataframe_series,
        coerce_object_as_category=coerce_object_as_category,
        meta=ddf,
        # We can't dynamically change the schema for Parquet files due to limitations in dd.to_parquet,
        # so go ahead and write all object columns as categorical like we did before
        # For everything else, use the dynamic way of determining when to choose categorical vs object
        categorical_repeat_threshold=0
        if load_type == SourceType.PARQUET
        else CATEGORICAL_REPEAT_THRESHOLD,
    )

    # Set the schema for writing as parquet
    schema = None
    if coerce_object_as_category and load_type == SourceType.PARQUET:
        # even though all object columns have been coerced to categorical in the parquet case,
        # get_arrow_schema expects these columns to be object in _meta_nonempty, and manually sets
        # the schema for them properly
        ddf = ddf.map_partitions(
            lambda df: df,
            meta={
                col: np.dtype("O") if dtype.name == "category" else dtype
                for col, dtype in ddf.dtypes.to_dict().items()
            },
        )
        schema = get_arrow_schema(ddf._meta_nonempty)

    return save_ddf(ddf, load_type, path, schema)


def save_ddf(
    ddf: dd.DataFrame,
    load_type: SourceType,
    path: str,
    schema: Optional[pa.Schema] = None,
) -> List[Any]:
    if load_type == SourceType.PARQUET:
        return [
            dd.to_parquet(
                ddf,
                resolve_data_path(path),
                engine="pyarrow",
                compute=False,
                schema=schema,
            )
        ]
    elif load_type == SourceType.ARROW_IPC:
        # Passing the schema here via dask's _meta_nonempty results in issues
        return [to_arrow(ddf, resolve_data_path(path), compute=False)]
    elif load_type == SourceType.PICKLE:
        return [to_pickle(ddf, resolve_data_path(path), compute=False)]
    elif load_type == SourceType.CSV:
        # TODO(ENG-15414): remove the ability to save ddf as CSV
        return [ddf.to_csv(resolve_data_path(path), compute=False, single_file=True)]
    else:
        raise ValueError(
            "Internal files must use parquet, pickle, or arrow-ipc format."
        )


def deserialize_dataframe_by_row(df: pd.DataFrame) -> pd.DataFrame:
    """
        A deserializer that deserializes by row. Use this if we expect
        non homogenous (mixed) types in the same column. While this is
        rare, it ensures correctness of the dataframe round tripping

    Args:
        df (pd.DataFrame): Dataframe to be deserialized

    Returns:
        pd.DataFrame: Deserialized dataframe
    """

    start_time = timer()

    cache: Dict[int, Any] = {}

    def _helper(row: Any) -> Any:
        types = json.loads(row[TYPES_COL])
        for col in types.keys():
            if row[col] not in cache:
                cache[row[col]] = get_serializable_class(types[col]).deserialize(row[col])  # type: ignore
            row[col] = cache[row[col]]

        return row

    df = df.apply(_helper, axis=1)

    logger.info(f"Deserialization from repartition took {timer() - start_time}")
    return df


def get_optimistic_memory_size(df: pd.DataFrame) -> int:
    """
    df.get_memory_usage(deep=True) doesn't take into account memory deduplication
    df.get_memory_usage() doesn't take into account object memory size accurately

    This method attempts to estimate memory based on actual object memory
    """
    # Start with index memory
    memory = df.index.memory_usage(deep=True)

    for col in df.columns:
        # Get unique values and get size of unique objects
        unique_indices = df[col].map(id).drop_duplicates().index
        col_memory = df[col][unique_indices].memory_usage(deep=True, index=False)

        # For object columns, pandas will store a memory address pointer ot the object
        if df[col].dtype == "object":
            col_memory += df[col].memory_usage(index=False)
        memory += col_memory

    return memory


def concat_dfs(dfs: List[pd.DataFrame]) -> pd.DataFrame:
    """A fancy version of pd.concat that does some column checking for us before the actual concat happens."""
    if len(dfs) == 1:
        return dfs[0]

    cols = dfs[0].columns
    all_cols = dfs[0].columns
    for df in dfs[1:]:
        cols = cols.intersection(df.columns)
        all_cols = all_cols.union(df.columns)
    if len(cols) == 0 and dfs[0].index.name != DATAPOINT_UID_COL:
        raise ValueError(f"Invalid Empty dataframe with no {DATAPOINT_UID_COL}")

    if len(cols) != len(all_cols):
        logger.warning(
            f"Not using all columns. Found {all_cols.tolist()}, "
            f"using columns found in all sources: {cols.tolist()}"
        )

    return pd.concat([df[cols] for df in dfs])


def _concat_ddfs(ddfs: List[dd.DataFrame], interleave_partitions: bool) -> dd.DataFrame:
    if len(ddfs) == 1:
        return ddfs[0]

    cols = ddfs[0].columns
    all_cols = ddfs[0].columns
    for ddf in ddfs[1:]:
        cols = cols.intersection(ddf.columns)
        all_cols = all_cols.union(ddf.columns)
    if len(cols) == 0 and ddfs[0].index.name != DATAPOINT_UID_COL:
        raise ValueError(f"Invalid Empty dataframe with no {DATAPOINT_UID_COL}")

    if len(cols) != len(all_cols):
        logger.warning(
            f"Not using all columns. Found {all_cols.tolist()}, "
            f"using columns found in all sources: {cols.tolist()}"
        )
    ddfs_to_concat = []
    for ddf in ddfs:
        if interleave_partitions:
            # Empty dataframes will have nan's in the index if we ever called
            # set_index. But when we concat these with non-empty dataframes with
            # interleave_partitions=True, it causes the result to be empty
            # (due to nan==nan returning False in dask/dataframe/multi.py:134).
            # So we just verify they're empty and skip them.
            if any(isinstance(div, float) and np.isnan(div) for div in ddf.divisions):
                if len(ddf):
                    raise ValueError(
                        "Found nan in index division of non-empty dataframe"
                    )
                else:
                    # Skip empty dataframe
                    continue
        ddfs_to_concat.append(ddf[cols])
    # Return concatenated DataFrames
    return dd.concat(ddfs_to_concat, interleave_partitions=interleave_partitions)


def subsample_datapoint_uids_pd(
    df: pd.DataFrame,
    uids: Iterable[str],
    is_sorted: bool = False,
    index_col: str = DATAPOINT_UID_COL,
) -> pd.DataFrame:
    if not is_sorted:
        uids = sorted(list(uids))
    if df.index.name == index_col:
        subsampled_df = df.loc[df.index.intersection(uids)]
    elif index_col in df.columns:
        subsampled_df = df[df[index_col].isin(uids)]
    else:
        raise ValueError(
            f"Can't sample_uids for if {index_col} is neither the index" " nor a column"
        )
    subsampled_df.index.name = df.index.name
    return subsampled_df


def subsample_datapoint_uids(ddf: dd.DataFrame, uids: Iterable[str]) -> dd.DataFrame:
    uids = sorted(list(uids))
    return ddf.map_partitions(
        subsample_datapoint_uids_pd,
        uids=uids,
        is_sorted=True,
        meta=ddf.dtypes.to_dict(),
    )


def get_dataframe_head(
    ddf: dd.DataFrame, n_rows: int, n_chars: Optional[int]
) -> dd.DataFrame:
    head = ddf.head(n_rows, npartitions=-1, compute=False)
    if n_chars is None:
        return head
    return head.applymap(lambda x: x[:n_chars] if isinstance(x, str) else x)


def _set_index_using_one_partition(ddf: dd.DataFrame) -> dd.DataFrame:
    """sets the index to DATAPOINT_UID_COL
    set_index is memory expensive when we have more than one partition,
    so repartition to 1 partition, set_index, and go back to same number
    of partitions as before.
    """
    # Remove empty partitions first as dask>=2022.4.0 doesn't work well with them
    ddf = cull_empty_partitions(ddf)
    num_partitions = ddf.npartitions
    ddf = ddf.repartition(npartitions=1)
    ddf = ddf.set_index(DATAPOINT_UID_COL)

    def get_partition_min_max(df: pd.DataFrame) -> Tuple[str, str]:
        index = df.index.tolist()
        return index[0], index[-1]

    ddf = ddf.repartition(num_partitions)
    min_max = ddf.map_partitions(get_partition_min_max, meta=("object")).compute()
    divisions = [x[0] for x in min_max] + [min_max[len(min_max) - 1][1]]
    ddf.divisions = tuple(divisions)
    return ddf


def fix_col_types_and_values(
    ddf: Union[pd.DataFrame, dd.DataFrame]
) -> Union[pd.DataFrame, dd.DataFrame]:
    # Convert the categorical columns to object
    # https://pandas.pydata.org/pandas-docs/stable/user_guide/categorical.html#regaining-original-data
    # this function will do it in place
    new_dtypes = {
        col: "object" if dtype.name == "category" else dtype
        for col, dtype in ddf.dtypes.to_dict().items()
    }
    if isinstance(ddf, dd.DataFrame):
        return ddf.map_partitions(_convert_categorical_to_object, meta=new_dtypes)
    else:
        return _convert_categorical_to_object(ddf, {"number": 0})


def _convert_categorical_to_object(
    df: pd.DataFrame, partition_info: Optional[Dict] = None
) -> pd.DataFrame:
    cols_converted = []
    for col in df.columns:
        if df[col].dtype.name == "category":
            if partition_info and partition_info.get("number", -1) == 0:
                cols_converted.append(col)
            df[col] = df[col].astype("object")
            df[col] = df[col].replace({np.nan: None})
    if cols_converted:
        logger.info(f"Setting {cols_converted} as string")
    return df


def rename_uid_column(
    df: Union[pd.DataFrame, dd.DataFrame],
    ds_schema_version: int,
    uid_col_name: Optional[str],
    rename_datapoint_uid: str,
    rename_fn: Callable,
) -> Union[pd.DataFrame, dd.DataFrame]:
    if DATAPOINT_UID_COL in df.columns:
        # ds_schema_version = 0 and set_uid=True allow skipping the DATAPOINT_UID calculation
        df[rename_datapoint_uid] = df[DATAPOINT_UID_COL]
    elif DATAPOINT_UID_COL == df.index.name:
        # ds_schema_version >= 3
        df = rename_fn()
    else:
        if ds_schema_version != 0:
            raise ValueError(
                f"Didn't find {DATAPOINT_UID_COL} even though ds_schema_version={ds_schema_version}"
            )
        if uid_col_name is None:
            raise ValueError(
                "Cannot compute datapoint_uid if uid_col is not set and ds_schema_version=0"
            )
        datapoint_instance = DocDatapoint([uid_col_name])
        df[rename_datapoint_uid] = datapoint_instance.get_datapoint_uid_col_pandas(df)

    return df


def _load_dataframe_from_config(
    load_config: LoadConfig,
    set_uid: bool = True,
    rename_uid: Optional[str] = None,
    minio_args: Optional[MinioArgs] = None,
    target_columns: Optional[List[str]] = None,
    sample_uids: Optional[Iterable[str]] = None,
    exclude_data_columns: bool = False,
    rename_datapoint_uid: Optional[str] = None,
    deserialize_columns: bool = True,
) -> dd.DataFrame:
    load_type = load_config.type
    if load_type is None:
        raise ValueError("load_type is required but missing")
    config = load_config.dict()
    config["minio_args"] = minio_args
    data_loader = get_data_loader_type(load_type).from_config(config)
    if isinstance(data_loader, ArrowDataLoader):
        data_loader.dask_kwargs["convert_categorical_to_object"] = deserialize_columns
    if (
        target_columns
        and load_config.uid_col
        and load_config.uid_col not in target_columns
    ):
        target_columns = target_columns + [load_config.uid_col]
    elif exclude_data_columns and load_config.uid_col:
        target_columns = [load_config.uid_col]

    if isinstance(data_loader, ColumnsDataLoaderMixin):
        ddf = None  # defer loading of ddf to later
        columns = data_loader.columns()
    else:
        ddf = data_loader.load()
        columns = ddf.columns.to_list()

    if target_columns is None:
        columns_to_read = columns
    else:
        columns_to_read = list(set(columns).intersection(target_columns))

    # If parquet or arrow, load DataFrame with pruned column names
    if set(columns_to_read) != set(columns):
        config["reader_kwargs"]["columns"] = columns_to_read
        if load_type in {SourceType.PARQUET, SourceType.ARROW_IPC}:
            data_loader = get_data_loader_type(load_type).from_config(config)
            if isinstance(data_loader, ArrowDataLoader):
                data_loader.dask_kwargs[
                    "convert_categorical_to_object"
                ] = deserialize_columns
            ddf = data_loader.load()

    # Load ddf if not already loaded
    if ddf is None:
        ddf = data_loader.load()

    ddf = fix_col_types_and_values(ddf)

    ds_schema_version = load_config.ds_schema_version
    if ds_schema_version in [1, 2]:
        raise ValueError(
            f"ds_schema_version {ds_schema_version} is no longer supported! Refresh the datasources."
        )

    uid_col_name = load_config.uid_col
    if not set_uid and ds_schema_version >= 3 and load_type == SourceType.CSV:
        # the index is NOT set yet because of the way loading from csv in dask works
        set_uid = True
        if uid_col_name is None:
            uid_col_name = DATAPOINT_UID_COL

    # Set index using UID column
    if set_uid:
        if (
            ds_schema_version == 0
            and uid_col_name is not None
            and uid_col_name != DATAPOINT_UID_COL
        ):
            # if passed uid_col, set the index to doc::<uid_col>
            # unless the index is already set to datapoint_uid, in which case, do nothing
            datapoint_instance = DocDatapoint([uid_col_name])
            ddf[DATAPOINT_UID_COL] = datapoint_instance.get_datapoint_uid_col(ddf)
            uid_col_name = DATAPOINT_UID_COL
        elif ds_schema_version >= 3 and uid_col_name != DATAPOINT_UID_COL:
            raise ValueError(
                f"uid_col has to be {DATAPOINT_UID_COL}, but received {uid_col_name}"
            )
        # Note: set_index in dask is very expensive (without sorted=True),
        # because it causes a full re-shuffle.
        if ddf.index.name != uid_col_name:
            if ddf.index.name:
                # If ddf already has a named index, reset to preserve it as a column
                columns_to_read.append(ddf.index.name)
                ddf = ddf.reset_index()
            if uid_col_name not in ddf.columns:
                raise ValueError(f"Missing uid column: {uid_col_name}")
            logger.warning(
                f"Setting index to column {uid_col_name}. This is an expensive "
                f"operation that can be avoided by inputting a dataframe that already has"
                f"{uid_col_name} as an index."
            )
            ddf = _set_index_using_one_partition(ddf)

            # Setting a new index can lead to empty partitions since the re-shuffle is
            # estimation based
            ddf = cull_empty_partitions(ddf)

    if sample_uids is not None:
        ddf = subsample_datapoint_uids(ddf, sample_uids)

    ddf = ddf[ddf.columns.intersection(columns_to_read)]

    if deserialize_columns:
        ddf = ddf.map_partitions(
            deserialize_dataframe_series, load_config.col_types, meta=ddf
        )

    # Remove TYPES_COL since it isn't used anywhere, and lots of caller have strict
    # assertions on column names loaded from the file.
    if TYPES_COL in ddf.columns.to_list():
        ddf = ddf.drop(TYPES_COL, axis=1)

    if target_columns:
        if TYPES_COL in target_columns:
            target_columns.remove(TYPES_COL)
        ddf = ddf[ddf.columns.intersection(target_columns)]

    if rename_uid is not None:
        if uid_col_name is None:
            raise ValueError("Cannot call rename_uid if uid col is not set")
        if uid_col_name == ddf.index.name:
            ddf = ddf.map_partitions(lambda df: df.assign(**{rename_uid: df.index}))
        else:
            if uid_col_name not in ddf.columns:
                raise ValueError(f"Missing uid column: {uid_col_name}")
            ddf = ddf.rename(columns={uid_col_name: rename_uid})

    if rename_datapoint_uid:
        ddf = rename_uid_column(
            ddf,
            ds_schema_version,
            uid_col_name,
            rename_datapoint_uid,
            lambda: ddf.map_partitions(  # type: ignore
                lambda df: df.assign(**{rename_datapoint_uid: df.index})
            ),
        )

    logger.info(f"Successfully loaded DataFrame with columns={list(ddf.columns)}")
    return ddf


def is_improper_csv_format_error(e: Exception) -> bool:
    return (
        "Error tokenizing data. C error: EOF inside string" in str(e)
        or "EOF encountered while reading header" in str(e)
        or "'utf-8' codec can't decode" in str(e)
    )


def load_dataframe_from_config(
    load_config: LoadConfig,
    set_uid: bool = True,
    rename_uid: Optional[str] = None,
    minio_args: Optional[MinioArgs] = None,
    target_columns: Optional[List[str]] = None,
    sample_uids: Optional[Iterable[str]] = None,
    exclude_data_columns: bool = False,
    rename_datapoint_uid: Optional[str] = None,
    deserialize_columns: bool = True,
) -> dd.DataFrame:
    """Load Dask DataFrame using a source config.

    Parameters
    ----------
    load_config
        A load config that represents how to load a datasource.
        The config dictionary entries are passed as kwargs to the loader
        function specified by ``load_type``, apart from the special
        key uid_col denoted in this file. The uid_col is used to
        set the index using a specific column if all configs have
        said key.
    set_uid
        Set index to doc::uid_col.
        By default, this will be set to the ``context_uid`` column.
        Is always true if ds_schema_version>=3.
    rename_uid
        If set, rename column given by uid_col to this.
        NOTE: when set_uid=True (or ds_schema_version>=3), this will add a new column
        instead that is identical to the index, but won't rename the index (since
        the index is _DATAPOINT_UID in this case).
    minio_args
        Optional MinioArgs object specifying minio url and credentials. Only
        used if path starts with minio://
    target_columns
        Optional list of columns needed in dataframe. Default to all columns.
    sample_uids
        If not None, subsample dataframe down to these uids before
        applying load processors or deserializing.
    rename_datapoint_uid
        If set, rename/calculate datapoint_uid to this value.
        Used to avoid setting index in dask.

    Returns
    -------
    dd.DataFrame
        Dask DataFrame with data from the specified source
    """
    try:
        return _load_dataframe_from_config(
            load_config,
            set_uid=set_uid,
            rename_uid=rename_uid,
            minio_args=minio_args,
            target_columns=target_columns,
            sample_uids=sample_uids,
            exclude_data_columns=exclude_data_columns,
            rename_datapoint_uid=rename_datapoint_uid,
            deserialize_columns=deserialize_columns,
        )
    except (ValueError, pd.errors.ParserError) as e:
        if load_config.type == SourceType.CSV and is_improper_csv_format_error(e):
            logger.exception(INVALID_CSV_ERROR_MSG)
            raise ValueError(f"{INVALID_CSV_ERROR_MSG} || Raw error message: {e}")
        elif "Error tokenizing data. C error: Expected" in str(e):
            raise ValueError(
                "The file you uploaded has inconsistent data structure. Each row must have the same number of fields"
            ) from e
        else:
            raise ValueError(
                f"Failed to read data source: {load_config.path} || Raw error message: {e}"
            )
    except FileNotFoundError as e:
        raise FileNotFoundError(
            f"File not found: {load_config.path} || Raw error message: {e}"
        )
    except Exception as e:
        raise ValueError(
            f"Failed to read data source: {load_config.path} || Raw error message: {e}"
        )


def load_dataframe_from_configs(
    load_configs: LoadConfigs,
    set_uid: bool = False,
    rename_uid: Optional[str] = None,
    minio_args: Optional[MinioArgs] = None,
    target_columns: Optional[List[str]] = None,
    sample_uids: Optional[Iterable[str]] = None,
    exclude_data_columns: bool = False,
    rename_datapoint_uid: Optional[str] = None,
    deserialize_columns: bool = True,
) -> dd.DataFrame:
    """Load Dask DataFrame using a dictionary of individual source configs.

    Parameters
    ----------
    load_configs
        A list of dictionary configs that each represent how to load a datasource.
        The config dictionary entries are passed as kwargs to the loader
        function specified by ``load_type``, apart from the special
        key uid_col denoted in this file. The uid_col is used to
        set the index using a specific column if all configs have
        said key.
    set_uid
        Set index to doc::uid_col
    rename_uid
        If set, rename column given by uid_col to this.
    sample_uids
        If not None, subsample dataframe down to these uids before
        applying load processors or deserializing.
    rename_datapoint_uid
        If set, rename/calculate datapoint_uid to this value.
        Used to avoid setting index in dask.
    deserialize_columns
        If True, then deserialize any serialized columns and convert any categorical columns to object

    Returns
    -------
    dd.DataFrame
        Dask DataFrame with data from all loaded sources
    """
    # Load configs into sub-DataFrames
    ddfs = [
        load_dataframe_from_config(
            load_config,
            set_uid=set_uid,
            rename_uid=rename_uid,
            minio_args=minio_args,
            target_columns=target_columns,
            sample_uids=sample_uids,
            exclude_data_columns=exclude_data_columns,
            rename_datapoint_uid=rename_datapoint_uid,
            deserialize_columns=deserialize_columns,
        )
        for load_config in load_configs
    ]

    return _concat_ddfs(ddfs, interleave_partitions=(len(load_configs) > 1))


def data_loader_can_stream(data_loader: BaseDataLoader) -> bool:
    # Separate method for easy mocking.
    return isinstance(data_loader, BatchStreamDataLoaderMixin)


def stream_datasource_from_config(
    datasource_load_type: SourceType,
    datasource_load_config: LoadConfig,
    batch_size: int = 100,
    batch_size_mode: BatchSizeMode = BatchSizeMode.ROWS,
    sample_uids: Optional[Iterable[str]] = None,
    sample_uids_is_sorted: bool = False,
    index_col: str = DATAPOINT_UID_COL,
) -> Generator[pd.DataFrame, None, None]:
    """Returns a Generator over batches of data from the specified datasource."""
    data_loader = get_data_loader_type(datasource_load_type).from_config(
        datasource_load_config.dict()
    )
    if data_loader_can_stream(data_loader):
        assert isinstance(data_loader, BatchStreamDataLoaderMixin)  # mypy
        generator = data_loader.iter_batches(
            max_batch_size=batch_size, mode=batch_size_mode
        )
        batch: pd.DataFrame
        for batch in generator:
            if sample_uids:
                batch = subsample_datapoint_uids_pd(
                    batch,
                    sample_uids,
                    is_sorted=sample_uids_is_sorted,
                    index_col=index_col,
                )
            yield batch
    else:
        # No streaming, just load 1 partition at a time
        ddf = data_loader.load()
        for partition in ddf.partitions:
            batch = partition.compute()
            if sample_uids:
                batch = subsample_datapoint_uids_pd(
                    batch,
                    sample_uids,
                    is_sorted=sample_uids_is_sorted,
                    index_col=index_col,
                )
            yield batch
