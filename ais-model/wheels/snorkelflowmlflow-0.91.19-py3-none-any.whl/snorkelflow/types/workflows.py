import json
from typing import Any, Dict, List, Optional

from pydantic import BaseModel

OperatorId = int


class OperatorInitConfig(BaseModel):
    """Data needed to initialize an operator."""

    op_type: str
    op_config: Dict[str, Any]
    op_asset: Optional[str] = None
    op_impl_version: int = 0

    def __str__(self) -> str:
        # op configs can be very long, so we truncate to avoid log spam
        truncated_op_config = {
            k: f"{str(v)[:1000]}..." for k, v in self.op_config.items()
        }
        return json.dumps(
            {
                "op_type": self.op_type,
                "op_config": truncated_op_config,
                "op_asset": self.op_asset,
                "op_impl_version": self.op_impl_version,
            }
        )


class OperatorConfig(OperatorInitConfig):
    input_ids: List[OperatorId]
    is_output: bool = False


# Define Workflow-related constants
INPUT_NODE_ID = -1
INPUT_NODE_TYPE = "_input"

WorkflowConfig = Dict[OperatorId, OperatorConfig]
