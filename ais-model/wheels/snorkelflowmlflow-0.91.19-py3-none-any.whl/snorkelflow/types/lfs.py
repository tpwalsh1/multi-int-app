class LFsExportKeys:
    PACKAGES = "packaged_lfs"
    ACTIVE = "active_lfs"
    LF_CONFIGS = "lf_configs_dict"
    LF_DATASOURCES_APPLIED = "lf_datasources_applied"
    LF_LABELS = "lf_labels"
    LF_AUTHORS = "lf_authors"
    LF_SUGGESTION_METADATA = "lf_suggestion_metadata"
