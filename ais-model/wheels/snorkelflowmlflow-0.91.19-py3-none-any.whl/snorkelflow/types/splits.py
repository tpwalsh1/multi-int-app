from enum import Enum


class Splits(str, Enum):
    train = "train"
    dev = "dev"
    valid = "valid"
    test = "test"


SCALE_SPLITS = [Splits.dev.value, Splits.test.value, Splits.valid.value]
