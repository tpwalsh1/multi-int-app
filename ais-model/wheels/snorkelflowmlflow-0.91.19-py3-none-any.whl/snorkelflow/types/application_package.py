from __future__ import annotations

from abc import ABC
from enum import Enum
from typing import Any, Dict, List, Optional, Type

from pydantic import BaseModel, root_validator

DataframeRecordsJSON = List[Dict[str, Any]]


class WorkflowEnv(str, Enum):
    NONE = "none"
    FIRST_PARTY = "first_party"
    FULL = "full"


class PackageType(str, Enum):
    SnorkelFlowPackage = "SnorkelFlowPackage"
    MLflowModel = "MLflowModel"


class ModelRegistryType(str, Enum):
    internal = "INTERNAL"
    external = "EXTERNAL"


class RegistryAuthenticationCredentials(BaseModel):
    username: Optional[str] = None
    password: Optional[str] = None
    bearer_token: Optional[str] = None

    @root_validator
    def basic_or_bearer(cls, values: Dict[str, Any]) -> Dict[str, Any]:
        """
        One must either full basic auth or full bearer auth but not both
        """
        username, password = values.get("username"), values.get("password")
        bearer_token = values.get("bearer_token")
        if bearer_token and (username is None and password is None):
            # Only a token provided
            return values
        if bearer_token is None and (username and password):
            # Only username and password provided
            return values
        # They've either included no values or too many
        raise ValueError(
            f"One must either specify a username+password or a bearer token for authentication, provided: {values}"
        )


class RegistryStorageCredentials(BaseModel):
    """
    When running an MLflow model registry, one has the option of using an S3-compatible
    service for artifact storage. The registry can either proxy uploads to storage or can
    have the client upload directly. If we are to upload directly, we need the same access
    credentials as the server (i.e. we are not given signed URLs). The access key and secret
    key can be used to provide access to S3, and the S3 endpoint url can be used to point us
    to, for example, MinIO (or other S3-compatible storage)
    """

    mlflow_s3_endpoint_url: Optional[str] = None
    aws_access_key_id: Optional[str] = None
    aws_secret_access_key: Optional[str] = None

    @root_validator
    def requires_access_and_secret_key(cls, values: Dict[str, Any]) -> Dict[str, Any]:
        access = values.get("aws_access_key_id")
        secret = values.get("aws_secret_access_key")
        if bool(access) + bool(secret) == 1:
            raise ValueError(
                "Both an aws_access_key_id and aws_secret_access_key must be specified (or neither)"
            )
        return values


class ModelRegistryAccessInformation(BaseModel):
    """
    Minimal set of registry information passed to the low-level and exportable
    application_package code that allows it to talk to a model registry (without
    having to depend directly on the ModelRegistry database model)
    """

    model_registry_uid: Optional[int] = None
    tracking_server_uri: str
    auth_credentials: Optional[RegistryAuthenticationCredentials] = None
    storage_credentials: Optional[RegistryStorageCredentials] = None


deployment_storage_information_dict: Dict[str, Type["DeploymentStorageInfo"]] = {}


class DeploymentStorageInfoConfig(BaseModel):
    """
    Used to serialize deployment storage information over the wire
    while maintaining class information
    """

    cls_name: str
    kwargs: Dict[str, Any]

    # TODO - use validator to ensure cls_name belong to deployment_storage_information_dict


class DeploymentStorageInfo(BaseModel, ABC):
    def __init_subclass__(cls, **kwargs: Any) -> None:
        """Define init subclass to register all subclasses in application_templates dict."""
        super(cls).__init_subclass__(**kwargs)  # type: ignore
        deployment_storage_information_dict[cls.__name__] = cls

    @staticmethod
    def from_config(cls_name: str, kwargs: Dict[str, Any]) -> DeploymentStorageInfo:
        StorageInfoClass = deployment_storage_information_dict.get(cls_name)
        if not StorageInfoClass:
            raise ValueError(
                f"Unable to find DeploymentStorageInformation class of type {type}"
            )

        return StorageInfoClass(**kwargs)

    def to_config(self) -> DeploymentStorageInfoConfig:
        return DeploymentStorageInfoConfig(
            cls_name=self.__class__.__name__, kwargs=self.dict()
        )


class DeploymentFileStorageInfo(DeploymentStorageInfo):
    """
    Represents a deployment stored as a directory on the shared disk
    # TODO - generalize this to support external storage systems like s3
    """

    workflow_package_dir: str


class DeploymentModelRegistryStorageInfo(DeploymentFileStorageInfo, ABC):
    """
    Separated out so that MLflow-specific methods can accept "this"
    class and its children, while other methods can take *any* class
    in this hierarchy (to support both MLflowModel and SnorkelFlowPackage)
    """

    registered_model_name: str
    model_version: str
    run_id: str
    model_uuid: str
    artifact_path: str
    model_uri: str
    experiment_id: int
    experiment_name: str

    @property
    def model_version_uri(self) -> str:
        """
        Return a model_uri in the format
            "models:/<registered_model_name>/<model_version>"
        This is required for some mlflow operations and it reads easier
        than the self.model_uri format of runs:/<run_uuid>/<registered_model_name>
        """
        return f"models:/{self.registered_model_name}/{self.model_version}"


class DeploymentInternalRegistryStorageInfo(DeploymentModelRegistryStorageInfo):
    """
    Holds information about how and where an ApplicationDeployment is stored
    inside of the Snorkel Flow internal MLflow model registry. This includes
    registry-specific UIDs, UUIDs, timestamps, and other URI information
    that we do not persist in our own OLTP
    """

    pass


class DeploymentExternalRegistryStorageInfo(DeploymentInternalRegistryStorageInfo):
    """
    The same information as is used when storing ApplicationDeployments in our
    internal registry, except these are stored in an external one (that we can
    look up via the model_registry_uid)
    """

    model_registry_uid: int


class UIComponent(str, Enum):
    """These constants map to components rendered in the UI."""

    CHECKBOX = "Checkbox"
    NUMBER = "Number"
    TEXT = "Text"
    MULTI_TEXT = "MultiText"
    JSON = "JSON"
    CHOICES = "Choices"
    RADIO = "Radio"
    # Special fields: frontend should populate choices with
    # associated dataset's dataframe columns
    DF_FIELD_CHOICES = "DataframeFieldChoices"
    DF_FIELD_MULTI_CHOICES = "DataframeMultiFieldChoices"
    # Frontend should populate choices with available dataset
    DATASET_CHOICES = "DatasetChoices"
    # Frontend should populate choices with available label schemas
    LABEL_SCHEMA_CHOICES = "LabelSchemaChoices"
