from typing import Optional

from pydantic import BaseModel


class Performance(BaseModel):
    compute_time_secs: int
    peak_memory_mb: int
    gpu_peak_memory_mb: Optional[int]
