from enum import Enum
from typing import Any, Dict, List, Optional, Set, Tuple

import networkx as nx
from pydantic import BaseModel

from snorkelflow.types.workflows import (
    INPUT_NODE_ID,
    INPUT_NODE_TYPE,
    OperatorConfig,
    OperatorId,
    WorkflowConfig,
)
from snorkelflow.utils.logging import get_logger

# Initialize Logger
logger = get_logger("Workflows")


class InvalidWorkflowException(Exception):
    pass


def make_input_op_config() -> OperatorConfig:
    """Return an OperatorConfig for the input node."""
    return OperatorConfig(input_ids=[], op_type=INPUT_NODE_TYPE, op_config={})


def get_workflow_output_ids(workflow_config: WorkflowConfig) -> List[OperatorId]:
    """Get list of output node ids for given workflow config."""
    return sorted(
        [op_id for op_id, op_config in workflow_config.items() if op_config.is_output]
    )


def workflow_configs_subgraph_match(
    first: WorkflowConfig, second: WorkflowConfig, first_terminal_op_id: OperatorId
) -> Optional[OperatorId]:
    """Check if first workflow, ending at first_terminal_op_id, is a subgraph of second.

    If it is a subgraph, returning matching op_id in second. Else return None.
    If there are multiple matches, returns any one of them.
    The check is agnostic to op_id values themselves e.g. they don't have to be
    contiguous, or increasing, or match exactly between the two workflows.
    """
    if first_terminal_op_id not in first:
        raise ValueError(f"{first_terminal_op_id} should be a node in workflow {first}")
    for second_terminal_op_id in second:
        if workflow_configs_targets_match(
            first, second, first_terminal_op_id, second_terminal_op_id
        ).is_match:
            return second_terminal_op_id
    return None


class StaleReasons(Enum):
    USER_CAUSE = "One or more model preprocessors are changed by user since last viewed"
    OP_IMPL_VERSION_CHANGED = (
        "Operator {} is updated to a newer version with recent upgrade"
    )
    OUTDATED_DS = "Outdated datasource"
    UNCOMMITTED_OP = "Uncommitted operators in upstream"


class WorkflowTargetsMatchInfo(BaseModel):
    is_match: bool
    is_op_impl_version_mismatch: bool
    is_other_mismatch: bool
    unmatch_reasons: Optional[List[str]]
    bumped_ops_and_preprocessed_version: Optional[
        List[Tuple[str, int]]
    ]  # a tuple of (op_type, op_impl_version for the preprocessed op)


def workflow_configs_targets_match(
    first: WorkflowConfig,
    second: WorkflowConfig,
    first_terminal_op_id: OperatorId,
    second_terminal_op_id: OperatorId,
) -> WorkflowTargetsMatchInfo:
    """Check whether workflows dags match up to target ops, in a way agnostic to op id values."""
    # we only want to know if mismatch is purely from op_impl_version mismatch or not; besides op_imple_version match, other mismatch is caused by users.
    is_op_impl_version_mismatch = False
    is_other_mismatch = False
    is_match = True
    unmatch_reasons = set()
    bumped_ops_and_preprocessed_version: List[Tuple[str, int]] = []

    if (first_terminal_op_id not in first) or (second_terminal_op_id not in second):
        unmatch_reasons.add(StaleReasons.USER_CAUSE.value)
        return WorkflowTargetsMatchInfo(
            is_match=False,
            is_other_mismatch=True,
            is_op_impl_version_mismatch=False,
            unmatch_reasons=list(unmatch_reasons),
            bumped_ops_and_preprocessed_version=bumped_ops_and_preprocessed_version,
        )
    pairs_to_check = {(first_terminal_op_id, second_terminal_op_id)}
    checked_pairs: Set[Tuple[OperatorId, OperatorId]] = set()
    while pairs_to_check:
        first_terminal_op_id, second_terminal_op_id = pairs_to_check.pop()
        first_op = first[first_terminal_op_id]
        second_op = second[second_terminal_op_id]
        if first_op.op_type == second_op.op_type == "UserDefinedOperator":
            # If user defined, only the code part is compared. The config part contains bytecodes and could be different.
            first_code = first_op.op_config.get("code", {})
            second_code = second_op.op_config.get("code", {})
            # Note that this is not a complete solution but should cover 99% of the cases b/c functions are usually passed through resources_fn.
            # If functions are passed through resources, _resources becomes non-empty. In this case, users would have to refresh the DAG (but it's not a complete failure).
            # An alternative solution is to migrate the provenance part of dim_datasources but 1. it's against our policy of not backporting a db migration
            # and 2. provenance is a snapshot that shoudln't be changed.
            if "_resources" not in first_code:
                first_code["_resources"] = {}
            if "_resources" not in second_code:
                second_code["_resources"] = {}
            op_config_mismatch = first_code != second_code
        else:
            op_config_mismatch = first_op.op_config != second_op.op_config
        if (
            first_op.op_type != second_op.op_type
            or op_config_mismatch
            or len(first_op.input_ids) != len(second_op.input_ids)
            or first_op.op_asset != second_op.op_asset
        ):
            is_other_mismatch = True
            is_match = False
            unmatch_reasons.add(StaleReasons.USER_CAUSE.value)
        if first_op.op_impl_version != second_op.op_impl_version:
            is_op_impl_version_mismatch = True
            is_match = False
            unmatch_reasons.add(
                StaleReasons.OP_IMPL_VERSION_CHANGED.value.format(first_op.op_type)
            )
            bumped_ops_and_preprocessed_version.append(
                (
                    first_op.op_type,
                    min(first_op.op_impl_version, second_op.op_impl_version),
                )
            )
        checked_pairs.add((first_terminal_op_id, second_terminal_op_id))
        for first_parent, second_parent in zip(first_op.input_ids, second_op.input_ids):
            pair = (first_parent, second_parent)
            if pair not in checked_pairs:
                pairs_to_check.add(pair)
    return WorkflowTargetsMatchInfo(
        is_match=is_match,
        is_op_impl_version_mismatch=is_op_impl_version_mismatch,
        is_other_mismatch=is_other_mismatch,
        unmatch_reasons=list(unmatch_reasons),
        bumped_ops_and_preprocessed_version=bumped_ops_and_preprocessed_version,
    )


def workflow_config_to_dag(workflow_config: WorkflowConfig) -> nx.DiGraph:
    """Construct a networkx DiGraph of operators from workflow config."""
    # Construct graph (nodes + edges) based on workflow_config
    op_ids = list(workflow_config.keys())
    G = nx.DiGraph()

    # Add operators as node attributes
    operators: List[Tuple[Any, Dict[str, Any]]] = []
    # TODO: Generalize to include all nodes with id < 0 to when workflows
    # support multiple inputs.
    if INPUT_NODE_ID in op_ids:
        op_ids.remove(INPUT_NODE_ID)
        operators.append(
            (
                INPUT_NODE_ID,
                dict(operator=None, op_config=workflow_config[INPUT_NODE_ID]),
            )
        )

    for op_id in op_ids:
        op_config = workflow_config[op_id]

        if len(op_config.input_ids) == 0:
            raise InvalidWorkflowException(
                f"Operator {op_id} must have at least 1 input."
            )

        operators.append((op_id, dict(operator=None, op_config=op_config)))
    G.add_nodes_from(operators)

    # Add edges between operators: input_op_id -> op_id
    for op_id in op_ids:
        input_op_ids = workflow_config[op_id].input_ids
        for input_op_id in input_op_ids:
            G.add_edge(input_op_id, op_id)

    # Add op_configs for nodes that were only specified via edges
    remaining_input_ids = set(G.nodes) - set(op_ids)
    for op_id in remaining_input_ids:
        G.add_node(op_id, operator=None, op_config=make_input_op_config())

    # Enforce DAG structure
    if not nx.algorithms.dag.is_directed_acyclic_graph(G):
        raise InvalidWorkflowException(
            "Specified workflow is not a DAG — make sure there are no cycles."
        )
    return G
