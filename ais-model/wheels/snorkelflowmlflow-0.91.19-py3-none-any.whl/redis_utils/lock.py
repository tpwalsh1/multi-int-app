import logging
from contextlib import contextmanager
from enum import Enum
from typing import Any, Generator, Optional

from redis import Redis
from redis_lock import Lock

from snorkelflow.utils.logging import get_logger

logger = get_logger("lock")

# The lock library has an annoying INFO-level log
get_logger("redis_lock.acquire").setLevel(logging.WARNING)


class _SnorkelRedisLock(Lock):
    def __init__(
        self,
        *args: Any,
        lock_renewal_interval_sec: Optional[float] = None,
        **kwargs: Any,
    ):
        super().__init__(*args, **kwargs)
        if lock_renewal_interval_sec is not None:
            self._lock_renewal_interval = lock_renewal_interval_sec


def redis_lock(
    redis_conn: Redis,
    name: str,
    expire_sec: int = 60,
    auto_renewal: bool = True,
    **lock_kwargs: Any,
) -> Lock:
    """Provide a Redis lock that works for most Snorkel usecases

    The lock will renew itself as long as the lock remains acquired.
    In the case of unclean restarts, the lock will expire and clean up itself after the expiration period.

    One risk is that the thread used to renew the lock doesn't renew in time. If this is a risk, increase the
    expire_sec period to something safer.

    Usage:
    Default contextmanager - blocks until lock is acquired
    with redis_lock(...):
        {do locked things here}

    nonblocking acquire:
    lock = redis_lock(...)
    acquired = lock.acquire(blocking=False)
    if acquired:
        try:
            {do locked things here}
        finally:
            lock.release()

    Time-limited acquire - Same as above, except with lock.acquire(timeout={seconds})
    """
    # The 3rd-party library sets lock renewal interval to 2/3 of expire_sec, meaning that we have
    # only one chance to renew the lock. Override so that we have 3-4.
    # Floor of min(1 sec, 2/3 expire_sec) renewal to prevent the equivalent of busy polling
    original_expire_sec = expire_sec * 2 / 3
    floor_sec = min(1, original_expire_sec)
    lock_renewal_interval_sec = max(floor_sec, expire_sec / 4)
    return _SnorkelRedisLock(
        redis_conn,
        name,
        expire=expire_sec,
        auto_renewal=auto_renewal,
        lock_renewal_interval_sec=lock_renewal_interval_sec,
        **lock_kwargs,
    )


"""
Readers-Writer (RW) Lock implementation to allow for concurrent reads of a resource while blocking
other reads/writes during a write to a resource. This is useful in cases where reads can potentially be slow,
so using RW Locks can improve performance by allowing them to occur concurrently instead of serially, while
still allowing writes to execute safely.

If rw_read_lock and rw_write_lock are used to protect the same resource, the "name" argument should be the same in both

When to use rw_read_lock:
- When you want to read a resource without modifying it

When to use rw_write_lock:
- When you want to modify a resource (e.g., edit, overwrite, delete, etc.)

Notes on priority:
- Readers can execute without waiting as long as there are no current or pending writers
- If a reader or writer is pending (either waiting for a writer to finish, or a writer is waiting for one or more readers
  to finish), all other readers and writers that come in after it also become pending.
    - Pending writers are executed (could be out of order, but they will be executed serially)
    - If readers and writers are pending, the writers are executed first, followed by the readers
    (which can execute concurrently)

Notes on lock/counter expiration:
- Redis mutexes acquired within the RW Lock implementation are unlikely to expire, as auto_renewal is set to True
  and in SnorkelRedisLock we ensure that the lock has 3-4 chances to renew itself before expiration
- The LightSwitch counters will expire if a read or write takes longer than expire_sec (set to 60 seconds by default).
    - Tests have been added to check that reads/writes don't overlap if a write takes longer than expire_sec
        - But we're not 100% sure that issues won't arise in this case,
          so it is ideal if writes are shorter than expire_sec.
    - If a write takes longer than expire_sec, there is a risk that pending reads are prioritized over pending writes.
    - If reads take longer than expire_sec, there is a risk of a read that ocurrs at the same time as a write.


Credits to https://github.com/swapnilsm/redis-rw-lock/blob/master/redis_rw_lock/__init__.py
for the RWLock class implementation - see the repo for more details
"""


class RWLockType(Enum):
    READ: str = "read"
    WRITE: str = "write"


@contextmanager
def rw_read_lock(
    redis_conn: Redis, name: str, expire_sec: int = 60, auto_renewal: bool = True
) -> Generator:
    lock = RWLock(redis_conn, name, RWLockType.READ, expire_sec, auto_renewal)
    lock.acquire()
    try:
        yield
    finally:
        lock.release()


@contextmanager
def rw_write_lock(
    redis_conn: Redis, name: str, expire_sec: int = 60, auto_renewal: bool = True
) -> Generator:
    lock = RWLock(redis_conn, name, RWLockType.WRITE, expire_sec, auto_renewal)
    lock.acquire()
    try:
        yield
    finally:
        lock.release()


class RWLock:
    def __init__(
        self,
        redis_conn: Redis,
        name: str,
        mode: RWLockType,
        expire_sec: int = 60,
        auto_renewal: bool = True,
    ):
        self.__mode = mode
        self._expire_sec = expire_sec
        self.__read_switch = _LightSwitch(
            redis_conn,
            "read_switch:{}".format(name),
            expire_sec=expire_sec,
            auto_renewal=auto_renewal,
        )
        self.__write_switch = _LightSwitch(
            redis_conn,
            "write_switch:{}".format(name),
            expire_sec=expire_sec,
            auto_renewal=auto_renewal,
        )
        self.__no_readers = redis_lock(
            redis_conn,
            "lock:no_readers:{}".format(name),
            expire_sec=expire_sec,
            auto_renewal=auto_renewal,
        )
        self.__no_writers = redis_lock(
            redis_conn,
            "lock:no_writers:{}".format(name),
            expire_sec=expire_sec,
            auto_renewal=auto_renewal,
        )
        self.__readers_queue = redis_lock(
            redis_conn,
            "lock:readers_queue:{}".format(name),
            expire_sec=expire_sec,
            auto_renewal=auto_renewal,
        )

    def __reader_acquire(self) -> None:
        self.__readers_queue.acquire()
        try:
            self.__no_readers.acquire()
            self.__read_switch.acquire(self.__no_writers)
            try:
                self.__no_readers.release()
            except Exception:
                logger.warning(
                    f"""_no_readers release failied in RW Lock reader acquire. This likely means that a write longer
                        than {self._expire_sec} seconds caused the write LightSwitch counter to expire, resulting in
                        multiple resets of the _no_readers lock"""
                )
        finally:
            self.__readers_queue.release()

    def __reader_release(self) -> None:
        self.__read_switch.release(self.__no_writers, self.__mode)

    def __writer_acquire(self) -> None:
        self.__write_switch.acquire(self.__no_readers)
        self.__no_writers.acquire()

    def __writer_release(self) -> None:
        try:
            self.__no_writers.release()
        finally:
            self.__write_switch.release(self.__no_readers, self.__mode)

    def acquire(self) -> None:
        if self.__mode == RWLockType.READ:
            return self.__reader_acquire()
        return self.__writer_acquire()

    def release(self) -> None:
        if self.__mode == RWLockType.READ:
            return self.__reader_release()
        return self.__writer_release()

    def reset(self) -> None:
        self.__read_switch.reset()
        self.__write_switch.reset()
        self.__no_readers.reset()
        self.__no_readers.reset()
        self.__readers_queue.reset()


class _LightSwitch:
    """An auxiliary "light switch"-like object. The first thread turns on the
    "switch", the last one turns it off."""

    def __init__(
        self, redis_conn: Redis, name: str, expire_sec: int, auto_renewal: bool = True
    ):
        self.__counter_name = "lock:switch:counter:{}".format(name)
        self.__expire_sec = expire_sec
        self.__redis_conn = redis_conn
        self.__redis_conn.set(self.__counter_name, 0, nx=True, ex=self.__expire_sec)
        self.__mutex = redis_lock(
            redis_conn,
            "lock:switch:{}".format(name),
            expire_sec=expire_sec,
            auto_renewal=auto_renewal,
        )

    def acquire(self, lock: Lock) -> None:
        self.__mutex.acquire()
        try:
            self.__redis_conn.incr(self.__counter_name)
            self.__redis_conn.expire(self.__counter_name, self.__expire_sec)
            counter_value = self.__redis_conn.get(self.__counter_name)
            counter_value_int = int(counter_value) if counter_value else 0
            if counter_value_int == 1:
                lock.acquire()
        finally:
            self.__mutex.release()

    def release(self, lock: Lock, mode: RWLockType) -> None:
        self.__mutex.acquire()
        try:
            counter_value = self.__redis_conn.get(self.__counter_name)
            counter_value_int = int(counter_value) if counter_value else 0
            if counter_value_int <= 0:
                logger.warning(
                    f"""Counter value {counter_value_int} is <= 0 in LightSwitch release for RW Lock type {mode.value}.
                    This is unexpected and means that a {mode.value} protected by an Readers-Writers Lock took longer than expire_sec={self.__expire_sec}
                    to complete, causing the LighSwitch counter to expire. The counter is now being set back to 0"""
                )
            new_counter_value = max(0, counter_value_int - 1)
            self.__redis_conn.set(self.__counter_name, new_counter_value)
            self.__redis_conn.expire(self.__counter_name, self.__expire_sec)
            if new_counter_value == 0:
                lock.reset()
        finally:
            self.__mutex.release()

    def reset(self) -> None:
        self.__mutex.reset()
        self.__redis_conn.set(self.__counter_name, 0)
