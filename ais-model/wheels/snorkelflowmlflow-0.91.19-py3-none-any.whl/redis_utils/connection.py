import threading
from typing import Any, Dict, Iterator, Optional

import redis

from snorkelflow.utils.logging import get_logger

logger = get_logger("redis")

_redis_host: Optional[str] = None
_redis_ssl_enabled: bool = False
_redis_password: Optional[str] = None
_redis_port: Optional[int] = None

# Arbitrarily chosen - the default behavior is to hang forever on socket connection hangs
# MUST BE greater than 420 seconds - it's what RQ uses as its default timeout for blpop()
# If it's less than 420, blpop for 420s will error out instead of returning None
_REDIS_SOCKET_TIMEOUT = 420 * 2

_REDIS_INITIALIZATION_LOCK = threading.Lock()
_GLOBAL_REDIS_CONN: Optional[redis.Redis] = None


def init_redis(
    redis_host: str,
    redis_ssl_enabled: bool = False,
    redis_password: Optional[str] = None,
    redis_port: Optional[int] = None,
) -> None:
    global _redis_host
    global _redis_ssl_enabled
    global _redis_password
    global _redis_port
    if _redis_host is not None:
        raise RuntimeError("Redis host already set")
    _redis_host = redis_host
    _redis_ssl_enabled = redis_ssl_enabled
    _redis_password = redis_password
    _redis_port = redis_port

    # Check that redis settings are actually valid
    redis_conn = _initialize_new_redis_conn()
    redis_conn.ping()


def connect_to_instance_cache() -> redis.Redis:
    return _connect_to_instance_cache()


def _connect_to_instance_cache() -> redis.Redis:
    global _GLOBAL_REDIS_CONN
    if _GLOBAL_REDIS_CONN is None:
        logger.warn("Global redis connection not initialized yet, initializing now...")
        with _REDIS_INITIALIZATION_LOCK:
            _GLOBAL_REDIS_CONN = _initialize_new_redis_conn()
    return _GLOBAL_REDIS_CONN


def get_cache_connection() -> Iterator[redis.Redis]:
    try:
        cache = connect_to_instance_cache()
        yield cache
    finally:
        pass


def _initialize_new_redis_conn() -> redis.Redis:
    # Method is mocked in tests
    if _redis_host is None:
        raise RuntimeError("Redis host not set yet")
    redis_args: Dict[str, Any] = dict(
        host=_redis_host, ssl=_redis_ssl_enabled, ssl_cert_reqs=None
    )
    if _redis_password is not None:
        redis_args["password"] = _redis_password
    if _redis_port is not None:
        redis_args["port"] = _redis_port
    return redis.Redis(
        **redis_args,
        socket_timeout=_REDIS_SOCKET_TIMEOUT,
        socket_connect_timeout=_REDIS_SOCKET_TIMEOUT,
    )
