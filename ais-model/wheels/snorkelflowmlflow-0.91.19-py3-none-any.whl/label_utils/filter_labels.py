from typing import Dict, List, Optional

import numpy as np


def filter_labels(
    label_dict: Dict[str, Optional[np.ndarray]], filter_dict: Dict[str, List[int]]
) -> Dict[str, np.ndarray]:
    """
    ***Modified version of OSS function that corrects bug related to length-1 vectors.***
    Filter out examples from arrays based on specified labels to filter.
    The most common use of this method is to remove examples whose gold label is
    unknown (marked with a -1) or examples whose predictions were abstains (also -1)
    before calculating metrics.
    NB: If an example matches the filter criteria for any label set, it will be removed
    from all label sets (so that the returned arrays are of the same size and still
    aligned).
    Parameters
    ----------
    label_dict
        A mapping from label set name to the array of labels
        The arrays in a label_dict.values() are assumed to be aligned
    filter_dict
        A mapping from label set name to the labels that should be filtered out for
        that label set
    Returns
    -------
    Dict[str, np.ndarray]
        A mapping with the same keys as label_dict but with filtered arrays as values
    Example
    -------
    >>> golds = np.array([-1, 0, 0, 1, 0])
    >>> preds = np.array([0, 0, 0, 1, -1])
    >>> filtered = filter_labels(
    ...     label_dict={"golds": golds, "preds": preds},
    ...     filter_dict={"golds": [-1], "preds": [-1]}
    ... )
    >>> filtered["golds"]
    array([0, 0, 1])
    >>> filtered["preds"]
    array([0, 0, 1])
    """

    masks = []
    for label_name, filter_values in filter_dict.items():
        label_array: Optional[np.ndarray] = label_dict.get(label_name)
        if label_array is not None:
            # _get_mask requires not-null input
            masks.append(_get_mask(label_array, filter_values))
    mask = (np.multiply(*masks) if len(masks) > 1 else masks[0]).squeeze()
    mask = mask[np.newaxis] if mask.ndim == 0 else mask

    filtered = {}
    for label_name, label_array in label_dict.items():
        filtered[label_name] = label_array[mask] if label_array is not None else None
    return filtered


def _get_mask(label_array: np.ndarray, filter_values: List[int]) -> np.ndarray:
    """Return a boolean mask marking which labels are not in filter_values.
    Parameters
    ----------
    label_array
        An array of labels
    filter_values
        A list of values that should be filtered out of the label array
    Returns
    -------
    np.ndarray
        A boolean mask indicating whether to keep (1) or filter (0) each example
    """
    mask: np.ndarray = np.ones_like(label_array).astype(bool)
    for value in filter_values:
        mask *= np.where(label_array != value, 1, 0).astype(bool)
    return mask
