import copy
import itertools
import json
import random
import sys
from collections import Counter, defaultdict, namedtuple
from typing import (
    Any,
    Callable,
    DefaultDict,
    Dict,
    Generator,
    Hashable,
    List,
    Optional,
    Set,
    Tuple,
    Union,
)

import dask.dataframe as dd
import numpy as np
import pandas as pd
import sparse

import label_spaces.common.constants as constants

try:
    import src.cpp.label_spaces.sequence as cpp_sequence

    USE_CPP_SEQ = True
except Exception:
    USE_CPP_SEQ = False
from api_utils.config import get_env_var
from api_utils.exceptions import NotSupportedException, UserInputError
from label_spaces.base import (
    GT_LABELS_COL,
    LM_PREDS_COL,
    MODEL_PREDS_COL,
    MODEL_PROBS_COL,
    AggregateScoreStrategy,
    LabelSpace,
    LabelSpaceConfig,
    LabelsType,
    LabelValidationError,
    PartialAutoMLParams,
    RawLabels,
    ThresholdHolder,
    probs_to_preds_with_threshold_flat,
)
from label_spaces.common import metrics_utils
from label_spaces.common.highlight_utils import (
    PREDICTION_CONFIDENCE_FIELD,
    PREDICTION_LABEL_FIELD,
    FilterTypesForHighlight,
    HighlightConfigFieldNames,
    HighlightVariant,
    to_rounded_percent,
    truncate_span_string,
)
from label_spaces.common.lf_utils import LFCondition
from label_spaces.common.metrics_utils import MetricsKeys
from label_spaces.common.sparse_dense_utils import onehot, sparse_any
from label_spaces.mixins import (
    HighlightMetadataMixin,
    TextDataMixin,
    TruncateSearchResponseMixin,
)
from secret_store import try_get_secret
from snorkelflow.config.constants import DEFAULT_WORKSPACE_UID
from snorkelflow.data.core import deserialize_dataframe_series
from snorkelflow.extraction.span import SpanCols
from snorkelflow.operators.operator import Operator
from snorkelflow.types.model import ModelCols
from snorkelflow.utils.dask import dask_compute
from snorkelflow.utils.datapoint import DocDatapoint, set_datapoint_uid_as_index
from snorkelflow.utils.logging import get_logger
from snorkelflow.utils.performance_profiling import PerfTimeLog

logger = get_logger("Label Space")

# NOTE: Tuple are not supported by OpenAPI generator, so use lists instead
OPENAPI_RAW_LABEL_TYPE = List[List[int]]
OPENAPI_USER_LABEL_TYPE = List[List[Union[int, str]]]

# Openapi type for /lf-vote-info endpoint
OPENAPI_LF_AGGREGATED_VOTE_TYPE = str
OPENAPI_LF_META_TYPE = List[
    List[Union[int, Dict[str, str]]]
]  # -> List[Tuple[int, int, Dict[str, str]]
OPENAPI_LF_AGGREGATED_VOTE_AND_META_TYPE = Dict[
    str, Union[OPENAPI_LF_META_TYPE, OPENAPI_LF_AGGREGATED_VOTE_TYPE]
]
OPENAPI_LF_UID_TO_LF_VOTED_INFO = Dict[str, OPENAPI_LF_AGGREGATED_VOTE_AND_META_TYPE]
OPENAPI_LF_VOTE_INFO_TYPE = List[
    List[Union[int, OPENAPI_LF_UID_TO_LF_VOTED_INFO]]
]  # -> List[Tuple[int, int, OPENAPI_LF_UID_TO_LF_VOTED_INFO]]


SIMPLE_INTERSECTION = "simple-intersection"
SPAN_RETRIEVAL_METRICS = ["span_precision", "span_recall", "span_f1"]
OVERLAP_SPAN_RETRIEVAL_METRICS = [
    "overlap_span_precision",
    "overlap_span_recall",
    "overlap_span_f1",
]
# NOTE: For backwards compatibility, using generic metric names
# TODO: Rename to text_precision, text_recall, text_f1
TEXT_RETRIEVAL_METRICS = [
    "precision",
    "recall",
    "f1",
    "precision_macro",
    "recall_macro",
    "f1_macro",
]
TOKEN_RETRIEVAL_METRICS = ["token_f1", "token_precision", "token_recall"]
SPAN_PER_CLASS_METRICS = [MetricsKeys.PER_CLASS_KEY]

NUM_SPANS_PER_BATCH = 10_000_000

HIGHLIGHT_CONFIG_KEYS = [
    HighlightConfigFieldNames.START.value,
    HighlightConfigFieldNames.END.value,
    HighlightConfigFieldNames.LABEL_INT_FIELD_NAME.value,
    HighlightConfigFieldNames.LABEL_STR_FIELD_NAME.value,
    HighlightConfigFieldNames.DESCRIPTION.value,
]

# taken from https://numpy.org/doc/stable/reference/arrays.scalars.html#numpy.int_
INT16_MAX = 32_767
INT32_MAX = 2_147_483_647


# Alternative python implementation if cpp implementation is not available.
def py_raw_labels_to_sparse_token_labels(
    labels: dict, tokenized_documents: dict
) -> dict:
    token_labels = {}
    for x_uid, raw_label in labels.items():
        if (
            raw_label == SequenceLabelSpace.get_raw_unknown_label()
            or x_uid not in tokenized_documents
        ):
            continue
        tokens = tokenized_documents[x_uid]
        if len(tokens) == 0:
            continue

        # need this to handle span ends with sys.max_size
        last_token_index = tokens[-1][1]

        # Compare token ends with span starts and token starts with span ends
        # using np.searchsorted to find where can we insert span start in
        # token end array and span end in token start array
        # and add span label for all tokens that fall in between these inserts
        # For example, if tokens are [0, 5], [5, 10], [11, 15], [15, 20]
        # and spans are [3, 7, 1], [16, 18, 0]
        # We find inserts for [3, 16] in [4, 9, 14, 19] which will be [0, 3]
        # then find inserts for [7, 18] in [0, 5, 11, 15] which will be [2, 4]
        # So now we assign label 1 for tokens between indices [0, 2](2 excluded)
        # ie., assign label 1 to [0, 5] [5, 10]
        # next assign label 0 to token between indices [3, 4] (4 excluded).
        # ie., token [15, 20] gets label 0
        # Read about np.searchsorted for further understanding on insert positions
        span_start_search_indexes = np.searchsorted(
            np.array([token[1] - 1 for token in tokens]),
            np.array([span[0] for span in raw_label]),
            side="left",
        )
        span_end_search_indexes = np.searchsorted(
            np.array([token[0] for token in tokens]),
            np.array(
                [
                    span[1] - 1
                    if span[1] != sys.maxsize and span[1] != -1
                    else last_token_index - 1
                    for span in raw_label
                ]
            ),
            side="right",
        )
        for idx, span in enumerate(raw_label):
            for token_index in range(
                span_start_search_indexes[idx], span_end_search_indexes[idx]
            ):
                token_uid = f"{x_uid}_{token_index}"
                if token_uid not in token_labels:
                    token_labels[token_uid] = span[2]
    return token_labels


def _safe_raw_labels_to_sparse_token_labels(
    labels: dict, tokenized_documents: dict
) -> dict:
    if USE_CPP_SEQ:
        return cpp_sequence.raw_labels_to_sparse_token_labels(
            labels, tokenized_documents
        )
    else:
        return py_raw_labels_to_sparse_token_labels(labels, tokenized_documents)


def max_sequence(sequence: List[Tuple]) -> float:
    return max([val for _, _, val in sequence])


def sum_sequence(sequence: List[Tuple]) -> float:
    return sum([val for _, _, val in sequence])


def average_sequence(sequence: List[Tuple]) -> float:
    if len(sequence) == 0:
        return 0.0
    return sum_sequence(sequence) / len(sequence)


def merge_spans(spans: List[Tuple[int, int]]) -> List[Tuple[int, int]]:
    """Sort and serge a list of spans (char_start, char_end) or (char_start, char_end, label)."""
    sorted_spans = sorted(spans, key=lambda x: x[0])
    merged: List[List[int]] = []
    for start, end in sorted_spans:
        if merged and merged[-1][1] >= start:
            merged[-1][1] = max(merged[-1][1], end)
        else:
            merged.append([start, end])
    return [(span[0], span[1]) for span in merged]


def and_two_span_lists(
    spans1: Union[List[Tuple[int, int]], List[Tuple[int, int, int]], List[List[int]]],
    spans2: Union[List[Tuple[int, int]], List[Tuple[int, int, int]], List[List[int]]],
    merge_intersects: bool = True,
    include_indices: bool = False,
) -> List[Any]:
    # based on https://stackoverflow.com/questions/40367461/intersection-of-two-lists-of-ranges-in-python/40368603
    if merge_intersects and include_indices:
        raise ValueError(
            "Can't merge_intersects and also include_indices because merged intersects could have more than 2 input spans contributing to them"
        )
    intersects = []
    i = j = 0
    while i < len(spans1) and j < len(spans2):
        s1_start, s1_end = spans1[i][0], spans1[i][1]
        s2_start, s2_end = spans2[j][0], spans2[j][1]
        if s1_end >= s2_start and s2_end >= s1_start:
            end_pts = sorted([s1_start, s1_end, s2_start, s2_end])
            if end_pts[1] < end_pts[2]:
                if include_indices:
                    # add indices of spans that have contribued to the intersection
                    # as third element in intersect
                    intersects.append((end_pts[1], end_pts[2], (i, j)))  # type: ignore
                else:
                    intersects.append((end_pts[1], end_pts[2]))  # type: ignore
        if s1_end < s2_end:
            i += 1
        else:
            j += 1
    if merge_intersects:
        # merge intersect spans that are directly next to each other
        k = 0
        while k < len(intersects) - 1:
            if intersects[k][1] == intersects[k + 1][0]:
                intersects[k : k + 2] = [(intersects[k][0], intersects[k + 1][1])]  # type: ignore
            else:
                k += 1
    return intersects


def compute_and_numbers(
    golds: np.ndarray, preds: np.ndarray, label_int_gold: int, label_int_pred: int
) -> int:
    num = 0
    for spans1, spans2 in zip(golds, preds):
        filter_spans1 = [
            (span[0], span[1]) for span in spans1 if span[2] == label_int_gold
        ]
        filter_spans2 = [
            (span[0], span[1]) for span in spans2 if span[2] == label_int_pred
        ]
        num += len(
            and_two_span_lists(filter_spans1, filter_spans2, merge_intersects=False)
        )
    return num


def _find_partial_correct_prediction_exact_match(
    data_doc: List[List[int]],
    gt_doc: List[List[int]],
    raw_negative_int: int,
    raw_unknown_int: int,
) -> List[Tuple[int, int]]:
    res: List[Tuple[int, int]] = []
    # keep positive pred only
    data_doc = [
        pred
        for pred in data_doc
        if pred[2] != raw_unknown_int and pred[2] != raw_negative_int
    ]
    intersects = and_two_span_lists(
        gt_doc, data_doc, merge_intersects=False, include_indices=True
    )
    for _, _, (gt_idx, pred_idx) in intersects:
        if res and res[-1] == tuple(data_doc[pred_idx][:2]):  # de-duplicate
            continue
        gt_char_offset = (gt_doc[gt_idx][0], gt_doc[gt_idx][1])
        pred_char_offset = (data_doc[pred_idx][0], data_doc[pred_idx][1])
        # if boundary is not exact match, and label is correct -> partially correct
        if (
            gt_char_offset != pred_char_offset
            and gt_doc[gt_idx][2] == data_doc[pred_idx][2]
        ):
            res.append(pred_char_offset)
    return res


def _find_correct_prediction_exact_match(
    data_doc: List[List[int]],
    gt_doc: List[List[int]],
    raw_negative_int: int,
    raw_unknown_int: int = -1,
    class_int: Optional[int] = None,
) -> List[Tuple[int, int]]:
    # only return true positives as users do not care about true negatives in model/TS prediction
    # for LF, however, true negatives are useful feedback
    res = []
    pos_ground_truth = {
        tuple(gt_span)
        for gt_span in gt_doc
        if gt_span[2] != raw_negative_int
        and (class_int is None or gt_span[2] == class_int)
    }
    for pred_span in data_doc:
        k = tuple(pred_span)
        if k in pos_ground_truth:
            res.append((pred_span[0], pred_span[1]))
    return res


def _find_incorrect_prediction_exact_match(
    data_doc: List[List[int]],
    gt_doc: List[List[int]],
    raw_negative_int: int,
    raw_unknown_int: int,
    class_int: Optional[int] = None,
) -> List[Tuple[int, int]]:
    pos_pred = [
        (pred[0], pred[1], pred[2])
        for pred in data_doc
        if pred[2] != raw_negative_int
        and pred[2] != raw_unknown_int
        and (class_int is None or pred[2] == class_int)
    ]
    pos_gt = [
        (gt[0], gt[1], gt[2])
        for gt in gt_doc
        if gt[2] != raw_negative_int and (class_int is None or gt[2] == class_int)
    ]

    pos_gt_set = set(pos_gt)
    pos_pred_set = set(pos_pred)

    # explict remove any GT span that only overlaps with unknown pred span -> they are not incorrect
    unknown_or_negative_pred = [
        (pred[0], pred[1], pred[2])
        for pred in data_doc
        if pred[2] == raw_unknown_int or pred[2] == raw_negative_int
    ]
    intersects = and_two_span_lists(
        pos_gt, unknown_or_negative_pred, merge_intersects=False, include_indices=True
    )
    gt_idx_to_pred_idx_map = defaultdict(list)

    for _, _, (gt_idx, pred_idx) in intersects:
        gt_idx_to_pred_idx_map[gt_idx].append(pred_idx)
    for gt_idx, pred_idx_list in gt_idx_to_pred_idx_map.items():
        pred_labels = set(
            [unknown_or_negative_pred[pred_idx][2] for pred_idx in pred_idx_list]
        )
        # if all pred labels are unknown, then remove this GT span
        # if pos GT overlap with both negative and unknown, mark as incorrect, so do not discard it
        if len(pred_labels) == 1 and raw_unknown_int in pred_labels:
            pos_gt_set.discard(pos_gt[gt_idx])

    false_positives = pos_pred_set.difference(pos_gt_set)
    false_negatives = pos_gt_set.difference(pos_pred_set)
    spans = list(false_negatives) + list(false_positives)
    return merge_spans([(span[0], span[1]) for span in spans])


def _get_correct_incorrect_unknown_spans(
    golds: List[List[int]],
    preds: List[List[int]],
    raw_negative_int: int,
    raw_unknown_int: int,
    class_int: Optional[int] = None,
) -> Tuple[List[Tuple[int, int]], List[Tuple[int, int]], List[Tuple[int, int]]]:
    """given golds and preds, return 3 lists of tuples (char_offsets): correct preds, incorrect preds, and unknown preds

    Parameters
    ----------
    golds : int or List[List[int]]: list of spans, where span is form of [char_start, char_end, label]
        when golds == [] , entire doc is unknown and return empty lists
    preds : int or List[List[int]]: list of spans, where span is form of [char_start, char_end, label]
        when preds == [] , entire doc is not predicted, return empty lists as there are no spans at all
    raw_unknown_int : int
    """
    correct_preds: List[Tuple[int, int]] = []
    incorrect_preds: List[Tuple[int, int]] = []
    unknown_preds: List[Tuple[int, int]] = []
    if not golds or not preds:
        # if gold is empty, we could not score preds as correct or incorrect
        # if preds is empty, return empty lists as well
        return correct_preds, incorrect_preds, unknown_preds

    correct_preds = _find_correct_prediction_exact_match(
        preds, golds, raw_negative_int, class_int=class_int
    )
    incorrect_preds = _find_incorrect_prediction_exact_match(
        preds, golds, raw_negative_int, raw_unknown_int, class_int
    )
    unknown_preds = [(pred[0], pred[1]) for pred in preds if pred[2] == raw_unknown_int]

    return correct_preds, incorrect_preds, unknown_preds


def confusion_matrix(
    golds: np.ndarray, preds: np.ndarray, labels: List[int]
) -> np.ndarray:
    matrix = np.zeros([len(labels), len(labels)])
    for label_int_i, label_int_j in itertools.product(labels, labels):
        matrix[label_int_i][label_int_j] = compute_and_numbers(
            golds, preds, label_int_i, label_int_j
        )
    return matrix


# lf_spans: [[char_start, char_end, label], []....]
# gt_spans: [[char_start, char_end, label], []....]
def get_num_lf_span_errors(lf_spans: List[List[int]], sort_gt: List[List[int]]) -> int:
    sort_lf = sorted(lf_spans)
    lf_p, gt_p = 0, 0
    correct = 0
    """
    Case 1: If LF span_start < GT span_start, there is no hope for this LF. move to next LF
    Case 2: If LF span_start < GT span_end, but LF span_end > GT span_end, then
        potentially there is another LF span that can fit, since the sorting is done by the
        first index. Move to next LF span
    Case 3: If LF span_start >= GT span_end, then we have to look at the next GT span.
    Case 4: If the labels don't match, look at the next LF span
    Case 5: If everything matches, increment the correct count and look at the next LF span
    """
    while lf_p < len(sort_lf) and gt_p < len(sort_gt):
        if sort_lf[lf_p][0] < sort_gt[gt_p][0]:
            lf_p += 1
        elif (
            sort_lf[lf_p][0] < sort_gt[gt_p][1] and sort_lf[lf_p][1] > sort_gt[gt_p][1]
        ):
            lf_p += 1
        elif (
            sort_lf[lf_p][0] >= sort_gt[gt_p][1] and sort_lf[lf_p][1] > sort_gt[gt_p][1]
        ):
            gt_p += 1
        elif sort_lf[lf_p][2] != sort_gt[gt_p][2]:
            lf_p += 1
        else:
            lf_p += 1
            correct += 1

    return len(lf_spans) - correct


def is_overlapping(s1: int, e1: int, s2: int, e2: int) -> bool:
    """Checks if two spans overlap"""
    return max(s1, s2) <= min(e1, e2)


def get_span_intersection_and_union(
    span1_start: int, span1_end: int, span2_start: int, span2_end: int
) -> Tuple[int, int]:
    """Gets the intersection of two spans and their union as measured by number of characters"""
    # candidate span is within GT span offsets
    if span1_start <= span2_start and span1_end >= span2_end:
        intersection = span2_end - span2_start

    # GT span is within candidate span offsets
    elif span2_start <= span1_start and span2_end >= span1_end:
        intersection = span1_end - span1_start

    # candidate span offsets extend beyond GT span
    elif span1_start <= span2_start <= span1_end:
        intersection = span1_end - span2_start

    # GT span offsets extend beyond candidate span
    elif span2_start <= span1_start <= span2_end:
        intersection = span2_end - span1_start

    union = max(span1_end, span2_end) - min(span1_start, span2_start)

    return intersection, union


class SequenceLabelSpace(
    HighlightMetadataMixin, TextDataMixin, TruncateSearchResponseMixin, LabelSpace
):
    """Manages labels and metrics for sequence tagging.

    Each label for an x_uid is a list of triples (char_start, char_end, label), where
    char_start is inclusive and char_end is exclusive.
    """

    _is_unknown_in_label_map = True
    _filter_correctness_options_no_unk = [
        constants.CORRECT,
        constants.PARTIALLY_CORRECT,
        constants.INCORRECT,
    ]
    # TODO (ENG-13307): Right now supporting these basic options,
    # but add more combinations of them with unknown
    # in the future
    _filter_correctness_options_with_unk = [
        constants.CORRECT,
        constants.PARTIALLY_CORRECT,
        constants.INCORRECT,
    ]
    annotation_metric: str = "span_f1"  # Overwrite the LabelSpace class variable
    default_aggregation_strategy = SIMPLE_INTERSECTION
    supported_aggregation_strategies = [SIMPLE_INTERSECTION]
    studio_disabled_filters = {"lf_conflict", "annotation", "annotator_agreement"}
    lf_filter_aggregate_options = [constants.THIS_LF_OPTION]
    disable_multiple_model_ts_lf_filters = True
    is_multi_label = False

    def __init__(
        self,
        label_map: Dict[str, int],
        field: str,
        tokens_field: Optional[str] = None,
        label_descriptions: Optional[Dict[str, str]] = None,
    ) -> None:
        super().__init__(label_map, label_descriptions)
        self.field = field
        self.tokens_field = tokens_field
        self.label_map_raw_negative_label = 0

    @property
    def text_col(self) -> str:
        return self.field

    @property
    def max_total_dataset_size(self) -> int:
        return self._get_guardrail_override(
            "MAX_SEQUENCE_DATASET_SIZE", 250_000_000
        )  # 250 MB

    @property
    def max_LF_count_override(self) -> int:
        # TODO : When engine LF apply is fixed to handle large LFs (ENG-15875)
        # and when training set creation is fixed to be memory bounded, (ENG-15876)
        # remove/upgrade this guardrail
        return self._get_guardrail_override("MAX_SEQUENCE_LFS", 200)

    @property
    def max_label_class_count(self) -> int:
        return self._get_guardrail_override("MAX_SEQUENCE_POSITIVE_LABELS", 25)

    @property
    def max_studio_dataset_size(self) -> int:
        return self._get_guardrail_override(
            "MAX_DEV_SIZE_SEQUENCE_TAGGING_IN_KB", 15000
        )  # 5 MB

    def _get_guardrail_override(self, env_var: str, default_value: int) -> int:
        # TODO : ENG-16518 Use a PlatformConfig override instead of secret store
        return int(
            get_env_var(env_var)
            or try_get_secret("local_store", {}, DEFAULT_WORKSPACE_UID, env_var)
            or default_value
        )

    def _get_default_raw_negative_prob(self) -> List[float]:
        """
        Default prob for filling abstain with negative, the prob is uniform across all label classes
        """
        probs: List[float]
        valid_labels = set(self.label_map.values())
        # Unknown spans should not be included in raw labels saved to DB
        valid_labels.remove(self.raw_unknown_int)
        probs = [0.0] * len(valid_labels)
        if len(probs) > 1:
            probs[0] = 1.0
        return probs

    def config(self) -> LabelSpaceConfig:
        return LabelSpaceConfig(
            cls_name=self.__class__.__name__,
            kwargs=dict(
                label_map=self.label_map,
                field=self.field,
                tokens_field=self.tokens_field,
                label_descriptions=self._label_descriptions,
            ),
        )

    def compress_labels_for_model_training(
        self, raw_labels: List[List[List[int]]]
    ) -> List[np.ndarray]:
        # compress the int labels into numpy arrays with potentially lower precision.
        # each element in raw_labels is a list of spans
        # each span is a list of integer with length of 3 [char_start, char_end, label]
        # for a document with length of 2^16, the size of text is 64 KB.
        # for a document with length of 2^32, the size of text is 4 GB.
        res = []
        for doc_spans in raw_labels:
            max_val = np.max(doc_spans)
            if max_val <= INT16_MAX:
                res.append(np.array(doc_spans).astype("int16"))
            elif max_val <= INT32_MAX:
                res.append(np.array(doc_spans).astype("int32"))
            else:
                res.append(np.array(doc_spans))
        return res

    def get_batch_size_for_loading_training_probs(self, num_x_uids: int) -> int:
        return 50_000 // self.cardinality

    @staticmethod
    def get_raw_unknown_label() -> Any:
        return None

    @staticmethod
    def get_raw_dummy_label() -> Any:
        # This happens to work properly for the compute-search-metrics endpoint, but it's not clear if `0` is really a valid label for SequenceLabelSpace.
        # Slack discussion: https://snorkel-team.slack.com/archives/C024MLQUP1P/p1668713317399589?thread_ts=1668709195.319739&cid=C024MLQUP1P
        return 0

    @classmethod
    def raw_label_type(cls) -> type:
        return List[List[int]]

    @classmethod
    def user_label_type(cls) -> type:
        return List[List[Union[int, str]]]

    def get_data_size_to_safeguard(self, df: pd.DataFrame) -> int:
        return df[self.text_col].str.len().sum()

    def get_label_model_list(
        self,
        label_model_list: List[Any],
        sample_df: pd.DataFrame,
        num_train_rows: int,
        num_lfs: int,
    ) -> List[Dict[str, Any]]:
        avg_num_tokens = sample_df[self.tokens_field].map(len).mean()
        # If total number of tokens * num of LFs > 1B, use majority vote
        if num_train_rows * avg_num_tokens * num_lfs > 1_000_000_000:
            return [{"label_model_name": "MajorityVoteLabelModel"}]
        return label_model_list

    def validate_raw_labels(self, raw_labels: RawLabels) -> None:
        # validate raw labels
        # if raw labels is unknown, delte the entry in-place
        valid_labels = set(self.label_map.values())
        # Unknown spans should not be included in raw labels saved to DB
        valid_labels.remove(self.raw_unknown_int)
        to_remove_x_uids = set()
        for x_uid, label in raw_labels.labels.items():
            # Validate label
            raw_labels.labels[x_uid] = self._validate_label(label, valid_labels, x_uid)
            if raw_labels.labels[x_uid] == self.get_raw_unknown_label():
                to_remove_x_uids.add(x_uid)

            if not getattr(raw_labels, "probs"):
                continue
            probs = raw_labels.probs[x_uid]  # type: ignore
            if type(probs) is not list:
                self._raise_error_incorrect_probs_format(x_uid, probs)
            if len(probs) != len(label):
                self._raise_error_incorrect_probs_format(x_uid, probs)
            for label_span, probs_span in zip(label, probs):
                if type(probs_span) is not list or len(probs_span) != 3:
                    self._raise_error_incorrect_probs_format(x_uid, probs)
                probs_char_start, probs_char_end, class_probs = probs_span
                if (
                    type(probs_char_start) is not int
                    or type(probs_char_end) is not int
                    or type(class_probs) is not dict
                    or any(
                        [
                            int(class_key) not in valid_labels
                            for class_key in class_probs.keys()
                        ]
                    )
                ):
                    self._raise_error_incorrect_probs_format(x_uid, probs)

                label_char_start, label_char_end, _ = label_span
                if (
                    label_char_start != probs_char_start
                    or label_char_end != probs_char_end
                ):
                    raise LabelValidationError(
                        f"Probs spans {probs} for x_uid {x_uid} doesn't match with labels spans {label}"
                    )
        for x in to_remove_x_uids:
            raw_labels.labels.pop(x)

    def _validate_label(
        self, label: Any, valid_labels: Set[Any], x_uid: Optional[str] = None
    ) -> Any:
        # return label if valid, otherwise raise error
        if type(label) is not list:
            raise LabelValidationError(
                f"Label {label} for x_uid {x_uid} is incorrectly formatted:"
                f" type of label should be a list, got {type(label)} instead"
            )

        if len(label) == 0:
            # Raw labels should only include docs with at least one non-unknown span
            # update to raw unknown label
            return None

        prev_span_char_end = -1
        for span in label:
            if type(span) not in [list, tuple] or len(span) != 3:
                raise LabelValidationError(
                    f"Label {label} for x_uid {x_uid} is incorrectly formatted:"
                    f" {span} should be a triple of (char_start, char_end, label)"
                )

            char_start, char_end, span_class = span
            if type(char_start) is not int or type(char_end) is not int:
                raise LabelValidationError(
                    f"Label {label} for x_uid {x_uid} is incorrectly formatted:"
                    f" char-offsets in {span} should be type of integer"
                )
            if span_class not in valid_labels:
                raise LabelValidationError(
                    f"Label {label} for x_uid {x_uid} is incorrectly formatted:"
                    f"{span_class} is not a valid label, must be one of {valid_labels}"
                )

            # empty span check
            if char_end - char_start <= 0:
                raise LabelValidationError(
                    f"Label {label} for x_uid {x_uid} is incorrectly formatted:"
                    f" char_start must be smaller than char_end, got char_start={char_start} and char_end={char_end} in span {span}"
                )

            # checks for duplicate or overlapping spans
            # we expect input spans to be already sorted
            if char_start < prev_span_char_end:
                raise LabelValidationError(
                    f"Label {label} for x_uid {x_uid} is incorrectly formatted:"
                    f" {span} overlaps with previous spans, please sort input spans by char-offsets and/or de-duplicate spans"
                )
            prev_span_char_end = int(char_end)
        return label

    @staticmethod
    def extract_values_from_input_label(label: Any) -> List[str]:
        try:
            label = json.loads(label)
        except Exception:
            pass

        def _is_list_like(x: Any) -> bool:
            return (
                isinstance(x, list)
                or isinstance(x, tuple)
                or isinstance(x, np.ndarray)
                or isinstance(x, pd.Series)
            )

        if not _is_list_like(label):
            raise ValueError

        span_labels = []
        for span in label:
            if not _is_list_like(span) or len(span) != 3:
                raise ValueError
            _, _, span_label = span
            if type(span_label) not in [str, int, bool]:
                raise ValueError
            span_labels.append(span_label)
        return span_labels

    @staticmethod
    def example_user_input_label() -> Any:
        return [[4, 8, "CLASS_1"], [12, 16, "CLASS_2"]]

    def get_user_unknown_pred_conf(self) -> Tuple[Any, Any]:
        # NOTE: We return the empty list instead of self.get_raw_unknown_label().
        # While unknown is always self.get_raw_unknown_label() in the backend,
        # this format is easier to handle for front-end and gets around formatting issues with
        # using the None value in self.get_raw_unknown_label() for FastAPI JSON encoding.
        return [], []

    def copy_with_label_map(self, label_map: Dict[str, int]) -> "SequenceLabelSpace":
        if self.raw_unknown_int not in label_map.values():
            label_map = {"UNKNOWN": self.raw_unknown_int, **label_map}
        label_descriptions = {
            k: v for k, v in self.label_descriptions.items() if k in label_map
        }
        return self.__class__(
            label_map=label_map,
            field=self.field,
            tokens_field=self.tokens_field,
            label_descriptions=label_descriptions,
        )

    def raw_probs_to_array_probs(self, raw_probs: List[Any]) -> List[Any]:
        try:
            # new format for probs is array, early check to avoid unnecessary computation
            if (
                raw_probs
                and raw_probs[0]
                and raw_probs[0][0]
                and len(raw_probs[0][0]) == 3
                and type(raw_probs[0][0][2]) is not dict
            ):
                return raw_probs
        except (TypeError, KeyError, IndexError):
            pass
        probs = []
        for raw_prob in raw_probs:
            if raw_prob:
                tmp = list(zip(*raw_prob))
                probs.append(
                    list(
                        zip(
                            tmp[0],
                            tmp[1],
                            [
                                self.prob_dict_to_prob_array(probs_dict)
                                for probs_dict in tmp[2]
                            ],
                        )
                    )
                )
            else:
                probs.append([])
        return probs

    def raw_probs_to_enumerate_array_probs(
        self, raw_probs: List[Any], **kwargs: Dict[str, Any]
    ) -> List[List[float]]:
        preds_probs_array_w_chars = self.raw_probs_to_array_probs(raw_probs)
        return [
            *[
                probs_array
                for preds in preds_probs_array_w_chars
                for _, _, probs_array in preds
            ]
        ]

    def aggregate_prediction_scores(
        self, scores: List[Any], aggregation: AggregateScoreStrategy
    ) -> List[Any]:
        aggregates = []
        aggregate_f_dict = {
            AggregateScoreStrategy.average: average_sequence,
            AggregateScoreStrategy.max: max_sequence,
            AggregateScoreStrategy.sum: sum_sequence,
            AggregateScoreStrategy.none: lambda x: x,
        }
        if aggregation not in aggregate_f_dict:
            raise NotImplementedError(
                f"No implementation for sequences for aggregation {aggregation}"
            )
        aggregate_f = aggregate_f_dict[aggregation]
        for seq in scores:
            aggregates.append(aggregate_f(seq))

        return aggregates

    def raw_probs_to_confidences(self, raw_probs: List[Any]) -> List[Any]:
        confidences: List[Any] = []
        for raw_prob in raw_probs:
            if not raw_prob:
                confidences.append([])
            else:
                tmp = list(zip(*raw_prob))
                confidences.append(
                    list(
                        zip(
                            tmp[0],
                            tmp[1],
                            [max(list(probs_dict.values())) for probs_dict in tmp[2]],
                        )
                    )
                )
        return confidences

    def raw_probs_to_entropies(self, raw_probs: List[Any]) -> List[Any]:
        return [
            [
                [char_start, char_end, self.probs_dict_to_entropy(probs_dict)]
                for char_start, char_end, probs_dict in prob
            ]
            for prob in raw_probs
        ]

    def array_probs_to_raw_probs(self, array_probs: List[Any]) -> List[Dict]:
        return [
            self.get_raw_unknown_label()
            if pred == self.get_raw_unknown_label()
            else [
                [p[0], p[1], self._prob_arrays_to_prob_dicts(p[2], self.cardinality)]  # type: ignore
                for p in pred
            ]
            for pred in array_probs
        ]

    def raw_labels_from_raw_probs(self, raw_probs: List[Any]) -> List[Any]:
        return [
            [[p[0], p[1], self._probs_dict_to_predicted_label(p[2])] for p in pred]
            for pred in raw_probs
        ]

    def raw_probs_from_raw_labels(self, raw_labels: List[Any]) -> List[Any]:
        return [
            [[p[0], p[1], self._get_default_predicted_probs(p[2])] for p in pred]
            for pred in raw_labels
        ]

    def get_max_df_batch_size(self, sample_df: pd.DataFrame, num_lf_uids: int) -> int:
        avg_num_tokens = sample_df[self.tokens_field].map(len).mean()
        # tokens_per_doc * num_docs * num_lfs should be less than 500M
        return int(500_000_000 // (1 + num_lf_uids * avg_num_tokens))

    def _postprocess_label(
        self,
        pred: Any,
        prob: Optional[Any] = None,
        raw_negative_int: int = 0,
        negative_labels_only: Optional[bool] = False,
    ) -> Tuple[Any, Optional[Any]]:
        # For non-negaitve spans, merge adjacent spans with same label if negative_labels_only = False
        # For negative spans:
        # (1) merge near-by negative spans
        # (2) the char_start should be the previous non-negative spans'end (if applicable)
        # (3) char_end should be the next non-negative span's start (if applicable)
        prev_end = 0
        # dummy label and prob so no need to check if new_label is empty
        new_label: List[Any] = [(0, 0, sys.maxsize)]
        new_prob: List[Any] = [(0, 0, sys.maxsize)]
        prev_label = new_label[-1][2]
        return_prob = prob is not None
        # create fake prob to avoid multiple checks of prob
        prob = pred if prob is None else prob
        for span_pred, span_prob in zip(pred, prob):
            start, end, class_label = span_pred
            is_negative_label = class_label == raw_negative_int
            if class_label == prev_label and (
                not negative_labels_only or is_negative_label
            ):  # if both current label and previous label are negative, merge them
                new_label[-1] = (new_label[-1][0], end, new_label[-1][2])
                new_prob[-1] = (new_prob[-1][0], end, new_prob[-1][2])

            else:
                if is_negative_label:
                    # when add new negative label, update the span start to be end of prev span
                    new_label.append((prev_end, end, class_label))
                    new_prob.append((prev_end, end, span_prob[2]))
                else:
                    if new_label[-1][2] == raw_negative_int:
                        # if prev span is negative, update negative span's end to be current span's start
                        new_label[-1] = (new_label[-1][0], start, new_label[-1][2])
                        new_prob[-1] = (new_prob[-1][0], start, new_prob[-1][2])
                    # when add new non-negative labels, do not touch its char-offsets
                    new_label.append(tuple(span_pred))
                    new_prob.append(tuple(span_prob))
            prev_end = end
            prev_label = class_label
        return new_label[1:], new_prob[1:] if return_prob else None

    def _postprocess_labels(
        self,
        preds: Union[np.ndarray, List[Any]],
        probs: Optional[Union[np.ndarray, List[Any]]] = None,
        negative_labels_only: Optional[bool] = False,
    ) -> Tuple[List, Optional[List]]:
        # For non-negaitve spans, merge adjacent spans with same label if negative_labels_only = False
        # For negative spans:
        # (1) merge near-by negative spans
        # (2) the char_start should be the previous non-negative spans'end (if applicable)
        # (3) char_end should be the next non-negative span's start (if applicable)
        # for x_uid, label in preds.items():
        new_preds, new_probs = (
            np.empty(len(preds), dtype=object),
            np.empty(len(probs) if probs is not None else len(preds), dtype=object),
        )
        for i in range(len(preds)):
            new_pred, new_prob = self._postprocess_label(
                preds[i],
                probs[i] if probs is not None else None,
                self.label_map_raw_negative_label,
                negative_labels_only,
            )
            new_preds[i] = new_pred
            new_probs[i] = new_prob
        if isinstance(preds, list):  # keep input/ouput type same
            return new_preds.tolist(), new_probs.tolist() if probs is not None else None
        return new_preds, new_probs if probs is not None else None

    def postprocess_negative_raw_labels(self, prediction: RawLabels) -> RawLabels:
        pred_x_uids = list(prediction.labels.keys())
        pred_labels = list(prediction.labels.values())
        if prediction.probs:
            pred_probs = list(prediction.probs.values())
        else:
            pred_probs = None
        (
            postprocessed_pred_labels,
            postprocessed_pred_probs,
        ) = self._postprocess_labels(pred_labels, pred_probs, negative_labels_only=True)
        raw_preds = {
            x_uid: pred for x_uid, pred in zip(pred_x_uids, postprocessed_pred_labels)
        }
        raw_probs = (
            {x_uid: prob for x_uid, prob in zip(pred_x_uids, postprocessed_pred_probs)}
            if postprocessed_pred_probs is not None
            else None
        )

        return RawLabels(raw_preds, raw_probs)

    def get_compute_lf_metrics_required_columns(self) -> List[str]:
        """Returns the list of data frame columns required to compute the given metrics"""
        if self.field is None:
            err_msg = f"Cannot compute lf metrics without field: {self.field}."
            raise UserInputError(user_friendly_message=err_msg, detail=err_msg)
        return [self.field]

    def get_compute_lm_required_columns(self) -> List[str]:
        """Returns the list of data frame columns required to compute the label model"""
        if (
            self.tokens_field is None
        ):  # label_model still needs tokens_field, will remove once update them to char level
            err_msg = f"Cannot compute label model or label model related stats without tokens field: {self.field}."
            raise UserInputError(user_friendly_message=err_msg, detail=err_msg)
        return [self.tokens_field]

    @staticmethod
    def _truncate_out_of_boundary_span_labels(
        raw_label: RawLabels, documents_length: Dict[str, int]
    ) -> RawLabels:
        raw_labels: Dict[str, Any] = {}
        for x_uid, span_labels in raw_label.labels.items():
            if not span_labels:
                raw_labels[x_uid] = span_labels
                continue
            document_length = documents_length[x_uid]
            adapted_span_labels = []
            for span_label in span_labels:
                char_start, char_end, label = span_label
                # Truncate out of boundary spans to length of document
                char_end = min(char_end, document_length)
                if char_start >= char_end:  # skip empty spans
                    continue
                adapted_span_labels.append([char_start, char_end, label])
            raw_labels[x_uid] = adapted_span_labels
        return RawLabels(raw_labels)

    def _get_span_boundaries_and_weights(
        self,
        x_uids: List[str],
        labels_list: List[LabelsType],
        documents_length: Dict[str, int],
    ) -> Tuple[List, List]:
        span_intervals, span_interval_weights = [], []
        for x_uid in x_uids:
            cur_doc_length = documents_length[x_uid]
            boundary_points = set()
            # add start and end of doc
            boundary_points.add(0)
            boundary_points.add(cur_doc_length)

            for labels in labels_list:
                spans = labels.get(x_uid, []) or []
                for span in spans:
                    # truncate out-of-boundary spans
                    if span[0] not in boundary_points and span[0] <= cur_doc_length:
                        boundary_points.add(span[0])
                    if span[1] not in boundary_points and span[1] <= cur_doc_length:
                        boundary_points.add(span[1])

            # mypy does not like sort set
            boundary_points = sorted(boundary_points)  # type: ignore
            span_intervals.append(boundary_points)
            span_interval_weights.append(
                [
                    boundary_points[i + 1]  # type: ignore
                    - boundary_points[i]  # type: ignore
                    for i in range(len(boundary_points) - 1)
                ]
            )
        return span_intervals, span_interval_weights

    def _map_labels_to_span_interval_labels(
        self,
        x_uids: List[str],
        labels: LabelsType,
        all_span_boundaries: List[List],
        sort: bool = True,  # sort labels or not? Only GT labels are validated to be sorted
    ) -> np.ndarray:
        """
        all_span_boundaries: a list of list of distinct boundary points, same length as x_uids

         (1) Map labels onto the span inverals (two consective boundary points) defined in all_span_boundaries
         (2) return an array of integer labels

        Example:
        input:
        x_uids = ["doc::0","doc::1"]
        labels = {
           "doc::0" : [[0,10,1]]}
           "doc::1" : None
        }
        all_span_boundaries = [
           [0,5,10] # "doc::0" : span_intervals = [[0, 5], [5, 10]]
           [0,10] # "doc::1" : span_intevals = [[0, 10]]
        ]

        return:
        labels_array = [
          1,  # doc::0, [0, 5]
          1,  # doc::0, [5,10]
          -1, # doc::1, [0,10]
        ]
        """

        labels_array = []
        raw_unknown_int = self.raw_unknown_int
        for i_xuid, x_uid in enumerate(x_uids):
            span_boundaries = all_span_boundaries[i_xuid]
            if not span_boundaries:
                continue
            if x_uid not in labels or not labels[x_uid]:  # labels[x_uid] could be None
                labels_array += [raw_unknown_int] * (len(span_boundaries) - 1)
                continue

            label = labels[x_uid]

            sorted_spans = sorted(label, key=lambda span: span[0]) if sort else label

            # Add a dummy span at the end so the while loop below terminates without going out of bounds.
            sorted_spans = (*sorted_spans, (sys.maxsize, sys.maxsize, raw_unknown_int))

            cur_span_idx = 0
            for idx, base_span_start in enumerate(span_boundaries[:-1]):
                base_span_end = span_boundaries[idx + 1]
                span_start, span_end, span_class = sorted_spans[cur_span_idx]

                while span_end <= base_span_start:
                    cur_span_idx += 1
                    span_start, span_end, span_class = sorted_spans[cur_span_idx]

                if base_span_end > span_start:
                    labels_array.append(span_class)
                else:
                    labels_array.append(raw_unknown_int)

        labels_array = np.array(labels_array)

        return labels_array

    def get_L_tuning_max_num_rows(self) -> int:
        return 10_000

    def _make_sparse_L_tensor(
        self, tokenwise_lf_votes: Dict[str, Any], token_uids: List[str], num_lfs: int
    ) -> sparse._coo.COO:
        rows = []
        lfs = []
        votes = []

        for token_ind, token_uid in enumerate(token_uids):
            if token_uid in tokenwise_lf_votes:
                rows += [token_ind] * len(tokenwise_lf_votes[token_uid]["lfs"])
                lfs += tokenwise_lf_votes[token_uid]["lfs"]
                votes += tokenwise_lf_votes[token_uid]["votes"]

        L = sparse.COO(
            coords=(rows, lfs, votes),
            data=np.uint64(1),
            shape=(len(token_uids), num_lfs, self.cardinality),
            fill_value=0,
        )
        return L

    def _compute_L(
        self,
        label_matrix: Any,  # To avoid importing LabelMatrix
        df: Optional[pd.DataFrame] = None,
        batch_size: int = sys.maxsize,
        random_seed: int = 123,
        max_num_examples: Optional[int] = None,
        x_uids_gt: Optional[Set] = None,
        compute_num_datapoints: bool = False,
    ) -> Tuple[List[str], Generator, int]:
        # TODO: Add sampling here (and in base class and single.py).
        token_uids: List[str] = []
        dense_list = label_matrix.dense(self)
        if not dense_list.size:
            return token_uids, dense_list, 0

        if df is None:
            raise ValueError("Need dataframe for SequenceLabelSpace compute L.")

        if self.tokens_field is None:
            raise ValueError(
                "Cannot compute token labels for label space without a tokens_field."
            )
        if self.tokens_field not in df.columns:
            raise ValueError(
                f"Missing tokens field {self.tokens_field} in dataframe columns: {df.columns}"
            )

        perf_time_log = PerfTimeLog("Compute L matrix for SequenceLabelSpace")

        perf_time_log.update(
            "Compute lf votes dict and raw labels for initial token uid function call"
        )

        token_uids = self.get_all_tokens(
            label_matrix.x_uids, df[self.tokens_field].to_dict()
        )

        token_uids_gt = (
            set(self.get_all_tokens(list(x_uids_gt), df[self.tokens_field].to_dict()))
            if x_uids_gt is not None
            else None
        )

        perf_time_log.update("Get token uids")

        if not token_uids:
            return (
                [],
                (y for y in [np.empty((0, len(label_matrix.lf_uids)), dtype="int16")]),
                0,
            )
        # Subsample token_uids to max_num_examples
        if max_num_examples is not None:
            if len(token_uids) > max_num_examples:
                logger.info(
                    f"Subsampling token_uids from {len(token_uids)} to {max_num_examples} rows."
                )
                samples_to_keep = self.subsample_uids(
                    token_uids, max_num_examples, random_seed, x_uids_gt=token_uids_gt
                )
                token_uids = [token_uids[i] for i in samples_to_keep]

                perf_time_log.update("Sample token uids")

        token_uids_set = set(token_uids)
        # Now compute token votes for all lfs with add_unknown_label=False
        # This way we can avoid unnecessary unknown labels before the tokenized_dense is computed
        tokenwise_lf_votes: Dict[str, Any] = {}
        num_lfs = len(label_matrix.lf_uids)

        perf_time_log.update("Initialize variables for lf votes")

        for lf_idx, _ in enumerate(label_matrix.lf_uids):
            lf_votes = dense_list[:, lf_idx].tolist()
            lf_votes_dict = dict(zip(label_matrix.x_uids, lf_votes))
            lf_votes_raw_labels = RawLabels(labels=lf_votes_dict)

            perf_time_log.update("Compute lf votes dict and raw labels")

            lf_token_votes = self.raw_labels_to_sparse_token_labels(
                lf_votes_raw_labels, df
            )

            perf_time_log.update("Convert lf raw labels to lf token votes")

            lf_token_votes = dict(
                filter(lambda elem: elem[0] in token_uids_set, lf_token_votes.items())
            )

            perf_time_log.update("Filter lf token votes on token uid set")

            for token_id, vote in lf_token_votes.items():
                if token_id not in tokenwise_lf_votes:
                    tokenwise_lf_votes[token_id] = {"votes": [], "lfs": []}

                tokenwise_lf_votes[token_id]["votes"].append(vote)
                tokenwise_lf_votes[token_id]["lfs"].append(lf_idx)

                perf_time_log.update("Update tokenwise lf votes dict")

        L_sparse_generator = (
            self._make_sparse_L_tensor(
                tokenwise_lf_votes, token_uids[i : i + batch_size], num_lfs
            )
            for i in range(0, len(token_uids), batch_size)
        )

        perf_time_log.update("Make sparse L generator")
        num_labeled_tokens = (
            len(tokenwise_lf_votes.keys()) if compute_num_datapoints else 0
        )

        perf_time_log.update("Compute number of labeled tokens")

        logger.debug(perf_time_log.pretty_summary())

        return token_uids, L_sparse_generator, num_labeled_tokens

    def compute_L_for_analysis(
        self,
        x_uids: List[str],
        lf_uids: List[int],
        lf_labels: Dict[int, LabelsType],
        do_filter: bool = True,
        **kwargs: Any,
    ) -> sparse._coo.core.COO:
        if "tokenized_documents" not in kwargs:
            raise ValueError("tokenized documents must be in kwargs")

        tokenized_documents = kwargs["tokenized_documents"]

        perf_time_log = PerfTimeLog(
            "Compute L matrix for SequenceLabelSpace for metrics"
        )

        token_uids = self.get_all_tokens(x_uids, tokenized_documents)
        perf_time_log.update("Get all token uids")

        if do_filter:
            for lf_idx, lf_uid in enumerate(lf_uids):
                if lf_uid in lf_labels:
                    raw_labels = lf_labels[lf_uid]
                    lf_labels[lf_uid] = {
                        x_uid: label
                        for x_uid, label in raw_labels.items()
                        if label != self.get_raw_unknown_label()
                    }

            perf_time_log.update("Filter LF votes for unknown")

        token_uids_to_idx = {uid: i for i, uid in enumerate(token_uids)}

        rows = []
        lfs = []
        votes = []

        perf_time_log.update("Initialize variables")

        for lf_idx, lf_uid in enumerate(lf_uids):
            if lf_uid in lf_labels:
                lf_token_votes = _safe_raw_labels_to_sparse_token_labels(
                    lf_labels[lf_uid], tokenized_documents
                )

                perf_time_log.update("Match LF votes to doc spans")

                lfs += [lf_idx] * len(lf_token_votes)
                votes += list(lf_token_votes.values())
                rows += [
                    token_uids_to_idx[token_uid]
                    for token_uid in list(lf_token_votes.keys())
                ]

                perf_time_log.update("Update variables")

        L = sparse.COO(
            coords=(rows, lfs, votes),
            data=np.uint64(1),
            shape=(len(token_uids), len(lf_uids), self.cardinality),
            fill_value=0,
        )

        perf_time_log.update(f"Make L tensor")

        logger.info(perf_time_log.pretty_summary())

        return L

    def _compute_label_model_tuning_ground_truth(
        self,
        ground_truth: Dict[str, Any],
        lm_uids: List[Any],
        df: Optional[pd.DataFrame] = None,
    ) -> np.ndarray:
        ground_truth_raw_labels = RawLabels(labels=ground_truth)
        ground_truth_dense_labels = self.raw_labels_to_dense_token_labels(
            ground_truth_raw_labels, df
        )

        ground_truth_for_lm = np.array(
            [
                ground_truth_dense_labels.get(uid, self.raw_unknown_int)
                for uid in lm_uids
            ],
            dtype=int,
        )

        return ground_truth_for_lm

    def _compute_probs_and_abstains_from_lm(
        self,
        lm_x_uids: List[str],
        lm_probs: np.ndarray,
        lm_abstains: np.ndarray,
        df: Optional[pd.DataFrame] = None,
    ) -> Tuple[List[str], List[Any], List[bool], Optional[List[Any]]]:
        """
        span_abstains: a list of bool per document, same length as the prob for that doc
        doc_abstains: bool per document, if all spans are abstained then True, else False
        """
        raw_probs = self.token_probs_to_raw_probs(lm_x_uids, lm_probs, df, lm_abstains)
        probs, span_abstains, doc_abstains = zip(*list(raw_probs.values()))
        doc_uids = list(raw_probs.keys())
        return doc_uids, list(probs), list(doc_abstains), list(span_abstains)

    def _compute_span_retrieval_metrics(
        self,
        ground_truth: RawLabels,
        prediction: RawLabels,
        ignore_negative_labels: bool = True,
        class_int: Optional[int] = None,
    ) -> Dict[str, Any]:
        y_true_spans: Set[tuple] = set()
        y_pred_spans: Set[tuple] = set()
        for x_uid, doc_gt in ground_truth.labels.items():
            # Filtering to all examples where GT exists
            # Docs with GT but no predictions will be scored as recall errors.
            # We filter out negative spans from scoring
            if doc_gt == self.get_raw_unknown_label():
                continue
            for span_gt_label in doc_gt:
                char_start, char_end, span_class = span_gt_label
                if not ignore_negative_labels or (
                    ignore_negative_labels
                    and span_class != self.label_map_raw_negative_label
                ):
                    if class_int is None or class_int == span_class:
                        y_true_spans.add((x_uid, char_start, char_end, span_class))
            for span_pred_label in prediction.labels.get(x_uid, []):
                char_start, char_end, span_class = span_pred_label
                if not ignore_negative_labels or (
                    ignore_negative_labels
                    and span_class != self.label_map_raw_negative_label
                ):
                    if class_int is None or (
                        class_int is not None and class_int == span_class
                    ):
                        y_pred_spans.add((x_uid, char_start, char_end, span_class))

        # This computes micro-averaged metrics
        retrieval_metrics = metrics_utils.compute_retrieval_metrics(
            y_pred_spans, y_true_spans
        )
        return retrieval_metrics

    def _compute_overlap_span_retrieval_metrics(
        self, ground_truth: RawLabels, prediction: RawLabels
    ) -> Dict[str, Any]:
        num_true_positives = 0
        num_false_positives = 0
        num_false_negatives = 0

        for x_uid, doc_gt in ground_truth.labels.items():
            # Filtering to all examples where GT exists
            # Docs with GT but no predictions will be scored as recall errors
            # We filter out negative spans from scoring
            if doc_gt == self.get_raw_unknown_label():
                continue

            # Maps ground truth spans to boolean indicating if they've been predicted
            y_true_spans = {}
            for span_gt_label in doc_gt:
                char_start, char_end, span_class = span_gt_label
                if span_class != self.label_map_raw_negative_label:
                    y_true_spans[(char_start, char_end, span_class)] = False
            for span_pred_label in prediction.labels.get(x_uid, []):
                y_pred_char_start, y_pred_char_end, y_pred_span_class = span_pred_label
                if y_pred_span_class != self.label_map_raw_negative_label:
                    is_false_positive = True
                    for y_true_span in y_true_spans.keys():
                        (
                            y_true_char_start,
                            y_true_char_end,
                            y_true_span_class,
                        ) = y_true_span
                        if y_pred_span_class == y_true_span_class and (
                            y_pred_char_start < y_true_char_end
                            and y_pred_char_end > y_true_char_start
                        ):
                            # We only keep overlaps if the intersection / union
                            # of the two spans is more than 0.5, to avoid trivial
                            # solutions
                            min_char_start = min(y_pred_char_start, y_true_char_start)
                            min_char_end = min(y_pred_char_end, y_true_char_end)
                            max_char_start = max(y_pred_char_start, y_true_char_start)
                            max_char_end = max(y_pred_char_end, y_true_char_end)
                            iou = float(min_char_end - max_char_start) / float(
                                max_char_end - min_char_start
                            )
                            if iou > 0.5:
                                y_true_spans[y_true_span] = True
                                is_false_positive = False
                    if is_false_positive:
                        num_false_positives += 1
            for predicted in y_true_spans.values():
                if predicted:
                    num_true_positives += 1
                else:
                    num_false_negatives += 1

        # This computes micro-averaged metrics
        retrieval_metrics = metrics_utils.calculate_retrieval_metrics(
            num_true_positives, num_false_positives, num_false_negatives
        )
        return {
            f"overlap_span_{metric_name}": metric_value
            for metric_name, metric_value in retrieval_metrics.items()
        }

    def _get_per_label_data(self, labels: Set[Tuple[str, str, int]]) -> Dict[int, Set]:
        """We assume the last value in `labels` is the label int"""

        per_class_dict = defaultdict(set)
        for label in labels:
            # grouping records by label_int
            label_int: int = label[-1]
            per_class_dict[label_int].add(label)
        return per_class_dict

    def _compute_macro_retrieval_metrics(
        self, pred_set: Set[Tuple[str, str, int]], gt_set: Set[Tuple[str, str, int]]
    ) -> Dict[str, Optional[float]]:
        """Compute macro retrieval metrics for SequenceLabelSpace with
        predictions/ground truth 'sets' comparisons.

        We assume the last value in the Tuple element for `pred_set` and `gt_set`
        are label ints.
        """
        gt_per_class = self._get_per_label_data(gt_set)
        pred_per_class = self._get_per_label_data(pred_set)

        per_class_metrics = {}
        for label_int, labels in gt_per_class.items():
            gt_set = gt_per_class[label_int]
            pred_set = pred_per_class[label_int]
            metrics_dict = metrics_utils.compute_retrieval_metrics(pred_set, gt_set)
            per_class_metrics[label_int] = metrics_dict

        results: Dict[str, Optional[float]] = {}
        # add macro metrics
        macro_metrics = defaultdict(list)
        for metric in MetricsKeys.RETRIEVAL_METRICS:
            vals = per_class_metrics.values()
            for val in vals:
                macro_metrics[metric].append(val[metric])

        for k, v in macro_metrics.items():
            if any([None is x for x in v]):
                results[f"{k}_macro"] = None
            else:
                results[f"{k}_macro"] = np.mean(v)
        return results

    def _compute_text_retrieval_metrics(
        self,
        ground_truth: RawLabels,
        prediction: RawLabels,
        documents: Dict[str, str],
        normalizer: Any,
    ) -> Dict[str, Any]:
        y_true: Set[Tuple[str, str, int]] = set()
        y_pred: Set[Tuple[str, str, int]] = set()

        for x_uid, doc_gt in ground_truth.labels.items():
            # Filtering to all examples where GT exists
            # Docs with GT but no predictions will be scored as recall errors.
            # We filter out negative spans from scoring
            if doc_gt == self.get_raw_unknown_label():
                continue
            document = documents[x_uid]
            for span_gt_label in doc_gt:
                char_start, char_end, span_class = span_gt_label
                if span_class != self.label_map_raw_negative_label:
                    span_text = document[char_start:char_end]
                    y_true.add((x_uid, span_text, span_class))
            for span_pred_label in prediction.labels.get(x_uid, []):
                char_start, char_end, span_class = span_pred_label
                if span_class != self.label_map_raw_negative_label:
                    span_text = document[char_start:char_end]
                    y_pred.add((x_uid, span_text, span_class))

        # Normalize spans if needed
        # NOTE: This is a hack to continue supporting normalization in doc metrics for
        # extraction model nodes. The correct implementation is to move this metric
        # to a new label space type on the normalizer instead of the model node.
        if normalizer:
            y_true_span_texts = pd.DataFrame(
                {SpanCols.SPAN_TEXT: [y_t[1] for y_t in y_true]}
            )
            y_pred_span_texts = pd.DataFrame(
                {SpanCols.SPAN_TEXT: [y_p[1] for y_p in y_pred]}
            )
            normalized_y_true_span_texts = list(
                dask_compute(
                    normalizer.execute(
                        [dd.from_pandas(y_true_span_texts, npartitions=1)]
                    )
                )[0][SpanCols.NORMALIZED_SPAN]
            )
            normalized_y_pred_span_texts = list(
                dask_compute(
                    normalizer.execute(
                        [dd.from_pandas(y_pred_span_texts, npartitions=1)]
                    )
                )[0][SpanCols.NORMALIZED_SPAN]
            )
            y_true = {
                (y_t[0], normalized_span, y_t[2])
                for y_t, normalized_span in zip(y_true, normalized_y_true_span_texts)
            }
            y_pred = {
                (y_p[0], normalized_span, y_p[2])
                for y_p, normalized_span in zip(y_pred, normalized_y_pred_span_texts)
            }

        # This computes micro-averaged metrics
        micro_retrieval_metrics = metrics_utils.compute_retrieval_metrics(
            y_pred, y_true
        )

        # This computes macro-average metrics
        macro_retrieval_metrics = self._compute_macro_retrieval_metrics(y_pred, y_true)

        return {**micro_retrieval_metrics, **macro_retrieval_metrics}

    def get_compute_metrics_required_columns(self, metrics: List[str]) -> List[str]:
        required_columns = set()
        for metric in metrics:
            if metric in TOKEN_RETRIEVAL_METRICS:
                if self.tokens_field is None:
                    raise ValueError(
                        "Tokens field must be defined in label space for token metrics"
                    )
                required_columns.add(self.tokens_field)
            if (
                metric
                in SPAN_RETRIEVAL_METRICS
                + OVERLAP_SPAN_RETRIEVAL_METRICS
                + TEXT_RETRIEVAL_METRICS
                + SPAN_PER_CLASS_METRICS
            ):
                if self.field is None:
                    raise ValueError(
                        "Documents field must be defined in label space for requested metrics"
                    )
                required_columns.add(self.field)
        return list(required_columns)

    def _compute_metrics(
        self,
        ground_truth: RawLabels,
        prediction: RawLabels,
        metrics: List[str],
        custom_metric_funcs: Dict[str, Callable],
        df: Optional[pd.DataFrame] = None,
        df_uid_col: Optional[str] = None,
        # NOTE: This is only used to support normalizing spans for text retrieval metrics
        # This can be removed once doc metrics are moved to the normalizer operator
        extra_params: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        if extra_params is None:
            extra_params = {}
        if custom_metric_funcs:
            err_msg = "Custom metrics are not supported for SequenceLabelSpace."
            raise NotSupportedException(detail=err_msg, user_friendly_message=err_msg)

        requested_span_retrieval_metrics = [
            metric for metric in metrics if metric in SPAN_RETRIEVAL_METRICS
        ]
        requested_text_retrieval_metrics = [
            metric for metric in metrics if metric in TEXT_RETRIEVAL_METRICS
        ]
        requested_overlap_span_retrieval_metrics = [
            metric for metric in metrics if metric in OVERLAP_SPAN_RETRIEVAL_METRICS
        ]
        requested_token_retrieval_metrics = [
            metric for metric in metrics if metric in TOKEN_RETRIEVAL_METRICS
        ]

        requested_per_class_span_retrieval_metrics = [
            metric for metric in metrics if metric in SPAN_PER_CLASS_METRICS
        ]

        metrics_values = {metric_name: None for metric_name in metrics}

        if requested_span_retrieval_metrics:
            if df is None or df_uid_col is None or self.field not in df.columns:
                raise ValueError("Dataframe is required to compute requested metrics")
            df[self.field] = df[self.field].apply(
                lambda x: "" if type(x) is not str else x
            )
            documents_length = dict(zip(df[df_uid_col], df[self.field].map(len)))
            ground_truth = self._truncate_out_of_boundary_span_labels(
                ground_truth, documents_length
            )
            prediction = self._truncate_out_of_boundary_span_labels(
                prediction, documents_length
            )

            span_retrieval_metrics_values = self._compute_span_retrieval_metrics(
                ground_truth, prediction
            )
            for metric_name, metric_value in span_retrieval_metrics_values.items():
                if f"span_{metric_name}" in requested_span_retrieval_metrics:
                    metrics_values[f"span_{metric_name}"] = metric_value
        if requested_per_class_span_retrieval_metrics:
            if df is None or df_uid_col is None or self.field not in df.columns:
                raise ValueError("Dataframe is required to compute requested metrics")
            df[self.field] = df[self.field].apply(
                lambda x: "" if type(x) is not str else x
            )
            documents_length = dict(
                zip(df[df_uid_col], df[self.field].apply(lambda x: len(x)))
            )
            ground_truth = self._truncate_out_of_boundary_span_labels(
                ground_truth, documents_length
            )
            prediction = self._truncate_out_of_boundary_span_labels(
                prediction, documents_length
            )

            metrics_values[MetricsKeys.PER_CLASS_KEY] = defaultdict()  # type: ignore
            for class_name, seq_class in self.label_map.items():
                if seq_class == self.raw_unknown_int:
                    continue
                span_metrics = self._compute_span_retrieval_metrics(
                    ground_truth,
                    prediction,
                    ignore_negative_labels=False,
                    class_int=seq_class,
                )
                for metric_name, metric_val in span_metrics.items():
                    span_metrics.pop(metric_name)
                    span_metrics[f"span_{metric_name}"] = metric_val
                metrics_values[MetricsKeys.PER_CLASS_KEY][class_name] = span_metrics  # type: ignore

        if requested_overlap_span_retrieval_metrics:
            if df is None or df_uid_col is None or self.field not in df.columns:
                raise ValueError("Dataframe is required to compute requested metrics")
            df[self.field] = df[self.field].apply(
                lambda x: "" if type(x) is not str else x
            )
            documents_length = dict(zip(df[df_uid_col], df[self.field].map(len)))

            ground_truth = self._truncate_out_of_boundary_span_labels(
                ground_truth, documents_length
            )
            prediction = self._truncate_out_of_boundary_span_labels(
                prediction, documents_length
            )

            overlap_span_retrieval_metrics_values = (
                self._compute_overlap_span_retrieval_metrics(ground_truth, prediction)
            )
            for (
                metric_name,
                metric_value,
            ) in overlap_span_retrieval_metrics_values.items():
                if metric_name in requested_overlap_span_retrieval_metrics:
                    metrics_values[metric_name] = metric_value
        if requested_text_retrieval_metrics:
            if df is None or df_uid_col is None or self.field not in df.columns:
                raise ValueError("Dataframe is required to compute requested metrics")
            df[self.field] = df[self.field].apply(
                lambda x: "" if type(x) is not str else x
            )
            documents = dict(zip(df[df_uid_col], df[self.field]))

            text_retrieval_metrics_values = self._compute_text_retrieval_metrics(
                ground_truth, prediction, documents, extra_params.get("normalizer")
            )
            for metric_name, metric_value in text_retrieval_metrics_values.items():
                if metric_name in requested_text_retrieval_metrics:
                    metrics_values[metric_name] = metric_value
        if requested_token_retrieval_metrics:
            if df is None or df_uid_col is None or self.tokens_field not in df.columns:
                raise ValueError(
                    "Tokens are required to compute token retrieval metrics"
                )
            tokens_df = df.set_index(df_uid_col)
            ground_truth_token_labels = self.raw_labels_to_sparse_token_labels(
                ground_truth, tokens_df
            )
            prediction_token_labels = self.raw_labels_to_sparse_token_labels(
                prediction, tokens_df
            )
            gt_labels: Set[str] = set()
            pred_labels: Set[str] = set()
            for token_id in ground_truth_token_labels:
                # Only include tokens with both predictions and ground truth
                if token_id in prediction_token_labels:
                    if (
                        ground_truth_token_labels[token_id]
                        != self.label_map_raw_negative_label
                    ):
                        gt_labels.add(
                            f"{token_id}_{ground_truth_token_labels[token_id]}"
                        )
                    if (
                        prediction_token_labels[token_id]
                        != self.label_map_raw_negative_label
                    ):
                        pred_labels.add(
                            f"{token_id}_{prediction_token_labels[token_id]}"
                        )
            token_retrieval_metrics = metrics_utils.compute_retrieval_metrics(
                pred_labels, gt_labels
            )
            for metric_name, metric_value in token_retrieval_metrics.items():
                if f"token_{metric_name}" in requested_token_retrieval_metrics:
                    metrics_values[f"token_{metric_name}"] = metric_value

        return metrics_values

    def get_all_tokens(self, x_uids: List, tokenized_documents: Dict) -> List[str]:
        # NOTE: documents can contain a superset of x_uids in first arg
        return [
            f"{x_uid}_{idx}"
            for x_uid in x_uids
            if x_uid in tokenized_documents
            for idx in range(len(tokenized_documents[x_uid]))
        ]

    # For tokens that doesn't have corresponding raw(span) label, this method fills
    # unknown labels for such tokens
    # Parsing token by token to find labels. This way is more effecient to fetch dense labels
    def raw_labels_to_dense_token_labels(
        self, raw_labels: RawLabels, df: pd.DataFrame
    ) -> Dict[str, Any]:
        # NOTE: documents can contain a superset of x_uids in raw_labels
        token_labels = {}
        if self.tokens_field is None:
            raise ValueError(
                "Cannot compute token labels for label space without a tokens_field."
            )
        if self.tokens_field not in df.columns:
            raise ValueError(
                f"Missing tokens field {self.tokens_field} in dataframe columns: {df.columns}"
            )
        tokenized_documents = df[self.tokens_field].to_dict()

        for x_uid, raw_label in raw_labels.labels.items():
            if x_uid not in tokenized_documents:
                continue
            tokens = tokenized_documents[x_uid]
            if len(tokens) == 0:
                continue
            if raw_label == self.get_raw_unknown_label():
                for idx in range(len(tokens)):
                    token_labels[f"{x_uid}_{idx}"] = self.raw_unknown_int
                continue
            sorted_spans = sorted(raw_label, key=lambda span: span[0])
            # Add a dummy span at the end so the while loop below terminates without going out of bounds.
            sorted_spans.append((sys.maxsize, sys.maxsize, self.raw_unknown_int))
            cur_span_idx = 0
            for idx, token in enumerate(tokens):
                token_uid = f"{x_uid}_{idx}"
                token_labels[token_uid] = self.raw_unknown_int
                token_start = token[0]
                token_end = token[1]
                span_start, span_end, span_class = sorted_spans[cur_span_idx]
                while span_end <= token_start:
                    cur_span_idx += 1
                    span_start, span_end, span_class = sorted_spans[cur_span_idx]
                # A token is labeled if any character is included in the labeled span
                if token_end > span_start:
                    # If a token has two labels, we use the label that occurs first
                    token_labels[token_uid] = span_class
        return token_labels

    def raw_labels_to_dense_span_labels(self, raw_labels: RawLabels) -> Dict[str, Any]:
        span_labels = {}
        for x_uid, raw_label in raw_labels.labels.items():
            if raw_label == self.get_raw_unknown_label():
                span_labels[f"{x_uid}_-1_-1"] = self.raw_unknown_int

            for _, span in enumerate(raw_label):
                span_uid = f"{x_uid}_{span[0]}_{span[1]}"
                span_labels[span_uid] = span[2]
        return span_labels

    # Unknown_labels are NOT filled for the tokens for which corresponding spans are not labeled
    # Parsing span by span to fetch token labels. (An effecient way to fetch sparse labels)
    def raw_labels_to_sparse_token_labels(
        self, raw_labels: RawLabels, df: pd.DataFrame
    ) -> Dict[str, Any]:
        # NOTE: documents can contain a superset of x_uids in raw_labels
        if self.tokens_field is None:
            raise ValueError(
                "Cannot compute token labels for label space without a tokens_field."
            )
        if self.tokens_field not in df.columns:
            raise ValueError(
                f"Missing tokens field {self.tokens_field} in dataframe columns: {df.columns}"
            )
        tokenized_documents = df[self.tokens_field].to_dict()

        filtered_labels = {
            x_uid: label
            for x_uid, label in raw_labels.labels.items()
            if label != self.get_raw_unknown_label()
        }
        result = _safe_raw_labels_to_sparse_token_labels(
            filtered_labels, tokenized_documents
        )
        return result

    def token_probs_to_raw_probs(
        self,
        token_uids: List[str],
        token_probs: np.ndarray,
        df: pd.DataFrame,
        token_abstains: np.ndarray,
    ) -> Dict[str, Any]:
        if self.tokens_field is None:
            raise ValueError(
                "Cannot compute token labels for label space without a tokens_field."
            )
        if self.tokens_field not in df.columns:
            raise ValueError(
                f"Missing tokens field {self.tokens_field} in dataframe columns: {df.columns}"
            )
        if len(token_abstains) != len(token_probs):
            raise ValueError(
                f"Inconsistent length between token_abstains and token_probs, token_abstains is of length {len(token_abstains)}, token_probs is of length {len(token_probs)}."
            )
        document_to_token_abstains = dict(zip(token_uids, token_abstains.tolist()))
        tokenized_documents = df[self.tokens_field].to_dict()
        # NOTE: documents can contain a superset of x_uids in raw_labels

        document_to_token_labels = defaultdict(list)
        raw_labels_dict = {}
        for i in range(len(token_uids)):
            x_uid, token_num_str = token_uids[i].split("_")
            document_to_token_labels[x_uid].append((int(token_num_str), token_probs[i]))
        for x_uid, document_token_labels in document_to_token_labels.items():
            tokens = tokenized_documents[x_uid]
            raw_label: List[List[Any]] = []
            span_abstains: List[bool] = []
            sorted_token_labels = sorted(
                document_token_labels, key=lambda label: label[0]
            )
            prev_token_label = None
            for token_num, token_prob in sorted_token_labels:
                token_start = int(tokens[token_num][0])
                token_end = int(tokens[token_num][1])
                token_abstain = document_to_token_abstains[f"{x_uid}_{token_num}"]
                if (
                    prev_token_label is not None
                    and prev_token_label[0] == token_num - 1
                    and (prev_token_label[1] == token_prob).all()
                    and prev_token_label[2] == token_abstain
                ):
                    # If the previous token has the same label as this token
                    # Extend the span to include this token
                    raw_label[-1][1] = token_end
                else:
                    raw_label.append([token_start, token_end, token_prob.tolist()])
                    span_abstains.append(token_abstain)
                prev_token_label = (token_num, token_prob, token_abstain)
            doc_abstain = False
            raw_labels_dict[x_uid] = (raw_label, span_abstains, doc_abstain)
        return raw_labels_dict

    def raw_label_to_user_label(self, raw_label: Any) -> Any:
        if raw_label == self.get_raw_unknown_label():
            return raw_label
        user_label = []
        for span in raw_label:
            char_start, char_end, class_int = span
            user_label.append(
                [char_start, char_end, self._inverse_label_map[class_int]]
            )
        return user_label

    def user_label_to_raw_label(
        self, user_label: Any, x_uid: Optional[str] = None
    ) -> Any:
        if not user_label:
            return self.get_raw_unknown_label()
        else:
            # valid user labels are the keys of the label_map dict
            valid_labels = set(self.label_map.keys())
            # remove unknown label
            valid_labels.remove(self._inverse_label_map[self.raw_unknown_int])
            self._validate_label(user_label, valid_labels, x_uid)
            raw_label = []
            for span in user_label:
                char_start, char_end, span_class = span
                raw_label.append([char_start, char_end, self.label_map[span_class]])
            return raw_label

    def get_label_remap_dict(
        self,
        old_label_space: LabelSpace,
        updated_label_schema: Optional[Dict[str, Optional[str]]],
    ) -> Optional[Dict[str, Optional[str]]]:
        """Compute label mapping for transfer given user mapping"""
        old_label_map = old_label_space.label_map
        label_map = self.label_map
        inv_label_map = {v: k for k, v in label_map.items()}
        label_remap_dictionary = None
        if updated_label_schema is not None:
            label_remap_dictionary = copy.deepcopy(updated_label_schema)

            # forbid any remapping to UNKNOWN
            if inv_label_map[self.raw_unknown_int] in label_remap_dictionary.values():
                err_msg = (
                    f"Cannot remap label to {inv_label_map[self.raw_unknown_int]}."
                )
                how_to_fix = f"Please remap label to another."
                raise UserInputError(
                    user_friendly_message=err_msg, detail=err_msg, how_to_fix=how_to_fix
                )

        # Map common label strings to themselves if not mapped to other labels by user
        common_labels = set(old_label_map).intersection(label_map)
        if common_labels:
            if label_remap_dictionary is None:
                label_remap_dictionary = {k: k for k in common_labels}
            else:
                for label in common_labels:
                    if label not in label_remap_dictionary:
                        label_remap_dictionary[label] = label

        # Map dropped labels to negative
        union_labels = set(old_label_map).union(set(label_map))
        dropped_labels = list(union_labels - set(label_map))
        for label in dropped_labels:
            if label_remap_dictionary and label not in label_remap_dictionary:
                label_remap_dictionary[label] = inv_label_map[
                    self.label_map_raw_negative_label
                ]  # negative label
        return label_remap_dictionary

    def remap_raw_label(
        self, label: List[List[Any]], remap: Dict
    ) -> Optional[List[List[Any]]]:
        # Because src/python/data_models/annotations.py - import_annotations default remap to:
        # remap != {i: i for i in range(self.cardinality)}, which suppose to keep the label unchanged
        # Hence, if we see such input, return same value
        if (not remap) or (remap == {i: i for i in range(self.cardinality)}):
            return label

        new_label = [
            [span[0], span[1], remap.get(span[2])] if (span[2] in remap) else span
            for span in label
        ]
        return new_label

    @staticmethod
    def remap_labels(
        labels: Dict[str, Any],
        remap: Dict[Any, Any],
        filter_missing_keys: Optional[bool] = True,
    ) -> Dict[Any, Any]:
        remapped_labels = dict()
        for x_uid, label in labels.items():
            if label == SequenceLabelSpace.get_raw_unknown_label():
                remapped_labels[x_uid] = label
                continue
            remapped_label = []
            filter_doc = False
            for span in label:
                if filter_missing_keys and span[2] not in remap:
                    # If any span in a document has an invalid label, filter out the
                    # entire document, not just the offending span
                    filter_doc = True
                    break
                remapped_label.append([span[0], span[1], remap.get(span[2], span[2])])
            if not filter_doc:
                remapped_labels[x_uid] = remapped_label
        return remapped_labels

    def parse_postprocessed_spans(
        self, postprocessed_spans: List[metrics_utils.PostprocessedSpan]
    ) -> RawLabels:
        # NOTE: This does not handle probs, since they're not needed downstream
        # NOTE: This does not add negative spans, since all current use cases filter them out
        raw_labels: Dict[str, Any] = {}
        for span in postprocessed_spans:
            if span.x_uid not in raw_labels:
                raw_labels[span.x_uid] = []
            # NOTE: Candidate [char_start, char_end] are [inclusive, inclusive], while
            # sequence ground truth [char_start, char_end) are [inclusive, exclusive)
            # TODO: Update candidates to use [inclusive, exclusive)
            raw_labels[span.x_uid].append(
                [span.char_start, span.char_end + 1, span.label]
            )
        return RawLabels(raw_labels)

    @staticmethod
    def check(
        x: pd.Series,
        op_name: str,
        fault_tolerant: bool = False,
        *conditions: LFCondition,
    ) -> List[Tuple[int, int]]:
        if op_name == constants.IS:
            return SequenceLabelSpace._is(x, fault_tolerant, conditions[0])

        if op_name == constants.AND:
            return SequenceLabelSpace._and(x, fault_tolerant, *conditions)

        if op_name == constants.OR:
            return SequenceLabelSpace._or(x, fault_tolerant, *conditions)

        if op_name == constants.NOT:
            return SequenceLabelSpace._not(x, fault_tolerant, *conditions)

        raise KeyError(f"invalid LF Graph op_name provided: {op_name}")

    @staticmethod
    def _is(
        x: pd.Series, fault_tolerant: bool, condition: LFCondition
    ) -> List[Tuple[int, int]]:
        return SequenceLabelSpace._safe_check(condition, x, fault_tolerant)

    @staticmethod
    def _and(
        x: pd.Series, fault_tolerant: bool, *conditions: LFCondition
    ) -> List[Tuple[int, int]]:
        spans1 = []
        for i, condition in enumerate(conditions):
            if i == 0:
                spans1 = sorted(
                    SequenceLabelSpace._safe_check(condition, x, fault_tolerant),
                    key=lambda x: x[0],
                )
            else:
                spans2 = sorted(
                    SequenceLabelSpace._safe_check(condition, x, fault_tolerant),
                    key=lambda x: x[0],
                )
                spans1 = and_two_span_lists(spans1, spans2)  # type: ignore

        return spans1

    @staticmethod
    def _or(
        x: pd.Series, fault_tolerant: bool, *conditions: LFCondition
    ) -> List[Tuple[int, int]]:
        span_list = []
        for condition in conditions:
            spans = SequenceLabelSpace._safe_check(condition, x, fault_tolerant)
            span_list.extend(spans)
        return merge_spans(span_list)

    @staticmethod
    def _get_complement_spans(
        spans: Union[List[Tuple[int, int]], List[List[int]]]
    ) -> List[Tuple[int, int]]:
        complement_spans = []
        sorted_spans = sorted(spans, key=lambda x: x[0])
        prev_end = 0
        for span in sorted_spans:
            # Note that *_ ignores a third member of the unpacked list since input spans
            # to this function can contain either 2 or 3 (with a label) members
            start, end, *_ = span
            if prev_end < start:
                complement_spans.append((prev_end, start))
            prev_end = end
        # TODO(ENG-13230): currently this returns (end of last span, sys.maxsize)
        # as a span every time, but in reality this complement span should be either
        # (end of last span, end of doc) if (end of last span < end of doc), or nothing if
        # (end of last span == end of doc). We need to figure out if it makes more sense
        # to figure this out on the FE or add code to find the length of each doc on the BE
        complement_spans.append((prev_end, sys.maxsize))
        return complement_spans

    @staticmethod
    def _not(
        x: pd.Series, fault_tolerant: bool, *conditions: LFCondition
    ) -> List[Tuple[int, int]]:
        spans = SequenceLabelSpace._safe_check(conditions[0], x, fault_tolerant)
        if not spans:
            return []
        return SequenceLabelSpace._get_complement_spans(spans)

    @staticmethod
    def _safe_check(
        condition: LFCondition,
        x: pd.Series,
        fault_tolerant: bool,
        on_error_return: Optional[List] = None,
    ) -> List[Tuple[int, int]]:
        if on_error_return is None:
            on_error_return = []
        if not fault_tolerant:
            return condition.check(x)
        try:
            return condition.check(x)
        except Exception:
            return on_error_return

    @staticmethod
    def compose_lf(label: int, condition: Any, fault_tolerant: bool) -> Callable:
        def lf(x: pd.Series) -> Optional[List[Tuple[int, int, int]]]:
            spans = condition.check(x, fault_tolerant=fault_tolerant)
            if spans:
                return [(start, end, label) for (start, end) in spans]
            return SequenceLabelSpace.get_raw_unknown_label()

        return lf

    def update_subdatapoint_lf_abstains_with_ground_truth(
        self,
        subdatapoint_lf_abstains: Optional[List[Any]],
        x_uids: List[str],
        ground_truth: LabelsType,
    ) -> Optional[List[Any]]:
        # subdatapoint_lf_abstains needs to be updated to all false for the ground truth spans
        if not subdatapoint_lf_abstains:
            return None
        updated_subdatapoint_lf_abstains = []
        for index, x_uid in enumerate(x_uids):
            if x_uid in ground_truth:
                updated_subdatapoint_lf_abstains.append(
                    [False] * len(ground_truth[x_uid])
                )
            else:
                updated_subdatapoint_lf_abstains.append(subdatapoint_lf_abstains[index])
        return updated_subdatapoint_lf_abstains

    def probs_to_preds_with_threshold(
        self,
        probs: np.ndarray,
        lf_abstains: Optional[np.ndarray] = None,
        tie_break_policy: str = "abstain",
        tol: float = 0.0001,
        filter_uncertain_labels_threshold: float = 0.0,
        postprocess_labels: bool = False,
    ) -> np.ndarray:
        perf_time_log = PerfTimeLog("Probs to preds for SequenceLabelSpace")

        span_lf_abstains = None
        num_doc = len(probs)

        total_spans = np.sum([len(probs[i]) for i in range(num_doc)])

        doc_batch_size = max(
            1, int(NUM_SPANS_PER_BATCH * num_doc / (total_spans + 1) / self.cardinality)
        )
        logger.info(f"process probs to preds with doc batch size of {doc_batch_size}")
        perf_time_log.update("Compute total number of spans and doc batch size")

        Y = np.empty(num_doc, dtype=object)
        for i_batch in range(0, num_doc, doc_batch_size):
            batch_probs = probs[i_batch : i_batch + doc_batch_size]
            span_index_per_doc = np.array(
                [0] + [len(batch_probs[i]) for i in range(len(batch_probs))]
            )
            np.cumsum(span_index_per_doc, out=span_index_per_doc)

            perf_time_log.update("Compute span_index_per_doc")

            all_probs = np.empty((span_index_per_doc[-1], self.cardinality))
            all_char_starts = []
            all_char_ends = []
            for i, prob in enumerate(batch_probs):
                tmp = list(zip(*prob))
                all_char_starts += tmp[0]
                all_char_ends += tmp[1]
                all_probs[span_index_per_doc[i] : span_index_per_doc[i + 1]] = np.array(
                    tmp[2]
                )

            perf_time_log.update("Munge probs")

            span_lf_abstains = None
            if lf_abstains is not None:
                span_lf_abstains = []
                for lf_abstain in lf_abstains[i_batch : i_batch + doc_batch_size]:
                    span_lf_abstains += (
                        lf_abstain if type(lf_abstain) is list else lf_abstain.tolist()
                    )

            perf_time_log.update("Munge abstains")

            raw_unknown_int = self.raw_unknown_int

            all_labels = probs_to_preds_with_threshold_flat(
                all_probs,
                tie_break_policy,
                tol,
                filter_uncertain_labels_threshold,
                raw_unknown_int,
                lf_abstains=np.array(span_lf_abstains)
                if span_lf_abstains is not None
                else None,
            ).tolist()

            perf_time_log.update("Threshold probabilities")

            for i in range(len(batch_probs)):
                Y[i + i_batch] = list(
                    zip(
                        all_char_starts[
                            span_index_per_doc[i] : span_index_per_doc[i + 1]
                        ],
                        all_char_ends[
                            span_index_per_doc[i] : span_index_per_doc[i + 1]
                        ],
                        all_labels[span_index_per_doc[i] : span_index_per_doc[i + 1]],
                    )
                )

            perf_time_log.update("Munge labels")

        if postprocess_labels:
            Y, _ = self._postprocess_labels(Y, Y)
            perf_time_log.update("Post-process negative labels")

        logger.info(perf_time_log.pretty_summary())

        return Y

    # For sequences we're computing abstains with predicted labels not matching any LF votes
    def compute_lf_abstains(
        self, L: sparse._coo.core.COO, probas: np.ndarray
    ) -> np.ndarray:
        perf_time_log = PerfTimeLog("Compute LF abstains for SequenceLabelSpace")

        preds = onehot(probas.argmax(axis=1), cardinality=self.cardinality)

        perf_time_log.update("Take argmax of probs and onehot")

        abstains = (
            sparse_any(L * preds[:, np.newaxis, :], axis=(1, 2), sparse_output=False)
            == 0
        )

        perf_time_log.update("Compute abstains from existing L matrix and preds")

        logger.debug(perf_time_log.pretty_summary())

        return abstains

    def _get_gt_label_mask_and_spans(
        self, label_int: int, data_vector: pd.Series, data_is_lf_votes: bool = False
    ) -> pd.DataFrame:
        """Given a class label (label_int) and a list with document spans, return a df with
        a 'mask' of which documents would be filtered and 'filter_spans', a list of spans that match the
        filter (or None if there are none that match). data_is_lf_votes is true if data_vector
        corresponds to votes by an LF (for finding unknowns in this case, complement spans need to be
        computed)"""
        filter_spans: List[Optional[List[Tuple[int, int]]]] = []
        for doc in data_vector:
            if doc == self.get_raw_unknown_label():
                # if an entire document is unknown, return the whole document as a span
                if label_int == self._raw_unknown_int:
                    filter_spans.append([(0, sys.maxsize)])
                else:
                    filter_spans.append(None)
            elif data_is_lf_votes and label_int == self._raw_unknown_int:
                # LF spans only contain spans that the LF voted on, so we need to
                # compute the complement spans if we want to find unknowns
                complement_spans = self._get_complement_spans(doc)
                if len(complement_spans) > 0:
                    filter_spans.append(
                        [(start, end) for start, end in complement_spans]
                    )
                else:
                    filter_spans.append(None)
            else:
                # otherwise, we simply look for spans in our input that match the desired label
                doc_filter_spans = []
                for span in doc:
                    _, _, span_label = span
                    if span_label == label_int:
                        doc_filter_spans.append((span[0], span[1]))
                filter_spans.append(doc_filter_spans if doc_filter_spans else None)
        mask = [span is not None for span in filter_spans]
        return pd.DataFrame.from_dict({"mask": mask, "filter_spans": filter_spans})

    def apply_spans_reducer(
        self,
        context_raw_labels: RawLabels,
        documents: Dict[str, str],
        reducer: Operator,
    ) -> RawLabels:
        (
            context_uid_ints,
            char_starts,
            char_ends,
            span_texts,
            span_classes,
            span_probs,
        ) = ([], [], [], [], [], [])
        for context_uid in context_raw_labels.labels.keys():
            context_label = context_raw_labels.labels[context_uid]
            context_label = sorted(context_label, key=lambda label: label[0])
            context_probs = None
            if context_raw_labels.probs:
                context_probs_dicts = context_raw_labels.probs[context_uid]
                context_probs = self.raw_probs_to_array_probs([context_probs_dicts])[0]
                context_probs = sorted(context_probs, key=lambda probs: probs[0])
            for span_idx in range(len(context_label)):
                char_start, char_end, span_class = context_label[span_idx]
                span_prob = None
                if context_probs is not None:
                    char_start_prob, char_end_prob, span_prob = context_probs[span_idx]
                    if char_start != char_start_prob or char_end != char_end_prob:
                        raise ValueError(
                            "Spans in labels and probs must have the same char_start and char_end"
                        )
                # NOTE: Candidate [char_start, char_end] are [inclusive, inclusive], while
                # sequence ground truth [char_start, char_end) are [inclusive, exclusive)
                char_end -= 1
                unknown_label_int = self.raw_unknown_int
                negative_label_int = self.label_map_raw_negative_label
                if span_class != unknown_label_int and span_class != negative_label_int:
                    # fetching context_uid slightly hackily here to avoid having to pass
                    # node_uid here to get datapoint_cols => call parse_datapoint_uid
                    context_uid_int = int(context_uid.split("::")[1].split(",", 1)[0])
                    context_uid_ints.append(context_uid_int)
                    char_starts.append(char_start)
                    char_ends.append(char_end)
                    span_texts.append(documents[context_uid][char_start:char_end])
                    span_classes.append(span_class)
                    if span_prob is None:
                        span_prob = [0.0 for _ in range(self.cardinality)]
                        span_prob[span_class] = 1.0
                    span_probs.append(span_prob)
        spans = []
        # If context_uid_ints is empty, there are no extracted spans
        if context_uid_ints:
            df_dict: Dict[str, List[Any]] = {
                SpanCols.CONTEXT_UID: context_uid_ints,
                SpanCols.CHAR_START: char_starts,
                SpanCols.CHAR_END: char_ends,
                SpanCols.SPAN_TEXT: span_texts,
                ModelCols.PREDICTION_INT: span_classes,
                ModelCols.PREDICTION_PROBABILITY: span_probs,
            }
            context_spans_ddf = dd.from_pandas(pd.DataFrame(df_dict), npartitions=1)
            context_spans_ddf = set_datapoint_uid_as_index(
                context_spans_ddf,
                datapoint_cls=DocDatapoint,
                datapoint_cols=[SpanCols.CONTEXT_UID],
            )
            ddf = reducer.execute([context_spans_ddf])
            reduced_context_spans_df = ddf[
                [SpanCols.CHAR_START, SpanCols.CHAR_END, ModelCols.PREDICTION_INT]
            ].compute()
            for (
                x_uid,
                char_start,
                char_end,
                span_class,
            ) in reduced_context_spans_df.itertuples():
                spans.append(
                    metrics_utils.PostprocessedSpan.parse_obj(
                        {
                            "x_uid": x_uid,
                            "char_start": char_start,
                            "char_end": char_end,
                            "label": span_class,
                        }
                    )
                )
        return self.parse_postprocessed_spans(spans)

    def get_gt_comparison_mask(
        self, gt_vector: pd.Series, config: Dict[str, Any]
    ) -> pd.Series:
        """Returns a mask where GT is present, if the vote is incorrect/correct (comparing to GT),
        otherwise returning a mask of all Trues"""
        if config["voted"] in [constants.CORRECT, constants.INCORRECT]:
            return ~gt_vector.isna()
        return pd.Series([True] * len(gt_vector))

    @staticmethod
    def _is_overlap(span_a: List[int], span_b: List[int]) -> bool:
        span_a_start, span_a_end, *_ = span_a
        span_b_start, span_b_end, *_ = span_b
        return span_a_start < span_b_end and span_b_start < span_a_end

    @staticmethod
    def _correct_overlap(
        candidate_span: List[int], gt_span: List[int], substring_check: bool
    ) -> bool:
        """
        substring_check : if set to True, check if candidate_span is substring of gt_span;
        if set to False, check exact char_offset match of input spans.
        """
        if substring_check:
            # if the span is an LF vote, it is correct if it is a substring of GT
            # this is because for LF, precision is more important than recall: we do not want to penalize an LF that does
            # not vote exactly on a GT, since we can always write more LFs to cover the missing part...
            return candidate_span[0] >= gt_span[0] and candidate_span[1] <= gt_span[1]
        else:
            return candidate_span[:2] == gt_span[:2]

    @staticmethod
    def _partially_correct_overlap(
        candidate_span: List[int], gt_span: List[int], data_is_lf_votes: bool
    ) -> bool:
        return not SequenceLabelSpace._correct_overlap(
            candidate_span, gt_span, data_is_lf_votes
        ) and SequenceLabelSpace._is_overlap(candidate_span, gt_span)

    # Used to map correctness filter criteria to the functions+actions they use
    # when checking each candidate/gt span pair. The first member is the function
    # that checks if a candidate span matches a relevant criteria for the filter. The second is
    # a bool that is True if we want to add the span to the list of filtered spans
    # if the relevant criteria is met for any GT span and False if we want to add the span to this
    # list if the relevant criteria is met for no GT spans
    filter_criteria_check_span_match: Dict[str, Tuple[Callable, bool]] = {
        constants.CORRECT: (_correct_overlap.__func__, True),  # type: ignore
        constants.PARTIALLY_CORRECT: (_partially_correct_overlap.__func__, True),  # type: ignore
        constants.INCORRECT: (_correct_overlap.__func__, False),  # type: ignore
    }

    # Used to map correctness filter criteria to the functions they use when checking a list of ground
    # truth spans and a list of candidate/predition spans under the strict exact match criateria (i.e.,
    # correct means char_offsets exactly match between ground truth span and candidate span).
    filter_criteria_check_list_of_spans_exact_match: Dict[str, Callable] = {
        constants.CORRECT: _find_correct_prediction_exact_match,
        constants.PARTIALLY_CORRECT: _find_partial_correct_prediction_exact_match,
        constants.INCORRECT: _find_incorrect_prediction_exact_match,
    }

    @staticmethod
    def _get_doc_correctness_criteria_spans(
        filter_criteria: str,
        data_doc: List[List[int]],
        gt_doc: List[List[int]],
        data_is_lf_votes: bool,
        raw_negative_int: int = 0,
        raw_unknown_int: int = -1,
    ) -> Optional[List[Tuple[int, int]]]:
        if (
            data_doc is SequenceLabelSpace.get_raw_unknown_label()
            or gt_doc is SequenceLabelSpace.get_raw_unknown_label()
        ):
            # if either canididate or gt doc is unknown, then no spans in the
            # candidate doc could be correct/partially correct or incorrect
            return None
        doc_filter_spans = []
        if data_is_lf_votes:
            # lf votes are not optimized: still use double for loop
            (
                check_span_match_fn,
                append_if_match,
            ) = SequenceLabelSpace.filter_criteria_check_span_match[filter_criteria]
            for candidate_span in data_doc:
                char_start, char_end, candidate_label = candidate_span
                # unknown spans are neither correct/partially correct nor incorrect
                if candidate_label == SequenceLabelSpace._raw_unknown_int:
                    continue
                is_match = False
                for gt_span in gt_doc:
                    _, _, gt_label = gt_span
                    # if gt and candidate labels differ, then this cannot be a correct match for the candidate
                    if gt_label != candidate_label:
                        continue
                    if check_span_match_fn(candidate_span, gt_span, data_is_lf_votes):
                        if append_if_match:
                            doc_filter_spans.append((char_start, char_end))
                        is_match = True
                        break
                # if there was no match and we want to append when there is no match
                # then append here
                if not is_match and not append_if_match:
                    doc_filter_spans.append((char_start, char_end))
        else:
            get_doc_filter_spans_fn = (
                SequenceLabelSpace.filter_criteria_check_list_of_spans_exact_match[
                    filter_criteria
                ]
            )
            doc_filter_spans = get_doc_filter_spans_fn(
                data_doc, gt_doc, raw_negative_int, raw_unknown_int
            )
        return doc_filter_spans if doc_filter_spans else None

    def filter_label_vector(
        self,
        data_vector: pd.Series,
        gt_vector: pd.Series,
        config: Dict[str, Any],
        x_uids: Optional[List[str]] = None,
        split: str = "dev",
    ) -> pd.DataFrame:
        """This method always gets two equal length pd.Series and returns a pd.DataFrame of the same length.
        This dataframe has two columns: a 'mask' that indicates whether or not a document should be returned by the span-level
        filter, and 'filter_spans', which for each doc is a list of spans that matched the span-level filter (or None if 'mask'
        = False). A CORRECT span is one that exactly matches a GT span (or if it is an lf vote, is contained within a GT span
        of the same class). A PARTIALLY_CORRECT span is one that is not CORRECT but has overlap with a GT span of the same class.
        An INCORRECT span is one that does not overlap with any GT span of the same class.
        Finally, this function is used for filtering on spans of a particular class (_get_gt_label_mask_and_spans is called for this case)
        """
        assert len(data_vector) == len(gt_vector)
        voted = config["voted"]

        if voted in [
            constants.CORRECT,
            constants.PARTIALLY_CORRECT,
            constants.INCORRECT,
        ]:
            data_is_lf_votes = "lf" in config
            filter_spans = [
                self._get_doc_correctness_criteria_spans(
                    voted,
                    data_doc,
                    gt_doc,
                    data_is_lf_votes,
                    self.label_map_raw_negative_label,
                    self.raw_unknown_int,
                )
                for _, (data_doc, gt_doc) in enumerate(zip(data_vector, gt_vector))
            ]
            mask = [span is not None for span in filter_spans]
            return pd.DataFrame.from_dict({"mask": mask, "filter_spans": filter_spans})
        # If this error ever triggers, we should make sure the invalid option is not
        # even being displayed in the UI, by updating e.g. get_lf_filter_structure
        if voted not in self.label_map:
            err_msg = f"{voted} filter is not supported for Sequence Tagging."
            raise UserInputError(user_friendly_message=err_msg, detail=err_msg)
        return self._get_gt_label_mask_and_spans(
            self.label_map[voted], data_vector, data_is_lf_votes=("lf" in config)
        )

    def filter_lf_conflict(self, data_row: pd.Series, config: Dict[str, Any]) -> bool:
        raise NotSupportedException(
            "WIP: LF conflict filter on sequence tagging is coming soon."
        )

    def get_text_to_code_base_prompt(self, df: pd.DataFrame) -> str:
        return f"""
    Act as a senior Python software engineer. Respond only with code, do not include any other text in your response. Do not include ``` or 'python' as part of the response.

    The goal is fill in the following function. The context is that this is a function used for sequence tagging, where we are trying to label specific subsets of the text (denoted as [char_start, char_end, label] as labels. Output the imports + function definition, as well as the completion of the function body.
    Do not import external libraries.

def determine_class(row):
    import regex


    This function will be applied in a df.apply(determine_class, axis=1) call later. The primary field to operate over is {self.text_col}. Here is a sample of the dataframe: {str(df.head())}.

    The function should return a list of [character_start, character_end, label] for each row, based on the number of extracted sequences. The possible classes are {list(self.label_map)}.
    """

    def compute_interannotator_aggregate_metric(
        self,
        user_raw_labels_map: Dict[str, RawLabels],
        metric: str = "krippendorff-alpha",
    ) -> Optional[float]:
        # TODO: Implement interannotator agreement for SequenceLabelSpace https://snorkelai.atlassian.net/browse/ENG-8824
        # Interannotator agreement aggregate metrics are not supported for SequenceLabelSpace yet.
        # Initially, we want to do mean_span_f1.
        # However, due to some tech debt in src/python/data_models/annotations.py - get_interannotator_agreement, we cannot cleanly add this method
        # Default to None (so it won't raise FE error) and revisit this again once we refactor that method.
        return None

    def _threshold_probs(
        self, x_uids: List[Any], probs: List[Any], threshold_holder: ThresholdHolder
    ) -> List[Any]:
        threshold = threshold_holder.get_threshold()
        assert self.cardinality == 2, "Only binary tasks support thresholding."
        thresholded_probs = []
        for pred in probs:
            thresholded_probs.append(
                [[p[0], p[1], int(p[2][1] >= threshold)] for p in pred]
            )
        assert len(thresholded_probs) == len(x_uids)
        return thresholded_probs

    def min_samples_per_class(
        self, labeled_data: pd.DataFrame, gt_field: str, min_samples_per_class: int
    ) -> pd.DataFrame:
        """
        Using the same logic in multi_label.min_samples_per_class
        sample is at the document level, and it belongs to a class if it contains at least one
        span with that class, thus a sample could have multi-label
        """
        class_to_datapoints = defaultdict(set)
        for idx, labels in zip(
            list(labeled_data.index), list((labeled_data[gt_field]))
        ):
            labels_set = {
                label_int
                for *_, label_int in labels
                if label_int != self._raw_unknown_int
            }
            for label in labels_set:
                class_to_datapoints[label].add(idx)
        final_sampled_point_idxs: Set[int] = set()
        for k in sorted(
            class_to_datapoints, key=lambda k: len(class_to_datapoints[k]), reverse=True
        ):
            all_datapoints_with_key = class_to_datapoints[k]
            unsampled_datapoints = all_datapoints_with_key - final_sampled_point_idxs

            overlap = len(all_datapoints_with_key) - len(unsampled_datapoints)
            num_datapoints_needed_to_meet_min = min_samples_per_class - overlap

            if len(unsampled_datapoints) <= num_datapoints_needed_to_meet_min:
                final_sampled_point_idxs = final_sampled_point_idxs.union(
                    unsampled_datapoints
                )
            else:
                sampled_datapoints = random.sample(
                    unsampled_datapoints, num_datapoints_needed_to_meet_min
                )
                final_sampled_point_idxs = final_sampled_point_idxs.union(
                    set(sampled_datapoints)
                )
        return labeled_data.loc[list(final_sampled_point_idxs)]

    @staticmethod
    def find_missing_predicted_classes(Y: np.ndarray) -> None:
        if len(Y[0][0]) != 3:
            raise TypeError(
                "Sequence Y labels should come in the form of [char_star, char_end, label_int]."
            )

    def validate_lf_label(self, lf_label: int) -> bool:
        if not isinstance(lf_label, int):
            raise TypeError("`lf_label` must be an `int`.")
        return bool(0 <= lf_label <= self.cardinality - 1)

    def compute_label_counts(self, annotations: List[Any]) -> defaultdict:
        return defaultdict(
            int,
            Counter(
                [
                    span[2]
                    for span in itertools.chain(
                        *[annotation.label for annotation in annotations]
                    )
                ]
            ),
        )

    def _spans_simple_majority_vote(self, labels: List) -> Tuple[bool, int]:
        """
        Function taking in a list of int labels and output the finalized label.
        Use majority vote.
        When ties, if self.label_map_raw_negative_label in the list -> default to NEG
        Else, random.choice
        """
        max_count = 0
        label_counts: dict = defaultdict(int)
        max_labels = []
        tie_breaking = False

        for label in labels:
            if label != self.get_raw_unknown_label():
                label_counts[label] += 1

        # Compute the list of max_labels: labels with max count (allow ties)
        for label, label_count in label_counts.items():
            if label_count > max_count:
                max_count = label_count
                max_labels = [label]
            elif label_count == max_count:
                max_labels.append(label)

        if len(max_labels) == 1:
            final_label = max_labels[0]
        # Tie-breaking
        elif len(max_labels) > 1:
            tie_breaking = True
            if self.label_map_raw_negative_label in max_labels:
                final_label = self.label_map_raw_negative_label
            else:
                max_labels.sort()
                # The seed is set in _simple_intersection
                final_label = random.choice(max_labels)

        return tie_breaking, final_label

    def _get_all_span_boundaries(
        self, annotations: List[List]
    ) -> List[Tuple[int, int, List]]:
        """
        For all annotations, we compute all the boundary points that can contain multiple labels.
        All boundary points = the sorted set of char offset from annotations (as those are the boundaries)
        From the boundary points, compute the possible intervals.

        Example:
        annotations1 = [(0, 5, 1), (5, 10, 0)]
        annotations2 = [(0, 2, 3), (2, 10, 1)]
        -> boundary_points = [0, 2, 5, 10]
        -> boundaries = [(0, 2, []), (2, 5, []), (5, 10, [])]
        """

        boundary_points = []

        for spans in annotations:
            # Get the char_start and char_end of all spans
            boundary_points += [span[0] for span in spans] + [span[1] for span in spans]

        boundary_points = sorted(list(set(boundary_points)))

        boundaries: List[Tuple[int, int, List]] = [
            (boundary_points[i], boundary_points[i + 1], [])
            for i in range(len(boundary_points) - 1)
        ]

        return boundaries

    def _inherit_labels(
        self, boundaries: List[Tuple[int, int, List]], annotations: List[List]
    ) -> List[Tuple[int, int, List]]:
        """
        Function to inherit labels from the annotations to the new boundaries.
        Each boundary will have a list of labels from all the annotations.

        Example:
        boundaries = [(0, 2, []), (2, 5, []), (5, 10, [])]
        annotations1 = [(0, 5, 1), (5, 10, 0)]
        annotations2 = [(0, 2, 3), (2, 10, 1)]
        annotations = [annotations1, annotations2]

        output_label_lists = [(0, 2, [1, 3]), (2, 5, [1, 1]), (5, 10, [0, 1])]
        """

        # To keep track of where the latest idx of each spans
        current_idx = [0] * len(annotations)

        for i, boundary in enumerate(boundaries):
            boundary_start, boundary_end, _ = boundary

            # Looping through all annotations, and use the LATEST spans interval contains this boundary
            for idx_annotation, spans in enumerate(annotations):
                spans_start, spans_end, spans_label = spans[current_idx[idx_annotation]]

                # This indicates the span intervals from annotations fully contain the boundary
                if boundary_start >= spans_start and boundary_end <= spans_end:
                    boundaries[i][2].append(spans_label)

                # This indicates the span intervals from annotations is fully utilized -> move on next annotation
                if boundary_end == spans_end:
                    current_idx[idx_annotation] += 1
        return boundaries

    def _merge_spans_with_label(
        self, spans: List[List], merge_label: int
    ) -> List[List]:
        """
        Consider output_spans as a stack, starting with the first span.
        Iterate through the spans, if the last interval of output_spans has the same label
        with the current span (and same as the merge_label), we will extend the last interval
        of output_spans. If different, we append the current interval.
        As the spans are consecutive, last item of output_spans's char_end == current_span's char_start

        Args:
            spans: The span interval labels in sequence tagging task
            merge_label: The int label of the label we concatenate nearby spans together

        Returns:
            output_spans: concatenated spans
        """
        # Edge case handling
        if not spans:
            return spans

        # Initiate the output_spans
        output_spans = [spans[0]]
        _, _, cur_output_label = output_spans[-1]

        # Iterate through the spans
        for span in spans[1:]:
            _, cur_char_end, cur_span_label = span

            # Merging when all labels are the same
            if (cur_span_label == merge_label) and (cur_output_label == merge_label):
                output_spans[-1][1] = cur_char_end

            # Append to output when there're mismatches
            else:
                output_spans.append(span)
                cur_output_label = cur_span_label
        return output_spans

    def _merge_all_spans_with_same_label(self, spans: List[List]) -> List[List]:
        """
        Consider output_spans as a stack, starting with the first span.
        Iterate through the spans, if the last interval of output_spans has the same label
        with the current span, we will extend the last interval of output_spans. If different, we append the current interval.
        As the spans are consecutive, last item of output_spans's char_end == current_span's char_start

        Args:
            spans: The span interval labels in sequence tagging task

        Returns:
            output_spans: concatenated spans
        """
        # Edge case handling
        if not spans:
            return spans

        # Initiate the output_spans
        output_spans = [spans[0]]
        _, _, cur_output_label = output_spans[-1]

        # Iterate through the spans
        for span in spans[1:]:
            _, cur_char_end, cur_span_label = span

            # Merging when all labels are the same
            if cur_span_label == cur_output_label:
                output_spans[-1][1] = cur_char_end

            # Append to output when there're mismatches
            else:
                output_spans.append(span)
                cur_output_label = cur_span_label
        return output_spans

    def _get_disjoint_boundaries(self, annotations: List[List]) -> Tuple[bool, List]:
        """Function to perform intersection aggregation on annotations for each document.

        Step 1:
            For all annotations, we compute all the boundary points that can contain multiple labels.
            Use _get_all_spans_boundaries
        Step 2:
            For each boundaries, we look for all the labels in that range from all the annotations and compile them to a list.
            Use _inherit_labels
        Step 3:
            For the list of labels within a span boundary, perform majority vote to output final label.
            Use _spans_simple_majority_vote
        Step 4:
            Output the finalized labels for each boundary
        Step 5:
            Clean up the output_labels by concatenating ONLY the consecutive NEG spans

        Returns:
        (tie, output_labels): Tuple(Boolean, List)
            tie: Boolean: True if this annotation needs tie-breaking
            output_labels: List of finalized labels for each boundary
        """

        # If there is 0 annotation -> return False, []
        if len(annotations) == 0:
            return False, []

        # If there is 1 annotation -> return False (no tie-breaking needed) & the annotation value
        if len(annotations) == 1:
            return False, annotations[0]

        # From 2+ annotations
        tie_breaking = False

        # All possible span_intervals
        boundaries = self._get_all_span_boundaries(annotations)

        # Inherit all labels from existing annotations
        output_label_lists = self._inherit_labels(boundaries, annotations)

        # Finalized labels
        output_labels = []
        for output_label_list in output_label_lists:
            cur_tie_breaking, label = self._spans_simple_majority_vote(
                output_label_list[2]
            )
            output_labels.append([output_label_list[0], output_label_list[1], label])
            tie_breaking = tie_breaking or cur_tie_breaking

        # Merging spans with negative labels
        output_labels = self._merge_spans_with_label(
            output_labels, self.label_map_raw_negative_label
        )

        return tie_breaking, [tuple(output_label) for output_label in output_labels]

    def _simple_intersection(
        self,
        annotations_array: List[List[Any]],
        source_uid: int,
        random_seed: int = 123,
    ) -> List[Dict]:
        """
        Function to perform intersection aggregation on batches of annotations.
        This function calls `_get_disjoint_boundaries`, which perform aggregation for each document.
        """

        new_annotations = []
        tie_counts = 0

        # initializing random seed
        random.seed(random_seed)

        for annotations in annotations_array:
            # annotation_labels: List[List] contains the lists of labels for all annotations
            # Only labels and no further information for processing
            annotations_labels: List[List] = [
                annotation.label for annotation in annotations
            ]
            tie_breaking, label = self._get_disjoint_boundaries(annotations_labels)

            # Number of datapoints need tie-breaking
            tie_counts += tie_breaking

            new_annotations.append(
                {
                    "x_uid": annotations[0].x_uid,
                    "label": label,
                    "source_uid": source_uid,
                }
            )
        logger.info(f"Aggregating labels: number of ties: {tie_counts}")
        return new_annotations

    def _aggregate_annotations(
        self,
        annotations_array: List[List[Any]],
        source_uid: int,
        strategy: str,
        params: Dict[str, Any],
    ) -> List[Dict]:
        """Function to perform aggregation on batches of annotations"""

        random_seed = params["random_seed"]

        if strategy == SIMPLE_INTERSECTION:
            return self._simple_intersection(annotations_array, source_uid, random_seed)

        return []

    def get_partial_automl_params(self) -> PartialAutoMLParams:
        tune_threshold_on_valid = True if self.cardinality == 2 else False
        return PartialAutoMLParams(
            sampler_config=None,
            use_lf_labels=False,
            discretize_labels=True,
            tune_threshold_on_valid=tune_threshold_on_valid,
        )

    def is_lf_coverage_valid(self, lf_dicts: List[Dict]) -> bool:
        # We cannot train a model with < 2 classes.
        if self.cardinality < 2:
            return False
        unique_lf_classes = set()
        for lf in lf_dicts:
            lf_config = lf["config"]
            if "label" not in lf_config:
                # Task contains multipolar LF, so skip validation
                # Multipolar LFs can vote on any class in the label space and there's no simple way
                # to determine which classes it votes on
                return True
            unique_lf_classes.add(lf_config["label"])
        if len(unique_lf_classes) != self.cardinality:
            return False
        return True

    def replace_abstain_with_negative(
        self, preds: np.ndarray, probs: np.ndarray
    ) -> Tuple[np.ndarray, np.ndarray]:
        new_labels = []
        new_probs = []
        for pred, prob in zip(preds, probs):
            prev_end = 0
            prev_label = None
            sorted_index = sorted(range(len(pred)), key=lambda k: pred[k][0])
            new_label = []
            new_prob = []
            for idx in sorted_index:
                start, end, class_label = pred[idx]
                # remap all abstain to negative
                class_label = (
                    self.label_map_raw_negative_label
                    if class_label == self.raw_unknown_int
                    else class_label
                )
                _, _, class_prob = prob[idx]
                # Auto fill with negative label
                if prev_end < start:
                    if (
                        prev_label is not None
                        and prev_label == self.label_map_raw_negative_label
                    ):
                        new_label[-1][
                            1
                        ] = start  # extend the span if previous label is also negative
                        new_prob[-1][1] = start
                    else:
                        new_label.append(
                            [prev_end, start, self.label_map_raw_negative_label]
                        )
                        new_prob.append(
                            [prev_end, start, self._get_default_raw_negative_prob()]
                        )
                    prev_label = new_label[-1][2]

                # Add current label
                if (
                    prev_label is not None
                    and class_label == prev_label
                    and class_label == self.label_map_raw_negative_label
                ):  # if both current label and previous label are negative, merge them
                    new_label[-1][1] = end
                    new_prob[-1][1] = end
                else:
                    new_label.append([start, end, class_label])
                    new_prob.append([start, end, class_prob])
                prev_end = end
                prev_label = class_label
            # Add last span
            if new_label and new_label[-1][2] == self.label_map_raw_negative_label:
                new_label[-1][1] = sys.maxsize
                new_prob[-1][1] = sys.maxsize
            else:
                new_label.append(
                    [prev_end, sys.maxsize, self.label_map_raw_negative_label]
                )
                new_prob.append(
                    [prev_end, sys.maxsize, self._get_default_raw_negative_prob()]
                )
            new_labels.append(new_label)
            new_probs.append(new_prob)
        return np.array(new_labels), np.array(new_probs)

    def replace_lf_votes(self, lf_votes: pd.DataFrame, new_label: Any) -> pd.DataFrame:
        def replace_span_lf_votes(
            spans: Optional[List[Tuple]],
        ) -> Optional[List[Tuple]]:
            if spans == self.get_raw_unknown_label() or spans is None:
                return spans
            else:
                for i in range(len(spans)):
                    tmp_span: List[int] = list(spans[i])
                    tmp_span[2] = new_label
                    spans[i] = tuple(tmp_span)
                return spans

        return lf_votes.apply(replace_span_lf_votes)

    def compute_confusion_matrix(
        self,
        golds: np.ndarray,
        preds: np.ndarray,
        label_map: Dict[str, int],
        n_classes: int,
    ) -> Optional[Dict[str, Any]]:
        # Overwrite base method as seq label space need special handlement
        return metrics_utils.compute_confusion_matrix(
            golds, preds, label_map, n_classes, confusion_matrix
        )

    def _get_lf_uid_errors(
        self, label_matrix: Any, x_uid_to_ground_truth: Dict[Hashable, Any]
    ) -> DefaultDict:
        lf_uid_to_num_errors: DefaultDict[int, int] = defaultdict(int)
        lf_uids = label_matrix.lf_uids
        x_uids = label_matrix.x_uids
        dense_L = label_matrix.dense(self)
        for x_index, x_uid in enumerate(x_uids):
            gt_spans: List[List[int]] = x_uid_to_ground_truth.get(x_uid, [])
            if not gt_spans:
                continue
            for lf_index, lf_uid in enumerate(lf_uids):
                lf_spans = dense_L[x_index][lf_index]
                if not lf_spans:
                    continue
                lf_uid_to_num_errors[lf_uid] += get_num_lf_span_errors(
                    lf_spans, gt_spans
                )

        return lf_uid_to_num_errors

    def get_lf_uid_errors(
        self,
        label_matrix: Any,
        x_uid_to_ground_truth: pd.DataFrame,
        class_int: Optional[int] = None,
    ) -> DefaultDict:
        return self._get_lf_uid_errors(label_matrix, x_uid_to_ground_truth)

    def compute_clarity_matrix(
        self,
        df: pd.DataFrame,
        gt_labels_col: str,
        lm_preds_col: str,
        model_preds_col: str,
        class_int: Optional[int] = None,
    ) -> pd.DataFrame:
        # Construct the clarity matrix.
        # 3 Rows represent (label model -> incorrect, correct, abstain)
        # 2 Cols represent (end model -> incorrect, correct)
        clarity_matrix = np.zeros((3, 2))
        incorrect_ix, correct_ix, abstain_ix = 0, 1, 2
        lm = df[lm_preds_col]
        gt = df[gt_labels_col]
        model = df[model_preds_col]
        for doc_gt, doc_lm, doc_model in zip(gt, lm, model):
            if doc_gt == self.raw_unknown_int:
                doc_gt = []
            if doc_lm == self.raw_unknown_int:
                doc_lm = []
            if doc_model == self.raw_unknown_int:
                doc_model = []
            (
                correct_model_spans,
                incorrect_model_spans,
                _,
            ) = _get_correct_incorrect_unknown_spans(
                doc_gt,
                doc_model,
                self.label_map_raw_negative_label,
                self.raw_unknown_int,
                class_int,
            )
            (
                correct_lm_spans,
                incorrect_lm_spans,
                unknown_lm_spans,
            ) = _get_correct_incorrect_unknown_spans(
                doc_gt,
                doc_lm,
                self.label_map_raw_negative_label,
                self.raw_unknown_int,
                class_int,
            )
            clarity_matrix[incorrect_ix][incorrect_ix] += len(
                and_two_span_lists(
                    incorrect_lm_spans, incorrect_model_spans, merge_intersects=False
                )
            )
            clarity_matrix[correct_ix][incorrect_ix] += len(
                and_two_span_lists(
                    correct_lm_spans, incorrect_model_spans, merge_intersects=False
                )
            )
            clarity_matrix[abstain_ix][incorrect_ix] += len(
                and_two_span_lists(
                    unknown_lm_spans, incorrect_model_spans, merge_intersects=False
                )
            )

            clarity_matrix[incorrect_ix][correct_ix] += len(
                and_two_span_lists(
                    incorrect_lm_spans, correct_model_spans, merge_intersects=False
                )
            )
            clarity_matrix[correct_ix][correct_ix] += len(
                and_two_span_lists(
                    correct_lm_spans, correct_model_spans, merge_intersects=False
                )
            )
            clarity_matrix[abstain_ix][correct_ix] += len(
                and_two_span_lists(
                    unknown_lm_spans, correct_model_spans, merge_intersects=False
                )
            )

        return clarity_matrix.astype(int)

    def create_analysis_df(
        self,
        df: pd.DataFrame,
        gt_labels_col: str,
        model_probs_col: str,
        class_int: Optional[int] = None,
    ) -> pd.DataFrame:
        unknown_label = self.get_raw_unknown_label()
        if class_int is not None:
            df = df[
                df[gt_labels_col].apply(
                    lambda doc_gt: doc_gt != unknown_label
                    and class_int in [span_gt[2] for span_gt in doc_gt]
                )
            ]
        return df

    def get_analysis_df_required_col(
        self, token_level: bool = False
    ) -> List[Optional[str]]:
        if token_level:
            return [self.tokens_field]
        return []

    def _tokenize_and_align_labels(
        self,
        gt_labels: Dict[str, Any],
        model_preds: Dict[str, Any],
        model_probs: Optional[Dict[str, Any]],
        lm_preds: Dict[str, Any],
        df: pd.DataFrame,
    ) -> Any:
        raw2token = lambda d: self.raw_labels_to_dense_token_labels(
            RawLabels(labels=d), df
        )
        return (
            raw2token(gt_labels),
            raw2token(model_preds),
            raw2token(model_probs) if model_probs else dict(),
            raw2token(lm_preds),
        )

    def _spanize_and_align_labels(
        self,
        gt_labels: Dict[str, Any],
        model_preds: Dict[str, Any],
        model_probs: Optional[Dict[str, Any]],
        lm_preds: Dict[str, Any],
    ) -> Any:
        raw2span = lambda d: self.raw_labels_to_dense_span_labels(RawLabels(labels=d))
        return (
            raw2span(gt_labels),
            raw2span(model_preds),
            raw2span(model_probs) if model_probs else dict(),
            raw2span(lm_preds),
        )

    def get_analysis_df(
        self,
        gt_labels: Dict[str, Any],
        model_preds: Dict[str, Any],
        model_probs: Optional[Dict[str, Any]],
        lm_preds: Dict[str, Any],
        doc_level: bool = False,
        fill_nan_with_negative: bool = True,
    ) -> pd.DataFrame:
        join_method = "left"
        if not doc_level:
            (
                gt_labels,
                model_preds,
                model_probs,
                lm_preds,
            ) = self._spanize_and_align_labels(
                gt_labels, model_preds, model_probs, lm_preds  # type: ignore
            )
            join_method = "outer"

        df = pd.DataFrame(index=gt_labels.keys())
        Column = namedtuple("Column", ["name", "map"])
        cols_to_add = [
            Column(name=GT_LABELS_COL, map=gt_labels),
            Column(name=MODEL_PREDS_COL, map=model_preds),
            Column(
                name=MODEL_PROBS_COL,
                map={
                    x_uid: self.prob_dict_to_prob_array(prob)
                    if prob != self.raw_unknown_int
                    else self.raw_unknown_int
                    for x_uid, prob in model_probs.items()
                }
                if model_probs
                else {},
            ),
            Column(name=LM_PREDS_COL, map=lm_preds),
        ]

        for col in cols_to_add:
            df = df.join(
                pd.DataFrame({col.name: list(col.map.values())}, index=col.map.keys()),
                how=join_method,
            )
        df.loc[:, df.columns != MODEL_PROBS_COL] = df.loc[
            :, df.columns != MODEL_PROBS_COL
        ].fillna(
            self.label_map_raw_negative_label
            if fill_nan_with_negative
            else self.raw_unknown_int
        )
        if fill_nan_with_negative:
            default_prob = self._get_default_raw_negative_prob()
            df.loc[df[MODEL_PROBS_COL].isnull(), [MODEL_PROBS_COL]] = pd.DataFrame(
                df.loc[df[MODEL_PROBS_COL].isnull(), MODEL_PROBS_COL].apply(
                    lambda x: default_prob
                )
            )
        return df

    def process_cluster_input_dataframe(
        self,
        df: pd.DataFrame,
        input_field: str,
        output_field: Optional[str] = None,
        candidate_field: Optional[str] = None,
        gt_field: Optional[str] = None,
        tsne_x_col: Optional[str] = None,
        tsne_y_col: Optional[str] = None,
        deserialize_columns: bool = False,
    ) -> pd.DataFrame:
        """Process input dataframe to effectively convert it into a
        single label classification problem, based on the candidate field.

        This process 'unrolls' candidate embeddings into a flat list (which has
        a unique identifier, similar to extraction IE tasks), that is used in
        cluster view (i.e. the unique_id here is treated as x_uids in cluster view)
        """
        if candidate_field is None:
            err_msg = (
                "Sequence Tagging does not support embeddings without candidate field. "
                "Use EmbeddingCandidateFeaturizer with a candidate-based Featurizer instead."
            )
            raise NotSupportedException(detail=err_msg, user_friendly_message=err_msg)

        if output_field is not None and deserialize_columns:
            # deserialize input/output/canidate columns for seq tagging if needed
            embedding_serialized_col_types = {
                col: df.attrs["serialized_col_types"][col]
                for col in [input_field, output_field, candidate_field]
                if col in df.attrs["serialized_col_types"]
            }
            df = deserialize_dataframe_series(df, embedding_serialized_col_types)

        # Drop all rows that have an empty list for candidate_field
        df = df[df[candidate_field].map(len) > 0]
        if df.empty:
            return df

        merged_field = "__temp_merged"
        unique_id = "__unique_id"
        cols_to_merge = [
            col
            for col in [candidate_field, output_field, tsne_x_col, tsne_y_col]
            if col
        ]
        df[merged_field] = df.apply(
            lambda x: list(zip(*[x[col] for col in cols_to_merge])), axis=1
        )

        # Exploded df
        df_exploded = df.explode(merged_field)

        # Drop merged field since it's no longer from DF, and it is modified in place
        df = df.drop(columns=[merged_field])

        # Unroll each part of the merged field
        df_exploded[unique_id] = df_exploded.apply(
            lambda x: f"{x.name},{x[merged_field][0]['start']},{x[merged_field][0]['end']},{candidate_field}",
            axis=1,
        )
        if gt_field is not None:
            df_exploded[gt_field] = df_exploded.apply(
                lambda x: self._get_matching_gt(
                    x, candidate_col=merged_field, gt_field=gt_field
                ),
                axis=1,
            )

        df_exploded[input_field] = df_exploded.apply(
            lambda x: x[input_field][
                x[merged_field][0]["start"] : x[merged_field][0]["end"] + 1
            ],
            axis=1,
        )

        if output_field:
            df_exploded[output_field] = df_exploded.apply(
                lambda x: x[merged_field][cols_to_merge.index(output_field)], axis=1
            )

        if tsne_x_col and tsne_y_col:
            df_exploded[tsne_x_col] = df_exploded.apply(
                lambda x: x[merged_field][cols_to_merge.index(tsne_x_col)], axis=1
            )
            df_exploded[tsne_y_col] = df_exploded.apply(
                lambda x: x[merged_field][cols_to_merge.index(tsne_y_col)], axis=1
            )

        # Set index as unique_ids
        df_exploded = df_exploded.set_index(unique_id)
        return df_exploded

    def _is_overlapping(self, s1: int, e1: int, s2: int, e2: int) -> bool:
        """Checks if two spans overlap"""
        return max(s1, s2) <= min(e1, e2)

    def _get_matching_gt(
        self, row: pd.Series, candidate_col: str, gt_field: str
    ) -> int:
        """Given a DataFrame row, match candidates with nearest GT labels if possible"""
        offsets = row[candidate_col][0]
        cand_start = offsets["start"]
        cand_end = offsets["end"]
        gts = row[gt_field]
        if gts:
            for gt_start, gt_end, gt_label in gts:
                if self._is_overlapping(gt_start, gt_end, cand_start, cand_end):
                    # candidate span is within GT span offsets
                    if gt_start <= cand_start and gt_end >= cand_end:
                        intersection = cand_end - cand_start

                    # GT span is within candidate span offsets
                    elif cand_start <= gt_start and cand_end >= gt_end:
                        intersection = gt_end - gt_start

                    # candidate span offsets extend beyond GT span
                    elif gt_start <= cand_start <= gt_end:
                        intersection = gt_end - cand_start

                    # GT span offsets extend beyond candidate span
                    elif cand_start <= gt_start <= cand_end:
                        intersection = cand_end - gt_start

                    union = max(gt_start, gt_end, cand_start, cand_end) - min(
                        gt_start, gt_end, cand_start, cand_end
                    )

                    jaccard = intersection / union
                    if jaccard >= 0.5:
                        # candidate overlaps with GT offets
                        return gt_label
            # candidates don't overlap with any GT offets

        # HACK: We return -1 to indicate unlabeled data, since we are
        # basically converting from sequence to single label space for cluster view
        return -1

    def aggregate_tsne_embeddings(
        self,
        df: pd.DataFrame,
        coordinates_df: pd.DataFrame,
        x_col: str,
        y_col: str,
        candidate_field: Optional[str] = None,
    ) -> pd.DataFrame:
        # Re-roll TSNE embeddings
        current_idx = 0
        grouped_tsne_x = []
        grouped_tsne_y = []
        for _, row in df.iterrows():
            noun_lens = len(row[candidate_field])
            end_idx = current_idx + noun_lens
            grouped_tsne_x.append(list(coordinates_df[current_idx:end_idx][x_col]))
            grouped_tsne_y.append(list(coordinates_df[current_idx:end_idx][y_col]))
            current_idx = end_idx

        df[x_col] = grouped_tsne_x
        df[y_col] = grouped_tsne_y
        return df

    def get_cluster_filter_mask(
        self, x_uids: List[str], cluster_x_uids: List[str]
    ) -> pd.Series:
        x_uid_mask = []
        for x_uid in x_uids:
            x_uid_in_cluster = False
            for cluster_x_uid in cluster_x_uids:
                if cluster_x_uid.split(",")[0] == x_uid:
                    x_uid_in_cluster = True
            x_uid_mask.append(x_uid_in_cluster)
        return pd.Series(x_uid_mask)

    def transform_model_predictions(
        self,
        raw_model_predictions: List[Dict[str, Any]],
        inverse_label_map: Dict[int, str],
        model_uid: int,
        fetch_span_text: bool = False,
        df: pd.DataFrame = None,
    ) -> Dict[str, Any]:
        """We go from a structure that looks like this:
            raw_model_predictions = [
                    {
                        "x_uid": "doc::10",
                        "prediction_int": DOC10_PREDS,
                        "prediction_probs": DOC10_PROBS,
                    },
                    {
                        "x_uid": "doc::5",
                        "prediction_int": DOC5_PREDS,
                        "prediction_probs": DOC5_PROBS,
                    },
                    {
                        "x_uid": "doc::90",
                        "prediction_int": DOC90_PREDS,
                        "prediction_probs": DOC90_PROBS,
                    },
                ]

        to something that looks like this
        model_predictions = {
            "doc::10": {
                "1": [
                    [
                        0,
                        1,
                        {
                            "start": 0,
                            "end": 1,
                            "raw_label": 1,
                            "label": "POSITIVE",
                            "type": "model",
                            "variant": "sequenceModelVotes",
                            "title": "Model 1",
                            "description": ["Label: POSITIVE", "Span: I", "Confidence: 81.2%"],
                        },
                    ],
                    [
                        1,
                        5,
                        {
                            "start": 1,
                            "end": 5,
                            "raw_label": 0,
                            "label": "NEGATIVE",
                            "type": "model",
                            "variant": "sequenceModelVotes",
                            "title": "Model 1",
                            "description": ["Label: NEGATIVE", "Span: nc is ", "Confidence: 12.0%"],
                        },
                    ],
                ]
            },
            "doc::5": {
                "1": [
                    [
                        0,
                        5,
                        {
                            "start": 0,
                            "end": 5,
                            "raw_label": 0,
                            "label": "NEGATIVE",
                            "type": "model",
                            "variant": "sequenceModelVotes",
                            "title": "Model 1",
                            "description": ["Label: NEGATIVE", "Span: Amaze", "Confidence: 39.0%"],
                        },
                    ],
                    [
                        5,
                        7,
                        {
                            "start": 5,
                            "end": 7,
                            "raw_label": 1,
                            "label": "POSITIVE",
                            "type": "model",
                            "variant": "sequenceModelVotes",
                            "title": "Model 1",
                            "description": ["Label: POSITIVE", "Span: ge", "Confidence: 90.0%"],
                        },
                    ],
                ]
            },
            "doc::90": {
                "1": [
                    [
                        0,
                        2,
                        {
                            "start": 0,
                            "end": 2,
                            "raw_label": 0,
                            "label": "NEGATIVE",
                            "type": "model",
                            "variant": "sequenceModelVotes",
                            "title": "Model 1",
                            "description": ["Label: NEGATIVE", "Span: qw", "Confidence: 40.0%"],
                        },
                    ],
                    [
                        2,
                        3,
                        {
                            "start": 2,
                            "end": 3,
                            "raw_label": 1,
                            "label": "POSITIVE",
                            "type": "model",
                            "variant": "sequenceModelVotes",
                            "title": "Model 1",
                            "description": ["Label: POSITIVE", "Span: !", "Confidence: 24.0%"],
                        },
                    ],
                ]
            },
        }
        """

        model_predictions: Dict[str, Any] = {}
        default_dict = {
            HighlightConfigFieldNames.TYPE.value: FilterTypesForHighlight.MODEL.value,
            HighlightConfigFieldNames.VARIANT.value: HighlightVariant.MODEL_VOTES.value,
            HighlightConfigFieldNames.TITLE.value: "Model " + str(model_uid),
        }

        fetch_span_text = fetch_span_text and df is not None

        for doc_result in raw_model_predictions:
            x_uid = doc_result.pop("x_uid")
            text = df.at[x_uid, self.text_col] if fetch_span_text else None
            labels = doc_result[PREDICTION_LABEL_FIELD]
            _, _, probs = list(zip(*doc_result[PREDICTION_CONFIDENCE_FIELD]))
            if labels:
                intervals = self._transform_span_highlight_metadata(
                    default_dict, inverse_label_map, labels, text, probs
                )
            else:
                intervals = []
            model_predictions.setdefault(x_uid, {}).setdefault(model_uid, []).extend(
                intervals
            )
        return model_predictions

    def transform_lf_labels(
        self,
        raw_lf_labels: List[Dict[str, Any]],
        inverse_label_map: Dict[int, str],
        lf_name_map: Dict[int, str],
        fetch_span_text: bool = False,
        df: pd.DataFrame = None,
    ) -> Dict[str, Any]:
        """Transform from
        raw_lf_labels = [
            {"x_uid": "doc::5", "lf_uid": 1, "label": [[0, 3, 0], [4, 17, 0], [18, 28, 0], [29, 100, 0]]},
            {"x_uid": "doc::5", "lf_uid": 2, "label": [[0, 3, 1], [4, 5, 1]]},
            {"x_uid": "doc::10", "lf_uid": 1, "label": [[0, 10, 1]]},
        ]

        To
        lf_labels = {
            "doc::5": {
                1: [
                    [
                        0,
                        3,
                        {
                            "start": 0,
                            "end": 3,
                            "raw_label": 0,
                            "label": "NEGATIVE",
                            "type": "lf",
                            "variant": "sequenceLFVotes",
                            "title": "REG-abc",
                            "description": ["Label: NEGATIVE", "Span: her"],
                        },
                    ],
                    [
                        4,
                        17,
                        {
                            "start": 4,
                            "end": 17,
                            "raw_label": 0,
                            "label": "NEGATIVE",
                            "type": "lf",
                            "variant": "sequenceLFVotes",
                            "title": "REG-abc",
                            "description": ["Label: NEGATIVE", "Span: name is Bob"],
                        },
                    ],
                    [
                        18,
                        28,
                        {
                            "start": 18,
                            "end": 28,
                            "raw_label": 0,
                            "label": "NEGATIVE",
                            "type": "lf",
                            "variant": "sequenceLFVotes",
                            "title": "REG-abc",
                            "description": ["Label: NEGATIVE", "Span: Dr. Bubbles"],
                        },
                    ],
                    [
                        29,
                        100,
                        {
                            "start": 29,
                            "end": 100,
                            "raw_label": 0,
                            "label": "NEGATIVE",
                            "type": "lf",
                            "variant": "sequenceLFVotes",
                            "title": "REG-abc",
                            "description": ["Label: NEGATIVE". "Span: This one is really long so truncat.."],
                        },
                    ],
                ],
                2: [
                    [
                        0,
                        3,
                        {
                            "start": 0,
                            "end": 3,
                            "raw_label": 1,
                            "label": "NEGATIVE",
                            "type": "lf",
                            "variant": "sequenceLFVotes",
                            "title": "KEY-match",
                            "description": ["Label: NEGATIVE", "Span: her"],
                        },
                    ],
                    [
                        4,
                        5,
                        {
                            "start": 4,
                            "end": 5,
                            "raw_label": 1,
                            "label": "NEGATIVE",
                            "type": "lf",
                            "variant": "sequenceLFVotes",
                            "title": "KEY-match",
                            "description": ["Label: NEGATIVE", "Span: f"],
                        },
                    ],
                ],
            },
            "doc::10": {
                1: [
                    [
                        0,
                        10,
                        {
                            "start": 0,
                            "end": 10,
                            "raw_label": 1,
                            "label": "NEGATIVE",
                            "type": "lf",
                            "variant": "sequenceLFVotes",
                            "title": "REG-abc",
                            "description": ["Label: NEGATIVE", "Span: Welcome"],
                        },
                    ]
                ]
            },
        }
        """
        lf_labels: Dict[str, Any] = {}
        default_dict = {
            HighlightConfigFieldNames.TYPE.value: FilterTypesForHighlight.LF.value,
            HighlightConfigFieldNames.VARIANT.value: HighlightVariant.SEQUENCE_LF_VOTES.value,
        }

        fetch_span_text = fetch_span_text and df is not None

        for result in raw_lf_labels:
            x_uid = result.pop("x_uid")
            text = df.at[x_uid, self.text_col] if fetch_span_text else None
            labels = result.pop("label")
            lf_uid = result.pop("lf_uid")
            lf_dict = default_dict.copy()
            lf_dict[HighlightConfigFieldNames.TITLE.value] = lf_name_map[lf_uid]
            if labels:
                intervals = self._transform_span_highlight_metadata(
                    lf_dict, inverse_label_map, labels, text
                )
            else:
                intervals = []
            lf_labels.setdefault(x_uid, {}).setdefault(lf_uid, []).extend(intervals)
        return lf_labels

    def transform_training_set_labels(
        self,
        raw_ts_labels: Tuple[list, list, Any],  # Any here is LabelFetchingMetadata
        inverse_label_map: Dict[int, str],
        ts_uid: int,
        fetch_span_text: bool = False,
        df: pd.DataFrame = None,
    ) -> Dict[str, Any]:
        """Go from:
        raw_ts_labels = [
            ["doc::10", "doc::5"],
            [[[0, 15, 1]], [[0, 1, 1], [2, 6, 0], [7, 13, 1]],],
            {}
        ]

        To this:
        ts_labels = {
            "doc::10": {
                "1": [
                    [
                        0,
                        15,
                        {
                            "start": 0,
                            "end": 15,
                            "raw_label": 1,
                            "label": "POSITIVE",
                            "type": "training_set",
                            "variant": "sequenceTrainingSetVotes",
                            "title": "Training set 1",
                            "description": ["Label: POSITIVE", "Span: 15character thing"],
                        },
                    ]
                ]
            },
            "doc::5": {
                "1": [
                    [
                        0,
                        1,
                        {
                            "start": 0,
                            "end": 1,
                            "raw_label": 1,
                            "label": "POSITIVE",
                            "type": "training_set",
                            "variant": "sequenceTrainingSetVotes",
                            "title": "Training set 1",
                            "description": ["Label: POSITIVE", "Span: a"],
                        },
                    ],
                    [
                        2,
                        6,
                        {
                            "start": 2,
                            "end": 6,
                            "raw_label": 0,
                            "label": "NEGATIVE",
                            "type": "training_set",
                            "variant": "sequenceTrainingSetVotes",
                            "title": "Training set 1",
                            "description": ["Label: NEGATIVE", "Span: help"],
                        },
                    ],
                    [
                        7,
                        13,
                        {
                            "start": 7,
                            "end": 13,
                            "raw_label": 1,
                            "label": "POSITIVE",
                            "type": "training_set",
                            "variant": "sequenceTrainingSetVotes",
                            "title": "Training set 1",
                            "description": ["Label: POSITIVE", "Span: octopus"],
                        },
                    ],
                ]
            },
        }
        """
        ts_labels: Dict[str, Any] = {}
        default_dict = {
            HighlightConfigFieldNames.TYPE.value: FilterTypesForHighlight.TRAINING_SET.value,
            HighlightConfigFieldNames.VARIANT.value: HighlightVariant.TRAINING_SET_VOTES.value,
            HighlightConfigFieldNames.TITLE.value: f"Training set {ts_uid}",
        }
        fetch_span_text = fetch_span_text and df is not None

        for x_uid, labels in zip(raw_ts_labels[0], raw_ts_labels[1]):
            text = df.at[x_uid, self.text_col] if fetch_span_text else None
            if labels:
                intervals = self._transform_span_highlight_metadata(
                    default_dict, inverse_label_map, labels, text
                )
            else:
                intervals = []
            ts_labels.setdefault(x_uid, {}).setdefault(ts_uid, []).extend(intervals)
        return ts_labels

    def transform_gt_labels(
        self,
        raw_gt_labels: Tuple[List[str], List[Any]],
        inverse_label_map: Dict[int, str],
        fetch_span_text: bool = False,
        df: pd.DataFrame = None,
    ) -> Dict[str, Any]:
        """Transform from
        raw_gt_labels = [
            ["doc::10", "doc::90"],
            [[[0, 14, 1]], [[0, 11, 1]]],
            {}
        ]

        To:
        gt_labels = {
            "doc::10": [
                [
                    0,
                    14,
                    {
                        "start": 0,
                        "end": 14,
                        "raw_label": 1,
                        "label": "POSITIVE",
                        "type": "ground_truth",
                        "variant": "annotatedSpan",
                        "title": "Ground truth",
                        "description": ["Label: POSITIVE", "Span: something"],
                    },
                ]
            ],
            "doc::90": [
                [
                    0,
                    11,
                    {
                        "start": 0,
                        "end": 11,
                        "raw_label": 1,
                        "label": "POSITIVE",
                        "type": "ground_truth",
                        "variant": "annotatedSpan",
                        "title": "Ground truth",
                        "description": ["Label: POSITIVE", "Span: text here"],
                    },
                ]
            ],
        }
        """

        gt_labels: Dict[str, Any] = {}

        default_dict = {
            HighlightConfigFieldNames.TYPE.value: FilterTypesForHighlight.GROUND_TRUTH.value,
            HighlightConfigFieldNames.VARIANT.value: HighlightVariant.ANNOTATED_SPAN.value,
            HighlightConfigFieldNames.TITLE.value: "Ground truth",
        }
        fetch_span_text = fetch_span_text and df is not None

        for x_uid, labels in zip(raw_gt_labels[0], raw_gt_labels[1]):
            text = df.at[x_uid, self.text_col] if fetch_span_text else None
            if labels:
                intervals = self._transform_span_highlight_metadata(
                    default_dict, inverse_label_map, labels, text
                )
            else:
                intervals = []
            gt_labels.setdefault(x_uid, []).extend(intervals)
        return gt_labels

    @staticmethod
    def _transform_span_highlight_metadata(
        default_dict: Dict[str, Any],
        inverse_label_map: Dict[int, str],
        labels: List[Any],
        text: Optional[str] = None,
        probs: Optional[List[Any]] = None,
    ) -> List[Any]:
        char_starts, char_ends, label_ints = list(zip(*labels))
        intervals = [default_dict.copy() for _ in range(len(labels))]
        label_strs = [inverse_label_map[label_int] for label_int in label_ints]
        if text:
            tooltips = [
                [
                    f"Label: {label_str}",
                    f"Span: {truncate_span_string(text[start:end])}",
                ]
                for start, end, label_str in zip(char_starts, char_ends, label_strs)
            ]
        else:
            tooltips = [[f"Label: {label_str}"] for label_str in label_strs]
        if probs:
            for tooltip, prob in zip(tooltips, probs):
                tooltip.append(f"Confidence: {to_rounded_percent(prob)}")

        for start, end, label_int, label_str, interval, tooltip_items in zip(
            char_starts, char_ends, label_ints, label_strs, intervals, tooltips
        ):
            interval.update(
                dict(
                    zip(
                        HIGHLIGHT_CONFIG_KEYS,
                        (start, end, label_int, label_str, tooltip_items),
                    )
                )
            )
        return list(zip(char_starts, char_ends, intervals))

    def compute_gt_label_distribution(
        self, gt_labels: LabelsType, user_formatted: bool = False
    ) -> Dict[Union[str, int], int]:
        """Compute the distribution of ground truth labels for each span"""
        gt_label_distribution: Dict[str, int] = defaultdict(int)
        for span_gts in gt_labels.values():
            for span_gt in span_gts:
                gt_label_distribution[span_gt[2]] += 1
        if user_formatted:
            return {
                str(v): gt_label_distribution[k] for k, v in self.inv_label_map.items()
            }
        else:
            return {k: gt_label_distribution[k] for k, v in self.inv_label_map.items()}

    def support_custom_metrics(self) -> bool:
        return False
