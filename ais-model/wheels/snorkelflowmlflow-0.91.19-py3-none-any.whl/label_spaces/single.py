import copy
import hashlib
import random
import sys
from collections import Counter, defaultdict
from typing import (
    Any,
    Callable,
    DefaultDict,
    Dict,
    Generator,
    List,
    Optional,
    Set,
    Tuple,
    Union,
)

import numpy as np
import pandas as pd
import sparse

import label_spaces.common.constants as constants
from api_utils.exceptions import NotSupportedException, ServerError
from label_spaces.base import (
    AggregateScoreStrategy,
    LabelSpace,
    LabelSpaceConfig,
    LabelsType,
    LabelValidationError,
    PartialAutoMLParams,
    RawLabels,
    ThresholdHolder,
    TrainingSetStats,
    convert_generator_to_array,
    probs_to_preds_with_threshold_flat,
)
from label_spaces.common import metrics_utils
from label_spaces.common.sparse_dense_utils import (
    make_singlelabel_lfs_dense,
    onehot,
    sparse_any,
)
from label_spaces.mixins import (
    ActiveLearningMixin,
    AutoTuneMixin,
    LFQualityMixin,
    MarginFilterMixin,
    TrainingSetStatsMixin,
)
from snorkelflow.utils.logging import get_logger
from snorkelflow.utils.performance_profiling import PerfTimeLog

logger = get_logger("Label Space")

OPENAPI_RAW_LABEL_TYPE = int
OPENAPI_USER_LABEL_TYPE = str
SIMPLE_MAJORITY = "simple-majority"


class SingleLabelSpace(
    TrainingSetStatsMixin,
    ActiveLearningMixin,
    LabelSpace,
    LFQualityMixin,
    MarginFilterMixin,
    AutoTuneMixin,
):
    """Manages labels and metrics for single-label classification."""

    _is_unknown_in_label_map = True
    default_aggregation_strategy = SIMPLE_MAJORITY
    supported_aggregation_strategies = [SIMPLE_MAJORITY]
    compression_threshold: int = 192_000_000
    is_multi_label = False

    def config(self) -> LabelSpaceConfig:
        return LabelSpaceConfig(
            cls_name=self.__class__.__name__,
            kwargs=dict(
                label_map=self.label_map, label_descriptions=self._label_descriptions
            ),
        )

    @staticmethod
    def get_raw_unknown_label() -> Any:
        return -1

    @staticmethod
    def get_raw_dummy_label() -> Any:
        return 0

    def _raise_error_incorrect_label_format(
        self,
        x_uid: str,
        label: Any,
        user_format: bool = False,
        detailed_error: Optional[str] = None,
    ) -> None:
        label_map_keys, label_map_values = zip(*self.label_map.items())
        valid_labels = set(label_map_values) - {self.get_raw_unknown_label()}
        if user_format:
            valid_labels = {
                label_map_keys[label_map_values.index(e)] for e in valid_labels
            }
        raise LabelValidationError(
            f"Label {label} for x_uid {x_uid} is incorrectly formatted. Must be one of {valid_labels}"
        )

    @classmethod
    def raw_label_type(cls) -> type:
        return int

    @classmethod
    def user_label_type(cls) -> type:
        return str

    def parse_postprocessed_spans(
        self, postprocessed_spans: List[metrics_utils.PostprocessedSpan]
    ) -> RawLabels:
        raw_labels: Dict[str, Any] = {}
        raw_probs: Dict[str, Any] = {}
        for span in postprocessed_spans:
            raw_labels[span.x_uid] = span.label
            if span.label_probs:
                raw_probs[span.x_uid] = self._prob_arrays_to_prob_dicts(
                    span.label_probs, self.cardinality
                )
        return RawLabels(raw_labels, raw_probs if raw_probs else None)

    def copy_with_label_map(self, label_map: Dict[str, int]) -> "SingleLabelSpace":
        if self.raw_unknown_int not in label_map.values():
            label_map = {"UNKNOWN": self.raw_unknown_int, **label_map}
        label_descriptions = {
            k: v for k, v in self.label_descriptions.items() if k in label_map
        }
        return self.__class__(
            label_map=label_map, label_descriptions=label_descriptions
        )

    def _make_sparse_L_tensor(
        self, sparse_rows: List[Any], lf_num: int
    ) -> sparse._coo.COO:
        if len(sparse_rows) == 0:
            return (y for y in [sparse_rows])

        rows = []
        lfs = []
        votes = []
        for x_uid, lf_votes in enumerate(sparse_rows):
            rows += [x_uid] * len(lf_votes)
            lfs += list(lf_votes.keys())
            votes += list(lf_votes.values())

        rows, lfs, votes = np.array(rows), np.array(lfs), np.array(votes)
        non_abstains = votes != self.raw_unknown_int
        rows, lfs, votes = rows[non_abstains], lfs[non_abstains], votes[non_abstains]  # type: ignore
        L = sparse.COO(
            coords=(rows, lfs, votes),
            data=np.uint64(1),
            shape=(len(sparse_rows), lf_num, self.cardinality),
            fill_value=0,
        )
        return L

    def _compute_L(
        self,
        label_matrix: Any,  # To avoid importing LabelMatrix
        df: Optional[pd.DataFrame] = None,
        batch_size: int = sys.maxsize,
        random_seed: int = 123,
        max_num_examples: Optional[int] = None,
        x_uids_gt: Optional[Set] = None,
        compute_num_datapoints: bool = False,
    ) -> Tuple[List[str], Generator, int]:
        perf_time_log = PerfTimeLog("Compute L matrix for SingleLabelSpace")

        x_uids = label_matrix.x_uids
        sparse_matrix = label_matrix.sparse_rows
        n_labeled_datapoints = 0
        if compute_num_datapoints:
            n_labeled_datapoints = int(
                (label_matrix.dense(self).max(axis=1) > self.raw_unknown_int).sum()
            )

        perf_time_log.update("Take label matrix attributes and compute num datapoints")

        if max_num_examples is not None:
            if len(sparse_matrix) > max_num_examples:
                logger.info(
                    f"Subsampling dense_matrix from {len(sparse_matrix)} to {max_num_examples} rows."
                )
                samples_to_keep = self.subsample_uids(
                    x_uids, max_num_examples, random_seed, x_uids_gt=x_uids_gt
                )

                sparse_matrix = [sparse_matrix[i] for i in samples_to_keep]
                x_uids = [x_uids[i] for i in samples_to_keep]

                perf_time_log.update("Take random sample")

        L_sparse_generator = (
            self._make_sparse_L_tensor(
                sparse_matrix[i : i + batch_size], len(label_matrix.lf_uids)
            )
            for i in range(0, len(sparse_matrix), batch_size)
        )
        perf_time_log.update("Make sparse L generator")

        logger.debug(perf_time_log.pretty_summary())

        return (x_uids, L_sparse_generator, n_labeled_datapoints)

    def _compute_label_model_tuning_ground_truth(
        self,
        ground_truth: Dict[str, Any],
        lm_uids: List[Any],
        df: Optional[pd.DataFrame] = None,
    ) -> np.ndarray:
        ground_truth_for_lm = np.array(
            [ground_truth.get(uid, self.raw_unknown_int) for uid in lm_uids], dtype=int
        )

        return ground_truth_for_lm

    def get_user_unknown_pred_conf(self) -> Tuple[Any, Any]:
        inv_label_map = {v: k for k, v in self.label_map.items()}
        return inv_label_map[self.raw_unknown_int], 0.0

    def _hash(self, i: int) -> int:
        """Deterministic hash function. From Snorkel OSS.
        https://github.com/snorkel-team/snorkel/blob/v0.9.6/snorkel/utils/core.py
        """
        byte_string = str(i).encode("utf-8")
        return int(hashlib.sha1(byte_string).hexdigest(), 16)

    def _compute_probs_and_abstains_from_lm(
        self,
        lm_x_uids: List[str],
        lm_probs: np.ndarray,
        lm_abstains: np.ndarray,
        df: Optional[pd.DataFrame] = None,
    ) -> Tuple[List[str], List[Any], List[bool], Optional[List[Any]]]:
        lm_abstains_list = lm_abstains.tolist()
        probs_size = lm_probs.size
        if probs_size >= self.compression_threshold:
            # We no longer use Redis to store the return for probs, but we
            # still need this compression for DB storage.
            logger.info(
                f"probs matrix {probs_size} is too large. Compressing to one-hot."
            )
            # Convert probs to a [num_datapoints, cardinality] matrix
            labels_arr = np.empty(lm_probs.shape[0], dtype=int)
            logger.info(f"create empty array with shape of {labels_arr.shape}")
            # We expect a number of ties using majority vote, so use pseudo-random
            # tie-breaking among all entries within epsilon of the max probability
            # Same algorithm used in Snorkel OSS
            # https://github.com/snorkel-team/snorkel/blob/v0.9.6/snorkel/utils/core.py#L63

            logger.info(f"compute abs")
            np.abs(lm_probs - lm_probs.max(axis=1, keepdims=True), out=lm_probs)
            for i in range(lm_probs.shape[0]):
                max_idxs = np.where(lm_probs[i, :] < 1e-6)[0]
                labels_arr[i] = max_idxs[self._hash(i) % len(max_idxs)]
            probs_list = [{label: 1.0} for label in labels_arr]
        else:
            probs_list = lm_probs.tolist()
        return lm_x_uids, probs_list, lm_abstains_list, None

    def get_compute_metrics_required_columns(self, metrics: List[str]) -> List[str]:
        return []

    def _compute_metrics(
        self,
        ground_truth: RawLabels,
        prediction: RawLabels,
        metrics: List[str],
        custom_metric_funcs: Dict[str, Callable],
        df: Optional[pd.DataFrame] = None,
        df_uid_col: Optional[str] = None,
        extra_params: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        if extra_params is None:
            extra_params = {}
        d_probs = (
            self.to_array_probs(prediction.probs)
            if getattr(prediction, "probs")
            else None
        )
        d_golds = ground_truth.labels
        d_preds = prediction.labels
        golds, preds, probs = [], [], []
        for x_uid in d_preds.keys():
            if (
                d_golds.get(x_uid, self.get_raw_unknown_label())
                == self.get_raw_unknown_label()
            ):
                continue
            golds.append(d_golds.get(x_uid, self.get_raw_unknown_label()))
            if d_probs:
                probs.append(d_probs[x_uid])  # type: ignore
            preds.append(d_preds[x_uid])
        logger.info(
            f"Filtered unknown ground truth labels. Computing metrics using {len(golds)} ground truth labels"
        )
        return metrics_utils.compute_classification_metrics(
            np.array(golds),
            np.array(preds),
            self.label_map,
            metrics,
            custom_metric_funcs,
            np.array(probs) if probs else None,
            self.get_raw_unknown_label(),
        )

    def get_lf_uid_errors(
        self,
        label_matrix: Any,
        x_uid_to_ground_truth: pd.DataFrame,
        class_int: Optional[int] = None,
    ) -> DefaultDict:
        lf_uids = label_matrix.lf_uids
        lf_uid_to_num_errors: DefaultDict[int, int] = defaultdict(int)
        lm_x_uids, L_sparse, _ = self.compute_L(label_matrix)
        L_sparse_array = convert_generator_to_array(L_sparse, do_sparse=True)
        L_dense_array = make_singlelabel_lfs_dense(L_sparse_array)
        # LF matrix has zero rows
        if len(L_dense_array) == 0:
            return lf_uid_to_num_errors

        num_lfs = len(lf_uids)

        # Construct [n,] mask indicating whether x_uids are valid
        mask_valid_x_uids = np.isin(lm_x_uids, list(x_uid_to_ground_truth.keys()))
        # Tile to [n,k] mask
        mask_valid_x_uids = np.tile(mask_valid_x_uids, (num_lfs, 1)).T
        # Construct [n,k] mask indicating whether a particular LF voted
        mask_lf_voted = L_dense_array != -1
        # Construct [n,k] mask indicating whether LF voted incorrectly
        gt_labels = np.array(
            [x_uid_to_ground_truth.get(x_uid, -1) for x_uid in lm_x_uids]
        )
        tiled_gt_labels = np.tile(gt_labels, (num_lfs, 1)).T
        mask_incorrect_lf = L_dense_array != tiled_gt_labels

        # Compute incorrect counts by lf_idx as [k,] array
        incorrect_counts = (mask_valid_x_uids & mask_lf_voted & mask_incorrect_lf).sum(
            axis=0
        )

        # Aggregate incorrect counts by lf_uid for this pkg_uid + split
        for lf_idx, count in enumerate(incorrect_counts):
            lf_uid = lf_uids[lf_idx]
            lf_uid_to_num_errors[lf_uid] += count

        return lf_uid_to_num_errors

    def validate_raw_labels(self, raw_labels: RawLabels) -> None:
        # Raw labels should only include labels that are not unknown in DB
        valid_labels = set(self.label_map.values())
        valid_labels.remove(self.get_raw_unknown_label())
        valid_str_labels = {str(label) for label in valid_labels}
        for x_uid, label in raw_labels.labels.items():
            if type(label) is not int or label not in valid_labels:
                self._raise_error_incorrect_label_format(x_uid, label)
            if not getattr(raw_labels, "probs"):
                continue
            probs = raw_labels.probs[x_uid]  # type: ignore
            if type(probs) is not dict:
                self._raise_error_incorrect_probs_format(x_uid, probs)
            for class_key in probs.keys():
                if class_key not in valid_str_labels:
                    self._raise_error_incorrect_probs_format(x_uid, probs)

    @staticmethod
    def extract_values_from_input_label(label: Any) -> List[str]:
        if (
            type(label) is not int
            and type(label) is not str
            and type(label) is not bool
        ):
            raise ValueError
        return [str(label)]

    @staticmethod
    def example_user_input_label() -> Any:
        return "example_label"

    def raw_probs_to_array_probs(self, raw_probs: List[Any]) -> List[Any]:
        try:
            # new format for probs is array, early check to avoid unnecessary computation
            if not isinstance(raw_probs[0], dict):
                return raw_probs
        except (TypeError, KeyError, IndexError):
            pass
        return [self.prob_dict_to_prob_array(probs_dict) for probs_dict in raw_probs]

    def raw_probs_to_enumerate_array_probs(
        self, raw_probs: List[Any], **kwargs: Dict[str, Any]
    ) -> List[List[float]]:
        return self.raw_probs_to_array_probs(raw_probs)

    def aggregate_prediction_scores(
        self, scores: List[Any], aggregation: AggregateScoreStrategy
    ) -> List[Any]:
        return scores

    def raw_probs_to_confidences(self, raw_probs: List[Any]) -> List[Any]:
        return [self.probs_dict_to_confidence(probs_dict) for probs_dict in raw_probs]

    def raw_probs_to_entropies(self, raw_probs: List[Any]) -> List[Any]:
        return [self.probs_dict_to_entropy(probs_dict) for probs_dict in raw_probs]

    def array_probs_to_raw_probs(self, array_probs: List[Any]) -> List[Dict]:
        self._validate_probs(array_probs)
        return [
            self._prob_arrays_to_prob_dicts(
                pred, self.cardinality, validate_distribution=False
            )
            for pred in array_probs
        ]

    def raw_labels_from_raw_probs(self, raw_probs: List[Any]) -> List[Any]:
        return [self._probs_dict_to_predicted_label(pred) for pred in raw_probs]

    def raw_probs_from_raw_labels(self, raw_labels: List[Any]) -> List[Any]:
        return [self._get_default_predicted_probs(pred) for pred in raw_labels]

    def raw_label_to_user_label(self, raw_label: Any) -> Any:
        return self._inverse_label_map[raw_label]

    def user_label_to_raw_label(
        self, user_label: Any, x_uid: Optional[str] = None
    ) -> Any:
        return self.label_map[user_label]

    @staticmethod
    def remap_labels(
        labels: Dict[str, Any],
        remap: Dict[Any, Any],
        filter_missing_keys: Optional[bool] = True,
    ) -> Dict[Any, Any]:
        """If filter_missing_keys is False, it keeps missing labels without remapping them"""
        return (
            {x_uid: remap[label] for x_uid, label in labels.items() if label in remap}
            if filter_missing_keys
            else {x_uid: remap.get(label, label) for x_uid, label in labels.items()}
        )

    def get_label_remap_dict(
        self,
        old_label_space: LabelSpace,
        updated_label_schema: Optional[Dict[str, Optional[str]]],
    ) -> Optional[Dict[str, Optional[str]]]:
        """Compute label mapping for transfer given user mapping"""
        old_label_map = old_label_space.label_map
        label_map = self.label_map
        inv_label_map = {v: k for k, v in label_map.items()}
        label_remap_dictionary = None
        if updated_label_schema is not None:
            label_remap_dictionary = copy.deepcopy(updated_label_schema)

        # Map common label strings to themselves if not mapped to other labels by user
        common_labels = set(old_label_map).intersection(label_map)
        if common_labels:
            if label_remap_dictionary is None:
                label_remap_dictionary = {k: k for k in common_labels}
            else:
                for label in common_labels:
                    if label not in label_remap_dictionary:
                        label_remap_dictionary[label] = label

        # Map dropped labels to UNKNOWN
        union_labels = set(old_label_map).union(set(label_map))
        dropped_labels = list(union_labels - set(label_map))
        for label in dropped_labels:
            if label_remap_dictionary and label not in label_remap_dictionary:
                label_remap_dictionary[label] = inv_label_map[-1]  # UNKNOWN label
        return label_remap_dictionary

    @staticmethod
    def check(
        x: pd.Series, op_name: str, fault_tolerant: bool = False, *conditions: Any
    ) -> bool:
        """Check a (potentially composed) boolean condition on an individual datum
        The `fault_tolerant` param is used to return False for each condition where an error
        would normally be raised.
        """
        # Note: we purposely use more verbose logic to enable short-circuiting on $AND and $OR
        # Note: assertions on self.conditions length are done while parsing the graph so they're
        # not repeated here

        if op_name == constants.AND:
            for arg in conditions:
                if not SingleLabelSpace._safe_check(arg, x, fault_tolerant):
                    return False
            return True
        if op_name == constants.OR:
            for arg in conditions:
                if SingleLabelSpace._safe_check(arg, x, fault_tolerant):
                    return True
            return False
        if op_name == constants.NOT:
            return not SingleLabelSpace._safe_check(
                conditions[0], x, fault_tolerant, on_error_return=True
            )
        if op_name == constants.IS:
            return SingleLabelSpace._safe_check(conditions[0], x, fault_tolerant)
        raise KeyError(f"invalid LF Graph op_name provided: {op_name}")

    @staticmethod
    def _safe_check(
        condition: Any,
        x: pd.Series,
        fault_tolerant: bool,
        on_error_return: bool = False,
    ) -> bool:
        """Helper to check conditions of templates with fault tolerance."""

        if not fault_tolerant:
            return condition.check(x)
        try:
            return condition.check(x)
        except Exception:
            return on_error_return

    @staticmethod
    def compose_lf(label: int, condition: Any, fault_tolerant: bool) -> Callable:
        def lf(x: pd.Series) -> int:
            return (
                label
                if condition.check(x, fault_tolerant=fault_tolerant)
                else SingleLabelSpace.get_raw_unknown_label()
            )

        return lf

    def probs_to_preds_with_threshold(
        self,
        probs: np.ndarray,
        lf_abstains: Optional[np.ndarray] = None,
        tie_break_policy: str = "abstain",
        tol: float = 1e-5,
        filter_uncertain_labels_threshold: float = 0.0,
        postprocess_labels: bool = False,
    ) -> np.ndarray:
        if len(probs) == 0:
            logger.info("Return empty preds")
            return np.empty(shape=(0,), dtype=int)

        perf_time_log = PerfTimeLog("Probs to preds for SingleLabelSpace")

        # Convert from object array (array of lists) to dense float array
        probs = np.array(list(probs), dtype=float)

        perf_time_log.update("Convert object array to dense float array")

        probs = probs_to_preds_with_threshold_flat(
            probs,
            tie_break_policy,
            tol,
            filter_uncertain_labels_threshold,
            self.raw_unknown_int,
            lf_abstains=lf_abstains,
        )

        perf_time_log.update("Threshold probs")

        logger.debug(perf_time_log.pretty_summary())

        return probs

    # For single-label we're computing abstains with predicted labels not matching any LF votes
    def compute_lf_abstains(
        self, L: sparse._coo.core.COO, probas: np.ndarray
    ) -> np.ndarray:
        perf_time_log = PerfTimeLog("Compute LF abstains for SingleLabelSpace")

        preds = onehot(probas.argmax(axis=1), cardinality=self.cardinality)

        perf_time_log.update("Take argmax of probs and onehot")

        abstains = (
            sparse_any(L * preds[:, np.newaxis, :], axis=(1, 2), sparse_output=False)
            == 0
        )
        perf_time_log.update("Compute abstains from existing L matrix and preds")

        logger.debug(perf_time_log.pretty_summary())
        return abstains

    def min_samples_per_class(
        self, labeled_data: pd.DataFrame, gt_field: str, min_samples_per_class: int
    ) -> pd.DataFrame:
        return labeled_data.groupby(gt_field, as_index=False).head(
            min_samples_per_class
        )

    @staticmethod
    def _get_gt_label_mask(label_int: int, label_vector: pd.Series) -> pd.Series:
        return label_vector == label_int

    def get_gt_comparison_mask(
        self, gt_vector: pd.Series, config: Dict[str, Any]
    ) -> pd.Series:
        """Returns a mask where GT is present, if the vote type is incorrect/correct,
        otherwise returning a mask of all Trues"""
        if config["voted"] in [constants.CORRECT, constants.INCORRECT]:
            return gt_vector != self.get_raw_unknown_label()
        return pd.Series([True for _ in range(len(gt_vector))])

    def filter_label_vector(
        self,
        data_vector: pd.Series,
        gt_vector: pd.Series,
        config: Dict[str, Any],
        x_uids: Optional[List[str]] = None,
        split: str = "dev",
    ) -> pd.DataFrame:
        """Voted will either be a class str, or 'correct' / 'incorrect'"""
        voted = config["voted"]
        if voted in [
            constants.CORRECT,
            constants.CORRECT_OR_UNKNOWN,
            constants.INCORRECT,
            constants.INCORRECT_OR_UNKNOWN,
        ]:
            not_abstain = np.logical_not(
                np.logical_or(
                    data_vector == self.get_raw_unknown_label(),
                    gt_vector == self.get_raw_unknown_label(),
                )
            )
            if voted in [constants.CORRECT, constants.CORRECT_OR_UNKNOWN]:
                gt_comparison_mask = data_vector == gt_vector
            else:
                gt_comparison_mask = data_vector != gt_vector
            if voted in [constants.CORRECT, constants.INCORRECT]:
                and_mask = np.logical_and(not_abstain, gt_comparison_mask)
                return pd.DataFrame({"mask": and_mask})
            else:
                or_mask = np.logical_or(~not_abstain, gt_comparison_mask)
                return pd.DataFrame({"mask": or_mask})

        if voted == constants.ANY:
            return pd.DataFrame({"mask": data_vector != self.get_raw_unknown_label()})

        return pd.DataFrame(
            {"mask": self._get_gt_label_mask(self.label_map[voted], data_vector)}
        )

    def filter_lf_conflict(self, data_row: pd.Series, config: Dict[str, Any]) -> bool:
        """Determines if any LFs are conflicting."""

        # For all labels that aren't the UNKNOWN label, create a unique set of tokens.
        # If the cardinality of the unique set is greater than 1, then there are conflicting votes.
        return len(data_row[data_row != self.get_raw_unknown_label()].unique()) > 1

    def get_text_to_code_base_prompt(self, df: pd.DataFrame) -> str:
        return f"""
    Act as a senior Python software engineer. Respond only with code, do not include any other text in your response. Do not include ``` or 'python' as part of the response.

    The goal is fill in the following function. Output the imports + function definition, as well as the completion of the function body. The function should return one of {self.label_map}. The default value returned should be "UNKNOWN"
    Do not import external libraries.

def determine_class(row) -> str:
    import regex

    This function will be applied in a df.apply(determine_class, axis=1) call later. Note that the DF has access to the following fields: {str(df.columns)}. Here is a sample of the dataframe: {str(df.head())}.

    The function should return one of {self.label_map}. The default value returned should be "UNKNOWN"
    """

    def remap_labels_and_get_new_label_map(
        self, user_raw_labels_dict: Dict[str, RawLabels], class_value: int
    ) -> Dict[str, Any]:
        # HACK(ENG-10095): Each label space should ideally have its own per-class annotation metric.
        # This workaround is temporary while label space organization (and annotation behavior) is being debated.
        user_labels_map = {
            username: raw_label.labels
            for username, raw_label in user_raw_labels_dict.items()
        }
        all_votes = pd.DataFrame.from_dict(user_labels_map)
        class_votes_simplified = self._get_per_class_labels_df(all_votes, class_value)
        per_class_user_labels_map = class_votes_simplified.to_dict()
        per_class_user_raw_labels_map = {
            username: RawLabels(labels=labels)
            for username, labels in per_class_user_labels_map.items()
        }
        return dict(
            label_map={
                "UNKNOWN": -1,
                f"Not {self.inv_label_map[class_value]}": 0,
                self.inv_label_map[class_value]: 1,
            },
            user_raw_labels_map=per_class_user_raw_labels_map,
        )

    def _get_per_class_labels_df(
        self, df: pd.DataFrame, class_value: int
    ) -> pd.DataFrame:
        """Given an input dataframe of labels, return the corresponding
        per-class dataframe. The per-class dataframe filters down to only
        those x_uids where at least one voter voted with class_value.

        Args:
            df (pd.DataFrame): DataFrame where rows are x_uids and columns represent voters
            class_value (int): Class to isolate

        Returns:
            pd.DataFrame: Per-class DataFrame
        """
        # Per-class single-label annotation matrix should only consider documents
        # which at least one annotator voted on with the desired class
        df_full = df.fillna(self.raw_unknown_int)
        class_df = df_full[df_full.isin([class_value]).any(axis=1)]
        # Remap labels
        return class_df.applymap(
            lambda label: self.raw_unknown_int
            if label == self.raw_unknown_int
            else (1 if label == class_value else 0)
        )

    def compute_interannotator_aggregate_metric(
        self,
        user_raw_labels_map: Dict[str, RawLabels],
        metric: str = "krippendorff-alpha",
    ) -> float:
        user_labels_map = {
            user: raw_labels.labels for user, raw_labels in user_raw_labels_map.items()
        }
        if metric == "krippendorff-alpha":
            return metrics_utils.compute_krippendorff_alpha(user_labels_map)
        err_msg = f"Only the krippendorff-alpha metric is currently supported. Requested metric: {metric}"
        raise NotSupportedException(detail=err_msg, user_friendly_message=err_msg)

    def find_missing_predicted_classes(self, Y: np.ndarray) -> None:
        if isinstance(Y[0], list) or isinstance(Y[0], np.ndarray):
            unique_pred_classes = np.where(np.sum(Y, axis=0) != 0.0)[0]
        else:
            unique_pred_classes = np.unique(Y)

        label_map_no_unknown = {
            k: v for k, v in self.label_map.items() if v != self.get_raw_unknown_label()
        }
        if len(unique_pred_classes) != len(label_map_no_unknown):
            if len(unique_pred_classes) == 1:
                raise TypeError(
                    "Cannot train model: the resulting training set has labels for only "
                    f"one class {unique_pred_classes} ({len(Y)} sample(s)). Need labels for more than one class to train a model."
                )

            missing_classes = []
            for label, label_int in label_map_no_unknown.items():
                if label_int not in unique_pred_classes:
                    missing_classes.append(label)

            logger.warning(
                f"The resulting training set has no labels for classes "
                f"[{', '.join(missing_classes)}]. Training a model with those classes missing ..."
            )

    def validate_lf_label(self, lf_label: int) -> bool:
        if not isinstance(lf_label, int):
            raise TypeError("`lf_label` must be an `int`.")
        return bool(0 <= lf_label <= self.cardinality - 1)

    def compute_label_counts(self, annotations: List[Any]) -> defaultdict:
        label_count: defaultdict = defaultdict(int)
        for annotation in annotations:
            label_count[annotation.label] = label_count[annotation.label] + 1
        return label_count

    def simple_majority(
        self,
        annotations_array: List[List[Any]],
        source_uid: int,
        random_seed: int = 123,
    ) -> List[Dict]:
        ties_count = 0
        new_annotations = []
        unknown_count = 0
        random.seed(random_seed)

        for annotations in annotations_array:
            max_count = 0
            label_counts: dict = defaultdict(int)
            max_labels = []

            for annotation in annotations:
                if annotation.label != self.get_raw_unknown_label():
                    label_counts[annotation.label] += 1

            for label, label_count in label_counts.items():
                if label_count > max_count:
                    max_count = label_count
                    max_labels = [label]
                elif label_count == max_count:
                    max_labels.append(label)

            if len(max_labels) == 1:
                label = max_labels[0]
            elif len(max_labels) > 1:
                ties_count += 1
                max_labels.sort()
                label = random.choice(max_labels)
            else:
                # The only way to end up with a -1 label is if all annotators abstained.
                # The commit_annotations method will filter out any unknown annotations
                # before updating the GT table.
                unknown_count += 1
                label = self.get_raw_unknown_label()

            new_annotations.append(
                {
                    "x_uid": annotations[0].x_uid,
                    "label": label,
                    "source_uid": source_uid,
                }
            )
        logger.info(
            f"Aggregating labels: number of ties: {ties_count}, number of unknown labels: {unknown_count}"
        )
        return new_annotations

    def _aggregate_annotations(
        self,
        annotations_array: List[List[Any]],
        source_uid: int,
        strategy: str,
        params: Dict[str, Any],
    ) -> List[Dict]:
        random_seed = params["random_seed"]

        if strategy == SIMPLE_MAJORITY:
            return self.simple_majority(annotations_array, source_uid, random_seed)
        return []

    def _threshold_probs(
        self, x_uids: List[Any], probs: List[Any], threshold_holder: ThresholdHolder
    ) -> List[Any]:
        threshold = threshold_holder.get_threshold()
        assert self.cardinality == 2, "Only binary tasks support thresholding."
        thresholded_preds = [int(p[1] >= threshold) for p in probs]
        assert len(thresholded_preds) == len(x_uids)
        return thresholded_preds

    def compute_gt_label_distribution(
        self, gt_labels: LabelsType, user_formatted: bool = False
    ) -> Dict[Union[str, int], int]:
        gt_label_dist = dict(Counter(gt_labels.values()))
        for label in self.label_map.values():
            if label not in gt_label_dist:
                gt_label_dist[label] = 0
        if user_formatted:
            return {
                self.inv_label_map[label]: count
                for label, count in gt_label_dist.items()
            }
        else:
            return gt_label_dist

    def compute_training_set_statistics(
        self,
        ts_labels: RawLabels,
        gt_labels: RawLabels,
        random_seed: int,
        sample_size: int,
    ) -> Optional[TrainingSetStats]:
        # Overloaded function which returns some statistics (including a small random sample) for a training set.

        # Remove UNKNOWN labels
        valid_ts_labels = {
            xuid: label
            for xuid, label in ts_labels.labels.items()
            if label != self.raw_unknown_int
        }
        correct_labels = {
            xuid: label
            for xuid, label in gt_labels.labels.items()
            if ts_labels.labels.get(xuid, self.get_raw_unknown_label()) == label
        }

        est_labels_precision = (
            (len(correct_labels) * 1.0 / len(gt_labels.labels))
            if len(gt_labels.labels) > 0
            else 0
        )

        # This ensures we get a consistent random sample if the seed is the same.
        random.seed(random_seed)
        if len(gt_labels.labels) > 0:
            random_sample = [
                # Generate a sample of sample_size.
                random.choice(list(gt_labels.labels.items()))
                for _ in range(sample_size)
            ]
        else:
            random_sample = []
        return TrainingSetStats(
            num_data_points=len(ts_labels.labels),
            num_est_labels=len(valid_ts_labels),
            num_gt_labels=len(gt_labels.labels),
            est_labels_precision=est_labels_precision,
            gt_label_dist=dict(Counter(gt_labels.labels.values())),
            est_label_dist=dict(Counter(valid_ts_labels.values())),
            random_sample=random_sample,
        )

    def compute_L_for_analysis(
        self,
        x_uids: List[str],
        lf_uids: List[int],
        lf_labels: Dict[int, LabelsType],
        do_filter: bool = True,
        **kwargs: Any,
    ) -> sparse._coo.core.COO:
        perf_time_log = PerfTimeLog("Compute L matrix for SingleLabelSpace metrics")

        data_map = {uid: i for i, uid in enumerate(x_uids)}
        rows = []
        lfs = []
        votes = []

        perf_time_log.update("Initialize variables")

        for lf_idx, lf_uid in enumerate(lf_uids):
            for x_uid, label in lf_labels[lf_uid].items():
                if x_uid not in data_map:
                    raise ServerError(
                        detail="Inconsistent x_uids and lf_labels inputs provided"
                    )
                rows.append(data_map[x_uid])
                lfs.append(lf_idx)
                votes.append(label)

                perf_time_log.update("For every lf and sample update variables")

        rows, lfs, votes = np.array(rows), np.array(lfs), np.array(votes)

        perf_time_log.update("Convert lists to numpy arrays")

        if do_filter:
            non_abstains = votes != self.raw_unknown_int
            rows, lfs, votes = rows[non_abstains], lfs[non_abstains], votes[non_abstains]  # type: ignore

        perf_time_log.update("Get abstains and filter variables")

        L = sparse.COO(
            coords=(rows, lfs, votes),
            data=np.uint64(1),
            shape=(len(x_uids), len(lf_uids), self.cardinality),
            fill_value=0,
        )

        perf_time_log.update("Create sparse L tensor")

        logger.info(perf_time_log.pretty_summary())

        return L

    def get_partial_automl_params(self) -> PartialAutoMLParams:
        tune_threshold_on_valid = True if self.cardinality == 2 else False
        return PartialAutoMLParams(
            sampler_config={"strategy": "auto"},
            use_lf_labels={"SEARCH": [True, False]},
            discretize_labels={"SEARCH": [True, False]},
            tune_threshold_on_valid=tune_threshold_on_valid,
        )

    def is_lf_coverage_valid(self, lf_dicts: List[Dict]) -> bool:
        # We cannot train a model with < 2 classes.
        if self.cardinality < 2:
            return False
        unique_lf_classes = set()
        for lf in lf_dicts:
            lf_config = lf["config"]
            if "label" not in lf_config:
                # Task contains multipolar LF, so skip validation
                # Multipolar LFs can vote on any class in the label space and there's no simple way
                # to determine which classes it votes on
                return True
            unique_lf_classes.add(lf_config["label"])
        if len(unique_lf_classes) < 2:
            return False
        return True

    def replace_lf_votes(self, lf_votes: pd.DataFrame, new_label: Any) -> pd.DataFrame:
        return lf_votes.apply(
            lambda vote: new_label
            if vote != self.get_raw_unknown_label()
            else self.get_raw_unknown_label()
        )

    def get_decision_tree_candidate_labels(
        self, raw_label: Optional[Any] = None
    ) -> List[str]:
        if raw_label is not None:
            return [self.raw_label_to_user_label(raw_label)]
        else:
            return [
                label_str
                for label_str, label_int in self.label_map.items()
                if not self.is_unknown_label(label_int)
            ]

    def get_decision_tree_label(
        self, decision_tree_label: str, provided_label: str
    ) -> Optional[str]:
        return decision_tree_label if decision_tree_label == provided_label else None

    def support_custom_metrics(self) -> bool:
        return True
