from typing import Any, Tuple

import numpy as np
import sparse
from frozendict import frozendict  # type: ignore


def freeze(x: Any) -> Any:
    """Recursive function for making immutable deep objects consisting of dicts and lists.
    Is faster than analogous function in gelidum.
    NOTE: we could make this more general but the goal here is speed -> minimizing number of
    conditional statements, and most complex variable types in snorkelflow consist of lists and dicts.

    """
    if isinstance(x, dict):
        return frozendict({k: freeze(v) for k, v in x.items()})
    elif isinstance(x, list):
        return tuple(map(freeze, x))

    return x


def unfreeze(x: Any) -> Any:
    """Recursive function for making mutable deep objects consisting of frozendicts and tuples."""
    if isinstance(x, frozendict):
        return {k: unfreeze(v) for k, v in x.items()}
    elif isinstance(x, tuple):
        return list(map(unfreeze, x))

    return x


def freeze_numpy(x: np.ndarray) -> Tuple:
    """Convert numpy array to tuple of immutable elements
    NOTE: we only want to use freeze when we have to, in general is much faster to just
    use any known required transformations -> conditional logic below.
    """
    if x.dtype == "object" or x.ndim > 2:
        return freeze(x.tolist())
    elif x.ndim == 2:
        return tuple(map(tuple, x.tolist()))
    else:
        return tuple(x)


def unfreeze_numpy(x: Tuple) -> np.ndarray:
    """Convert tuple to numpy array, mostly convenient if data type is complex."""
    return np.asarray(unfreeze(x))


def freeze_sparse(L: sparse._coo.core.COO) -> frozendict:
    """Convert sparse tensor to immutable dict with coordinates and shape.
    NOTE: Assumes this is a one-hot encoded variable so data=1 everywhere.
    """

    if (L.data != 1).any():
        raise ValueError("Function only accepts one-hot tensors")

    return frozendict({"coords": freeze_numpy(L.coords), "shape": L.shape})


def unfreeze_sparse(d: frozendict) -> sparse._coo.core.COO:
    """Convert immutable dict with coordinates and shape information to one-hot
    sparse tensor.
    """
    return sparse.COO(coords=d["coords"], shape=d["shape"], data=np.uint64(1))
