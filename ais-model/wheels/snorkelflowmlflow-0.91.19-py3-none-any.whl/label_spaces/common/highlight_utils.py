from enum import Enum
from typing import Any, Dict, List, Optional

from pydantic import BaseModel

PREDICTION_CONFIDENCE_FIELD = "prediction_confidence"
PREDICTION_LABEL_FIELD = "prediction_int"
RETURN_PRED_CONFIDENCE = "confidence"
SPAN_TEXT_WORD_MAX_LENGTH = 15


class HighlightMetadataParams(BaseModel):
    x_uids: List[str]
    model_uids: Optional[List[int]] = None
    ts_uids: Optional[List[int]] = None
    lf_uids: Optional[List[int]] = None
    is_context: bool = False
    return_confidences: bool = True
    filter_unlabeled: bool = True
    split: str = "dev"
    fetch_span_text: bool = False


class HighlightMetadataResponse(BaseModel):
    """For each of these dictionaries, keys are xuids and values are nested dictionaries
    with keys of the model_uid (or training_set_uid etc) and values with intervals and
    labels for those intervals. For examples of the types seen in these nested
    dictionaries (the Any part), look at the _transform methods at the bottom of this
    file"""

    model_predictions: Dict[str, Any] = {}
    training_set_labels: Dict[str, Any] = {}
    gt_labels: Dict[str, Any] = {}
    lf_labels: Dict[str, Any] = {}


class HighlightVariant(str, Enum):
    ANNOTATED_SPAN = "annotatedSpan"  # GT for seq tagging, other task types
    CANDIDATE_SPAN = "candidateSpan"  # GT for candidate extraction tasks
    HIGHLIGHTED = "highlighted"
    HYPERLINK = "hyperlink"
    CLF_LF_VOTES = "classificationLFVotes"
    SEQUENCE_LF_VOTES = "sequenceLFVotes"
    LIVE = "live"
    MODEL_VOTES = "sequenceModelVotes"
    TRAINING_SET_VOTES = "sequenceTrainingSetVotes"


class FilterTypesForHighlight(str, Enum):
    GROUND_TRUTH = "ground_truth"
    ALL_LFS = "lfs"
    NO_LFS = "no_lfs"
    LF = "lf"
    MODEL = "model"
    TAG = "tag_type"
    TRAINING_SET = "training_set"
    SELECTED_FIELDS = "special_filter"
    COLUMN = "field"
    ANNOTATIONS = "annotation"
    LF_CONFLICT = "lf_conflict"
    CLUSTER = "cluster"
    MARGIN_DISTANCE = "margin_distance"


class HighlightConfigFieldNames(str, Enum):
    """Use to generate the HighlightConfig object on the FE
    LABEL_INT_FIELD_NAME is the integer label
    LABEL_STR_FIELD_NAME is the label displayed to the user in string form
    TITLE is displayed at the top of the highlighted span tooltip
    START and END are character offsets for the span and used to know when the styling should start/end (ie the start of a circle should be curved around the character and not just below and beneath it)
    VARIANT is the style of highlight to display
    TYPE is the filter type this highlight is associated with
    DESCRIPTION is the content of the tooltip in list form with an element for each row
    """

    LABEL_INT_FIELD_NAME = "raw_label"
    LABEL_STR_FIELD_NAME = "label"
    TITLE = "title"
    START = "start"
    END = "end"
    VARIANT = "variant"
    TYPE = "type"
    DESCRIPTION = "description"


def to_rounded_percent(num: float) -> str:
    return "{:.1%}".format(num) if num > 0.1 else "{:.2%}".format(num)


def truncate_span_string(string: str) -> str:
    if len(string) < 1.5 * SPAN_TEXT_WORD_MAX_LENGTH:
        return string

    words = string.split()
    if len(words) <= 1:
        return string[: SPAN_TEXT_WORD_MAX_LENGTH - 3] + "..."

    last_word_len = len(words[-1])
    last_word_start = last_word_len - SPAN_TEXT_WORD_MAX_LENGTH
    return (
        words[0][:SPAN_TEXT_WORD_MAX_LENGTH]
        + "..."
        + words[-1][last_word_start if last_word_start >= 0 else 0 :]
    )
