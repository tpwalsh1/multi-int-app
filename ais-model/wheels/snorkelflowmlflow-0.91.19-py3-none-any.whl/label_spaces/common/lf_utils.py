from typing import Any, Dict, List, Type

import pandas as pd

from label_spaces.single import SingleLabelSpace
from snorkelflow.types.performance import Performance


class LFCondition:
    """An LFCondition maps a data point to a boolean of whether the condition applies

    This is the primary logic inside of an LF.
    Note than LF condition may be composed of one or more conditions being combined.
    """

    # Note: conditions are actually of type Union[Template, LFCondition], but we use Any to
    # avoid recursive type annotations
    def __init__(
        self, op_name: str, label_space_cls: Type = SingleLabelSpace, *conditions: Any
    ) -> None:
        self.op_name = op_name
        self.label_space_cls = label_space_cls
        self.conditions = conditions

    def check(self, x: pd.Series, fault_tolerant: bool = False) -> Any:
        """Check a (potentially composed) boolean condition on an individual datum
        The `fault_tolerant` param is used to return False for each condition where an error
        would normally be raised.
        """
        # Note: we purposely use more verbose logic to enable short-circuiting on $AND and $OR
        # Note: assertions on self.conditions length are done while parsing the graph so they're
        # not repeated here

        # TODO: consider replacing this method with a direct call to label_space_cls
        return self.label_space_cls.check(
            x, self.op_name, fault_tolerant, *self.conditions
        )

    def preprocess_configs(self) -> List[Dict[str, Any]]:
        """List of operator configs to run before applying LF."""
        configs: List[Dict[str, Any]] = []
        for condition in self.conditions:
            preprocess_configs = condition.preprocess_configs()
            if preprocess_configs:
                configs.extend(preprocess_configs)
        return configs

    def estimate_perf(self, df: pd.DataFrame) -> Performance:
        """Estimate performance cost of running this condition on given df."""
        # Note that this can raise a NotImplementedError which must be
        # handled by callers.
        perf = Performance(compute_time_secs=0, peak_memory_mb=0)
        for condition in self.conditions:
            cperf = condition.estimate_perf(df)
            perf.compute_time_secs += cperf.compute_time_secs
            perf.peak_memory_mb = max(perf.peak_memory_mb, cperf.peak_memory_mb)
        return perf
