from typing import List, Tuple, Union

import numpy as np
import sparse


def sparse_any(
    X: sparse._coo.core.COO,
    axis: Union[int, Tuple, List] = 0,
    sparse_output: bool = False,
) -> Union[sparse._coo.core.COO, np.ndarray]:
    """Takes logical-or condition across given axes for existence of non-zero (True) values.

    Equivalent to X.any(axis=axis) when sparse_output=True, and X.any(axis=axis).todense() when sparse_output=False. This version is faster
    because it exploits the fact that we already know the coordinates of non-zero entries.

    NOTE: Behavior from sparse methods may differ when X has non-zero fill values, which generally are exception prone (unlike here).

    Args:
        X (sparse._coo.core.COO): Input tensor
        axis (Union[int,Tuple,List], optional): axes over which to take condition. Defaults to 0.
        sparse_output (bool, optional): Whether to output a sparse tensor. Defaults to False, in which case output is a numpy array.

    Returns:
        sparse._coo.core.COO
    """
    if isinstance(axis, int):
        axis = (axis,)

    result_axes = np.array(sorted(list(set(range(X.ndim)) - set(axis))))
    result_shape = tuple(np.array(X.shape)[result_axes])

    if sparse_output:
        X_any = sparse.COO(
            coords=tuple(X.coords[result_axes, :]), data=True, shape=result_shape
        )
    else:
        X_any = np.full(result_shape, False)
        X_any[tuple(X.coords[result_axes, :])] = True

    return X_any


def index_sparse_tensor(
    X: sparse._coo.core.COO, ind: int, axis: int = 0
) -> sparse._coo.core.COO:
    """Indexes a sparse tensor, seems to be faster than built-in sparse method

    Args:
        X (sparse._coo.core.COO): tensor
        ind (int): index
        axis (int, optional): axis along which to index. Defaults to 0.

    Returns:
        sparse._coo.core.COO: indexes tensor
    """
    if (X.data != 1).any():
        raise ValueError("Function only accepts one-hot tensors")

    # If it's the first axis, this appears to be fastest (because of how sparse sorts coordinates?)
    if axis == 0:
        return X[ind]

    else:
        mask = X.coords[axis] == ind
        new_coords = X.coords[:, mask]
        new_coords = np.vstack([new_coords[:axis], new_coords[axis + 1 :]])

        original_shape = X.shape
        new_shape = (*original_shape[:axis], *original_shape[axis + 1 :])

        return sparse.COO(new_coords, np.uint64(1), shape=new_shape)


def slice_sparse_tensor(
    X: sparse._coo.core.COO, slice_inds: Union[np.ndarray, List], axis: int = 0
) -> sparse._coo.core.COO:
    """Slices a sparse tensor along a single axis. Seems to be faster than methods built into sparse lib

    Args:
        X (sparse._coo.core.COO): original tensor
        slice_inds (np.ndarray): slice inds, either boolean or integers
        axis (int, optional): axis along which to slice. Defaults to 0.

    Returns:
        sparse._coo.core.COO: sliced tensor
    """

    if (X.data != 1).any():
        raise ValueError("Function only accepts one-hot tensors")

    if isinstance(slice_inds, list):
        slice_inds = np.asarray(slice_inds)

    if slice_inds.dtype == bool:
        (slice_inds,) = np.where(slice_inds)
    else:
        slice_inds = np.sort(slice_inds)

    original_shape = X.shape
    new_dim = len(slice_inds)
    new_shape = (*original_shape[:axis], new_dim, *original_shape[axis + 1 :])

    if new_dim == 0:
        return sparse.full(new_shape, fill_value=X.fill_value, dtype=X.dtype)

    if new_dim == X.shape[axis]:
        return X

    mask = np.isin(X.coords[axis], slice_inds)
    new_coords = X.coords[:, mask]
    new_coords[axis] = np.searchsorted(
        np.arange(original_shape[axis])[slice_inds], new_coords[axis]
    )

    return sparse.COO(new_coords, data=np.uint64(1), shape=new_shape)


def onehot(x: np.ndarray, cardinality: int) -> np.ndarray:
    X = np.zeros((len(x), cardinality))
    legit = x != -1
    X[legit, x[legit]] = 1
    return X


def densify(x: Union[sparse._coo.core.COO, np.ndarray]) -> np.ndarray:
    """
    Args:
        x (Any): object that could be a sparse tensor or numpy array
    Returns:
        np.ndarray: numpy array
    """
    if isinstance(x, sparse._coo.core.COO):
        return x.todense()
    else:
        return x


def make_singlelabel_target_sparse(
    y: np.ndarray, cardinality: int
) -> sparse._coo.core.COO:
    if y.shape[0] > 0 and y.max() > cardinality:
        raise ValueError("cardinality < maximum class")

    sample_size = len(y)
    non_abstain_mask = y > -1
    (samples,) = np.where(non_abstain_mask)

    y_sparse = sparse.COO(
        (samples, y[samples]),
        np.uint64(1),
        shape=(sample_size, cardinality),
        fill_value=0,
    )
    return y_sparse


def make_singlelabel_target_dense(y_sparse: sparse._coo.core.COO) -> np.ndarray:
    sample_size = y_sparse.shape[0]
    y_dense = np.full((sample_size,), -1)
    y_dense[y_sparse.coords[0, :]] = y_sparse.coords[1, :]

    return y_dense


def make_singlelabel_lfs_sparse(
    L: np.ndarray, cardinality: int
) -> sparse._coo.core.COO:
    if L.shape == ():
        return sparse.COO([])
    elif any(dim == 0 for dim in L.shape):
        return sparse.full((*L.shape, cardinality), 0)

    if L.shape[0] > 0 and L.max() > cardinality:
        raise ValueError("cardinality < maximum vote in L matrix")

    sample_size, lf_num = L.shape
    vote_mask = L > -1
    samples, votes = np.where(vote_mask)

    L_sparse = sparse.COO(
        (samples, votes, L[samples, votes]),
        np.uint64(1),
        shape=(sample_size, lf_num, cardinality),
        fill_value=0,
    )
    return L_sparse


def make_singlelabel_lfs_dense(L_sparse: sparse._coo.core.COO) -> np.ndarray:
    if L_sparse.shape == ():
        return np.array([])
    sample_size, lf_num, _ = L_sparse.shape
    L = np.full((sample_size, lf_num), -1)
    L[L_sparse.coords[0, :], L_sparse.coords[1, :]] = L_sparse.coords[2, :]

    return L


def make_multilabel_target_sparse(Y: np.ndarray) -> sparse._coo.core.COO:
    sample_size, label_num = Y.shape
    vote_mask = Y > -1
    samples, labels = np.where(vote_mask)

    Y_sparse = sparse.COO(
        (samples, labels, Y[samples, labels]),
        np.uint64(1),
        shape=(sample_size, label_num, 2),
        fill_value=0,
    )
    return Y_sparse


def make_multilabel_target_dense(Y_sparse: sparse._coo.core.COO) -> np.ndarray:
    sample_size, label_num, _ = Y_sparse.shape
    Y_dense = np.full((sample_size, label_num), -1)
    Y_dense[Y_sparse.coords[0, :], Y_sparse.coords[1, :]] = Y_sparse.coords[2, :]

    return Y_dense


def make_multilabel_lfs_sparse(L: np.ndarray) -> sparse._coo.core.COO:
    sample_size, lf_num, label_num = L.shape
    vote_mask = L > -1
    samples, lfs, labels = np.where(vote_mask)

    L_sparse = sparse.COO(
        (samples, lfs, labels, L[samples, lfs, labels]),
        np.uint64(1),
        shape=(sample_size, lf_num, label_num, 2),
        fill_value=0,
    )
    return L_sparse


def make_multilabel_lfs_dense(L_sparse: sparse._coo.core.COO) -> np.ndarray:
    sample_size, lf_num, label_num, _ = L_sparse.shape
    L = np.full((sample_size, lf_num, label_num), -1)
    L[
        L_sparse.coords[0, :], L_sparse.coords[1, :], L_sparse.coords[2, :]
    ] = L_sparse.coords[3, :]

    return L
