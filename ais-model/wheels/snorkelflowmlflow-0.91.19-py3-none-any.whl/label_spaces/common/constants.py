from typing import Any, Dict, List

# Grammar constants
AND = "$AND"
OR = "$OR"
IS = "$IS"
NOT = "$NOT"

# Filter constants
CORRECT = "correct"
INCORRECT = "incorrect"
UNKNOWN = "unknown"
PARTIALLY_CORRECT = "partially correct"
CORRECT_OR_UNKNOWN = "correct or unknown"
INCORRECT_OR_UNKNOWN = "incorrect or unknown"
ALL_CLASSES = "all classes"
ANY_CLASS = "any class"
THIS = "this"
ANY = "any"
ALL = "all"
NONE = "none"

ANNOTATION_AGGREGATE_OPTIONS: List[Dict[str, Any]] = [
    {"title": "All annotators", "value": ALL},
    {"title": "No annotators", "value": NONE},
    {"title": "Any annotator", "value": ANY},
]
BATCH_AWARE_ANNOTATION_AGGREGATE_OPTIONS: List[Dict[str, Any]] = [
    {"title": "All annotators in batch ", "value": ALL},
    {"title": "No annotators in batch", "value": NONE},
    {"title": "Any annotator in batch", "value": ANY},
]

COMMENT_AGGREGATE_OPTIONS: List[Dict[str, Any]] = [{"title": "Any user", "value": ANY}]

THIS_LF_OPTION = {"title": "This LF", "value": THIS}
LF_GENERAL_OPTIONS: List[Dict[str, Any]] = [
    # Studio preview option
    THIS_LF_OPTION,
    # Aggregate options
    {"title": "All LFs", "value": ALL},
    {"title": "No LFs", "value": NONE},
    {"title": "Any LFs", "value": ANY},
]
