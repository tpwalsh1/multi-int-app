"""Utils for LabelSpace metrics"""
import itertools
from typing import Any, Callable, Dict, List, Optional, Set

import numpy as np
import pandas as pd
from pydantic import BaseModel
from scipy import sparse
from sklearn.metrics import confusion_matrix, precision_recall_curve

from api_utils.exceptions import UserInputError
from metrics import Scorer
from snorkelflow.utils.logging import get_logger

from .sparse_dense_utils import onehot


class PostprocessedSpan(BaseModel):
    x_uid: str
    char_start: int
    char_end: int
    label: int
    label_probs: Optional[List[float]]


class PostprocessedModelPredictions(BaseModel):
    x_uid: str
    preds: Any
    pred_probs: Any


class MetricsKeys:
    PER_CLASS_KEY = "per_class"
    CONFUSION_MATRIX_KEY = "confusion_matrix"
    PR_CURVE_KEY = "pr_curve"
    N_PR_CURVE_POINTS = 20
    PR_METRICS = ["f1", "f1_micro", "f1_macro", "precision", "recall", "roc_auc"]
    RETRIEVAL_METRICS = ["precision", "recall", "f1"]
    MULTILABEL_METRIC_ANY = "any-present"
    MULTILABEL_METRIC_ALL = "all-present"
    F1_MACRO = "f1_macro"
    ACCURACY_MACRO = "accuracy_macro"
    ACCURACY = "accuracy"
    F1_MICRO = "f1_micro"
    F1 = "f1"
    PRECISION = "precision"
    RECALL = "recall"
    TP = "tp"
    FP = "fp"
    TN = "tn"
    FN = "fn"


logger = get_logger("Label Spaces - Metrics")


def compute_classification_metrics(
    golds: np.ndarray,
    preds: np.ndarray,
    label_map: Dict[str, int],
    metrics: List[str],
    custom_metric_funcs: Dict[str, Callable],
    probs: Optional[np.ndarray] = None,
    abstain_int: int = -1,
) -> Dict[str, Any]:
    """Compute classification metrics from aligned labels, predictions, and probabilities."""
    # If list is empty, no GT, or not predictions, set metrics to None
    scores: Dict[str, Any] = {}
    if len(golds) == 0 or golds.max() == -1 or preds.max() == -1:
        # Set metrics to None so that Scorer doesn't throw an error.
        scores = {metric: None for metric in metrics + list(custom_metric_funcs.keys())}
        if len(golds) == 0 or golds.max() == -1:
            logger.warning("Empty ground truth")
        if len(preds) == 0 or preds.max() == -1:
            logger.warning("Empty predictions")
        logger.warning("Returning null scores")
        return scores
    for metric in metrics:
        if metric == MetricsKeys.PER_CLASS_KEY:
            scores[MetricsKeys.PER_CLASS_KEY] = _compute_per_class_retrieval_metrics(
                golds=golds, preds=preds, label_map=label_map, abstain_int=abstain_int
            )
            continue
        if metric == "roc_auc" and all(golds[0] == gold for gold in golds):
            logger.warning(
                "Only one class present in ground truth. ROC AUC score is not defined in that case."
            )
            scores["roc_auc"] = None
            continue
        # Score metrics one at a time. If one computation fails,
        # we set the result to None (and avoid blocking other metrics).
        try:
            score: Optional[float] = Scorer(
                abstain_int, [metric], custom_metric_funcs=custom_metric_funcs
            ).score(golds=golds, preds=preds, probs=probs)[metric]
        except Exception as e:
            err_msg = f"Unable to compute metric: {metric}"
            logger.error(err_msg, exc_info=True, stack_info=True)
            raise UserInputError(
                user_friendly_message=err_msg, detail=f"{err_msg}. Raw error : {str(e)}"
            ) from e

        # Assign score and remove NaN values
        scores[metric] = _convert_nans_to_none(score)

    return scores


def _compute_per_class_retrieval_metrics(
    golds: np.ndarray, preds: np.ndarray, label_map: Dict[str, int], abstain_int: int
) -> Optional[Dict[str, Any]]:
    per_class_retrieval_metrics: Dict[str, Dict[str, Optional[float]]] = {}
    for label_str, label_int in label_map.items():
        if label_int == abstain_int:
            continue
        gt_set = set(np.where(golds == label_int)[0])
        pred_set = set(np.where(preds == label_int)[0])
        per_class_retrieval_metrics[label_str] = compute_retrieval_metrics(
            pred_set, gt_set
        )
    return per_class_retrieval_metrics


def compute_pr_curve(
    golds: np.ndarray, probs: np.ndarray, n_classes: int
) -> Optional[Dict[str, Any]]:
    # TODO: Consider updating the Scorer to handle pr_curve so filtering of
    # abstains and calculations for this metric mirror other metrics
    logger.info(
        "A precision- or recall-based metric was requested; " "calculating PR curve"
    )

    if not len(golds):
        return None

    # Filter out invalid probs
    golds_list, probs_list = [], []
    for idx, prob in enumerate(probs.tolist()):
        if prob is not None and prob is not np.nan:
            golds_list.append(golds[idx])
            probs_list.append(probs[idx])
    golds = np.array(golds_list).astype(int)
    probs = np.array(probs_list)

    # Calculate on positive class if binary, otherwise micro-average
    if n_classes == 2:
        logger.info(
            "Binary problem: assuming class 1 is positive class "
            "for precision and recall"
        )
        precisions, recalls, _ = precision_recall_curve(
            golds.ravel(), probs[:, 1].ravel()
        )
    else:
        logger.info(
            "Non-binary problem: calculating precision and recall "
            "curve using micro-average over all classes"
        )
        precisions, recalls, _ = precision_recall_curve(
            onehot(golds, n_classes).ravel(), probs.ravel()
        )
    n = len(precisions)
    n_sample = min(n, MetricsKeys.N_PR_CURVE_POINTS)
    idxs = np.linspace(0, n - 1, num=n_sample, endpoint=True, dtype=int)
    precision = [
        _convert_nans_to_none(x)
        for x in np.around(precisions[idxs], decimals=3).tolist()
    ]
    recall = [
        _convert_nans_to_none(x) for x in np.around(recalls[idxs], decimals=3).tolist()
    ]

    updated_precision = []
    updated_recall = []
    # Filter any precision recalls in which one is None
    for idx in range(len(precision)):
        if precision[idx] is not None and recall[idx] is not None:
            updated_precision.append(precision[idx])
            updated_recall.append(recall[idx])
    return dict(precision=updated_precision, recall=updated_recall)


def calculate_retrieval_metrics(
    num_true_positives: float, num_false_positives: float, num_false_negatives: float
) -> Dict[str, Optional[float]]:
    precision: Optional[float] = None
    recall: Optional[float] = None
    f1: Optional[float] = None
    try:
        precision = num_true_positives / (num_true_positives + num_false_positives)
    except ZeroDivisionError:
        logger.warn("Divide by zero error; precision is undefined.")
    try:
        recall = num_true_positives / (num_true_positives + num_false_negatives)
    except ZeroDivisionError:
        logger.warn("Divide by zero error; recall is undefined.")
    if precision is not None and recall is not None:
        try:
            f1 = (2.0 * precision * recall) / (precision + recall)
        except ZeroDivisionError:
            logger.warn("Divide by zero error; f1 is undefined.")
    return {"precision": precision, "recall": recall, "f1": f1}


def compute_retrieval_metrics(
    pred_set: Set[Any], gt_set: Set[Any]
) -> Dict[str, Optional[float]]:
    """Compute retrieval metrics with predictions/ground truth 'sets' comparisons.
    Only F1, Recall, and Precision are supported. Other metrics will be set to None.
    """

    true_positives = pred_set.intersection(gt_set)
    false_positives = pred_set.difference(gt_set)
    false_negatives = gt_set.difference(pred_set)
    num_true_positives = float(len(true_positives))
    num_false_positives = float(len(false_positives))
    num_false_negatives = float(len(false_negatives))

    metrics_dict = calculate_retrieval_metrics(
        num_true_positives, num_false_positives, num_false_negatives
    )
    return metrics_dict


def _convert_nans_to_none(score: Optional[float]) -> Optional[float]:
    return None if score is not None and np.isnan(score) else score


def compute_confusion_matrix(
    golds: np.ndarray,
    preds: np.ndarray,
    label_map: Dict[str, int],
    n_classes: int,
    confusion_matrix_fn: Callable = confusion_matrix,
) -> Optional[Dict[str, Any]]:
    # Add the confusion matrix
    label_names: List[Optional[str]] = [None] * n_classes
    for k, v in label_map.items():
        if v >= 0:
            label_names[v] = k
    if not len(golds):
        return dict(
            matrix=np.zeros((n_classes, n_classes)).tolist(), labels=label_names
        )
    return dict(
        matrix=confusion_matrix_fn(
            golds, preds, labels=list(range(len(label_names)))
        ).tolist(),
        labels=label_names,
    )


def compute_normalized_entropy_score(probs: np.ndarray) -> float:
    # compute entropy in the base of the number of classes
    # so it is always in [0, 1]
    n_classes = probs.shape[1]
    if n_classes < 1:
        return 0.0
    log_probs = np.log(probs) / np.log(n_classes)
    # fill any of the -infs (prob is zero) before w take the hadamard product
    log_probs[np.isneginf(log_probs)] = 0.0
    negative_entropies = (probs * log_probs).sum(axis=1)
    average_negative_entropy = negative_entropies.mean()
    # protect against returning -0.0
    return np.abs(-1 * average_negative_entropy)


def _sparse_outer_product(
    A: sparse.csr_matrix, B: sparse.csr_matrix
) -> sparse.csr_matrix:
    """Computes the row-wise outer product of two sparse matrices.
    Modified from https://stackoverflow.com/questions/57099722/row-wise-outer-product-on-sparse-matrices

    _sparse_outer_product(A, B)[i] = flatten(A[i]B[i]^T)
    """
    N, L = A.shape
    N, K = B.shape
    drows = zip(*(np.split(x.data, x.indptr[1:-1]) for x in (A, B)))
    data = [np.outer(a, b).ravel() for a, b in drows]
    irows = zip(*(np.split(x.indices, x.indptr[1:-1]) for x in (A, B)))
    indices = [np.ravel_multi_index(np.ix_(a, b), (L, K)).ravel() for a, b in irows]
    indptr = np.fromiter(itertools.chain((0,), map(len, indices)), int).cumsum()
    return sparse.csr_matrix(
        (np.concatenate(data), np.concatenate(indices), indptr), (N, L * K)
    )


def _broadcast_row_diagonal(A: sparse.csr_matrix) -> sparse.csr_matrix:
    """Compute a matrix of flattened diagonal matrices, where row i is a
    flattened diagonal matrix whose entries are the ith row of the sparse matrix A.
    Modified from https://stackoverflow.com/questions/8339299/create-a-sparse-diagonal-matrix-from-row-of-a-sparse-matrix

    If A[1] = [1, 2, 3]
    then _broadcast_row_diagonal(A)[1] = [1, 0, 0, 0, 2, 0, 0, 0, 3]
    """
    diags = sparse.csr_matrix((0, A.shape[1] * A.shape[1]))
    for i in range(A.shape[0]):
        idx_begin = A.indptr[i]
        idx_end = A.indptr[i + 1]
        diag_elems = A.data[idx_begin:idx_end]
        diag_indices = A.indices[idx_begin:idx_end]
        ith_diag = sparse.csr_matrix(
            (diag_elems, (diag_indices, diag_indices)), shape=(A.shape[1], A.shape[1])
        ).reshape(1, -1)
        diags = sparse.vstack([diags, ith_diag])
    return diags


def compute_krippendorff_alpha(user_labels_map: Dict[str, Any]) -> float:
    """
    Compute Krippendorff's alpha using notation borrowed from
    https://en.wikipedia.org/wiki/Krippendorff%27s_alpha
    """
    # The Reliability matrix M x N (M annotators, N data points)
    # reliability[i, j] is the vote that annotator I assigned to sample J.
    reliability_df = pd.DataFrame.from_dict(user_labels_map).stack()
    reliability = (
        pd.Series(reliability_df.factorize()[0], index=reliability_df.index)
        .unstack()
        .to_numpy()
        .T
    )

    # The Labels vector is of dimension V (V possible labels)
    # For non-numeric labels, labels need to be uniquely encoded.
    # Since our metric for comparison is nominal, it is sufficient to encode unique labels with unique integers.
    values = np.unique(reliability[~np.isnan(reliability)])

    # value_counts is an N x V matrix tallying votes for each label per data point
    # value_counts[i, j] is the number of votes for label J given to sample I
    value_counts = (reliability[..., None] == values).sum(0)
    _, V = value_counts.shape
    sparse_value_counts = sparse.csr_matrix(value_counts)
    o_unnormalized = _sparse_outer_product(sparse_value_counts, sparse_value_counts)
    # m_u is the number of votes given to unit u
    # Take max(counts, 2) for numerical reasons (o_unnormalized will be 0 here, will not impact calculation)
    m_u = np.maximum(value_counts.sum(1), 1)
    diags = _broadcast_row_diagonal(sparse_value_counts)
    o_unnormalized = o_unnormalized - diags
    inv_m_u = np.reciprocal(m_u - 1, dtype=np.float64)
    o_ck = sparse.csr_matrix.dot(inv_m_u, o_unnormalized).reshape(V, V)

    n_v = o_ck.sum(0)
    e_ck = np.divide(np.outer(n_v, n_v) - np.diag(n_v), n_v.sum() - 1)
    dist = (values[:, None] != values[None, :]).astype(float)
    if (e_ck * dist).sum() == 0:
        alpha = 1.0
    else:
        alpha = 1.0 - (o_ck * dist).sum() / (e_ck * dist).sum()

    return alpha
