from typing import Any, Dict, List, Type, Union

from label_spaces.base import LabelSpace, label_spaces_dict
from label_spaces.mixins import LabelSpaceMixinBase

# Import LabelSpace subclasses to register them
from . import anomaly_detection, multi_label, sequence, single  # noqa: F401

# The specific types below should be used with OpenAPI endpoints,
# so backend and frontend incompatibilities can be highlighted when new
# label space types are added.
RawLabelOpenAPIType = Union[
    multi_label.OPENAPI_RAW_LABEL_TYPE,
    sequence.OPENAPI_RAW_LABEL_TYPE,
    single.OPENAPI_RAW_LABEL_TYPE,
]
UserLabelOpenAPIType = Union[
    multi_label.OPENAPI_USER_LABEL_TYPE,
    sequence.OPENAPI_USER_LABEL_TYPE,
    single.OPENAPI_USER_LABEL_TYPE,
]
# LF vote is not yet supported for non-sequence label spaces, change to Union once we supported other label space
LFVoteOpenAPIType = sequence.OPENAPI_LF_VOTE_INFO_TYPE
LFVotesOpenAPIType = Dict[str, LFVoteOpenAPIType]
RawLabelsOpenAPIType = Dict[str, RawLabelOpenAPIType]
UserLabelsOpenAPIType = Dict[str, UserLabelOpenAPIType]


class LabelSpaceNotFoundException(Exception):
    pass


def get_label_space_cls(cls_name: str) -> Type[LabelSpace]:
    if cls_name not in label_spaces_dict:
        raise LabelSpaceNotFoundException(
            f"LabelSpace class not found: {cls_name}. "
            "Make sure the class file is imported above."
        )
    return label_spaces_dict[cls_name]


def get_label_space(cls_name: str, kwargs: Dict[str, Any]) -> LabelSpace:
    if cls_name not in label_spaces_dict:
        raise LabelSpaceNotFoundException(
            f"LabelSpace class not found: {cls_name}. "
            "Make sure the class file is imported above."
        )
    return label_spaces_dict[cls_name](**kwargs)


def get_label_space_mixins(cls_name: str) -> List[str]:
    """Return list of LabelSpaceMixinBase subclasses implemented by label space class."""
    cls = get_label_space_cls(cls_name)
    supported_mixins: List[str] = []
    for superclass in cls.mro():
        if issubclass(superclass, LabelSpaceMixinBase):
            supported_mixins.append(superclass.__name__)
    return sorted(supported_mixins)


def get_label_space_classes() -> List[Type[LabelSpace]]:
    """Return list of label space classes."""
    return list(label_spaces_dict.values())
