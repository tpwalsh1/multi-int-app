import itertools
import json
import random
import sys
from collections import Counter, OrderedDict, defaultdict
from copy import deepcopy
from statistics import mean
from typing import (
    Any,
    Callable,
    DefaultDict,
    Dict,
    Generator,
    Iterable,
    List,
    Optional,
    Set,
    Tuple,
    Union,
)

import numpy as np
import pandas as pd
import sparse
from sklearn.metrics import (
    accuracy_score,
    confusion_matrix,
    f1_score,
    precision_score,
    recall_score,
)

import label_spaces.common.constants as constants
from api_utils.exceptions import NotSupportedException, ServerError, UserInputError
from label_spaces.base import (
    AggregateScoreStrategy,
    LabelSpace,
    LabelSpaceConfig,
    LabelsType,
    PartialAutoMLParams,
    RawLabels,
    ThresholdHolder,
    TrainingSetStats,
    UserLabels,
    probs_to_preds_with_threshold_flat,
)
from label_spaces.common import metrics_utils
from label_spaces.common.metrics_utils import MetricsKeys
from label_spaces.common.sparse_dense_utils import sparse_any
from label_spaces.mixins import ActiveLearningMixin, TrainingSetStatsMixin
from snorkelflow.types.splits import Splits
from snorkelflow.utils.logging import get_logger
from snorkelflow.utils.performance_profiling import PerfTimeLog

logger = get_logger("Label Space")

OPENAPI_RAW_LABEL_TYPE = Dict[str, int]
OPENAPI_USER_LABEL_TYPE = Optional[Dict[str, str]]  # user raw label is None

SIMPLE_UNION = "simple-union"
MULTILABEL_MAJORITY_VOTE_CARDINALITY = 1000
MULTILABEL_NUM_VOTE_THRESHOLD = 64
MULTILABEL_PRESENCE_USER_LABEL_DICT: Dict[int, str] = {
    -1: "ABSTAIN",
    0: "ABSENT",
    1: "PRESENT",
}
MULTILABEL_INVERSE_PRESENCE_USER_LABEL_DICT: Dict[str, int] = {
    "ABSTAIN": -1,
    "ABSENT": 0,
    "PRESENT": 1,
}

DEFAULT_MULTI_LABEL_MODELS: List[Any] = [
    "BeamingMultiLabelModel",
    "MajorityVoteMultiLabelModel",
]
DEFAULT_KEY = "_default"

ABSTAIN_PROB = 0.5


class MultiLabelSpace(TrainingSetStatsMixin, ActiveLearningMixin, LabelSpace):
    """Manages labels and metrics for multi-label classification.

    See `validate_raw_labels` for expected RawLabel format.

    Attributes:
        raw_unknown_int (see base class): Indicates a class is UNKNOWN for a datapoint.
        _raw_absent_int: Indicates a class is ABSENT for a datapoint.
        _raw_present_int: Indicates a class is PRESENT for a datapoint.
        _default_key: Key which stores the label to default to for missing classes.
        _is_unknown_in_label_map: Indicates label_map should not include raw_unknown_int.
    """

    _raw_absent_int: int = 0
    _raw_present_int: int = 1
    _default_key: str = DEFAULT_KEY
    _is_unknown_in_label_map: bool = False
    default_aggregation_strategy = SIMPLE_UNION
    supported_aggregation_strategies = [SIMPLE_UNION]
    annotation_metric: str = MetricsKeys.MULTILABEL_METRIC_ALL
    label_model_list = DEFAULT_MULTI_LABEL_MODELS
    is_multi_label = True

    def __init__(
        self,
        label_map: Dict[str, int],
        label_descriptions: Optional[Dict[str, str]] = None,
        *args: Any,
        **kwargs: Any,
    ) -> None:
        super().__init__(label_map, label_descriptions, *args, **kwargs)
        self._class_strings = [str(class_int) for class_int in range(self.cardinality)]

    def config(self) -> LabelSpaceConfig:
        return LabelSpaceConfig(
            cls_name=self.__class__.__name__,
            kwargs=dict(
                label_map=self.label_map, label_descriptions=self._label_descriptions
            ),
        )

    def get_default_lm_scoring_metric(self) -> str:
        return "jaccard_with_abstains"

    def L_to_generator(self, L_sparse: Any, batch_size: int) -> Generator:
        if len(L_sparse) == 0:
            return (y for y in [L_sparse])
        # Subtract 1 from array to account for sparsity
        return (
            np.stack([elem.toarray() for elem in L_sparse[i : i + batch_size]]) - 1
            for i in range(0, len(L_sparse), batch_size)
        )

    def validate_raw_labels(self, raw_labels: RawLabels) -> None:
        """Validate format of RawLabels.

        raw_labels.labels Dict[int, int] should contain:
          - Keys: class_int, not necessarily every class_int.
          - Values: presence_int, a -1, 0, or 1 label indicating
            if this class is labeled ABSENT, UNKNOWN, PRESENT.
          - A special _default key also exists which will contain an
            int in [raw_unknown_int, raw_absent_int, raw_present_int].

        raw_labels.probs Dict[int, List[float]] should contain:
          - Keys: class_int, every class_int in the label_map should be present.
          - Values: a List of 2 values, the first value indicates the probability
            of the ABSENT label for this class. The 2nd value is just 1 - ABSENT.
        """
        valid_class_int_strs: Set[Union[str, int]] = {
            str(v) for v in self.label_map.values()
        }
        valid_class_int_strs.add(self._default_key)

        for x_uid, label in raw_labels.labels.items():
            if not isinstance(label, dict):
                self._raise_error_incorrect_label_format(
                    x_uid,
                    label,
                    detailed_error=f"expect label to be type of dict, got {type(label)} for {x_uid=} and {label=}",
                )

            if not set(label.keys()).issubset(valid_class_int_strs):
                self._raise_error_incorrect_label_format(
                    x_uid,
                    label,
                    detailed_error=f"expect label keys to be subset of {valid_class_int_strs}, got {set(label.keys())} for {x_uid=} and {label=}",
                )

            all_possible_class_presence_ints = {
                self._raw_unknown_int,
                self._raw_absent_int,
                self._raw_present_int,
            }
            for presence_int in label.values():
                if presence_int not in all_possible_class_presence_ints:
                    self._raise_error_incorrect_label_format(
                        x_uid,
                        label,
                        detailed_error=f"expect label values to be subset of {all_possible_class_presence_ints}, got {presence_int} for {x_uid=} and {label=}",
                    )

            if not getattr(raw_labels, "probs"):
                continue

            probs = raw_labels.probs[x_uid]  # type: ignore
            if not isinstance(probs, list):
                self._raise_error_incorrect_probs_format(x_uid, probs)

            if not len(probs) == self.cardinality:
                self._raise_error_incorrect_probs_format(x_uid, probs)

            for prob in probs:
                if prob < 0.0 or prob > 1.0:
                    self._raise_error_incorrect_label_format(x_uid, label)

    @staticmethod
    def get_raw_unknown_label() -> Any:
        return {"_default": -1}

    @staticmethod
    def get_user_unknown_label() -> Any:
        return {"_default": MULTILABEL_PRESENCE_USER_LABEL_DICT[-1]}

    @staticmethod
    def get_raw_dummy_label() -> Any:
        return {"_default": 0}

    @classmethod
    def raw_label_type(cls) -> type:
        return Dict[str, int]

    @classmethod
    def user_label_type(cls) -> type:
        return Dict[str, str]

    @staticmethod
    def extract_values_from_input_label(label: Any) -> List[str]:
        try:
            label = json.loads(label)
        except Exception:
            pass

        if isinstance(label, dict):
            values = []
            for key, val in label.items():
                if key == DEFAULT_KEY:
                    continue
                if val not in ["PRESENT", "ABSENT", "ABSTAIN"]:
                    raise ValueError
                values.append(key)
            return values
        else:
            raise ValueError

    @staticmethod
    def example_user_input_label() -> Any:
        return {
            "CLASS_1": "PRESENT",
            "CLASS_2": "PRESENT",
            "CLASS_3": "ABSENT",
            "CLASS_4": "ABSTAIN",
        }

    def get_user_unknown_pred_conf(self) -> Tuple[Any, Any]:
        """Returns the unknown prediction and confidence to return to front-end."""
        return (
            self.raw_label_to_user_label(self.get_raw_unknown_label()),
            [0.0] * self.cardinality,
        )

    def copy_with_label_map(self, label_map: Dict[str, int]) -> "MultiLabelSpace":
        label_descriptions = {
            k: v for k, v in self.label_descriptions.items() if k in label_map
        }
        return self.__class__(
            label_map=label_map, label_descriptions=label_descriptions
        )

    def _get_per_class_labels(
        self,
        x_uids: List[str],
        labels: LabelsType,
        class_int_list: Optional[List[int]] = None,
    ) -> Dict[int, List[int]]:
        per_class_labels: Dict[int, List[int]] = {
            k: [] for k in self._label_map.values()
        }
        for x_uid in x_uids:
            default_presence_int = (
                labels[x_uid].get(self._default_key, self._raw_unknown_int)
                if x_uid in labels
                else self._raw_unknown_int
            )
            for class_int in (
                class_int_list if class_int_list else self._label_map.values()
            ):
                per_class_labels[class_int].append(
                    labels[x_uid].get(str(class_int), default_presence_int)
                    if x_uid in labels
                    else default_presence_int
                )

        return per_class_labels

    def compute_L_for_analysis(
        self,
        x_uids: List[str],
        lf_uids: List[int],
        lf_labels: Dict[int, LabelsType],
        do_filter: bool = False,
        **kwargs: Any,
    ) -> sparse._coo.core.COO:
        """Computes label tensor and class voting indicator for lf analysis

        Args:
            x_uids (List[str]): x uid associated with each sample
            lf_uids (List[int]): lf uid associated with each lf
            lf_labels (Dict[int, LabelsType]): list of lf labels
            enforce_num_vote_threshold (bool, optional): whether to enforce a thresholding for computing the class voting indicator. Defaults to False.

        Returns:
            sparse._coo.core.COO: KxNxLx2 tensor for K classes, N samples, L lfs
            NOTE: L matrix dims are different from compute_L to facilitate indexing on class (much faster when along the 0th axis due to coordinate sorting in sparse lib)
        """

        perf_time_log = PerfTimeLog("Compute per-class L matrix for metrics")

        data_map = {uid: idx for idx, uid in enumerate(x_uids)}
        lf_num = len(lf_uids)

        rows = []
        lfs = []
        labels = []
        votes = []
        perf_time_log.update("Initialize variables")

        for lf_idx, lf_uid in enumerate(lf_uids):
            for x_uid, lf_vote in lf_labels[lf_uid].items():
                if x_uid not in data_map:
                    raise ServerError(
                        detail="Inconsistent x_uids and lf_labels inputs provided"
                    )

                label_inds, lf_votes = self.to_coo_tuples(lf_vote)

                perf_time_log.update(
                    "Convert sparse LF vote to sparse inds for each lf and sample"
                )

                vote_n = len(label_inds)
                rows += [data_map[x_uid]] * vote_n
                lfs += [lf_idx] * vote_n
                labels += label_inds
                votes += lf_votes

                perf_time_log.update("Update variables for each lf and sample")

        L = sparse.COO(
            coords=(labels, rows, lfs, votes),
            data=np.uint64(1),
            shape=(self.cardinality, len(x_uids), lf_num, 2),
            fill_value=0,
        )

        perf_time_log.update("Create sparse L tensor")

        logger.info(perf_time_log.pretty_summary())

        return L

    def get_classes_computed(
        self, L: sparse._coo.core.COO, lf_uids: List[int]
    ) -> Dict[int, Set[int]]:
        """Get of all classes for which each lf voted present if total non-abstain votes for the class > threshold
        but only if at least one class goes above threshold (of none do then we ignore)

        Args:
            L (sparse._coo.core.COO): L tensor
            lf_uids (List[int]): List of uids for returned Dict keys, assumed to be parallel to 1st axis of L

        Returns:
            Dict[int, Set[int]]: Set of class indices for each lf uid
        """

        perf_time_log = PerfTimeLog("Get classes computed for L tensor")

        classes_computed: Dict[int, Set[int]] = {}

        class_votes = sparse_any(L, axis=1, sparse_output=False)

        perf_time_log.update(
            "Check for presence of class votes across samples for each lf"
        )

        do_L_present_only = (
            class_votes.any(axis=2).sum(axis=0) >= MULTILABEL_NUM_VOTE_THRESHOLD
        )

        perf_time_log.update("Threshold present votes")

        if do_L_present_only.any():
            class_votes = class_votes[:, do_L_present_only, 1]
            for lf_idx, lf_uid in enumerate(np.array(lf_uids)[do_L_present_only]):
                (class_inds,) = np.where(class_votes[:, lf_idx])
                classes_computed[lf_uid] = set(class_inds.tolist())

            perf_time_log.update(
                "If any class present votes, compute whether classes are valid"
            )

        logger.info(perf_time_log.pretty_summary())
        return classes_computed

    def get_L_train_max_num_rows(self) -> int:
        return 10_000

    def _compute_optimal_threshold(
        self,
        primary_metric: str,
        valid_x_uids: List,
        valid_probs: List,
        valid_ground_truth: RawLabels,
        custom_metric_funcs: Dict[str, Callable],
        df: Optional[pd.DataFrame] = None,
        df_uid_col: Optional[str] = None,
    ) -> ThresholdHolder:
        primary_metric_to_per_class_metric_map = {
            MetricsKeys.F1_MACRO: MetricsKeys.F1,
            MetricsKeys.F1_MICRO: MetricsKeys.F1,
            MetricsKeys.ACCURACY_MACRO: MetricsKeys.ACCURACY,
        }
        class_primary_metric = primary_metric_to_per_class_metric_map.get(
            primary_metric, MetricsKeys.F1
        )
        thresholds = np.arange(0, 1, 0.01)
        scores_per_class = defaultdict(list)
        for threshold in thresholds:
            thresholded_preds = self._threshold_probs(
                valid_x_uids, valid_probs, ThresholdHolder(threshold)
            )
            thresholded_raw_preds = RawLabels(
                dict(zip(valid_x_uids, thresholded_preds))
            )
            per_class_metrics = self._compute_metrics(
                valid_ground_truth,
                thresholded_raw_preds,
                [MetricsKeys.PER_CLASS_KEY],
                custom_metric_funcs=custom_metric_funcs,
                df=df,
                df_uid_col=df_uid_col,
            )[MetricsKeys.PER_CLASS_KEY]
            for class_name, class_metrics in per_class_metrics.items():
                score = class_metrics[class_primary_metric]
                scores_per_class[str(self.label_map[str(class_name)])].append(
                    (score if score else 0.0, threshold)
                )
        return ThresholdHolder(
            {
                class_int_str: max(scores)[1]
                for class_int_str, scores in scores_per_class.items()
            }
        )

    def _threshold_probs(
        self, x_uids: List[Any], probs: List[Any], threshold_holder: ThresholdHolder
    ) -> List[Any]:
        thresholded_preds = []
        for prob in probs:
            preds = {}
            for class_int, class_prob in enumerate(prob):
                class_int_str = str(class_int)
                preds[class_int_str] = int(
                    class_prob >= threshold_holder.get_threshold(class_int_str)
                )
            preds[self._default_key] = self._raw_absent_int
            thresholded_preds.append(preds)
        assert len(thresholded_preds) == len(x_uids)
        return thresholded_preds

    def _make_sparse_L_tensor(
        self, sparse_rows: List[Any], lf_num: int
    ) -> sparse._coo.COO:
        sample_size = len(sparse_rows)

        rows = []
        lfs = []
        labels = []
        votes = []

        for sparse_row_ind, sparse_row in enumerate(sparse_rows):
            for lf_ind, lf_vote in sparse_row.items():
                label_inds, lf_votes = self.to_coo_tuples(lf_vote)
                vote_n = len(label_inds)
                rows += [sparse_row_ind] * vote_n
                lfs += [lf_ind] * vote_n
                labels += label_inds
                votes += lf_votes

        L = sparse.COO(
            coords=(rows, lfs, labels, votes),
            data=np.uint64(1),
            shape=(sample_size, lf_num, self.cardinality, 2),
            fill_value=0,
        )

        return L

    def compute_class_L(
        self, label_matrix: Any, class_int: int
    ) -> Tuple[np.ndarray, List[Any]]:
        sample_size = len(label_matrix.sparse_rows)
        lf_num = len(label_matrix.lf_uids)
        L = np.full((sample_size, lf_num), self.raw_unknown_int, dtype=np.int8)

        for sparse_row_ind, sparse_row in enumerate(label_matrix.sparse_rows):
            for lf_ind, lf_vote in sparse_row.items():
                vote = lf_vote.get(
                    str(class_int),
                    lf_vote.get(self._default_key, self._raw_unknown_int),
                )
                L[sparse_row_ind, lf_ind] = vote

        return label_matrix.x_uids, L

    def _compute_L(
        self,
        label_matrix: Any,  # To avoid importing LabelMatrix
        df: Optional[pd.DataFrame] = None,
        batch_size: int = sys.maxsize,
        random_seed: int = 123,
        max_num_examples: Optional[int] = None,
        x_uids_gt: Optional[Set] = None,
        compute_num_datapoints: bool = False,
    ) -> Tuple[List[str], Generator, int]:
        perf_time_log = PerfTimeLog("Compute L matrix for MultiLabelSpace")

        x_uids = label_matrix.x_uids
        num_lfs = len(label_matrix.lf_uids)
        sparse_rows = label_matrix.sparse_rows
        num_sparse_rows = len(sparse_rows)

        perf_time_log.update("Take label matrix attributes and count rows")

        if max_num_examples is not None and max_num_examples < num_sparse_rows:
            samples_to_keep = self.subsample_uids(
                x_uids, max_num_examples, random_seed, x_uids_gt=x_uids_gt
            )
            x_uids = [x_uids[i] for i in samples_to_keep]
            sparse_rows = [sparse_rows[i] for i in samples_to_keep]
            num_sparse_rows = max_num_examples

            perf_time_log.update("Take random sample")

        L_sparse_generator = (
            self._make_sparse_L_tensor(sparse_rows[i : i + batch_size], num_lfs)
            for i in range(0, len(sparse_rows), batch_size)
        )

        perf_time_log.update("Make sparse L generator")

        logger.info(
            f"Shape of sparse L:  {num_sparse_rows}, {num_lfs}, {self.cardinality}"
        )

        if compute_num_datapoints:
            raw_unknown_label = self.get_raw_unknown_label()
            num_labeled_datapoints = sum(
                any(x != raw_unknown_label for x in sparse_row.values())
                for sparse_row in sparse_rows
            )
            perf_time_log.update("Compute number datapoints")

        else:
            num_labeled_datapoints = 0

        logger.info(perf_time_log.pretty_summary())

        return (x_uids, L_sparse_generator, num_labeled_datapoints)

    def _to_dense_array(
        self,
        sparse_label: Dict,
        abstain_as_absent: bool = False,
        class_ints: Optional[List[int]] = None,
    ) -> List:
        default_value = sparse_label.get(self._default_key)
        if class_ints:
            return [sparse_label.get(str(c), default_value) for c in class_ints]
        if abstain_as_absent and default_value == -1:
            default_value = 0
        arr = [default_value] * self.cardinality
        for k in sparse_label:
            if k != self._default_key:
                val = sparse_label.get(k)
                if abstain_as_absent and val == -1:
                    val = 0
                arr[int(k)] = val
        return arr

    def to_dense_array(
        self,
        sparse_labels: Union[Dict, List[Dict], np.ndarray],
        abstain_as_absent: bool = False,
    ) -> Union[List, np.ndarray]:
        """
        Note: If you want to convert the sparse label dictionary to a COO-compatible data format,
        use to_coo_tuples()
        """
        if isinstance(sparse_labels, Dict):
            return self._to_dense_array(sparse_labels)
        else:
            if len(sparse_labels) == 0:
                return np.empty((0, self.cardinality))
            else:
                return np.stack(
                    list(
                        map(
                            lambda x: self._to_dense_array(x, abstain_as_absent),
                            sparse_labels,
                        )
                    ),
                    axis=0,
                )

    @classmethod
    def dense_array_to_sparse_labels(
        cls, dense_array: np.ndarray, inv_label_map: Optional[Dict] = None
    ) -> Dict:
        sparse_user_labels = dict()
        most_frequent_label: int = Counter(dense_array).most_common(1)[0][0]
        sparse_user_labels[cls._default_key] = (
            MULTILABEL_PRESENCE_USER_LABEL_DICT[most_frequent_label]
            if inv_label_map
            else most_frequent_label
        )
        for i, label in enumerate(dense_array):
            if label != most_frequent_label:
                class_key = inv_label_map[i] if inv_label_map else str(i)
                sparse_user_labels[class_key] = (
                    MULTILABEL_PRESENCE_USER_LABEL_DICT[label]
                    if inv_label_map
                    else label
                )
        return sparse_user_labels

    def _to_coo_tuples(self, sparse_labels: Dict) -> Tuple[List, List]:
        label_inds = []
        lf_votes = []

        default_value = sparse_labels[self._default_key]
        include_default = default_value != self.raw_unknown_int

        items: Iterable[Tuple[Any, Any]]
        if include_default:
            default_keys = set([str(x) for x in range(self.cardinality)]) - set(
                sparse_labels.keys()
            )
            items = itertools.chain(
                sparse_labels.items(), [(k, default_value) for k in default_keys]
            )
        else:
            items = sparse_labels.items()
        for key, value in items:
            if key == self._default_key or value == self.raw_unknown_int:
                continue

            label_inds.append(int(key))
            lf_votes.append(value)

        return label_inds, lf_votes

    def to_coo_tuples(
        self, sparse_labels: Union[Dict, List[Dict], np.ndarray]
    ) -> Tuple[List, List]:
        if isinstance(sparse_labels, Dict):
            return self._to_coo_tuples(sparse_labels)
        elif len(sparse_labels) == 0:
            return [], []
        else:
            label_inds = []
            lf_votes = []
            for sparse_label in sparse_labels:
                label_ind, lf_vote = self._to_coo_tuples(sparse_label)
                label_inds.extend(label_ind)
                lf_votes.extend(lf_vote)
            return label_inds, lf_votes

    def _compute_label_model_tuning_ground_truth(
        self,
        ground_truth: Dict[str, Any],
        lm_uids: List[Any],
        df: Optional[pd.DataFrame] = None,
    ) -> Dict[str, Any]:
        return np.array(
            [ground_truth.get(uid, self.get_raw_unknown_label()) for uid in lm_uids]
        )

    def _make_sparse_ground_truth_tensor(
        self, ground_truth: np.ndarray
    ) -> sparse._coo.COO:
        sample_size = len(ground_truth)

        rows = []
        labels = []
        label_gts = []

        for x_ind, x in enumerate(ground_truth.tolist()):
            label_inds, label_gt = self.to_coo_tuples(x)
            label_n = len(label_inds)
            rows += [x_ind] * label_n
            labels += label_inds
            label_gts += label_gt

        Y = sparse.COO(
            (rows, labels, label_gts),
            np.uint64(1),
            shape=(sample_size, self.cardinality, 2),
            fill_value=0,
        )

        return Y

    def _compute_probs_and_abstains_from_lm(
        self,
        lm_x_uids: List[str],
        lm_probs: np.ndarray,
        lm_abstains: np.ndarray,
        df: Optional[pd.DataFrame] = None,
    ) -> Tuple[List[str], List[Any], List[bool], Optional[List[Any]]]:
        lm_probs_list = lm_probs.tolist()
        lm_abstains_list = lm_abstains.tolist()
        return lm_x_uids, lm_probs_list, lm_abstains_list, None

    def get_compute_metrics_required_columns(self, metrics: List[str]) -> List[str]:
        """Returns the list of data frame columns required to compute the given metrics"""
        return []

    def _make_default_explicit(
        self, x_uids: List[str], raw_labels: RawLabels
    ) -> RawLabels:
        raw_labels.labels = {
            x_uid: self.to_dense_array(raw_labels.labels[x_uid]) for x_uid in x_uids
        }
        return raw_labels

    def _compute_all_any_metric(
        self, ground_truth: RawLabels, prediction: RawLabels, mode: str
    ) -> Optional[float]:
        """
        The ANY-PRESENT and ALL-PRESENT metrics examine agreement among PRESENT
        votes from two actors. These metrics are only calculated over data points'
        where the set of labels where both actors voted (the intersection) contains
        at least one PRESENT vote.

        The ALL-PRESENT metric scores as correct if both actors agree on all PRESENT votes
        in the intersection.

        The ANY-PRESENT metric scores as correct if both actors agree on any PRESENT vote
        in the intersection.

        Examples:
            ground_truth: {"0": 1, "1": 0, "_default": -1}
            prediction:   {"0": 1, "1": 1, "_default": 0}
            ALL-PRESENT: False, since not all PRESENT votes line up in the intersection.
            ANY-PRESENT: True, since one PRESENT vote lines up in the intersection.

            ground_truth: {"0": 1, "1": 0, "2": 0, "_default": -1}
            prediction: {"0": 0, "1": 0, "2": 1, "_default": -1}
            ALL-PRESENT: Not counted, since the intersection contains no present votes.
            ANY-PRESENT: Not counted, since the intersection contains no present votes.

        Args:
            ground_truth (RawLabels): The votes of one actor, in RawLabels format.
            prediction (RawLabels): The votes of the other actor, in RawLabels format.
            mode (str): Which metric to use (one of `any-present`, `all-present`).

        Raises:
            ValueError: If an incorrect argument is given to `mode`.

        Returns:
            float: The value returned by the appropriate metric, averaged over all valid data points.
        """
        if mode.lower() not in [
            MetricsKeys.MULTILABEL_METRIC_ALL,
            MetricsKeys.MULTILABEL_METRIC_ANY,
        ]:
            raise ValueError(f"Mode {mode} not either any-present or all-present.")

        x_uids: List[Any] = list(
            set(ground_truth.labels.keys()) & set(prediction.labels.keys())
        )

        ground_truth = self._make_default_explicit(x_uids, ground_truth)
        prediction = self._make_default_explicit(x_uids, prediction)

        n_correct: int = 0
        n_total: int = 0

        for x_uid in x_uids:
            predicted_labels = np.array(prediction.labels[x_uid])
            ground_truth_labels = np.array(ground_truth.labels[x_uid])

            predicted_present: Set[int] = set(
                np.flatnonzero(predicted_labels == self._raw_present_int).tolist()
            )
            predicted_absent: Set[int] = set(
                np.flatnonzero(predicted_labels == self._raw_absent_int).tolist()
            )
            ground_truth_present: Set[int] = set(
                np.flatnonzero(ground_truth_labels == self._raw_present_int).tolist()
            )
            ground_truth_absent: Set[int] = set(
                np.flatnonzero(ground_truth_labels == self._raw_absent_int).tolist()
            )

            predicted_voted = predicted_present.union(predicted_absent)
            ground_truth_voted = ground_truth_present.union(ground_truth_absent)

            predicted_present_intersection = predicted_present.intersection(
                ground_truth_voted
            )
            ground_truth_present_intersection = ground_truth_present.intersection(
                predicted_voted
            )

            # abstained on present and absent, so continue
            if not bool(
                predicted_present_intersection.union(ground_truth_present_intersection)
            ):
                continue

            if mode.lower() == MetricsKeys.MULTILABEL_METRIC_ALL:
                if predicted_present_intersection == ground_truth_present_intersection:
                    n_correct += 1
            elif mode.lower() == MetricsKeys.MULTILABEL_METRIC_ANY:
                if bool(predicted_present & ground_truth_present):
                    n_correct += 1

            n_total += 1

        # number deemed correct / number not abstained
        metric_value = None
        try:
            metric_value = float(n_correct) / n_total
        except ZeroDivisionError:
            logger.info(
                f"Setting metric {mode} to None, since no data points available for scoring"
            )
        return metric_value

    def _compute_per_class_metrics(
        self, ground_truth: RawLabels, prediction: RawLabels
    ) -> Dict[str, Dict[str, Any]]:
        per_class_metrics: Dict[str, Dict[str, Any]] = {
            str(k): dict.fromkeys(
                [
                    MetricsKeys.PRECISION,
                    MetricsKeys.RECALL,
                    MetricsKeys.ACCURACY,
                    MetricsKeys.F1,
                    MetricsKeys.TP,
                    MetricsKeys.TN,
                    MetricsKeys.FP,
                    MetricsKeys.FN,
                ]
            )
            for k in self._label_map.values()
        }

        gt = ground_truth.labels
        preds = prediction.labels
        x_uids = list(set(gt.keys()) & set(preds.keys()))
        classes = self._label_map.values()

        gt_vote_matrix = np.zeros((len(x_uids), len(classes)))
        preds_vote_matrix = np.zeros((len(x_uids), len(classes)))
        for i, x_uid in enumerate(x_uids):
            gt_vote_matrix[i] = self.to_dense_array(gt[x_uid])
            preds_vote_matrix[i] = self.to_dense_array(preds[x_uid])

        all_votes = np.stack((gt_vote_matrix, preds_vote_matrix), axis=2)
        for k in classes:
            class_votes = all_votes[:, k, :]
            # Ignore entries where both voters ABSTAIN
            class_votes = class_votes[~(class_votes == self.raw_unknown_int).any(1)]
            per_class_ground_truth, per_class_predictions = class_votes.T

            if per_class_ground_truth is None or len(per_class_ground_truth) == 0:
                continue

            confusion_matrix_k = confusion_matrix(
                per_class_ground_truth,
                per_class_predictions,
                labels=[self._raw_absent_int, self._raw_present_int],
            ).ravel()

            prec = precision_score(per_class_ground_truth, per_class_predictions)
            recall = recall_score(per_class_ground_truth, per_class_predictions)
            # f1_score of current version does not raise warning when both precision and recall are 0
            # so we need to check it manually
            if prec == 0 and recall == 0:
                f1 = None
            else:
                f1 = f1_score(per_class_ground_truth, per_class_predictions)

            per_class_metrics[str(k)] = {
                MetricsKeys.PRECISION: prec,
                MetricsKeys.RECALL: recall,
                MetricsKeys.ACCURACY: accuracy_score(
                    per_class_ground_truth, per_class_predictions
                ),
                MetricsKeys.F1: f1,
                MetricsKeys.TP: int(confusion_matrix_k[3]),
                MetricsKeys.TN: int(confusion_matrix_k[0]),
                MetricsKeys.FP: int(confusion_matrix_k[1]),
                MetricsKeys.FN: int(confusion_matrix_k[2]),
            }

        return per_class_metrics

    def _compute_metrics(
        self,
        ground_truth: RawLabels,
        prediction: RawLabels,
        metrics: List[str],
        custom_metric_funcs: Dict[str, Callable],
        df: Optional[pd.DataFrame] = None,
        df_uid_col: Optional[str] = None,
        extra_params: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        if extra_params is None:
            extra_params = {}
        if custom_metric_funcs:
            err_msg = "Custom metrics are not supported for MultiLabelSpace."
            raise NotSupportedException(detail=err_msg, user_friendly_message=err_msg)

        metrics_values: Dict[str, Any] = {metric_name: None for metric_name in metrics}

        multilabel_metrics = [
            MetricsKeys.MULTILABEL_METRIC_ALL,
            MetricsKeys.MULTILABEL_METRIC_ANY,
        ]
        requested_multilabel_metrics = [
            metric for metric in metrics if metric in multilabel_metrics
        ]

        per_class_metrics = self._compute_per_class_metrics(ground_truth, prediction)

        if MetricsKeys.PER_CLASS_KEY in metrics:
            returned_per_class_metrics: Dict[str, Any] = {}
            for class_name in self._label_map.keys():
                class_str = str(self.label_map[class_name])
                returned_per_class_metrics[class_name] = {
                    t: per_class_metrics[class_str][t]
                    for t in [
                        MetricsKeys.PRECISION,
                        MetricsKeys.RECALL,
                        MetricsKeys.ACCURACY,
                        MetricsKeys.F1,
                    ]
                    if t in per_class_metrics[class_str]
                }
            metrics_values[MetricsKeys.PER_CLASS_KEY] = returned_per_class_metrics

        remove_none = lambda x: [y for y in x if y is not None]

        if MetricsKeys.F1_MACRO in metrics:
            per_class_f1 = remove_none(
                [per_class_metrics[x][MetricsKeys.F1] for x in per_class_metrics]
            )
            metrics_values[MetricsKeys.F1_MACRO] = (
                sum(per_class_f1) / len(per_class_f1)
                if len(per_class_f1) != 0
                else None
            )

        if MetricsKeys.F1_MICRO in metrics:
            tp = sum(
                remove_none(
                    [per_class_metrics[x][MetricsKeys.TP] for x in per_class_metrics]
                )
            )
            fp = sum(
                remove_none(
                    [per_class_metrics[x][MetricsKeys.FP] for x in per_class_metrics]
                )
            )
            fn = sum(
                remove_none(
                    [per_class_metrics[x][MetricsKeys.FN] for x in per_class_metrics]
                )
            )
            if tp + 0.5 * (fp + fn) != 0:
                metrics_values[MetricsKeys.F1_MICRO] = float(tp) / (tp + 0.5 * (fp + fn))  # type: ignore
            else:
                metrics_values[MetricsKeys.F1_MICRO] = None

        if MetricsKeys.ACCURACY_MACRO in metrics:
            per_class_accuracy = remove_none(
                [per_class_metrics[x][MetricsKeys.ACCURACY] for x in per_class_metrics]
            )
            metrics_values[MetricsKeys.ACCURACY_MACRO] = (
                sum(per_class_accuracy) / len(per_class_accuracy)
                if len(per_class_accuracy) != 0
                else None
            )

        for multilabel_metric in requested_multilabel_metrics:
            metrics_values[multilabel_metric] = self._compute_all_any_metric(
                deepcopy(ground_truth), deepcopy(prediction), multilabel_metric
            )

        return metrics_values

    def get_lf_uid_errors(
        self,
        label_matrix: Any,
        x_uid_to_ground_truth: pd.DataFrame,
        class_int: Optional[int] = None,
    ) -> DefaultDict:
        class_int = class_int or 0
        lf_uid_to_num_errors: DefaultDict[int, int] = defaultdict(int)
        lf_uids = label_matrix.lf_uids
        lm_x_uids, L_dense_array = self.compute_class_L(label_matrix, class_int)
        if len(L_dense_array) == 0:
            return lf_uid_to_num_errors

        num_lfs = len(lf_uids)

        # Construct [n,] mask indicating whether x_uids are valid
        mask_valid_x_uids = np.isin(lm_x_uids, list(x_uid_to_ground_truth.keys()))
        # Tile to [n,k] mask
        mask_valid_x_uids = np.tile(mask_valid_x_uids, (num_lfs, 1)).T
        # Construct [n,k] mask indicating whether a particular LF voted
        mask_lf_voted = L_dense_array != -1
        # Construct [n,k] mask indicating whether LF voted incorrectly
        gt_labels = np.array(
            [x_uid_to_ground_truth.get(x_uid, -1) for x_uid in lm_x_uids]
        )
        tiled_gt_labels = np.tile(gt_labels, (num_lfs, 1)).T
        mask_incorrect_lf = L_dense_array != tiled_gt_labels

        # Compute incorrect counts by lf_idx as [k,] array
        incorrect_counts = (mask_valid_x_uids & mask_lf_voted & mask_incorrect_lf).sum(
            axis=0
        )

        # Aggregate incorrect counts by lf_uid for this pkg_uid + split
        for lf_idx, count in enumerate(incorrect_counts):
            lf_uid = lf_uids[lf_idx]
            lf_uid_to_num_errors[lf_uid] += count

        return lf_uid_to_num_errors

    def parse_postprocessed_spans(
        self, postprocessed_spans: List[metrics_utils.PostprocessedSpan]
    ) -> RawLabels:
        """Converts postprocessed spans into RawLabels for doc metrics"""
        raise NotImplementedError

    def array_probs_to_raw_probs(self, array_probs: List[Any]) -> List[Dict]:
        return array_probs

    def raw_probs_to_array_probs(self, raw_probs: List[Any]) -> List[Any]:
        return raw_probs

    def raw_probs_to_enumerate_array_probs(
        self, raw_probs: List[Any], **kwargs: Dict[str, Any]
    ) -> List[List[float]]:
        assert "klass" in kwargs  # mypy
        assert isinstance(kwargs["klass"], str)  # mypy
        klass = kwargs["klass"]
        label_int = self._label_map[klass]
        return [
            [1.0 - raw_prob[label_int], raw_prob[label_int]] for raw_prob in raw_probs
        ]

    def aggregate_prediction_scores(
        self, scores: List[Any], aggregation: AggregateScoreStrategy
    ) -> List[Any]:
        aggregates = []
        aggregate_f_dict = {
            AggregateScoreStrategy.average: lambda x: mean(x),
            AggregateScoreStrategy.max: lambda x: max(x),
            AggregateScoreStrategy.sum: lambda x: sum(x),
            AggregateScoreStrategy.none: lambda x: x,
        }
        if aggregation not in aggregate_f_dict:
            raise NotImplementedError(
                f"No implementation for multi-label aggregation {aggregation}"
            )
        aggregate_f = aggregate_f_dict[aggregation]
        for pred in scores:
            aggregates.append(aggregate_f(pred))

        return aggregates

    def raw_probs_to_confidences(self, raw_probs: List[Any]) -> List[Any]:
        return [[max(1.0 - prob, prob) for prob in raw_prob] for raw_prob in raw_probs]

    def raw_confidence_to_user_confidence(self, raw_confidence: Any) -> Any:
        return {
            self.inv_label_map[i]: raw_confidence[i] for i in range(len(raw_confidence))
        }

    def raw_probs_to_entropies(self, raw_probs: List[Any]) -> List[Any]:
        probs_dicts = [
            [{"1": prob, "0": 1.0 - prob} for prob in raw_prob]
            for raw_prob in raw_probs
        ]
        return [
            [self.probs_dict_to_entropy(probs_dict) for probs_dict in probs_dict_nested]
            for probs_dict_nested in probs_dicts
        ]

    def raw_labels_from_raw_probs(self, raw_probs: List[Any]) -> List[Any]:
        labels = [
            {
                class_str: self._raw_present_int
                if prob >= 0.5
                else self._raw_absent_int
                for class_str, prob in zip(self._class_strings, prob_list)
            }
            for prob_list in raw_probs
        ]
        # Add default key.
        for label in labels:
            label[self._default_key] = self._raw_unknown_int
        return labels

    def _convert_dense_label(self, dense_label: Any) -> float:
        if dense_label == -1:
            return ABSTAIN_PROB
        elif dense_label == 1:
            return 1.0
        return 0.0

    def raw_probs_from_raw_labels(self, raw_labels: List[Any]) -> List[Any]:
        return [
            [
                self._convert_dense_label(dense_label)
                for dense_label in self.to_dense_array(raw_label)
            ]
            for raw_label in raw_labels
        ]

    def raw_label_to_user_label(self, raw_label: Any) -> Any:
        if set(raw_label.values()) == {self.raw_unknown_int}:
            # If all labels are unknown, set user facing label to None
            return None
        user_label = {}
        for class_str, class_int in self.label_map.items():
            default_value = raw_label.get(self._default_key, self._raw_unknown_int)
            presence_int = raw_label.get(str(class_int), default_value)
            user_label[class_str] = MULTILABEL_PRESENCE_USER_LABEL_DICT[presence_int]
        return user_label

    def raw_labels_to_SME_labels(self, raw: RawLabels) -> UserLabels:
        user_labels_dict = self.raw_labels_to_user_labels(raw).labels
        user_labels_list: Dict[str, List[str]] = {}
        # Convert to a list per document of "PRESENT" labels
        for doc in list(user_labels_dict.keys()):
            if user_labels_dict[doc] is None:
                user_labels_list[doc] = []
                continue

            presents = []
            for key, value in user_labels_dict[doc].items():
                if value == "PRESENT":
                    presents.append(key)
            user_labels_list[doc] = presents
        return UserLabels(user_labels_list)

    def user_label_to_raw_label(
        self, user_label: Any, x_uid: Optional[str] = None
    ) -> Any:
        if user_label is None:
            return self.get_raw_unknown_label()
        elif isinstance(user_label, str):
            user_label = {user_label: "PRESENT"}
        # this is an internal representation and we don't expect the user to provide such input
        elif isinstance(user_label, tuple):
            user_label = {user_label[0]: user_label[1]}

        raw_label = {self._default_key: self._raw_unknown_int}
        all_class_strs = set(self.label_map.keys())
        all_class_strs.add(self._default_key)
        user_class_strs = set(user_label.keys())
        if not user_class_strs.issubset(all_class_strs):
            err_msg = f"User label dictionary must be a subset of all classes {all_class_strs}"
            if x_uid is not None:
                err_msg += f". x_uid:{x_uid}"
            raise ValueError(err_msg)
        # Support partial user labels
        for class_str in self.label_map.keys():
            presence_str = user_label.get(
                class_str, user_label.get(self._default_key, "ABSTAIN")
            )
            class_int_str = str(self.label_map[class_str])
            presence_int = MULTILABEL_INVERSE_PRESENCE_USER_LABEL_DICT[presence_str]
            if presence_int != self._raw_unknown_int:
                raw_label[class_int_str] = presence_int
        raw_label = self.compress_label(raw_label)
        return raw_label

    def remap_lf_label(self, label: Dict, remap: Dict) -> Optional[Dict]:
        # The remap_lf_label function is only used when changing a label map.
        # The remap dict will include all common labels shared by the two label maps.
        # All labels not in remap dict will not be included in remapped_label.
        remapped_label: Dict[str, int] = {}
        for class_int in remap.keys():
            if str(class_int) not in label:
                continue
            new_label = str(remap[class_int])
            if (
                new_label in remapped_label
                and remapped_label[new_label] != label[str(class_int)]
            ):
                # There are 2 potential ways to implement merging conflicting labels, we select the first
                # 1) Prioritize PRESENT, then ABSENT, then ABSTAIN, if we are merging labels then
                # a PRESENT vote in any of the subset labels should be PRESENT in the the superset label
                # 2) Select the values from the label that we are merging/mapping into
                remapped_label[new_label] = max(
                    remapped_label[new_label], label[str(class_int)]
                )
            else:
                remapped_label[new_label] = label[str(class_int)]
        remapped_label[self._default_key] = label.get(
            self._default_key, self._raw_unknown_int
        )
        return remapped_label

    def remap_labels(
        self,
        labels: Dict[str, Any],
        remap: Dict[Any, Any],
        filter_missing_keys: Optional[bool] = True,
    ) -> Dict[Any, Any]:
        # NOTE: This doesn't remap raw labels. Only user -> user.
        if not labels:
            return {}
        if isinstance(list(labels.values())[0], dict):
            # This doesn't remap raw labels.
            raise NotImplementedError
        if filter_missing_keys:
            return {
                x_uid: [remap[l] for l in label]
                for x_uid, label in labels.items()
                if all(l in remap for l in label)
            }
        return {
            x_uid: [remap.get(l, l) for l in label] for x_uid, label in labels.items()
        }

    def compress_label(self, raw_label: Dict) -> Dict:
        if not raw_label:
            raw_label = self.get_raw_unknown_label()
        if self._default_key not in raw_label:
            raw_label[self._default_key] = self._raw_unknown_int
        default_value = raw_label[self._default_key]
        value_freqs = Counter(raw_label.values())
        value_freqs[default_value] += self.cardinality - len(raw_label)
        # Sort to maintain the same default key to prevent non-determinism
        od_value_freqs = OrderedDict(sorted(value_freqs.items()))
        max_freq_key = max(od_value_freqs, key=od_value_freqs.get)  # type: ignore

        # default to the previous default_value on tie
        if value_freqs[max_freq_key] == value_freqs[default_value]:
            return raw_label

        raw_label_new = {"_default": max_freq_key}
        for class_int in self.label_map.values():
            class_int_str = str(class_int)
            prev_label = (
                raw_label[class_int_str]
                if class_int_str in raw_label
                else default_value
            )
            if prev_label != max_freq_key:
                raw_label_new[class_int_str] = prev_label

        return raw_label_new

    def get_label_remap_dict(
        self,
        old_label_space: LabelSpace,
        updated_label_schema: Optional[Dict[str, Optional[str]]],
    ) -> Optional[Dict[str, Optional[str]]]:
        """Compute label mapping for transfer given user mapping"""
        old_label_map = old_label_space.label_map
        label_map = self.label_map
        label_remap_dictionary = (
            deepcopy(updated_label_schema) if updated_label_schema is not None else None
        )

        # Map common label strings to themselves if not mapped to other labels by user
        common_labels = set(old_label_map).intersection(label_map)
        if common_labels:
            if label_remap_dictionary is None:
                label_remap_dictionary = {k: k for k in common_labels}
            else:
                for label in common_labels:
                    if label not in label_remap_dictionary:
                        label_remap_dictionary[label] = label

        return label_remap_dictionary

    @staticmethod
    def check(
        x: pd.Series, op_name: str, fault_tolerant: bool = False, *conditions: Any
    ) -> bool:
        """Check a (potentially composed) boolean condition on an individual datum
        The `fault_tolerant` param is used to return False for each condition where an error
        would normally be raised.
        """
        # Note: we purposely use more verbose logic to enable short-circuiting on $AND and $OR
        # Note: assertions on self.conditions length are done while parsing the graph so they're
        # not repeated here

        if op_name == constants.AND:
            for arg in conditions:
                if not MultiLabelSpace._safe_check(arg, x, fault_tolerant):
                    return False
            return True
        if op_name == constants.OR:
            for arg in conditions:
                if MultiLabelSpace._safe_check(arg, x, fault_tolerant):
                    return True
            return False
        if op_name == constants.NOT:
            return not MultiLabelSpace._safe_check(
                conditions[0], x, fault_tolerant, on_error_return=True
            )
        if op_name == constants.IS:
            return MultiLabelSpace._safe_check(conditions[0], x, fault_tolerant)
        raise KeyError(f"invalid LF Graph op_name provided: {op_name}")

    @staticmethod
    def _safe_check(
        condition: Any,
        x: pd.Series,
        fault_tolerant: bool,
        on_error_return: bool = False,
    ) -> bool:
        """Helper to check conditions of templates with fault tolerance."""
        if not fault_tolerant:
            return condition.check(x)
        try:
            return condition.check(x)
        except Exception:
            return on_error_return

    @staticmethod
    def compose_lf(label: Dict, condition: Any, fault_tolerant: bool) -> Callable:
        def lf(x: pd.Series) -> Dict:
            if condition.check(x, fault_tolerant=fault_tolerant):
                return label
            return MultiLabelSpace.get_raw_unknown_label()

        return lf

    def replace_abstain_with_negative_multilabel(
        self, preds: np.ndarray, lf_abstains: np.ndarray
    ) -> np.ndarray:
        (lf_abstain_rows,) = np.where(lf_abstains)
        pred_abstain_rows, pred_abstain_cols = np.where(preds == self._raw_unknown_int)
        replace_inds = ~np.isin(pred_abstain_rows, lf_abstain_rows)
        preds[
            pred_abstain_rows[replace_inds], pred_abstain_cols[replace_inds]
        ] = self._raw_absent_int

        return preds

    # TODO: investigate tie-break implementation (https://snorkelai.atlassian.net/browse/ENG-14546)
    def probs_to_preds_with_threshold(
        self,
        probs: np.ndarray,
        lf_abstains: Optional[np.ndarray] = None,
        tie_break_policy: str = "abstain",
        tol: float = 1e-5,
        filter_uncertain_labels_threshold: float = 0.0,
        postprocess_labels: bool = False,
    ) -> np.ndarray:
        perf_time_log = PerfTimeLog("Probs to preds for MultiLabelSpace")

        if isinstance(probs, np.ndarray):
            # Convert to list to handle edge case where
            # probs is an ndarray of Lists, which does not
            # properly broadcast
            probs = probs.tolist()
        probs = np.array(probs)

        perf_time_log.update("Munge probs")

        mask_non_tied_probs = np.abs(probs - 0.5) < tol

        # ties = True, non-ties = False.

        present_arr = probs >= (0.5 - tol)
        # 0 == absent, 1 == present + ties

        perf_time_log.update("Compute ties and present array")

        if tie_break_policy == "random":
            np.random.seed(123)
            tie_break_arr = 1 - (
                mask_non_tied_probs
                * np.random.randint(2, size=mask_non_tied_probs.shape)
            )
            # 0 == tie => absent, 1 == (tie => present) + other

            preds = tie_break_arr * present_arr
            preds[lf_abstains] = self.raw_unknown_int
            # 0 = absent, 1 = present.

        elif tie_break_policy == "abstain":
            mask_tied_probs = -2 * mask_non_tied_probs
            preds = mask_tied_probs + present_arr

            if lf_abstains is not None:
                preds[lf_abstains] = self.raw_unknown_int

        elif tie_break_policy == "true-random":
            preds = np.vstack(
                [
                    probs_to_preds_with_threshold_flat(
                        np.stack(
                            [1.0 - probs[:, class_int], probs[:, class_int]], axis=1
                        ),
                        tie_break_policy,
                        tol,
                        filter_uncertain_labels_threshold,
                        self.raw_unknown_int,
                        lf_abstains=lf_abstains,
                    )
                    for class_int in sorted(self.label_map.values())
                ]
            ).T
        else:
            raise ValueError(f"Invalid `tie_break_policy` passed {tie_break_policy}.")

        #        preds = self.replace_abstain_with_negative_multilabel(preds, lf_abstains)

        perf_time_log.update("Compute tie-breaks")

        default_int = self._raw_unknown_int

        # Sparse RawLabels format
        # NOTE: Changing default_int to a different value will break
        # has_unknown in data_models/label.py.
        raw_Y = [{"_default": default_int} for i in range(len(preds))]
        sparse_preds = np.argwhere(preds != default_int)

        perf_time_log.update("Initialize preds and compute non-default preds")

        for example_idx, class_int in sparse_preds:
            # Casting to int here as otherwise, the dtype of the set value is
            # np.int64, which breaks fastapi
            raw_Y[example_idx][str(class_int)] = int(preds[example_idx][class_int])

        perf_time_log.update("Fill in preds return arg")

        raw_Y = list(map(self.compress_label, raw_Y))
        raw_Y = np.array(raw_Y)

        perf_time_log.update("Compress pred labels and make numpy array")

        return raw_Y

    # For multi-label we're computing abstains the way we do by default in the TDM API
    def compute_lf_abstains(
        self, L: sparse._coo.core.COO, probas: Optional[np.ndarray] = None
    ) -> np.ndarray:
        abstains = L.sum(axis=(1, 2, 3)) == 0
        if isinstance(abstains, sparse._coo.core.COO):
            abstains = abstains.todense()

        return abstains

    def _single_class_matches(
        self, label: Dict[str, int], label_int: int, vote_type: int
    ) -> bool:
        label_default = label.get(self._default_key, self._raw_unknown_int)
        return label.get(str(label_int), label_default) == vote_type

    def get_new_gt_mask(
        self,
        x_uids_and_labels_per_split: Dict[str, Dict[str, List[Any]]],
        metadata_df: pd.DataFrame,
        split: str,
    ) -> Tuple[np.ndarray, np.ndarray]:
        valid_splits = [Splits.dev, Splits.valid]
        if split not in valid_splits:
            err_msg = f"Invalid split selected: {split}. This function only works on {valid_splits}"
            raise UserInputError(detail=err_msg, user_friendly_message=err_msg)

        gt_vector = pd.Series(
            data=x_uids_and_labels_per_split[split]["labels"],
            index=x_uids_and_labels_per_split[split]["x_uids"],
        )
        new_mask = self.create_binary_mask(gt_vector)
        indices_to_replace = np.where(
            metadata_df.index.isin(x_uids_and_labels_per_split[split]["x_uids"])
        )

        return new_mask, indices_to_replace

    def create_binary_mask(
        self, data_vector: pd.Series, class_ints: Optional[List[int]] = None
    ) -> np.ndarray:
        # To prevent OOM issues, ensure data_vector does not contain data from train
        data_labels = list(data_vector)
        card = len(class_ints) if class_ints else self.cardinality
        rows = len(data_labels)
        # num_data_points x num_classes
        data_mask = np.full((rows, card), self._raw_unknown_int)
        for i, data_label in enumerate(data_labels):
            data_mask[i, :] = self._to_dense_array(data_label, class_ints=class_ints)
        return data_mask

    def _get_gt_label_mask(
        self, vote_type: int, label_int: int, label_vector: pd.Series
    ) -> pd.Series:
        return label_vector.apply(
            self._single_class_matches, label_int=label_int, vote_type=vote_type
        )

    def get_gt_comparison_mask(
        self, gt_vector: pd.Series, config: Dict[str, Any]
    ) -> pd.Series:
        """
        Returns a mask of non-abstained eamples  unless vote type is
        unknown. In that case it returns a vector of all true
        """
        if config["vote_type"] in [
            constants.CORRECT,
            constants.INCORRECT,
            constants.CORRECT_OR_UNKNOWN,
            constants.INCORRECT_OR_UNKNOWN,
        ]:
            gt_labels = list(gt_vector)
            return pd.Series(
                [
                    set(gt_label.values()) != {self._raw_unknown_int}
                    for gt_label in gt_labels
                ]
            )
        return pd.Series([True for _ in range(len(gt_vector))])

    def _label_votes_all_like_gt(
        self, gt_label: Dict[str, Any], data_label: Dict[str, Any]
    ) -> bool:
        """
        Checks whether a data label would yield "all correct" when compared to ground truth label.
        This is defined as all non-unknown classes as matching exactly with GT.
        """
        # NOTE: Examples where GT or data all vote unknown are filtered out in a different stage
        # by the unknown mask

        data_label_default = data_label.get(self._default_key, self._raw_unknown_int)
        gt_label_default = gt_label.get(self._default_key, self._raw_unknown_int)

        for class_int in self.label_map.values():
            class_int_str = str(class_int)
            data_presence_label = data_label.get(class_int_str, data_label_default)
            gt_presence_label = gt_label.get(class_int_str, gt_label_default)

            # For any labels that are present or absent for both GT and data label,
            # if they disagree then the labels do not match
            if (
                data_presence_label != self._raw_unknown_int
                and gt_presence_label != self._raw_unknown_int
            ):
                if data_presence_label != gt_presence_label:
                    return False
        return True

    def _label_votes_any_like_gt(
        self, gt_label: Dict[str, Any], data_label: Dict[str, Any]
    ) -> bool:
        """
        Checks whether a data label would yield "any correct" when compared to ground truth label.
        This is defined as any non-unknown classes as matching with GT.
        """
        # NOTE: Examples where GT or data all vote unknown are filtered out in a different stage
        # by the unknown mask
        data_label_default = data_label.get(self._default_key, self._raw_unknown_int)
        gt_label_default = gt_label.get(self._default_key, self._raw_unknown_int)

        for class_int in self.label_map.values():
            class_int_str = str(class_int)
            data_presence_label = data_label.get(class_int_str, data_label_default)
            gt_presence_label = gt_label.get(class_int_str, gt_label_default)

            # For any labels that are present or absent for both GT and data label,
            # if they agree then they `any match`
            if (
                data_presence_label != self._raw_unknown_int
                and gt_presence_label != self._raw_unknown_int
            ):
                if data_presence_label == gt_presence_label:
                    return True
        return False

    def single_class_vote(
        self, vote_type: str, voted: str, data_vector: pd.Series
    ) -> pd.DataFrame:
        vote_type_int = int(vote_type)

        if voted in [constants.ALL_CLASSES, constants.ANY_CLASS]:
            raw_mask = []
            for label in list(data_vector):
                if voted == constants.ALL_CLASSES:
                    raw_mask.append(
                        all(
                            self._single_class_matches(label, class_int, vote_type_int)
                            for class_int in self.label_map.values()
                        )
                    )
                elif voted == constants.ANY_CLASS:
                    raw_mask.append(
                        any(
                            self._single_class_matches(label, class_int, vote_type_int)
                            for class_int in self.label_map.values()
                        )
                    )
            return pd.DataFrame({"mask": raw_mask})
        else:
            # Vote_type is 1/0/-1, and voted is a specific class int
            return pd.DataFrame(
                {
                    "mask": self._get_gt_label_mask(
                        vote_type_int, self.label_map[voted], data_vector
                    )
                }
            )

    def return_filter_mask(
        self, vote_type: str, unknown_mask: pd.Series, filter_mask: pd.Series
    ) -> Optional[pd.DataFrame]:
        if vote_type == constants.INCORRECT:
            return pd.DataFrame({"mask": unknown_mask & ~filter_mask})
        elif vote_type == constants.CORRECT:
            return pd.DataFrame({"mask": unknown_mask & filter_mask})
        elif vote_type == constants.INCORRECT_OR_UNKNOWN:
            return pd.DataFrame({"mask": ~unknown_mask | ~filter_mask})
        elif vote_type == constants.CORRECT_OR_UNKNOWN:
            return pd.DataFrame({"mask": ~unknown_mask | filter_mask})
        return None

    def filter_label_vector(
        self,
        data_vector: pd.Series,
        gt_vector: pd.Series,
        config: Dict[str, Any],
        x_uids: Optional[List[str]] = None,
        split: str = "dev",
    ) -> pd.DataFrame:
        from ray_utils import constants as ray_constants

        """This function returns a mask (filter representation) given a data vector
        and a ground truth vector. When sentinel values 'correct' or 'incorrect' are specified,
        the data vector is compared to the GT vector; in all other cases, the data vector
        is checked for specific class / vote parameters specified in the `config`.

        Voted will either be a str representation of a class, or some special value
        to indicate a derived calculation (i.e. 'correct' -> data is same as gt. Each label
        space may take different special values."""
        voted = config["voted"]
        vote_type = config["vote_type"]
        una = ray_constants.USER_NODE_ACTOR

        if una and any([key in config for key in ["lf", "model_uid", "ts_uid"]]):
            # This codepath is for running inside the UNA for filters that compare
            # LF votes, model votes, or TS with GT.
            assert isinstance(x_uids, list)  # mypy
            return self._filter_label_vector_una(data_vector, config, split, x_uids)

        if vote_type in [
            constants.CORRECT,
            constants.INCORRECT,
            constants.CORRECT_OR_UNKNOWN,
            constants.INCORRECT_OR_UNKNOWN,
        ]:
            gt_labels = list(gt_vector)
            data_labels = list(data_vector)

            gt_unknown_mask = self.get_gt_comparison_mask(gt_vector, config)
            data_unknown_mask = pd.Series(
                [
                    set(data_label.values()) != {self._raw_unknown_int}
                    for data_label in data_labels
                ]
            )
            unknown_mask = gt_unknown_mask & data_unknown_mask

            # Any incorrect == ~All correct
            if (
                voted == constants.ALL_CLASSES
                and vote_type in [constants.CORRECT, constants.CORRECT_OR_UNKNOWN]
            ) or (
                voted == constants.ANY_CLASS
                and vote_type in [constants.INCORRECT, constants.INCORRECT_OR_UNKNOWN]
            ):
                filter_mask = pd.Series(
                    [
                        self._label_votes_all_like_gt(gt_label, data_label)
                        for data_label, gt_label in zip(data_labels, gt_labels)
                    ]
                )
            # All incorrect == ~Any correct
            elif (
                voted == constants.ANY_CLASS
                and vote_type in [constants.CORRECT, constants.CORRECT_OR_UNKNOWN]
            ) or (
                voted == constants.ALL_CLASSES
                and vote_type in [constants.INCORRECT, constants.INCORRECT_OR_UNKNOWN]
            ):
                filter_mask = pd.Series(
                    [
                        self._label_votes_any_like_gt(gt_label, data_label)
                        for data_label, gt_label in zip(data_labels, gt_labels)
                    ]
                )
            else:
                label_match_for_class = []
                not_unknown_for_class = []
                for data_label, gt_label in zip(data_labels, gt_labels):
                    default_gt_label = gt_label.get(
                        self._default_key, self._raw_unknown_int
                    )
                    default_data_label = data_label.get(
                        self._default_key, self._raw_unknown_int
                    )
                    gt_label_for_class = gt_label.get(
                        str(self.label_map[voted]), default_gt_label
                    )
                    data_label_for_class = data_label.get(
                        str(self.label_map[voted]), default_data_label
                    )
                    gt_not_unknown_for_class = (
                        gt_label_for_class != self._raw_unknown_int
                    )
                    data_not_unknown_for_class = (
                        data_label_for_class != self._raw_unknown_int
                    )
                    not_unknown_for_class.append(
                        gt_not_unknown_for_class and data_not_unknown_for_class
                    )
                    label_match_for_class.append(
                        gt_label_for_class == data_label_for_class
                    )
                filter_mask = pd.Series(label_match_for_class)
                unknown_mask = unknown_mask & pd.Series(not_unknown_for_class)
            mask = self.return_filter_mask(vote_type, unknown_mask, filter_mask)
            if mask is not None:
                return mask

        # Single class vote for global and class-specific filters
        return self.single_class_vote(vote_type, voted, data_vector)

    def _filter_label_vector_una(
        self,
        data_vector: pd.Series,
        config: Dict[str, Any],
        split: str,
        x_uids: List[str],
    ) -> pd.DataFrame:
        from ray_utils import constants as ray_constants

        """This function returns a mask (filter representation) given for an LF when UNA is enabled."""

        voted = config["voted"]
        vote_type = config["vote_type"]
        una = ray_constants.USER_NODE_ACTOR
        metadata_df_index = una.get_metadata_df(split).index
        indices_to_use = np.where(metadata_df_index.isin(x_uids))

        gt_mask = una.get_gt_mask(split)[indices_to_use]

        gt_unknown_mask_array = gt_mask == -1

        data_mask = None

        if "model_uid" in config:
            model_uid = config["model_uid"]
            data_mask = una.get_model_mask(model_uid, split)
        elif "ts_uid" in config:
            ts_uid = config["ts_uid"]
            data_mask = una.get_ts_mask(ts_uid, split)

        # Correct / incorrect require comparing to ground truth
        if vote_type in [
            constants.CORRECT,
            constants.INCORRECT,
            constants.CORRECT_OR_UNKNOWN,
            constants.INCORRECT_OR_UNKNOWN,
        ]:
            if "lf" in config:
                lf = config["lf"]
                # If the filter is for a single LF
                if lf != "all" and lf != "none" and lf != "any":
                    data_mask = una.get_lf_mask(data_vector.name, split)
                else:
                    # Here we are looping through LFs one by one where data_vector.name is the index
                    # We use the index to retrieve the LF mask since dict keys are sorted now
                    keys = list(una.lf_vote_masks[split].keys())
                    ind = data_vector.name
                    lf_name = keys[int(ind)]
                    data_mask = una.get_lf_mask(lf_name, split)

            data_mask = data_mask[indices_to_use]  # type: ignore
            data_unknown_mask_array = data_mask == -1
            gt_unknown_mask = np.any(~gt_unknown_mask_array, axis=1)
            data_unknown_mask = np.any(~data_unknown_mask_array, axis=1)
            unknown_mask = gt_unknown_mask & data_unknown_mask

            # Any incorrect == ~All correct
            if (
                voted == constants.ALL_CLASSES
                and vote_type in [constants.CORRECT, constants.CORRECT_OR_UNKNOWN]
            ) or (
                voted == constants.ANY_CLASS
                and vote_type in [constants.INCORRECT, constants.INCORRECT_OR_UNKNOWN]
            ):
                # Datapoints where the LF votes match the GT
                filter_mask = gt_mask == data_mask

                # Add datapoints where the LF votes are unknown.
                filter_mask = filter_mask | (
                    gt_unknown_mask_array | data_unknown_mask_array
                )

                # Return if true for all classes. This captures all the datapoints where the LF votes correct on
                # all non-unknown classes matching exactly with GT. A disagreement is only relevant if both the GT
                # and the LF vote are unknown since only then can we know for sure that it is incorrect
                filter_mask = np.all(filter_mask, axis=1)
            # All incorrect == ~Any correct
            elif (
                voted == constants.ANY_CLASS
                and vote_type in [constants.CORRECT, constants.CORRECT_OR_UNKNOWN]
            ) or (
                voted == constants.ALL_CLASSES
                and vote_type in [constants.INCORRECT, constants.INCORRECT_OR_UNKNOWN]
            ):
                # Datapoints where the LF votes match the GT
                filter_mask = gt_mask == data_mask

                # Remove datapoints where the both LF and GT are unknown
                filter_mask = filter_mask & (
                    ~gt_unknown_mask_array | ~data_unknown_mask_array
                )

                # Return if true for any class. This captures all the datapoints where the LF votes correct on
                # any non-unknown class matching with GT. The agreement is only relevant if both the GT and the LF
                # are known since only then can we know for sure that it is correct
                filter_mask = np.any(filter_mask, axis=1)
            else:
                # Datapoints where the LF votes match the GT for specific class
                filter_mask = (
                    gt_mask[:, self.label_map[voted]]
                    == data_mask[:, self.label_map[voted]]
                )

                # Datapoints where LF vote and GT vote are unknown for specific class
                unknown_mask = (
                    ~gt_unknown_mask_array[:, self.label_map[voted]]
                    & ~data_unknown_mask_array[:, self.label_map[voted]]
                )

            mask = self.return_filter_mask(vote_type, unknown_mask, filter_mask)
            if mask is not None:
                return mask
        elif data_mask is not None:
            data_mask = data_mask[indices_to_use]
            # Single class vote for global and class-specific filters
            vote_type_int = int(vote_type)

            if voted in [constants.ALL_CLASSES, constants.ANY_CLASS]:
                if voted == constants.ALL_CLASSES:
                    raw_mask = np.all(data_mask == vote_type_int, axis=1)
                elif voted == constants.ANY_CLASS:
                    raw_mask = np.any(data_mask == vote_type_int, axis=1)
            else:
                # Vote_type is 1/0/-1, and voted is a specific class int
                # return gt_mask
                raw_mask = (
                    np.squeeze(data_mask[:, self.label_map[voted]]) == vote_type_int
                )
            if isinstance(raw_mask, np.bool_):
                raw_mask = np.array([raw_mask])

            return pd.DataFrame({"mask": raw_mask})
        else:
            return self.single_class_vote(vote_type, voted, data_vector)

    def filter_label_vector_by_label(
        self, label_vector: pd.Series, label: Any
    ) -> pd.Series:
        """Filter labels of any type (e.g., GT, prediction, LF vote) that are relevant to the provided label."""
        self.validate_lf_label(label)
        # Being correct at all classes is multi-label's equivalent for single-label's being correct at a single class
        vote_config = {"vote_type": constants.CORRECT, "voted": constants.ALL_CLASSES}
        filter = self.filter_label_vector(
            pd.Series(np.tile(label, len(label_vector))), label_vector, vote_config
        )["mask"]
        return filter

    def _decompress_labels(self, labels: Dict, config: Dict[str, Any]) -> Dict:
        """Decompresses LF votes to have a more straightforward mapping between each label and its LF vote.

        Parameters
        ----------
        labels : Dict
            The compressed representation of a label.
        config : Dict[str, any]
            Config dictionary.

        Returns
        -------
        Dict
            The decompressed representation of a label.
        """
        if self._default_key in labels:
            decompressed = dict()
            label_keys = map(str, self.label_map.values())

            # For each label in the label map, copy the value over from decompressed_label to compressed_label.
            # If it doesn't exist in decompressed_label, use the default value.
            for key in label_keys:
                if key in labels:
                    decompressed[key] = labels[key]
                else:
                    decompressed[key] = labels[self._default_key]

            return decompressed

        else:
            # If compressed_label doesn't have the default key, we don't process it. I'd rather not assert.
            return dict(labels)

    def filter_lf_conflict(self, data_row: pd.Series, config: Dict[str, Any]) -> bool:
        """Computes conflict among LFs based on whether the absolute score for a label matches the number of votes.
        If one LF votes +1 and another votes -1, then the absolute score of the label will be less than the
        number of votes and thus we detect a conflict.
        """
        label_scores: Counter = Counter()
        label_votes: Counter = Counter()

        # Maintain a score for each label. A present vote is +1, an absent vote is -1.
        # Also keep a Counter of LFs that voted for a label. Don't count abstains.
        for lf_votes in list(data_row):
            lf_votes = self._decompress_labels(lf_votes, config)

            for label in lf_votes:
                # Ignore the _default key.
                if label == self._default_key:
                    continue

                if lf_votes[label] == self._raw_present_int:
                    label_scores[label] += 1
                    label_votes[label] += 1
                elif lf_votes[label] == self._raw_absent_int:
                    label_scores[label] -= 1
                    label_votes[label] += 1

        # The absolute value of the score for each label should be the number of LFs that voted.
        # Any discrepancy means that there is conflict among the LFs that voted for a label.
        # For example, if a label received three +1's and a -1, that means that 4 LFs voted but the score is only 2.
        for label, score in label_scores.items():
            votes = label_votes[label]

            if abs(score) != votes:
                return True

        return False

    def get_text_to_code_base_prompt(self, df: pd.DataFrame) -> str:
        return f"""
    Act as a senior Python software engineer. Respond only with code, do not include any other text in your response. Do not include ``` or 'python' as part of the response.

    The goal is fill in the following function. The context is that this is a function used for multilabel classification, where a row can be PRESENT, ABSENT, or ABSTAIN for each of the classes. Output the function definition, as well as the completion of the function body.
    Do not import external libraries.

def determine_class(row) -> Dict[str, str]:
    label_dict = {{'_default': 'ABSTAIN'}}
    do_something...
    return label_dict

    This function will be applied in a df.apply(determine_class, axis=1) call later. Note that the DF has access to the following fields: {str(df.columns)}. Here is a sample of the dataframe: {str(df.head())}.

    The function should return a dictionary mapping only the necessary keys in {self.label_map} to either 'PRESENT' or 'ABSENT'. The _default key will handle all other classes, that aren't specificed by the request.
    """

    def get_gt_filter_structure(self) -> List[Dict[str, Any]]:
        return [
            dict(
                input_name="gt",
                component="Render",
                default="Ground truth is",
                options=None,
                size=3,
            ),
            dict(
                input_name="vote_type",
                component="CustomChoices",
                default=None,
                options=[
                    {"title": "present", "value": self._raw_present_int},
                    {"title": "absent", "value": self._raw_absent_int},
                    {"title": "unknown", "value": self._raw_unknown_int},
                ],
                size=2,
            ),
            dict(
                input_name="on", component="Render", default="on", options=None, size=1
            ),
            dict(
                input_name="voted",
                component="CustomChoices",
                default=None,
                options=self._get_label_choices(
                    [constants.ALL_CLASSES] + list(self.label_map.keys())
                ),
                size=2,
            ),
        ]

    def get_ts_filter_structure(
        self, training_set_names: List[str], training_set_uids: List[int]
    ) -> List[Dict[str, Any]]:
        return [
            dict(
                input_name="ts_uid",
                component="CustomChoices",
                default=None,
                options=[
                    {"title": name, "value": ts_uid}
                    for name, ts_uid in zip(training_set_names, training_set_uids)
                ],
                size=2,
            ),
            dict(
                input_name="labels",
                component="Render",
                default="labels",
                options=None,
                size=1,
            ),
            dict(
                input_name="vote_type",
                component="CustomChoices",
                default=None,
                options=[
                    {"title": "correct", "value": constants.CORRECT},
                    {"title": "incorrect", "value": constants.INCORRECT},
                    {"title": "present", "value": self._raw_present_int},
                    {"title": "absent", "value": self._raw_absent_int},
                    {"title": "unknown", "value": self._raw_unknown_int},
                ],
                size=2,
            ),
            dict(
                input_name="on", component="Render", default="on", options=None, size=1
            ),
            dict(
                input_name="voted",
                component="CustomChoices",
                default=None,
                options=self._get_label_choices(
                    [constants.ALL_CLASSES, constants.ANY_CLASS]
                    + list(self.label_map.keys())
                ),
                size=2,
            ),
        ]

    def get_model_filter_structure(
        self, models: List[str], model_uids: List[int]
    ) -> List[Dict[str, Any]]:
        return [
            dict(
                input_name="model_uid",
                component="CustomChoices",
                default=None,
                options=[
                    {"title": name, "value": model_uid}
                    for name, model_uid in zip(models, model_uids)
                ],
                size=2,
            ),
            dict(
                input_name="predicts",
                component="Render",
                default="votes",
                options=None,
                size=1,
            ),
            dict(
                input_name="vote_type",
                component="CustomChoices",
                default=None,
                options=[
                    {"title": "correct", "value": constants.CORRECT},
                    {"title": "incorrect", "value": constants.INCORRECT},
                    {"title": "present", "value": self._raw_present_int},
                    {"title": "absent", "value": self._raw_absent_int},
                ],
                size=2,
            ),
            dict(
                input_name="on", component="Render", default="on", options=None, size=1
            ),
            dict(
                input_name="voted",
                component="CustomChoices",
                default=None,
                options=self._get_label_choices(
                    [constants.ALL_CLASSES, constants.ANY_CLASS]
                    + list(self.label_map.keys())
                ),
                size=2,
            ),
        ]

    def get_lf_filter_structure(
        self, lf_names: List[str], lf_uids: List[int]
    ) -> List[Dict[str, Any]]:
        return [
            dict(
                input_name="lf",
                component="CustomChoices",
                default=None,
                options=constants.LF_GENERAL_OPTIONS
                + [
                    {"title": name, "value": lf_uid}
                    for name, lf_uid in zip(lf_names, lf_uids)
                ],
                size=2,
            ),
            dict(
                input_name="voted_str",
                component="Render",
                default="votes",
                options=None,
                size=1,
            ),
            dict(
                input_name="vote_type",
                component="CustomChoices",
                default=None,
                options=[
                    {"title": "correct", "value": constants.CORRECT},
                    {"title": "incorrect", "value": constants.INCORRECT},
                    {
                        "title": "correct or unknown",
                        "value": constants.CORRECT_OR_UNKNOWN,
                    },
                    {
                        "title": "incorrect or unknown",
                        "value": constants.INCORRECT_OR_UNKNOWN,
                    },
                    {"title": "present", "value": self._raw_present_int},
                    {"title": "absent", "value": self._raw_absent_int},
                    {"title": "unknown", "value": self._raw_unknown_int},
                ],
                size=2,
            ),
            dict(
                input_name="on", component="Render", default="on", options=None, size=1
            ),
            dict(
                input_name="voted",
                component="CustomChoices",
                default=None,
                options=self._get_label_choices(
                    [constants.ALL_CLASSES] + list(self.label_map.keys())
                ),
                size=2,
            ),
        ]

    def get_annotation_filter_structure(
        self,
        annotator_names: List[str],
        annotator_uids: List[int],
        in_annotation_mode: Optional[bool] = None,
    ) -> List[Dict[str, Any]]:
        aggregate_options = (
            constants.BATCH_AWARE_ANNOTATION_AGGREGATE_OPTIONS
            if in_annotation_mode
            else constants.ANNOTATION_AGGREGATE_OPTIONS
        )

        return [
            dict(
                input_name="annotator",
                component="CustomChoices",
                default=None,
                options=aggregate_options
                + [
                    {"title": name, "value": lf_uid}
                    for name, lf_uid in zip(annotator_names, annotator_uids)
                ],
                size=2,
            ),
            dict(
                input_name="labeled",
                component="Render",
                default="labeled",
                options=None,
                size=1,
            ),
            dict(
                input_name="vote_type",
                component="CustomChoices",
                default=None,
                options=[
                    {"title": "correct", "value": constants.CORRECT},
                    {"title": "incorrect", "value": constants.INCORRECT},
                    {"title": "present", "value": self._raw_present_int},
                    {"title": "absent", "value": self._raw_absent_int},
                ],
                size=2,
            ),
            dict(
                input_name="on", component="Render", default="on", options=None, size=1
            ),
            dict(
                input_name="voted",
                component="CustomChoices",
                default=None,
                options=self._get_label_choices(
                    [constants.ANY_CLASS, constants.ALL_CLASSES]
                    + list(self.label_map.keys())
                ),
                size=2,
            ),
        ]

    def get_annotation_agreement_filter_structure(
        self,
        annotator_names: List[str],
        annotator_uids: List[int],
        in_annotation_mode: Optional[bool],
    ) -> List[Dict[str, Any]]:
        return [
            dict(
                input_name="annotator_uid_one",
                display_name="Annotator one",
                component="CustomChoices",
                default=None,
                options=[
                    {"title": annotator, "value": user_uid}
                    for annotator, user_uid in zip(annotator_names, annotator_uids)
                ],
                size=6,
            ),
            dict(
                input_name="and",
                component="Render",
                default="and",
                options=None,
                size=2,
            ),
            dict(
                input_name="annotator_uid_two",
                display_name="Annotator two",
                component="CustomChoices",
                default=None,
                options=[
                    {"title": annotator, "value": user_uid}
                    for annotator, user_uid in zip(annotator_names, annotator_uids)
                ],
                size=6,
            ),
            dict(
                input_name="vote_type",
                component="CustomChoices",
                display_name="Disagree",
                default=None,
                options=[
                    {"title": "Agree", "value": constants.CORRECT},
                    {"title": "Disagree", "value": constants.INCORRECT},
                ],
                size=4,
            ),
            dict(
                input_name="on", component="Render", default="on", options=None, size=1
            ),
            dict(
                input_name="voted",
                component="CustomChoices",
                default=None,
                options=self._get_label_choices(
                    [constants.ANY_CLASS, constants.ALL_CLASSES]
                    + list(self.label_map.keys())
                ),
                size=2,
            ),
        ]

    def min_samples_per_class(
        self, labeled_data: pd.DataFrame, gt_field: str, min_samples_per_class: int
    ) -> pd.DataFrame:
        """Creates a mapping from each class to a list of datapoints, and then builds a list of
        sampled datapoints by selecting N examples from each class. Returns a subset of the
        original labeled data, following this sampling scheme.
        """
        class_to_datapoints = defaultdict(set)
        for idx, label in zip(list(labeled_data.index), list((labeled_data[gt_field]))):
            for class_int in self.label_map.values():
                label_default = label.get(self._default_key, self._raw_unknown_int)
                vote = label.get(str(class_int), label_default)
                if vote == self._raw_present_int:
                    class_to_datapoints[class_int].add(idx)
        final_sampled_point_idxs: Set[int] = set()
        for k in sorted(
            class_to_datapoints, key=lambda k: len(class_to_datapoints[k]), reverse=True
        ):
            all_datapoints_with_key = class_to_datapoints[k]
            unsampled_datapoints = all_datapoints_with_key - final_sampled_point_idxs

            overlap = len(all_datapoints_with_key) - len(unsampled_datapoints)
            # If we have more than the minimum already sampled,
            # we don't need to sample any more for that class
            num_datapoints_needed_to_meet_min = max(0, min_samples_per_class - overlap)

            if len(unsampled_datapoints) <= num_datapoints_needed_to_meet_min:
                final_sampled_point_idxs = final_sampled_point_idxs.union(
                    unsampled_datapoints
                )
            else:
                sampled_datapoints = random.sample(
                    unsampled_datapoints, num_datapoints_needed_to_meet_min
                )
                final_sampled_point_idxs = final_sampled_point_idxs.union(
                    set(sampled_datapoints)
                )
        return labeled_data.loc[list(final_sampled_point_idxs)]

    def create_analysis_df(
        self,
        df: pd.DataFrame,
        gt_labels_col: str,
        model_probs_col: str,
        class_int: Optional[int] = None,
    ) -> pd.DataFrame:
        if len(df) == 0:
            return df

        if class_int is not None:
            for col in df.columns:
                if col == model_probs_col:
                    # Make probs an array of length 2, where class 1 is positive class for precision and recall
                    # Since not every model returns probs and not every datapoint gets preds/probs, need to check if all probs exist
                    if (~df[col].isnull()).all():
                        df[model_probs_col] = df[model_probs_col].apply(
                            lambda arr: [1 - arr[class_int], arr[class_int]]
                        )
                    continue
                df[col] = df[col].apply(
                    lambda d: d.get(str(class_int), d.get(self._default_key))
                    if d != self.raw_unknown_int
                    else self.raw_unknown_int
                )
            return df[df[gt_labels_col] != self._raw_unknown_int]

        # NOTE: We drop model probs because they are not used for all labels
        # in analysis page
        df = df.drop(model_probs_col, axis=1)
        for col in df.columns:
            df[col] = df[col].apply(
                lambda d: np.array(self.to_dense_array(d))
                if d != self.raw_unknown_int
                else np.repeat(self.raw_unknown_int, self.cardinality)
            )
        # Flatten columns
        new_df_raw = {}
        for col in df.columns:
            new_df_raw[col] = np.hstack(df[col].ravel())
            del df[col]
        df = pd.DataFrame(new_df_raw)
        return df[df[gt_labels_col] != self._raw_unknown_int]

    def compute_interannotator_aggregate_metric(
        self,
        user_raw_labels_map: Dict[str, RawLabels],
        metric: str = "krippendorff-alpha",
    ) -> float:
        user_labels_map = {
            user: {doc: json.dumps(label) for doc, label in raw_labels.labels.items()}
            for user, raw_labels in user_raw_labels_map.items()
        }
        if metric == "krippendorff-alpha":
            return metrics_utils.compute_krippendorff_alpha(user_labels_map)
        err_msg = f"Only the krippendorff-alpha metric is currently supported. Requested metric: {metric}"
        raise NotSupportedException(detail=err_msg, user_friendly_message=err_msg)

    def get_label_model_list(
        self,
        label_model_list: List[Any],
        sample_df: pd.DataFrame,
        num_train_rows: int,
        num_lfs: int,
    ) -> List[Dict[str, Any]]:
        if self.cardinality > MULTILABEL_MAJORITY_VOTE_CARDINALITY:
            add_gt = type(label_model_list[0]) == dict and label_model_list[0].get(
                "use_gt", True
            )

            label_model_name = (
                "GroundTruthMultiLabelModel"
                if add_gt
                else "MajorityVoteMultiLabelModel"
            )

            label_model_list = [
                {"label_model_name": label_model_name, "use_gt": add_gt}
            ]

            logger.info(
                f"Switching to {label_model_name}, since cardinality > {MULTILABEL_MAJORITY_VOTE_CARDINALITY}"
            )
        return label_model_list

    @staticmethod
    def find_missing_predicted_classes(Y: np.ndarray) -> None:
        if not isinstance(Y[0], dict):
            raise TypeError("Multi label space requires a dictionary as Y.")

    def validate_lf_label(self, lf_label: Dict) -> bool:
        if not isinstance(lf_label, dict):
            raise TypeError("`lf_label` must be a `dict`.")
        try:
            self.validate_raw_labels(RawLabels({"dummy_xuid": lf_label}))
        except Exception:
            return False
        return True

    def _compute_label_counts(
        self, annotations: List[Any], presence_int: int
    ) -> defaultdict:
        label_count: defaultdict = defaultdict(int)
        for annotation in annotations:
            default_label = annotation.label.get(
                self._default_key, self._raw_unknown_int
            )
            for label_int in self._label_map.values():
                label_int_str = str(label_int)
                presence_label = annotation.label.get(label_int_str, default_label)
                if presence_label == presence_int:
                    label_count[label_int] += 1
        return label_count

    def compute_label_counts(self, annotations: List[Any]) -> defaultdict:
        return self._compute_label_counts(annotations, self._raw_present_int)

    def _simple_union(
        self,
        annotations_array: List[List[Any]],
        source_uid: int,
        random_seed: int = 123,
    ) -> List[Dict]:
        new_annotations = []
        unknown_count = 0

        # initializing random seed
        random.seed(random_seed)

        # iterating over each annotation series for each x_uid
        for annotations in annotations_array:
            present_label_counts = self._compute_label_counts(
                annotations, self._raw_present_int
            )
            absent_label_counts = self._compute_label_counts(
                annotations, self._raw_absent_int
            )

            label: Dict[str, Any] = {self._default_key: 0}
            for label_int in self._label_map.values():
                if present_label_counts[label_int] > absent_label_counts[label_int]:
                    label[str(label_int)] = self._raw_present_int
                elif present_label_counts[label_int] == absent_label_counts[label_int]:
                    if random.choice([0, 1]) == 1:
                        label[str(label_int)] = self._raw_present_int

            if label:
                new_annotations.append(
                    {
                        "x_uid": annotations[0].x_uid,
                        "label": label,
                        "source_uid": source_uid,
                    }
                )
            else:
                unknown_count += 1

        logger.info(f"Aggregating labels: number of unknown labels: {unknown_count}")
        return new_annotations

    def _aggregate_annotations(
        self,
        annotations_array: List[List[Any]],
        source_uid: int,
        strategy: str,
        params: Dict[str, Any],
    ) -> List[Dict]:
        random_seed = params["random_seed"]

        if strategy == SIMPLE_UNION:
            return self._simple_union(annotations_array, source_uid, random_seed)

        return []

    def get_partial_automl_params(self) -> PartialAutoMLParams:
        return PartialAutoMLParams(
            sampler_config=None,
            use_lf_labels=False,
            discretize_labels=True,
            tune_threshold_on_valid=True,
        )

    def remap_labels_and_get_new_label_map(
        self, user_raw_labels_map: Dict[str, RawLabels], class_value: int
    ) -> Dict[str, Any]:
        per_class_user_raw_labels_map: Dict[str, RawLabels] = {}
        for username, raw_labels in user_raw_labels_map.items():
            slice_labels = {}
            for x_uid, label in raw_labels.labels.items():
                if len(label) > 0:
                    slice_labels[x_uid] = label.get(
                        str(class_value),
                        label.get(self._default_key, self._raw_unknown_int),
                    )
            per_class_user_raw_labels_map[username] = RawLabels(labels=slice_labels)
        return dict(
            label_map=MULTILABEL_INVERSE_PRESENCE_USER_LABEL_DICT,
            user_raw_labels_map=per_class_user_raw_labels_map,
        )

    def _compute_class_counts_helper(
        self, labels: Dict[str, Dict[str, int]]
    ) -> Dict[str, Dict[int, int]]:
        class_counts_dict = {
            str(k): {self._raw_absent_int: 0, self._raw_present_int: 0}
            for k in self.inv_label_map.keys()
        }

        for _, label in labels.items():
            for class_key, vote in label.items():
                # if class key is not default and it votes non-unknown
                if class_key != self._default_key and vote != self._raw_unknown_int:
                    class_counts_dict[class_key][vote] += 1
                # if class key is default and it votes non-unknown,
                # it needs to update all other labels' votes
                elif class_key == self._default_key and vote != self._raw_unknown_int:
                    for clz in self.inv_label_map.keys():
                        # if the label does not contain the key, increase its count
                        # because if the key is in the label, it might be different from the default vote value
                        if str(clz) not in label:
                            class_counts_dict[str(clz)][vote] += 1
        return class_counts_dict

    def compute_gt_label_distribution(
        self, gt_labels: LabelsType, user_formatted: bool = False
    ) -> Dict[Union[str, int], Dict[int, int]]:
        gt_label_dist = self._compute_class_counts_helper(gt_labels)
        if user_formatted:
            return {self.inv_label_map[int(k)]: v for k, v in gt_label_dist.items()}
        else:
            return {int(k): v for k, v in gt_label_dist.items()}

    def compute_training_set_statistics(
        self,
        ts_labels: RawLabels,
        gt_labels: RawLabels,
        random_seed: int,
        sample_size: int,
    ) -> Optional[TrainingSetStats]:
        # Overloaded function which returns some statistics (including a small random sample) for a training set.

        # Remove UNKNOWN labels
        valid_ts_labels = {
            xuid: label
            for xuid, label in ts_labels.labels.items()
            if label != self.get_raw_unknown_label()
        }

        # there are couple of cases where accuracy_macro could be None
        # ex. no gt labels, gt labels and ts labels x_uids don't overlap
        est_labels_precision = (
            self._compute_metrics(
                gt_labels, ts_labels, metrics=["accuracy_macro"], custom_metric_funcs={}
            )["accuracy_macro"]
            or 0.0
        )

        # This ensures we get a consistent random sample if the seed is the same.
        random.seed(random_seed)
        random_sample = (
            random.sample(list(gt_labels.labels.items()), sample_size)
            if sample_size < len(gt_labels.labels)
            else gt_labels.labels
        )

        return TrainingSetStats(
            num_data_points=len(ts_labels.labels),
            num_est_labels=len(valid_ts_labels),
            num_gt_labels=len(gt_labels.labels),
            est_labels_precision=est_labels_precision,
            gt_label_dist=self.compute_gt_label_distribution(gt_labels.labels),
            est_label_dist=self._compute_class_counts_helper(valid_ts_labels),
            random_sample=random_sample,
        )

    def compute_class_counts(
        self, df: pd.DataFrame, col: str, class_int: Optional[int]
    ) -> Dict[str, int]:
        if class_int is None:
            raise ValueError(
                "class_int must be provided for compute_class_counts in MultiLabelSpace."
            )
        initial_class_counts = {self._raw_absent_int: 0, self._raw_present_int: 0}
        int_vote_counts = {
            **initial_class_counts,
            **df[df[col] != self._raw_unknown_int][col].value_counts().to_dict(),
        }
        return {
            MULTILABEL_PRESENCE_USER_LABEL_DICT[vote_int]: count
            for vote_int, count in int_vote_counts.items()
        }

    def is_lf_coverage_valid(self, lf_dicts: List[Dict]) -> bool:
        # We can always train a multi-label model, even if there are no labels
        # (model will predict 0 for all classes in that case).
        return True

    def replace_lf_votes(self, lf_votes: pd.DataFrame, new_label: Any) -> pd.DataFrame:
        return lf_votes.apply(
            lambda vote: new_label
            if vote != self.get_raw_unknown_label()
            else self.get_raw_unknown_label()
        )

    def update_probs_with_ground_truth_probs(
        self, probs: Dict[str, Any], gt_probs: Dict[str, Any]
    ) -> Dict[str, Any]:
        for x_uid, gt_prob in gt_probs.items():
            if x_uid not in probs:
                probs[x_uid] = gt_prob
            else:
                if len(gt_prob) != len(probs[x_uid]):
                    err_msg = "GT probs and probs should have the same length"
                    raise UserInputError(detail=err_msg, user_friendly_message=err_msg)
                for idx in range(len(gt_prob)):
                    probs[x_uid][idx] = (
                        gt_prob[idx]
                        if gt_prob[idx] != ABSTAIN_PROB
                        else probs[x_uid][idx]
                    )
        return probs

    def get_decision_tree_candidate_labels(
        self, raw_label: Optional[Any] = None
    ) -> List[Tuple[str, str]]:
        if raw_label is not None:
            user_label = self.raw_label_to_user_label(raw_label)
            return [
                (k, v)
                for k, v in user_label.items()
                if str(self.label_map[k]) in raw_label
            ]
        else:
            return [(label_str, "PRESENT") for label_str in self.label_map.keys()] + [
                (label_str, "ABSENT") for label_str in self.label_map.keys()
            ]

    def get_decision_tree_label(
        self, decision_tree_label: Any, provided_label: Tuple[str, str]
    ) -> Optional[str]:
        label_key, presence = provided_label
        return (
            label_key
            if label_key in decision_tree_label
            and decision_tree_label[label_key] == presence
            else None
        )

    def support_custom_metrics(self) -> bool:
        return False
