import sys
from abc import ABC, abstractmethod
from collections import OrderedDict, defaultdict, namedtuple
from enum import Enum, auto
from itertools import zip_longest
from typing import (
    Any,
    Callable,
    DefaultDict,
    Dict,
    Generator,
    Iterable,
    List,
    Optional,
    Set,
    Tuple,
    Type,
    Union,
)

import numpy as np
import pandas as pd
import sparse
from pydantic import BaseModel

import label_spaces.common.constants as constants
from api_utils.exceptions import NotSupportedException
from label_spaces.common import metrics_utils
from snorkelflow.data.core import deserialize_dataframe_series
from snorkelflow.types.splits import Splits
from snorkelflow.utils.logging import get_logger
from snorkelflow.utils.performance_profiling import PerfTimeLog

logger = get_logger("Label Space")

label_spaces_dict: Dict[str, Type["LabelSpace"]] = {}

# The general types below are for use with internal backend application logic and
# label space functions. The use of Any type avoids complex typing issues
# that may arise when using the specific types OpenAPI types. Use the specific OpenAPI
# for typing endpoints to catch backend and frontend incompatibilities.
LabelsType = Dict[str, Any]
ProbsType = Optional[Dict[str, Any]]

GT_LABELS_COL = "gt_labels"
MODEL_PREDS_COL = "model_preds"
MODEL_PROBS_COL = "model_probs"
LM_PREDS_COL = "lm_preds"
UNKNOWN = "UNKNOWN"

DEFAULT_LABEL_MODELS: List[Any] = ["BeamingLabelModel", "MajorityVoteLabelModel"]


class AggregateScoreStrategy(Enum):
    none = auto()
    average = auto()
    sum = auto()
    max = auto()


class PartialAutoMLParams(BaseModel):
    sampler_config: Optional[Dict[str, str]]
    use_lf_labels: Any
    discretize_labels: Any
    tune_threshold_on_valid: Any


class TrainingSetStats(BaseModel):
    # Total data points
    num_data_points: int
    # Note: This is the number of gt labels in the requested split
    num_gt_labels: int
    # Total predictions
    num_est_labels: int
    est_labels_precision: float
    # Ground truth label distribution
    # for multi label, the distribution value is a dict from vote int to the count
    gt_label_dist: Dict[str, Union[int, Dict[int, int]]]
    # Estimated label distribution
    est_label_dist: Dict[str, Union[int, Dict[int, int]]]
    # Returns a small sample of (default 20) data points.
    random_sample: LabelsType


class LabelSpaceConfig(BaseModel):
    cls_name: str
    kwargs: Dict[str, Any]


class RawLabels:
    """Internal label representation for metrics computation and DB storage"""

    labels: LabelsType

    def __init__(self, labels: LabelsType, probs: ProbsType = None) -> None:
        self.labels = labels
        self.probs = probs


class UserLabels:
    """User-facing label representation"""

    labels: LabelsType

    def __init__(self, labels: LabelsType) -> None:
        self.labels = labels


class ThresholdHolder:
    # A copy of this class is located in snorkelflow.models.sklearn.py
    # due to backwards compatibility issues for existing deployments, we can't import this class
    # make sure to update both places if you make changes
    def __init__(self, data: Union[float, Dict[str, float]]) -> None:
        self._data = data

    def get_threshold(self, class_name: Optional[str] = None) -> float:
        if isinstance(self._data, float):
            return self._data
        else:
            assert class_name is not None  # mypy
            return self._data[class_name]

    def round(self, ndigits: int) -> Union[float, Dict[str, float]]:
        if isinstance(self._data, float):
            return round(self._data, ndigits)
        else:
            return {k: round(v, ndigits) for k, v in self._data.items()}


class LabelValidationError(Exception):
    pass


class InvalidModelOutputError(Exception):
    pass


class LabelSpace(ABC):
    _raw_unknown_int = -1
    _filter_correctness_options_no_unk = [constants.CORRECT, constants.INCORRECT]
    _filter_correctness_options_with_unk = [
        constants.CORRECT,
        constants.INCORRECT,
        constants.INCORRECT_OR_UNKNOWN,
        constants.CORRECT_OR_UNKNOWN,
    ]
    default_aggregation_strategy: str = "not-implemented"
    supported_aggregation_strategies: List = []
    annotation_metric: str = "accuracy"
    # used to disable particular filters for the label space
    studio_disabled_filters: Set[str] = set()
    # used to disable aggregate filter options for label_spaces where they are not implemented
    lf_filter_aggregate_options = constants.LF_GENERAL_OPTIONS
    disable_multiple_model_ts_lf_filters: bool = False
    label_model_list = DEFAULT_LABEL_MODELS

    def __init__(
        self,
        label_map: Dict[str, int],
        label_descriptions: Optional[Dict[str, str]] = None,
        *args: List,
        **kwargs: Dict,
    ) -> None:
        self._label_map = label_map
        self._label_descriptions = label_descriptions or {}
        self._inverse_label_map = {v: k for k, v in self.label_map.items()}
        min_class_int = self.raw_unknown_int if self._is_unknown_in_label_map else 0
        if set(self.label_map.values()) != set(
            range(min_class_int, len(label_map) + min_class_int)
        ):
            raise LabelValidationError(
                f"Label map must contain consecutive label ints starting at {min_class_int}."
            )

    @property
    @abstractmethod
    def _is_unknown_in_label_map(self) -> bool:
        """Indicate whether UNKNOWN is expected in the label_map."""

    @property
    def label_map(self) -> Dict[str, int]:
        return self._label_map

    @property
    def raw_unknown_int(self) -> int:
        return self._raw_unknown_int

    @property
    def cardinality(self) -> int:
        return len(self.label_map) - int(self._is_unknown_in_label_map)

    @property
    def inv_label_map(self) -> Dict:
        return {v: k for k, v in self.label_map.items()}

    @property
    def label_descriptions(self) -> Dict[str, str]:
        return self._label_descriptions

    @property
    def max_studio_dataset_size(self) -> int:
        return -1

    @property
    def max_label_class_count(self) -> int:
        return -1

    @property
    def max_total_dataset_size(self) -> int:
        return -1

    @property
    def max_LF_count_override(self) -> int:
        # 0 indicates no override
        return 0

    @property
    @abstractmethod
    def is_multi_label(self) -> bool:
        """Indicates whether the label space is multi-label."""

    def _raise_error_incorrect_label_format(
        self,
        x_uid: str,
        label: Any,
        # user_format can be used to provide more detailed user-facing error message
        # unused in base class
        user_format: bool = False,
        detailed_error: Optional[str] = None,
    ) -> None:
        raise LabelValidationError(
            f"Label {label} for x_uid {x_uid} is incorrectly formatted{': '+detailed_error if detailed_error else ''}"
        )

    def _raise_error_incorrect_probs_format(self, x_uid: str, probs: Any) -> None:
        raise LabelValidationError(
            f"Probs {probs} for x_uid {x_uid} is incorrectly formatted"
        )

    @abstractmethod
    def config(self) -> LabelSpaceConfig:
        """Return class name and kwargs to instantiate this label space."""
        pass

    @classmethod
    @abstractmethod
    def raw_label_type(cls) -> type:
        """Type of non-abstain raw labels."""
        pass

    @classmethod
    @abstractmethod
    def user_label_type(cls) -> type:
        """Type of non-abstain user labels."""
        pass

    @abstractmethod
    def validate_raw_labels(self, raw_labels: RawLabels) -> None:
        """Validate format of RawLabels.

        NOTE: Unknown labels are not valid, since they cannot be stored in the database.
        In the future, we can add an option to allow unknown raw labels if we use validation
        elsewhere in the codebase.
        """

    @staticmethod
    @abstractmethod
    def extract_values_from_input_label(label: Any) -> List[str]:
        """Extract values from input label.

        This is used to extract values from the input label to be used in the label space.
        """
        pass

    @staticmethod
    @abstractmethod
    def example_user_input_label() -> Any:
        """Return an example user input label."""
        pass

    @staticmethod
    @abstractmethod
    def get_raw_unknown_label() -> Any:
        pass

    @staticmethod
    @abstractmethod
    def get_raw_dummy_label() -> Any:
        """Returns a valid dummy label to let us calculate metrics for an LF even if the user has not yet chosen what label(s) the LF should vote for."""
        pass

    @abstractmethod
    def get_user_unknown_pred_conf(self) -> Tuple[Any, Any]:
        """Returns the unknown prediction and confidence to return to front-end."""
        pass

    def __init_subclass__(cls, **kwargs: Any) -> None:
        """Define init subclass to register all subclasses in label_spaces_dict."""
        super(cls).__init_subclass__(**kwargs)  # type: ignore
        label_spaces_dict[cls.__name__] = cls

    @abstractmethod
    def copy_with_label_map(self, label_map: Dict[str, int]) -> "LabelSpace":
        """Return an instance of the same class with a new label map."""
        pass

    def get_compute_lf_metrics_required_columns(self) -> List[str]:
        """Returns the list of data frame columns required to compute the given metrics"""
        return []

    def get_compute_lm_required_columns(self) -> List[str]:
        """Returns the list of data frame columns required to compute the label model"""
        return self.get_compute_lf_metrics_required_columns()

    def get_data_size_to_safeguard(self, df: pd.DataFrame) -> int:
        """Returns the size of the data from dataframe that needs to be safeguarded"""
        return -1  # -1 means nothing to be safeguarded

    def _check_and_filter_df(
        self, df: Optional[pd.DataFrame], required_columns: List[str], target_name: str
    ) -> Optional[pd.DataFrame]:
        if required_columns:
            if df is None:
                raise ValueError(f"Cannot compute {target_name} without dataframe")
            missing_columns = set(required_columns) - set(df.columns)
            if missing_columns:
                raise ValueError(
                    f"Cannot compute {target_name}. DataFrame {df} missing columns {missing_columns}"
                )
            return df[required_columns]
        return pd.DataFrame()

    @abstractmethod
    def find_missing_predicted_classes(self, Y: np.ndarray) -> None:
        pass

    def subsample_uids(
        self,
        x_uids: List[Any],
        max_num_examples: int,
        random_seed: int,
        x_uids_gt: Optional[Set] = None,
    ) -> Set[int]:
        rng = np.random.default_rng(seed=random_seed)

        if x_uids_gt is not None:
            gt_inds = [i for i, x_uid in enumerate(x_uids) if x_uid in x_uids_gt]
            if len(x_uids_gt) < max_num_examples:
                non_gt_inds = [
                    i for i, x_uid in enumerate(x_uids) if x_uid not in x_uids_gt
                ]
                samples_to_keep = set(
                    rng.choice(
                        non_gt_inds, max_num_examples - len(gt_inds), False
                    ).tolist()
                ).union(set(gt_inds))
            else:
                samples_to_keep = set(
                    rng.choice(gt_inds, max_num_examples, False).tolist()
                )
        else:
            samples_to_keep = set(
                rng.choice(len(x_uids), max_num_examples, False).tolist()
            )

        return samples_to_keep

    @abstractmethod
    def _compute_L(
        self,
        label_matrix: Any,  # To avoid importing LabelMatrix
        df: Optional[pd.DataFrame] = None,
        batch_size: int = sys.maxsize,
        random_seed: int = 123,
        max_num_examples: Optional[int] = None,
        x_uids_gt: Optional[Set] = None,
        compute_num_datapoints: bool = False,
    ) -> Tuple[List[str], Generator, int]:
        pass

    def compute_L(
        self,
        label_matrix: Any,  # To avoid importing LabelMatrix
        df: Optional[pd.DataFrame] = None,
        batch_size: int = sys.maxsize,
        random_seed: int = 123,
        max_num_examples: Optional[int] = None,
        x_uids_gt: Optional[Set] = None,
        compute_num_datapoints: bool = False,
    ) -> Tuple[List[str], Generator, int]:
        """Compute uids and L matrix for Label Model training and inference.

        If max_rows > 0, subsample down to at most that many rows.
        """
        from data_models.label import LabelMatrix

        assert isinstance(label_matrix, LabelMatrix)
        required_columns = self.get_compute_lm_required_columns()
        df = self._check_and_filter_df(df, required_columns, "L matrix")
        return self._compute_L(
            label_matrix,
            df,
            batch_size,
            max_num_examples=max_num_examples,
            x_uids_gt=x_uids_gt,
            random_seed=random_seed,
            compute_num_datapoints=compute_num_datapoints,
        )

    @abstractmethod
    def compute_L_for_analysis(
        self,
        x_uids: List[str],
        lf_uids: List[int],
        lf_labels: Dict[int, LabelsType],
        do_filter: bool = True,
        **kwargs: Any,
    ) -> sparse._coo.core.COO:
        """Compute L matrix for lf analysis module

        do_filter governs whether to filter lf_labels for abstains. Should be false if it's already happened upstream
        (eg in compute_lf_metrics for base lf_analysis class)
        """
        pass

    @abstractmethod
    def _compute_label_model_tuning_ground_truth(
        self,
        ground_truth: Dict[str, Any],
        lm_uids: List[Any],
        df: Optional[pd.DataFrame] = None,
    ) -> Dict[str, Any]:
        pass

    def compute_label_model_tuning_ground_truth(
        self, ground_truth: Any, lm_uids: List[Any], df: Optional[pd.DataFrame] = None
    ) -> Union[np.ndarray, sparse._coo.COO]:
        """Compute tuning ground truth for the label model."""
        required_columns = self.get_compute_lm_required_columns()
        df = self._check_and_filter_df(
            df, required_columns, "label model tuning ground truth"
        )
        return self._compute_label_model_tuning_ground_truth(ground_truth, lm_uids, df)

    @abstractmethod
    def _compute_probs_and_abstains_from_lm(
        self,
        lm_x_uids: List[str],
        lm_probs: np.ndarray,
        lm_abstains: np.ndarray,
        df: Optional[pd.DataFrame] = None,
    ) -> Tuple[List[str], List[Any], List[bool], Optional[List[Any]]]:
        pass

    def compute_probs_and_abstains_from_lm(
        self,
        lm_x_uids: List[str],
        lm_probs: List[Any],
        lm_abstains: List[Any],
        df: Optional[pd.DataFrame] = None,
    ) -> Tuple[List[str], List[Any], List[bool], Optional[List[Any]]]:
        """Compute uids and L matrix for Label Model training and inference."""
        required_columns = self.get_compute_lm_required_columns()
        df = self._check_and_filter_df(
            df, required_columns, "datapoint probs from LabelModel probs"
        )
        return self._compute_probs_and_abstains_from_lm(
            lm_x_uids, lm_probs, lm_abstains, df
        )

    def update_subdatapoint_lf_abstains_with_ground_truth(
        self,
        subdatapoint_lf_abstains: Optional[List[Any]],
        x_uids: List[str],
        ground_truth: LabelsType,
    ) -> Optional[List[Any]]:
        return subdatapoint_lf_abstains

    @abstractmethod
    def get_compute_metrics_required_columns(self, metrics: List[str]) -> List[str]:
        """Returns the list of data frame columns required to compute the given metrics"""
        pass

    @abstractmethod
    def _compute_metrics(
        self,
        ground_truth: RawLabels,
        prediction: RawLabels,
        metrics: List[str],
        custom_metric_funcs: Dict[str, Callable],
        df: Optional[pd.DataFrame] = None,
        df_uid_col: Optional[str] = None,
        extra_params: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        pass

    def compute_metrics(
        self,
        ground_truth: RawLabels,
        prediction: RawLabels,
        metrics: List[str],
        custom_metric_funcs: Dict[str, Callable],
        df: Optional[pd.DataFrame] = None,
        df_uid_col: Optional[str] = None,
        extra_params: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Compute metrics for this LabelSpace"""
        if extra_params is None:
            extra_params = {}
        required_metrics_columns = self.get_compute_metrics_required_columns(metrics)
        if required_metrics_columns:
            if df is None or df_uid_col is None:
                raise ValueError("Dataframe required to compute requested metrics")
            for col in required_metrics_columns:
                if col not in df.columns:
                    raise ValueError(
                        f"Missing column {col} in dataframe required to compute requested metrics"
                    )

            all_required_columns = required_metrics_columns + [df_uid_col]
            df = df[all_required_columns]
        return self._compute_metrics(
            ground_truth=ground_truth,
            prediction=prediction,
            metrics=metrics,
            custom_metric_funcs=custom_metric_funcs,
            df=df,
            df_uid_col=df_uid_col,
            extra_params=extra_params,
        )

    @abstractmethod
    def parse_postprocessed_spans(
        self, postprocessed_spans: List[metrics_utils.PostprocessedSpan]
    ) -> RawLabels:
        """Converts postprocessed spans into RawLabels for doc metrics"""
        pass

    @abstractmethod
    def array_probs_to_raw_probs(self, array_probs: List[Any]) -> List[Dict]:
        pass

    @abstractmethod
    def raw_probs_to_array_probs(self, raw_probs: List[Any]) -> List[Any]:
        pass

    @abstractmethod
    def raw_probs_to_enumerate_array_probs(
        self, raw_probs: List[Any], **kwargs: Dict[str, Any]
    ) -> List[List[float]]:
        pass

    @abstractmethod
    def aggregate_prediction_scores(
        self, scores: List[Any], aggregation: AggregateScoreStrategy
    ) -> List[Any]:
        pass

    def to_aggregate(
        self, scores: Dict[str, Any], aggregation: AggregateScoreStrategy
    ) -> Dict[str, Any]:
        agg_scores = {
            x_uid: self.aggregate_prediction_scores(
                [score_data], aggregation=aggregation
            )
            for x_uid, score_data in scores.items()
        }
        return agg_scores

    @abstractmethod
    def raw_probs_to_confidences(self, raw_probs: List[Any]) -> List[Any]:
        pass

    @abstractmethod
    def raw_probs_to_entropies(self, raw_probs: List[Any]) -> List[Any]:
        pass

    @abstractmethod
    def raw_labels_from_raw_probs(self, raw_probs: List[Any]) -> List[Any]:
        pass

    @abstractmethod
    def raw_probs_from_raw_labels(self, raw_labels: List[Any]) -> List[Any]:
        pass

    @staticmethod
    def _get_default_predicted_probs(label: int) -> Dict:
        return {str(label): 1.0}

    @staticmethod
    def _validate_probs(arrays: List[Any]) -> None:
        probs = np.array(list(zip_longest(*arrays, fillvalue=0)))
        if not np.all(np.isclose(np.sum(probs, axis=0), 1.0, 1e-3)) or np.any(
            probs < 0
        ):
            raise LabelValidationError(f"Invalid probability distribution")

    @staticmethod
    def _prob_arrays_to_prob_dicts(
        arrays: List[Any], n_classes: int, validate_distribution: Optional[bool] = True
    ) -> Dict[str, float]:
        """Convert probabilities (dense list) to sparse dict."""
        EPS = 1e-5
        # Check valid size
        if not isinstance(arrays, list):
            raise LabelValidationError(
                f"All predicted_probs should be lists, found {type(arrays)}"
            )
        if len(arrays) != n_classes:
            raise LabelValidationError(
                f"Expected all predicted_probs to have {n_classes} classes "
                f"but found {len(arrays)}"
            )
        # Check valid distribution
        if validate_distribution and (
            not np.isclose(sum(arrays), 1.0, 1e-3) or any(p_i < 0 for p_i in arrays)
        ):
            raise LabelValidationError(f"Invalid probability distribution: {arrays}")
        # Keys are strings to match the result of the DB query from Prediction class
        return {str(i): v for i, v in enumerate(arrays) if v > EPS}

    @staticmethod
    def _probs_dict_to_predicted_label(p_dict: Dict) -> int:
        return int(max(p_dict, key=p_dict.get))  # type: ignore

    def prob_dict_to_prob_array(
        self, prob_dict: Union[List[float], Dict[str, Any]]
    ) -> List[float]:
        """Convert probabilities (dense list or sparse dict) to dense array."""
        if isinstance(prob_dict, list):
            return prob_dict
        return [prob_dict.get(str(i), 0.0) for i in range(self.cardinality)]

    @staticmethod
    def probs_dict_to_confidence(probs_dict: Dict[str, float]) -> List[float]:
        """Get confidence of highest probability prediction."""
        probs: Iterable = probs_dict.values()
        return max(list(probs))

    def probs_dict_to_entropy(self, probs_dict: Dict[str, float]) -> float:
        arr = np.array(self.prob_dict_to_prob_array(probs_dict)).reshape(1, -1)
        return metrics_utils.compute_normalized_entropy_score(arr)

    def to_array_probs(self, probs: ProbsType) -> Dict[str, Any]:
        x_uids: List[str] = []
        dict_probs: List[Dict] = []
        for x_uid, dict_prob in probs.items():  # type: ignore
            x_uids.append(x_uid)
            dict_probs.append(dict_prob)
        array_probs = self.raw_probs_to_array_probs(dict_probs)
        return dict(zip(x_uids, array_probs))

    def to_confidences(self, probs: ProbsType) -> Dict[str, Any]:
        if not probs:
            return {}
        return dict(
            zip(list(probs.keys()), self.raw_probs_to_confidences(list(probs.values())))
        )

    def to_entropies(self, probs: ProbsType) -> Dict[str, Any]:
        x_uids: List[str] = []
        dict_probs: List[Dict] = []
        for x_uid, dict_prob in probs.items():  # type: ignore
            x_uids.append(x_uid)
            dict_probs.append(dict_prob)
        entropies = self.raw_probs_to_entropies(dict_probs)
        return dict(zip(x_uids, entropies))

    @abstractmethod
    def raw_label_to_user_label(self, raw_label: Any) -> Any:
        pass

    def raw_labels_to_user_labels(self, raw_labels: RawLabels) -> UserLabels:
        user_labels = {}
        for x_uid, raw_label in raw_labels.labels.items():
            user_labels[x_uid] = self.raw_label_to_user_label(raw_label)
        return UserLabels(user_labels)

    def raw_confidence_to_user_confidence(self, raw_confidence: Any) -> Any:
        return raw_confidence

    def raw_labels_to_SME_labels(self, raw: RawLabels) -> UserLabels:
        return self.raw_labels_to_user_labels(raw)

    @abstractmethod
    def user_label_to_raw_label(
        self, user_label: Any, x_uid: Optional[str] = None
    ) -> Any:
        pass

    def user_labels_to_raw_labels(
        self, user_labels: UserLabels, remove_invalid_x_uids: bool = False
    ) -> RawLabels:
        raw_labels = {}
        for x_uid, user_label in user_labels.labels.items():
            try:
                raw_labels[x_uid] = self.user_label_to_raw_label(user_label, x_uid)
            except Exception as e:
                if remove_invalid_x_uids:
                    continue
                else:
                    self._raise_error_incorrect_label_format(
                        x_uid, user_label, detailed_error=str(e), user_format=True
                    )
        return RawLabels(raw_labels)

    @abstractmethod
    def remap_labels(
        self,
        labels: Dict[str, Any],
        remap: Dict[Any, Any],
        filter_missing_keys: Optional[bool] = True,
    ) -> Dict[Any, Any]:
        pass

    def remap_lf_label(self, label: Any, remap: Dict) -> Optional[Any]:
        """
        Remap LF Label is used to remap LF labels when transferring assets across applications.
        Label in this function refers to LF label ('Dict' for MultiLabel & 'int' for other label spaces).
        Overridden in MultiLabelSpace.
        """
        return remap.get(label)

    def remap_raw_label(self, label: Any, remap: Dict) -> Optional[Any]:
        """
        Remap Raw Label is used to remap Raw labels (e.g. annotations) when transferring assets across applications.
        Label in this function refers to raw labels ('Dict' for MultiLabel, 'List' for SequenceLabel,
        & 'int' for other label spaces).
        We can reuse remap_lf_label for most label spaces because the raw & LF labels are similar types & logic.
        Except in SequenceLabelSpace: LF label: int, raw label: List
        Will be overridden in SequenceLabelSpace in a upcoming separate PR immediately after this PR is approved.
        """
        return self.remap_lf_label(label, remap)

    def get_label_remap_dict(
        self,
        old_label_space: "LabelSpace",
        updated_label_schema: Optional[Dict[str, Optional[str]]],
    ) -> Optional[Dict[str, Optional[str]]]:
        """Compute label mapping for transfer given user mapping"""
        if old_label_space.label_map == self.label_map and all(
            k == v for k, v in (updated_label_schema or {}).items()
        ):
            # Skip remapping as there is no change in label map and label schema
            return {k: k for k in self.label_map}
        err_msg = f"Transfer not supported for {type(self).__name__}"
        raise NotSupportedException(detail=err_msg, user_friendly_message=err_msg)

    @staticmethod
    @abstractmethod
    def check(
        x: pd.Series, op_name: str, fault_tolerant: bool = False, *conditions: Any
    ) -> Any:
        """Whether the composed LF conditions vote or abstains on a datapoint"""
        pass

    @staticmethod
    @abstractmethod
    def compose_lf(label: Any, condition: Any, fault_tolerant: bool) -> Callable:
        pass

    @abstractmethod
    def probs_to_preds_with_threshold(
        self,
        probs: np.ndarray,
        lf_abstains: Optional[np.ndarray] = None,
        tie_break_policy: str = "abstain",
        tol: float = 1e-5,
        filter_uncertain_labels_threshold: float = 0.0,
        postprocess_labels: bool = False,
    ) -> np.ndarray:
        """Converts model-produced probablities to point predictions.

        Args:
            probs (np.ndarray): Model-produced probablities, 1st dimension always rows.
            lf_abstains (np.ndarray): N x 1 boolean indicator of whether all LFs abstain on a given sample.
                (This will be None if abstains have already been filtered out prior to calling the method.)
            tie_break_policy (str, optional): method for dealing with ties in probabilities. Defaults to "abstain".
            tol (float, optional): tolerance for considering probalities ties. Defaults to 1e-5.
            filter_uncertain_labels_threshold (float, optional): Prob threshold for passing through a prediction. Defaults to 0.0.
            postprocess_labels (bool, optional): Whether to process negative labels. Defaults to False.

        Returns:
            N x 1 array of point predictions
        """
        pass

    def get_new_gt_mask(
        self,
        x_uids_and_labels_per_split: Dict[str, Dict[str, List[Any]]],
        metadata_df: pd.DataFrame,
        split: str,
    ) -> Tuple[np.ndarray, np.ndarray]:
        # Returns a new GT binary mask for specified x_uids along with indices to replace in existing mask
        return np.array([]), np.array([])

    def create_binary_mask(
        self, data_vector: pd.Series, class_ints: Optional[List[int]] = None
    ) -> np.ndarray:
        # Returns updated binary mask for the label_space based
        return np.array([])

    @abstractmethod
    def compute_lf_abstains(self, L: np.ndarray, probas: np.ndarray) -> np.ndarray:
        """Returns a mask for abstains. Depending on the label space, this should either be
        simply samples where no LFs vote, or in addition samples where no LFs vote for the
        predicted label.

        Args:
            L (np.ndarray): label matrix
            probas (np.ndarray): label probabilities
        Returns:
            mask
        """
        pass

    def postprocess_negative_raw_labels(self, prediction: RawLabels) -> RawLabels:
        # no-op for non-seq label space
        return prediction

    @abstractmethod
    def get_gt_comparison_mask(
        self, gt_vector: pd.Series, config: Dict[str, Any]
    ) -> pd.Series:
        """Returns a mask where GT is present, if the vote is incorrect/correct (comparing to GT),
        otherwise returning a mask of all Trues"""
        pass

    @abstractmethod
    def filter_label_vector(
        self,
        data_vector: pd.Series,
        gt_vector: pd.Series,
        config: Dict[str, Any],
        x_uids: Optional[List[str]] = None,
        split: str = "dev",
    ) -> pd.DataFrame:
        """Voted will either be a str representation of a class, or some special value
        to indicate a derived calculation (i.e. 'correct' -> data is same as gt. Each label
        space may take different special values."""
        pass

    def filter_label_vector_by_label(
        self, label_vector: pd.Series, label: Any
    ) -> pd.Series:
        """Filter labels of any type (e.g., GT, prediction, LF vote) that are relevant to the provided label."""
        self.validate_lf_label(label)
        return label_vector == label

    @abstractmethod
    def filter_lf_conflict(self, data_row: pd.Series, config: Dict[str, Any]) -> bool:
        """Returns a True or False value depending on whether the LFs for this data point conflict."""
        pass

    @abstractmethod
    def get_text_to_code_base_prompt(self, df: pd.DataFrame) -> str:
        pass

    def filter_abstains_from_label(self, raw_label: LabelsType) -> LabelsType:
        return {
            x_uid: label
            for x_uid, label in raw_label.items()
            if label != self.get_raw_unknown_label()
        }

    def sort_label(self, raw_label: LabelsType) -> LabelsType:
        return dict(sorted(raw_label.items()))

    def filter_abstains_from_label_dict(
        self, label_dict: Dict[int, LabelsType]
    ) -> Dict[int, LabelsType]:
        return {
            uid: self.filter_abstains_from_label(raw_label)
            for uid, raw_label in label_dict.items()
        }

    def sort_label_dict(
        self, label_dict: Dict[int, LabelsType]
    ) -> Dict[int, LabelsType]:
        label_dict = {k: self.sort_label(v) for k, v in label_dict.items()}
        return dict(sorted(label_dict.items()))

    def _get_label_choices(self, choices: List[str]) -> List[Any]:
        if UNKNOWN in choices:
            # Move "UNKNOWN" to the top of the class list
            choices.insert(0, choices.pop(choices.index(UNKNOWN)))
        return [{"title": class_name, "value": class_name} for class_name in choices]

    def get_gt_filter_structure(self) -> List[Dict[str, Any]]:
        return [
            dict(
                input_name="gt",
                component="Render",
                default="Ground truth",
                options=None,
                size=3,
            ),
            dict(
                input_name="is", component="Render", default="is", options=None, size=2
            ),
            dict(
                input_name="voted",
                display_name="Labeled",
                component="CustomChoices",
                default=None,
                options=self._get_label_choices(list(self.label_map.keys())),
                size=3,
            ),
        ]

    def get_model_filter_structure(
        self, models: List[str], model_uids: List[int]
    ) -> List[Dict[str, Any]]:
        return [
            dict(
                input_name="model_uid",
                component="CustomChoices",
                default=None,
                options=[
                    {"title": name, "value": model_uid}
                    for name, model_uid in zip(models, model_uids)
                ],
                size=3,
            ),
            dict(
                input_name="predicted",
                component="Render",
                default="predicted",
                options=None,
                size=2,
            ),
            dict(
                input_name="voted",
                display_name="Label",
                component="CustomChoices",
                default=None,
                options=self._get_label_choices(
                    self._filter_correctness_options_no_unk
                    + list(self.label_map.keys())
                ),
                size=3,
            ),
        ]

    def get_ts_filter_structure(
        self, training_set_names: List[str], training_set_uids: List[int]
    ) -> List[Dict[str, Any]]:
        return [
            dict(
                input_name="ts_uid",
                component="CustomChoices",
                default=None,
                options=[
                    {"title": name, "value": training_set_uid}
                    for name, training_set_uid in zip(
                        training_set_names, training_set_uids
                    )
                ],
                size=3,
            ),
            dict(
                input_name="labels",
                component="Render",
                default="labels",
                options=None,
                size=2,
            ),
            dict(
                input_name="voted",
                component="CustomChoices",
                display_name="Label",
                default=None,
                options=self._get_label_choices(
                    self._filter_correctness_options_with_unk
                    + list(self.label_map.keys())
                ),
                size=3,
            ),
        ]

    def get_lf_filter_structure(
        self, lf_names: List[str], lf_uids: List[int]
    ) -> List[Dict[str, Any]]:
        return [
            dict(
                input_name="lf",
                component="CustomChoices",
                default=None,
                options=self.lf_filter_aggregate_options
                + [
                    {"title": name, "value": lf_uid}
                    for name, lf_uid in zip(lf_names, lf_uids)
                ],
                size=3,
            ),
            dict(
                input_name="voted_str",
                component="Render",
                default="voted",
                options=None,
                size=2,
            ),
            dict(
                input_name="voted",
                component="CustomChoices",
                display_name="Label",
                default=None,
                options=self._get_label_choices(
                    self._filter_correctness_options_with_unk
                    + list(self.label_map.keys())
                ),
                size=3,
            ),
        ]

    def get_annotation_agreement_filter_structure(
        self,
        annotator_names: List[str],
        annotator_uids: List[int],
        in_annotation_mode: Optional[bool],
    ) -> List[Dict[str, Any]]:
        return [
            dict(
                input_name="annotator_uid_one",
                display_name="Annotator one",
                component="CustomChoices",
                default=None,
                options=[
                    {"title": annotator, "value": user_uid}
                    for annotator, user_uid in zip(annotator_names, annotator_uids)
                ],
                size=6,
            ),
            dict(
                input_name="and",
                component="Render",
                default="and",
                options=None,
                size=2,
            ),
            dict(
                input_name="annotator_uid_two",
                display_name="Annotator two",
                component="CustomChoices",
                default=None,
                options=[
                    {"title": annotator, "value": user_uid}
                    for annotator, user_uid in zip(annotator_names, annotator_uids)
                ],
                size=6,
            ),
            dict(
                input_name="voted",
                component="CustomChoices",
                display_name="Disagree",
                default=None,
                options=[
                    {"title": "Agree", "value": constants.CORRECT},
                    {"title": "Disagree", "value": constants.INCORRECT},
                ],
                size=4,
            ),
        ]

    def get_annotation_filter_structure(
        self,
        annotator_names: List[str],
        annotator_uids: List[int],
        in_annotation_mode: Optional[bool],
    ) -> List[Dict[str, Any]]:
        aggregate_options = (
            constants.BATCH_AWARE_ANNOTATION_AGGREGATE_OPTIONS
            if in_annotation_mode
            else constants.ANNOTATION_AGGREGATE_OPTIONS
        )
        return [
            dict(
                input_name="annotator",
                component="CustomChoices",
                default=None,
                options=aggregate_options
                + [
                    {"title": annotator, "value": user_uid}
                    for annotator, user_uid in zip(annotator_names, annotator_uids)
                ],
                size=3,
            ),
            dict(
                input_name="labeled",
                component="Render",
                default="labeled",
                options=None,
                size=2,
            ),
            dict(
                input_name="voted",
                component="CustomChoices",
                display_name="Label",
                default=None,
                options=self._get_label_choices(
                    self._filter_correctness_options_no_unk
                    + list(self.label_map.keys())
                ),
                size=3,
            ),
        ]

    def remap_labels_and_get_new_label_map(
        self, user_raw_labels_dict: Dict[str, RawLabels], class_value: int
    ) -> Dict[str, Any]:
        """Modify a dictionary of RawLabels and create a new label map
        according to a supplied class_value.

        Args:
            raw_labels_dict (Dict[str, RawLabels]): Dict of format {username: RawLabels}
            class_value (int): Integer representing a class

        Raises:
            NotSupportedException: If the current label space does not support per-class calculations

        Returns:
            Dict[str, Any]: Remapped {user: RawLabels} dictionary and per-class label space
        """
        err_msg = f"Label remapping is not supported in {type(self)}."
        raise NotSupportedException(err_msg)

    @abstractmethod
    def compute_interannotator_aggregate_metric(
        self,
        user_raw_labels_map: Dict[str, RawLabels],
        metric: str = "krippendorff-alpha",
    ) -> Optional[float]:
        pass

    def get_label_model_list(
        self,
        label_model_list: List[Any],
        sample_df: pd.DataFrame,
        num_train_rows: int,
        num_lfs: int,
    ) -> List[Dict[str, Any]]:
        """
        Provides a chance for label spaces to change the possible label models to be used.
        """
        return label_model_list

    @abstractmethod
    def min_samples_per_class(
        self, labeled_data: pd.DataFrame, gt_field: str, min_samples_per_class: int
    ) -> pd.DataFrame:
        """Return a subset of labeled_data where there are at least N samples per class,
        if available. If not, return all samples for that class."""
        pass

    def is_unknown_label(self, label: Optional[Any]) -> bool:
        return label == self.get_raw_unknown_label()

    @abstractmethod
    def validate_lf_label(self, lf_label: Any) -> bool:
        pass

    def compress_label(self, raw_label: Any) -> Any:
        return raw_label

    def compress_labels_for_model_training(self, raw_labels: List[Any]) -> Any:
        # compress labels for model training.
        # here we can use numpy array to compress labels
        return raw_labels

    def get_batch_size_for_loading_training_probs(self, num_x_uids: int) -> int:
        # to-do: figure out optimal batch size for other label space
        return num_x_uids

    def create_analysis_df(
        self,
        df: pd.DataFrame,
        gt_labels_col: str,
        model_probs_col: str,
        class_int: Optional[int] = None,
    ) -> pd.DataFrame:
        if class_int is not None:
            df = df[df[GT_LABELS_COL] == class_int]
        return df

    def get_analysis_df_required_col(
        self, token_level: bool = False
    ) -> List[Optional[str]]:
        return []

    def get_analysis_df(
        self,
        gt_labels: Dict[str, Any],
        model_preds: Dict[str, Any],
        model_probs: Optional[Dict[str, Any]],
        lm_preds: Dict[str, Any],
        doc_level: bool = False,
        fill_nan_with_negative: bool = True,
    ) -> pd.DataFrame:
        df = pd.DataFrame(index=gt_labels.keys())
        Column = namedtuple("Column", ["name", "map"])
        cols_to_add = [
            Column(name=GT_LABELS_COL, map=gt_labels),
            Column(name=MODEL_PREDS_COL, map=model_preds),
            Column(
                name=MODEL_PROBS_COL,
                map={
                    x_uid: self.prob_dict_to_prob_array(prob)
                    if prob != self.raw_unknown_int
                    else self.raw_unknown_int
                    for x_uid, prob in model_probs.items()
                }
                if model_probs
                else {},
            ),
            Column(name=LM_PREDS_COL, map=lm_preds),
        ]

        for col in cols_to_add:
            df = df.join(
                pd.DataFrame({col.name: list(col.map.values())}, index=col.map.keys())
            )
        df.loc[:, df.columns != MODEL_PROBS_COL] = df.loc[
            :, df.columns != MODEL_PROBS_COL
        ].fillna(self.raw_unknown_int)
        return df

    @abstractmethod
    def compute_label_counts(self, annotations: List[Any]) -> defaultdict:
        pass

    def compute_label_distribution(
        self, annotations: List[Any]
    ) -> List[Dict[str, Any]]:
        if len(annotations) == 0:
            return []

        label_count = self.compute_label_counts(annotations)
        label_distribution = [
            {
                "label": self.inv_label_map[label],
                "count": label_count[label],
                "distribution": float(label_count[label]) / sum(label_count.values()),
            }
            for label in label_count
        ]
        label_distribution.sort(key=lambda i: i["label"])
        return label_distribution

    @abstractmethod
    def _aggregate_annotations(
        self,
        annotations_array: List[List[Any]],
        source_uid: int,
        strategy: str,
        params: Dict[str, Any],
    ) -> List[Dict]:
        pass

    def validate_aggregation_strategy(self, strategy: str) -> None:
        if strategy not in self.supported_aggregation_strategies:
            raise Exception(f"Unsupported label resolution strategy {strategy}")

    def aggregate_annotations(
        self,
        annotations: List[Any],
        source_uid: int,
        strategy: str,
        random_seed: int = 123,
    ) -> List[Dict]:
        self.validate_aggregation_strategy(strategy)

        annotation_x_uid_map: defaultdict = defaultdict(list)
        for annotation in annotations:
            annotation_x_uid_map[annotation.x_uid].append(annotation)

        annotations_array = [
            annotation_x_uid_map[x_uid] for x_uid in annotation_x_uid_map
        ]

        params = {"random_seed": random_seed}

        return self._aggregate_annotations(
            annotations_array, source_uid, strategy, params
        )

    def tune_threshold_on_valid(
        self,
        predictions: Dict[str, Tuple[List[str], List[Any], List[Any]]],
        valid_gt_x_uids: List[str],
        valid_gt_labels: List[Any],
        primary_metric: str,
        custom_metric_funcs: Dict[str, Callable],
        df: Optional[pd.DataFrame] = None,
        df_uid_col: Optional[str] = None,
    ) -> Tuple[
        Dict[str, Tuple[List[str], List[Any], List[Any]]],
        Union[float, Dict[str, float]],
    ]:
        """
        `predictions` contain each split: "train", "valid", "test", and a tuple containing:
        0: x_uids, 1: labels, 2: probs.

        Modifies the labels on `predictions` to be set at the optimal threshold.
        Computes primary metric in increments of 0.05 to find the optimal threshold.
        """
        valid_raw_ground_truth = RawLabels(dict(zip(valid_gt_x_uids, valid_gt_labels)))
        valid_x_uids, _, valid_probs = predictions[Splits.valid]
        optimal_valid_threshold = self._compute_optimal_threshold(
            primary_metric,
            valid_x_uids,
            valid_probs,
            valid_raw_ground_truth,
            custom_metric_funcs,
            df,
            df_uid_col,
        )
        predictions = self._update_prediction_with_threshold(
            predictions, optimal_valid_threshold
        )
        return predictions, optimal_valid_threshold.round(2)

    def _compute_optimal_threshold(
        self,
        primary_metric: str,
        valid_x_uids: List,
        valid_probs: List,
        valid_ground_truth: RawLabels,
        custom_metric_funcs: Dict[str, Callable],
        df: Optional[pd.DataFrame] = None,
        df_uid_col: Optional[str] = None,
    ) -> ThresholdHolder:
        thresholds = np.arange(0, 1, 0.01)
        scores = []
        for threshold in thresholds:
            thresholded_preds = self._threshold_probs(
                valid_x_uids, valid_probs, ThresholdHolder(threshold)
            )
            thresholded_raw_preds = RawLabels(
                dict(zip(valid_x_uids, thresholded_preds))
            )
            score = self._compute_metrics(
                valid_ground_truth,
                thresholded_raw_preds,
                [primary_metric],
                custom_metric_funcs=custom_metric_funcs,
                df=df,
                df_uid_col=df_uid_col,
            )[primary_metric]
            scores.append((score if score else 0.0, threshold))
        return ThresholdHolder(max(scores)[1])

    def _update_prediction_with_threshold(
        self,
        predictions: Dict[str, Tuple[List[str], List[Any], List[Any]]],
        threshold: ThresholdHolder,
    ) -> Any:
        new_predictions = {}
        for split, pred_values in predictions.items():
            pred_x_uids, preds, pred_probs = pred_values
            if pred_probs is None:
                raise InvalidModelOutputError(
                    f"Model must output probabilities for {split} split for threshold tuning"
                )
            thresholded_preds = self._threshold_probs(
                pred_x_uids, pred_probs, threshold
            )
            new_predictions[split] = (pred_x_uids, thresholded_preds, pred_probs)
        return new_predictions  # type: ignore

    @abstractmethod
    def _threshold_probs(
        self, x_uids: List[Any], probs: List[Any], threshold: ThresholdHolder
    ) -> List[Any]:
        """Takes in a list of probs which are label space specific.
        Returns labels using the given threshold.
        """
        pass

    def get_max_df_batch_size(self, sample_df: pd.DataFrame, num_lf_uids: int) -> int:
        return 100_000

    def get_L_train_max_num_rows(self) -> int:
        return 100_000

    def get_L_tuning_max_num_rows(self) -> int:
        return self.get_L_train_max_num_rows()

    def get_default_lm_scoring_metric(self) -> str:
        return "log_likelihood"

    @abstractmethod
    def get_partial_automl_params(self) -> PartialAutoMLParams:
        pass

    def replace_abstain_with_negative(
        self, preds: np.ndarray, probs: np.ndarray
    ) -> Tuple[np.ndarray, np.ndarray]:
        """Overridden in SequenceLabelSpace."""
        err_msg = f"Fill abstain with negatives not supported for {type(self).__name__}"
        raise NotSupportedException(detail=err_msg, user_friendly_message=err_msg)

    def compute_class_counts(
        self, df: pd.DataFrame, col: str, class_int: Optional[int]
    ) -> Dict[str, int]:
        """Compute the histogram for each unique object in df[col], where
        df[col] is a column of labels or label votes.

        Args:
            df (pd.DataFrame): Dataframe, the result of `get_analysis_df`.
            col (str): Column name containing labels or label votes.
            class_int (Optional[int]): Optional int specifying a class, only required for MultiLabelSpace.

        Raises:
            ValueError: If `class_int` is given in the incorrect context.

        Returns:
            Dict[str, int]: Mapping of class names to the number of occurrences of that class.
        """
        if class_int is not None:
            raise ValueError(
                "class_int shouldn't be provided for compute_class_counts in non MultiLabelSpace."
            )
        initial_class_counts = {i: 0 for i in range(len(self.label_map) - 1)}
        int_class_counts = {
            **initial_class_counts,
            **df[df[col] != self.raw_unknown_int][col].value_counts().to_dict(),
        }
        return {
            self.inv_label_map[class_int]: count
            for class_int, count in int_class_counts.items()
        }

    @abstractmethod
    def is_lf_coverage_valid(self, lf_dicts: List[Dict]) -> bool:
        """Check whether there is enough LF coverage to unblock training a model for all classes.

        For example, for single-label classification, there should be at least two classes (without which
        a model isn't meaninful), and every class should have at least one LF that can vote for it.
        For multi-label classification, every class should have at least one LF that can vote positive,
        as well as at least one LF that can vote negative.
        """
        pass

    @abstractmethod
    def replace_lf_votes(self, lf_votes: pd.DataFrame, new_label: Any) -> pd.DataFrame:
        """This function updates the LF votes read from the cache with the given new label.

        When writing the LF apply results to the cache, we did not use the label in lf_config as a part of the cache key since
        recomputing LF apply is more costly than updating the LF votes after reading from cache. Therefore, if we were to perform
        LF apply again with a different label, the LF votes read from the cache will be incorrect. This function updates the stale
        LF votes read from cache with the correct label.
        """
        pass

    def compute_confusion_matrix(
        self,
        golds: np.ndarray,
        preds: np.ndarray,
        label_map: Dict[str, int],
        n_classes: int,
    ) -> Optional[Dict[str, Any]]:
        return metrics_utils.compute_confusion_matrix(
            golds, preds, label_map, n_classes
        )

    @abstractmethod
    def get_lf_uid_errors(
        self,
        label_matrix: Any,
        x_uid_to_ground_truth: pd.DataFrame,
        class_int: Optional[int] = None,
    ) -> DefaultDict:
        pass

    def compute_clarity_matrix(
        self,
        df: pd.DataFrame,
        gt_labels_col: str,
        lm_preds_col: str,
        model_preds_col: str,
        class_int: Optional[int] = None,
    ) -> pd.DataFrame:
        # Construct the clarity matrix.
        # 3 Rows represent (label model -> incorrect, correct, abstain)
        # 2 Cols represent (end model -> incorrect, correct)
        clarity_matrix = np.zeros((3, 2))
        incorrect_ix, correct_ix, abstain_ix = 0, 1, 2

        lm = df[lm_preds_col]
        gt = df[gt_labels_col]
        model = df[model_preds_col]

        lm_abstain_mask = lm == self.raw_unknown_int
        lm[~lm_abstain_mask] = (lm[~lm_abstain_mask] == gt[~lm_abstain_mask]).astype(
            int
        )
        lm[lm_abstain_mask] = 2

        model_correct_mask = model == gt

        def evaluate(pred: int) -> Tuple[np.ndarray, np.ndarray]:
            correct = np.logical_and(lm == pred, model_correct_mask).sum()
            incorrect = np.logical_and(lm == pred, ~model_correct_mask).sum()
            return correct, incorrect

        lm_correct_model_correct, lm_correct_model_incorrect = evaluate(1)
        clarity_matrix[correct_ix, correct_ix] = lm_correct_model_correct
        clarity_matrix[correct_ix, incorrect_ix] = lm_correct_model_incorrect

        lm_incorrect_model_correct, lm_incorrect_model_incorrect = evaluate(0)
        clarity_matrix[incorrect_ix, correct_ix] = lm_incorrect_model_correct
        clarity_matrix[incorrect_ix, incorrect_ix] = lm_incorrect_model_incorrect

        lm_abstain_model_correct, lm_abstain_model_incorrect = evaluate(2)
        clarity_matrix[abstain_ix, correct_ix] = lm_abstain_model_correct
        clarity_matrix[abstain_ix, incorrect_ix] = lm_abstain_model_incorrect

        return clarity_matrix

    def process_cluster_input_dataframe(
        self,
        df: pd.DataFrame,
        input_field: str,
        output_field: Optional[str] = None,
        candidate_field: Optional[str] = None,
        gt_field: Optional[str] = None,
        tsne_x_col: Optional[str] = None,
        tsne_y_col: Optional[str] = None,
        deserialize_columns: bool = False,
    ) -> pd.DataFrame:
        """This function processes input data frame to become compatible with Cluster View"""
        if (
            deserialize_columns
            and output_field is not None
            and output_field in df.attrs["serialized_col_types"]
        ):
            df = deserialize_dataframe_series(
                df, {output_field: df.attrs["serialized_col_types"][output_field]}
            )
        return df

    def aggregate_tsne_embeddings(
        self,
        df: pd.DataFrame,
        coordinates_df: pd.DataFrame,
        x_col: str,
        y_col: str,
        candidate_field: Optional[str] = None,
    ) -> pd.DataFrame:
        df[x_col] = coordinates_df[x_col].to_numpy()
        df[y_col] = coordinates_df[y_col].to_numpy()
        return df

    def get_cluster_filter_mask(
        self, x_uids: List[str], cluster_x_uids: List[str]
    ) -> pd.Series:
        return pd.Series([x_uid in cluster_x_uids for x_uid in x_uids])

    def update_probs_with_ground_truth_probs(
        self, probs: Dict[str, Any], gt_probs: Dict[str, Any]
    ) -> Dict[str, Any]:
        probs.update(gt_probs)
        return probs

    def get_decision_tree_candidate_labels(
        self, raw_label: Optional[Any] = None
    ) -> List[Any]:
        """Get candidate raw labels for numeric generator decision tree. If raw_label is provided, this function generates based on the
        provided label. Otherwise, this function generates based on the label space's label map.

        Args:
            raw_label (Any): raw label in corresponding label space

        Raises:
            NotSupportedException: If the current label space does not support numeric generator

        Returns:
            List[Any]: a list of candidate labels for the numeric generator decision tree
        """
        err_msg = f"Get LF labels is not supported in {type(self)}."
        raise NotSupportedException(detail=err_msg, user_friendly_message=err_msg)

    def get_decision_tree_label(
        self, decision_tree_label: Any, provided_label: Any
    ) -> Optional[str]:
        """Given numeric generator's decision tree label and a raw label, calculate the raw label's representation in the decision tree

        Args:
            decision_tree_label (Any): decision tree's raw label in corresponding label space
            provided_label (Any): For single label space, it is a str. For multi label space, it is a label and presence strs tuple.

        Raises:
            NotSupportedException: If the current label space does not support numeric generator

        Returns:
            Optional[Any]: the provided raw label's representation in the decision tree if there is a match. Otherwise, return None
        """
        err_msg = f"Get Decision tree is not supported in {type(self)}."
        raise NotSupportedException(detail=err_msg, user_friendly_message=err_msg)

    @abstractmethod
    def compute_gt_label_distribution(
        self, gt: LabelsType, user_formatted: bool = False
    ) -> Dict[
        Any, Any
    ]:  # actually Dict[Union[str, int], Union[int, Dict[int, int]]], but mypy can't resolve the types correctly
        pass

    @abstractmethod
    def support_custom_metrics(self) -> bool:
        """Whether the label space support custom metrics"""
        pass


def probs_to_preds_with_threshold_flat(
    probs: np.ndarray,
    tie_break_policy: str,
    tol: float,
    filter_uncertain_labels_threshold: float,
    unknown_label: int,
    lf_abstains: Optional[np.ndarray] = None,
    random_seed: int = 123,
) -> np.ndarray:
    """Convert an array of probabilistic labels into an array of predictions.

    Includes confidence threshold---outputs abstain if max probability is below.

    Policies to break ties include:
    "abstain": return an abstain vote (-1)
    "true-random": randomly choose among the tied options
    "random": randomly choose among tied option using deterministic hash

    NOTE: if tie_break_policy="true-random", repeated runs may have slightly different results due to difference in broken ties

    Parameters
    ----------
    prob
        A [num_datapoints, num_classes] array of probabilistic labels such that each
        row sums to 1.
    tie_break_policy
        Policy to break ties when converting probabilistic labels to predictions
    tol
        The minimum difference among probabilities to be considered a tie
    filter_uncertain_labels_threshold
        The confidence threshold. If maximum class probability (on a point) is below
        the threshold, the point gets set to abstain
    unknown_label
        The label assigned to the tied probs. Only used when tie_break_policy == 'abstain'
    random_seed
        ONLY used when tie_break_policy == 'random'.

    Returns
    -------
    np.ndarray
        A [n] array of predictions (integers in [0, ..., num_classes - 1])

    Examples
    --------
    >>> probs_to_preds(np.array([[0.5, 0.5, 0.5]]), tie_break_policy="abstain")
    array([-1])
    >>> probs_to_preds(np.array([[0.8, 0.1, 0.1]]))
    array([0])
    """

    perf_time_log = PerfTimeLog("probs_to_preds_with_threshold_flat")

    if tie_break_policy not in {"abstain", "random", "true-random"}:
        raise ValueError(f"tie_break_policy={tie_break_policy} policy not recognized.")

    num_datapoints, num_classes = probs.shape

    if num_classes <= 1:
        raise ValueError(
            f"probs must have probabilities for at least 2 classes. "
            f"Instead, got {num_classes} classes."
        )

    winners = probs.argmax(axis=1)
    max_probs = probs[np.arange(num_datapoints), winners]

    perf_time_log.update("Compute max probs and associated class indices")

    # -lf_abstains indicate abstains based entirely on lf abstain patterns (ie no votes at all or
    # abstains on labels the label model predicted, determined in compute_lf_abstains)
    # -all abstains need to include additional cases where the label model is uncertain even though there
    # is evidence for the label prediction from LF votes

    if filter_uncertain_labels_threshold > 0:
        non_abstains = max_probs >= filter_uncertain_labels_threshold
    else:
        non_abstains = np.full((num_datapoints,), True)

    if lf_abstains is not None:
        non_abstains = np.logical_and(~lf_abstains, non_abstains)

    perf_time_log.update(
        "Compute non-abstain indices and combine with existing lf non-abstains if they exist"
    )

    num_non_abstain_samples = non_abstains.sum()

    probs = probs[non_abstains]
    max_probs = max_probs[non_abstains]
    winners = winners[non_abstains]

    perf_time_log.update("Compute count of non-abstains and filter variables")

    # Look for contestants close to the winner within some tolerance
    almost_winners = np.abs(probs - max_probs[:, np.newaxis]) < tol

    perf_time_log.update("Compute close contestants")

    num_almost_winners = almost_winners.sum(axis=1)
    tied_samples = num_almost_winners > 1
    num_tied_samples = tied_samples.sum()

    # First take clear winners from the original argmax function
    Y_non_abstain_non_tied = winners[~tied_samples]

    perf_time_log.update(
        "Compute # close contestants per sample, ties and overall tied sum, filter preds"
    )

    if tie_break_policy == "abstain":
        Y_non_abstain_tied = np.full((num_tied_samples,), unknown_label)
    else:
        almost_winners = almost_winners[tied_samples]
        num_almost_winners = num_almost_winners[tied_samples]
        if tie_break_policy == "true-random":
            rng = np.random.default_rng()
            for_reals_winners = np.floor(
                num_almost_winners * rng.uniform(0, 1, (num_tied_samples,))
            ).astype("int")
            # need to map into winners now
            Y_non_abstain_tied = np.array(
                [
                    np.where(almost_winners[i])[0][for_reals_winners[i]]
                    for i in range(num_tied_samples)
                ]
            )
        else:
            # Goal here is to make identical predictions for identical prob vectors, which we take as a proxy
            # for identical data inputs. This is esp important if we're using label models as end models.
            rng = np.random.default_rng(random_seed)
            probs = probs[tied_samples]
            prob_tuples = list(map(lambda x: hash(tuple(x)), probs))
            prob_dict = {
                x: y
                for x, y in zip(
                    prob_tuples,
                    [np.where(almost_winners[i])[0] for i in range(num_tied_samples)],
                )
            }

            # Making sure we obtain same results for same data shuffled
            prob_dict = OrderedDict(sorted(prob_dict.items()))
            num_almost_winners_unique = np.array(list(map(len, prob_dict.values())))
            num_unique_tied_samples = len(prob_dict)
            for_reals_winners = (
                np.floor(
                    num_almost_winners_unique
                    * rng.uniform(0, 1, (num_unique_tied_samples,))
                )
                .astype("int")
                .tolist()
            )

            Y_non_abstain_tied_unique = {
                prob_tuple: almost_winner[for_reals_winner]
                for prob_tuple, almost_winner, for_reals_winner in zip(
                    prob_dict.keys(), prob_dict.values(), for_reals_winners
                )
            }
            Y_non_abstain_tied = np.array(
                [Y_non_abstain_tied_unique[prob_tuple] for prob_tuple in prob_tuples]
            )

    perf_time_log.update("Compute tie-breaks")

    Y_non_abstain = np.empty((num_non_abstain_samples,))
    Y_non_abstain[tied_samples] = Y_non_abstain_tied
    Y_non_abstain[~tied_samples] = Y_non_abstain_non_tied

    Y_pred = np.full((num_datapoints,), unknown_label)
    Y_pred[non_abstains] = Y_non_abstain

    Y_pred = Y_pred.astype(int)

    perf_time_log.update("Fill in tie-breaks, create final pred variable")

    logger.debug(perf_time_log.pretty_summary())

    return Y_pred


def convert_generator_to_array(
    L_generator: Generator, do_sparse: bool = False
) -> Union[np.ndarray, sparse._coo.core.COO]:
    all_arrays = list(L_generator)

    if len(all_arrays) == 0:
        return sparse.COO([]) if do_sparse else np.array([])

    if do_sparse:
        all_arrays = sparse.concatenate(all_arrays, axis=0)
    else:
        all_arrays = np.vstack(all_arrays)

    return all_arrays
