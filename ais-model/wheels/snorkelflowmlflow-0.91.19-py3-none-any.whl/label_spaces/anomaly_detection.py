import re
from typing import Any, Callable, Dict, Iterable, List, Optional, Tuple

import numpy as np
import pandas as pd

import label_spaces.common.constants as constants
from label_spaces.base import RawLabels
from label_spaces.common import metrics_utils
from label_spaces.single import SingleLabelSpace
from snorkelflow.utils.logging import get_logger

logger = get_logger("Label Space")

timestamp_pat = re.compile(r"\d{4}-\d{2}-\d{2}\s\d{2}:\d{2}:\d{2}")


class AnomalyDetectionLabelSpace(SingleLabelSpace):
    """Manages labels and metrics for anomaly detection."""

    def _compute_metrics(
        self,
        ground_truth: RawLabels,
        prediction: RawLabels,
        metrics: List[str],
        custom_metric_funcs: Dict[str, Callable],
        df: Optional[pd.DataFrame] = None,
        df_uid_col: Optional[str] = None,
        extra_params: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        if extra_params is None:
            extra_params = {}

        # Get a sorted list of the x_uids
        sorted_x_uids = sort_x_uids(ground_truth.labels)
        d_probs = (
            self.to_array_probs(prediction.probs)
            if getattr(prediction, "probs")
            else None
        )
        d_golds = ground_truth.labels
        d_preds = prediction.labels
        golds, preds, probs = [], [], []
        # Iterate through the sorted x_uids to generate time ordered arrays
        for x_uid in sorted_x_uids:
            if (
                d_golds.get(x_uid, self.get_raw_unknown_label())
                == self.get_raw_unknown_label()
            ):
                continue
            golds.append(d_golds.get(x_uid, self.get_raw_unknown_label()))
            if d_probs:
                probs.append(d_probs[x_uid])  # type: ignore
            preds.append(d_preds[x_uid])
        return metrics_utils.compute_classification_metrics(
            np.array(golds),
            np.array(preds),
            self.label_map,
            metrics,
            custom_metric_funcs,
            np.array(probs) if probs else None,
            self.get_raw_unknown_label(),
        )

    @staticmethod
    def _get_gt_label_mask(label_int: int, label_vector: pd.Series) -> pd.Series:
        return label_vector == label_int

    def get_gt_comparison_mask(
        self, gt_vector: pd.Series, config: Dict[str, Any]
    ) -> pd.Series:
        """Returns a mask where GT is present, if the vote type is incorrect/correct,
        otherwise returning a mask of all Trues"""
        if config["voted"] in [constants.CORRECT, constants.INCORRECT]:
            return gt_vector != self.get_raw_unknown_label()
        return pd.Series([True for _ in range(len(gt_vector))])

    def filter_label_vector(
        self,
        data_vector: pd.Series,
        gt_vector: pd.Series,
        config: Dict[str, Any],
        x_uids: Optional[List[str]] = None,
        split: str = "dev",
    ) -> pd.DataFrame:
        """Voted will either be a class str, or 'correct' / 'incorrect'"""
        voted = config["voted"]
        if voted == constants.CORRECT:
            not_abstain = np.logical_not(
                np.logical_or(
                    data_vector == self.get_raw_unknown_label(),
                    gt_vector == self.get_raw_unknown_label(),
                )
            )
            mask = np.logical_and(data_vector == gt_vector, not_abstain)
            return pd.DataFrame({"mask": mask})
        if voted == constants.INCORRECT:
            # Incorrect if disagrees w/ ground truth and neither ground truth
            # nor label is abstain
            not_abstain = np.logical_not(
                np.logical_or(
                    data_vector == self.get_raw_unknown_label(),
                    gt_vector == self.get_raw_unknown_label(),
                )
            )
            mask = np.logical_and(data_vector != gt_vector, not_abstain)
            return pd.DataFrame({"mask": mask})
        if voted == constants.ANY:
            mask = data_vector != self.get_raw_unknown_label()
            return pd.DataFrame({"mask": mask})

        mask = self._get_gt_label_mask(self.label_map[voted], data_vector)
        return pd.DataFrame({"mask": mask})

    def get_default_lm_scoring_metric(self) -> str:
        return "anomaly_f1"

    def _subsample_uids(
        self,
        x_uids: List[Any],
        sparse_matrix: List[Any],
        max_num_examples: int,
        random_seed: int,
    ) -> Tuple[List[Any], List[Any]]:
        # Single Label Space randomly samples, but we need to chop off the first n rows to subsample
        # Subsampling here
        sparse_matrix = sparse_matrix[:max_num_examples]
        x_uids = x_uids[:max_num_examples]
        return (x_uids, sparse_matrix)


def sort_x_uids(x_uids: Iterable[str]) -> List[str]:
    ts_xuid_map = {}
    for x_uid in x_uids:
        match = timestamp_pat.search(x_uid)
        if match:
            ts_xuid_map[x_uid] = match.group(0)
        else:
            raise ValueError("timestamp not found in x_uids")
    return [
        x_uid for (x_uid, _) in sorted(ts_xuid_map.items(), key=lambda item: item[1])
    ]
