from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional, Tuple

import pandas as pd

from label_spaces import base


class LabelSpaceMixinBase(ABC):
    """Base class for label space mixins. Used to determine what functionality a
    label space implements.
    """


class ActiveLearningMixin(LabelSpaceMixinBase):
    """
    Mixin used to determine if entropy needs to be calculated
    """

    pass


class MarginFilterMixin(LabelSpaceMixinBase):
    """
    Mixin used to determine if margin filter needs to be calculated
    """

    pass


class TruncateSearchResponseMixin(LabelSpaceMixinBase):
    """
    Mixin used to determine if search response is truncated
    """

    pass


class LFQualityMixin(LabelSpaceMixinBase):
    """
    Mixin used to determine if LF quality can be calculated
    """

    pass


class AutoTuneMixin(LabelSpaceMixinBase):
    """
    Mixin used to determine if AutoTune can be used
    """

    pass


class TrainingSetStatsMixin(LabelSpaceMixinBase):
    @abstractmethod
    def compute_training_set_statistics(
        self,
        ts_labels: "base.RawLabels",
        gt_labels: "base.RawLabels",
        random_seed: int,
        sample_size: int,
    ) -> Optional["base.TrainingSetStats"]:
        pass


class TextDataMixin(LabelSpaceMixinBase):
    @property
    @abstractmethod
    def text_col(self) -> str:
        pass


class HighlightMetadataMixin(LabelSpaceMixinBase):
    @property
    @abstractmethod
    def text_col(self) -> str:
        pass

    @abstractmethod
    def transform_gt_labels(
        self,
        raw_gt_labels: Tuple[List[str], List[Any]],
        inverse_label_map: Dict[int, str],
        fetch_span_text: bool = False,
        df: pd.DataFrame = None,
    ) -> Dict[str, Any]:
        pass

    @abstractmethod
    def transform_training_set_labels(
        self,
        raw_ts_labels: Tuple[
            list, list, Any
        ],  # Any here represents LabelFetchingMetadata
        inverse_label_map: Dict[int, str],
        ts_uid: int,
        fetch_span_text: bool = False,
        df: pd.DataFrame = None,
    ) -> Dict[str, Any]:
        pass

    @abstractmethod
    def transform_lf_labels(
        self,
        raw_lf_labels: List[Dict[str, Any]],
        inverse_label_map: Dict[int, str],
        lf_name_map: Dict[int, str],
        fetch_span_text: bool = False,
        df: pd.DataFrame = None,
    ) -> Dict[str, Any]:
        pass

    @abstractmethod
    def transform_model_predictions(
        self,
        raw_model_predictions: List[Dict[str, Any]],
        inverse_label_map: Dict[int, str],
        model_uid: int,
        fetch_span_text: bool = False,
        df: pd.DataFrame = None,
    ) -> Dict[str, Any]:
        pass


class LfVotedInfoMixin(LabelSpaceMixinBase):
    @abstractmethod
    def get_lf_voted_info(
        self,
        x_uids: List[str],
        lf_labels: Dict[str, Dict[int, Any]],
        ground_truth_labels: base.LabelsType,
        spans: Optional[List[List[List[int]]]] = None,
        documents: Optional[Dict[str, str]] = None,
    ) -> Dict[str, Any]:
        """Compute lf voted infomation for given x_uids with lf_labels and ground_truth_labels

        Parameters
        ----------
        x_uids :
            Requested x_uids
        lf_labels :
            lf_labels for x_uids
        ground_truth_labels :
            ground_truth_labels for x_uids
        spans : optional
            compute lf voted info for each span in spans, only required for sequence tagging, should be the same length as x_uids,
        documents : optional
            only required for sequence tagging, a dict of documents, key is x_uid, value is document text.
        """
        pass
