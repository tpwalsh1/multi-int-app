from multiprocessing import synchronize
from typing import Dict, Tuple

import psutil

STOP_EV_WAIT_TIME_SEC = 0.01


def get_process_memory(include_children: bool = False) -> Tuple[int, int]:
    p = psutil.Process()
    mem_info = p.memory_info()
    rss = mem_info.rss
    vms = mem_info.vms

    if include_children:
        child_p: Dict[int, psutil.Process] = {}
        for child in p.children(recursive=True):
            if child.pid in child_p and child_p[child.pid].is_running():
                child = child_p[child.pid]
            else:
                child_p[child.pid] = child

            try:
                mem_info = child.memory_info()
                rss += mem_info.rss
                vms += mem_info.vms
            except Exception:
                # Child can get killed out of band
                pass

    return (rss, vms)


def memory_usage_monitor(
    stop_ev: synchronize.Event, stop_ev_wait_time: float = STOP_EV_WAIT_TIME_SEC
) -> Tuple[int, int]:
    current_rss, current_vms = get_process_memory()

    rss, vms = current_rss, current_vms
    while not stop_ev.wait(stop_ev_wait_time):
        tmp_rss, tmp_vms = get_process_memory()
        rss = max(rss, tmp_rss)
        vms = max(vms, tmp_vms)

    return rss, vms
