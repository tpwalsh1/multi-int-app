from typing import Dict, List, Optional

import psutil
import pynvml
from gpustat import GPUStat, GPUStatCollection

from concurrency_utils.threading import PeriodicTimer
from snorkelflow.utils.logging import get_logger
from snorkelflow.utils.statsd import stats

logger = get_logger("ProcessMetricsCollector")


class _ProcessMetricsCollector(PeriodicTimer):
    def __init__(self, parent_pid: Optional[int] = None):
        logger.info("Starting process metrics collector")
        super().__init__(interval=5, daemon=True, ignore_errors=True)
        self._parent_pid = parent_pid

        try:
            GPUStatCollection.new_query()
        except pynvml.NVMLError_LibraryNotFound:
            logger.warning(
                "Not running GPU metrics collector due to missing NVML library"
            )
            self._gpu = False
        else:
            self._gpu = True

    def _run(self) -> None:
        self._collect_per_process_metrics()

        self._collect_network_io_metrics()
        if self._gpu:
            self._collect_gpu_metrics()

    def _collect_per_process_metrics(self) -> None:
        # Collect per-process CPU and memory metrics
        for p in self._get_processes():
            try:
                metrics = self._collect_process(p)
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue
            except Exception:
                logger.warning(
                    f"Failed to collect metrics for process {p.pid}", exc_info=True
                )
                continue

            for metric_name, metric_value in metrics.items():
                stats.gauge_set(
                    metric_name,
                    metric_value,
                    tags={"pid": p.pid},
                    include_hostname_tag=True,
                )

    def _get_processes(self) -> List[psutil.Process]:
        parent = psutil.Process(self._parent_pid)
        return [parent] + parent.children(recursive=True)

    def _collect_process(self, p: psutil.Process) -> Dict[str, float]:
        with p.oneshot():
            cpu_time = p.cpu_times()
            ctx_switches = p.num_ctx_switches()
            disk_io = p.io_counters()
            return {
                "per_process_cpu_time": cpu_time.system + cpu_time.user,
                "per_process_memory_rss": p.memory_info().rss,
                "per_process_disk_io_read_bytes": disk_io.read_bytes,
                "per_process_disk_io_write_bytes": disk_io.write_bytes,
                "per_process_ctx_switches_voluntary": ctx_switches.voluntary,
                "per_process_ctx_switches_involuntary": ctx_switches.involuntary,
                "per_process_num_threads": p.num_threads(),
                "per_process_num_fds": p.num_fds(),
            }

    def _collect_network_io_metrics(self) -> None:
        network_io = psutil.net_io_counters()
        stats.gauge_set(
            "network_io_bytes_sent", network_io.bytes_sent, include_hostname_tag=True
        )
        stats.gauge_set(
            "network_io_bytes_recv", network_io.bytes_recv, include_hostname_tag=True
        )

    def _collect_gpu_metrics(self) -> None:
        # Unfortunately the processes use the container host's PID namespace,
        # so we can't map them to the processes in the container.
        # https://github.com/NVIDIA/nvidia-docker/issues/179
        # For now, we won't report the PID metrics
        gpu_stats = GPUStatCollection.new_query()
        gpu: GPUStat

        for gpu in gpu_stats.gpus:
            # This is notably missing power state, which is not exposed by gpustat,
            # but is available in pynvml
            # Didn't decide to put in the time to figure out pynvml yet
            gauge_metrics = {
                "gpu_memory_total": gpu.memory_total,
                "gpu_memory_used": gpu.memory_used,
                "gpu_utilization": gpu.utilization,
                "gpu_power_draw": gpu.power_draw,
                "gpu_power_limit": gpu.power_limit,
            }
            for metric_name, metric_value in gauge_metrics.items():
                stats.gauge_set(
                    metric_name,
                    metric_value,
                    include_hostname_tag=True,
                    tags={"device_index": gpu.index},
                )


def install_process_metrics_collector() -> None:
    _ProcessMetricsCollector().start()
