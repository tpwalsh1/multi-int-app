import re
from typing import Optional

import jwt

from api_utils.exceptions import AuthenticationError
from snorkelflow.utils.logging import get_logger

logger = get_logger("Key Util")


public_jwt_key_fname = "/etc/auth/jwt/jwt_key.pub"
sso_key_cert_fname = "/etc/auth/sso/sso_key.cert"

_public_jwt_key: Optional[bytes] = None
_sso_key_cert: Optional[bytes] = None
JWT_ALGORITHM = "RS256"


class JWTKeyError(Exception):
    pass


class SSOKeyError(Exception):
    pass


def init_public_jwt_key() -> None:
    global _public_jwt_key
    try:
        with open(public_jwt_key_fname, "r") as f:
            _public_jwt_key = f.read().encode()
    except FileNotFoundError:
        return None


# Private function for easier mocking
def _get_public_jwt_key() -> bytes:
    if _public_jwt_key:
        return _public_jwt_key
    else:
        raise JWTKeyError("JWT public key not found.")


def get_public_jwt_key() -> bytes:
    return _get_public_jwt_key()


def validate_jwt_request(token: str) -> None:
    try:
        jwt.decode(token, get_public_jwt_key(), algorithms=[JWT_ALGORITHM])
    except jwt.PyJWTError:
        err_msg = "Authentication Error: Could not authenticate JWT"
        raise AuthenticationError(detail=err_msg, user_friendly_message=err_msg)


def get_jwt_user_uid(token: str) -> int:
    try:
        user_jwt = jwt.decode(token, get_public_jwt_key(), algorithms=[JWT_ALGORITHM])
        user_uid = user_jwt.get("user_uid")
        if user_uid is None:
            err_msg = "No user_uid found in JWT."
            raise AuthenticationError(detail=err_msg, user_friendly_message=err_msg)
        return int(user_uid)
    except jwt.PyJWTError:
        err_msg = "Authentication Error: Could not authenticate JWT."
        raise AuthenticationError(detail=err_msg, user_friendly_message=err_msg)


def get_jwt_username(token: str, key: bytes) -> str:
    try:
        if key is None:
            key = get_public_jwt_key()
        user_jwt = jwt.decode(token, key, algorithms=[JWT_ALGORITHM])
        username = user_jwt.get("username")
        if username is None:
            err_msg = "No username found in JWT."
            raise AuthenticationError(detail=err_msg, user_friendly_message=err_msg)
        return username
    except jwt.PyJWTError:
        err_msg = "Authentication Error: Could not authenticate JWT."
        raise AuthenticationError(detail=err_msg, user_friendly_message=err_msg)


def init_sso_key_cert() -> None:
    global _sso_key_cert
    try:
        with open(sso_key_cert_fname, "r") as f:
            _sso_key_cert = f.read().encode()
    except FileNotFoundError:
        return None


def _get_sso_key_cert() -> bytes:
    if _sso_key_cert:
        return _sso_key_cert
    else:
        raise SSOKeyError("SSO cert not found.")


pem_preamble = re.compile(r"^\-+BEGIN.*\-+$")
pem_ending = re.compile(r"^\-+END.*\-+$")


# We expect the format to be:
# -----BEGIN <something>-----
# <ACTUAL CERT>
# -----END <something>-----
# Otherwise, extract_cert_contents will fail if the actual cert is on the same line
# as the BEGIN or END
def is_valid_pem_formatted_cert(contents: str) -> bool:
    lines = contents.strip().splitlines()
    if len(lines) < 3:
        return False
    if pem_preamble.search(lines[0]) is None:
        return False
    return pem_ending.search(lines[-1]) is not None


def extract_cert_contents(pem_formatted_contents: str) -> str:
    if not is_valid_pem_formatted_cert(pem_formatted_contents):
        raise SSOKeyError(
            f"Invalid x509 certificate. Please make sure the x509 certificate starts with ------BEGIN CERTIFICATE------, the certificate itself is on its own line separate from the BEGIN and END certificate, and that you have provided the complete, unedited document. You provided '{pem_formatted_contents}', which is invalid."
        )
    sso_key_cert_contents = pem_formatted_contents.strip().splitlines()
    return "".join(sso_key_cert_contents[1:-1])


def get_sso_key_cert() -> bytes:
    return _get_sso_key_cert()


def extract_sso_key_cert() -> str:
    return get_sso_key_cert().decode()


def get_sso_key_cert_contents() -> str:
    return extract_cert_contents(extract_sso_key_cert())
