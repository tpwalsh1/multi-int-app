from datetime import datetime

import pytz


def is_valid_timezone(timezone: str) -> bool:
    try:
        pytz.timezone(timezone)
        return True
    except Exception:
        return False


def datetime_in_timezone(timezone: str) -> datetime:
    tz = pytz.timezone(timezone)
    return datetime.now(tz)
