import os
from typing import Optional

from snorkelflow.config.constants import (
    ALLOWED_ENVIRONMENT_VARIABLES,
    SERVICE_TYPE_ENV_VAR,
    ServiceType,
)
from snorkelflow.utils.logging import get_logger

# If service type is set, enforce what env vars can be read
# This env var will always be set when booting services through snorkel-install
# This env var will possibly be unset when running tests
_service_type_str: Optional[str] = os.environ.get(SERVICE_TYPE_ENV_VAR)
_service_type: Optional[ServiceType] = (
    ServiceType(_service_type_str) if _service_type_str else None
)

_api_logger = get_logger("api_utils")


def get_service_type() -> Optional[ServiceType]:
    return _service_type


def get_env_var(env_var_name: str, default: Optional[str] = None) -> Optional[str]:
    """Gets an env var with the specified name. Must be allowlisted in
    snorkelflow/config/constants.py
    """
    if _service_type is not None:
        allowed_env_vars = ALLOWED_ENVIRONMENT_VARIABLES.get(_service_type, [])
        if env_var_name not in allowed_env_vars:
            _api_logger.warn(
                f"{env_var_name} is not a allowlisted env var for service type {_service_type}."
            )
    return os.environ.get(env_var_name, default)
