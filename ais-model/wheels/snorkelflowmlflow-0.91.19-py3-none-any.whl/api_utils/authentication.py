from functools import wraps
from typing import Any, Callable, Optional

from fastapi import APIRouter, Request, Response
from starlette.middleware.base import BaseHTTPMiddleware, RequestResponseEndpoint

from api_utils.decorator import (
    EndpointRegistry,
    EndpointSpec,
    decorator_add_endpoint_to_registry,
)
from api_utils.route import MiddlewareHTTPError
from snorkelflow.utils.logging import get_logger

logger = get_logger("APIUTILS")

# Per-service global allowlist of endpoints that allow access without
# authentication (i.e. don't look for token in auth-headers).
# This tuple contains (HTTP_METHOD, PATH) and is populated via
# the use of the @no_auth_required decorator.
# un_authenticated_endpoints: EndpointRegistry = []
un_authenticated_endpoints: EndpointRegistry = EndpointRegistry()


class InvalidAuthHeaderFormat(Exception):
    def __init__(self, message: str = "Invalid Authorization header format"):
        super(InvalidAuthHeaderFormat, self).__init__(message)


def parse_token_from_cookie(request: Request) -> Optional[str]:
    """If they don't include an Authorization header we return None,
    if they include one but it's in an invalid format we raise an Exception"""
    authorization_header = request.cookies.get("authorization", None)
    if not authorization_header:
        return None
    split = authorization_header.split(" ")
    if not len(split) == 2 or split[0].lower() not in ("bearer", "token"):
        raise InvalidAuthHeaderFormat(f"Found Authorization header in invalid format")
    _, token = split
    return token


def parse_token_from_header(request: Request) -> Optional[str]:
    """If they don't include an Authorization header we return None,
    if they include one but it's in an invalid format we raise an Exception"""
    authorization_header = request.headers.get("Authorization", None)
    if not authorization_header:
        return None
    # HACK: If authorization contains a comma, just take the last portion (most recently added)
    authorization_header_split = authorization_header.split(",")[-1]
    split = authorization_header_split.split(" ")
    if not len(split) == 2 or split[0].lower() not in ("bearer", "token"):
        raise InvalidAuthHeaderFormat(
            f"Found Authorization header in invalid format: {authorization_header_split}. Original: {authorization_header}"
        )
    _, token = split
    return token


def no_auth_required(router: APIRouter) -> Callable:
    def logging_callback(spec: EndpointSpec) -> None:
        logger.info(
            f"Saving ({spec.method},{spec.path}) as an un-authenticated endpoint"
        )

    return decorator_add_endpoint_to_registry(
        router, un_authenticated_endpoints, logging_callback=logging_callback
    )


def parse_api_key_from_header(request: Request) -> Optional[str]:
    authorization_header = request.headers.get("Authorization", None)
    if not authorization_header:
        return None
    split = authorization_header.split(" ")
    if not len(split) == 2 or split[0].lower() != "key":
        return None
    _, token = split
    return token


# NOTE - this only works when wrapping a member function of a Middleware class
# it doesn't work on direct middleware definition via @app.middleware("http")
def _conditionally_skip_middleware(condition: Callable[[Request], bool]) -> Callable:
    """
    This will cause us to skip evaluation of a middleware function if the provided
    condition evaluates to true over the incoming request.
    """

    def request_context_wrapper(func: Callable) -> Callable:
        @wraps(func)
        async def wrapper(self: Any, request: Request, call_next: Any) -> Any:
            if condition(request):
                return await call_next(request)
            return await func(self, request, call_next)

        return wrapper

    return request_context_wrapper


def check_auth_is_set(request: Request) -> bool:
    # NOTE - on interservice requests the user_uid field will exist
    # but will be None (no user info crosses interservice barrier)
    # NOTE - we can eventually move this to just check the context
    # variables are set and get away from checking request.state entirely
    attrs = ["authorization_header", "user_uid"]
    return all([hasattr(request.state, attr) for attr in attrs])


def _check_endpoint_is_unauthenticated(request: Request) -> bool:
    """Using the Starlette route-matching logic, see if the incoming request matched
    any of our routes marked as unauthenticated"""
    return un_authenticated_endpoints.match_request_with_metadata(
        request, metadata=None
    )


# This decorator tells a middleware stage to skip running (e.g. pass the request through)
# if the endpoint is decorate by @no_auth_required e.g. the endpoint required no authentication
# for access
skip_if_endpoint_unauthenticated = _conditionally_skip_middleware(
    _check_endpoint_is_unauthenticated
)

# Different stages of middleware can perform authentication, if one stage
# has already authenticated a user it will set the request.state object to
# contain the authorization headers and possibly the user's UID. Putting this
# decorator around middleware will cause that middleware stage to be skipped
# if an earlier stage has already authenticated the request (and set the
# request.state accordingly)
skip_if_already_authenticated = _conditionally_skip_middleware(check_auth_is_set)


class BasicAPIKeyAuthenticationMiddleware(BaseHTTPMiddleware):
    """Simple middleware that checks header against an API key environment variable."""

    def __init__(self, api_key: Optional[str], *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)
        self.required_api_key = api_key

    @skip_if_endpoint_unauthenticated
    @skip_if_already_authenticated
    async def dispatch(
        self, request: Request, call_next: RequestResponseEndpoint
    ) -> Response:
        if self.required_api_key:
            api_key_plaintext = parse_api_key_from_header(request)
            if api_key_plaintext != self.required_api_key:
                return MiddlewareHTTPError(
                    message="Authentication Error", status_code=401
                )
        else:
            logger.info("No API key required. Skipping authentication.")
        return await call_next(request)
