import inspect
import time
import traceback
import typing
from dataclasses import dataclass
from typing import Any, Awaitable, Callable, Dict

import orjson
from fastapi import Request, status
from starlette.middleware.base import BaseHTTPMiddleware, RequestResponseEndpoint
from starlette.responses import JSONResponse, Response

from api_utils.constants import REQ_ID_HEADER
from api_utils.exceptions import (
    AppSetupError,
    AuthenticationError,
    AuthorizationError,
    DuplicateValueError,
    NotFoundError,
    NotLicensedError,
    NotSupportedException,
    RequestConflictError,
    RequestTimeout,
    ResourceGoneError,
    ServerError,
    SnorkelException,
    SnorkelFlowAPIException,
    UnprocessableEntityError,
    UserInputError,
)
from api_utils.metrics import emit_route_metrics
from api_utils.request_logging import get_log_request_info
from api_utils.string import random_id
from profiling_utils.pyroscope import pyroscope_tag_wrapper
from snorkelflow.utils.logging import from_log_ctx, get_logger, log_ctx

try:
    from services.observability.trace import add_global_trace_tag
except ImportError:
    add_global_trace_tag = lambda *args, **kwargs: None

access_logger = get_logger("app.access")
DEFAULT_SERVER_ERROR_MESSAGE = "A server error occurred while handling the request"


class ORJSONResponse(JSONResponse):
    """Normal JSON encoding results in nan float values being out of range (i.e. np.nan, float('nan'))
    Using orjson in the middleware allows us to convert all of these without getting compliance errors.
    Not using https://github.com/tiangolo/fastapi/blob/master/fastapi/responses.py#L29 as we need to
    specify certain dumps options (for auto int-> str key conversion, numpy serialization, utc)
    """

    media_type = "application/json"

    def render(self, content: Any) -> bytes:
        return orjson.dumps(content, option=orjson.OPT_NON_STR_KEYS | orjson.OPT_SERIALIZE_NUMPY | orjson.OPT_NAIVE_UTC)  # type: ignore


@dataclass
class ORMRegistryItem:
    status_code: int
    default_message: str


class ORMExceptionRegistry:
    registry: Dict[typing.Type[SnorkelException], ORMRegistryItem] = {
        SnorkelException: ORMRegistryItem(
            status_code=status.HTTP_400_BAD_REQUEST, default_message="An error occurred"
        ),
        NotFoundError: ORMRegistryItem(
            status_code=status.HTTP_404_NOT_FOUND,
            default_message="A requested resource was not found",
        ),
        AuthorizationError: ORMRegistryItem(
            status_code=status.HTTP_403_FORBIDDEN, default_message="Permission denied"
        ),
        NotLicensedError: ORMRegistryItem(
            status_code=status.HTTP_403_FORBIDDEN,
            default_message="Cannot perform this action with current license",
        ),
        AuthenticationError: ORMRegistryItem(
            status_code=status.HTTP_401_UNAUTHORIZED,
            default_message="Authentication failure",
        ),
        UserInputError: ORMRegistryItem(
            status_code=status.HTTP_400_BAD_REQUEST,
            default_message="The input could not be parsed properly",
        ),
        DuplicateValueError: ORMRegistryItem(
            status_code=status.HTTP_400_BAD_REQUEST,
            default_message="Resource already exists",
        ),
        UnprocessableEntityError: ORMRegistryItem(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            default_message="Could not parse unprocessable entity",
        ),
        NotSupportedException: ORMRegistryItem(
            status_code=status.HTTP_400_BAD_REQUEST,
            default_message="Functionality is not yet supported in SnorkelFlow",
        ),
        ServerError: ORMRegistryItem(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            default_message=DEFAULT_SERVER_ERROR_MESSAGE,
        ),
        RequestTimeout: ORMRegistryItem(
            status_code=status.HTTP_408_REQUEST_TIMEOUT,
            default_message="Request timeout",
        ),
        RequestConflictError: ORMRegistryItem(
            status_code=status.HTTP_409_CONFLICT,
            default_message="Request conflicted with current state of the resource",
        ),
        ResourceGoneError: ORMRegistryItem(
            status_code=status.HTTP_410_GONE,
            default_message="Resource no longer exists",
        ),
        AppSetupError: ORMRegistryItem(
            status_code=420,
            default_message="App can't be loaded using the onboarding flow",
        ),
    }

    @classmethod
    def subclass_depth(cls, exception_type: typing.Type[SnorkelException]) -> int:
        return len(inspect.getmro(exception_type))

    @classmethod
    def get_most_relevant_item(cls, e: SnorkelException) -> ORMRegistryItem:
        """Converts an exception to the most relevant registry item by checking subclass depth"""
        max_priority = -1
        most_relevant_exception = SnorkelException
        for exception in cls.registry:
            if issubclass(type(e), exception):
                priority = cls.subclass_depth(exception)
                # More specific errors (i.e. more subclass depth) are given preference
                if priority > max_priority:
                    max_priority = priority
                    most_relevant_exception = exception
        return cls.registry[most_relevant_exception]


class ORMExceptionMappingMiddleware(BaseHTTPMiddleware):
    async def dispatch(
        self, request: Request, call_next: RequestResponseEndpoint
    ) -> Response:
        try:
            return await call_next(request)
        except SnorkelException as e:
            req_id = from_log_ctx("req_id")
            exception_metadata = ORMExceptionRegistry.get_most_relevant_item(e)
            status_code = exception_metadata.status_code
            if status_code >= 500:
                # If it's a server error go ahead and log the full traceback
                access_logger.exception(
                    f"req_id:{req_id} {request.method} {request.url} {status_code}"
                )
            metadata = {"traceback": traceback.format_exc(limit=-5)}
            if e.metadata:
                metadata.update(e.metadata)
            raise SnorkelFlowAPIException(
                status_code=status_code,
                detail=e.detail,
                user_friendly_message=e.user_friendly_message
                if e.user_friendly_message
                else exception_metadata.default_message,
                request_id=req_id,
                metadata=metadata,
                **e.extra_args,  # Can pass through items like `headers`
            )


async def log_ctx_middleware(
    request: Request, call_next: Callable[[Request], Awaitable[Response]]
) -> Any:
    request.state.time_started = time.time()

    response = None

    req_id = from_log_ctx("req_id")
    if req_id:
        response = await _log_request(req_id, request, call_next)
    else:
        req_id = request.headers.get(REQ_ID_HEADER, "")
        if req_id == "":
            req_id = random_id(8)
        with log_ctx(req_id=req_id), pyroscope_tag_wrapper({"req_id": req_id}):
            add_global_trace_tag("req_id", req_id)
            response = await _log_request(req_id, request, call_next)

    response.headers[REQ_ID_HEADER] = req_id
    return response


async def snorkel_flow_api_exception_handler(
    request: Request, exc: Exception
) -> JSONResponse:
    status_code = exc.status_code if isinstance(exc, SnorkelFlowAPIException) else 500
    req_id = from_log_ctx("req_id")

    if not isinstance(exc, SnorkelFlowAPIException):
        new_exc = SnorkelFlowAPIException(
            status_code=status_code,
            detail=" ".join(str(arg) for arg in exc.args),
            user_friendly_message=DEFAULT_SERVER_ERROR_MESSAGE,
            request_id=req_id,
            metadata={"traceback": traceback.format_exc(limit=-5)},
        )
        new_exc.__cause__ = exc
        exc = new_exc

    current_time = time.time()
    emit_route_metrics(
        response_status_code=exc.status_code,
        tags={"path": request.url.path, "method": request.method},
        request_time_seconds=current_time
        - (request.state.time_started or current_time),
    )

    return exc.construct_json_response()


async def _log_request(
    req_id: str, request: Request, call_next: Callable[[Request], Awaitable[Response]]
) -> Response:
    request_info_format, request_info_args = get_log_request_info(request)

    try:
        access_logger.info(
            f"START_REQUEST {request_info_format}",
            *request_info_args.values(),
            extra=request_info_args,
        )
        response = await call_next(request)
    except SnorkelFlowAPIException as exc:
        access_logger.info(f"{repr(exc)}")
        response = await snorkel_flow_api_exception_handler(request, exc)
    except Exception as exc:
        # Not one of our defined SnorkelException classes, log the traceback.
        access_logger.exception(f"req_id:{req_id} {request.method} {request.url} 500")
        response = await snorkel_flow_api_exception_handler(request, exc)
    access_logger.info(
        f"END_REQUEST   {request_info_format} %d",
        *request_info_args.values(),
        response.status_code,
        extra={**request_info_args, "status_code": response.status_code},
    )
    return response
