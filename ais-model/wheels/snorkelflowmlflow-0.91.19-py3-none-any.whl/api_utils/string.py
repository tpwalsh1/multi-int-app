import os
import random
import string
from typing import Any, Iterator, Sequence, Union

from file_utils.core import open_file


def random_id(n_char: int) -> str:
    r = random.Random()
    return "".join(r.choices(string.ascii_letters + string.digits, k=n_char))


def seq_chunks(seq: Sequence[Any], chunk_size: int) -> Iterator[Any]:
    """Yield chunks from seq of size chunk_size, useful for streaming
    response buffers"""
    for i in range(0, len(seq), chunk_size):
        yield seq[i : i + chunk_size]


def chunked_file_read(
    path: Union[str, bytes, os.PathLike], chunk_size: int
) -> Iterator[Any]:
    """Read a file-like object in chunks"""
    with open_file(path) as f:  # type: ignore
        while True:
            data = f.read(chunk_size)
            if not data:
                break
            yield data


def formatted_like_email(possible_email: str) -> bool:
    return len(list(filter(None, possible_email.split("@")))) == 2
