from typing import Any, Callable, List, NamedTuple, Optional

from fastapi import APIRouter, FastAPI, Request
from starlette.routing import Match


class IncorrectDecoratorUsage(Exception):
    pass


class EndpointSpec(NamedTuple):
    # Websocket endpoints have no "method"
    method: Optional[str]
    path: str
    metadata: Optional[Any] = None


class EndpointRegistry:
    def __init__(self) -> None:
        self.endpoints: List[EndpointSpec] = []

    def add_endpoint(self, endpoint: EndpointSpec) -> None:
        self.endpoints.append(endpoint)

    def match_request_with_metadata(
        self, request: Request, metadata: Optional[Any] = None
    ) -> bool:
        """Match a given request against an existing endpoint registry, ensuring that the provided
        metadata matches what was registered."""
        for route in request.app.routes:
            methods = getattr(route, "methods", [None])
            for method in methods:
                if EndpointSpec(method, route.path, metadata) in self.endpoints:
                    match, _ = route.matches(request.scope)
                    if match == Match.FULL:
                        return True
        return False

    def match_request_without_metadata(self, request: Request) -> bool:
        """Match a given request against the endpoint registry, ignoring any metadata that
        is associated with the registered endpoints"""
        for route in request.app.routes:
            methods = getattr(route, "methods", [None])
            for method in methods:
                if any(
                    (method, route.path) == (es.method, es.path)
                    for es in self.endpoints
                ):
                    match, _ = route.matches(request.scope)
                    if match == Match.FULL:
                        return True
        return False


def decorator_add_endpoint_to_registry(
    router: APIRouter,
    registry: EndpointRegistry,
    metadata: Optional[Any] = None,
    logging_callback: Optional[Callable[[EndpointSpec], None]] = None,
) -> Callable:
    if not isinstance(router, (FastAPI, APIRouter)):
        raise IncorrectDecoratorUsage(
            f"decorator for ({router.__name__}) must be instantiated with router: @<decorator>(<router>)"
        )

    def decorated(f: Callable) -> Callable:
        """
        Decorator that places the (method, path) tuple in the provided registry
        Must be placed *before* the router method decorator for a route.
        """
        for route in router.routes:
            if route.name == f.__name__:
                for method in route.methods:
                    endpoint_spec = EndpointSpec(method, route.path, metadata=metadata)
                    if logging_callback:
                        logging_callback(endpoint_spec)
                    registry.add_endpoint(endpoint_spec)
                return f
        # Since there is no path/method corresponding to f.__name__ they must have
        # placed the decorators in the wrong order
        raise IncorrectDecoratorUsage(
            f"Decorated function {f.__name__} is not a registered route. "
            "Hint: decorator must be placed before router method like @router.get(...)."
        )

    return decorated
