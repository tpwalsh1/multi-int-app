import re
from typing import Any, Dict, NamedTuple, Optional

import requests
from influxdb_client import (
    Bucket,
    BucketRetentionRules,
    InfluxDBClient,
    Organization,
    SetupService,
)

from snorkelflow.utils.logging import get_logger
from snorkelflow.utils.statsd import stats

logger = get_logger("metrics")

_global_labels: Dict[str, str] = {}


def set_api_name(name: str) -> None:
    add_system_metric_tag("api_name", name)


def add_system_metric_tag(key: str, value: str) -> None:
    _global_labels[key] = value


def emit_route_metrics(
    *,
    response_status_code: int,
    tags: Dict[str, Any],
    request_time_seconds: float,  # a float representing fractional seconds can be achieved from time.time() - time.time()
) -> None:
    if "path" in tags:
        tags["path"] = remove_all_digit_path_segments(tags["path"])

    if "status_code" not in tags:
        tags["status_code"] = str(response_status_code)

    request_time_ms = round(request_time_seconds * 1000)

    tags.update(_global_labels)

    # default metrics for a route
    stats.counter_incr("api.requests_all", tags=tags)
    stats.timer_set("api.requests_latency", request_time_ms, tags=tags)

    code_family = response_status_code // 100

    stats.counter_incr(f"api.requests_{code_family}xx", tags=tags)


# whole route replacements
_jobs = re.compile(
    r"^/jobs/([\w\-_]+)(/.*)?"
)  # job UIDs look different from task UIDs, explicitly replace them

# path patterns
_all_digits = re.compile(r"^\d+$")
_uid = re.compile(r"^\w{8}-\w{4}-\w{4}-\w{4}-\w{12}$")


def remove_all_digit_path_segments(path: str) -> str:
    # Because we don't have the route name (there isn't one to find for a 404) we want to
    # include the request path (eg: /api/v5/users/123) in the metric labels. However
    # we also want to minimize the cardinality of metrics labels - we never want
    # them to be O(user data). As a poor-man's solution we'll replace any path segment
    # with all digits with 3 consecutive Ns (eg: /api/v5/users/NNN). Logs are a better
    # way to find specific entities that are causing issues.
    #
    # UIDS are also replaced with a UUUU-UUUU. This is only for well known formats of UIDs.

    path = _jobs.sub("/jobs/UUU\\2", path)
    segments = path.split("/")
    digit_free_segments = list(map(_replace_all_digits, segments))
    uid_free_segments = list(map(_replace_uid, digit_free_segments))
    return "/".join(uid_free_segments)


def _replace_all_digits(segment: str) -> str:
    if _all_digits.search(segment):
        return "NNN"
    else:
        return segment


def _replace_uid(segment: str) -> str:
    if _uid.search(segment):
        return "UUUU-UUUU"
    else:
        return segment


INFLUX_ORG_NAME = "snorkel"


class InfluxBucket(NamedTuple):
    name: str
    retentionPeriodSeconds: int
    description: str


LONGTERM_RETENTION_BUCKET = InfluxBucket(
    name="snorkel_longterm",
    retentionPeriodSeconds=60 * 60 * 24 * 30,
    description="""
Use longterm retention for events which contain lots of metadata and happen infrequently.
""",
)

DEFAULT_RETENTION_BUCKET = InfluxBucket(
    name="snorkel",
    retentionPeriodSeconds=60 * 60 * 24 * 7,
    description="""
Use default retention for events with a small number of extra metadata and which can expire after a week
""",
)

SHORTTERM_RETENTION_BUCKET = InfluxBucket(
    name="snorkel_shortterm",
    retentionPeriodSeconds=60 * 60 * 4,
    description="""
Use short retention for events that happen very frequently - order of 100x / second - and can be lost after 4 hours
""",
)

_influx_client: Optional[InfluxDBClient] = None


def influx_client() -> InfluxDBClient:
    if _influx_client is None:
        raise RuntimeError("Influx not initialized yet")
    return _influx_client


def influx_initialized() -> bool:
    return _influx_client is not None


def _init_influx_client(*, url: str, token: str, verify_ssl: bool) -> None:
    logger.info("initializing influx")
    global _influx_client
    _influx_client = InfluxDBClient(
        url=url, token=token, org=INFLUX_ORG_NAME, verify_ssl=verify_ssl
    )


def initialize_influx(*, url: str, token: str, verify_ssl: bool) -> InfluxDBClient:
    if _influx_client is None:
        _init_influx_client(url=url, token=token, verify_ssl=verify_ssl)

    setup_service = SetupService(api_client=influx_client().api_client)

    # "allowed" = there's no org or bucket yet, so set them up
    if setup_service.get_setup().allowed:
        logger.info(
            f"initial setup up for org {INFLUX_ORG_NAME} and bucket {DEFAULT_RETENTION_BUCKET.name}"
        )
        setup_args = {
            "username": token,
            "password": token,
            "org": INFLUX_ORG_NAME,
            "bucket": DEFAULT_RETENTION_BUCKET.name,
            "token": token,
            "retentionPeriodSeconds": DEFAULT_RETENTION_BUCKET.retentionPeriodSeconds,  # 7 day retention
        }
        response = requests.post(f"{url}/api/v2/setup", json=setup_args)
        # Can encounter race conditions while configuring InfluxDB
        if (
            response.status_code != 201
            and "onboarding has already been completed" not in response.text
        ):
            raise RuntimeError(f"Unable to configure InfluxDB: {response.text}")

    # initialize other buckets if needed
    init_influx_bucket(LONGTERM_RETENTION_BUCKET)
    init_influx_bucket(SHORTTERM_RETENTION_BUCKET)

    return _influx_client


def _influx_org() -> Organization:
    orgs = influx_client().organizations_api().find_organizations()
    for org in orgs:
        if org.name == INFLUX_ORG_NAME:
            return org


def init_influx_bucket(bucket: InfluxBucket) -> Bucket:
    result = influx_client().buckets_api().find_bucket_by_name(bucket_name=bucket.name)
    if result is not None:
        return result

    org = _influx_org()

    logger.info(f"creating bucket {bucket.name}")

    bucket_to_make = Bucket(
        name=bucket.name,
        retention_rules=[
            BucketRetentionRules(every_seconds=bucket.retentionPeriodSeconds)
        ],
        org_id=org.id,
        description=bucket.description,
    )

    return influx_client().buckets_api().create_bucket(bucket_to_make)
