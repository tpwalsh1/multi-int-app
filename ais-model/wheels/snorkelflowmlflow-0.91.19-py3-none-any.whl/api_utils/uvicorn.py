# The default server keep-alive is generally 2-5 seconds.
# Our ALBs have keep-alive interval of 600s, and FlowUI
# has a keep-alive interval of 75s.
# Default to 610s so that we are compatible with the ALB keep-alive
KEEP_ALIVE_TIMEOUT = 610
