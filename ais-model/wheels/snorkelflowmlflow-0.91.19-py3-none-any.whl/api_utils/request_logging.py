from typing import Any, OrderedDict, Tuple

from fastapi import Request
from uvicorn.protocols.utils import get_path_with_query_string


def get_log_request_info(request: Request) -> Tuple[str, OrderedDict[str, Any]]:
    request_info_format = '%s - "%s %s HTTP/%s"'

    client_addr_parts = request.scope.get("client")
    client_addr = (
        f"{client_addr_parts[0]}:{client_addr_parts[1]}" if client_addr_parts else ""
    )
    # Can remove ordereddict in 3.7, when iteration order is guaranteed
    request_info_args = OrderedDict(
        [
            ("client_addr", client_addr),
            ("method", request.scope["method"]),
            ("path", get_path_with_query_string(request.scope)),
            ("http_version", request.scope["http_version"]),
        ]
    )
    return request_info_format, request_info_args
