import asyncio


# As discovered in https://github.com/snorkel-ai/strap/pull/19102, some global scope
# Dask code was unexpectedly modifying the event loop policy in our API servers.
# Some things just worked that likely shouldn't have. To minimize risk while upgrading
# the Bazel build chain, we'll replicate this modification in a more predictable way.
# We should remove this and use the default uvloop.EventLoopPolicy once it's confirmed
# safe to do so.
class AnyThreadEventLoopPolicy(asyncio.DefaultEventLoopPolicy):  # type: ignore
    def get_event_loop(self) -> asyncio.AbstractEventLoop:
        try:
            return super().get_event_loop()
        except (RuntimeError, AssertionError):
            loop = self.new_event_loop()
            self.set_event_loop(loop)
            return loop


def set_any_thread_event_loop_policy() -> None:
    asyncio.set_event_loop_policy(AnyThreadEventLoopPolicy())
