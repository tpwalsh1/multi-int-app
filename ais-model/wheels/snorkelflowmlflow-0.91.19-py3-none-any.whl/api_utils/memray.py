import os
import shutil
from contextlib import contextmanager
from contextvars import ContextVar
from pathlib import Path
from typing import Any

from memray import FileDestination, Tracker
from memray.commands.flamegraph import FlamegraphCommand

from snorkelflow.utils.file import resolve_data_path

memray_dir: Any = ContextVar("memray_dir", default="")


@contextmanager
def memray_tracker(dirname: str, suffix: str = "", refresh_dir: bool = False) -> Any:
    if dirname == "":
        # If dirname is "", this is a no-op:
        yield
    else:
        base_dir = os.path.join(resolve_data_path("minio://memray_profiles"), dirname)
        if refresh_dir:
            shutil.rmtree(base_dir, ignore_errors=True)
            os.makedirs(base_dir)
        dump = os.path.join(base_dir, f"dump{suffix}")
        tracker = Tracker(destination=FileDestination(dump), follow_fork=True)
        try:
            with tracker:
                yield
        finally:
            flamegraph_file = os.path.join(base_dir, f"flamegraph{suffix}.html")
            fc = FlamegraphCommand()
            fc.write_report(
                Path(dump),
                Path(flamegraph_file),
                False,
                temporary_allocation_threshold=0,
                merge_threads=True,
            )
