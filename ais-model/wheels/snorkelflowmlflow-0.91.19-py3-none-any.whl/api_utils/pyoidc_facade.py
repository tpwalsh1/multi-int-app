# Adapted from https://github.com/zamzterz/Flask-pyoidc/blob/master/src/flask_pyoidc/pyoidc_facade.py
# but with better types
#
import base64
import collections
import json
import logging
from typing import Any, Dict, Iterator, List, Optional, Union

import requests
from oic.oauth2.message import ASConfigurationResponse
from oic.oic import (
    AccessTokenResponse,
    AuthorizationErrorResponse,
    AuthorizationResponse,
    Client,
    RegistrationResponse,
    TokenErrorResponse,
)
from oic.oic.message import AuthorizationRequest
from oic.utils.authn.client import CLIENT_AUTHN_METHOD

logger = logging.getLogger(__name__)


class OIDCData(collections.MutableMapping):
    """
    Basic OIDC data representation providing validation of required fields.
    """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        """
        Args:
            args (List[Tuple[String, String]]): key-value pairs to store
            kwargs (Dict[string, string]): key-value pairs to store
        """
        self.store: Dict[str, Union[str, List[str]]] = dict()
        self.update(dict(*args, **kwargs))

    def __getitem__(self, key: str) -> Union[str, List[str]]:
        return self.store[key]

    def __setitem__(self, key: str, value: Union[str, List[str]]) -> None:
        self.store[key] = value

    def __delitem__(self, key: str) -> None:
        del self.store[key]

    def __iter__(self) -> Iterator:
        return iter(self.store)

    def __len__(self) -> int:
        return len(self.store)

    def __str__(self) -> str:
        data = self.store.copy()
        if "client_secret" in data:
            data["client_secret"] = "<masked>"  # noqa: S105
        return str(data)

    def __repr__(self) -> str:
        return str(self.store)

    def __bool__(self) -> bool:
        return True

    def copy(self, **kwargs: Any) -> "OIDCData":
        values = self.to_dict()
        values.update(kwargs)
        return self.__class__(**values)

    def to_dict(self) -> Dict[str, Union[str, List[str]]]:
        return self.store.copy()


class ProviderMetadata(OIDCData):
    def __init__(
        self,
        issuer: Optional[str] = None,
        authorization_endpoint: Optional[str] = None,
        jwks_uri: Optional[str] = None,
        **kwargs: Dict,
    ) -> None:
        """
        Args:
            issuer (str): OP Issuer Identifier.
            authorization_endpoint (str): URL of the OP's Authorization Endpoint
            jwks_uri (str): URL of the OP's JSON Web Key Set
            kwargs (dict): key-value pairs corresponding to
                `OpenID Provider Metadata`_

        .. _OpenID Provider Metadata:
            https://openid.net/specs/openid-connect-discovery-1_0.html#ProviderMetadata
        """
        super(ProviderMetadata, self).__init__(
            issuer=issuer,
            authorization_endpoint=authorization_endpoint,
            jwks_uri=jwks_uri,
            **kwargs,
        )


class ClientRegistrationInfo(OIDCData):
    pass


class ClientMetadata(OIDCData):
    def __init__(
        self,
        client_id: Optional[str] = None,
        client_secret: Optional[str] = None,
        redirect_uris: Optional[List[str]] = None,
        **kwargs: Dict,
    ) -> None:
        """
        Args:
            client_id (str): client identifier representing the client
            client_secret (str): client secret to authenticate the client with
                the OP
            kwargs (dict): key-value pairs
        """
        super(ClientMetadata, self).__init__(
            client_id=client_id, client_secret=client_secret, **kwargs
        )


class ProviderConfiguration:
    """
    Metadata for communicating with an OpenID Connect Provider (OP).

    Attributes:
        auth_request_params (dict): Extra parameters, as key-value pairs, to include in the query parameters
            of the authentication request
        registered_client_metadata (ClientMetadata): The client metadata registered with the provider.
        requests_session (requests.Session): Requests object to use when communicating with the provider.
        session_refresh_interval_seconds (int): Number of seconds between updates of user data (tokens, user data, etc.)
            fetched from the provider. If `None` is specified, no silent updates should be made user data will be made.
        userinfo_endpoint_method (str): HTTP method ("GET" or "POST") to use when making the UserInfo Request. If
            `None` is specifed, no UserInfo Request will be made.
    """

    DEFAULT_REQUEST_TIMEOUT = 5

    def __init__(
        self,
        *,
        issuer: Optional[str] = None,
        provider_metadata: Dict[str, Union[str, List[str]]],
        userinfo_http_method: str = "GET",
        client_registration_info: Optional[ClientRegistrationInfo] = None,
        client_metadata: Optional[ClientMetadata] = None,
        auth_request_params: Optional[Dict[str, str]] = None,
        session_refresh_interval_seconds: Optional[int] = None,
        requests_session: Optional[requests.Session] = None,
    ) -> None:
        """
        Args:
            issuer (str): OP Issuer Identifier. If this is specified discovery will be used to fetch the provider
                metadata, otherwise `provider_metadata` must be specified.
            provider_metadata (ProviderMetadata): OP metadata,
            userinfo_http_method (Optional[str]): HTTP method (GET or POST) to use when sending the UserInfo Request.
                If `none` is specified, no userinfo request will be sent.
            client_registration_info (ClientRegistrationInfo): Client metadata to register your app
                dynamically with the provider. Either this or `registered_client_metadata` must be specified.
            client_metadata (ClientMetadata): Client metadata if your app is statically
                registered with the provider. Either this or `client_registration_info` must be specified.
            auth_request_params (dict): Extra parameters that should be included in the authentication request.
            session_refresh_interval_seconds (int): Length of interval (in seconds) between attempted user data
                refreshes.
            requests_session (requests.Session): custom requests object to allow for example retry handling, etc.
        """

        if auth_request_params is None:
            auth_request_params = {}

        if not issuer and not provider_metadata:
            raise ValueError("Specify either 'issuer' or 'provider_metadata'.")

        if not client_registration_info and not client_metadata:
            raise ValueError(
                "Specify either 'client_registration_info' or 'client_metadata'."
            )

        self._issuer = issuer
        self._provider_metadata = provider_metadata

        self._client_registration_info = client_registration_info
        self._client_metadata = client_metadata

        self.userinfo_endpoint_method = userinfo_http_method
        self.auth_request_params = auth_request_params or {}
        self.session_refresh_interval_seconds = session_refresh_interval_seconds

        self.requests_session = requests_session or requests.Session()

    def ensure_provider_metadata(self) -> Dict[str, Union[str, List[str]]]:
        if not self._provider_metadata:
            resp = self.requests_session.get(
                (self._issuer or "") + "/.well-known/openid-configuration",
                timeout=self.DEFAULT_REQUEST_TIMEOUT,
            )
            logger.debug("Received discovery response: " + resp.text)

            self._provider_metadata = ProviderMetadata(**resp.json()).to_dict()

        return self._provider_metadata

    @property
    def registered_client_metadata(self) -> Optional[ClientMetadata]:
        return self._client_metadata

    def register_client(
        self, redirect_uris: List[str], extra_parameters: Optional[Dict] = None
    ) -> ClientMetadata:
        if not self._client_metadata:
            if "registration_endpoint" not in self._provider_metadata:
                raise ValueError(
                    "Can't use dynamic client registration, provider metadata is missing "
                    "'registration_endpoint'."
                )
            if self._client_registration_info:
                registration_request = self._client_registration_info.to_dict()
            registration_request["redirect_uris"] = redirect_uris
            if extra_parameters:
                registration_request.update(extra_parameters)

            resp = self.requests_session.post(
                str(self._provider_metadata["registration_endpoint"]),
                json=registration_request,
                timeout=self.DEFAULT_REQUEST_TIMEOUT,
            )
            self._client_metadata = ClientMetadata(
                redirect_uris=redirect_uris, **resp.json()
            )
            logger.debug(
                "Received registration response: client_id="
                + str(self._client_metadata["client_id"])
            )

        return self._client_metadata


class PyoidcFacade:
    """
    Wrapper around pyoidc library, coupled with config for a simplified API for flask-pyoidc.
    """

    def __init__(
        self, provider_configuration: ProviderConfiguration, redirect_uri: str
    ) -> None:
        """
        Args:
            provider_configuration (flask_pyoidc.provider_configuration.ProviderConfiguration)
        """
        self._provider_configuration = provider_configuration
        self._client = Client(client_authn_method=CLIENT_AUTHN_METHOD)

        provider_metadata = provider_configuration.ensure_provider_metadata()
        self._client.handle_provider_config(
            ASConfigurationResponse(**provider_metadata),
            str(provider_metadata["issuer"]),
        )

        if self._provider_configuration.registered_client_metadata:
            client_metadata = (
                self._provider_configuration.registered_client_metadata.to_dict()
            )
            registration_response = RegistrationResponse(**client_metadata)
            self._client.store_registration_info(registration_response)

        self._redirect_uri = redirect_uri

    def is_registered(self) -> bool:
        return bool(self._provider_configuration.registered_client_metadata)

    def register(self, extra_registration_params: Optional[Dict] = None) -> None:
        client_metadata = self._provider_configuration.register_client(
            [self._redirect_uri], extra_registration_params
        )
        logger.debug("client registration response: %s", client_metadata)
        self._client.store_registration_info(
            RegistrationResponse(**client_metadata.to_dict())
        )

    def authentication_request(
        self, state: str, nonce: str, extra_auth_params: Dict[str, str]
    ) -> AuthorizationRequest:
        """

        Args:
            state (str): authentication request parameter 'state'
            nonce (str): authentication request parameter 'nonce'
            extra_auth_params (Mapping[str, str]): extra authentication request parameters
        Returns:
            AuthorizationRequest: the authentication request
        """
        args = {
            "client_id": self._client.client_id,
            "response_type": "code",
            "scope": ["openid"],
            "redirect_uri": self._redirect_uri,
            "state": state,
            "nonce": nonce,
        }

        args.update(self._provider_configuration.auth_request_params)
        args.update(extra_auth_params)
        auth_request = self._client.construct_AuthorizationRequest(request_args=args)
        logger.debug("sending authentication request: %s", auth_request.to_json())

        return auth_request

    def login_url(self, auth_request: AuthorizationRequest) -> str:
        """
        Args:
            auth_request (AuthorizationRequest): authentication request
        Returns:
            str: Authentication request as a URL to redirect the user to the provider.
        """
        return auth_request.request(self._client.authorization_endpoint)

    def parse_authentication_response(
        self, response_params: Dict[str, str]
    ) -> Union[AuthorizationResponse, AuthorizationErrorResponse]:
        """
        Args:
            response_params (Mapping[str, str]): authentication response parameters
        Returns:
            Union[AuthorizationResponse, AuthorizationErrorResponse]: The parsed authorization response
        """
        auth_resp = self._parse_response(
            response_params, AuthorizationResponse, AuthorizationErrorResponse
        )
        if "id_token" in response_params:
            auth_resp["id_token_jwt"] = response_params["id_token"]
        return auth_resp

    def exchange_authorization_code(
        self, authorization_code: str
    ) -> Union[AccessTokenResponse, TokenErrorResponse, None]:
        """
        Requests tokens from an authorization code.

        Args:
            authorization_code (str): authorization code issued to client after user authorization

        Returns:
            Union[AccessTokenResponse, TokenErrorResponse, None]: The parsed token response, or None if no token
            request was performed.
        """
        request = {
            "grant_type": "authorization_code",
            "code": authorization_code,
            "redirect_uri": self._redirect_uri,
        }

        return self._token_request(request)

    def verify_id_token(
        self, id_token: Dict[str, str], auth_request: Dict[str, str]
    ) -> None:
        """
        Verifies the ID Token.

        Args:
            id_token (Mapping[str, str]): ID token claims
            auth_request (Mapping[str, str]): original authentication request parameters to validate against
                (nonce, acr_values, max_age, etc.)

        Raises:
            PyoidcError: If the ID token is invalid.

        """
        self._client.verify_id_token(id_token, auth_request)

    def refresh_token(
        self, refresh_token: str
    ) -> Union[AccessTokenResponse, TokenErrorResponse, None]:
        """
        Requests new tokens using a refresh token.

        Args:
            refresh_token (str): refresh token issued to client after user authorization

        Returns:
            Union[AccessTokenResponse, TokenErrorResponse, None]: The parsed token response, or None if no token
            request was performed.
        """
        request = {
            "grant_type": "refresh_token",
            "refresh_token": refresh_token,
            "redirect_uri": self._redirect_uri,
        }

        return self._token_request(request)

    def _client_authentication(
        self,
        *,
        client_id: str,
        client_secret: str,
        method: str,
        request: Dict[str, Any],
    ) -> Dict[str, Any]:
        """
        Args:
            method (str): Client Authentication Method. Only 'client_secret_basic' and 'client_secret_post' is
                supported.
            request (MutableMapping[str, str]): Token request parameters. This may be modified, i.e. if
                'client_secret_post' is used the client credentials will be added.

        Returns:
            (Mapping[str, str]): HTTP headers to be included in the token request, or `None` if no extra HTTPS headers
            are required for the token request.
        """
        if method == "client_secret_post":
            request["client_id"] = client_id
            request["client_secret"] = client_secret
            return (
                {}
            )  # authentication is in the request body, so no Authorization header is returned

        # default to 'client_secret_basic'
        credentials = "{}:{}".format(self._client.client_id, self._client.client_secret)
        basic_auth = "Basic {}".format(
            base64.urlsafe_b64encode(credentials.encode("utf-8")).decode("utf-8")
        )
        return {"Authorization": basic_auth}

    def _token_request(
        self, request: Dict[str, Any]
    ) -> Union[AccessTokenResponse, TokenErrorResponse, None]:
        """
        Makes a token request.  If the 'token_endpoint' is not configured in the provider metadata, no request will
        be made.

        Args:
            request (Mapping[str, str]): token request parameters

        Returns:
            Union[AccessTokenResponse, TokenErrorResponse, None]: The parsed token response, or None if no token
            request was performed.
        """

        if not self._client.token_endpoint:
            return None

        logger.debug("making token request: %s", request)
        client_auth_method = self._client.registration_response.get(
            "token_endpoint_auth_method", "client_secret_basic"
        )
        auth_header = self._client_authentication(
            client_id=self._client.client_id,
            client_secret=self._client.client_secret,
            request=request,
            method=client_auth_method,
        )

        resp = self._provider_configuration.requests_session.post(
            self._client.token_endpoint, data=request, headers=auth_header
        ).json()
        logger.debug("received token response: %s", json.dumps(resp))

        token_resp = self._parse_response(resp, AccessTokenResponse, TokenErrorResponse)
        if "id_token" in resp:
            token_resp["id_token_jwt"] = resp["id_token"]

        return token_resp

    @property
    def session_refresh_interval_seconds(self) -> Optional[int]:
        return self._provider_configuration.session_refresh_interval_seconds

    @property
    def provider_end_session_endpoint(self) -> Optional[Union[str, List[str]]]:
        provider_metadata = self._provider_configuration.ensure_provider_metadata()
        return provider_metadata.get("end_session_endpoint")

    @property
    def post_logout_redirect_uris(self) -> Any:
        return self._client.registration_response.get("post_logout_redirect_uris")

    def _parse_response(
        self,
        response_params: Dict[str, str],
        success_response_cls: Any,
        error_response_cls: Any,
    ) -> Any:
        if "error" in response_params:
            response = error_response_cls(**response_params)
        else:
            response = success_response_cls(**response_params)
            response.verify(keyjar=self._client.keyjar)
        return response
