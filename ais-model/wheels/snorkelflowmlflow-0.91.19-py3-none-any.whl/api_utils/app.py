import importlib
import pkgutil
from types import ModuleType
from typing import Optional

from fastapi import FastAPI

from snorkelflow.utils.logging import get_logger

logger = get_logger("api_utils")


def install_routers(app: FastAPI, router_parent_module: ModuleType) -> None:
    """Install all routers within a particular parent module

    This lets us install a custom set of routers in tests by including only the bazel
    modules we need
    """
    # Add routers to app
    # TODO: add v1 prefix to routers/app
    for router_module_info in pkgutil.iter_modules(router_parent_module.__path__):
        router_name = router_module_info.name
        full_path = f"{router_parent_module.__package__}.{router_name}"
        router_module = importlib.import_module(full_path)

        install_router(app, router_module, router_name=router_name)


def install_router(
    app: FastAPI, router_module: ModuleType, router_name: Optional[str] = None
) -> None:
    """
    Install FastAPI routes from a module

    router_name - an override for the name of the router. By default, we use the module name's
    second-to-last component of the module path (e.g. "logs" for "some.prefix.logs.routes")
    """
    full_path = router_module.__name__
    if router_name is None:
        router_name = full_path.rsplit(".")[-2]

    try:
        router = getattr(router_module, "router")
    except AttributeError:
        logger.warning(f"Warning: module {full_path} does not have a router")
        return

    app.include_router(router, tags=[router_name])  # type: ignore
