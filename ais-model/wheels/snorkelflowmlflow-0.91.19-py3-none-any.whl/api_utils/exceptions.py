from typing import Any, Dict, Optional, Type

from starlette.responses import JSONResponse

from api_utils.constants import REQ_ID_HEADER


# SnorkelFlowAPIException represents an exception specific to an HTTP error status code.
# When raised from a FastAPI service these are translated by the middleware to an
# HTTP response with the given status code and JSON-API-compatible error information
# and headers.
class SnorkelFlowAPIException(Exception):
    def __init__(
        self,
        status_code: int,
        detail: str,
        request_id: Optional[str] = None,
        user_friendly_message: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
        headers: Optional[Dict[str, str]] = None,
    ) -> None:
        super().__init__(detail)
        self.__suppress_context__ = True
        self.status_code = status_code
        self.detail = detail
        self.request_id = request_id
        self.user_friendly_message = user_friendly_message
        self.metadata = metadata
        self.headers = headers
        # This is required for unpickling to work without errors
        # See https://stackoverflow.com/questions/41808912/cannot-unpickle-exception-subclass
        self.args = (
            status_code,
            detail,
            request_id,
            user_friendly_message,
            metadata,
            headers,
        )

    def construct_json_response(self, headers: Optional[Dict] = None) -> JSONResponse:
        headers = self.headers if self.headers else {}
        if self.request_id:
            headers[REQ_ID_HEADER] = self.request_id
        return JSONResponse(
            status_code=self.status_code,
            headers=headers,
            content=dict(
                detail=self.detail,
                user_friendly_message=self.user_friendly_message,
                request_id=self.request_id,
                metadata=self.metadata,
            ),
        )

    def __repr__(self) -> str:
        return f'SnorkelFlowAPIException(status_code={self.status_code}, detail="{self.detail}")'


# SnorkelException is the base class for any exceptions that can be raised within the SnorkelFlow
# service context. Exceptions in this hierarchy are not HTTP-specific (i.e. they do not reference
# or correspond one-to-one with HTTP status codes). These are meant to be valid even in non-HTTP
# contexts, such as in async job-queues or SDK methods. When these exceptions make their way out
# to our FastAPI middleware they are translated to SnorkelFlowAPIExceptions (and, hence, valid HTTP
# error responses). This allows one to raise a NotFoundError from an ORM in data-models/*.py and have
# this turned into a 404 response without needing to encode a 404 status code from the ORM.
class SnorkelException(Exception):
    def __init_subclass__(cls, **kwargs: Any) -> None:
        """Define init subclass to register all subclasses in SNORKEL_EXCEPTIONS_MAPPING."""
        super(cls).__init_subclass__(**kwargs)  # type: ignore
        SNORKEL_EXCEPTIONS_MAPPING[cls.__name__] = cls

    def __init__(
        self,
        detail: str,
        user_friendly_message: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
        **extra_args: Any,
    ) -> None:
        """
        The `detail`, `user_friendly_message`, and `metadata` fields are passed directly through to the
        SnorkelFlowAPIException during translation in the middleware. `extra_args` is used to hold
        things like `headers` and other values that can be used by the SnorkelFlowAPIException class
        but don't make sense to explicitly define for exceptions in this hierarchy.
        """
        super().__init__(detail)
        self.detail = detail
        self.user_friendly_message = user_friendly_message
        self.metadata = metadata
        if not extra_args:
            extra_args = {}
        self.extra_args = extra_args
        # This is required for unpickling to work without errors
        # See https://stackoverflow.com/questions/41808912/cannot-unpickle-exception-subclass
        self.args = (detail,)

    def __repr__(self) -> str:
        return f'{self.__class__.__name__}(detail="{self.detail}")'


SNORKEL_EXCEPTIONS_MAPPING: Dict[str, Type[SnorkelException]] = {
    SnorkelException.__name__: SnorkelException
}


def get_snorkel_exception(exc_name: str) -> Optional[Type[SnorkelException]]:
    return SNORKEL_EXCEPTIONS_MAPPING.get(exc_name)


# TODO - It would be helpful to add small descriptions to these, explaining in what context it makes
# sense for each of these to be used
class NotFoundError(SnorkelException):
    pass


class AuthenticationError(SnorkelException):
    pass


class AuthorizationError(SnorkelException):
    pass


class ResourceGoneError(SnorkelException):
    """This exception is to represent the HTTP status code 410 which indicates that access to the target resource is no longer available and will not be available in the future.
    This exception should be used if the service knows a resource has been deleted and can no longer be served to the client.
    """

    pass


class UserInputError(SnorkelException):
    def __init__(
        self,
        detail: str,
        user_friendly_message: str,
        how_to_fix: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
        **extra_args: Any,
    ) -> None:
        if how_to_fix:
            user_friendly_message = user_friendly_message.rstrip(".")
            user_friendly_message = f"{user_friendly_message}. {how_to_fix}"
            detail = detail.rstrip(".")
            detail = f"{detail}. {how_to_fix}"
        super().__init__(detail, user_friendly_message, metadata, **extra_args)
        # This is required for unpickling to work without errors
        # See https://stackoverflow.com/questions/41808912/cannot-unpickle-exception-subclass
        self.args = (detail, user_friendly_message)

    def __repr__(self) -> str:
        return f'{self.__class__.__name__}(detail="{self.detail}", user_friendly_message="{self.user_friendly_message}")'


class DuplicateValueError(UserInputError):
    pass


class UnsupportedModelError(UserInputError):
    pass


class UnprocessableEntityError(SnorkelException):
    pass


class ServerError(SnorkelException):
    pass


class NotLicensedError(AuthorizationError):
    pass


class OutOfConnectionsError(SnorkelException):
    pass


class NotSupportedException(SnorkelException, NotImplementedError):
    pass


class LFApplyError(UserInputError):
    pass


class OperatorExecutionError(SnorkelException):
    pass


class FailedJobError(ServerError):
    pass


class RequestTimeout(SnorkelException):
    pass


class RequestConflictError(SnorkelException):
    pass


class AppSetupError(SnorkelException):
    """Returned when the setup app can't be used"""

    pass


class ModelNodeNotSetup(AppSetupError):
    """Returned when the model node is not setup"""

    pass
