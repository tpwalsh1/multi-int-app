from contextvars import ContextVar, Token
from typing import Optional

from pydantic import BaseModel

from snorkelflow.utils.logging import get_logger

logger = get_logger("APIMIDDLEWARE")

REQUEST_ID_CTX_KEY = "request_context"


# A RequestContext used between calls of different services, to keep track of
# shared data, such as JWTs, and the user who made the request.
class RequestContext(BaseModel):
    authorization_header: str
    user_uid: Optional[int]


# Creates a context variable used to keep track of our request context object
# See: https://docs.python.org/3.7/library/contextvars.html for more details


_request_id_ctx_var: ContextVar[Optional[RequestContext]] = ContextVar(
    REQUEST_ID_CTX_KEY, default=None
)


# Function used to retrive our context later on
def get_request_context() -> Optional[RequestContext]:
    return _request_id_ctx_var.get()


def set_request_context(context: Optional[RequestContext]) -> Token:
    return _request_id_ctx_var.set(context)
