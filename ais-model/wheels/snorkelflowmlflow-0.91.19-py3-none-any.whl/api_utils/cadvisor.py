import os
import subprocess

from concurrency_utils.threading import PeriodicTimer
from snorkelflow.utils.logging import get_logger

logger = get_logger("cadvisor")


def maybe_fork_cadvisor() -> None:
    cadvisor_url = os.environ.get("TELEGRAF_CADVISOR_URL", None)
    if cadvisor_url:
        CAdvisorDaemon(cadvisor_url).__enter__()


class CAdvisorDaemon(PeriodicTimer):
    def __init__(self, cadvisor_url: str):
        super().__init__(interval=1, daemon=True, ignore_errors=True)
        self.cadvisor_url = cadvisor_url

    def _run(self) -> None:
        logger.info("Starting cadvisor")
        subprocess.check_call(
            [
                "cadvisor",
                "--port",
                "8090",
                "-storage_driver=influxdb",
                f"-storage_driver_host={self.cadvisor_url}",
            ]
        )
