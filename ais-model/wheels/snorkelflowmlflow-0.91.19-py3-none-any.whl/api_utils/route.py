import asyncio
import gzip
import json
import os
import threading
import time
from contextlib import nullcontext
from functools import wraps
from typing import Any, Callable

from fastapi import Response as FastAPIResponse
from fastapi.routing import APIRoute
from starlette.requests import Request
from starlette.responses import Response

from api_utils.memray import memray_dir, memray_tracker
from api_utils.metrics import emit_route_metrics
from snorkelflow.utils.statsd import stats

try:
    from services.observability.trace import set_active_thread_id
except ImportError:
    set_active_thread_id = nullcontext  # type: ignore


MIN_SIZE_FOR_COMPRESSION = 100_000
COUNTER_LOCK = threading.Lock()


# Mandatory decorator for routes that do not return any content.
# FastAPI's JSONResponse has a bug when used in a function
# that returns HTTP 204. The content-length is set to a non-zero value
# because it marshals whatever the route function returns to JSON,
# including the value None ("null"). This breaks downstream services that
# think there is more content coming, like Envoy.
#
# https://github.com/tiangolo/fastapi/issues/717#issuecomment-693400670
#
# Once this bug is resolved we can stop requiring this on 204 routes.
def no_content(fn: Callable) -> Callable:
    @wraps(fn)
    def _ret(*args, **kwargs) -> FastAPIResponse:  # type: ignore
        fn(*args, **kwargs)
        r = FastAPIResponse()
        r.status_code = 204
        return r

    _ret.__no_content__ = True  # type: ignore

    return _ret


def allow_list_query_params(fn: Callable) -> Callable:
    """
    GET Routes that wish to allow query arguments with List types
    must use this decorator as a "waiver" that they acknowledge the
    risks associated with this design, specifically, that a caller could
    pass too-long of a query string and cause a backend/routing error. If
    a route is defined that accepts List query params without using this
    decorator a unit test fill fail with an appropriate error message.

    When is it okay to use this? When you can safely assume
    that the caller will only ever send a few values.
    Example: when accepting "splits" on an endpoint. There will only ever
    be a few splits, and even if we add more, we will never have 1,000 of them.
    """
    fn.__allow_list_args__ = True  # type: ignore
    return fn


class MiddlewareHTTPError(FastAPIResponse):
    """Assemble a FastAPI Response object with an HTTPException-like
    structure by providing an error message and status code"""

    def __init__(self, *, status_code: int, message: str = ""):
        content = json.dumps(dict(detail=message))
        FastAPIResponse.__init__(self, content=content, status_code=status_code)


# Handle GZIP decompression in requests
# https://fastapi.tiangolo.com/advanced/custom-request-and-route/
class GzipRequest(Request):
    async def body(self) -> bytes:
        if not hasattr(self, "_body"):
            body = await super().body()
            if "gzip" in self.headers.getlist("Content-Encoding"):
                body = gzip.decompress(body)
            self._body = body
        return self._body


class _GzipRoute(APIRoute):
    def get_route_handler(self) -> Callable:
        original_route_handler = super().get_route_handler()

        async def custom_route_handler(request: Request) -> Response:
            request = GzipRequest(request.scope, request.receive)
            return await original_route_handler(request)

        return custom_route_handler


class _MetricRoute(_GzipRoute):
    # We use a custom route type instead of middleware for metrics
    # because fastapi/starlette do not expose the matched route_name
    # to middleware, only the final path.
    def get_route_handler(self) -> Callable:
        original_route_handler = super().get_route_handler()
        route_name = self.name

        async def custom_route_handler(request: Request) -> Response:
            request.state.route_name = route_name
            tags = {
                "route": route_name,
                "method": request.method,
                "path": request.url.path,
            }
            start = time.time()
            response = await original_route_handler(request)
            time_taken = time.time() - start

            emit_route_metrics(
                response_status_code=response.status_code,
                tags=tags,
                request_time_seconds=time_taken,
            )

            return response

        return custom_route_handler


def _endpoint_memray_wrapper(fn: Callable) -> Callable:
    """Decorator to memray profiling of functions."""

    # No-op for async functions
    if asyncio.iscoroutinefunction(fn):
        return fn
    # Set attribute to make decorator idempotent, since it gets called twice in
    # our code. Once in the router.get decorator, and once via install_routers.
    if getattr(fn, "__endpoint_memray_wrapper_set", False):
        return fn

    start_counter = 0
    finish_counter = 0

    @wraps(fn)
    def wrapper(*args: Any, **kwargs: Any) -> FastAPIResponse:  # type: ignore
        nonlocal start_counter, finish_counter
        pid = os.getpid()
        tags = {"pid": pid}
        with memray_tracker(memray_dir.get(), refresh_dir=True), set_active_thread_id():
            with COUNTER_LOCK:
                start_counter += 1
                stats.gauge_set(
                    "request_started",
                    start_counter,
                    tags=tags,
                    include_hostname_tag=True,
                )
            try:
                return fn(*args, **kwargs)
            finally:
                with COUNTER_LOCK:
                    finish_counter += 1
                    stats.gauge_set(
                        "request_finished",
                        finish_counter,
                        tags=tags,
                        include_hostname_tag=True,
                    )

    setattr(wrapper, "__endpoint_memray_wrapper_set", True)
    return wrapper


class _ProfilableRoute(_MetricRoute):
    def __init__(self, path: str, endpoint: Callable, **kwargs: Any):
        super().__init__(path, _endpoint_memray_wrapper(endpoint), **kwargs)


SnorkelApiRoute = _ProfilableRoute
