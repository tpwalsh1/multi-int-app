from contextlib import contextmanager
from time import sleep
from typing import Generator

# Very simple sleep-based rate limiter for now, introduce
# something fancy later if product goes multi-tenant.


@contextmanager
def sleep_limit() -> Generator:
    sleep(0.1)
    yield


@contextmanager
def no_limit() -> Generator:
    yield


limit = sleep_limit
