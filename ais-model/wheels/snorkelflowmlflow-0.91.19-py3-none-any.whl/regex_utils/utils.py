import regex


# re2 does not support fuzzy searching so we'll always use regex in this case
def is_fuzzy_pattern(s: str) -> bool:
    return regex.search(r"\{(i|d|s|e).*\}", s) is not None


# re2 is slower when special sequences dominate the pattern. This could probably be improved a lot.
def is_special_sequence_pattern(s: str) -> bool:
    special_sequence_count = len(
        regex.findall(r"\\(w|d|s|b|\.)", s, flags=regex.IGNORECASE)
    )
    character_count = len(regex.findall(r"[a-z0-9]", s, flags=regex.IGNORECASE))
    token_count = len(regex.findall(r"[a-z0-9]{2,}", s, flags=regex.IGNORECASE))

    return token_count < 2 and (
        character_count == 0
        or ((special_sequence_count > 0) and (len(s) <= 8))
        or ((special_sequence_count / character_count) >= 0.5)
    )


# Addresses bug in re2 that returns None when lower bound is not specified in repetition qualifier
def correct_lower_bound(s: str) -> str:
    return regex.sub(r"\{,(\d+)\}", r"{0,\1}", s)


# Removes redundant grouping
def remove_extra_groupings(s: str) -> str:
    return regex.sub(r"[(]{2}(.*)[)]{2}", r"(\1)", s)


def has_non_latin_characters(s: str) -> bool:
    return not s.isascii()
