from typing import Any, Pattern

import re2
import regex

from regex_utils.utils import (
    correct_lower_bound,
    has_non_latin_characters,
    is_fuzzy_pattern,
    is_special_sequence_pattern,
    remove_extra_groupings,
)
from snorkelflow.utils.logging import get_logger

logger = get_logger("Regex selector")


def select_compiled_regex(pattern: str, *args: Any, **kwargs: Any) -> Pattern:
    pattern = remove_extra_groupings(pattern)

    if (
        is_fuzzy_pattern(pattern)
        or is_special_sequence_pattern(pattern)
        or has_non_latin_characters(pattern)
    ):
        logger.debug(f"Used regex compiler for pattern {pattern}.")
        return regex.compile(pattern, *args, **kwargs)
    else:
        corrected_pattern = correct_lower_bound(pattern)
        logger.debug(
            f"Used re2 compiler for pattern {pattern}, corrected pattern {corrected_pattern}."
        )
        return re2.compile(corrected_pattern, *args, **kwargs)
