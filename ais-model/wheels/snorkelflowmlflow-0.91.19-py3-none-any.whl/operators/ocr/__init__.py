"""OCR operators"""
