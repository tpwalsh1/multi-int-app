import os
import shutil
import tempfile
from typing import Any, List, Optional

import pytesseract
import re2

from api_utils.exceptions import OperatorExecutionError
from file_utils.core import open_file
from snorkelflow.ocr.client import OCRClient
from snorkelflow.operators.operator import write_skipped_datapoints
from snorkelflow.rich_docs import RichDoc
from snorkelflow.rich_docs.rich_doc_utils import convert_pdf_to_image
from snorkelflow.utils.file import get_path_storage_options
from snorkelflow.utils.logging import get_logger

logger = get_logger("TesseractClient")


def natural_sort(l: List[str]) -> List[str]:
    convert = lambda text: int(text) if text.isdigit() else text.lower()
    alphanum_key = lambda key: [convert(c) for c in re2.split("([0-9]+)", key)]
    return sorted(l, key=alphanum_key)


class TesseractOCRClient(OCRClient):
    """Client for Tesseract OCR."""

    def __init__(
        self, ignore_errors: bool = False, errors_file_path: Optional[str] = None
    ) -> None:
        self.ignore_errors = ignore_errors
        self.errors_file_path = errors_file_path

    def apply_ocr(
        self, pdf_urls: List[str], datapoint_uids: Optional[List[str]] = None
    ) -> Any:
        """Applies OCR to the given PDF URLs."""
        ocr_results: List[str] = []
        for i, pdf_url in enumerate(pdf_urls):
            try:
                # By default copy to local since thats what owrks with PDFBox
                tmp_file = tempfile.NamedTemporaryFile()
                pdf_url, storage_options = get_path_storage_options(pdf_url)
                with open_file(
                    pdf_url, "rb", **(storage_options if storage_options else {})
                ) as f:
                    shutil.copyfileobj(f, open(tmp_file.name, "wb"))
                pdf_path = tmp_file.name

                # Convert the PDF to a directory of images
                with convert_pdf_to_image(
                    pdf_path, dpi=300, grayscale=True, format="png"
                ) as img_dir:
                    # Get all the images in the directory
                    img_paths = [
                        os.path.join(img_dir, f)
                        for f in os.listdir(img_dir)
                        if f.endswith(".png")
                    ]
                    img_paths = natural_sort(img_paths)
                    logger.info(f"{pdf_url}, img_paths: {img_paths}")
                    tmp = tempfile.NamedTemporaryFile()
                    # Write all the image paths to a tempfile
                    with open(tmp.name, "w") as f:
                        f.write("\n".join(img_paths))
                    # Run OCR on the images
                    config = r"--psm 4"
                    hocr = pytesseract.image_to_pdf_or_hocr(
                        tmp.name, lang="eng", config=config, extension="hocr"
                    )
                    # Decoding bytes to a string
                    hocr = hocr.decode("utf-8")
                    ocr_results.append(hocr)
            except pytesseract.TesseractNotFoundError as e:
                err_msg = "Tesseract is not installed. Please install it to use the Tesseract OCR client. You can find installation instructions at https://tesseract-ocr.github.io/tessdoc/Installation.html"
                logger.error(err_msg)
                raise OperatorExecutionError(detail=str(e), user_friendly_msg=err_msg)
            except pytesseract.TesseractError as e:
                err_msg = f"Could not run OCR successfully on {pdf_url}. Check that the PDF is not corrupt."
                logger.exception(err_msg)
                if self.ignore_errors:
                    if datapoint_uids is not None:
                        write_skipped_datapoints(
                            [datapoint_uids[i]], [str(e)], self.errors_file_path
                        )
                    # Ignore bad PDFs
                    ocr_results.append("")
                else:
                    raise OperatorExecutionError(
                        detail=str(e), user_friendly_msg=err_msg
                    )
            except Exception as e:
                err_msg = f"Could not convert the PDF {pdf_url} to an image."
                logger.error(err_msg, exc_info=True)
                if self.ignore_errors:
                    if datapoint_uids is not None:
                        write_skipped_datapoints(
                            [datapoint_uids[i]], [str(e)], self.errors_file_path
                        )
                    # Ignore bad PDFs
                    ocr_results.append("")
                else:
                    raise OperatorExecutionError(
                        detail=str(e), user_friendly_msg=err_msg
                    )
        return ocr_results

    def ocr_to_hocr(self, ocr_result: Any) -> List[str]:
        """Converts the OCR output to hOCR."""
        return ocr_result

    def ocr_to_rich_doc(self, ocr_result: Any) -> RichDoc:
        """Converts the OCR output to a RichDoc object."""
        raise NotImplementedError("TesseractOCRClient does not support ocr_to_rich_doc")
