from operators.ocr.tesseract_client import TesseractOCRClient
from operators.types import DataframeFieldType
from snorkelflow.ocr.featurizer import OCRFeaturizer


class TesseractFeaturizer(OCRFeaturizer):
    """
    Operator that takes in a PDF URL and outputs the hOCR text.

    This operator uses the Tesseract OCR engine to convert PDFs to hOCR text.
    The hOCR text is then used by the HocrToRichDocParser to generate a
    RichDoc object for the PDF.

    Parameters
    ----------
    pdf_url_field
        The name of the field that contains the URL of the PDF to be OCR'd
    output_field
        The name of the field that will contain the hOCR text
    ignore_errors
        Whether we want to raise errors or not for bad PDF files

    Returns
    -------
    output_field: The hOCR text
    """

    def __init__(
        self,
        pdf_url_field: DataframeFieldType,
        output_field: str,
        ignore_errors: bool = False,
    ):
        super().__init__(pdf_url_field, output_field)
        # Whether we want to raise errors or not for bad PDF files
        self.ignore_errors = ignore_errors

    @property
    def ocr_client(self) -> TesseractOCRClient:
        return TesseractOCRClient(
            ignore_errors=self.ignore_errors, errors_file_path=self.errors_file_path
        )
