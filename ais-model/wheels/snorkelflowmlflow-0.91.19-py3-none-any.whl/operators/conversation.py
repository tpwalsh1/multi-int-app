import json
from typing import Any, Dict, List, Optional

import pandas as pd

from api_utils.exceptions import UserInputError
from snorkelflow.extraction.span import SpanCols
from snorkelflow.operators.candidates import (
    SpanExtractor,
    SpanFeaturizer,
    SpanFeaturizerExtractor,
    get_span_field_value_hash,
)
from snorkelflow.operators.featurizer import Featurizer, OpProgressCallback
from snorkelflow.operators.operator import ColSchema, no_op_progress_callback
from snorkelflow.types.columns import ConvCols
from snorkelflow.types.performance import Performance


class ConversationParser(Featurizer):
    """
    Operator that parses conversation json and creates a json blob with utterances and speakers.

    This operator takes in the conversation json and creates a json blob for the filtered
    utterances, speakes, and metadata those we interested in.

    The output includes the json blob with utterances and speakers (conversation_json), and
    raw text consisting of joined utterances - no speaker names (conversation_text)

    Parameters
    ----------
    field : str
        Key in the JSON under which conversations can be found
    utterances_path : Optional[List[str]]
        Specify the path to actual utterances if the input json has a nested path
    text_field : str
        Key for each utterance
    speaker_field : str
        Key for speaker of each utterance
    speakers_to_classify : List[str]
        List of speakers whose utterances we want to classify
    metadata_field : json
        Key for metadata field for each utterance

    Returns
    -------
    conversation_json
        Json blob with utterances and speakers
    conversation_text
        Raw text consisting of joined utterances (no speaker names)


    """

    def __init__(
        self,
        field: str,
        utterances_path: Optional[List[str]],
        text_field: str,
        speaker_field: str,
        speakers_to_classify: List[str],
        metadata_field: str = "",
    ):
        self.field = field
        self.utterances_path = utterances_path or []
        self.text_field = text_field
        self.speaker_field = speaker_field
        self.metadata_field = metadata_field
        self.speakers_to_classify = speakers_to_classify

    @property
    def input_schema(self) -> ColSchema:
        return {self.field: str}

    @property
    def output_schema(self) -> ColSchema:
        return {ConvCols.CONV_COL: None, ConvCols.TEXT_COL: str}

    def estimate_perf(self, df: pd.DataFrame) -> Performance:
        length = df[self.field].str.len().sum()
        return Performance(
            compute_time_secs=length * 0.00000005, peak_memory_mb=length * 0.00002
        )

    def _parse(self, input_json: str) -> pd.Series:
        input_utterances = json.loads(input_json)
        for k in self.utterances_path:
            input_utterances = input_utterances[k]
        char_start = 0
        speakers: Dict[str, Any] = {}
        utterances: List[Dict[str, Any]] = []
        for row_id, utterance in enumerate(input_utterances):
            assert isinstance(utterance, dict)
            if self.text_field not in utterance:
                err_msg = f"{self.field} json in row with id {row_id} doesn't have expected text field {self.text_field}"
                raise UserInputError(
                    detail=err_msg,
                    user_friendly_message=err_msg,
                    how_to_fix="Please provide a valid text_field input in the ConversationParser or fix the input json",
                )
            text = str(utterance[self.text_field])
            if self.speaker_field not in utterance:
                err_msg = f"{self.field} json in row with id {row_id} doesn't have expected speaker field {self.speaker_field}"
                raise UserInputError(
                    detail=err_msg,
                    user_friendly_message=err_msg,
                    how_to_fix="Please provide a valid speaker_field input in the ConversationParser or fix the input json",
                )
            speaker = utterance[self.speaker_field]
            if speaker not in speakers:
                speakers[speaker] = {
                    ConvCols.SHOULD_CLASSIFY: speaker in self.speakers_to_classify
                }
            utterances.append(
                {
                    ConvCols.SPEAKER: speaker,
                    ConvCols.UTTERANCE: text,
                    SpanCols.CHAR_START: char_start,
                    SpanCols.CHAR_END: char_start + len(text),
                    ConvCols.TIMESTAMP: None,
                    ConvCols.METADATA: {},
                }
            )
            if self.metadata_field:
                utterances[-1][ConvCols.METADATA] = utterance.get(self.metadata_field)
            char_start += len(text) + 1  # For newline.
        # Generate full text so each span refers to a span of the text field as expected.
        full_text = "\n".join(map(lambda x: x[ConvCols.UTTERANCE], utterances))

        return pd.Series(
            {
                ConvCols.CONV_COL: {
                    ConvCols.UTTERANCES: utterances,
                    ConvCols.SPEAKERS: speakers,
                },
                ConvCols.TEXT_COL: full_text,
            }
        )

    def _compute_features(
        self,
        input_df: pd.DataFrame,
        callback: OpProgressCallback = no_op_progress_callback,
    ) -> pd.DataFrame:
        """Override base class method"""
        return input_df[self.field].apply(self._parse)

    def column_docs(self) -> Dict[str, str]:
        return {
            ConvCols.CONV_COL: "Json blob with utterances and speakers",
            ConvCols.TEXT_COL: "Raw text consisting of joined utterances (no speaker names)",
        }


class ConversationSpanFeaturizer(SpanFeaturizer):
    """
    Extractor that creates one span per utterance to classify.
    """

    def __init__(self, gt_field: str = "") -> None:
        self.field = gt_field

    @property
    def input_schema(self) -> ColSchema:
        return {ConvCols.CONV_COL: None, ConvCols.TEXT_COL: str}

    @property
    def output_schema(self) -> ColSchema:
        parent_output_schema = super().output_schema
        added_output_schema = self.get_suffixed_dict(
            {ConvCols.IDX_COL: object, ConvCols.UTTERANCE: object}
        )
        if parent_output_schema is None or added_output_schema is None:
            raise ValueError("Output schema is found none")
        return {**parent_output_schema, **added_output_schema}

    def extract_span_list_from_row(
        self, datapoint_uid: str, row: pd.Series
    ) -> List[Dict[str, Any]]:
        """Return a list of Span candidates extracted from the given row's fields"""
        spans = []
        span_field_value_hash = get_span_field_value_hash(row[ConvCols.TEXT_COL])
        speakers = row[ConvCols.CONV_COL][ConvCols.SPEAKERS]
        for idx, utterance in enumerate(row[ConvCols.CONV_COL][ConvCols.UTTERANCES]):
            if speakers[utterance[ConvCols.SPEAKER]][ConvCols.SHOULD_CLASSIFY]:
                spans.append(
                    dict(
                        utterance_idx=idx,
                        # This col is a trivial copy of span_text intended to help
                        # users select fields without understanding span-based columns
                        utterance=utterance[ConvCols.UTTERANCE],
                        span_field=ConvCols.TEXT_COL,
                        span_field_value_hash=span_field_value_hash,
                        char_start=utterance[SpanCols.CHAR_START],
                        # Since extractions use [inclusive, inclusive]
                        char_end=utterance[SpanCols.CHAR_END] - 1,
                        span_text=utterance[ConvCols.UTTERANCE],
                        span_entity=None,
                        initial_label=(utterance[ConvCols.METADATA] or {}).get(
                            self.field, -1
                        ),
                    )
                )
        return spans


class ConversationExtractor(SpanFeaturizerExtractor, ConversationSpanFeaturizer):
    """
    Extractor that creates one span per utterance to classify.

    This operator internally processes the JSON to create a datapoint per utterance.
    It also extracts the Ground Truth for each utterances from the JSON and attaches it to the datapoint.

    Parameters
    ----------
    gt_field
        Key for the Ground Truth Label field
    """

    def __init__(self, gt_field: str = "") -> None:
        ConversationSpanFeaturizer.__init__(self, gt_field)

    @property
    def input_schema(self) -> ColSchema:
        # return input schema from ConversationSpanFeaturizer
        return {**super(SpanExtractor, self).input_schema}

    @property
    def output_schema(self) -> ColSchema:
        parent_output_schema = super().output_schema
        added_output_schema = self.get_suffixed_dict(
            {ConvCols.IDX_COL: int, ConvCols.UTTERANCE: str}
        )
        if parent_output_schema is None or added_output_schema is None:
            raise ValueError("Output schema is found none")
        return {**parent_output_schema, **added_output_schema}

    def extract_span_list_from_row(
        self, datapoint_uid: str, row: pd.Series
    ) -> List[Dict[str, Any]]:
        return ConversationSpanFeaturizer.extract_span_list_from_row(
            self, datapoint_uid, row
        )


class ConversationLastUtterances(Featurizer):
    """
    Operator that creates text columns for last k utterances of same and other speakers.

    This operator creates text columns for last k utterances of same and other speakers.
    You can change k to be any int value. You can also add more of these operators to add more such columns in the data.

    Parameters
    ----------
    last_k
        The number of utterances to create text column
    group_by_speaker
        If true, the utterances will be grouped by the speaker (default to true)
    """

    def __init__(self, last_k: int = 5, group_by_speaker: bool = True):
        self.last_k = last_k
        # self.suffixes must be the range of values of self.speaker_to_suffix.
        if group_by_speaker:
            self.suffixes = ["_other", "_same"]
            self.speaker_to_suffix = (
                lambda cur_speaker, speaker: "_same"
                if cur_speaker == speaker
                else "_other"
            )
        else:
            self.suffixes = [""]
            self.speaker_to_suffix = lambda cur_speaker, speaker: ""

    def _feature_name(self, suffix: str) -> str:
        return f"last_{self.last_k}_utterances{suffix}"

    @property
    def input_schema(self) -> ColSchema:
        return {ConvCols.IDX_COL: int}

    @property
    def output_schema(self) -> ColSchema:
        return {self._feature_name(suffix): str for suffix in self.suffixes}

    def _per_row(self, row: pd.Series) -> pd.Series:
        idx = row[ConvCols.IDX_COL] - 1
        speaker = row[ConvCols.CONV_COL][ConvCols.UTTERANCES][row[ConvCols.IDX_COL]][
            ConvCols.SPEAKER
        ]
        suffix_to_utterances: Dict[str, List[str]] = {
            suffix: [] for suffix in self.suffixes
        }
        while idx >= 0 and min(map(len, suffix_to_utterances.values())) < self.last_k:
            cur_utterance = row[ConvCols.CONV_COL][ConvCols.UTTERANCES][idx]
            speaker_suffix = self.speaker_to_suffix(
                cur_utterance[ConvCols.SPEAKER], speaker
            )
            utterances_list = suffix_to_utterances[speaker_suffix]

            if len(utterances_list) < self.last_k:
                utterances_list.append(cur_utterance[ConvCols.UTTERANCE])
            idx -= 1

        series = pd.Series(
            {
                self._feature_name(suffix): ". ".join(
                    reversed(suffix_to_utterances[suffix])
                )
                for suffix in sorted(suffix_to_utterances)
            }
        )
        return series

    def _compute_features(
        self,
        input_df: pd.DataFrame,
        callback: OpProgressCallback = no_op_progress_callback,
    ) -> pd.DataFrame:
        """Override base class method"""
        return input_df.apply(self._per_row, 1)


class UtteranceEntities(Featurizer):
    """Operator that creates text column containing Spacy based entities for utterances."""

    operator_impl_version: int = 1

    def __init__(self) -> None:
        self.field = ConvCols.UTTERANCE
        self.nlp = None

    @property
    def input_schema(self) -> ColSchema:
        return {ConvCols.UTTERANCE: str}

    @property
    def output_schema(self) -> ColSchema:
        return {ConvCols.UTTERANCE_ENTITIES: None}

    def _per_row(self, row: pd.Series) -> pd.Series:
        # Currently executed only for speaker with should_classify = True
        doc = self.nlp(row)  # type: ignore
        entities = []
        for ent in doc.ents:
            entities.append([ent.text, ent.label_])
        series = pd.Series({ConvCols.UTTERANCE_ENTITIES: entities})
        return series

    def _compute_features(
        self,
        input_df: pd.DataFrame,
        callback: OpProgressCallback = no_op_progress_callback,
    ) -> pd.DataFrame:
        """Override base class method"""
        if self.nlp is None:
            import spacy

            self.nlp = spacy.load("en_core_web_sm")

        return input_df[self.field].apply(self._per_row, 1)
