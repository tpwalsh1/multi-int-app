from typing import Dict, List

from dask import dataframe as dd

from snorkelflow.operators.operator import (
    ColSchema,
    Operator,
    OpWithPartitionInfoProgressCallback,
    no_op_progress_callback,
)
from snorkelflow.utils.logging import get_logger

logger = get_logger("Operator")


class ConcatRows(Operator):
    """Processor that concatenates dataframes along the index axis."""

    def __init__(self) -> None:
        pass

    @property
    def input_schema(self) -> ColSchema:
        return {}

    @property
    def output_schema(self) -> ColSchema:
        return {}

    def _execute(self, input_ddfs: List[dd.DataFrame]) -> dd.DataFrame:
        """Private method for reading Contexts DataFrame and returning Candidates DataFrame."""
        # Compute intersection of columns
        cols = input_ddfs[0].columns
        for ddf in input_ddfs[1:]:
            cols = cols.intersection(ddf.columns)
        return dd.concat([ddf[cols] for ddf in input_ddfs])


class ConcatColumns(Operator):
    """Processor that concatenates columns of dataframes."""

    @staticmethod
    def get_options() -> Dict[str, List[str]]:
        return dict(join_type=["inner", "left"])

    def __init__(
        self, join_type: str = "inner", suffix: str = "", drop_duplicates: bool = False
    ) -> None:
        self.join_type = join_type
        self.suffix = suffix
        self.drop_duplicates = drop_duplicates

    @property
    def input_schema(self) -> ColSchema:
        return {}

    @property
    def output_schema(self) -> ColSchema:
        return {}

    def _execute(self, input_ddfs: List[dd.DataFrame]) -> dd.DataFrame:
        """Private method for reading Contexts DataFrame and returning Candidates DataFrame."""
        ddf_left = input_ddfs[0]
        # TODO: Should we even allow left joins? nans can lead to weird type errors down the line.
        for idx, ddf_right in enumerate(input_ddfs[1:]):
            if self.drop_duplicates:
                # Drop overlapping columns from ddf_right.
                nonduplicate_right_cols = ddf_right.columns.difference(ddf_left.columns)
                ddf_right = ddf_right[nonduplicate_right_cols]
            ddf_left = ddf_left.join(
                ddf_right, how=self.join_type, rsuffix=f"{self.suffix}{idx + 1}"
            )
        return ddf_left

    def execute(
        self,
        input_ddfs: List[dd.DataFrame],
        callback: OpWithPartitionInfoProgressCallback = no_op_progress_callback,
    ) -> dd.DataFrame:
        return self._execute(input_ddfs)
