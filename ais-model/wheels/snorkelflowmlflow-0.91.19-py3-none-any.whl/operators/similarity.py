from typing import Any, Dict, List, Optional

import numpy as np
import pandas as pd

from api_utils.exceptions import UserInputError
from embeddings.similarity import METRIC_FNS
from snorkelflow.operators.featurizer import Featurizer, OpProgressCallback
from snorkelflow.operators.operator import ColSchema, no_op_progress_callback
from snorkelflow.utils.logging import get_logger

logger = get_logger("Embedding")


class EmbeddingComparator(Featurizer):
    """Comparator that compares embedding_field to
    reference_field embeddings or reference_embeddings."""

    def __init__(
        self,
        embedding_field: str,
        reference_field: Optional[str] = None,
        reference_embeddings: Optional[List[List[float]]] = None,
        compute_reference_embeddings_fn: Optional[Any] = None,
        metric: str = "cosine_similarity",
        target_field: Optional[str] = None,
        device: Optional[str] = None,
    ) -> None:
        self.embedding_field = embedding_field
        if reference_field is not None and reference_embeddings is not None:
            user_friendly_message = (
                "Cannot use both reference_field and reference_embeddings"
            )
            detailed_message = f"{user_friendly_message}: reference_field={reference_field}, reference_embeddings={reference_embeddings}"
            raise UserInputError(
                detail=detailed_message, user_friendly_message=user_friendly_message
            )
        self.reference_field = reference_field
        self.reference_embeddings = reference_embeddings

        if (
            self.reference_embeddings is None
            and compute_reference_embeddings_fn is not None
        ):
            self.reference_embeddings = compute_reference_embeddings_fn()

        if metric not in METRIC_FNS:
            message = f"Invalid metric '{metric}': Must be in {list(METRIC_FNS.keys())}"
            raise UserInputError(detail=message, user_friendly_message=message)
        self.metric = metric
        self.metric_fn = METRIC_FNS[metric]

        self.target_field = target_field or self.metric
        self.device = device

    @property
    def input_schema(self) -> ColSchema:
        if self.reference_field is not None:
            return {self.embedding_field: str, self.reference_field: str}
        else:
            return {self.embedding_field: str}

    @property
    def output_schema(self) -> ColSchema:
        return {self.target_field: None}

    @staticmethod
    def get_options() -> Dict[str, List[str]]:
        return dict(metric=list(METRIC_FNS.keys()))

    def _compute_features_embedding(
        self, input_df: pd.DataFrame, embeddings: Optional[np.ndarray] = None
    ) -> pd.DataFrame:
        if embeddings is None:
            # Recompute embeddings if not provided
            return self._compute_features(input_df)
        else:
            reference_embeddings = (
                input_df[self.reference_field].values.tolist()
                if self.reference_field
                else self.reference_embeddings
            )

            target_field = self.target_field or self.metric
            reference_embeddings = np.array(reference_embeddings)
            if 0 in [reference_embeddings.size, embeddings.size]:  # type: ignore
                input_df[target_field] = [[]] * len(input_df)
                return input_df

            input_df[target_field] = self.metric_fn(
                embeddings, reference_embeddings, device=self.device
            )
            return input_df

    def _compute_features(
        self,
        input_df: pd.DataFrame,
        callback: OpProgressCallback = no_op_progress_callback,
    ) -> pd.DataFrame:
        # Similarities are currently not cached
        if self.embedding_field not in input_df:
            message = f"'{self.embedding_field}' not present in input columns: '{input_df.columns.values.tolist()}'"
            raise UserInputError(detail=message, user_friendly_message=message)

        embeddings = input_df[self.embedding_field].values.tolist()
        reference_embeddings = (
            input_df[self.reference_field].values.tolist()
            if self.reference_field
            else self.reference_embeddings
        )
        target_field = self.target_field or self.metric

        # Empty reference embeddings
        if reference_embeddings in [[], [[]]] or embeddings in [[], [[]]]:
            input_df[target_field] = [[]] * len(input_df)
            return input_df

        results = self.metric_fn(embeddings, reference_embeddings, device=self.device)
        # results is guaranteed to be a numpy array.
        if isinstance(results, np.ndarray) and results.shape[1] > 1:
            # If the results array is multi-dim, then convert to list of lists.
            # Not sure why this would ever happen but I'll leave it up to Damian
            # to help us figure this out.
            input_df[target_field] = results.tolist()
        else:
            input_df[target_field] = results

        return input_df
