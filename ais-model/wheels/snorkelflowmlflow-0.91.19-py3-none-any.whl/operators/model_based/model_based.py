import os
from enum import Enum
from functools import cached_property
from typing import Any, Dict, List, Optional, Type, Union

import numpy as np
import pandas as pd

from api_utils.exceptions import UserInputError
from snorkelflow.operators.featurizer import (
    Featurizer,
    OpProgressCallback,
    cache_features,
)
from snorkelflow.operators.operator import (
    ColSchema,
    get_operator_data_dir,
    no_op_progress_callback,
)
from snorkelflow.utils.file import resolve_data_path
from snorkelflow.utils.hashing import consistent_hash
from snorkelflow.utils.logging import get_logger

from .base_model import BaseModel
from .constants import GT_FIELD
from .simple_models import ZeroShotTextMatchModel
from .sklearn_models import (
    LogisticRegressionModel,
    OneClassSVMModel,
    TFIDFLogisticRegressionModel,
)

try:
    from .transformer_base_models import BaseLLMModel, EntailmentZeroShotModel
    from .transformer_trainable_models import MaskedLMModel, SDNetSFModel, SetFitSFModel

    LLM_ENABLED = True
except ImportError:
    # If we're running outside of the platform on the slim target
    # and don't have access to these models
    BaseLLMModel = None  # type: ignore
    LLM_ENABLED = False

logger = get_logger("ModelBasedFeaturizer")


class MODEL_TYPES(str, Enum):
    zsl_text_match: str = "zsl_text_match"
    zsl_entailment: str = "zsl_entailment"
    zsl_prompt: str = "zsl_prompt"
    zsl_prompt_remote: str = "zsl_prompt_remote"
    zsl_prompt_multi_label: str = "zsl_prompt_multi_label"
    zsl_prompt_multi_label_remote: str = "zsl_prompt_multi_label_remote"
    masked_lm: str = "masked_lm"
    logistic_regression: str = "logistic_regression"
    one_class_svm: str = "one_class_svm"
    tfidf_logreg: str = "tfidf_logreg"
    setfit: str = "setfit"
    setfit_multilabel: str = "setfit_multilabel"
    sdnet: str = "sdnet"
    sequence_embedding: str = "sequence_embedding"


LLM_MODEL_TYPES = {
    MODEL_TYPES.zsl_entailment,
    MODEL_TYPES.zsl_prompt,
    MODEL_TYPES.masked_lm,
    MODEL_TYPES.setfit,
    MODEL_TYPES.setfit_multilabel,
    MODEL_TYPES.sdnet,
    MODEL_TYPES.zsl_prompt_remote,
    MODEL_TYPES.zsl_prompt_multi_label,
    MODEL_TYPES.zsl_prompt_multi_label_remote,
}


# Defining Model Options
MODEL_OPTIONS: Dict[str, Type[BaseModel]] = {
    MODEL_TYPES.logistic_regression: LogisticRegressionModel,
    MODEL_TYPES.tfidf_logreg: TFIDFLogisticRegressionModel,
    MODEL_TYPES.zsl_text_match: ZeroShotTextMatchModel,
    MODEL_TYPES.one_class_svm: OneClassSVMModel,
}

if LLM_ENABLED:
    MODEL_OPTIONS.update(
        {
            MODEL_TYPES.zsl_entailment: EntailmentZeroShotModel,
            MODEL_TYPES.masked_lm: MaskedLMModel,
            MODEL_TYPES.setfit: SetFitSFModel,
            MODEL_TYPES.setfit_multilabel: SetFitSFModel,
            MODEL_TYPES.sdnet: SDNetSFModel,
        }
    )


DEPRECATION_MESSAGE = "Fitting new ModelBasedFeaturizer DAG nodes is now deprecated, please use the new model based LF template instead."


class ModelBasedFeaturizer(Featurizer):
    """
    Featurizer that trains and applies a model to a new column

    Parameters
    ----------
    model_name
        Assign name to the trained model
    model_type
        Type of the model to train
    input_fields
        Fields to input to model to get predictions over
    dirpath
        The path to the directory where the pickled model (and additional
        info) is stored
    target_field
        Optional name to give to the output column(s) of model predictions
    load_from_cache_only
        If True, will only load features from cache.
    """

    artifact_config_keys: List[str] = ["dirpath"]
    show_args_in_gui: bool = False

    def __init__(
        self,
        model_name: str = "model",
        model_type: Optional[str] = None,
        input_fields: Optional[List[str]] = None,
        dirpath: Optional[str] = None,
        target_field: Optional[str] = None,
        min_confidence_threshold: Optional[float] = None,
        load_from_cache_only: bool = False,
        unique_model_name: Optional[str] = None,
    ) -> None:
        """
        Parameters
        ----------
        model_type
            Type of the model to train
        input_fields
            Fields to input to model to get predictions over
        dirpath
            The path to the directory where the pickled model (and additional
            info) is stored
        target_field
            Optional name to give to the output column(s) of model predictions
        min_confidence_threshold [DEPRECATED]
            Included for legacy support of old ModelBasedFeaturizer DAG nodes
        load_from_cache_only
            Whether to return predictions already generated, abstaining on all new datapoints.
        """
        # TODO: Allow for either models to be defined here by user
        #       (and raise UserInputError if the model_type selected has
        #       to be fitted before instantiating).
        if model_type is None or input_fields is None or dirpath is None:
            # Making required __init__ params optional to hide them from the GUI
            raise UserInputError(
                "Cannot instantiate this operator without fitting the model",
                user_friendly_message="Model type is required",
            )

        self.model_name = model_name
        self.model_type = model_type
        self.input_fields = input_fields
        self.dirpath = dirpath
        self.unique_model_name = unique_model_name
        # expand to target_fields
        self.target_field = (
            target_field or f"__{model_type}_preds_{self.get_featurizer_hash()}"
        )
        if min_confidence_threshold is not None:
            logger.warning(
                f"min_confidence_threshold is deprecated. Please only use with existing legacy ModelBasedFeaturizer DAG nodes."
            )
        self.min_confidence_threshold = min_confidence_threshold
        self.load_from_cache_only = load_from_cache_only
        self.is_multilabel = self.model_type == MODEL_TYPES.setfit_multilabel

    @staticmethod
    def get_options() -> Dict[str, List[str]]:
        return dict(model_type=list(MODEL_OPTIONS.keys()))

    @property
    def input_schema(self) -> ColSchema:
        return {field: None for field in self.input_fields}

    @property
    def output_schema(self) -> ColSchema:
        return {
            self.target_field: Union[int, List[int]],
            f"{self.target_field}_max_logit": Union[float, List[float]],
        }

    @cached_property
    def use_gpu_if_available(self) -> bool:
        return self.model_type in LLM_MODEL_TYPES

    @classmethod
    def _fit(  # type: ignore
        cls,
        df: pd.DataFrame,
        model_type: str,
        fields: List[str],
        target_field: Optional[str] = None,
        label_map: Optional[Dict[str, Union[str, int, float]]] = None,
        min_confidence_threshold: Optional[float] = None,
        model_init_args: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """
        Parameters
        ----------
        model_type
            Type of model to train and apply over dataset
        fields
            (X) Fields to pass as input to the model
        target_field
            Optional name of new column created for model predictions
        label_map
            Optional mapping of label name to label int
        model_init_args
            Any additional arguments to pass to model init
        """
        if min_confidence_threshold is not None:
            raise UserInputError(
                detail=DEPRECATION_MESSAGE, user_friendly_message=DEPRECATION_MESSAGE
            )
        if model_init_args is None:
            model_init_args = {}
        else:
            model_init_args = model_init_args.copy()

        if "label_map" not in model_init_args and model_type not in {
            MODEL_TYPES.one_class_svm
        }:
            model_init_args["label_map"] = label_map

        label_space = model_init_args.get("label_space", None)
        unknown_label = (
            -1 if label_space is None else label_space.get_raw_unknown_label()
        )
        df = df[(df[GT_FIELD].notnull()) & (df[GT_FIELD] != unknown_label)]

        if df.empty and model_type not in {
            MODEL_TYPES.zsl_text_match,
            MODEL_TYPES.zsl_entailment,
        }:
            msg = "No training data provided, cannot train model."
            raise UserInputError(detail=msg, user_friendly_message=msg)

        model = MODEL_OPTIONS[model_type](**model_init_args)

        X = df[fields]
        y = df[GT_FIELD].values

        dirpath = get_operator_data_dir()

        model.fit(X, y)

        # Create path if it doesn't exist
        resolved_dirpath = resolve_data_path(dirpath)
        os.makedirs(resolved_dirpath, exist_ok=True)
        model.save(resolved_dirpath)

        del model

        return dict(
            model_type=model_type,
            input_fields=fields,
            dirpath=dirpath,
            target_field=target_field,
        )

    @classmethod
    def _fit_input_schema(  # type: ignore
        cls,
        model_type: str,
        fields: List[str],
        target_field: Optional[str] = None,
        label_map: Optional[Dict[str, Union[str, int, float]]] = None,
        model_init_args: Optional[Dict[str, Union[str, int, float]]] = None,
    ) -> ColSchema:
        return {field: None for field in fields}

    # Overriding both fit() and check_fit_arguments() because a breaking change introduced in python 3.7 makes it so that
    # the type checks in check_fit_arguments() fail with
    # "TypeError: Subscripted generics cannot be used with class and instance checks"
    # Github thread for context: https://github.com/ramazanpolat/prodict/issues/1
    @classmethod
    def check_fit_arguments(cls, **kwargs: Any) -> None:
        label_map = kwargs.get("label_map", {})
        model_type = kwargs.get("model_type", "")

        # Check if label_map is > 3 to account for unknown class
        if len(label_map) > 3 and model_type == "one_class_svm":
            err_msg = f"{model_type} is not supported for multinomial classification"
            raise UserInputError(detail=err_msg, user_friendly_message=err_msg)

    @classmethod
    def fit(cls, df: pd.DataFrame, **kwargs: Any) -> Dict[str, Any]:
        return cls._fit(df, **kwargs)

    def _compute_features(
        self,
        input_df: pd.DataFrame,
        callback: OpProgressCallback = no_op_progress_callback,
        load_from_cache_only: Optional[bool] = None,
    ) -> pd.DataFrame:
        cache_only = (
            self.load_from_cache_only
            if load_from_cache_only is None
            else load_from_cache_only
        )
        return self._cached_compute_features(
            input_df=input_df, callback=callback, load_from_cache_only=cache_only
        )

    @cache_features
    def _cached_compute_features(
        self,
        input_df: pd.DataFrame,
        callback: OpProgressCallback = no_op_progress_callback,
    ) -> pd.DataFrame:
        """
        Override base class method. Compute and cache prediction logits. If
        logits are not available then cache predictions.
        """
        # Cannot figure out why mypy doesn't like this line - seems to think
        # `cls` should be explicitely passed to a classmethod
        model = MODEL_OPTIONS[self.model_type].load(resolve_data_path(self.dirpath))  # type: ignore
        if BaseLLMModel and isinstance(model, BaseLLMModel):
            # BaseLLMPredictor assumes progress_fn with arguments (num_done, num_total, self._predicted_ids)
            model.predictor.set_callback(callback)

        X = input_df[self.input_fields]

        # DEPRECATED: legacy path for ModelBasedFeaturizer DAG nodes
        if self.min_confidence_threshold is not None:
            try:
                logger.warning(f"ModelBasedFeaturizer DAG nodes are deprecated")
                logits = model.predict_proba(X)
                preds = logits.argmax(axis=1)
                preds[logits.max(axis=1) <= self.min_confidence_threshold] = -1
                input_df[self.target_field] = preds
                return input_df
            # AttributeError will occur when previous model is trained on older sklearn version ENG-24360
            except AttributeError:
                raise UserInputError(
                    detail=DEPRECATION_MESSAGE,
                    user_friendly_message=DEPRECATION_MESSAGE,
                )

        try:
            logits = model.predict_proba(X)
            if self.is_multilabel:
                # In the multi-label case, we return a logit for each class
                logits[pd.isna(logits)] = 0
                input_df[f"{self.target_field}"] = list(np.ones_like(logits))
                input_df[f"{self.target_field}_max_logit"] = list(logits)
            else:
                input_df[f"{self.target_field}"] = logits.argmax(axis=1)
                input_df[f"{self.target_field}_max_logit"] = logits.max(axis=1)
        except NotImplementedError:
            logger.info("model does not support thresholding")
            preds = model.predict(X)
            input_df[self.target_field] = preds
            if self.is_multilabel:
                input_df[f"{self.target_field}_max_logit"] = preds
            else:
                input_df[f"{self.target_field}_max_logit"] = 1

        del model
        return input_df

    def get_featurizer_hash(self) -> str:
        if self.unique_model_name is not None:
            return str(consistent_hash(self.unique_model_name))
        return str(consistent_hash(self.dirpath))  # For backwards compat
