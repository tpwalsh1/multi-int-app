from typing import Tuple

import numpy as np
import pandas as pd

from api_utils.exceptions import UserInputError
from snorkelflow.models.utils import is_num_series, is_text_series

from .constants import GT_FIELD


def inverse_dict(d: dict) -> dict:
    """Returns a dict with the values from `d` as keys"""
    # Note: Assumes 1-1 mapping
    return {v: k for k, v in d.items()}


def validate_col_types(X: pd.DataFrame, col_type: str) -> None:
    """Validates that all columns within a dataframe satisfy one type"""
    if col_type == "text":
        check_func = is_text_series
    elif col_type == "numeric":
        check_func = is_num_series
    else:
        raise ValueError(f"Unrecognized col_type {col_type}")

    for col in X.columns:
        if not check_func(X[col]):
            err_msg = f"Model selected cannot use non-{col_type} type field {col}"
            raise UserInputError(detail=err_msg, user_friendly_message=err_msg)


def combine_text_cols(
    X: pd.DataFrame, new_col_name: str, drop: bool = False
) -> pd.DataFrame:
    """Combine all existing text columns into one with the specified column name

    Parameters
    ----------
    X
        Input dataframe
    new_col_name
        New column for the resulting DF
    drop
        Whether to drop all concatenated text columns
    """
    text_cols = [col for col in X.columns if is_text_series(X[col])]
    feature_df = X.fillna({text_col: "" for text_col in text_cols})

    if len(text_cols) > 1:
        feature_df[new_col_name] = feature_df.apply(
            lambda row: ". ".join([row[col] for col in text_cols]), axis=1
        )
    elif len(text_cols) == 1:
        feature_df[new_col_name] = feature_df[text_cols[0]]

    if drop:
        feature_df = feature_df.drop(text_cols, axis=1)

    return feature_df


def train_val_split(
    X: pd.DataFrame, y: np.ndarray, val_split: float
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """Returns a train_df, val_df given an input X and y"""
    X[GT_FIELD] = y
    X = X.sample(frac=1).reset_index(drop=True)
    val_df = X[int(val_split * len(X)) :]
    train_df = X[len(val_df) :]

    return train_df, val_df
