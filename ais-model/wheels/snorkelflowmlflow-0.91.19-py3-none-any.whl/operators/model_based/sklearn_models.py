import abc
import os
import pickle
from typing import Any, Dict, List, Optional, Type, Union

import numpy as np
import pandas as pd
from sklearn.base import ClassifierMixin
from sklearn.compose import ColumnTransformer
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline

from api_utils.exceptions import UserInputError
from file_utils.core import open_file
from snorkelflow.models.sklearn import LIBLINEAR_MAX_CARDINALITY
from snorkelflow.models.svm_wrapper import SVMWrapper
from snorkelflow.models.utils import is_num_series
from snorkelflow.utils.file import resolve_data_path

from .base_model import BaseModel, BaseTrainableModel
from .utils import combine_text_cols, validate_col_types

# Creating selector for use with ColumnTransformer to return the
# relevant columns for numeric.
# NOTE: These are defined up here for pickling purposes with sklearn


class ColumnTransformerWrapper(ColumnTransformer):
    """Wrapper to fix bug in ColumnTransformer

    When a ColumnTransformer uses a sparse matrix but one of its
    transformers has no columns, it will throw an error. This removes any
    empty lists from the self._columns variable, which causes that error.
    """

    def _validate_column_callables(self, X: Union[pd.Series, np.ndarray]) -> None:
        super()._validate_column_callables(X)

        self._columns: List[Any] = [col for col in self._columns if col == 0 or col]


def select_optional_num_cols(X: pd.DataFrame) -> List[str]:
    """Selects all available numeric columns"""
    return [col for col in X.columns if is_num_series(X[col])]


# Scikit Learn models have a common interface with saving/loading
class SKLearnModelWrapper(BaseTrainableModel, metaclass=abc.ABCMeta):
    """Wrapper around sklearn models"""

    model_cls: Type[ClassifierMixin]

    def __init__(self, model: Optional[ClassifierMixin] = None, **model_init_args: Any):
        """
        Parameters
        ----------
        model
            sklearn model to wrap
        """

        super().__init__()

        if model is None:
            self.model = self.model_cls(**model_init_args)
        else:
            self.model = model

    def _preprocess(self, X: pd.DataFrame, fit: bool) -> np.ndarray:
        """Can be implemented by child classes to preprocess data"""
        return X.values

    def fit(self, X: pd.DataFrame, y: np.ndarray, **kwargs: Any) -> None:
        super().fit(X, y)
        X = self._preprocess(X, fit=True)
        self.model.fit(X, y, **kwargs)

    def predict(self, X: pd.DataFrame) -> np.ndarray:
        X = self._preprocess(X, fit=False)
        preds = self.model.predict(X)
        return preds

    def predict_proba(self, X: pd.DataFrame) -> np.ndarray:
        X = self._preprocess(X, fit=False)
        y_hat = self.model.predict_proba(X)
        return y_hat

    def save(self, dirpath: str) -> None:
        with open_file(self._pkl_path(resolve_data_path(dirpath)), "wb") as model_file:
            pickle.dump(self.model, model_file)

    @classmethod
    def load(cls, dirpath: str) -> BaseModel:
        with open_file(cls._pkl_path(resolve_data_path(dirpath)), "rb") as model_file:
            sk_model = pickle.load(model_file)

        return cls(sk_model)

    @staticmethod
    def _pkl_path(dirpath: str) -> str:
        """Helper method to return the model path given the model type and dirpath"""
        return os.path.join(dirpath, f"sklearn_model.pkl")


class LogisticRegressionModel(SKLearnModelWrapper):
    model_cls = LogisticRegression

    def __init__(
        self,
        model: Optional[ClassifierMixin] = None,
        random_state: int = 123,
        label_map: Optional[Dict[str, int]] = None,
        solver: Optional[str] = None,
        **model_init_args: Any,
    ):
        if model is None:
            if solver is None:
                if label_map is None:
                    msg = "Need to specify one of solver or label_map"
                    raise UserInputError(detail=msg, user_friendly_message=msg)
                else:
                    n_classes = len(label_map) - 1
                    solver = (
                        "liblinear" if n_classes < LIBLINEAR_MAX_CARDINALITY else "saga"
                    )
        super().__init__(
            model=model, random_state=random_state, solver=solver, **model_init_args
        )

    def _preprocess(self, X: pd.DataFrame, fit: bool) -> np.ndarray:
        validate_col_types(X, col_type="numeric")
        return np.nan_to_num(X.values)


class OneClassSVMModel(SKLearnModelWrapper):
    model_cls = SVMWrapper

    def _preprocess(self, X: pd.DataFrame, fit: bool) -> np.ndarray:
        validate_col_types(X, col_type="numeric")
        return np.nan_to_num(X.values)


class TFIDFLogisticRegressionModel(SKLearnModelWrapper):
    model_cls = Pipeline

    def __init__(
        self,
        model: Optional[ClassifierMixin] = None,
        random_state: int = 123,
        label_map: Optional[Dict[str, int]] = None,
        solver: Optional[str] = None,
        **model_init_args: Any,
    ):
        self.text_col_name = "_tmp_logreg_tfidf_text_"
        if model is None:
            if solver is None:
                if label_map is None:
                    msg = "Need to specify one of solver or label_map"
                    raise UserInputError(detail=msg, user_friendly_message=msg)
                else:
                    n_classes = len(label_map) - 1
                    solver = (
                        "liblinear" if n_classes < LIBLINEAR_MAX_CARDINALITY else "saga"
                    )
        # Passing model init args to TfidfVectorizer bc that has more config options
        pipeline_init_args = dict(
            steps=[
                (
                    "transform",
                    ColumnTransformerWrapper(
                        [
                            ("tfidf", TfidfVectorizer(), self.text_col_name),
                            ("numeric", "passthrough", select_optional_num_cols),
                        ]
                    ),
                ),
                (
                    "clf",
                    LogisticRegression(
                        random_state=random_state, solver=solver, **model_init_args
                    ),
                ),
            ]
        )

        super().__init__(model=model, **pipeline_init_args)

    def _preprocess(self, X: pd.DataFrame, fit: bool) -> pd.DataFrame:
        X = combine_text_cols(X, new_col_name=self.text_col_name, drop=True)

        # Check to validate that a text column exists
        if self.text_col_name not in X:
            err_msg = "Selected model requires at least one text input field"
            raise UserInputError(detail=err_msg, user_friendly_message=err_msg)

        if fit:
            # Check that a vocabulary can be created from the train data
            if X[self.text_col_name].apply(lambda x: len(x.strip()) == 0).all():
                err_msg = "Model selected requires non-empty training data to build vocabulary"
                raise UserInputError(detail=err_msg, user_friendly_message=err_msg)

        return X.fillna(0)
