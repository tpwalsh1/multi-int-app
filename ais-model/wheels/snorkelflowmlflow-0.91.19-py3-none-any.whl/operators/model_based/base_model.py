import abc
from typing import Any

import numpy as np
import pandas as pd

from api_utils.exceptions import UserInputError


class BaseModel(metaclass=abc.ABCMeta):
    """Base class for a model that can be used to generate LFs"""

    def __init__(self, **kwargs: Any):
        # Including for mypy
        pass

    @abc.abstractmethod
    def save(self, dirpath: str) -> None:
        """Saves the model"""

    @classmethod
    @abc.abstractmethod
    def load(cls, dirpath: str) -> "BaseModel":
        """Loads the model and returns it from a given directory"""

    @abc.abstractmethod
    def fit(self, X: pd.DataFrame, y: np.ndarray, **kwargs: Any) -> None:
        """Fits (if necessary) the model over the data"""

    @abc.abstractmethod
    def predict(self, X: pd.DataFrame) -> np.ndarray:
        """Runs predictions for the model over a numpy array"""

    @abc.abstractmethod
    def predict_proba(self, X: pd.DataFrame) -> np.ndarray:
        """Returns predictions confidences for each label class for the model over a numpy array"""


class BaseTrainableModel(BaseModel, metaclass=abc.ABCMeta):
    """Base class for models that require training"""

    @abc.abstractmethod
    def fit(self, X: pd.DataFrame, y: np.ndarray, **kwargs: Any) -> None:
        """Fits the model with some X and y"""
        if len(X) == 0:
            err_msg = "Train set must contain some ground truth to use this operator"
            raise UserInputError(detail=err_msg, user_friendly_message=err_msg)
