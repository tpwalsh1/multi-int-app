import abc
import json
import os
from typing import Any, Dict, List, Optional

import numpy as np
import pandas as pd

from api_utils.exceptions import UserInputError
from file_utils.core import open_file
from snorkelflow.utils.logging import get_logger

from .base_model import BaseModel
from .utils import combine_text_cols, validate_col_types

logger = get_logger("ModelBasedFeaturizer")


class ZeroShotModel(BaseModel, metaclass=abc.ABCMeta):
    """A base ZSL model class that does not fit on data"""

    def fit(self, X: pd.DataFrame, y: np.ndarray, **kwargs: Any) -> None:
        """Zero shot models do not fit on data (purposely ignoring UserInputData if no ground truth)"""
        pass

    def predict_proba(self, X: pd.DataFrame) -> np.ndarray:
        raise NotImplementedError


class ZeroShotPromptedModel(ZeroShotModel):
    """A base prompted model (text-based) that uses the label mapping in ZSL"""

    def __init__(
        self,
        label_map: Optional[Dict[str, int]] = None,
        labels_to_targets: Optional[Dict[str, List[str]]] = None,
    ) -> None:
        """
        Parameters
        ----------
        label_map
            A map of labels to predicted GT values.
        labels_to_targets
            A map of labels to "targets", where a target is any string that
            can represent that label in some semantic sense, depending on
            the child class. If not passed, will use just the names of the
            labels from the label_map

            ex: For the basic text match case, a target for a label is any
                string that will cause the model to vote for that label if
                found in the text for that row.
        """
        super().__init__()

        if not label_map:
            raise UserInputError(
                "Model selected requires a label_map as argument",
                user_friendly_message="Model selected requires label_map input",
            )

        if labels_to_targets is None:
            labels_to_targets = {
                label: [label]
                for label, label_num in label_map.items()
                if label_num != -1
            }

        self.label_map = label_map.copy()
        self.labels_to_targets = labels_to_targets.copy()

        if -1 not in self.label_map.values():
            self.label_map["UNKNOWN"] = -1

        self.unknown_label = [
            label for label, label_num in self.label_map.items() if label_num == -1
        ][0]

        logger.info(
            f"Creating new ZSL Labeler for labels: {','.join(label_map.keys())}"
        )

    def predict(self, X: pd.DataFrame) -> np.ndarray:
        # Make sure all columns are text
        validate_col_types(X, col_type="text")

        # TODO: Abstract this out into a _preprocess method or util to more
        #       easily implement batch prediction methods
        text_col = "_tmp_zsl_combined_text_"
        feature_df = combine_text_cols(X, new_col_name=text_col)

        def apply_func(text: str) -> int:
            label = self.predict_single_label(text)
            return self.label_map[label]

        return feature_df[text_col].apply(apply_func).values

    def predict_single_label(self, text: str) -> str:
        """Shortcut to implement this instead of predict and return a single
        label for a single text (not great performance)

        NOTE: Can ignore this and override predict instead
        """
        raise NotImplementedError

    def save(self, dirpath: str) -> None:
        with open_file(self.info_fpath(dirpath), "w") as info_file:
            json.dump(self.info, info_file)

    @classmethod
    def load(cls, dirpath: str) -> BaseModel:
        with open_file(cls.info_fpath(dirpath)) as info_file:
            return cls(**json.load(info_file))

    @staticmethod
    def info_fpath(dirpath: str) -> str:
        """Helper method to return the labels_to_targets path"""
        return os.path.join(dirpath, "zsl_model_info.json")

    @property
    def info(self) -> dict:
        """Helper method to get model info (for storing to disk)"""
        return dict(labels_to_targets=self.labels_to_targets, label_map=self.label_map)


class ZeroShotTextMatchModel(ZeroShotPromptedModel):
    """A model to generate basic text match predictions"""

    def predict_single_label(self, text: str) -> str:
        # Counting total occurences of each label target, and grouping by label
        label_count_map = {
            label: sum([text.lower().count(target.lower()) for target in targets])
            for label, targets in self.labels_to_targets.items()
        }

        if len(label_count_map) == 0 or max(label_count_map.values()) == 0:
            # No targets found
            return self.unknown_label

        else:
            # Return label (key) with max target count
            # TODO: Implement some tie-breaking logic
            return max(label_count_map, key=label_count_map.get)  # type: ignore
