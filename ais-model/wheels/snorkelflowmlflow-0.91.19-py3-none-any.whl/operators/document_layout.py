import logging
import os
import shutil
import tempfile
import time
from typing import Any, List, Optional, Tuple

import layoutparser as lp
import pandas as pd

from api_utils.exceptions import UserInputError
from file_utils.core import open_file
from snorkelflow.operators.featurizer import Featurizer, OpProgressCallback
from snorkelflow.operators.operator import ColSchema, no_op_progress_callback
from snorkelflow.rich_docs import BOTTOM, LEFT, RIGHT, TOP, DocumentLayout, RichDocCols
from snorkelflow.rich_docs.rich_doc_utils import convert_pdf_to_image
from snorkelflow.utils.file import resolve_data_path
from snorkelflow.utils.logging import get_logger

logger = get_logger("DocumentLayoutFeaturizer")


MODEL_NAMES = [
    "TableBank/faster_rcnn_R_50_FPN_3x",
    "TableBank/faster_rcnn_R_101_FPN_3x",
]

LABEL_MAPS = {
    "TableBank": {0: "Table"},
    "PubLayNet": {0: "Text", 1: "Title", 2: "List", 3: "Table", 4: "Figure"},
    "HJDataset": {
        1: "Page Frame",
        2: "Row",
        3: "Title Region",
        4: "Text Region",
        5: "Title",
        6: "Subtitle",
        7: "Other",
    },
    "PrimaLayout": {
        1: "TextRegion",
        2: "ImageRegion",
        3: "TableRegion",
        4: "MathsRegion",
        5: "SeparatorRegion",
        6: "OtherRegion",
    },
    "NewspaperNavigator": {
        0: "Photograph",
        1: "Illustration",
        2: "Map",
        3: "Comics/Cartoon",
        4: "Editorial Cartoon",
        5: "Headline",
        6: "Advertisement",
    },
    "MFD": {1: "Equation"},
}


def normalize_coordinates(
    coordinates: List[Tuple[float, ...]], dim: Tuple[int, int]
) -> List[Tuple[float, ...]]:
    """Normalizes coordinates."""
    width, height = dim
    return [
        (c[0] / width, c[1] / height, c[2] / width, c[3] / height) for c in coordinates
    ]


def denormalize_coordinates(
    coordinates: List[Tuple[float, ...]], dim: Tuple[int, int]
) -> List[Tuple[float, ...]]:
    """Denormalizes normalized coordinates to desired image dimensions."""
    width, height = dim
    return [
        (c[0] * width, c[1] * height, c[2] * width, c[3] * height) for c in coordinates
    ]


def scale_coordinates(
    coordinates: List[Tuple[float, ...]],
    original_dim: Tuple[int, int],
    new_dim: Tuple[int, int],
) -> List[Tuple[int, ...]]:
    """
    Scales coordinates by normalizing by original dimension and then denormalizing to desired dimension. Return format
    is a list of tuples of integers.
    """
    original_width, original_height = original_dim
    new_width, new_height = new_dim
    return [
        (
            int(c[0] * new_width / original_width),
            int(c[1] * new_height / original_height),
            int(c[2] * new_width / original_width),
            int(c[3] * new_height / original_height),
        )
        for c in coordinates
    ]


class DocumentLayoutFeaturizer(Featurizer):
    """Operator that detects layout and structures in a RichDocument.

    Parameters
    ----------
    field
        The field containing the PDF path.
    model
        The model to use for layout detection. Options are "TableBank/faster_rcnn_R_50_FPN_3x" and "TableBank/faster_rcnn_R_101_FPN_3x".
    resolution_px
        The the input resolution of the image in DPI.
    confidence_threshold
        The confidence threshold to be used to filter the prediction.
    pages_field
        The field containing the page indices to run layout detection on. If None, will run on all pages.
    """

    is_expensive = True
    show_args_in_gui: bool = True

    def __init__(
        self,
        field: str = "rich_doc_pdf_url",
        model: str = MODEL_NAMES[0],
        resolution_px: int = 600,
        confidence_threshold: float = 0.8,
        pages_field: Optional[str] = None,
    ):
        if resolution_px <= 0:
            err_msg = f"Resolution px input in DocumentLayoutFeaturizer must be an integer greater than 0, got {resolution_px}"
            raise UserInputError(detail=err_msg, user_friendly_message=err_msg)

        # field should correspond to the pdf_path
        self.field: str = field
        self.model_name: str = model
        self.resolution_px: int = resolution_px
        self.confidence_threshold: float = confidence_threshold
        self.pages_field: Optional[str] = pages_field

    @property
    def input_schema(self) -> ColSchema:
        input_schema: ColSchema = {self.field: str}
        if self.pages_field:
            input_schema[self.pages_field] = None
        return input_schema

    @property
    def output_schema(self) -> ColSchema:
        return {RichDocCols.LAYOUT_STRUCTURE_BBOXS: None}

    def _get_layout_from_image(
        self, image_path: str, dim: Tuple[int, int]
    ) -> pd.DataFrame:
        """
        Generates layout given an image path, and the dimenions of the original PDF. Will determine all
        structures in the image and convert to original PDF dimension with the bounding box, confidence score,
        and structure type.
        """
        import cv2

        image = cv2.imread(image_path)
        height, width = image.shape[:2]

        layout = self.model.detect(image)
        block_coordinates = [lb.coordinates for lb in layout]
        scaled_coordinates = scale_coordinates(block_coordinates, (width, height), dim)

        ret_val = pd.DataFrame(
            scaled_coordinates, columns=[LEFT, TOP, RIGHT, BOTTOM]
        ).sort_values(by=LEFT)

        ret_val["confidence"] = [t.score for t in layout]
        ret_val["structure_type"] = [t.type for t in layout]
        return ret_val

    def _get_layout_from_pdf(
        self,
        pdf_path: str,
        page_indices: List[int],
        pdf_dimensions: List[Tuple[int, int]],
    ) -> List[pd.DataFrame]:
        """
        Converts the given page number to image, and then identifies structures in the image and scales coordinates to match
        original PDF dimensions.
        """
        tables: List[pd.DataFrame] = []

        try:
            # Finding predictions on pages in pages field
            if self.pages_field:
                for index in range(len(page_indices)):
                    page_index = page_indices[index]
                    with convert_pdf_to_image(
                        pdf_path=pdf_path,
                        start_page=page_index + 1,
                        end_page=page_index + 1,
                        dpi=300,
                    ) as img_dir:
                        img_path = os.path.join(img_dir, f"{page_index+1}.jpg")
                        structure = self._get_layout_from_image(
                            img_path, pdf_dimensions[index]
                        )
                        structure["page_index"] = page_index
                        tables.append(structure)
            else:
                # Finding predictions on all pages
                with convert_pdf_to_image(pdf_path=pdf_path, dpi=300) as img_dir:
                    for index in page_indices:
                        img_path = os.path.join(img_dir, f"{index+1}.jpg")
                        structure = self._get_layout_from_image(
                            img_path, pdf_dimensions[index]
                        )
                        structure["page_index"] = index
                        tables.append(structure)

            return tables
        except Exception as e:
            logging.error(str(e))
            empty_df = pd.DataFrame([], columns=[LEFT, TOP, RIGHT, BOTTOM]) * (
                len(page_indices)
            )
            return empty_df

    def _add_layout_structure(
        self, pdf_path: str, index: Any, page_indices: Optional[List[int]]
    ) -> pd.Series:
        """
        Generates layout given a PDF path, and the dimensions of the original PDF. Will determine all
        structures in the image and convert to original PDF dimension with the bounding box, confidence score,
        and structure type.
        """
        import pdfplumber

        start_time = time.time()
        with tempfile.TemporaryDirectory() as tmp_dir:
            file_name = os.path.split(pdf_path)[-1]
            dest_file = os.path.join(tmp_dir, file_name)
            with open_file(resolve_data_path(pdf_path), "rb") as src_f, open(
                dest_file, "wb"
            ) as dest_f:
                shutil.copyfileobj(src_f, dest_f)
                pdf = pdfplumber.open(src_f)

                if page_indices is None:
                    page_indices = list(range(len(pdf.pages)))
                    dimensions = [(int(p.width), int(p.height)) for p in pdf.pages]
                else:
                    # Verify page indices exist in PDF
                    if not all([0 <= item <= len(pdf.pages) for item in page_indices]):
                        message = "Error using DocumentLayoutFeaturizer. Page indices not found in PDF"
                        detail = "Page indices: {} not found in PDF: {}".format(
                            page_indices, pdf_path
                        )
                        how_to_fix = "Please update page indices."
                        raise UserInputError(
                            user_friendly_message=message,
                            detail=detail,
                            how_to_fix=how_to_fix,
                        )

                    dimensions = [
                        (
                            int(pdf.pages[page_index].width),
                            int(pdf.pages[page_index].height),
                        )
                        for page_index in page_indices
                    ]

            structures: List[pd.DataFrame] = self._get_layout_from_pdf(
                pdf_path=dest_file, page_indices=page_indices, pdf_dimensions=dimensions
            )

        logger.info(
            f"LayoutFeauturizer took {time.time() - start_time} for pdf={pdf_path}, index={index}"
        )
        return pd.Series(
            {RichDocCols.LAYOUT_STRUCTURE_BBOXS: DocumentLayout(structures)}
        )

    def _compute_features(
        self,
        input_df: pd.DataFrame,
        callback: OpProgressCallback = no_op_progress_callback,
    ) -> pd.DataFrame:
        """Override base class method"""
        self.model = lp.Detectron2LayoutModel(
            f"lp://{self.model_name}/config",
            label_map=LABEL_MAPS[self.model_name.split("/")[0]],
            extra_config=[
                "MODEL.ROI_HEADS.SCORE_THRESH_TEST",
                self.confidence_threshold,
                "INPUT.MAX_SIZE_TEST",
                self.resolution_px,
            ],
        )

        return input_df.apply(
            lambda row: self._add_layout_structure(
                pdf_path=row[self.field],
                index=row.name,
                page_indices=row[self.pages_field] if self.pages_field else None,
            ),
            axis=1,
        )
