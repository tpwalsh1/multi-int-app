from snorkelflow.operators.featurizer import Featurizer
from snorkelflow.operators.fixed_datapoint import Filter


class IdentityOperator(Featurizer, Filter):
    """No-op operator"""

    input_schema = None
    output_schema = None
