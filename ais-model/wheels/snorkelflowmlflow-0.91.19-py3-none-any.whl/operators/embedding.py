import hashlib
import inspect
import json
from typing import Callable, Dict, List, Optional

import pandas as pd

from api_utils.exceptions import UserInputError
from embeddings.text import EMBEDDING_FNS
from operators.types import BuiltInOperators
from snorkelflow.operators.featurizer import (
    Featurizer,
    OpProgressCallback,
    cache_features,
)
from snorkelflow.operators.operator import (
    ColSchema,
    OperatorExample,
    no_op_progress_callback,
)
from snorkelflow.types.performance import Performance
from snorkelflow.utils.logging import get_logger

logger = get_logger("EmbeddingFeaturizer")


class EmbeddingFeaturizerBase(Featurizer):
    """Featurizer that converts data to an embedding."""

    is_expensive = True

    def __init__(
        self, embedding_fn: Callable, field: str, target_field: Optional[str] = None
    ) -> None:
        self.field = field
        self.target_field = target_field or f"{field}_embedding"
        self.embedding_fn = embedding_fn

    @property
    def input_schema(self) -> ColSchema:
        return {self.field: str}

    @property
    def output_schema(self) -> ColSchema:
        return {self.target_field: List[float]}

    @property
    def use_gpu_if_available(self) -> bool:
        return True

    @cache_features
    def _compute_features(
        self,
        input_df: pd.DataFrame,
        callback: OpProgressCallback = no_op_progress_callback,
    ) -> pd.DataFrame:
        """Override base class method"""
        self.target_field = self.target_field or f"{self.field}_embedding"
        embeddings: List[List[float]] = self.embedding_fn(
            input_df[self.field], callback
        )
        input_df[self.target_field] = embeddings
        return input_df

    def get_featurizer_hash(self) -> str:
        def get_function_hash(func: Callable) -> str:
            source = inspect.getsource(func)
            return hashlib.md5(source.encode("utf-8")).hexdigest()

        return get_function_hash(self.embedding_fn) + str(self.operator_impl_version)


class EmbeddingCandidateFeaturizerBase(Featurizer):
    """Featurizer that converts data to an embedding."""

    is_expensive = True

    def __init__(
        self,
        embedding_fn: Callable,
        field: str,
        candidate_field: str,
        target_field: Optional[str] = None,
    ) -> None:
        self.field = field
        self.candidate_field = candidate_field
        self.target_field = target_field or f"{candidate_field}_embedding"
        self.embedding_fn = embedding_fn

    @property
    def input_schema(self) -> ColSchema:
        return {self.field: str, self.candidate_field: List[Dict[str, int]]}

    @property
    def output_schema(self) -> ColSchema:
        return {self.target_field: List[float]}

    @property
    def use_gpu_if_available(self) -> bool:
        return True

    def _compute_features(
        self,
        input_df: pd.DataFrame,
        callback: OpProgressCallback = no_op_progress_callback,
    ) -> pd.DataFrame:
        """Override base class method"""
        text_col = input_df[self.field]
        text_cands = []
        text_cands_idxs = []
        for idx, cands in enumerate(input_df[self.candidate_field]):
            text_field = text_col.iloc[idx]
            for c in cands:
                text_cands.append(text_field[c["start"] : c["end"] + 1])
                text_cands_idxs.append(idx)
        embeddings: List[List[float]] = self.embedding_fn(pd.Series(text_cands))
        grouped_embeddings: List[List[List[float]]] = [[] for _ in range(len(input_df))]
        for emb, text_cand_idx in zip(embeddings, text_cands_idxs):
            grouped_embeddings[text_cand_idx].append(emb)
        input_df[self.target_field] = grouped_embeddings
        return input_df

    def get_featurizer_hash(self) -> str:
        def get_function_hash(func: Callable) -> str:
            source = inspect.getsource(func)
            return hashlib.md5(source.encode("utf-8")).hexdigest()

        return get_function_hash(self.embedding_fn) + str(self.operator_impl_version)


class EmbeddingFeaturizer(EmbeddingFeaturizerBase):
    """Featurizer that converts text to an embedding.

    Parameters
    ----------
    field
        The name of the column containing the text to embed
    target_field
        The name of the column to store the embedding in
    embedding_type
        The type of embedding to use. Options are "simcse" and "spacy".
    """

    operator_impl_version: int = 1

    def __init__(
        self,
        field: str,
        target_field: Optional[str] = None,
        embedding_type: str = "simcse",
    ) -> None:
        self.embedding_type = embedding_type
        if embedding_type not in EMBEDDING_FNS:
            message = f"Invalid embedding type {embedding_type}: Must be in {list(EMBEDDING_FNS.keys())}"
            raise UserInputError(detail=message, user_friendly_message=message)
        self.embedding_fn = EMBEDDING_FNS[embedding_type]
        super().__init__(self.embedding_fn, field, target_field)

    @staticmethod
    def get_options() -> Dict[str, List[str]]:
        return dict(embedding_type=list(EMBEDDING_FNS.keys()))

    def estimate_perf(self, df: pd.DataFrame) -> Performance:
        total_len = df[self.field].map(len).sum()
        if self.embedding_type == "simcse":
            # The dependence on doc length is a bit odd here, something sublinear
            # Use a linear upper bound on number of docs instead.
            return Performance(compute_time_secs=len(df) * 5, peak_memory_mb=3000)
        elif self.embedding_type == "spacy":
            return Performance(
                compute_time_secs=total_len * 0.0003, peak_memory_mb=4000
            )
        else:
            raise KeyError(
                f"Estimated perf numbers not available for provided embedding model: {self.embedding_type}."
            )

    def estimate_gpu_perf(self, df: pd.DataFrame) -> Performance:
        total_len = df[self.field].map(len).sum()
        if self.embedding_type == "simcse":
            # The dependence on doc length is a bit odd here, something sublinear
            # Use a linear upper bound on number of docs instead.
            return Performance(compute_time_secs=len(df) * 4 + 25, peak_memory_mb=10000)
        elif self.embedding_type == "spacy":
            return Performance(
                compute_time_secs=total_len * 0.0003, peak_memory_mb=4000
            )
        else:
            raise KeyError(
                f"Estimated gpu perf numbers not available for provided embedding model: {self.embedding_type}."
            )


class EmbeddingCandidateFeaturizer(EmbeddingCandidateFeaturizerBase):
    """Featurizer that converts text to an embedding."""

    def __init__(
        self,
        field: str,
        candidate_field: str,
        target_field: Optional[str] = None,
        embedding_type: str = "simcse",
    ) -> None:
        self.embedding_type = embedding_type
        if embedding_type not in EMBEDDING_FNS:
            message = f"Invalid embedding type {embedding_type}: Must be in {list(EMBEDDING_FNS.keys())}"
            raise UserInputError(detail=message, user_friendly_message=message)
        self.embedding_fn = EMBEDDING_FNS[embedding_type]
        super().__init__(self.embedding_fn, field, candidate_field, target_field)

    @staticmethod
    def get_options() -> Dict[str, List[str]]:
        return dict(embedding_type=list(EMBEDDING_FNS.keys()))


class RegisterCustomEmbedding(Featurizer):
    """
    Featurizer that registers an existing column as an embedding, so that it can be used
    in cluster view.

    This also does some validation of the embedding column, ensuring that
    it is a list of floats per row.

    Parameters
    ----------
    embedding_operator_type: str
        The operator type to register the embedding as. Must be one of
        [EmbeddingFeaturizer, EmbeddingCandidateFeaturizer, ImageEmbeddingFeaturizer]
    embedding_vector_field: str
        The name of the column containing the embedding vectors
    embedding_source_field: str
        The name of the column containing the text that the embedding was generated from
    embedding_source_candidate_field: Optional[str]
        The name of the column containing the candidate text that the embedding was generated from
    """

    def __init__(
        self,
        embedding_operator_type: str,
        embedding_vector_field: str,
        embedding_source_field: str,
        embedding_source_candidate_field: Optional[str] = None,
    ) -> None:
        self.embedding_operator_type = embedding_operator_type
        self.embedding_vector_field = embedding_vector_field
        self.embedding_source_field = embedding_source_field
        self.embedding_source_candidate_field = embedding_source_candidate_field

    @staticmethod
    def get_options() -> Dict[str, List[str]]:
        return dict(
            embedding_operator_type=[
                BuiltInOperators.EmbeddingFeaturizer,
                BuiltInOperators.EmbeddingCandidateFeaturizer,
                BuiltInOperators.ImageEmbeddingFeaturizer,
            ]
        )

    @property
    def input_schema(self) -> ColSchema:
        return {}

    @property
    def output_schema(self) -> ColSchema:
        return {self.embedding_vector_field: List[float]}

    def _compute_features(
        self,
        input_df: pd.DataFrame,
        callback: OpProgressCallback = no_op_progress_callback,
    ) -> pd.DataFrame:
        """The register embedding featurizer does not compute any features. instead,
        it just registers an embedding node in the DAG to make cluster view available"""
        # Attempt to convert the embedding_vector_field to a list of floats
        # If this fails, then the user has not provided a valid embedding vector
        try:
            if type(input_df[self.embedding_vector_field][0]) != list:
                # Try to convert to a list, using json.loads
                try:
                    input_df[self.embedding_vector_field] = input_df[
                        self.embedding_vector_field
                    ].apply(lambda x: json.loads(x))
                except Exception:
                    # If it's not json encoded, it is hopefully a list of floats
                    pass

            # Check that all values are lists
            if not all(
                type(input_df[self.embedding_vector_field][i]) == list
                for i in range(len(input_df))
            ):
                raise UserInputError(
                    detail=f"Invalid embedding vector provided in {self.embedding_vector_field}.",
                    user_friendly_message="Invalid embedding vector provided.",
                    how_to_fix="Ensure your embedding vector column has a list of floats, and there are no missing values.",
                )

            # Check that all lists have the same length
            first_vector_len = len(input_df[self.embedding_vector_field][0])
            if not all(
                len(input_df[self.embedding_vector_field][i]) == first_vector_len
                for i in range(len(input_df))
            ):
                raise UserInputError(
                    detail=f"Inconsistent embedding lengths in field {self.embedding_vector_field}. Expected {first_vector_len} dim based on first vector.",
                    user_friendly_message=f"Inconsistent embedding lengths in field {self.embedding_vector_field}.",
                    how_to_fix="Ensure that all embedding vectors have the same length (and are not empty).",
                )

            # Try converting all values in each list to float
            try:
                input_df[self.embedding_vector_field] = input_df[
                    self.embedding_vector_field
                ].apply(lambda x: [float(i) for i in x])
            except Exception:
                raise UserInputError(
                    detail=f"Vector field {self.embedding_vector_field} does not contain only floats.",
                    user_friendly_message="Invalid embedding vector provided.",
                    how_to_fix="Ensure your embedding vector column has a list of floats, and there are no missing values.",
                )

            return input_df
        except Exception:
            raise UserInputError(
                detail=f"Invalid embedding vector provided in {self.embedding_vector_field}.",
                user_friendly_message="Invalid embedding vector provided.",
                how_to_fix="Ensure your embedding vector column has a list of floats, and there are no missing values.",
            )

    @staticmethod
    def examples() -> List[OperatorExample]:
        return [
            OperatorExample(
                input_df=dict(
                    text=["This is a sentence", "Another sentence"],
                    embedding_col=[[0.5, 0.3, 0.1], [0.9, 0.5, 0.1]],
                ),
                kwargs=dict(
                    embedding_operator_type="EmbeddingFeaturizer",
                    embedding_vector_field="embedding_col",
                    embedding_source_field="text",
                ),
            )
        ]
