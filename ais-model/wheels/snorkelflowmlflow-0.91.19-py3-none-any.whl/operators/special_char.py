import pandas as pd
import re2

from snorkelflow.operators.featurizer import Featurizer, OpProgressCallback
from snorkelflow.operators.operator import ColSchema, no_op_progress_callback


class SpecialCharFilter(Featurizer):
    """A base class that provides a function to remove special char from text"""

    def __init__(self, field: str) -> None:
        self.field = field
        self.target_field = f"{field}"  # overwrite the input col by default for better compatability in seq tagging task

    @property
    def input_schema(self) -> ColSchema:
        return {self.field: str}

    @property
    def output_schema(self) -> ColSchema:
        return {self.target_field: str}

    def remove_special_char(self, text: str) -> str:
        pass

    def _compute_features(
        self,
        input_df: pd.DataFrame,
        callback: OpProgressCallback = no_op_progress_callback,
    ) -> pd.DataFrame:
        """Override base class method"""
        remove_func = lambda x: self.remove_special_char(str(x))
        input_df[self.target_field] = input_df[self.field].map(
            remove_func, na_action="ignore"
        )
        return input_df


class AsciiCharFilter(SpecialCharFilter):
    """Preprocessor that removes non-ascii chars from selected column in place."""

    def remove_special_char(self, text: str) -> str:
        return text.encode("ascii", "ignore").decode("ascii")


class LatinCharFilter(SpecialCharFilter):
    """Preprocessor that removes non-latin chars from selected column in place. The following unicode ranges are not filtered: Basic_Latin: U+0000–U+007F; Latin-1_Supplement: U+0080–U+00FF; Latin_Extended-A: U+0100–U+017F; Latin_Extended-B: U+0180–U+024F; Latin_Extended_Additional: U+1E00–U+1EFF."""

    # ranges based on https://jrgraphix.net/r/Unicode/
    def remove_special_char(self, text: str) -> str:
        return re2.sub(
            "[^\x00-\x7F\x80-\xFF\u0100-\u017F\u0180-\u024F\u1E00-\u1EFF]", "", text
        )
