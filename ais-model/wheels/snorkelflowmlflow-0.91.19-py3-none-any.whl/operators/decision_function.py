from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

from operators.model import Model
from snorkelflow.models.sklearn import TrainedMultiLabelSklearnModel
from snorkelflow.operators.featurizer import OpProgressCallback
from snorkelflow.operators.operator import no_op_progress_callback
from snorkelflow.types.model import ModelCols
from snorkelflow.utils.logging import get_logger

logger = get_logger("DecisionFunctionFeaturizer")


class DecisionFunctionFeaturizer(Model):
    """
    Featurizer that computes the decision function of a model.
    Currently only supports sklearn models or models that implement a decision_function method.
    Currently only implements logic for the multi-label sklearn model.
    Reference snorkelflow.models.sklearn for the implementation.

    Parameters
    ----------
    model_name
        Assign name to the trained model
    dirpath
        The path to the directory where the pickled model (and additional
        info) is stored
    label_map
        The map of the labels to their integer representation
    label_space_config
        An optional configuration for the label space
    model_class_pickle
        An optional model class pickle
    embedding_field
        OPTIONAL: This is the embedding field that we take in to feed into
        the model for embeddings-based apps. Currently most applicable to
        Images apps.
    """

    @property
    def output_schema(self) -> Dict[str, Any]:
        return {ModelCols.DECISION_FUNCTION: List[float]}

    def _compute_features(
        self,
        input_df: pd.DataFrame,
        callback: OpProgressCallback = no_op_progress_callback,
    ) -> pd.DataFrame:
        model = self._get_loaded_model()
        if not isinstance(model, TrainedMultiLabelSklearnModel):
            raise TypeError(
                "DecisionFunctionFeaturizer is currently only supported for the multi-label sklearn model"
            )
        preds, probs = self._predict_decision_fn(model, input_df)
        if probs is None:
            probs = np.full(preds.shape, None)
        input_df[ModelCols.DECISION_FUNCTION] = probs.tolist()

        # Cast these columns explicitly intead of using meta in map_partitions,
        # in case the, given the model lib may add unexpected columns.
        return input_df.astype({ModelCols.DECISION_FUNCTION: object})

    def _compute_features_embedding(
        self, input_df: pd.DataFrame, embeddings: Optional[np.ndarray] = None
    ) -> pd.DataFrame:
        model = self._get_loaded_model()

        if not isinstance(model, TrainedMultiLabelSklearnModel):
            raise TypeError(
                "DecisionFunctionFeaturizer is currently only supported for the multi-label sklearn model"
            )

        probs = model.model.decision_function(embeddings)
        _, probs = self._postprocess(model, probs)
        input_df[ModelCols.DECISION_FUNCTION] = probs.tolist()
        return input_df.astype({ModelCols.DECISION_FUNCTION: object})

    def _predict_decision_fn(
        self, model: TrainedMultiLabelSklearnModel, df: pd.DataFrame
    ) -> Tuple[np.ndarray, Optional[np.ndarray]]:
        if not len(df):
            logger.info("Received empty dataframe, returning empty predictions.")
            return np.empty([0], "object"), np.empty([0, model.n_classes], "float64")
        logger.info("Featurizing data fields.")
        X = model.vectorizer.transform(df)

        if model.sklearn_preprocessor is not None:
            logger.info("Applying sklearn preprocessor.")
            X = model.sklearn_preprocessor.transform(X)

        logger.info(f"Performing inference on {X.shape} shape features.")
        probs = model.model.decision_function(X)
        return self._postprocess(model, probs)

    def _postprocess(
        self, model: TrainedMultiLabelSklearnModel, probs: List
    ) -> Tuple[np.ndarray, List]:
        """Predict and return in the raw label values format for MultiLabelSpace.

        NOTE: These values will get zipped with x_uids to return a RawLabel format.
        """
        if not model.n_classes:
            raise ValueError("Model must have n_classes set.")
        if model.invalid_class_default_prob is None:
            raise ValueError("Model must have invalid_class_default_prob set.")

        if not isinstance(probs[0], (list, np.ndarray)):
            probs = [probs]

        n_examples = len(probs[0])
        prob_idx_to_label_int = model.prob_idx_to_label_int or {
            i: i for i in range(model.n_classes)
        }
        dense_probs = np.zeros((n_examples, model.n_classes))
        for prob_idx, label_int in prob_idx_to_label_int.items():
            dense_probs[:, label_int] = probs[prob_idx]

        for class_int, default_prob in model.invalid_class_default_prob.items():
            dense_probs[:, class_int] = default_prob
        preds = model._probs_to_preds(dense_probs)
        return preds, np.array(dense_probs)
