from typing import List

import pandas as pd

from api_utils.exceptions import UserInputError
from snorkelflow.operators.fixed_datapoint import ChangeColumns
from snorkelflow.operators.operator import OperatorExample


class ColumnDropper(ChangeColumns):
    """
    Processor that drops given columns from the DataFrame.

    Given a list of column names, this operator will drop those columns from
    the passing DataFrame. Invalid fields will be ignored.

    Parameters
    ----------
    fields
        The list of columns to be dropped
    """

    def __init__(self, fields: List[str]) -> None:
        if not fields or not isinstance(fields, list):
            err_msg = f"No fields were selected in the Fields input in ColumnDropper"
            raise UserInputError(
                detail=err_msg,
                user_friendly_message=err_msg,
                how_to_fix="Please select one or more fields in the Fields input dropdown",
            )
        self._fields = fields

    @property
    def input_schema(self) -> None:
        return None

    @property
    def output_schema(self) -> None:
        return None

    @property
    def drop_schema(self) -> List[str]:
        return self._fields

    @staticmethod
    def examples() -> List[OperatorExample]:
        return [
            OperatorExample(
                input_df=dict(
                    counts=[10, 20, 30],
                    names=["John", "Manas", "Naveen"],
                    teams=["MLF", "Lifecycle", "Studio"],
                ),
                kwargs=dict(fields=["counts", "names", "invalid_column"]),
            )
        ]

    def _execute_pandas(self, input_df: pd.DataFrame) -> pd.DataFrame:
        """Override base class method"""
        for field in self._fields:
            if field in input_df:
                input_df = input_df.drop(field, axis=1)
        return input_df
