import ast
import json
from typing import Any, List

import dask.dataframe as dd
import numpy as np
import pandas as pd

from api_utils.exceptions import UserInputError
from snorkelflow.extraction.span import SpanCols
from snorkelflow.operators import Operator
from snorkelflow.operators.featurizer import Featurizer, OpProgressCallback
from snorkelflow.operators.operator import (
    ColSchema,
    df_operator_error_wrapper,
    no_op_progress_callback,
)
from snorkelflow.types.columns import RelationClassificationCols
from snorkelflow.types.load import DATAPOINT_UID_COL
from snorkelflow.utils.datapoint import Datapoint, DatapointType

# Make some variables for column names for perf
CHAR_START_1 = f"{SpanCols.CHAR_START}_1"
CHAR_END_1 = f"{SpanCols.CHAR_END}_1"
CHAR_START_2 = f"{SpanCols.CHAR_START}_2"
CHAR_END_2 = f"{SpanCols.CHAR_END}_2"


class RelationContextFeaturizer(Featurizer):
    """Featurizer that adds features for text between entities, text to the left of first entity, and text to the right of second entity.

    Parameters
    ----------
    sentence_field
        Name of the field which contains the sentence
    entity_spans_field
        Name of the field which contains entity spans
    """

    def __init__(self, sentence_field: str, entity_spans_field: Any) -> None:
        self._sentence_field = sentence_field
        self._entity_spans_field = entity_spans_field

        if not sentence_field:
            err_msg = (
                "Sentence field input in RelationContextFeaturizer must be non empty"
            )
            raise UserInputError(detail=err_msg, user_friendly_message=err_msg)

        if not entity_spans_field:
            err_msg = "Entity spans field input in RelationContextFeaturizer must be non empty"
            raise UserInputError(detail=err_msg, user_friendly_message=err_msg)

    @property
    def input_schema(self) -> ColSchema:
        return {self._sentence_field: str, self._entity_spans_field: str}

    @property
    def output_schema(self) -> ColSchema:
        return {
            RelationClassificationCols.TEXT_BETWEEN: str,
            RelationClassificationCols.TEXT_LEFT_OF_ENTITY1: str,
            RelationClassificationCols.TEXT_RIGHT_OF_ENTITY2: str,
        }

    def _compute_features(
        self,
        input_df: pd.DataFrame,
        callback: OpProgressCallback = no_op_progress_callback,
    ) -> pd.DataFrame:
        """Override base class method"""

        # entity_spans list of tuples is stored as string, need to convert back
        def _get_text_between(sentence: str, entity_span: str) -> str:
            entity_span = ast.literal_eval(entity_span)
            assert isinstance(entity_span, list)  # mypy
            return "".join(sentence[entity_span[0][1] : entity_span[1][0]])

        def _get_text_left_of_entity1(sentence: str, entity_span: str) -> str:
            entity_span = ast.literal_eval(entity_span)
            assert isinstance(entity_span, list)  # mypy
            return "".join(sentence[: entity_span[0][0]])

        def _get_text_right_of_entity2(sentence: str, entity_span: str) -> str:
            entity_span = ast.literal_eval(entity_span)
            assert isinstance(entity_span, list)  # mypy
            return "".join(sentence[entity_span[1][1] :])

        input_df[RelationClassificationCols.TEXT_BETWEEN] = input_df.apply(
            lambda x: _get_text_between(
                x[self._sentence_field], x[self._entity_spans_field]
            ),
            axis=1,
        )
        input_df[RelationClassificationCols.TEXT_LEFT_OF_ENTITY1] = input_df.apply(
            lambda x: _get_text_left_of_entity1(
                x[self._sentence_field], x[self._entity_spans_field]
            ),
            axis=1,
        )
        input_df[RelationClassificationCols.TEXT_RIGHT_OF_ENTITY2] = input_df.apply(
            lambda x: _get_text_right_of_entity2(
                x[self._sentence_field], x[self._entity_spans_field]
            ),
            axis=1,
        )

        return input_df


class RelationGenerator(Operator):
    """Generates binary relations using the cross product of spans within the same context_uid.

    Generated relations (entity_1, entity_2) are ones between two entity spans of the same context_uid that meet the following conditions:

    1. The char_start of entity_1 is smaller than that of entity_2, and they are within char_window.
    2. The value at all of the fields_to_determine_duplicates is different between two entities.

    Parameters
    ----------
    sentence_field
        The sentence field
    fields_to_determine_duplicates
        List of fields to determine duplicates of two entities. If the value is the same at any one of the fields, don't generate such a relation.
    char_window
        The size of window (in characters), defaults to 200
    """

    operator_impl_version: int = 0

    def __init__(
        self,
        sentence_field: str,
        fields_to_determine_duplicates: List[str],
        char_window: int = 200,
    ) -> None:
        self._sentence_field = sentence_field
        self._fields_to_determine_duplicates = fields_to_determine_duplicates
        if char_window <= 0:
            msg = "char_window must be positive."
            raise UserInputError(detail=msg, user_friendly_message=msg)
        self._char_window = char_window
        self._cols_1 = [f"{field}_1" for field in fields_to_determine_duplicates]
        self._cols_2 = [f"{field}_2" for field in fields_to_determine_duplicates]

    @property
    def input_schema(self) -> ColSchema:
        return {
            self._sentence_field: str,
            SpanCols.CONTEXT_UID: int,
            SpanCols.CHAR_START: int,
            SpanCols.CHAR_END: int,
            SpanCols.SPAN_TEXT: str,
            **{k: None for k in self._fields_to_determine_duplicates},
        }

    @property
    def output_schema(self) -> ColSchema:
        return {
            self._sentence_field: str,
            RelationClassificationCols.ENTITY_SPANS: None,
        }

    def get_datapoint_instance(
        self, input_datapoint_instances: List[DatapointType]
    ) -> DatapointType:
        return Datapoint(
            columns=[
                SpanCols.CONTEXT_UID,
                CHAR_START_1,
                CHAR_END_1,
                CHAR_START_2,
                CHAR_END_2,
            ]
        )

    def _execute(self, input_ddfs: List[dd.DataFrame]) -> dd.DataFrame:
        def map_fn(input_df: pd.DataFrame) -> pd.DataFrame:
            def cross_product(x: pd.DataFrame) -> pd.DataFrame:
                # Make cross products
                # TODO: (ENG-17029) to make it less memory intensive, use an iterator like itertools.product
                # instead of fully making the cross product then pruning.
                cross_product_df = pd.merge(
                    x,
                    x,
                    on=SpanCols.CONTEXT_UID,
                    suffixes=("_1", "_2"),  # To allow "_n" in the future
                )
                # Filter out these relations
                # 1. self-relation (e.g., [(0, 10), (0, 10)])
                # 2. backward direction (e.g., [(10, 20), (0, 10)])
                # 3. one where two entities are far apart (e.g., [(0, 10), (1000, 1010)])
                # 4. one where two entities have the same value at any one of fields to compare
                #    = filter through ones where two entities don't have the same value at any one of the fields to compare)
                cross_product_df = cross_product_df.loc[
                    cross_product_df.apply(
                        lambda y: y[CHAR_START_1] < y[CHAR_START_2]
                        and y[CHAR_START_2] - y[CHAR_START_1] <= self._char_window
                        and np.all(
                            np.not_equal(
                                y[self._cols_1].to_numpy(), y[self._cols_2].to_numpy()
                            )
                        ),
                        axis=1,
                    ),
                    :,
                ]
                if len(cross_product_df) > 0:
                    # Make entity_spans column and have them JSON serialized
                    cross_product_df[
                        RelationClassificationCols.ENTITY_SPANS
                    ] = cross_product_df.apply(
                        lambda y: json.dumps(
                            [
                                (y[CHAR_START_1], y[CHAR_END_1]),
                                (y[CHAR_START_2], y[CHAR_END_2]),
                            ]
                        ),
                        axis=1,
                    )
                else:
                    cross_product_df[
                        RelationClassificationCols.ENTITY_SPANS
                    ] = pd.Series([], dtype=str)
                return cross_product_df

            # Make cross products within the same context_uid and apply filters
            cross_product_df = cross_product(input_df)

            # Drop one side of self._sentence_field b/c this is common to both spans
            output_df = cross_product_df.drop(
                f"{self._sentence_field}_2", axis=1
            ).rename(columns={f"{self._sentence_field}_1": self._sentence_field})
            # Push the self._sentence_field to the end
            cols = list(output_df.columns)
            cols.remove(self._sentence_field)
            cols.append(self._sentence_field)
            output_df = output_df[cols]

            # Set the index
            datapoint_instance = self.get_datapoint_instance([])
            output_df = output_df.reset_index()

            if len(output_df) > 0:
                output_df[
                    DATAPOINT_UID_COL
                ] = datapoint_instance.get_datapoint_uid_col_pandas(output_df)
            else:
                output_df[DATAPOINT_UID_COL] = pd.Series([], dtype=str)
            return output_df.set_index(DATAPOINT_UID_COL).sort_index()

        # Currently only one input is supported
        ddf = input_ddfs[0]
        col_dict = ddf.dtypes.to_dict()
        context_uid_type = col_dict.pop(SpanCols.CONTEXT_UID)
        sentence_field_type = col_dict.pop(self._sentence_field)
        meta = {
            SpanCols.CONTEXT_UID: context_uid_type,
            **{f"{k}_1": v for k, v in col_dict.items()},
            **{f"{k}_2": v for k, v in col_dict.items()},
            RelationClassificationCols.ENTITY_SPANS: None,
            self._sentence_field: sentence_field_type,
        }
        output_ddf = (
            # Set index before groupby to make groupby fast https://docs.dask.org/en/latest/dataframe-groupby.html
            # Set index with shuffle="tasks" to avoid https://github.com/ray-project/ray/issues/20108
            ddf.set_index(SpanCols.CONTEXT_UID, shuffle="tasks")
            .groupby(SpanCols.CONTEXT_UID, group_keys=False)
            .apply(
                df_operator_error_wrapper(
                    map_fn, self.__class__.__name__, getattr(self, "node_uid", None)
                ),
                meta=meta,
            )
        )
        # Make sure the name of the index is DATAPOINT_UID_COL.
        # When all output_df is empty (ie no relation) at pandas-level, DATAPOINT_UID_COL isn't set as index.
        output_ddf.index = output_ddf.index.rename(DATAPOINT_UID_COL).astype(str)
        return output_ddf
