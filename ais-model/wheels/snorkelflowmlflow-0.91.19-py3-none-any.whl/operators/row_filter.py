from typing import Dict, List, Optional

import pandas as pd
import re2

from api_utils.exceptions import UserInputError
from operators.filter import FilterTypes
from snorkelflow.operators.operator import ColSchema, OperatorExample
from snorkelflow.operators.row_filter import BaseRowFilter
from snorkelflow.rich_docs import RichDocCols
from snorkelflow.types.performance import Performance


class BooleanColumnBasedRowFilter(BaseRowFilter):
    """
    Filters rows based on the specified boolean column.

    This operator allows one to either include or exclude rows based
    on the the boolean values present in a column in the DataFrame.

    Parameters
    ----------
    boolean_col_name
        The name of the dataframe column containing the boolean values used for filtering
    filter_type
        One of ({FilterTypes.INCLUDE}, {FilterTypes.EXCLUDE}), defaults to {FilterTypes.INCLUDE}
    """

    @staticmethod
    def get_options() -> Dict[str, List[str]]:
        return dict(filter_type=[FilterTypes.INCLUDE, FilterTypes.EXCLUDE])

    def __init__(
        self, boolean_col_name: str, filter_type: str = FilterTypes.INCLUDE
    ) -> None:
        self._boolean_col_name = boolean_col_name

        filter_type_options = self.get_options()["filter_type"]
        if filter_type not in filter_type_options:
            err_msg = f"Filter type input in BooleanColumnBasedRowFilter must be one of {filter_type_options}, got {filter_type}"
            raise UserInputError(detail=err_msg, user_friendly_message=err_msg)
        self._filter_type = filter_type

    @property
    def input_schema(self) -> ColSchema:
        return {self._boolean_col_name: bool}

    @staticmethod
    def examples() -> List[OperatorExample]:
        return [
            OperatorExample(
                input_df=dict(
                    text=[
                        "the first string of text",
                        "the second string of text",
                        "a final string of text",
                    ],
                    counts=[12, 24, 36],
                    filters=[True, False, False],
                ),
                kwargs=dict(
                    boolean_col_name="filters", filter_type=FilterTypes.INCLUDE
                ),
            )
        ]

    def _filter_condition(self, df: pd.DataFrame) -> pd.Series:
        if self._filter_type == FilterTypes.INCLUDE:
            return df[self._boolean_col_name]
        return ~df[self._boolean_col_name]


class PandasQueryFilter(BaseRowFilter):
    """
    Includes or excludes rows based on a pandas query

    This operator allows one to specify an arbitary Pandas DataFrame query and have that query applied
    over the input DataFrame, filtering the DataFrame in the process.

    Parameters
    ----------
    query
        The Pandas DataFrame query to perform, see https://pandas.pydata.org/docs/reference/api/pandas.DataFrame.query.html.
    """

    def __init__(self, query: str) -> None:
        self._query = query
        if not query:
            err_msg = "Query input in PandasQueryFilter cannot be empty"
            raise UserInputError(detail=err_msg, user_friendly_message=err_msg)

    @staticmethod
    def examples() -> List[OperatorExample]:
        return [
            OperatorExample(
                input_df=dict(
                    text=[
                        "the first string of text",
                        "the second string of text",
                        "a final string of text",
                    ],
                    counts=[12, 24, 36],
                ),
                kwargs=dict(query="counts >= 24"),
            )
        ]

    def _filter_condition(self, df: pd.DataFrame) -> pd.Series:
        try:
            return df.eval(self._query)
        except Exception as e:
            err_msg = f"Error running PandasQueryFilter with query `{self._query}`. Error : {e}"
            raise UserInputError(
                detail=err_msg,
                user_friendly_message=err_msg,
                how_to_fix="Please fix the query",
            )


class TableRowFilter(BaseRowFilter):
    """A filter that includes all rows with a table."""

    def __init__(self) -> None:
        self._structure_col_name = RichDocCols.LAYOUT_STRUCTURE_BBOXS

    @property
    def input_schema(self) -> ColSchema:
        return {self._structure_col_name: str}

    def _includes_table(self, row: pd.Series) -> bool:
        structures = row[self._structure_col_name].structures
        table_count = sum([len(rd) for rd in structures])
        return table_count > 0

    def _filter_condition(self, df: pd.DataFrame) -> pd.Series:
        return df.apply(self._includes_table, axis=1)


class TextSizeFilter(BaseRowFilter):
    """A filter that excludes rows with a text column larger than specificed size (in KB)

    Used by Sequence Tagging applications to filter large texts

    Parameters
    ----------
    field
        The text field to filter rows on.
    max_text_size
        Maximum text size in KB.
    """

    def __init__(self, field: str, max_text_size: int) -> None:
        self._field = field
        self._max_text_size = max_text_size

    @property
    def input_schema(self) -> ColSchema:
        return {self._field: str}

    @staticmethod
    def examples() -> List[OperatorExample]:
        return [
            OperatorExample(
                input_df=dict(
                    text=[
                        "the first string of text",
                        "the second string of text",
                        "a final string of text",
                    ],
                    uid=[1, 2, 3],
                ),
                kwargs=dict(field="text", max_text_size=10),
            )
        ]

    # Encoding to utf8 because some single characters will require
    # multiple bytes to be represented. Example : 你
    def _utf8_len(self, string: str) -> int:
        return len(string.encode("utf-8"))

    def _filter_condition(self, df: pd.DataFrame) -> pd.Series:
        return df.apply(
            lambda row: not row[self._field]
            or self._utf8_len(row[self._field]) / 1024 <= self._max_text_size,
            axis=1,
        )

    def estimate_perf(self, df: pd.DataFrame) -> Performance:
        data_set_size = df[self._field].map(len).sum()
        return Performance(
            peak_memory_mb=data_set_size * 0.0000004,
            compute_time_secs=data_set_size * 0.00000002,
        )


class RegexRowFilter(BaseRowFilter):
    """
    Filters rows based on the regex pattern provided. This is applied over the `rich_doc_text` field by default.

    This operator allows users to search for a regex pattern over a text field.
    If the regex pattern is not present in the text for a row, the row is dropped from the Pandas DataFrame.

    This operator is commonly used to filter rows (pages or documents) based on keywords in PDF extraction applications.

    Parameters
    ----------
    regex_pattern: str
        The regular expression pattern we use to filter rows
    text_field: str
        The text field over which we perform the regex match
    case_sensitive
        If False, ignore case when considering regular expression matches (defaults to False)
    """

    def __init__(
        self,
        regex_pattern: str,
        text_field: Optional[str] = None,
        case_sensitive: bool = False,
    ) -> None:
        self._regex_pattern = regex_pattern
        self._text_field = text_field or RichDocCols.TEXT_COL
        self._case_sensitive = case_sensitive

        if not regex_pattern:
            err_msg = "Regex pattern input is required for RegexRowFilter"
            raise UserInputError(detail=err_msg, user_friendly_message=err_msg)

        try:
            re2.compile(regex_pattern)
        except Exception:
            err_msg = (
                f"Error running RegexRowFilter with regex pattern `{regex_pattern}`"
            )
            raise UserInputError(
                detail=err_msg,
                user_friendly_message=err_msg,
                how_to_fix="Please enter valid regex",
            )

    @property
    def input_schema(self) -> ColSchema:
        return {self._text_field: str}

    @staticmethod
    def examples() -> List[OperatorExample]:
        return [
            OperatorExample(
                input_df=dict(
                    text=[
                        "the first string of text",
                        "the second string of text",
                        "a final string of text",
                    ]
                ),
                kwargs=dict(regex_pattern="string", text_field="text"),
            )
        ]

    def _filter_condition(self, df: pd.DataFrame) -> pd.Series:
        try:
            query = "{}.str.contains('{}', case={}, regex=True)".format(
                self._text_field, self._regex_pattern, self._case_sensitive
            )

            return df.eval(query)
        except Exception:
            err_msg = f"Error running RegexRowFilter with regex pattern `{self._regex_pattern}` over column `{self._text_field}`"
            raise UserInputError(
                detail=err_msg,
                user_friendly_message=err_msg,
                how_to_fix="Please enter valid inputs",
            )
