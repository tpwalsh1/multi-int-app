from typing import Any, List

import pandas as pd

from api_utils.exceptions import UserInputError
from snorkelflow.operators.featurizer import Featurizer, OpProgressCallback
from snorkelflow.operators.operator import (
    ColSchema,
    OperatorExample,
    no_op_progress_callback,
)


class ColumnFiller(Featurizer):
    """
    Operator that replaces values in either a new or existing column in the DataFrame with the given value

    Parameters
    ----------
    field
        The field whose values will be replaced
    value
        The value to insert into the specified field
    """

    def __init__(self, field: str, value: Any) -> None:
        if not field:
            err_msg = f"Field input in ColumnFiller must be non empty"
            raise UserInputError(detail=err_msg, user_friendly_message=err_msg)

        if not isinstance(value, (int, str, float)):
            err_msg = (
                "Value input in ColumnFiller must be of type int, str or float only"
            )
            raise UserInputError(detail=err_msg, user_friendly_message=err_msg)

        self._field = field
        self._value = value

    @property
    def input_schema(self) -> None:
        return None

    @property
    def output_schema(self) -> ColSchema:
        return {self._field: type(self._value)}

    @staticmethod
    def examples() -> List[OperatorExample]:
        return [
            OperatorExample(
                input_df=dict(
                    text=["some text", "other textual information"], counts=[12, 24]
                ),
                kwargs=dict(field="text", value="replaced value"),
            )
        ]

    def _compute_features(
        self,
        input_df: pd.DataFrame,
        callback: OpProgressCallback = no_op_progress_callback,
    ) -> pd.DataFrame:
        """Override base class method"""
        input_df[self._field] = self._value
        return input_df
