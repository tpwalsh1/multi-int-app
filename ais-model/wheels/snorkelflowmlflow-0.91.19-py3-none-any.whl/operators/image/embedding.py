from typing import Dict, List, Optional

from api_utils.exceptions import UserInputError
from embeddings.image import EMBEDDING_FNS
from operators.embedding import EmbeddingFeaturizerBase
from snorkelflow.utils.logging import get_logger

logger = get_logger("ImageEmbeddingFeaturizer")


class ImageEmbeddingFeaturizer(EmbeddingFeaturizerBase):
    """Featurizer that converts image to an embedding."""

    operator_impl_version: int = 1

    def __init__(
        self,
        field: str,
        target_field: Optional[str] = None,
        embedding_type: str = "clip",
    ) -> None:
        self.embedding_type = embedding_type
        if embedding_type not in EMBEDDING_FNS:
            message = f"Invalid embedding type {embedding_type}: Must be in {list(EMBEDDING_FNS.keys())}"
            raise UserInputError(detail=message, user_friendly_message=message)
        self.embedding_fn = EMBEDDING_FNS[embedding_type]
        super().__init__(self.embedding_fn, field, target_field)

    @staticmethod
    def get_options() -> Dict[str, List[str]]:
        return dict(embedding_type=list(EMBEDDING_FNS.keys()))
