import pandas as pd

from snorkelflow.operators.featurizer import Featurizer, OpProgressCallback
from snorkelflow.operators.operator import ColSchema, no_op_progress_callback
from snorkelflow.utils.load_image import load_minio_image
from snorkelflow.utils.logging import get_logger

logger = get_logger("ImageDimensionsFeaturizer")


class ImageDimensionsFeaturizer(Featurizer):
    """Featurizer that computes the dimensions of an image."""

    def __init__(
        self, field: str, target_width_field: str, target_height_field: str
    ) -> None:
        self.field = field
        self.target_width_field = target_width_field
        self.target_height_field = target_height_field

    @property
    def input_schema(self) -> ColSchema:
        return {self.field: str}

    @property
    def output_schema(self) -> ColSchema:
        return {self.target_width_field: int, self.target_height_field: int}

    def _compute_features(
        self,
        input_df: pd.DataFrame,
        callback: OpProgressCallback = no_op_progress_callback,
    ) -> pd.DataFrame:
        width, height = [], []
        for image_path in input_df[self.field]:
            image = load_minio_image(image_path)
            width.append(image.width)
            height.append(image.height)

        input_df[self.target_width_field] = width
        input_df[self.target_height_field] = height

        return input_df
