from typing import Dict, List

import pandas as pd

from api_utils.exceptions import UserInputError
from snorkelflow.operators.fixed_datapoint import Filter
from snorkelflow.operators.operator import ColSchema, OperatorExample
from snorkelflow.types.model import ModelCols


class FilterTypes:
    INCLUDE = "include"
    EXCLUDE = "exclude"


class LabelIntFilter(Filter):
    """
    A filter that includes/excludes all datapoints corresponding to specified label ints.

    This operator either includes or excludes datapoints in passing dataframes that have
    integer labels in the set of provided :label_ints.

    Parameters
    ----------
    label_ints
        The list of integers to use when applying the filter
    filter_type
        The type of filter to apply (either "include" or "exclude")
    label_col
        The column in the passing dataframe to look for label integers
    """

    @staticmethod
    def get_options() -> Dict[str, List[str]]:
        return dict(filter_type=[FilterTypes.INCLUDE, FilterTypes.EXCLUDE])

    def __init__(
        self,
        label_ints: List[int],
        filter_type: str = FilterTypes.INCLUDE,
        label_col: str = ModelCols.PREDICTION_INT,
    ) -> None:
        self._label_ints = label_ints

        try:
            # Frontend may pass strings... attempt to cast values.
            label_ints = [int(x) for x in label_ints]
        except ValueError:
            # Cast failed
            err_msg = "All elements of Label ints input in LabelIntFilter must be ints"
            raise UserInputError(detail=err_msg, user_friendly_message=err_msg)

        filter_type_options = self.get_options()["filter_type"]
        if filter_type not in filter_type_options:
            err_msg = f"Filter type input in LabelIntFilter must be one of {filter_type_options}, got {filter_type}"
            raise UserInputError(detail=err_msg, user_friendly_message=err_msg)
        self._filter_type = filter_type

        self._label_col = label_col

    @property
    def input_schema(self) -> ColSchema:
        return {self._label_col: int}

    output_schema = None

    @staticmethod
    def examples() -> List[OperatorExample]:
        return [
            OperatorExample(
                input_df={
                    ModelCols.PREDICTION_INT: [0, 0, 1, 1],
                    ModelCols.PREDICTION_STR: ["SPAM", "SPAM", "HAM", "HAM"],
                },
                kwargs=dict(label_ints=[1], filter_type=FilterTypes.EXCLUDE),
                description="Excluding the two rows that contain the '1' label",
            ),
            OperatorExample(
                input_df={
                    ModelCols.PREDICTION_INT: [0, 0, 1, 1],
                    ModelCols.PREDICTION_STR: ["SPAM", "SPAM", "HAM", "HAM"],
                },
                kwargs=dict(label_ints=[1], filter_type=FilterTypes.INCLUDE),
                description="Including the two rows that contain the '1' label",
            ),
        ]

    def _execute_pandas(self, input_df: pd.DataFrame) -> pd.DataFrame:
        mask = input_df[self._label_col].isin(self._label_ints)
        if self._filter_type == FilterTypes.EXCLUDE:
            mask = ~mask

        return input_df[mask]


class LabelFilter(Filter):
    """
    A filter that includes/excludes all datapoints corresponding to specified label strings.

    This operator either includes or excludes datapoints in passing dataframes that have
    string labels in the set of provided :label_strs.

    Parameters
    ----------
    label_strs
        The list of strings to use when applying the filter
    filter_type
        The type of filter to apply (either "include" or "exclude", default: {FilterTypes.INCLUDE})
    label_col
        The column in the passing dataframe to look for label integers (default: {ModelCols.PREDICTION_STR})
    """

    @staticmethod
    def get_options() -> Dict[str, List[str]]:
        return dict(filter_type=[FilterTypes.INCLUDE, FilterTypes.EXCLUDE])

    def __init__(
        self,
        label_strs: List[str],
        filter_type: str = FilterTypes.INCLUDE,
        label_col: str = ModelCols.PREDICTION_STR,
    ) -> None:
        self._label_strs = label_strs

        filter_type_options = self.get_options()["filter_type"]
        if filter_type not in filter_type_options:
            err_msg = f"Filter type input in LabelFilter must be one of {filter_type_options}, got {filter_type}"
            raise UserInputError(detail=err_msg, user_friendly_message=err_msg)
        self._filter_type = filter_type

        self._label_col = label_col

    @property
    def input_schema(self) -> ColSchema:
        return {self._label_col: str}

    output_schema = None

    @staticmethod
    def examples() -> List[OperatorExample]:
        return [
            OperatorExample(
                input_df={
                    ModelCols.PREDICTION_INT: [0, 0, 1, 1],
                    ModelCols.PREDICTION_STR: ["SPAM", "SPAM", "HAM", "HAM"],
                },
                kwargs=dict(label_strs=["SPAM"], filter_type=FilterTypes.EXCLUDE),
                description="Excluding the two rows that contain the 'SPAM' label",
            ),
            OperatorExample(
                input_df={
                    ModelCols.PREDICTION_INT: [0, 0, 1, 1],
                    ModelCols.PREDICTION_STR: ["SPAM", "SPAM", "HAM", "HAM"],
                },
                kwargs=dict(label_strs=[1], filter_type=FilterTypes.INCLUDE),
                description="Including the two rows that contain the 'SPAM' label",
            ),
        ]

    def _execute_pandas(self, input_df: pd.DataFrame) -> pd.DataFrame:
        mask = input_df[self._label_col].isin(self._label_strs)
        if self._filter_type == FilterTypes.EXCLUDE:
            mask = ~mask

        return input_df[mask]
