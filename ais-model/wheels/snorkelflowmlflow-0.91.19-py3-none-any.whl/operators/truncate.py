from typing import Callable, Dict, List, Optional

import pandas as pd

from api_utils.exceptions import UserInputError
from snorkelflow.operators.featurizer import Featurizer, OpProgressCallback
from snorkelflow.operators.operator import (
    ColSchema,
    OperatorExample,
    no_op_progress_callback,
)
from snorkelflow.types.performance import Performance


def truncate_words(s: str, max_len: int) -> str:
    # Truncate a string down to n_words runs of non-space characters
    # Preserves all runs of whitespace (via string.isspace()) but doesn't count
    # towards max_len
    s_truncated = ""
    word_count = 0
    in_word = False
    for c in s:
        if word_count >= max_len:
            break
        if c.isspace():
            if in_word:
                in_word = False
                word_count += 1
                if word_count == max_len:
                    break
            s_truncated += c
        else:
            in_word = True
            s_truncated += c
    return s_truncated


def truncate_chars(s: str, max_len: int) -> str:
    return s[:max_len]


# Mapping from `by` arg to a truncate function with signature f(s, max_len) -> str
TruncateFunction = Callable[[str, int], str]
TRUNCATE_FUNCTIONS: Dict[str, TruncateFunction] = {
    "chars": truncate_chars,
    "words": truncate_words,
}


class TruncatePreprocessor(Featurizer):
    """
    Truncates a column by given amount.

    Truncates the given column (with string values) and writes result to
    the target field.

    Parameters
    ----------
    field : str
        The field you want to truncate
    target_field: str
        The output field to write the truncated strings to
    length : int
        The length to truncate to
    by : str
        Whether to truncate to <length> 'words' or 'chars'.
    """

    @staticmethod
    def get_options() -> Dict[str, List[str]]:
        return dict(by=list(TRUNCATE_FUNCTIONS.keys()))

    def __init__(
        self,
        field: str,
        target_field: Optional[str] = None,
        length: int = 5000,
        by: str = "words",
    ) -> None:
        self.field = field
        self.target_field = target_field or f"{field}_truncated"
        if length <= 0:
            err_msg = (
                f"Length input in TruncatePreprocessor must be > 0, found {length}"
            )
            raise UserInputError(detail=err_msg, user_friendly_message=err_msg)
        self.length = length
        if by not in self.get_options()["by"]:
            err_msg = f"by argument in TruncatePreprocessor must be in {TRUNCATE_FUNCTIONS.keys()}, found {by}"
            raise UserInputError(detail=err_msg, user_friendly_message=err_msg)
        self.by = by

    @property
    def input_schema(self) -> ColSchema:
        return {self.field: str}

    @property
    def output_schema(self) -> ColSchema:
        return {self.target_field: str}

    def estimate_perf(self, df: pd.DataFrame) -> Performance:
        return Performance(
            compute_time_secs=len(df) * self.length * 0.00001,
            peak_memory_mb=len(df) * self.length * 0.00003,
        )

    def _compute_features(
        self,
        input_df: pd.DataFrame,
        callback: OpProgressCallback = no_op_progress_callback,
    ) -> pd.DataFrame:
        """Override base class method"""
        truncate_func = lambda x: TRUNCATE_FUNCTIONS[self.by](str(x), self.length)
        input_df[self.target_field] = input_df[self.field].map(truncate_func)
        return input_df

    @staticmethod
    def examples() -> List[OperatorExample]:
        return [
            OperatorExample(
                input_df=dict(text=["This is a sentence", "Another sentence"]),
                kwargs=dict(
                    field="text", by="chars", length=5, target_field="text_trunc"
                ),
            ),
            OperatorExample(
                input_df=dict(text=["This is a sentence", "Another sentence"]),
                kwargs=dict(field="text", length=1),
            ),
        ]
