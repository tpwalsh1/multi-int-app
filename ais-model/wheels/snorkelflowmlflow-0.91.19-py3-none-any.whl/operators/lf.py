from typing import Any, Dict, List

import pandas as pd

from label_spaces.get_label_space import get_label_space
from snorkelflow.operators.featurizer import Featurizer, OpProgressCallback
from snorkelflow.operators.operator import ColSchema, no_op_progress_callback
from snorkelflow.serialization.code_asset import deserialize_asset
from snorkelflow.utils.lfs import LFWrapper


class LabelingFunctions(Featurizer):
    input_schema = None

    @property
    def output_schema(self) -> ColSchema:
        if self.label_space.get_raw_unknown_label() == -1:
            return {col: int for col in self.target_columns}
        else:
            return {col: None for col in self.target_columns}

    def __init__(
        self,
        lf_configs: List[Dict[str, Any]],
        target_columns: List[str],
        label_space_config: Dict,
    ) -> None:
        from lfs.builder import LFBuilder

        self.target_columns = target_columns
        self.label_space = get_label_space(
            label_space_config["cls_name"], label_space_config["kwargs"]
        )
        label_space_cls = self.label_space.__class__
        self.lfs = [
            LFBuilder.from_config(
                config, label_space_cls=label_space_cls, label_space=self.label_space
            )
            for config in lf_configs
        ]

    def _compute_features(
        self,
        input_df: pd.DataFrame,
        callback: OpProgressCallback = no_op_progress_callback,
    ) -> pd.DataFrame:
        from operators.get_operator import init_featurizer_class

        preprocess_configs: List[Dict[str, Any]] = [
            config for lf in self.lfs for config in lf.preprocess_configs
        ]
        for config in preprocess_configs:
            op = init_featurizer_class(config["op_type"], config["op_config"])
            df_features = op._compute_features(input_df)
            assert op.output_schema is not None  # For mypy
            input_df = input_df.assign(
                **{col: df_features[col] for col in op.output_schema}
            )

        lf_results = []
        for lf in self.lfs:
            wrapper = LFWrapper(lf, True, self.label_space)
            lf_results.append(wrapper.apply(input_df))

        # Returns LF vote for each LF in RawLabel format
        return pd.DataFrame(dict(zip(self.target_columns, lf_results)))


class LabelingFunctionsExportable(LabelingFunctions):
    def __init__(
        self, target_columns: List[str], label_space_config: Dict, lfs_pickle: str
    ) -> None:
        self.target_columns = target_columns
        self.label_space = get_label_space(
            label_space_config["cls_name"], label_space_config["kwargs"]
        )
        self.lfs = deserialize_asset(lfs_pickle)
