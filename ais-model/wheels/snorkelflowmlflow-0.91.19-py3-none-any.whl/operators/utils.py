import inspect
from abc import ABCMeta
from typing import Any, Dict, List, Optional, Type, Union, get_args, get_origin

import pandas as pd
from dask import dataframe as dd
from docstring_parser import DocstringStyle, parse

from operators.types import DataframeFieldType, DataframeMultiFieldType
from snorkelflow.types.application_package import UIComponent
from snorkelflow.types.model import ModelCols
from snorkelflow.utils.logging import get_logger

logger = get_logger("Operator Utils")

TOKEN_FIELD_PREFIX = "tokenized_"


def add_prediction_columns(
    df: Union[pd.DataFrame, dd.DataFrame],
    uid_col: str,
    pred_x_uids: List[str],
    pred_ints: List[int],
    pred_probs: List[List[float]],
    pred_strs: Optional[List[str]] = None,
    join_type: str = "inner",
) -> Union[pd.DataFrame, dd.DataFrame]:
    """Joins an existing dataframe with one containing its predictions."""

    # If columns already exist, overwite them.
    # NOTE: This case may occur when chaining tasks: a previous model's preds
    # are leftover in the dataframe, and we'd like to include a new model's preds.
    if ModelCols.PREDICTION_INT in df.columns:
        logger.warning(f"Overwriting {ModelCols.PREDICTION_INT} column.")
        df = df.drop(ModelCols.PREDICTION_INT, axis=1)
    if ModelCols.PREDICTION_PROBABILITY in df.columns:
        df = df.drop(ModelCols.PREDICTION_PROBABILITY, axis=1)
        logger.warning(f"Overwriting {ModelCols.PREDICTION_PROBABILITY} column.")

    df_data = {
        ModelCols.PREDICTION_INT: pred_ints,
        ModelCols.PREDICTION_PROBABILITY: pred_probs,
    }
    if pred_strs:
        df_data[ModelCols.PREDICTION_STR] = pred_strs

    pred_df = pd.DataFrame(data=df_data, index=pd.Index(pred_x_uids, "str"))
    if isinstance(df, dd.DataFrame):
        pred_df = dd.from_pandas(pred_df, npartitions=1)

    # NOTE: Inner join will filter rows with missing preds/probs
    joined_df = df.join(pred_df, how=join_type, on=uid_col)
    if isinstance(df, dd.DataFrame):
        # HACK: Workaround for https://github.com/dask/dask/issues/8113
        # If both DFs are single-partition, the divisions field in the joined DF is incorrect
        # Set explicitly to the left hand DF divisions field
        if df.npartitions == 1:
            joined_df.divisions = df.divisions
    return joined_df


def _py_type_to_ui_component(
    field_type: Type, param_name: Optional[str] = None
) -> UIComponent:
    # Special: Choices with single data frame field selection
    if param_name == "field" and field_type == str:
        return UIComponent.DF_FIELD_CHOICES
    if field_type == DataframeFieldType:
        return UIComponent.DF_FIELD_CHOICES
    elif field_type == bool:
        return UIComponent.CHECKBOX
    elif field_type == float:
        return UIComponent.NUMBER
    elif field_type == int:
        return UIComponent.NUMBER
    elif field_type == str:
        return UIComponent.TEXT
    elif field_type == DataframeMultiFieldType:
        return UIComponent.DF_FIELD_MULTI_CHOICES
    elif get_origin(field_type) == Union and get_args(field_type) == (
        DataframeMultiFieldType,
        type(None),
    ):
        return UIComponent.DF_FIELD_MULTI_CHOICES
    elif field_type == Any:
        # Default to Text input for flexible types
        return UIComponent.TEXT

    if hasattr(field_type, "__origin__"):
        # Special: Choices with multiple data frame field selection
        if param_name == "fields" and field_type.__origin__ in [list, List]:
            return UIComponent.DF_FIELD_MULTI_CHOICES
        elif field_type.__origin__ in [dict, Dict]:
            return UIComponent.JSON
        elif field_type.__origin__ in [list, List]:
            return UIComponent.MULTI_TEXT
        elif field_type.__origin__ == Union:
            # Default to Text input for flexible types
            return UIComponent.TEXT

    logger.error(f"field type: {field_type}, param: {param_name}")
    raise NotImplementedError(
        f"Field type {field_type} for param {param_name} not valid"
    )


def _get_non_optional_field_type(field_type: Type) -> Type:
    # Handle Optional AKA Union[<>, None] type
    if get_origin(field_type) == Union:
        # Filter out NoneTypes from [typing.List[str], <class 'NoneType'>]
        non_none_types = [
            x for x in get_args(field_type) if x is not type(None)  # noqa: E721
        ]
        # If there is one type remaining, set that as the field_type
        if len(non_none_types) == 1:
            # Recursively unnest "Optional" types
            field_type = non_none_types[0]
        elif set(non_none_types) == {str, List[str]}:
            # Handle `Optional[Union[str, List[str]]]` - the case where we accept
            # multiple input types for strings and wrap them under the hood
            return List[str]
        else:
            # We don't support more deeply nested types (yet)
            # TODO: We could likely do this by recurisvely calling this function,
            # but not well-tested yet.
            raise NotImplementedError

    return field_type


def _get_configs_from_params(
    cls: ABCMeta,
    input_annotations: Dict[str, Any],
    input_defaults: Optional[Dict[str, Any]] = None,
    input_is_kwarg: Optional[Dict[str, bool]] = None,
) -> List[Dict[str, Any]]:
    """Helper to wrap logic of creating input configs based on parameters

    Currently used for getting configs based on parameters to __init__
    and _fit, but can be used for more options in future.
    """
    field_configs: List[Dict[str, Any]] = []
    # Fetch options for args from class
    arg_options = cls.get_options() if hasattr(cls, "get_options") else {}  # type: ignore

    param_to_doc_string = {}
    param_to_type_name = {}
    try:
        parsed_doc_string = parse(cls.__doc__, DocstringStyle.NUMPYDOC)
        for param in parsed_doc_string.params:
            arg_name = param.arg_name
            param_to_doc_string[arg_name] = param.description
            param_to_type_name[arg_name] = param.type_name or None
    except Exception as e:
        logger.info(e)
        pass

    for param_name, annotation in input_annotations.items():
        field_type = _get_non_optional_field_type(annotation)
        assert field_type != inspect._empty, "Operators should have typed parameters"  # type: ignore

        # Map to a UI component based on the type annotation
        if param_name in arg_options:
            # Use option for Dropdown if the class defines them
            component = UIComponent.CHOICES
            options = arg_options[param_name]
        else:
            component = _py_type_to_ui_component(field_type, param_name)
            options = None

        # Check for 'Optional' type, AKA Union[TYPE, None]
        is_optional = (
            hasattr(annotation, "__origin__")
            and annotation.__origin__ == Union
            and type(None) in annotation.__args__
        )

        # Set default value
        if input_defaults and input_defaults.get(param_name) != inspect._empty:  # type: ignore
            default = input_defaults[param_name]
        else:
            default = None

        if input_is_kwarg:
            is_kwarg = input_is_kwarg[param_name]
            if is_kwarg:
                is_optional = True
                default = "{}"
        else:
            is_kwarg = None

        field_configs.append(
            dict(
                component=component.value,
                default=default,
                input_name=param_name,
                is_optional=is_optional,
                options=options,
                is_kwarg=is_kwarg,
                description=param_to_doc_string.get(param_name, ""),
                type_name=param_to_type_name.get(param_name, ""),
            )
        )

    return field_configs


def get_field_configs_from_cls(cls: ABCMeta) -> List[Dict[str, Any]]:
    """Return input configs based on __init__ of specified class.

    These will be used by the frontend to render in the UI.
    """
    # Determine if the class is dim_operators table (User Defined Class)
    # Triggers on built-in operator. Built-in operators do not have init_params and fit_params defined.
    if not cls.init_params:  # type: ignore
        init_params = inspect.signature(cls.__init__).parameters  # type: ignore
    else:
        init_params = cls.init_params  # type: ignore

    # TODO: Clean this up when fit_params and init_params structure is synced
    # Filter out generic args
    init_annotations = {
        k: v.annotation
        for k, v in init_params.items()
        if k not in ["self", "args", "kwargs"]
    }
    init_defaults = {
        k: v.default
        for k, v in init_params.items()
        if k not in ["self", "args", "kwargs"]
    }
    is_param_kwarg = {
        k: v.kind == v.VAR_KEYWORD
        for k, v in init_params.items()
        if k not in ["self", "args", "kwargs"]
    }

    # Leaving this out of common logic function - assuming cls.show_args_in_gui does not apply to _fit method
    if not cls.show_args_in_gui:  # type: ignore
        if any([default == inspect._empty for default in init_defaults.values()]):  # type: ignore
            raise ValueError(
                "Cannot set show_args_in_gui=False if an arg is missing a default value."
            )
        return []

    return _get_configs_from_params(
        cls, init_annotations, init_defaults, is_param_kwarg
    )


def get_fit_configs_from_cls(cls: ABCMeta) -> Optional[List[Dict[str, Any]]]:
    # Determine if cls is a user-defined class
    # Dill does not serialize type annotations and are stored separately for UDF classes.
    # Triggers on built-in operator. Built-in operators do not have init_params and fit_params defined.
    if cls.fit_params:  # type: ignore
        # This is becasue fit_arguments uses inspect,
        # but user defined classes don't have type annotations serialized
        fit_annotations = cls.fit_params  # type: ignore
        # fit_params can have either of the following formats:
        # {'field': <class 'str'>, 'target_field': <class 'str'>} or
        # {'field': {'annotation': <class 'inspect._empty'>, 'default': <class 'inspect._empty'>}}
        # If the values of fit_params are dict, a custom operator was registered after snorkel-ai/strap#13263
        # Extracting only the "annotation" part
        for k, v in fit_annotations.items():
            if isinstance(v, dict):
                fit_annotations[k] = v["annotation"]

    else:
        fit_args = cls.fit_arguments()  # type: ignore
        fit_annotations = (
            {k: v["annotation"] for k, v in fit_args.items()} if fit_args else fit_args
        )
    # Possibly need to add support for is_optional and default and options in operator fit args
    if fit_annotations is None:
        return None

    return _get_configs_from_params(cls, fit_annotations)
