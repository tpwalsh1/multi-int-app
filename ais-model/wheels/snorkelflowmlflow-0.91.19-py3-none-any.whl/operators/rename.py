from typing import Dict, List

import pandas as pd

from api_utils.exceptions import UserInputError
from snorkelflow.operators.fixed_datapoint import ChangeColumns
from snorkelflow.operators.operator import ColSchema, OperatorExample


class ColumnRenamer(ChangeColumns):
    """Preprocessor that renames columns

    This operator is used to rename columns in the passing dataframe according
    to a provided renaming dictionary

    Parameters
    ----------
    column_map
        A dictionary mapping old column names to new column names
    """

    def __init__(self, column_map: Dict[str, str]) -> None:
        if not isinstance(column_map, dict):
            err_msg = "Column map input in ColumnRenamer must be a dictionary"
            raise UserInputError(detail=err_msg, user_friendly_message=err_msg)
        if any(
            not isinstance(k, str) or not isinstance(v, str)
            for k, v in column_map.items()
        ):
            err_msg = (
                "Column map input in ColumnRenamer must contain string keys and values"
            )
            raise UserInputError(detail=err_msg, user_friendly_message=err_msg)
        self.column_map = column_map

    @property
    def input_schema(self) -> ColSchema:
        return {x: None for x in self.column_map.keys()}

    @property
    def output_schema(self) -> ColSchema:
        return {x: None for x in self.column_map.values()}

    @property
    def drop_schema(self) -> List[str]:
        return list(self.column_map.keys() - self.column_map.values())

    def _execute_pandas(self, input_df: pd.DataFrame) -> pd.DataFrame:
        """Override base class method"""
        return input_df.rename(columns=self.column_map)

    def get_datapoint_cols(self, input_datapoint_cols: List[List[str]]) -> List[str]:
        assert input_datapoint_cols  # mypy
        return [
            self.column_map[x] if x in self.column_map else x
            for x in input_datapoint_cols[0]
        ]

    def column_docs(self) -> Dict[str, str]:
        inv_map: Dict[str, List[str]] = {}
        for k, v in self.column_map.items():
            inv_map[v] = inv_map.get(v, []) + [k]

        def _format_col(k: str) -> str:
            v = inv_map[k]
            # We lost information about what was the precise parent column
            if len(v) > 1:
                return f"one of the columns {v}"
            return f"column '{v[0]}'"

        return {
            k: f"Renamed from '{_format_col(k)}' in original dataframe"
            for k in self.output_schema
        }

    @staticmethod
    def examples() -> List[OperatorExample]:
        """List of examples (pairs of input df and operator kwargs)."""
        return [
            OperatorExample(
                input_df=dict(uid=[1, 3], text=["first example", "another example"]),
                kwargs=dict(column_map={"text": "renamed_text"}),
            )
        ]
