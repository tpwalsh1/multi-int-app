from typing import Dict, List, Optional

import numpy as np
import pandas as pd

from api_utils.exceptions import UserInputError
from snorkelflow.extraction.span import SpanCols
from snorkelflow.operators.featurizer import Featurizer, OpProgressCallback
from snorkelflow.operators.operator import (
    ColSchema,
    OperatorExample,
    no_op_progress_callback,
)
from snorkelflow.types.performance import Performance

MAX_CHAR_WINDOW = 10000


class SpanPreviewPreprocessor(Featurizer):
    """
    Operator that adds a field with nearby textual features for each extracted span.

    This Operator adds a preview of the parent document to the Span dataframe. This is
    useful when one needs to classify spans based on the surrounding context.

    Parameters
    ----------
    char_window
        The size of window (in characters), defaults to 200
    feature_suffix
        String to suffix the default feature names of this operator's output schema
    """

    input_schema = {
        SpanCols.CHAR_START: int,
        SpanCols.CHAR_END: int,
        SpanCols.SPAN_FIELD: str,
    }

    def __init__(
        self, char_window: int = 200, feature_suffix: Optional[str] = ""
    ) -> None:
        if char_window < 0:
            raise UserInputError(
                detail="char_window must be nonnegative.",
                user_friendly_message="char_window must be nonnegative.",
                how_to_fix="select a value greater than or equal to 0 for char_window.",
            )
        if char_window > MAX_CHAR_WINDOW:
            raise UserInputError(
                detail=f"char_window must be less than or equal to {MAX_CHAR_WINDOW}.",
                user_friendly_message=f"char_window must be less than or equal to {MAX_CHAR_WINDOW}.",
                how_to_fix=f"select a value less than or equal to {MAX_CHAR_WINDOW} for char_window.",
            )
        self._char_window = char_window
        self.feature_suffix = feature_suffix or ""

    def feature_name(self, feature: str) -> str:
        return f"{feature}{self.feature_suffix}"

    @property
    def output_schema(self) -> ColSchema:
        return {
            self.feature_name(SpanCols.SPAN_PREVIEW): str,
            self.feature_name(SpanCols.SPAN_PREVIEW_OFFSET): int,
            self.feature_name(SpanCols.LEFT_CONTEXT): str,
            self.feature_name(SpanCols.RIGHT_CONTEXT): str,
        }

    def column_docs(self) -> Dict[str, str]:
        return {
            self.feature_name(
                SpanCols.SPAN_PREVIEW
            ): f"Text window from {self._char_window} characters before to {self._char_window} characters after the span",
            self.feature_name(
                SpanCols.SPAN_PREVIEW_OFFSET
            ): f"Starting character of span preview in the original text",
            self.feature_name(
                SpanCols.LEFT_CONTEXT
            ): f"{self._char_window} characters before the span",
            self.feature_name(
                SpanCols.RIGHT_CONTEXT
            ): f"{self._char_window} characters after the span",
        }

    def _compute_features(
        self,
        input_df: pd.DataFrame,
        callback: OpProgressCallback = no_op_progress_callback,
    ) -> pd.DataFrame:
        """Override base class method"""

        input_df[self.feature_name(SpanCols.SPAN_PREVIEW_OFFSET)] = np.maximum(
            0, input_df[SpanCols.CHAR_START] - self._char_window
        )
        input_df["temp_preview_end"] = (
            input_df[SpanCols.CHAR_END] + self._char_window + 1
        )
        text_col = input_df[SpanCols.SPAN_FIELD].iloc[0]
        input_df[self.feature_name(SpanCols.SPAN_PREVIEW)] = input_df.apply(
            lambda row: row[text_col][
                row[self.feature_name(SpanCols.SPAN_PREVIEW_OFFSET)] : row[
                    "temp_preview_end"
                ]
            ],
            axis=1,
        )
        input_df[self.feature_name(SpanCols.LEFT_CONTEXT)] = input_df.apply(
            lambda row: row[text_col][
                row[self.feature_name(SpanCols.SPAN_PREVIEW_OFFSET)] : row[
                    SpanCols.CHAR_START
                ]
            ],
            axis=1,
        )
        input_df[self.feature_name(SpanCols.RIGHT_CONTEXT)] = input_df.apply(
            lambda row: row[text_col][
                row[SpanCols.CHAR_END] + 1 : row["temp_preview_end"]
            ],
            axis=1,
        )

        return input_df

    def estimate_perf(self, df: pd.DataFrame) -> Performance:
        return Performance(
            compute_time_secs=len(df) * 0.0001, peak_memory_mb=len(df) * 0.003
        )

    @staticmethod
    def examples() -> List[OperatorExample]:
        """List of examples (pairs of input df and operator kwargs)."""
        return [
            OperatorExample(
                input_df=dict(
                    uid=[1, 3],
                    text=["first example", "another example"],
                    char_start=[1, 10],
                    char_end=[4, 11],
                    span_field=["text", "text"],
                ),
                kwargs=dict(char_window=2, feature_suffix="2"),
            )
        ]
