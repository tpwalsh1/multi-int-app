import pandas as pd

from snorkelflow.operators.featurizer import Featurizer, OpProgressCallback
from snorkelflow.operators.operator import no_op_progress_callback
from snorkelflow.rich_docs import RichDocCols
from snorkelflow.rich_docs.rich_doc import RichDoc


# DEPRECATED: Kept for backward compatibility with existing tasks that have this
# operator, but shouldn't be needed for new tasks due to custom serialization.
class RichDocPageSerializer(Featurizer):
    """Processor that serializes RichDoc page objects into pickle strings.

    The operator that serializes RichDoc page objects into pickle strings.
    This should be used in conjunction with RichDocPageDeserializer.
    """

    input_schema = {RichDocCols.DOC_COL: RichDoc}
    output_schema = {RichDocCols.PKL_COL: None}

    def _compute_features(
        self,
        input_df: pd.DataFrame,
        callback: OpProgressCallback = no_op_progress_callback,
    ) -> pd.DataFrame:
        """Override base class method"""
        return input_df.assign(
            **{
                RichDocCols.PKL_COL: input_df[RichDocCols.DOC_COL].map(
                    lambda rd: rd.serialize()
                )
            }
        )
