import re
from typing import List

import pandas as pd
from dateutil.parser import parse
from num2words import num2words

from snorkelflow.extraction.span import SpanCols
from snorkelflow.operators.candidates import SpanNormalizer
from snorkelflow.operators.featurizer import OpProgressCallback
from snorkelflow.operators.operator import (
    ColSchema,
    OperatorExample,
    no_op_progress_callback,
)


# Check whether a string is a number
def is_int(x: str) -> bool:
    try:
        int(x)
        return True
    except ValueError:
        return False


class DateSpanNormalizer(SpanNormalizer):
    """Normalizes date spans into their canonical forms, e.g. 2020-01-01.

    Returns
    -------
    {SpanCols.NORMALIZED_SPAN}
        The normalized span after post-processing
    """

    def _normalize(self, x: str) -> str:
        pattern = re.compile(r"([0-9]{1,2})(?:st|nd|rd|th)? day of")
        sub_pattern = pattern.sub(r"\1", x)

        if is_int(sub_pattern):
            # If sub_pattern is 6 or -33, parse will converge it to date based on the current date
            # e.g. if it's Jun 2020, parse("6").date() = "2020-06-06"
            # and parse("-33").date() == "2033-06-01"
            return sub_pattern

        try:
            # the parse() fails if the sub_pattern is not a valid datetime str (e.g., $10.10)
            parsed = str(parse(sub_pattern).date())
        except ValueError:
            return x
        return parsed

    @staticmethod
    def examples() -> List[OperatorExample]:
        """List of examples (pairs of input df and operator kwargs)."""
        return [
            OperatorExample(
                input_df=dict(
                    uid=[0, 0, 1, 1],
                    span_text=[
                        "January 1, 2020",
                        "1/2/2020",
                        "February 3, 2020",
                        "2/4/2020",
                    ],
                ),
                kwargs=dict(),
            )
        ]


class USCurrencySpanNormalizer(SpanNormalizer):
    """Normalizes US currency spans into their numerical values.

    Returns
    -------
    {SpanCols.NORMALIZED_SPAN}
        The normalized span after post-processing
    """

    def _normalize(self, x: str) -> str:
        # Remove dollar sign, commas, and whitespace, then try to cast to float
        try:
            parsed = float("".join(x.split()).replace(",", "").replace("$", ""))
        except ValueError:
            return x
        return f"{parsed:.2f}"

    @staticmethod
    def examples() -> List[OperatorExample]:
        """List of examples (pairs of input df and operator kwargs)."""
        return [
            OperatorExample(
                input_df=dict(
                    uid=[0, 0, 1, 1],
                    span_text=["$100, 000.00", "6", "£100.000,00", "MO NEY!"],
                ),
                kwargs=dict(),
            )
        ]


class TextCasingSpanNormalizer(SpanNormalizer):
    """Normalizes spans by lowercasing them, then capitalizing the first letter of each word.

    Returns
    -------
    {SpanCols.NORMALIZED_SPAN}
        The normalized span after post-processing
    """

    def _normalize(self, x: str) -> str:
        # Lower case spans and capitalize first letter of each word
        return str(x).lower().title()


class OrdinalSpanNormalizer(SpanNormalizer):
    """Normalizes numerical ordinals (1st, 2nd, etc) to string ordinals (first, second, etc).

    Returns
    -------
    {SpanCols.NORMALIZED_SPAN}
        The normalized span after post-processing
    """

    def _normalize(self, x: str) -> str:
        parsed_ints = re.findall("\d+", x)
        if len(parsed_ints) != 1:
            parsed_string = x
        else:
            try:
                parsed_string = num2words(parsed_ints[0], to="ordinal")
            except ValueError:
                parsed_string = x

        return parsed_string.replace("-", " ")


class NumericalSpanNormalizer(SpanNormalizer):
    """Normalizes numerical cardinals (1, 2, etc) to string values (one, two, etc).

    Returns
    -------
    {SpanCols.NORMALIZED_SPAN}
        The normalized span after post-processing
    """

    def _normalize(self, x: str) -> str:
        try:
            parsed = float(x)
            parsed_string = num2words(parsed, to="cardinal")
        except ValueError:
            parsed_string = x

        parsed_string = parsed_string.strip(",")
        return parsed_string.replace("-", " ")


class SpanEntityNormalizer(SpanNormalizer):
    """
    Copies the linked span entity from the extractor as the normalized span.

    Returns
    -------
    {SpanCols.NORMALIZED_SPAN}
        The normalized span after post-processing
    """

    input_schema: ColSchema = {SpanCols.SPAN_TEXT: str, SpanCols.SPAN_ENTITY: str}

    def _normalize(self, x: str) -> str:
        # Define this to override abstract class
        pass

    def _compute_features(
        self,
        input_df: pd.DataFrame,
        callback: OpProgressCallback = no_op_progress_callback,
    ) -> pd.DataFrame:
        # NOTE: This supports entity classification workflows, where the extractor
        # performs both entity extraction and linking for efficiency
        return input_df.assign(
            **{SpanCols.NORMALIZED_SPAN: input_df[SpanCols.SPAN_ENTITY]}
        )


class IdentitySpanNormalizer(SpanNormalizer):
    """Copies span text as is.

    Returns
    -------
    {SpanCols.NORMALIZED_SPAN}
        The normalized span after post-processing
    """

    def _normalize(self, x: str) -> str:
        return x
