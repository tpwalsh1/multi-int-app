import json
from typing import Any, Dict, List, Optional, Union

import pandas as pd
import re2
import regex

from api_utils.exceptions import UserInputError
from rich_doc_wrapper import (
    BEFORE_OR_AFTER,
    CENTER,
    DEFAULT_RICH_DOC_SPAN_FEATURES_CONFIG,
    DIRECTIONS,
    LEFT_OR_RIGHT,
    LINE,
    LOCATIONS,
    PAGE,
    PIXELS,
    SCOPES,
    SEQ_DIRECTIONS,
    TEXT_DELIMITER,
    THRESHOLD_UNITS,
    Ngram,
    RichDocSpanFeatures,
    RichDocWrapper,
)
from snorkelflow.extraction.span import SpanCols
from snorkelflow.operators.featurizer import Featurizer, OpProgressCallback
from snorkelflow.operators.operator import ColSchema, no_op_progress_callback
from snorkelflow.rich_docs import BOTTOM, LEFT, RIGHT, TOP, RichDocCols
from snorkelflow.rich_docs.rich_doc import RichDoc, RichDocList
from snorkelflow.types.performance import Performance
from snorkelflow.utils.logging import get_logger

logger = get_logger("RichDocFeatures")

NGRAM_DOC_COL = "__doc"
NGRAM_ID_COL = "__ids"


class RichDocRegexNGramDetector(Featurizer):
    """Featurizer that detects ngrams matching a regex pattern.

    Parameters
    ----------
    regex
        The regex pattern to search for
    target_field
        The name of the field to store the detected ngrams in
    capture_group
        The capture group to use when extracting the ngram text
    case_sensitive
        Whether to ignore case when searching for the regex pattern
    """

    def __init__(
        self,
        regex: str,
        target_field: Optional[str] = None,
        capture_group: int = 0,
        case_sensitive: bool = True,
    ) -> None:
        self.regex = regex
        self.case_sensitive = case_sensitive
        self.capture_group = capture_group
        self.target_field = target_field or f"pattern_ngrams"

    @property
    def input_schema(self) -> ColSchema:
        return {
            RichDocCols.DOC_COL: Optional[RichDoc],
            RichDocCols.PAGE_DOCS: RichDocList,
        }

    @property
    def output_schema(self) -> ColSchema:
        return {self.target_field: None}

    def _compute_features(
        self,
        input_df: pd.DataFrame,
        callback: OpProgressCallback = no_op_progress_callback,
    ) -> pd.DataFrame:
        """Override base class method"""

        flags = 0 if self.case_sensitive else regex.IGNORECASE
        rgx = regex.compile(self.regex, flags=flags)

        # Dealing with PDF classification cases where DOC_COL is not set
        if RichDocCols.DOC_COL not in input_df.columns:
            # PAGE_DOCS exists with and without the PageSplitter operator
            input_df[NGRAM_DOC_COL] = input_df[RichDocCols.PAGE_DOCS].apply(
                lambda x: RichDoc.from_page_docs(x)
            )
        else:
            input_df[NGRAM_DOC_COL] = input_df[RichDocCols.DOC_COL]

        input_df[NGRAM_ID_COL] = input_df[NGRAM_DOC_COL].apply(id)
        ids_df = input_df.groupby(NGRAM_ID_COL).first()
        id_to_ngrams: Dict[int, List[Ngram]] = {}

        for rid, rd in zip(ids_df.index, ids_df[NGRAM_DOC_COL]):
            offset = rd.words.char_start.min() - 2
            rdw = RichDocWrapper(rd)
            id_to_ngrams[rid] = []
            for match in regex.finditer(rgx, rd.text):
                char_start, char_end_exclusive = match.span(self.capture_group)
                char_end = char_end_exclusive - 1
                id_to_ngrams[rid].append(
                    rdw.get_span_ngram(char_start + offset, char_end + offset)
                )
        df_ngrams = pd.DataFrame(
            {self.target_field: id_to_ngrams.values()}, index=id_to_ngrams.keys()
        )
        # Set lsuffix in case there is an overlapping column, so we prioritize
        # the column from df_ngrams.
        return input_df.join(df_ngrams, on=NGRAM_ID_COL, lsuffix="___")


class RichDocRegexPageFeaturizer(Featurizer):
    """
    This operator adds a list of pages to retain based on the regex pattern provided.
    The regex pattern is searched for over the text in each page of the document.
    The list of pages to retain is stored in the `context_pages` field.

    This operator is the first step in filtering out pages based on keywords in native PDF extraction applications.
    The user should add this operator followed by a PDFToRichDocParser.
    The `context_pages` field should be provided as the "Pages field" input to the PDFToRichDocParser.

    Parameters
    ----------
    regex_pattern: str
        The regular expression pattern we use to filter rows
    case_sensitive
        If False, ignore case when considering regular expression matches (defaults to False)
    """

    def __init__(self, regex_pattern: str, case_sensitive: bool = False) -> None:
        self._regex_pattern = regex_pattern
        self._flags = 0 if case_sensitive else re2.IGNORECASE

        if not regex_pattern:
            err_msg = "Regex pattern input is required for RichDocRegexPageFeaturizer"
            raise UserInputError(detail=err_msg, user_friendly_message=err_msg)

        try:
            re2.compile(regex_pattern)
        except Exception:
            err_msg = f"Error running RichDocRegexPageFeaturizer with regex pattern `{regex_pattern}`"
            raise UserInputError(
                detail=err_msg,
                user_friendly_message=err_msg,
                how_to_fix="Please enter valid regex",
            )

    @property
    def input_schema(self) -> ColSchema:
        return {RichDocCols.PAGE_DOCS: RichDocList}

    @property
    def output_schema(self) -> ColSchema:
        return {RichDocCols.CONTEXT_PAGES: List[int]}

    def _compute_features(
        self,
        input_df: pd.DataFrame,
        callback: OpProgressCallback = no_op_progress_callback,
    ) -> pd.DataFrame:
        def get_page_numbers(row: pd.Series) -> List[int]:
            context_pages = []
            for index, rich_doc in enumerate(row[RichDocCols.PAGE_DOCS].rich_docs):
                if bool(re2.search(self._regex_pattern, rich_doc.text, self._flags)):
                    context_pages.append(index)

            if len(context_pages) == 0:
                logger.warning(f"No pages to retain found for PDF: {row.index}.")

            return context_pages

        input_df[RichDocCols.CONTEXT_PAGES] = input_df.apply(
            lambda row: get_page_numbers(row), axis=1
        )
        return input_df


class RichDocSpanBaseFeaturesPreprocessor(Featurizer):
    """
    Operator that computes basic features for each span using the associated RichDoc object (e.g., bounding box values of the span, page numbers, etc.)

    This operator compute span-based features for richer information for each span. The list of computed
    features can be found in the Returns section.

    This operator usually co-exists with RichDocSpanBaseFeaturesPreprocessor and RichDocSpanRowFeaturesPreprocessor
    to create RichDoc representation and features.

    This operator utilizes existing RichDoc prepopulated columns (no input required).

    Returns
    -------
    rich_doc_span_page_id (int)
        Page number (0-based)
    rich_doc_span_start_word_id (str)
        The ID of the word containing the start of the span (hereafter referred to as "start word")
    rich_doc_span_start_char_offset (int)
        The inclusive start index of the span, relative to the start index of the "start word"
    rich_doc_span_end_word_id (str)
        The ID of the word containing the end of the span
    rich_doc_span_end_char_offset (int)
        The inclusive end index of the span, relative to the start index of the "start word"
    rich_doc_span_ngram (:class:`~rich_doc_wrapper.rich_doc_wrapper.Ngram`)
        The :class:`~rich_doc_wrapper.rich_doc_wrapper.Ngram` object for words containing the span
    left (int)
        The left of the bounding box
    top (int)
        The top of the bounding box
    right (int)
        The right of the bounding box
    bottom (int)
        The bottom of the bounding box
    rich_doc_font_size (int)
        The font size of the :class:`~rich_doc_wrapper.rich_doc_wrapper.Ngram` object
    """

    operator_impl_version: int = 1

    def __init__(self) -> None:
        pass

    @property
    def input_schema(self) -> ColSchema:
        return {
            RichDocCols.DOC_COL: RichDoc,
            SpanCols.CHAR_START: int,
            SpanCols.CHAR_END: int,
        }

    @property
    def output_schema(self) -> ColSchema:
        return {
            RichDocCols.SPAN_PAGE_ID: int,
            RichDocCols.SPAN_START_WORD_ID: str,
            RichDocCols.SPAN_START_CHAR_OFFSET: int,
            RichDocCols.SPAN_END_WORD_ID: str,
            RichDocCols.SPAN_END_CHAR_OFFSET: int,
            LEFT: int,
            TOP: int,
            RIGHT: int,
            BOTTOM: int,
            RichDocSpanFeatures.FONT_SIZE: int,
        }

    def estimate_perf(self, df: pd.DataFrame) -> Performance:
        num_spans = len(df)
        return Performance(
            peak_memory_mb=num_spans * 0.003, compute_time_secs=num_spans * 0.004
        )

    def _compute_features(
        self,
        input_df: pd.DataFrame,
        callback: OpProgressCallback = no_op_progress_callback,
    ) -> pd.DataFrame:
        """Override base class method"""

        def _get_rich_doc_base_span_features(row: pd.Series) -> pd.Series:
            rd = row[RichDocCols.DOC_COL]
            rdw = RichDocWrapper(rd)
            char_start = row[SpanCols.CHAR_START]
            char_end = row[SpanCols.CHAR_END]

            # Get span location fields (used in front-end)
            span_ngram = rdw.get_span_ngram(char_start, char_end)
            span_dict = rdw.rd.get_span_location_fields(
                char_start, char_end, span_ngram.words
            )
            span_dict[RichDocSpanFeatures.FONT_SIZE] = rdw._get_span_font_size(
                span_ngram
            )
            return pd.Series(span_dict)

        return input_df.apply(_get_rich_doc_base_span_features, axis=1)


# NOTE: If you update this, update RichDocSpanRowFeaturesPreprocessor docstring as well
DEFAULT_RICH_DOC_ROW_FEATURES_CONFIG = {
    "scope": PAGE,
    "multi_row": True,
    "min_margin": 10,
    "max_gap": 20,
    "max_left_page_pct": 50,
}


# TODO: Rename all inferred_row_headers to row_headers_inferred so it will show up next
# to row_header by default in most lists. We leave it for now for backwards
# compatibility with existing LFs and operators.
# NOTE: Feature names are spaced to make them bullets in rst
class RichDocSpanRowFeaturesPreprocessor(Featurizer):
    """
    Operator that computes row-level features for a span (eg. text from the span’s row, text before and after the span’s row etc)

    This operator compute row-level features for richer information for each span. The list of computed
    features can be found in the Returns section (optionally with a suffix on each feature name).

    This operator usually co-exists with RichDocSpanBaseFeaturesPreprocessor and RichDocSpanBaseFeaturesPreprocessor
    to create RichDoc representation and features.

    Parameters
    ----------
    row_id : int
        If True, calculate the rich_doc_row_id feature
    row_text_before : str
        If positive, include this many rows before span in rich_doc_row_text_before
    row_text_inline : bool
        If True, calculate the rich_doc_row_text_inline feature
    row_text_after : int
        If positive, include this many rows before span in rich_doc_row_text_after
    row_header : bool
        If True, calculate the rich_doc_row_header feature
    inferred_row_headers : bool
        If True, calculate the rich_doc_inferred_row_headers feature
    mask_span : str
        If True, replace the span content with '-SPAN-' in rich_doc_row_text_inline
    row_header_json : bool
        JSON string containing additional settings for row header features.
    feature_suffix : str
        If None, auto-generate suffixes for features based on their parameters.
        Otherwise, append this string to each feature (use empty string for no suffixes)

    Returns
    -------
    rich_doc_row_id
        The (int) index of the span's row
    rich_doc_row_text_before
        The text in the rows 1 to X before the span's row
    rich_doc_row_text_after
        The text in the rows 1 to X  after the span's row
    rich_doc_row_text_inline
        The text from the span's row
    rich_doc_row_header
        The text in the span's row header
    rich_doc_inferred_row_headers
        The text in the span's inferred row headers
    """

    operator_impl_version: int = 2

    def __init__(
        self,
        row_id: bool = False,
        row_text_before: int = 0,
        row_text_inline: bool = False,
        row_text_after: int = 0,
        row_header: bool = False,
        inferred_row_headers: bool = False,
        row_header_json: str = json.dumps(DEFAULT_RICH_DOC_ROW_FEATURES_CONFIG),
        mask_span: bool = True,
        feature_suffix: Optional[str] = "",
    ) -> None:
        if not isinstance(row_header_json, str):
            raise ValueError(
                f"row_header_json must be a JSON string of a dict. "
                f"Found type {type(row_header_json)}."
            )

        logger.info(
            f"RichDocSpanRowFeaturePreprocessor: feature_suffix = {feature_suffix}"
        )
        logger.info(
            f"RichDocSpanRowFeaturePreprocessor: row_header_json = {row_header_json}"
        )

        self.row_id = row_id
        self.row_text_before = row_text_before
        self.row_text_inline = row_text_inline
        self.row_text_after = row_text_after
        self.row_header = row_header
        self.inferred_row_headers = inferred_row_headers
        self.mask_span = mask_span
        try:
            self.row_header_config = json.loads(row_header_json)
        except json.decoder.JSONDecodeError:
            raise ValueError(
                f"Provided row_header_json {row_header_json} "
                "failed to parse as a valid JSON dict."
            )

        if not isinstance(self.row_header_config, dict):
            raise ValueError(
                f"Loaded row_header_json must be a dict. "
                f"Found type {type(self.row_header_config)}"
            )

        # Calculate feature suffixes:
        if feature_suffix is None:
            self.row_id_name = f"{RichDocSpanFeatures.ROW_ID}"
            self.row_text_before_name = (
                f"{RichDocSpanFeatures.ROW_TEXT_BEFORE}_{self.row_text_before}"
            )
            self.row_text_inline_name = f"{RichDocSpanFeatures.ROW_TEXT_INLINE}_{'masked' if self.mask_span else 'unmasked'}"
            self.row_text_after_name = (
                f"{RichDocSpanFeatures.ROW_TEXT_AFTER}_{self.row_text_after}"
            )
            rhc = self.row_header_config
            row_header_suffix = (
                f"_{rhc.get('scope')}"
                f"_{int(rhc.get('multi_row', False))}"
                f"_{rhc.get('min_margin')}"
                f"_{rhc.get('max_gap')}"
                f"_{rhc.get('max_left_page_pct')}"
            )
            self.row_header_name = (
                f"{RichDocSpanFeatures.ROW_HEADER}_{row_header_suffix}"
            )
            self.inferred_row_headers_name = (
                f"{RichDocSpanFeatures.INFERRED_ROW_HEADERS}_{row_header_suffix}"
            )
        else:
            self.row_id_name = f"{RichDocSpanFeatures.ROW_ID}{feature_suffix}"
            self.row_text_before_name = (
                f"{RichDocSpanFeatures.ROW_TEXT_BEFORE}{feature_suffix}"
            )
            self.row_text_inline_name = (
                f"{RichDocSpanFeatures.ROW_TEXT_INLINE}{feature_suffix}"
            )
            self.row_text_after_name = (
                f"{RichDocSpanFeatures.ROW_TEXT_AFTER}{feature_suffix}"
            )
            self.row_header_name = f"{RichDocSpanFeatures.ROW_HEADER}{feature_suffix}"
            self.inferred_row_headers_name = (
                f"{RichDocSpanFeatures.INFERRED_ROW_HEADERS}{feature_suffix}"
            )

    @property
    def input_schema(self) -> ColSchema:
        return {
            RichDocCols.DOC_COL: RichDoc,
            SpanCols.CHAR_START: int,
            SpanCols.CHAR_END: int,
        }

    @property
    def output_schema(self) -> ColSchema:
        output_schema: Dict[str, Union[type, Any, None]] = {}
        if self.row_id:
            output_schema[self.row_id_name] = int
        if self.row_text_before > 0:
            output_schema[self.row_text_before_name] = str
        if self.row_text_inline:
            output_schema[self.row_text_inline_name] = str
        if self.row_text_after > 0:
            output_schema[self.row_text_after_name] = str
        if self.row_header:
            output_schema[self.row_header_name] = str
        if self.inferred_row_headers:
            output_schema[self.inferred_row_headers_name] = str
        return output_schema

    def estimate_perf(self, df: pd.DataFrame) -> Performance:
        compute_factor = 1
        if self.row_text_after or self.row_text_before:
            compute_factor += 16
        if self.row_header:
            compute_factor += 58
        compute_time = len(df) * compute_factor * 0.00012
        return Performance(
            peak_memory_mb=len(df) * 0.0015, compute_time_secs=compute_time
        )

    def _compute_features(
        self,
        input_df: pd.DataFrame,
        callback: OpProgressCallback = no_op_progress_callback,
    ) -> pd.DataFrame:
        """Override base class method"""

        def _get_features(row: pd.Series) -> pd.Series:
            rd = row[RichDocCols.DOC_COL]
            rdw = RichDocWrapper(rd)
            char_start = row[SpanCols.CHAR_START]
            char_end = row[SpanCols.CHAR_END]

            features_dict: Dict[str, Union[int, str]] = {}
            span_ngram = rdw.get_span_ngram(char_start, char_end)

            if self.row_id:
                features_dict[self.row_id_name] = span_ngram.row_id

            if self.row_text_before > 0:
                features_dict[self.row_text_before_name] = rdw.get_span_row_text(
                    char_start,
                    char_end,
                    row_offsets=(self.row_text_before * -1, -1),
                    span_ngram=span_ngram,
                )

            if self.row_text_inline:
                features_dict[self.row_text_inline_name] = rdw.get_span_row_text(
                    char_start,
                    char_end,
                    row_offsets=(0, 0),
                    mask_span=self.mask_span,
                    span_ngram=span_ngram,
                )

            if self.row_text_after > 0:
                features_dict[self.row_text_after_name] = rdw.get_span_row_text(
                    char_start,
                    char_end,
                    row_offsets=(1, self.row_text_after),
                    span_ngram=span_ngram,
                )

            if self.row_header or self.inferred_row_headers:
                row_headers_dict = rdw.get_row_headers(
                    char_start, char_end, **(self.row_header_config)
                )
                if self.row_header:
                    features_dict[self.row_header_name] = row_headers_dict["row_header"]  # type: ignore
                if self.inferred_row_headers:
                    features_dict[self.inferred_row_headers_name] = TEXT_DELIMITER.join(
                        row_headers_dict["row_headers_inferred"]
                    )
            return pd.Series(features_dict)

        return input_df.apply(_get_features, axis=1)


class RichDocSpanStructuralPreprocessor(Featurizer):
    """Operator to compute structural Rich Doc features for span.

    This operator computes structural Rich Doc features for span.
    Available Features (optionally with a suffix on the feature name):

    Note: rich_doc_proximate_text: The text in [window] [scope_unit]s [direction] of span (e.g., [1] [line] [before] the span)

    Parameters
    ----------
    window
        Number of scope units to extract feature text from.
    scope_unit
        The unit to use (word / line / par / area / page).
    direction
        The direction (before_only / after_only / before_or_after) to extract feature text from relative to span.
    feature_name_override
        If not None, use this as the generated column name (instead of an auto-generated name).
    """

    operator_impl_version: int = 1

    def __init__(
        self,
        window: int = 1,
        scope_unit: str = LINE,
        direction: str = BEFORE_OR_AFTER,
        feature_name_override: Optional[str] = None,
    ) -> None:
        self.direction = direction
        self.scope_unit = scope_unit
        if window <= 0:
            raise ValueError(f"window must be positive. Found {window}")
        self.window = window
        self.feature_name = (
            feature_name_override
            if feature_name_override is not None
            else f"{RichDocSpanFeatures.PROXIMATE_TEXT}_{self.window}_{self.scope_unit}_{self.direction}"
        )

    @staticmethod
    def get_options() -> Dict[str, List[str]]:
        return dict(direction=SEQ_DIRECTIONS, scope=SCOPES, scope_unit=SCOPES)

    @property
    def input_schema(self) -> ColSchema:
        return {
            RichDocCols.DOC_COL: RichDoc,
            SpanCols.CHAR_START: int,
            SpanCols.CHAR_END: int,
        }

    @property
    def output_schema(self) -> ColSchema:
        output_schema: Dict[str, Union[type, Any, None]] = {self.feature_name: str}
        return output_schema

    def _compute_features(
        self,
        input_df: pd.DataFrame,
        callback: OpProgressCallback = no_op_progress_callback,
    ) -> pd.DataFrame:
        """Override base class method"""

        def _get_features(row: pd.Series) -> pd.Series:
            rd = row[RichDocCols.DOC_COL]
            rdw = RichDocWrapper(rd)
            char_start = row[SpanCols.CHAR_START]
            char_end = row[SpanCols.CHAR_END]
            span_ngram = rdw.get_span_ngram(char_start, char_end)

            features_dict: Dict[str, Union[int, str]] = {}
            features_dict[self.feature_name] = rdw._get_proximate_text(
                span_ngram,
                window=self.window,
                scope_unit=self.scope_unit,
                direction=self.direction,
            )

            return pd.Series(features_dict)

        return input_df.apply(_get_features, axis=1)


# TODO: Add more detailed docstring.
class RichDocSpanVisualPreprocessor(Featurizer):
    """Operator to compute visual Rich Doc features for span.

    Operator to compute visual Rich Doc features for span.
    Available Features (optionally with a suffix on the feature name):

    Note: rich_doc_aligned_ngrams: The ngrams in the given [scope] whose [location] is within [threshold] [threshold_unit]s

    Parameters
    ----------
    location
        The location of the span and ngrams to compare (left / center / right / top / middle / bottom)
    scope
        The scope to search for ngrams within (word / line / par / area / page).
    threshold
        The maximum threshold used when comparing two location values
    threshold_dir
        A specific direction for restricting the search for aligned ngrams (left_only, right_only, left_or_right, up_only, down_only, up_or_down)
    mask_span_ngrams
        If True, replace the span with -SPAN- in all ngrams
    ngram_range_min
        The lower bound of ngrams to include (e.g., 1 = unigrams, 2 = bigrams, etc.)
    ngram_range_max
        The upper bound of ngrams to include (e.g., 1 = unigrams, 2 = bigrams, etc.)
    feature_name_override
        If not None, use this as the generated column name (instead of an auto-generated name).
    """

    operator_impl_version: int = 1

    def __init__(
        self,
        location: str = CENTER,
        scope: str = PAGE,
        threshold: int = 50,
        threshold_unit: str = PIXELS,
        threshold_dir: str = LEFT_OR_RIGHT,
        mask_span_ngrams: bool = True,
        ngram_range_min: int = 1,
        ngram_range_max: int = 2,
        feature_name_override: Optional[str] = None,
    ) -> None:
        self.location = location
        self.scope = scope
        self.threshold = threshold
        self.threshold_unit = threshold_unit
        self.threshold_dir = threshold_dir
        self.mask_span_ngrams = mask_span_ngrams
        self.ngram_range_min = ngram_range_min
        self.ngram_range_max = ngram_range_max
        self.feature_name = (
            feature_name_override
            if feature_name_override is not None
            else f"{RichDocSpanFeatures.ALIGNED_NGRAMS}_{self.location[:1]}_{self.scope[:3]}_{self.threshold}{self.threshold_unit[:2]}_{int(self.mask_span_ngrams)}_{self.ngram_range_min}_{self.ngram_range_max}"
        )

    @staticmethod
    def get_options() -> Dict[str, List[str]]:
        return dict(
            location=LOCATIONS,
            scope=SCOPES,
            threshold_unit=THRESHOLD_UNITS,
            threshold_dir=DIRECTIONS,
        )

    @property
    def input_schema(self) -> ColSchema:
        return {
            RichDocCols.DOC_COL: RichDoc,
            SpanCols.CHAR_START: int,
            SpanCols.CHAR_END: int,
        }

    @property
    def output_schema(self) -> ColSchema:
        return {self.feature_name: str}

    def _compute_features(
        self,
        input_df: pd.DataFrame,
        callback: OpProgressCallback = no_op_progress_callback,
    ) -> pd.DataFrame:
        """Override base class method"""

        def _get_features(row: pd.Series) -> pd.Series:
            rd = row[RichDocCols.DOC_COL]
            rdw = RichDocWrapper(rd)
            char_start = row[SpanCols.CHAR_START]
            char_end = row[SpanCols.CHAR_END]
            span_ngram = rdw.get_span_ngram(char_start, char_end)

            # TODO: Copied from prevous preprocessor. Check why we aren't using threshold_dir here.
            aligned_ngrams_dict = rdw._get_aligned_ngrams(
                span_ngram,
                locations=[self.location],
                scope=self.scope,
                vert_threshold=self.threshold,
                vert_threshold_unit=self.threshold_unit,
                vert_threshold_dir=self.threshold_dir,
                horz_threshold=self.threshold,
                horz_threshold_unit=self.threshold_unit,
                horz_threshold_dir=self.threshold_dir,
                mask_span_ngrams=self.mask_span_ngrams,
                ngram_range=(self.ngram_range_min, self.ngram_range_max),
            )
            aligned_ngrams = aligned_ngrams_dict[self.location]
            features_dict = {
                self.feature_name: " ".join(
                    ngram.replace(" ", "_") for ngram in aligned_ngrams
                )
            }

            return pd.Series(features_dict)

        return input_df.apply(_get_features, axis=1)


# DEPRECATED: Use the small featurizers above instead.
class RichDocSpanFeaturesPreprocessor(Featurizer):
    """Operator that computes span features from its RichDoc."""

    input_schema = {
        RichDocCols.DOC_COL: RichDoc,
        SpanCols.CHAR_START: int,
        SpanCols.CHAR_END: int,
    }
    output_schema = {
        RichDocCols.SPAN_PAGE_ID: int,
        RichDocCols.SPAN_START_WORD_ID: str,
        RichDocCols.SPAN_START_CHAR_OFFSET: int,
        RichDocCols.SPAN_END_WORD_ID: str,
        RichDocCols.SPAN_END_CHAR_OFFSET: int,
        LEFT: int,
        TOP: int,
        RIGHT: int,
        BOTTOM: int,
        RichDocSpanFeatures.FONT_SIZE: int,
        RichDocSpanFeatures.ROW_ID: int,
        RichDocSpanFeatures.ROW_HEADER: str,
        RichDocSpanFeatures.INFERRED_ROW_HEADERS: str,
        RichDocSpanFeatures.VERT_ALIGNED_NGRAMS: str,
        RichDocSpanFeatures.HORZ_ALIGNED_NGRAMS: str,
        RichDocSpanFeatures.PROXIMATE_TEXT_BEFORE: str,
        RichDocSpanFeatures.PROXIMATE_TEXT_AFTER: str,
        RichDocSpanFeatures.ROW_TEXT_BEFORE: str,
        RichDocSpanFeatures.ROW_TEXT_AFTER: str,
        RichDocSpanFeatures.ROW_TEXT_INLINE: str,
    }

    def __init__(
        self, config_json: str = json.dumps(DEFAULT_RICH_DOC_SPAN_FEATURES_CONFIG)
    ) -> None:
        self.config = json.loads(config_json)
        # TODO: Good error handling and messages for invalid configs

    def _compute_features(
        self,
        input_df: pd.DataFrame,
        callback: OpProgressCallback = no_op_progress_callback,
    ) -> pd.DataFrame:
        """Override base class method"""

        def _get_rich_doc_features_for_span(row: pd.Series) -> pd.Series:
            rd = row[RichDocCols.DOC_COL]
            rdw = RichDocWrapper(rd)
            char_start = row[SpanCols.CHAR_START]
            char_end = row[SpanCols.CHAR_END]

            # Get span location fields (used in front-end)
            span_dict = rdw.rd.get_span_location_fields(char_start, char_end)

            # Get Span RichDoc features
            span_features = rdw.get_span_features(char_start, char_end, self.config)
            span_dict.update(span_features)

            return pd.Series(span_dict)

        return input_df.apply(_get_rich_doc_features_for_span, axis=1)
