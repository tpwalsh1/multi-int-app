from typing import List

import numpy as np
import pandas as pd

from snorkelflow.extraction.span import SpanCols
from snorkelflow.operators.featurizer import Featurizer, OpProgressCallback
from snorkelflow.operators.operator import no_op_progress_callback
from snorkelflow.rich_docs import RichDocCols
from snorkelflow.rich_docs.rich_doc import RichDoc, RichDocList
from snorkelflow.types.performance import Performance


class RichDocPagePreprocessor(Featurizer):
    """
    Operator that filters out all RichDoc pages except the one containing the span to show on the frontend (for the sake of performance)

    This operator removes all pages expect the ones containing the span to show
    in the frontend. This preprocessor creates the {RichDocCols.DOC_COL} column
    and is required by the frontend for rendering a RichDoc with its original formatting on the Data Viewer.

    This operator usually co-exists with RichDocSpanBaseFeaturesPreprocessor and RichDocSpanRowFeaturesPreprocessor
    to create RichDoc representation and features.

    NOTE: RichDocPagePreprocessor can only be used with spans extracted from the
    {RichDocCols.TEXT_COL} column.

    NOTE: The candidate RichDoc is added to the same column as the context RichDoc.

    This operator utilizes existing RichDoc prepopulated columns (no inputs required).
    The output includes the column contains RichDoc formatting for frontend rendering (RichDocCols.DOC_COL)

    Returns
    -------
    {RichDocCols.DOC_COL}
        The column contains RichDoc formatting for frontend rendering
    """

    # TODO: Support validation schemas for multiple inputs
    input_schema = {
        SpanCols.CHAR_START: int,
        SpanCols.CHAR_END: int,
        RichDocCols.PAGE_CHAR_STARTS: List[int],
        RichDocCols.PAGE_DOCS: RichDocList,
        RichDocCols.PDF_URL_COL: str
        # TODO: Add validation based on SPAN_FIELD
    }
    output_schema = {RichDocCols.DOC_COL: RichDoc}

    def estimate_perf(self, df: pd.DataFrame) -> Performance:
        return Performance(
            compute_time_secs=len(df) * 0.01, peak_memory_mb=len(df) * 0.01
        )

    def _compute_features(
        self,
        input_df: pd.DataFrame,
        callback: OpProgressCallback = no_op_progress_callback,
    ) -> pd.DataFrame:
        """Override base class method"""

        def _get_rich_doc_for_span_page(row: pd.Series) -> pd.Series:
            span_page = (
                np.searchsorted(
                    row[RichDocCols.PAGE_CHAR_STARTS], row[SpanCols.CHAR_START] + 1
                )
                - 1
            )
            rich_doc = row[RichDocCols.PAGE_DOCS][span_page]
            pdf_url = row[RichDocCols.PDF_URL_COL]
            if rich_doc.words.empty:
                # Get the first occurance of the page_char_starts
                span_page = np.searchsorted(
                    row[RichDocCols.PAGE_CHAR_STARTS],
                    row[RichDocCols.PAGE_CHAR_STARTS][span_page],
                )
                rich_doc = row[RichDocCols.PAGE_DOCS][span_page]
            return pd.Series(
                {RichDocCols.DOC_COL: rich_doc, RichDocCols.PDF_URL_COL: pdf_url}
            )

        return input_df.apply(_get_rich_doc_for_span_page, axis=1).astype(
            {RichDocCols.DOC_COL: "category", RichDocCols.PDF_URL_COL: str}
        )
