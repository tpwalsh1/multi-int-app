from abc import ABC, abstractmethod
from typing import Dict, List, Optional

import numpy as np
import pandas as pd

from snorkelflow.extraction.span import SpanCols
from snorkelflow.operators.candidates import SpanReducer, get_span_value_col
from snorkelflow.operators.operator import ColSchema
from snorkelflow.types.load import DATAPOINT_UID_COL
from snorkelflow.types.model import ModelCols
from snorkelflow.utils.datapoint import (
    DatapointType,
    DocDatapoint,
    EntityDatapoint,
    SpanDatapoint,
)


class BuiltInSpanReducer(SpanReducer, ABC):
    """An abstract class that contains some convenience logic before/after reduction for our built-in reducers"""

    def _reduce_inner(self, df: pd.DataFrame) -> pd.DataFrame:
        # Perform some shared logic before handing off to the subclass
        # Reset the index (which should be context_uid)
        # That way, we can select using the default idx (0, 1, 2, ...)
        index_name = df.index.name
        columns = df.columns
        df = df.reset_index()
        df.index.name = "__idx"

        # Split the probs column if it's a list.
        # NOTE: This is generally assumed to be true, and that the list consists of numeric values
        #       corresponding to each label class
        input_schema = self.input_schema or {}
        if input_schema.get(self._probs_col) == list:
            df = self._split_probs_col(df)

        df = self._reduce_helper(df)

        # Restore original df structure
        # Drop any columns with the same name as indices
        df = df.drop(df.index.names, axis=1, errors="ignore")
        return df.reset_index().set_index(index_name)[columns]

    def _split_probs_col(self, df: pd.DataFrame) -> pd.DataFrame:
        # Generate temporary columns associated with each label class:
        # If the probs col for a row is [0, 1, 0], the resulting df
        # will have new columns class_prob_0, class_prob_1, class_prob_2
        # with values 0, 1, 0.
        # This is useful for vectorizing operations and avoiding groupby...apply
        class_num = len(df[self._probs_col][0])
        zipped_probs = zip(*df[self._probs_col])
        for idx in range(class_num):
            temp_col_name = f"class_prob_{idx}"
            df[temp_col_name] = next(zipped_probs)
        return df

    def _get_probs_cols(self, df: pd.DataFrame) -> List[str]:
        """Get sorted list of all temporary columns generated from the model probs column"""
        class_num = len(df[self._probs_col][0])
        return [self._get_probs_col_for_class_idx(idx) for idx in range(class_num)]

    def _get_probs_col_for_class_idx(self, idx: int) -> str:
        """Get the temporary column associated with the label class"""
        return f"class_prob_{idx}"

    @abstractmethod
    def _reduce_helper(self, df: pd.DataFrame) -> pd.DataFrame:
        """The method subclasses are expected to override. The outer _reduce_inner method
        applies some transformations to the df before/after this method for convenience.
        The requirements are otherwise the same as the _reduce_inner method description in Reducer.
        """
        pass


class IdentityReducer(BuiltInSpanReducer):
    """No-Op Reducer that passes all Spans through"""

    @property
    def _reduced_datapoint_instance(self) -> DatapointType:
        return SpanDatapoint()

    def _reduce_helper(self, df: pd.DataFrame) -> pd.DataFrame:
        return df


class DocumentFirstReducer(BuiltInSpanReducer):
    """Reduces span predictions in a document to the span which occurs first."""

    @property
    def _reduced_datapoint_instance(self) -> DatapointType:
        return DocDatapoint()

    def _reduce_helper(self, df: pd.DataFrame) -> pd.DataFrame:
        # Select row with the min CHAR_START (first appearance in doc)
        # per context_uid
        df = (
            df.sort_values([SpanCols.CHAR_START, SpanCols.CONTEXT_UID]).drop_duplicates(
                SpanCols.CONTEXT_UID, keep="first"
            )
            # Do one last sort - there is no explicit sort on the dask dataframe as that would
            # be more expensive, so sort by the index here.
            .sort_values(DATAPOINT_UID_COL)
        )
        return df


class DocumentLastReducer(BuiltInSpanReducer):
    """Reduces spans predictions in a document to the span which occurs last."""

    @property
    def _reduced_datapoint_instance(self) -> DatapointType:
        return DocDatapoint()

    def _reduce_helper(self, df: pd.DataFrame) -> pd.DataFrame:
        # Select row with the last CHAR_START (last appearance in doc)
        # per context_uid
        df = (
            # The equivalent of df.loc[df.groupby(...)[...].idxmax()], but faster
            df.sort_values(SpanCols.CHAR_START).drop_duplicates(
                SpanCols.CONTEXT_UID, keep="last"
            )
            # Do one last sort - there is no explicit sort on the dask dataframe as that would
            # be more expensive, so sort by the index here.
            .sort_values(DATAPOINT_UID_COL)
        )
        return df


class DocumentMostConfidentReducer(BuiltInSpanReducer):
    """Reduces spans predictions in a document to the span with the most confident model prediction."""

    TMP_POS_PROB_COL = "__pos_probs"

    @property
    def _reduced_datapoint_instance(self) -> DatapointType:
        return DocDatapoint()

    @property
    def input_schema(self) -> ColSchema:
        # Override the base Reducer's input_schema to include probs col
        return {
            SpanCols.CHAR_START: int,
            SpanCols.CHAR_END: int,
            SpanCols.SPAN_TEXT: str,
            self._probs_col: list,
        }

    def _reduce_helper(self, df: pd.DataFrame) -> pd.DataFrame:
        df["highest_prob_score"] = np.max(
            df[self._get_probs_cols(df)].values.tolist(), axis=1
        )
        df = (
            df.sort_values(
                ["highest_prob_score", SpanCols.CONTEXT_UID, "__idx"],
                # To replicate idxmax's behavior, we choose the FIRST row that has the max value
                ascending=[True, False, False],
            ).drop_duplicates([SpanCols.CONTEXT_UID], keep="last")
            # Do one last sort - there is no explicit sort on the dask dataframe as that would
            # be more expensive, so sort by the index here.
            .sort_values(DATAPOINT_UID_COL)
        )

        return df


class DocumentMostCommonReducer(BuiltInSpanReducer):
    """Reduces spans predictions in a document to the span which occurs most frequently."""

    @property
    def _reduced_datapoint_instance(self) -> DatapointType:
        return DocDatapoint()

    def _reduce_helper(self, df: pd.DataFrame) -> pd.DataFrame:
        # Select a row whose span value is equal to the most common value
        span_value_col = get_span_value_col(df)

        label_counts = df.groupby([SpanCols.CONTEXT_UID, span_value_col]).size()
        label_counts.name = "count"

        # Keep the first span value that is most common per context
        to_keep = (
            label_counts.reset_index()
            .sort_values(["count", span_value_col], ascending=[False, True])
            .drop_duplicates([SpanCols.CONTEXT_UID], keep="first")
        )

        # Trim the dataframe by keeping only the first row for each span value per-context
        df = df.drop_duplicates([SpanCols.CONTEXT_UID, span_value_col], keep="first")

        # Perform a merge to drop any span values that aren't the mode in the context
        df = (
            pd.merge(
                df.reset_index(), to_keep, on=[SpanCols.CONTEXT_UID, span_value_col]
            )
            .set_index("__idx")
            .drop_duplicates([SpanCols.CONTEXT_UID], keep="first")
        )
        return df


class EntityMeanPredictionReducer(BuiltInSpanReducer):
    """Reduces span predictions for a document entity by computing the mean prediction."""

    @property
    def _reduced_datapoint_instance(self) -> DatapointType:
        return EntityDatapoint()

    @property
    def input_schema(self) -> ColSchema:
        # Override the base Reducer's input_schema to include preds/probs cols
        return {
            SpanCols.CHAR_START: int,
            SpanCols.CHAR_END: int,
            SpanCols.SPAN_TEXT: str,
            self._preds_col: int,
            self._probs_col: list,
        }

    def _reduce_helper(self, df: pd.DataFrame) -> pd.DataFrame:
        span_value_col = get_span_value_col(df)
        grouped = df.groupby([SpanCols.CONTEXT_UID, span_value_col])
        reduced_df = grouped.first()

        # Pandas is very particular about everything being lists and not numpy arrays
        mean_probs = [
            e.tolist() for e in grouped[self._get_probs_cols(df)].mean().values
        ]

        most_likely_class = np.argmax(mean_probs, axis=1)
        reduced_df[self._probs_col] = mean_probs
        reduced_df[self._preds_col] = most_likely_class

        return reduced_df.sort_values(DATAPOINT_UID_COL)


TIEBREAK_OPTIONS = ["first (no tiebreak)", "first", "last", "confidence"]


class EntityMostCommonReducer(BuiltInSpanReducer):
    """Reduces span predictions for a document entity to the prediction of the majority vote class."""

    # TODO: Support showing selective args since preds and probs are internal
    show_args_in_gui: bool = True

    @property
    def input_schema(self) -> ColSchema:
        # Override the base Reducer's input_schema to include probs col
        schema: ColSchema = {
            SpanCols.CHAR_START: int,
            SpanCols.CHAR_END: int,
            SpanCols.SPAN_TEXT: str,
            # May be an int or str (e.g. when working with hierarchical labels)
            self._preds_col: None,
        }
        if self.tie_break == "confidence":
            schema[self._probs_col] = list
        return schema

    @property
    def _reduced_datapoint_instance(self) -> DatapointType:
        return EntityDatapoint()

    @staticmethod
    def get_options() -> Dict[str, List[str]]:
        return dict(tie_break=TIEBREAK_OPTIONS)

    def __init__(
        self,
        tie_break: Optional[str] = "first (no tiebreak)",
        preds_col: str = ModelCols.PREDICTION_INT,
    ) -> None:
        super().__init__(preds_col=preds_col)
        # For backwards compatibilty, map None to the default tiebreak strategy
        # TODO: Write migration to migrate postprocessors away from the None tiebreak strategy
        if tie_break is None:
            tie_break = "first (no tiebreak)"
        if tie_break not in self.get_options()["tie_break"]:
            raise ValueError(
                "tie_break option must be in {TIEBREAK_OPTIONS}, found {tie_break}"
            )
        self.tie_break = tie_break

    def _reduce_helper(self, df: pd.DataFrame) -> pd.DataFrame:
        span_value_col = get_span_value_col(df)
        pred_counts = (
            df.groupby([SpanCols.CONTEXT_UID, span_value_col, self._preds_col])
            .size()
            .unstack(fill_value=0)
        )
        class_is_majority_series = pred_counts.eq(
            pred_counts.max(axis=1), axis=0
        ).stack()
        class_is_majority_series.name = "is_majority"

        df = df.join(
            class_is_majority_series,
            on=[SpanCols.CONTEXT_UID, span_value_col, self._preds_col],
        )
        df = df[df["is_majority"]]

        # TODO: There is definitely some way to reuse the code from EntityXXXReducer
        #       for each of the tie break strategies.
        if self.tie_break in ["first (no tiebreak)", "first"]:
            # Grab the first span of the context, ordered by UID
            df = df.sort_values("__idx").drop_duplicates(
                [SpanCols.CONTEXT_UID, span_value_col], keep="first"
            )
        elif self.tie_break == "last":
            # Grab the last span of the context, ordered by UID
            df = df.sort_values("__idx").drop_duplicates(
                [SpanCols.CONTEXT_UID, span_value_col], keep="last"
            )
        else:
            # Compute the highest probability score per-context
            df["highest_prob_score"] = np.max(
                df[self._get_probs_cols(df)].values.tolist(), axis=1
            )
            df = (
                # Grab the first span in the context that has the highest probability score to break ties
                df.sort_values(
                    ["highest_prob_score", "__idx"],
                    # To replicate idxmax's behavior, we choose the FIRST row that has the max value
                    ascending=[False, True],
                )
                .drop_duplicates([SpanCols.CONTEXT_UID, span_value_col], keep="first")
                .sort_values("__idx")
            )
        return df


class EntityMostConfidentReducer(BuiltInSpanReducer):
    """Reduces span predictions for a document entity to the most confident prediction."""

    @property
    def input_schema(self) -> ColSchema:
        # Override the base Reducer's input_schema to include preds col
        return {
            SpanCols.CHAR_START: int,
            SpanCols.CHAR_END: int,
            SpanCols.SPAN_TEXT: str,
            self._probs_col: list,
        }

    @property
    def _reduced_datapoint_instance(self) -> DatapointType:
        return EntityDatapoint()

    def _reduce_helper(self, df: pd.DataFrame) -> pd.DataFrame:
        span_value_col = get_span_value_col(df)
        df["highest_prob_score"] = np.max(
            df[self._get_probs_cols(df)].values.tolist(), axis=1
        )
        df = (
            df.sort_values(
                ["highest_prob_score", SpanCols.CONTEXT_UID, span_value_col, "__idx"],
                # To replicate idxmax's behavior, we choose the FIRST row that has the max value
                ascending=[True, False, False, False],
            ).drop_duplicates([SpanCols.CONTEXT_UID, span_value_col], keep="last")
            # Do one last sort - there is no explicit sort on the dask dataframe as that would
            # be more expensive, so sort by the index here.
            .sort_values(DATAPOINT_UID_COL)
        )
        return df


class EntityFirstReducer(BuiltInSpanReducer):
    """Reduces span predictions for a document entity to the first occuring span of that entity."""

    @property
    def _reduced_datapoint_instance(self) -> DatapointType:
        return EntityDatapoint()

    def _reduce_helper(self, df: pd.DataFrame) -> pd.DataFrame:
        span_value_col = get_span_value_col(df)
        df = (
            df.sort_values(SpanCols.CHAR_START).drop_duplicates(
                [SpanCols.CONTEXT_UID, span_value_col], keep="first"
            )
            # Do one last sort - there is no explicit sort on the dask dataframe as that would
            # be more expensive, so sort by the index here.
            .sort_values(DATAPOINT_UID_COL)
        )
        return df


class EntityLastReducer(BuiltInSpanReducer):
    """Reduces span predictions for a document entity to the last occuring span of that entity."""

    @property
    def _reduced_datapoint_instance(self) -> DatapointType:
        return EntityDatapoint()

    def _reduce_helper(self, df: pd.DataFrame) -> pd.DataFrame:
        span_value_col = get_span_value_col(df)
        df = (
            # The equivalent of df.loc[df.groupby(...)[...].idxmax()], but faster
            df.sort_values(SpanCols.CHAR_END).drop_duplicates(
                [SpanCols.CONTEXT_UID, span_value_col], keep="last"
            )
            # Do one last sort - there is no explicit sort on the dask dataframe as that would
            # be more expensive, so sort by the index here.
            .sort_values(DATAPOINT_UID_COL)
        )
        return df
