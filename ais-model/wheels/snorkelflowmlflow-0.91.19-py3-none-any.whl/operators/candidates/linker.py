import json
from typing import Dict

import pandas as pd

from file_utils.core import LocalReadFsspecPath
from snorkelflow.extraction.span import SpanCols
from snorkelflow.operators.featurizer import Featurizer, OpProgressCallback
from snorkelflow.operators.operator import ColSchema, no_op_progress_callback


class EntityDictLinker(Featurizer):
    """Maps span_text to span_entity given an entity to alias dictionary."""

    def __init__(self, entity_dict_path: str, ignore_case: bool = False):
        self.entity_lookup_table: Dict[str, str] = {}
        self.ignore_case = ignore_case
        with LocalReadFsspecPath(entity_dict_path) as local_path:
            with open(local_path, "r") as f:
                entity_dict = json.load(f)
                for entity_id, common_entity_forms in entity_dict.items():
                    for value in common_entity_forms:
                        if ignore_case:
                            value = value.lower()
                        self.entity_lookup_table[value] = entity_id

    @property
    def input_schema(self) -> ColSchema:
        return {SpanCols.SPAN_TEXT: str}

    @property
    def output_schema(self) -> ColSchema:
        return {SpanCols.SPAN_ENTITY: str}

    def _compute_features(
        self,
        input_df: pd.DataFrame,
        callback: OpProgressCallback = no_op_progress_callback,
    ) -> pd.DataFrame:
        input_df_span_text = input_df.span_text
        if self.ignore_case:
            input_df_span_text = input_df_span_text.str.lower()
        input_df[SpanCols.SPAN_ENTITY] = input_df_span_text.map(
            self.entity_lookup_table
        )
        return input_df
