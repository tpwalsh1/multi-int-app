import re
from typing import List

import pandas as pd
from dask import dataframe as dd

from operators.filter import FilterTypes, LabelIntFilter
from snorkelflow.extraction.span import SpanCols
from snorkelflow.operators.operator import (
    ColSchema,
    Operator,
    OperatorExample,
    df_operator_error_wrapper,
)
from snorkelflow.types.model import ModelCols
from snorkelflow.utils.logging import get_logger

logger = get_logger("Filter")


class RegexSpanFilter(Operator):
    """A filter that REMOVES all candidates that match a given regular expresion"""

    def __init__(
        self, regex: str, field: str = SpanCols.SPAN_TEXT, ignore_case: bool = False
    ) -> None:
        self.regex = re.compile(  # type: ignore
            regex, flags=re.IGNORECASE if ignore_case else 0
        )
        self.field = field

    @property
    def input_schema(self) -> ColSchema:
        return {self.field: None}

    @property
    def output_schema(self) -> ColSchema:
        return {self.field: None}

    def _execute(self, input_ddfs: List[dd.DataFrame]) -> dd.DataFrame:
        ddf = input_ddfs[0]

        def map_fn(df: pd.DataFrame) -> pd.DataFrame:
            return df[df[self.field].map(lambda x: not bool(self.regex.search(x)))]

        return dd.map_partitions(
            df_operator_error_wrapper(
                map_fn, self.__class__.__name__, getattr(self, "node_uid", None)
            ),
            ddf,
        )


class ExtractedSpanFilter(LabelIntFilter):
    """
    A filter that removes all spans with a negative prediction.

    Parameters
    ----------
    prediction_col
        The column contains (integer representation) prediction
    negative_label
        The (integer representation) of the NEGATIVE label

    """

    show_args_in_gui: bool = False

    def __init__(
        self, prediction_col: str = ModelCols.PREDICTION_INT, negative_label: int = 0
    ) -> None:
        super(ExtractedSpanFilter, self).__init__(
            label_ints=[negative_label],
            filter_type=FilterTypes.EXCLUDE,
            label_col=prediction_col,
        )

    @staticmethod
    def examples() -> List[OperatorExample]:
        return [
            OperatorExample(
                input_df={
                    ModelCols.PREDICTION_INT: [0, 0, 1, 1],
                    ModelCols.PREDICTION_STR: ["SPAM", "SPAM", "HAM", "HAM"],
                },
                kwargs=dict(),
                description="Filtering using default prediction column and label",
            ),
            OperatorExample(
                input_df={
                    "predictions": [0, 0, 1, 1],
                    ModelCols.PREDICTION_STR: ["SPAM", "SPAM", "HAM", "HAM"],
                },
                kwargs=dict(prediction_col="predictions", negative_label=1),
                description="Filtering custom predictions column and label",
            ),
        ]
