import pandas as pd

from snorkelflow.extraction.span import SpanCols
from snorkelflow.operators.featurizer import Featurizer, OpProgressCallback
from snorkelflow.operators.operator import ColSchema, no_op_progress_callback
from snorkelflow.utils.logging import get_logger

logger = get_logger("Filter")


class ContextAggregator(Featurizer):
    """Adds a column with aggregated spans for the current context_uid."""

    @property
    def input_schema(self) -> ColSchema:
        return {
            SpanCols.SPAN_FIELD: str,
            SpanCols.CHAR_START: int,
            SpanCols.CHAR_END: int,
            SpanCols.SPAN_TEXT: str,
            SpanCols.INITIAL_LABEL: int,
            SpanCols.SPAN_ENTITY: None,
        }

    @property
    def output_schema(self) -> ColSchema:
        return {SpanCols.CONTEXT_SPANS: object}

    def _compute_features(
        self,
        input_df: pd.DataFrame,
        callback: OpProgressCallback = no_op_progress_callback,
    ) -> pd.DataFrame:
        """Override base class method"""
        # Only add the span_fields
        span_fields = list(self.input_schema.keys())

        context_spans = input_df.groupby([SpanCols.CONTEXT_UID])[span_fields].apply(
            lambda x: x.to_json(orient="records")
        )
        input_df[SpanCols.CONTEXT_SPANS] = input_df.apply(
            lambda row: context_spans.loc[row.context_uid], axis=1
        )

        return input_df
