import pandas as pd

from snorkelflow.operators.featurizer import Featurizer, OpProgressCallback
from snorkelflow.operators.operator import ColSchema, no_op_progress_callback
from snorkelflow.rich_docs import RichDoc, RichDocCols


# DEPRECATED: Kept for backward compatibility with existing tasks that have this
# operator, but shouldn't be needed for new tasks due to custom serialization.
class RichDocPageDeserializer(Featurizer):
    """Operator that deserializes RichDoc page objects.

    This operator deserializes RichDoc page objects for further DAG testing
    and utilizing RichDoc features.
    """

    @property
    def input_schema(self) -> ColSchema:
        return {RichDocCols.PKL_COL: str}

    @property
    def output_schema(self) -> ColSchema:
        return {RichDocCols.DOC_COL: RichDoc}

    def _compute_features(
        self,
        input_df: pd.DataFrame,
        callback: OpProgressCallback = no_op_progress_callback,
    ) -> pd.DataFrame:
        """Override base class method"""
        input_df[RichDocCols.DOC_COL] = input_df[RichDocCols.PKL_COL].map(
            lambda pkl: RichDoc.deserialize(pkl)
        )
        # We should drop the pickled representation here, since we're not using
        # it downstream. However, Featurizer requires that we only add columns.
        # Subclassing Featurizer is important, because we don't want to run
        # expensive deserialization downstream if the RichDoc is not being used
        # (e.g. in model training)
        return input_df
