import re
import uuid
from typing import Any, Dict, Iterable, List, Optional, Tuple, Union

from filelock import SoftFileLock

from api_utils.exceptions import UserInputError
from operators.candidates.extractor import (
    EN,
    ENT_TAG,
    NER_SPAN_TAGS,
    SpanFeaturizer,
    SpanFeaturizerExtractor,
)


class SpacySpanFeaturizer(SpanFeaturizer):
    """An abstract SpanFeaturizer subclass that utilizes spaCy"""

    operator_impl_version: int = 1

    def __init__(
        self,
        field: str,
        model: str = EN,
        disable: Optional[List[str]] = None,
        col_suffix: Optional[str] = None,
        **spacy_kwargs: Any,
    ):
        super().__init__(field, col_suffix=col_suffix)
        self.model = model
        self.spacy_kwargs = spacy_kwargs
        self._max_doc_len = None

        if "max_length" in self.spacy_kwargs:
            try:
                self._max_doc_len = int(self.spacy_kwargs["max_length"])
                del self.spacy_kwargs["max_length"]
            except ValueError:
                err_msg = f"max_length input should be an integer. Provided {self.spacy_kwargs['max_length']}"
                raise UserInputError(detail=err_msg, user_friendly_message=err_msg)

        if "max_doc_len" in self.spacy_kwargs:
            try:
                self._max_doc_len = int(self.spacy_kwargs["max_doc_len"])
                del self.spacy_kwargs["max_doc_len"]
            except ValueError:
                err_msg = f"max_doc_len input should be an integer. Provided {self.spacy_kwargs['max_doc_len']}"
                raise UserInputError(detail=err_msg, user_friendly_message=err_msg)
        self.disable = disable
        self._lock_path = f"/tmp/{uuid.uuid4()}"
        self._lazy_model: Any = None

    @property
    def _nlp(self) -> Any:
        with SoftFileLock(self._lock_path):
            if self._lazy_model:
                return self._lazy_model
            # TODO: Disable unused pipeline components based on requested tag type
            try:
                # NOTE: We do not use the Snorkel OSS SpacyPreprocessor because we would
                # need to specify at init time a single field to always use as input
                import spacy

                self._lazy_model = spacy.load(
                    self.model, disable=self.disable or [], **self.spacy_kwargs
                )
                if self._max_doc_len is not None:
                    self._lazy_model.max_length = self._max_doc_len
                return self._lazy_model
            except OSError:
                raise ValueError(
                    f"spaCy model {self.model} is not available in this build of Snorkel Flow"
                )


class TagSpanFeaturizer(SpacySpanFeaturizer):
    """
    A SpanFeaturizer that yields all matches for a given NER tag according to spaCy

    Parameters
    ----------
    tag
        The set of tags to look for
    attr
        The spaCy attribute to compare to the tags (e.g., ``ent_type_``)
    model
        The model to load into spaCy (only supports models in strap)
    fields
        The fields in which to look for candidates
    match_longest
        If True, return contiguous chunks of a tag as a single candidate
    """

    def __init__(
        self,
        field: str,
        tag: Union[str, List[str]],
        attr: str = ENT_TAG,
        match_longest: bool = True,
        **spacy_span_kwargs: Any,
    ):
        disable = spacy_span_kwargs.pop("disable", [])
        if attr == ENT_TAG:
            disable = ["tagger", "parser"]
        super().__init__(field=field, disable=disable, **spacy_span_kwargs)
        self.tags = tag if isinstance(tag, list) else [tag]
        self.attr = attr
        self.match_longest = match_longest

    def extract_span_list_from_str(
        self, content: str, datapoint_uid: Optional[str] = None
    ) -> Iterable[Tuple[int, int, Optional[str]]]:
        if not self.match_longest:
            for token in self._nlp(content):
                if getattr(token, self.attr) in self.tags:
                    yield (token.idx, token.idx + len(token) - 1, None)
        else:
            if self.attr == ENT_TAG:
                # Find groups of tags via ents property
                for ent in self._nlp(content).ents:
                    if ent.label_ in self.tags:
                        yield (ent.start_char, ent.end_char - 1, None)
            else:
                # Find groups of tags manually
                matches = []
                # In this for loop, index is the index of the token
                for index, token in enumerate(self._nlp(content)):
                    if getattr(token, self.attr) in self.tags:
                        # spaCy's Token.idx is the character offset of the token
                        span: Tuple[int, int, Optional[str]] = (
                            token.idx,
                            token.idx + len(token) - 1,
                            None,
                        )
                        matches.append((index, span))
                for span in self._merge_matches(matches):
                    yield span

    def _merge_matches(
        self, matches: List[Tuple[int, Tuple[int, int, Optional[str]]]]
    ) -> Iterable[Tuple[int, int, Optional[str]]]:
        # TODO: No doubt this can be calculated more elegantly/efficiently
        if not matches:
            return
        # The first contiguous match will start with the span of the first matched token
        first_span = matches[0][1]  # Pull out (start_char, end_char) of the first match
        char_start = first_span[0]
        for i, (token_idx, span) in enumerate(matches):
            # If we're on the last matched token, then we don't need to check if the
            # next token is also match because there is no next token
            is_last = i == len(matches) - 1
            if not is_last:
                # Check if the next match in our list of matches is contiguous to the
                # current match (i.e., has a token index just one away)
                is_contiguous = matches[i + 1][0] == token_idx + 1
                if is_contiguous:
                    # If there are more of this tag after the current token, then don't
                    # yield the match yet, since it can still be expanded
                    continue
            char_end = span[1]
            entity = span[2]
            yield (char_start, char_end, entity)
            # Reset the char_start whenever a "longest" span is yielded
            if not is_last:
                next_span = matches[i + 1][1]
                char_start = next_span[0]


class SpacyNERSpanFeaturizer(TagSpanFeaturizer):
    """
    A SpanFeaturizer that yields all matches for a default list of NER tags according to spaCy

    Parameters
    ----------
    tag
        A valid NER tag (see options)
    attr
        The spaCy attribute to compare to the tags (e.g., ``ent_type_``)
    model
        The model to load into spaCy (only supports models in strap)
    fields
        The fields in which to look for candidates
    match_longest
        If True, return contiguous chunks of a tag as a single candidate
    """

    @staticmethod
    def get_options() -> Dict[str, List[str]]:
        return dict(tag=NER_SPAN_TAGS)

    def __init__(
        self, tag: str, field: str, match_longest: bool = True, **spacy_span_kwargs: Any
    ):
        if tag not in self.get_options()["tag"]:
            raise ValueError(f"tag argument must be in {NER_SPAN_TAGS}, found {tag}")
        super().__init__(
            tag=tag, field=field, match_longest=match_longest, **spacy_span_kwargs
        )


class TagSpanExtractor(SpanFeaturizerExtractor, TagSpanFeaturizer):
    """A SpanExtractor that yields all matches for a given NER tag according to spaCy

    Parameters
    ----------
    tag
        The set of tags to look for
    attr
        The spaCy attribute to compare to the tags (e.g., ``ent_type_``)
    model
        The model to load into spaCy (only supports models in strap)
    fields
        The fields in which to look for candidates
    match_longest
        If True, return contiguous chunks of a tag as a single candidate
    """

    def __init__(
        self,
        field: str,
        tag: Union[str, List[str]],
        attr: str = ENT_TAG,
        match_longest: bool = True,
        col_suffix: Optional[str] = None,
        **spacy_span_kwargs: Any,
    ):
        TagSpanFeaturizer.__init__(
            self,
            field=field,
            tag=tag,
            attr=attr,
            match_longest=match_longest,
            col_suffix=col_suffix,
            **spacy_span_kwargs,
        )
        SpanFeaturizerExtractor.__init__(self, field=field, col_suffix=col_suffix)


class NounChunkSpanFeaturizer(SpacySpanFeaturizer):
    """
    A SpanFeaturizer that yields all noun phrases according to spaCy

    Parameters
    ----------
    field
        The dataframe column to apply the tokenization strategy over
    """

    def __init__(self, field: str, **spacy_span_kwargs: Any):
        super().__init__(field=field, disable=["ner"], **spacy_span_kwargs)

    def extract_span_list_from_str(
        self, content: str, datapoint_uid: Optional[str] = None
    ) -> Iterable[Tuple[int, int, Optional[str]]]:
        for chunk in self._nlp(content).noun_chunks:
            yield (chunk.start_char, chunk.end_char - 1, None)


class NounChunkSpanExtractor(SpanFeaturizerExtractor, NounChunkSpanFeaturizer):
    """A SpanExtractor that yields all noun phrases according to spaCy"""

    def __init__(
        self, field: str, col_suffix: Optional[str] = None, **spacy_span_kwargs: Any
    ):
        NounChunkSpanFeaturizer.__init__(
            self, field=field, col_suffix=col_suffix, **spacy_span_kwargs
        )
        SpanFeaturizerExtractor.__init__(self, field=field, col_suffix=col_suffix)


class SpacyNERSpanExtractor(SpanFeaturizerExtractor, SpacyNERSpanFeaturizer):
    def __init__(
        self,
        tag: str,
        field: str,
        match_longest: bool = True,
        col_suffix: Optional[str] = None,
        **spacy_span_kwargs: Any,
    ):
        SpacyNERSpanFeaturizer.__init__(
            self,
            tag=tag,
            field=field,
            match_longest=match_longest,
            col_suffix=col_suffix,
            **spacy_span_kwargs,
        )
        SpanFeaturizerExtractor.__init__(self, field=field, col_suffix=col_suffix)


class TokenSpanFeaturizer(SpacySpanFeaturizer):
    """
    A SpanFeaturizer that yields every token, given a selected tokenization strategy

    Given a valid tokenization strategy, this operator will tokenize the input dataframe
    into spans based on the produced tokens.

    Parameters
    ----------
    field
        The dataframe column to apply the tokenization strategy over
    tokenizer
        The tokenizer strategy (one of "spacy" or "whitespace")
    """

    def __init__(self, field: str, tokenizer: str = "spacy", **spacy_span_kwargs: Any):
        self._tokenizer = tokenizer
        if tokenizer == "whitespace":
            # TODO: restructure so that spacy is not a dependency for whitespace tokenization
            SpanFeaturizer.__init__(self, field=field)
        elif tokenizer == "regex":
            raise NotImplementedError
        elif tokenizer == "spacy":
            super().__init__(
                field=field, disable=["tagger", "parser", "ner"], **spacy_span_kwargs
            )
        compiled_regex = re.compile(r"\S+")
        self._whitespace_nlp = lambda inp: re.finditer(compiled_regex, inp)
        self._use_spacy = tokenizer == "spacy"

    @property
    def _nlp(self) -> Any:
        if self._tokenizer == "whitespace":
            # assign self._nlp to be a re parser, not spacy-based
            return self._whitespace_nlp
        else:
            return super()._nlp

    def extract_span_list_from_str(
        self, content: str, datapoint_uid: Optional[str] = None
    ) -> Iterable[Tuple[int, int, Optional[str]]]:
        if self._use_spacy:
            for token in self._nlp(content):
                yield (token.idx, token.idx + len(token) - 1, None)
        else:
            for token in self._nlp(content):
                yield (token.span(0)[0], token.span(0)[1] - 1, None)


class TokenSpanExtractor(SpanFeaturizerExtractor, TokenSpanFeaturizer):
    """A SpanExtractor that yields every token, given a selected tokenization strategy"""

    def __init__(
        self,
        field: str,
        tokenizer: str = "spacy",
        col_suffix: Optional[str] = None,
        **spacy_span_kwargs: Any,
    ):
        TokenSpanFeaturizer.__init__(
            self,
            field=field,
            tokenizer=tokenizer,
            col_suffix=col_suffix,
            **spacy_span_kwargs,
        )
        SpanFeaturizerExtractor.__init__(self, field=field, col_suffix=col_suffix)


class SpacySpanExtractor(SpanFeaturizerExtractor, SpacySpanFeaturizer):
    """An abstract SpanExtractor subclass that utilizes spaCy"""

    def __init__(
        self,
        field: str,
        model: str = EN,
        disable: Optional[List[str]] = None,
        col_suffix: Optional[str] = None,
        **spacy_kwargs: Any,
    ):
        SpacySpanFeaturizer.__init__(
            self,
            field=field,
            model=model,
            disable=disable,
            col_suffix=col_suffix,
            **spacy_kwargs,  # type: ignore
        )
        SpanFeaturizerExtractor.__init__(self, field=field, col_suffix=col_suffix)
