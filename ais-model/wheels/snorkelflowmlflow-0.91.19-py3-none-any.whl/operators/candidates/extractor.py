import json
import re
from collections import defaultdict
from typing import Any, DefaultDict, Dict, Iterable, List, Optional, Tuple

import pandas as pd
import regex
from dask import dataframe as dd

from file_utils.core import LocalReadFsspecPath
from regex_utils.trie import Trie
from snorkelflow.data import core as data_lib
from snorkelflow.extraction.span import SpanCols
from snorkelflow.operators.candidates import (
    SpanExtractor,
    SpanFeaturizer,
    SpanFeaturizerExtractor,
    get_span_field_value_hash,
)
from snorkelflow.operators.operator import ColSchema, OperatorExample
from snorkelflow.types.load import DATAPOINT_UID_COL, LoadConfig, SourceType
from snorkelflow.types.performance import Performance
from snorkelflow.utils.dask import dask_compute
from snorkelflow.utils.datapoint import DocDatapoint, SpanDatapoint
from snorkelflow.utils.file import resolve_data_path
from snorkelflow.utils.logging import get_logger

# Note: leaving the default model as en_core_web_sm instead of en_core_web_md due
# to missed entity tags in our tests
EN = "en_core_web_sm"
ENT_TAG = "ent_type_"
DATE_REGEX = "(?:[0-9]{1,2}(?:st|nd|rd|th)?\s*(?:day)?\s*(?:of)?\s*.?(?:(?:Jan(?:.|uary)?)|(?:Feb(?:.|ruary)?)|(?:Mar(?:.|ch)?)|(?:Apr(?:.|il)?)|May|(?:Jun(?:.|e)?)|(?:Jul(?:.|y)?)|(?:Aug(?:.|ust)?)|(?:Sep(?:.|tember)?)|(?:Oct(?:.|ober)?)|(?:Nov(?:.|ember)?)|(?:Dec(?:.|ember)?)),?.?\s*[12][0-9]{3})|(?:(?:(?:Jan(?:.|uary)?)|(?:Feb(?:.|ruary)?)|(?:Mar(?:.|ch)?)|(?:Apr(?:.|il)?)|May|(?:Jun(?:.|e)?)|(?:Jul(?:.|y)?)|(?:Aug(?:.|ust)?)|(?:Sep(?:.|tember)?)|(?:Oct(?:.|ober)?)|(?:Nov(?:.|ember)?)|(?:Dec(?:.|ember)?)).?\s*[0-9]{1,2}(?:st|nd|rd|th)?\s*(?:day)?\s*(?:of)?,?.?\s*[12][0-9]{3})"

logger = get_logger("Extractor")


class ListToRowsExploder(SpanExtractor):
    """A SpanExtractor that explodes a field containing a list of spans.

    This can be combined with a featurizer that produces a list of spans.
    For the featurizer before this operator, each field's type in the output schema
    should be object rather than the type in the list.

    Parameters
    ----------
    span_fields_schema
        Dictionary mapping a span field name to the type contained within that field
    """

    # for other types specified in the schema, they will be converted to object
    SUPPORTED_TYPE_NAMES = {"str": str, "int": int, "float": float, "bool": bool}

    def __init__(self, span_fields_schema: Dict[str, str]):
        self.span_fields_schema: ColSchema = {
            field: ListToRowsExploder.SUPPORTED_TYPE_NAMES[type_str]
            if type_str in ListToRowsExploder.SUPPORTED_TYPE_NAMES
            else object
            for field, type_str in span_fields_schema.items()
        }
        self.span_fields = list(self.span_fields_schema.keys())
        self.new_datapoint_cols = self.span_fields

    @property
    def input_schema(self) -> ColSchema:
        return {field: None for field, _ in self.span_fields_schema.items()}

    @property
    def output_schema(self) -> ColSchema:
        output_schema = self.get_suffixed_dict(self.span_fields_schema)
        assert output_schema is not None
        return output_schema

    def _execute(self, input_ddfs: List[dd.DataFrame]) -> dd.DataFrame:
        """Override base class method"""
        ddf = input_ddfs[0]
        return self.extract_from_ddf(ddf)

    @staticmethod
    def examples() -> List[OperatorExample]:
        return [
            OperatorExample(
                input_df=dict(
                    index=["doc::0"],
                    text=["The total for your order is $5.50, $5.89 with tax"],
                    span_field_hash_value=[
                        [
                            "90b50201f3d6104d5db7e9d2bd52f886",
                            "b64461cac929d743baaa3f36b6a20926",
                        ]
                    ],
                    char_start=[[28, 35]],
                    char_end=[[32, 39]],
                    span_text=[["$5.50", "$5.89"]],
                    initial_label=[[-1, -1]],
                ),
                kwargs=dict(
                    span_fields_schema=dict(
                        span_field_hash_value="str",
                        char_start="int",
                        char_end="int",
                        span_text="str",
                        initial_label="int",
                    )
                ),
            )
        ]

    def extract_from_ddf(self, ddf: dd.DataFrame) -> dd.DataFrame:
        """Return a ddf indicating Span candidates extracted from the given ddf

        Parameters
        ----------
        ddf:
            The dataframe to extract candidates from

        Returns
        -------
        dd.DataFrame
            A dataframe of candidate information (metadata)
        """
        datapoint_instance = SpanDatapoint(self.new_datapoint_cols)

        def explode(df: pd.DataFrame) -> pd.DataFrame:
            exploded_df = df[self.span_fields].apply(pd.Series.explode).dropna()
            exploded_df[DATAPOINT_UID_COL] = exploded_df.apply(
                lambda row: datapoint_instance.get_new_datapoint_uid_from_old(
                    row.name, row.to_dict()
                ),
                axis=1,
            )
            return exploded_df.join(df.drop(columns=self.span_fields)).set_index(
                DATAPOINT_UID_COL
            )

        assert self.output_meta is not None  # mypy
        old_meta = {
            k: v for k, v in ddf.dtypes.to_dict().items() if k not in self.output_meta
        }
        return ddf.map_partitions(explode, meta={**self.output_meta, **old_meta})


class EmptySpanFeaturizer(SpanFeaturizer):
    """A SpanFeaturizer that yields a single empty span from (0,0) for each row

    This can be used to create a candidate set with a one-to-one mapping
    with documents, which can serve as a starting point for labeling GT manually.
    """

    @staticmethod
    def examples() -> List[OperatorExample]:
        return [
            OperatorExample(
                input_df=dict(
                    index=["doc::0", "doc::1"],
                    text=[
                        "It doesn't matter what I place in this text, nothing will be extracted",
                        "Same with this one - the EmptySpanFeaturizer does not care",
                    ],
                ),
                kwargs=dict(field="text"),
            )
        ]

    def extract_span_list_from_str(
        self, content: str, datapoint_uid: Optional[str] = None
    ) -> Iterable[Tuple[int, int, Optional[str]]]:
        yield (0, 0, None)


class RegexSpanFeaturizer(SpanFeaturizer):
    """
    A SpanFeaturizer that yields all matches for a given regular expression

    This operator applies a given regular expression over a specified field
    in the passing DataFrame and adds each match as a new span in the output.

    Parameters
    ----------
    regex
        The regular expression to apply over the data
    field
        The name of the column in the dataframe to apply to provided regex over
    ignore_case
        If true, ignore case when considering regular expression matches (defaults to false)
    capture_group
        The capture group to provide to the regex results
    col_suffix
        An optional suffix for the column containing the extracted spans
    """

    def __init__(
        self,
        regex: str,
        field: str,
        ignore_case: bool = False,
        capture_group: int = 0,
        col_suffix: Optional[str] = None,
    ):
        super().__init__(field, col_suffix)
        self.capture_group = capture_group
        self.regex = re.compile(  # type: ignore
            regex, flags=re.IGNORECASE if ignore_case else 0
        )

    def extract_span_list_from_str(
        self, content: str, datapoint_uid: Optional[str] = None
    ) -> Iterable[Tuple[int, int, Optional[str]]]:
        for match in self.regex.finditer(content):
            char_start, char_end_exclusive = match.span(self.capture_group)
            yield (char_start, char_end_exclusive - 1, None)

    def estimate_perf(self, df: pd.DataFrame) -> Performance:
        total_len = df[self.field].map(len).sum()
        return Performance(
            compute_time_secs=total_len * 0.00001, peak_memory_mb=total_len * 0.00003
        )

    @staticmethod
    def examples() -> List[OperatorExample]:
        URL_REGEX = r"http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\(\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+"
        return [
            OperatorExample(
                input_df=dict(
                    index=["doc::0", "doc::1"],
                    text=[
                        "Allow https://zoom.com to access your microphone?",
                        "Is it https://snorkel.ai or http://snorkel.ai?",
                    ],
                ),
                kwargs=dict(field="text", regex=URL_REGEX),
                description="This shows how to extract URLs from a text field",
            )
        ]


class DateSpanFeaturizer(RegexSpanFeaturizer):
    """
    Extracts spans (slices of documents) that contain dates (using regex)

    This operator uses a regex to extract all spans from the parent document
    that contain dates. The vast majority of standard date formats are supported,
    including ISO-8601, RFC-3339, and others.

    Parameters
    ----------
    field
        The dataframe column to extract date spans from
    col_suffix
        An optional suffix for the column containing the extracted spans

    """

    def __init__(self, field: str, col_suffix: Optional[str] = None):
        super().__init__(regex=DATE_REGEX, field=field, col_suffix=col_suffix)

    @staticmethod
    def examples() -> List[OperatorExample]:
        return [
            OperatorExample(
                input_df=dict(
                    index=["doc::0", "doc::1", "doc::2"],
                    text=[
                        "This message was created 2022-03-04T12:13:14 but updated 2022-03-05T10:06:04",
                        "I was born on December 4th, 1992",
                        "When was that, Nov. 10th?",
                    ],
                ),
                kwargs=dict(field="text"),
            )
        ]


class ParagraphSpanFeaturizer(RegexSpanFeaturizer):
    """
    Extracts spans (slices of documents) that contain paragraphs (using regex)

    This operator uses a regex pattern to extract all paragraphs as spans from
    the parent document. Trailing newline characters are preserved for each paragraph

    Parameters
    ----------
    field
        The dataframe column to extract paragraph spans from
    col_suffix
        An optional suffix for the column containing the extracted spans

    """

    def __init__(self, field: str, col_suffix: Optional[str] = None):
        paragraph_regex = r"(?s)((?:[^\n][\n]?)+)"
        super().__init__(
            regex=paragraph_regex, field=field, ignore_case=True, col_suffix=col_suffix
        )

    @staticmethod
    def examples() -> List[OperatorExample]:
        return [
            OperatorExample(
                input_df=dict(
                    index=["doc::0"],
                    text=[
                        "This message was created 2022-03-04T12:13:14 but updated 2022-03-05T10:06:04\n\nI was born on December 4th, 1992"
                    ],
                ),
                kwargs=dict(field="text"),
            )
        ]


class NumericSpanFeaturizer(RegexSpanFeaturizer):
    """
    Extracts spans (slices of documents) that contain numeric values

    Parameters
    ----------
    field
        The dataframe column to extract numeric spans from
    col_suffix
        An optional suffix for the column containing the extracted spans

    """

    def __init__(self, field: str, col_suffix: Optional[str] = None):
        super().__init__(regex="[\d][\d\.\,]*", field=field, col_suffix=col_suffix)

    @staticmethod
    def examples() -> List[OperatorExample]:
        return [
            OperatorExample(
                input_df=dict(
                    index=["doc::0"],
                    text=[
                        "The tax rate increased by 0.15% in fiscal year 2022, resulting in increased expenses of $1000"
                    ],
                ),
                kwargs=dict(field="text"),
            )
        ]


class EmailAddressSpanFeaturizer(RegexSpanFeaturizer):
    """
    Extracts spans (slices of documents) that contain email addresses (using regex)

    This operator uses a regex to extract all spans from the parent document
    that contain properly formatted email addresses according to RFC6530.

    Parameters
    ----------
    field
        The dataframe column to extract email address spans from
    col_suffix
        An optional suffix for the column containing the extracted spans

    """

    def __init__(self, field: str, col_suffix: Optional[str] = None):
        # Some restrictions on characters but still permissive
        # Adapted from https://www.regular-expressions.info/email.html
        super().__init__(
            regex="[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}",
            field=field,
            ignore_case=True,
            col_suffix=col_suffix,
        )

    @staticmethod
    def examples() -> List[OperatorExample]:
        return [
            OperatorExample(
                input_df=dict(
                    index=["doc::0"], text=["send a message to someone@example.com"]
                ),
                kwargs=dict(field="text"),
            )
        ]


class USCurrencySpanFeaturizer(RegexSpanFeaturizer):
    """
    Extracts spans (slices of documents) that contain US currency (using regex)

    Parameters
    ----------
    field
        The dataframe column to extract currency amount spans from
    col_suffix
        An optional suffix for the column containing the extracted spans

    """

    def __init__(self, field: str, col_suffix: Optional[str] = None):
        super().__init__(
            regex="\\$\s{0,2}([0-9]{1,3},([0-9]{3},)*[0-9]{3}|[0-9]+)(\\.[0-9][0-9])?",
            field=field,
            col_suffix=col_suffix,
        )

    @staticmethod
    def examples() -> List[OperatorExample]:
        return [
            OperatorExample(
                input_df=dict(
                    index=["doc::0"],
                    text=["The total for your order is $5.50, $5.89 with tax."],
                ),
                kwargs=dict(field="text"),
            )
        ]


# List from https://spacy.io/api/annotation#named-entities
NER_SPAN_TAGS: List[str] = [
    "PERSON",
    "NORP",
    "FAC",
    "ORG",
    "GPE",
    "LOC",
    "PRODUCT",
    "EVENT",
    "WORK_OF_ART",
    "LAW",
    "LANGUAGE",
    "DATE",
    "TIME",
    "PERCENT",
    "MONEY",
    "QUANTITY",
    "ORDINAL",
    "CARDINAL",
]


class HardCodedSpanFeaturizer(SpanFeaturizer):
    """
    A SpanFeaturizer that reads spans directly from its config.

    This SpanFeaturizer directly takes in span definitions as part
    of its config and applies those span definitions over the passing
    DataFrame.

    Parameters
    ----------
    char_starts
        The indices of the first characters of the spans for this candidate
    char_ends
        The indices of the last characters of the spans for this candidate
    context_uids
        The UIDs of the columns in the passing dataframe to extract the specified span from
    span_fields
        The names of the fields that these spans are extracted from
    initial_labels
        The labels assigned to spans at creation time (if available)
    span_entities
        The entities linked to the span_text
    col_suffix
        An optional suffix for the column containing the extracted spans
    """

    def __init__(
        self,
        char_starts: List[int],
        char_ends: List[int],
        context_uids: List[int],
        span_fields: List[str],
        initial_labels: List[int],
        span_entities: List[Optional[str]],
        col_suffix: Optional[str] = None,
    ):
        if not span_entities:
            span_entities = [None] * len(context_uids)

        doc_datapoint_instance = DocDatapoint()
        datapoint_uids = [
            doc_datapoint_instance.get_datapoint_uid_from_values([x])
            for x in context_uids
        ]

        if not (
            len(char_starts)
            == len(char_ends)
            == len(span_fields)
            == len(initial_labels)
            == len(span_entities)
            == len(datapoint_uids)
        ):
            raise ValueError("All input lists must be the same length.")

        self.uid_to_spans: DefaultDict[str, List[tuple]] = defaultdict(list)
        for (
            char_start,
            char_end,
            span_field,
            initial_label,
            span_entity,
            datapoint_uid,
        ) in zip(
            char_starts,
            char_ends,
            span_fields,
            initial_labels,
            span_entities,
            datapoint_uids,
        ):
            self.uid_to_spans[datapoint_uid].append(
                (char_start, char_end, span_field, initial_label, span_entity)
            )
        # Set self.fields so the dataframe gets truncated in extract_from_ddf before we iterate on it.
        fields = list(set(span_fields))
        if len(fields) == 0:
            raise ValueError("Must contain at least one span")
        if len(fields) > 1:
            raise ValueError("All spans must refer to the same field.")
        super().__init__(fields[0], col_suffix)

    @staticmethod
    def examples() -> List[OperatorExample]:
        return [
            OperatorExample(
                input_df={
                    "index": ["doc::0", "doc::1"],
                    SpanCols.CONTEXT_UID: [0, 1],
                    "recipient": ["Avery", "Brenda"],
                    "subject": ["Let's do lunch?", "I am hungry"],
                    "body": [
                        "Let's go get tacos on 1/20/20!",
                        "I really wish lunch would arrive soon...",
                    ],
                },
                kwargs=dict(
                    char_starts=[6, 14],
                    char_ends=[11, 20],
                    context_uids=[0, 1],
                    span_fields=["body", "body"],
                    initial_labels=[-1, -1],
                    span_entities=[None, None],
                ),
            )
        ]

    def extract_span_list_from_row(
        self, datapoint_uid: str, row: pd.Series
    ) -> List[Dict[str, Any]]:
        spans: List[Dict[str, Any]] = []
        for (
            char_start,
            char_end,
            span_field,
            initial_label,
            span_entity,
        ) in self.uid_to_spans[datapoint_uid]:
            span_text = row[span_field][char_start : char_end + 1]
            spans.append(
                dict(
                    span_field=span_field,
                    span_field_value_hash=get_span_field_value_hash(row[span_field]),
                    char_start=char_start,
                    char_end=char_end,
                    span_text=span_text,
                    initial_label=initial_label,
                    span_entity=span_entity,
                )
            )
        return spans


class SpansFileFeaturizer(HardCodedSpanFeaturizer):
    """
    A SpanFeaturizer that reads spans directly from a file with the expected span columns

    This operator reads specified spans from the provided file. The file can live either locally or in
    cloud storage. The file is expected to encode a dataframe with the following columns:
    ["char_start", "char_end", "context_uid", "span_field", "initial_label", "span_entity"]

    Parameters
    ----------
    path
        A path (either local or to S3) to the file that defines the spans
    source_type
        Either "CSV" or "PARQUET" for .csv and .parquet files, respectively
    col_suffix
        An optional suffix for the column containing the extracted spans
    """

    artifact_config_keys = ["path"]

    def __init__(
        self, path: str, source_type: str = "CSV", col_suffix: Optional[str] = None
    ):
        self.path = path
        st = SourceType(data_lib.get_load_type_value(source_type))
        config = LoadConfig(path=path, type=st)
        spans_df = dask_compute(
            data_lib.load_dataframe_from_config(config, set_uid=False)
        )[0]
        super().__init__(
            char_starts=spans_df[SpanCols.CHAR_START].tolist(),
            char_ends=spans_df[SpanCols.CHAR_END].tolist(),
            context_uids=spans_df[SpanCols.CONTEXT_UID].tolist(),
            span_fields=spans_df[SpanCols.SPAN_FIELD].tolist(),
            initial_labels=spans_df[SpanCols.INITIAL_LABEL].tolist(),
            span_entities=spans_df[SpanCols.SPAN_ENTITY].tolist()
            if SpanCols.SPAN_ENTITY in spans_df.columns
            else [],
            col_suffix=col_suffix,
        )

    @staticmethod
    def examples() -> List[OperatorExample]:
        return []


class EntityDictSpanFeaturizer(SpanFeaturizer):
    """
    SpanFeaturizer that yields (and optionally links) spans in an entity-to-aliases dictionary

    This is used for entity classification tasks. It additionally annotates each
    span with the linked entity, using the dictionary value. This operator is Optimized for keyword aliases.

    Parameters
    ----------
    entity_dict_path
        A path (either local or to remote storage) that contains the entity linking definitions
    field
        The field of the passing dataframe that entities will be extracted from
    ignore_cae
        If true, ignore case when matching entities (defaults to false)
    link_entities
        If true, link entities (defaults to true)
    col_suffix
        An optional suffix for the column containing the extracted spans
    """

    artifact_config_keys = ["entity_dict_path"]

    def __init__(
        self,
        entity_dict_path: str,
        field: str,
        ignore_case: bool = False,
        link_entities: bool = True,
        col_suffix: Optional[str] = None,
    ):
        self.entity_dict_path = entity_dict_path
        super().__init__(field, col_suffix=col_suffix)
        self.link_entities = link_entities
        self.entity_lookup_table = {}
        trie = Trie()
        entity_dict_path = resolve_data_path(entity_dict_path)
        with LocalReadFsspecPath(entity_dict_path) as local_path:
            with open(local_path, "r") as f:
                entity_dict = json.load(f)
                for entity_id, common_entity_forms in entity_dict.items():
                    for value in common_entity_forms:
                        trie.add(value)
                        self.entity_lookup_table[value.lower()] = entity_id

        pattern = trie.pattern()

        regex_pattern = rf"\b{pattern}\b" if pattern else ""
        flags = regex.IGNORECASE if ignore_case else 0
        self.regex_pattern = regex.compile(regex_pattern, flags=flags)

    def extract_span_list_from_str(
        self, context: str, datapoint_uid: Optional[str] = None
    ) -> Iterable[Tuple[int, int, Optional[str]]]:
        # Using regex.finditer(self.regex_pattern, context) is very costly if self.regex_pattern
        # is large, because of a dictionary lookup within re's cache. Hence
        # calling self.regex_pattern.finditer.
        for match in self.regex_pattern.finditer(context):
            char_start = match.start(0)
            char_end = match.end(0) - 1
            entity = (
                self.entity_lookup_table[match[0].lower()]
                if self.link_entities
                else None
            )
            yield char_start, char_end, entity


class EntityDictRegexSpanFeaturizer(SpanFeaturizer):
    """A SpanFeaturizer that yields (and optionally links) spans in an entity-to-aliases dictionary, which supports regexes.
    Entity Dict Featurizer is better suited for keywords.

    This is used for entity classification tasks. It additionally annotates each
    span with the linked entity, using the dictionary value. By default regexes provided are surrounded by (``\\b``).
    """

    artifact_config_keys = ["entity_dict_path"]

    def __init__(
        self,
        entity_dict_path: str,
        field: str,
        ignore_case: bool = False,
        link_entities: bool = True,
        col_suffix: Optional[str] = None,
    ):
        super().__init__(field, col_suffix=col_suffix)
        self.entity_dict_path = entity_dict_path
        self.link_entities = link_entities
        self.entity_lookup_table = {}
        # Index is across all common_entity_forms of all entities.
        index = 0
        pattern = ""
        entity_dict_path = resolve_data_path(entity_dict_path)
        with LocalReadFsspecPath(entity_dict_path) as local_path:
            with open(local_path, "r") as f:
                entity_dict = json.load(f)
                for entity_id, common_entity_forms in entity_dict.items():
                    for value in common_entity_forms:
                        capture_name = f"i{index}"
                        if len(pattern) == 0:
                            # Assign current index to this capture group, so we can get that value later
                            # Regex capture pattern names can't start with a number, so we prepend an i to the index value
                            pattern += rf"(?P<{capture_name}>{value})"
                        else:
                            # Assign current index to this capture group, so we can get that value later
                            # Regex capture pattern names can't start with a number, so we prepend an i to the index value
                            pattern += rf"|(?P<{capture_name}>{value})"
                        # We prepend the i in the dictonary key as well, so it's easier to find the value later
                        self.entity_lookup_table[capture_name] = entity_id
                        index += 1

        regex_pattern = rf"\b{pattern}\b" if pattern else ""

        flags = regex.IGNORECASE if ignore_case else 0
        try:
            self.regex_pattern = regex.compile(regex_pattern, flags=flags)
        except regex._regex_core.error as e:
            raise ValueError(f"Could not parse regex:{str(e)}")

    def extract_span_list_from_str(
        self, context: str, datapoint_uid: Optional[str] = None
    ) -> Iterable[Tuple[int, int, Optional[str]]]:
        # Using regex.finditer(self.regex_pattern, context) is very costly if self.regex_pattern
        # is large, because of a dictionary lookup within re's cache. Hence
        # calling self.regex_pattern.finditer.
        for match in self.regex_pattern.finditer(context):
            char_start = match.start(0)
            char_end = match.end(0) - 1
            entity = (
                # We use match.lastgroup as it's free for us to get this info. Getting the first match
                # would require us to iterate through the dictonary containing all of the capture groups
                self.entity_lookup_table[match.lastgroup]
                if self.link_entities
                else None
            )
            yield char_start, char_end, entity


class DocEntityDictSpanFeaturizer(SpanFeaturizer):
    """(Optimized for keyword aliases) SpanFeaturizer that yields (and optionally links) spans, given an entity-to-aliases dictionary and doc-id-to-entity dictionary."""

    artifact_config_keys = ["entity_dict_path", "doc_entity_dict_path"]

    def __init__(
        self,
        entity_dict_path: str,
        doc_entity_dict_path: str,
        field: str,
        ignore_case: bool = False,
        link_entities: bool = True,
        col_suffix: Optional[str] = None,
    ):
        super().__init__(field, col_suffix=col_suffix)
        self.entity_dict_path = entity_dict_path
        self.doc_entity_dict_path = doc_entity_dict_path
        self.link_entities = link_entities
        self.entity_lookup_table = {}

        entity_dict_path = resolve_data_path(entity_dict_path)
        flags = regex.IGNORECASE if ignore_case else 0

        # Load dict of context_uid -> List[span_entity]
        doc_entity_dict_path = resolve_data_path(doc_entity_dict_path)
        self.doc_regex_dict: Dict[str, regex.pattern] = {}
        with LocalReadFsspecPath(doc_entity_dict_path) as local_path:
            with open(local_path, "r") as f:
                doc_entity_dict = json.load(f)

        with LocalReadFsspecPath(entity_dict_path) as local_path:
            with open(local_path, "r") as f:
                entity_dict = json.load(f)

        doc_datapoint_instance = DocDatapoint([SpanCols.CONTEXT_UID])
        for context_uid, span_entities in doc_entity_dict.items():
            datapoint_uid = doc_datapoint_instance.get_datapoint_uid_from_values(
                [context_uid]
            )
            trie = Trie()
            for entity_id in span_entities:
                aliases = entity_dict.get(entity_id)
                if not aliases:
                    continue
                for value in aliases:
                    trie.add(value)
                    self.entity_lookup_table[value.lower()] = entity_id

            pattern = trie.pattern()
            if not pattern:
                continue

            regex_pattern = regex.compile(pattern, flags=flags)
            self.doc_regex_dict[datapoint_uid] = regex_pattern

    def _extract_from_str_with_context(
        self, datapoint_uid: str, content: str
    ) -> Iterable[Tuple[int, int, Optional[str]]]:
        # Using regex.finditer(self.regex_pattern, context) is very costly if self.regex_pattern
        # is large, because of a dictionary lookup within re's cache. Hence
        # calling self.regex_pattern.finditer.
        regex_pattern = self.doc_regex_dict.get(datapoint_uid)
        if not regex_pattern:
            return
        for match in regex_pattern.finditer(content):
            char_start = match.start(0)
            char_end = match.end(0) - 1
            entity = (
                self.entity_lookup_table[match[0].lower()]
                if self.link_entities
                else None
            )
            yield char_start, char_end, entity

    def extract_span_list_from_row(
        self, datapoint_uid: str, row: pd.Series
    ) -> List[Dict[str, Any]]:
        # Copied from parent SpanFeaturizer, but passes datapoint_uid into extract_from_str
        spans = []
        for field, content in row.items():
            content = row[field]
            if not isinstance(content, str):
                continue
            for (
                char_start,
                char_end,
                span_entity,
            ) in self._extract_from_str_with_context(datapoint_uid, content):
                span_text = content[char_start : char_end + 1]
                spans.append(
                    dict(
                        span_field=field,
                        span_field_value_hash=get_span_field_value_hash(row[field]),
                        char_start=char_start,
                        char_end=char_end,
                        span_text=span_text,
                        span_entity=span_entity,
                        initial_label=-1,
                    )
                )
        return spans


class EmptySpanExtractor(SpanFeaturizerExtractor, EmptySpanFeaturizer):
    """A SpanExtractor that yields a single empty span from (0,0) for each row

    This can be used to create a candidate set with a one-to-one mapping
    with documents, which can serve as a starting point for labeling GT manually.
    """

    pass


class RegexSpanExtractor(SpanFeaturizerExtractor, RegexSpanFeaturizer):
    """
    A SpanExtractor that yields all matches for a given regular expression

    This operator applies a given regular expression over a specified field
    in the passing DataFrame and adds each match as a new span in the output.

    Parameters
    ----------
    regex : str
        The regular expression to apply over the data
    field : str
        The name of the column in the dataframe to apply to provided regex over
    ignore_case : bool
        If true, ignore case when considering regular expression matches (defaults to false)
    capture_group : str
        The capture group to provide to the regex results
    col_suffix : str
        An optional suffix for the column containing the extracted spans
    """

    def __init__(
        self,
        regex: str,
        field: str,
        ignore_case: bool = False,
        capture_group: int = 0,
        col_suffix: Optional[str] = None,
    ):
        RegexSpanFeaturizer.__init__(
            self,
            field=field,
            regex=regex,
            ignore_case=ignore_case,
            capture_group=capture_group,
            col_suffix=col_suffix,
        )
        SpanFeaturizerExtractor.__init__(self, field=field, col_suffix=col_suffix)


class DateSpanExtractor(SpanFeaturizerExtractor, DateSpanFeaturizer):
    """
    Extracts spans (slices of documents) that contain dates (using regex)

    This operator uses a regex to extract all spans from the parent document
    that contain dates. The vast majority of standard date formats are supported,
    including ISO-8601, RFC-3339, and others.

    Parameters
    ----------
    field
        The dataframe column to extract date spans from
    col_suffix
        An optional suffix for the column containing the extracted spans

    """

    def __init__(self, field: str, col_suffix: Optional[str] = None):
        DateSpanFeaturizer.__init__(self, field=field, col_suffix=col_suffix)
        SpanFeaturizerExtractor.__init__(self, field=field, col_suffix=col_suffix)


class ParagraphSpanExtractor(SpanFeaturizerExtractor, ParagraphSpanFeaturizer):
    """
    Extracts spans (slices of documents) that contain paragraphs (using regex)

    This operator uses a regex pattern to extract all paragraphs as spans from
    the parent document. Trailing newline characters are preserved for each paragraph

    Parameters
    ----------
    field
        The dataframe column to extract paragraph spans from
    col_suffix
        An optional suffix for the column containing the extracted spans

    """

    def __init__(self, field: str, col_suffix: Optional[str] = None):
        ParagraphSpanFeaturizer.__init__(self, field=field, col_suffix=col_suffix)
        SpanFeaturizerExtractor.__init__(self, field=field, col_suffix=col_suffix)


class NumericSpanExtractor(SpanFeaturizerExtractor, NumericSpanFeaturizer):
    """Extracts spans (slices of documents) that contain numbers (using regex)"""

    def __init__(self, field: str, col_suffix: Optional[str] = None):
        NumericSpanFeaturizer.__init__(self, field=field, col_suffix=col_suffix)
        SpanFeaturizerExtractor.__init__(self, field=field, col_suffix=col_suffix)


class EmailAddressSpanExtractor(SpanFeaturizerExtractor, EmailAddressSpanFeaturizer):
    """Extracts spans (slices of documents) that contain email addresses (using regex)"""

    def __init__(self, field: str, col_suffix: Optional[str] = None):
        EmailAddressSpanFeaturizer.__init__(self, field=field, col_suffix=col_suffix)
        SpanFeaturizerExtractor.__init__(self, field=field, col_suffix=col_suffix)


class USCurrencySpanExtractor(SpanFeaturizerExtractor, USCurrencySpanFeaturizer):
    """Extracts spans (slices of documents) that contain US currency (using regex)"""

    operator_impl_version: int = 1

    def __init__(self, field: str, col_suffix: Optional[str] = None):
        USCurrencySpanFeaturizer.__init__(self, field=field, col_suffix=col_suffix)
        SpanFeaturizerExtractor.__init__(self, field=field, col_suffix=col_suffix)


class HardCodedSpanExtractor(SpanFeaturizerExtractor, HardCodedSpanFeaturizer):
    """A SpanExtractor that reads spans directly from its config."""

    def __init__(
        self,
        char_starts: List[int],
        char_ends: List[int],
        context_uids: List[int],
        span_fields: List[str],
        initial_labels: List[int],
        span_entities: List[Optional[str]],
        col_suffix: Optional[str] = None,
    ):
        HardCodedSpanFeaturizer.__init__(
            self,
            char_starts,
            char_ends,
            context_uids,
            span_fields,
            initial_labels,
            span_entities,
            col_suffix,
        )
        self.new_datapoint_cols = [
            self.get_suffixed_output_col_name(x) for x in self.new_datapoint_cols
        ]

    @staticmethod
    def examples() -> List[OperatorExample]:
        # Explicit to override LTR method resolution order
        return HardCodedSpanFeaturizer.examples()

    def extract_span_list_from_row(
        self, datapoint_uid: str, row: pd.Series
    ) -> List[Dict[str, Any]]:
        return HardCodedSpanFeaturizer.extract_span_list_from_row(
            self, datapoint_uid, row
        )


class SpansFileExtractor(SpanFeaturizerExtractor, SpansFileFeaturizer):
    """A SpanExtractor that reads spans directly from a file with columns ["char_start", "char_end", "context_uid", "span_field", "initial_label", "span_entity"]"""

    def __init__(
        self, path: str, source_type: str = "CSV", col_suffix: Optional[str] = None
    ):
        SpansFileFeaturizer.__init__(self, path, source_type, col_suffix=col_suffix)
        self.new_datapoint_cols = [
            self.get_suffixed_output_col_name(x) for x in self.new_datapoint_cols
        ]

    def extract_span_list_from_row(
        self, datapoint_uid: str, row: pd.Series
    ) -> List[Dict[str, Any]]:
        return SpansFileFeaturizer.extract_span_list_from_row(self, datapoint_uid, row)


class EntityDictSpanExtractor(SpanFeaturizerExtractor, EntityDictSpanFeaturizer):
    """
    SpanExtractor that yields (and optionally links) spans in an entity-to-aliases dictionary

    This is used for entity classification tasks. It additionally annotates each
    span with the linked entity, using the dictionary value. This operator is Optimized for keyword aliases.

    An example of the entity-to-aliases dictionary can be found in Entity Classification Tutorials.

    Parameters
    ----------
    entity_dict_path
        The path to the entity-to-aliases dictionary
    field
        The dataframe column to extract spans from
    ignore_case
        If true, the extraction will be NOT case sensitive (default to false)
    link_entities
        If true, the extracted span will be linked with its original entity/aliases
    col_suffix
        An optional suffix for the column containing the extracted spans
    """

    def __init__(
        self,
        entity_dict_path: str,
        field: str,
        ignore_case: bool = False,
        link_entities: bool = True,
        col_suffix: Optional[str] = None,
    ):
        EntityDictSpanFeaturizer.__init__(
            self,
            entity_dict_path=entity_dict_path,
            field=field,
            ignore_case=ignore_case,
            link_entities=link_entities,
            col_suffix=col_suffix,
        )
        SpanFeaturizerExtractor.__init__(self, field=field, col_suffix=col_suffix)


class EntityDictRegexSpanExtractor(
    SpanFeaturizerExtractor, EntityDictRegexSpanFeaturizer
):
    """A SpanExtractor that yields (and optionally links) spans in an entity-to-aliases dictionary, which supports regexes.
    Entity Dict Extractor is better suited for keywords.

    This is used for entity classification tasks. It additionally annotates each
    span with the linked entity, using the dictionary value. By default regexes provided are surrounded by (``\\b``).
    """

    def __init__(
        self,
        entity_dict_path: str,
        field: str,
        ignore_case: bool = False,
        link_entities: bool = True,
        col_suffix: Optional[str] = None,
    ):
        EntityDictRegexSpanFeaturizer.__init__(
            self,
            entity_dict_path=entity_dict_path,
            field=field,
            ignore_case=ignore_case,
            link_entities=link_entities,
            col_suffix=col_suffix,
        )
        SpanFeaturizerExtractor.__init__(self, field=field, col_suffix=col_suffix)


class DocEntityDictSpanExtractor(SpanFeaturizerExtractor, DocEntityDictSpanFeaturizer):
    """(Optimized for keyword aliases) SpanExtractor that yields (and optionally links) spans, given an entity-to-aliases dictionary and doc-id-to-entity dictionary."""

    def __init__(
        self,
        entity_dict_path: str,
        doc_entity_dict_path: str,
        field: str,
        ignore_case: bool = False,
        link_entities: bool = True,
        col_suffix: Optional[str] = None,
    ):
        DocEntityDictSpanFeaturizer.__init__(
            self,
            entity_dict_path=entity_dict_path,
            field=field,
            doc_entity_dict_path=doc_entity_dict_path,
            ignore_case=ignore_case,
            link_entities=link_entities,
            col_suffix=col_suffix,
        )
        SpanFeaturizerExtractor.__init__(self, field=field, col_suffix=col_suffix)

    def extract_span_list_from_row(
        self, datapoint_uid: str, row: pd.Series
    ) -> List[Dict[str, Any]]:
        return DocEntityDictSpanFeaturizer.extract_span_list_from_row(
            self, datapoint_uid, row
        )
