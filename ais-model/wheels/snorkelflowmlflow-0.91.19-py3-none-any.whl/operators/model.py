import json
from typing import Any, Dict, Optional

import numpy as np
import pandas as pd

from label_spaces.get_label_space import get_label_space, get_label_space_cls
from operators import workflow_utils
from snorkelflow.extraction.span import SpanCols
from snorkelflow.models.cls_model import TrainedClassificationModelV2
from snorkelflow.operators.featurizer import Featurizer, OpProgressCallback
from snorkelflow.operators.operator import no_op_progress_callback
from snorkelflow.types.model import ModelCols
from snorkelflow.utils.logging import get_logger

logger = get_logger("ModelFeaturizer")


class Model(Featurizer):
    is_expensive = True

    artifact_config_keys = ["dirpath"]

    def __init__(
        self,
        model_name: str,
        dirpath: str,
        label_map: Dict[str, int],
        label_space_config: Optional[Dict[str, Any]] = None,
        model_class_pickle: Optional[str] = None,
        embedding_field: Optional[str] = None,
    ) -> None:
        from snorkelflow.models.model_registry import load_model_fields

        self.model_name = model_name
        self.dirpath = dirpath
        self.model_class_pickle = model_class_pickle
        self.model: Optional[TrainedClassificationModelV2] = None
        self._use_workflow_resource_cache = False

        self._input_cols = set(load_model_fields(dirpath))
        if SpanCols.SPAN_PREVIEW in self._input_cols:
            # TODO: Add context as proper df columns.
            # Until then... this is a hack to workaround.
            self._input_cols = self._input_cols.union(
                {
                    SpanCols.CHAR_START,
                    SpanCols.CHAR_END,
                    SpanCols.SPAN_TEXT,
                    SpanCols.SPAN_PREVIEW_OFFSET,
                }
            )

        self.inv_label_map = {v: k for k, v in label_map.items()}
        self.label_space_config = label_space_config
        label_space_name = (
            "SingleLabelSpace"
            if label_space_config is None
            else label_space_config["cls_name"]
        )
        label_space_cls = get_label_space_cls(label_space_name)
        self.label_space = None
        if label_space_config and label_space_config.get("kwargs"):
            self.label_space = get_label_space(
                label_space_config["cls_name"], label_space_config["kwargs"]
            )
        self.preds_type = label_space_cls.raw_label_type()
        self.preds_str_type = label_space_cls.user_label_type()
        self._workflow_resource_cache_key = json.dumps(
            {
                "dirpath": f"{self.dirpath}",
                "model_class_pickle": self.model_class_pickle,
            },
            sort_keys=True,
        )

    @property
    def input_schema(self) -> Dict[str, Any]:
        return {x: None for x in self._input_cols}

    @property
    def output_schema(self) -> Dict[str, Any]:
        return {
            ModelCols.PREDICTION_INT: self.preds_type,
            ModelCols.PREDICTION_PROBABILITY: None,
            ModelCols.PREDICTION_STR: self.preds_str_type,
        }

    def preload_resources_into_workflow_cache(self) -> None:
        """This method is used to pre-populate the global cache
        and use it in the subsequent runs. This is used
        only by the workflow path.
        When the ModelFeaturizer contains self.model,
        Dask tries to cloud pickle the model. This adds
        a few seconds of overhead. Using a global cache
        is necessary to avoid any slowdowns due to
        dask cloud pickling. See ENG-6290 for more details
        """
        self._use_workflow_resource_cache = True
        self.model = None
        if self.dirpath not in workflow_utils.resources_cache:
            from snorkelflow.models.model_registry import load_model

            logger.info("Using workflow model cache")
            workflow_utils.resources_cache[
                self._get_workflow_resource_cache_key()
            ] = load_model(self.dirpath, self.model_class_pickle)

    def _get_workflow_resource_cache_key(self) -> str:
        return self._workflow_resource_cache_key

    def _get_loaded_model(self) -> TrainedClassificationModelV2:
        """A helper method to get the loaded model. This method hides the caching layer and provides
           an interface that the caller can use to get the model.

        Returns:
            TrainedClassificationModelV2: The model thats loaded in the memory
        """
        model = None
        if self._use_workflow_resource_cache:
            if (
                self._get_workflow_resource_cache_key()
                in workflow_utils.resources_cache
            ):
                logger.info(
                    f"Using workflow model cache for loading the model - key:{self._get_workflow_resource_cache_key()}"
                )
                model = workflow_utils.resources_cache[
                    self._get_workflow_resource_cache_key()
                ]

        if not model:
            # Fall back to using the locally cached model
            if self.model is None:
                from snorkelflow.models.model_registry import load_model

                self.model = load_model(self.dirpath, self.model_class_pickle)
            logger.info("Using local cache for loading the model")
            model = self.model

        return model

    def _compute_features(
        self,
        input_df: pd.DataFrame,
        callback: OpProgressCallback = no_op_progress_callback,
    ) -> pd.DataFrame:
        # Load model lazily if it isn't loaded yet. This ensures the loading
        # only happens once, while keeping the constructor lightweight.

        model = self._get_loaded_model()
        preds, probs = model.predict(input_df)
        if probs is None:
            probs = np.full(preds.shape, None)
        input_df[ModelCols.PREDICTION_INT] = preds.tolist()
        input_df[ModelCols.PREDICTION_PROBABILITY] = probs.tolist()

        if self.label_space:
            input_df[ModelCols.PREDICTION_STR] = input_df[
                ModelCols.PREDICTION_INT
            ].apply(
                lambda raw_label: self.label_space.raw_label_to_user_label(raw_label)
            )
        elif np.issubdtype(input_df[ModelCols.PREDICTION_INT].dtype, np.integer):
            # 1) we're only supporting PREDICTION_STR for single label spaces for now and
            # 2) this should be handled in the model object in the future using the label space
            # (should use `raw_to_user` functionality).
            input_df[ModelCols.PREDICTION_STR] = input_df[ModelCols.PREDICTION_INT].map(
                self.inv_label_map
            )
        else:
            input_df[ModelCols.PREDICTION_STR] = None
        # Cast these columns explicitly intead of using meta in map_partitions,
        # in case the, given the model lib may add unexpected columns.
        return input_df.astype({ModelCols.PREDICTION_PROBABILITY: object})
