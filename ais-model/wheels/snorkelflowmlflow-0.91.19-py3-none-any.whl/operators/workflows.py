import copy
import csv
import os
from collections import defaultdict
from typing import Any, Collection, Dict, Iterator, List, Optional, Tuple, Type, Union

import networkx as nx
from dask import dataframe as dd
from pydantic import BaseModel
from secret_clients import SecretAccessMixin

from api_utils.exceptions import OperatorExecutionError, SnorkelException
from operators import get_operator
from operators import model as model_op
from operators.workflow_utils import get_workflow_hash
from snorkelflow.operators.operator import ColSchema, Operator, validate_df_schema
from snorkelflow.types.workflows import (
    INPUT_NODE_ID,
    INPUT_NODE_TYPE,
    OperatorConfig,
    OperatorId,
    WorkflowConfig,
)
from snorkelflow.utils.datapoint import DatapointType, DocDatapoint
from snorkelflow.utils.file import resolve_data_path
from snorkelflow.utils.logging import get_logger
from snorkelflow.workflows.graph_utils import (
    get_workflow_output_ids,
    make_input_op_config,
    workflow_config_to_dag,
)

# Initialize Logger
logger = get_logger("Workflows")

DatapointTypes = Dict[int, DatapointType]
OpToContextOp = Dict[int, int]


def processor_to_workflow_config(
    processor_config: List[Dict[str, Any]]
) -> WorkflowConfig:
    """Compute and return workflow config and final op id."""
    workflow_config: WorkflowConfig = {INPUT_NODE_ID: make_input_op_config()}
    curr_op_id = 0

    # Iterate through all preprocessor_configs and convert them to operators
    for config in processor_config:
        # Convert processor configs to operators
        op_type = config["cls"]
        op_config = config.get("kwargs", {})
        op_class: Operator = get_operator.get_operator_class(op_type)
        op_impl_version = op_class.get_op_impl_version()

        # Inputs of each processor is the previous processor
        input_ids = [curr_op_id - 1]

        if get_operator.is_extractor(op_type, op_config):
            workflow_config[curr_op_id - 1].is_output = True

        # Add the current operator to the workflow
        workflow_config[curr_op_id] = OperatorConfig(
            input_ids=input_ids,
            op_type=op_type,
            op_config=op_config,
            op_impl_version=op_impl_version,
        )

        # Increment the op_id
        curr_op_id += 1

    # Set the last node as an output.
    workflow_config[curr_op_id - 1].is_output = True
    return workflow_config


def get_pre_extractor_ops(workflow_config: WorkflowConfig) -> List[int]:
    pre_extractor_ops = set()
    for op_config in workflow_config.values():
        if op_config.op_type == INPUT_NODE_TYPE:
            continue
        if get_operator.is_extractor(op_config.op_type, op_config.op_config):
            pre_extractor_ops.update(op_config.input_ids)
    return sorted(pre_extractor_ops)


def infer_schema_per_node_id(
    data_schema: ColSchema, G: nx.DiGraph
) -> Dict[int, ColSchema]:
    inferred_output_schemas: Dict[int, ColSchema] = {INPUT_NODE_ID: data_schema.copy()}
    for op_id in nx.algorithms.dag.topological_sort(G):
        op_config = G.nodes[op_id]["op_config"]
        if op_config.op_type == INPUT_NODE_TYPE:
            continue

        operator = G.nodes[op_id]["operator"]
        operator.node_uid = op_id
        input_schema = operator.input_schema

        # Validate current operator's input schema against inferred output
        # schema for first input.
        # TODO: Allow schema specification and validation for all inputs.
        validate_df_schema(
            expected_schema=input_schema,
            received_schema=inferred_output_schemas[op_config.input_ids[0]],
            operator_name=operator.__class__.__name__,
            missing_col_err_msg_template="'{col_name}' column expected by '{operator_name}', but is not present in downstream dataframe columns {received_schema}. Please update operator input schema or data.",
        )

        inferred_output_schemas[op_id] = inferred_output_schemas[
            op_config.input_ids[0]
        ].copy()

        # Update running schema to the current operator's output
        inferred_output_schemas[op_id].update(operator.output_schema or {})

        # Drop any columns
        drop_schema = operator.drop_schema
        if drop_schema:
            for key in drop_schema:
                if key in inferred_output_schemas[op_id]:
                    inferred_output_schemas[op_id].pop(key)
    return inferred_output_schemas


def infer_output_schema(data_schema: ColSchema, G: nx.DiGraph) -> ColSchema:
    # Validate based on whether the `next_schema` has what it needs to proceed,
    # given a "running" schema of columns added/removed via operators
    inferred_output_schemas = infer_schema_per_node_id(data_schema, G)
    target_schemas = [
        schema
        for op_id, schema in inferred_output_schemas.items()
        if G.nodes[op_id]["op_config"].is_output
    ]
    if not target_schemas:
        return data_schema
    return target_schemas[-1]


def get_op_errors_file_path(
    workflow_config: WorkflowConfig, op_id: OperatorId, datasource_uid: int
) -> str:
    workflow_hash = get_workflow_hash(workflow_config, op_id)
    return resolve_data_path(
        f"minio://errors_file_path/{datasource_uid}/{workflow_hash}"
    )


class SkippedDatapointResponse(BaseModel):
    datapoint: str
    error_msg: Optional[str] = None


def get_skipped_datapoints(
    workflow_config: WorkflowConfig,
    target_node_uids: List[int],
    datasource_uids: List[int],
    include_error_msg: bool = False,
) -> List[SkippedDatapointResponse]:
    # Lazily import OS-specific python module to avoid import errors on Windows
    # Long term fix should be to used OS agnostic file locking
    import fcntl

    skipped_datapoints = []
    subworkflow_config = get_targets_workflow_config(workflow_config, target_node_uids)

    for datapoint_uid in datasource_uids:
        for node_uid in subworkflow_config:
            errors_file_path = get_op_errors_file_path(
                subworkflow_config, node_uid, datapoint_uid
            )
            if os.path.exists(errors_file_path):
                with open(errors_file_path, "r") as f:
                    fcntl.lockf(f, fcntl.LOCK_SH)
                    reader = csv.reader(f)
                    logger.info(f"Reading skipped datapoints from {errors_file_path}")
                    next(reader)  # Skip the header
                    for row in reader:
                        if include_error_msg:
                            skipped_datapoints.append(
                                SkippedDatapointResponse(
                                    datapoint=row[0], error_msg=row[1]
                                )
                            )
                        else:
                            skipped_datapoints.append(
                                SkippedDatapointResponse(datapoint=row[0])
                            )

    return skipped_datapoints


def build_workflow_dag(
    workflow_config: WorkflowConfig,
    init_operators: bool = True,
    datasource_uid: Optional[int] = None,
) -> nx.DiGraph:
    G = workflow_config_to_dag(workflow_config)
    if init_operators:
        for node_id in G.nodes:
            if node_id == INPUT_NODE_ID:
                continue
            node = G.nodes[node_id]
            if node["op_config"].op_type == INPUT_NODE_TYPE:
                continue
            node["operator"] = get_operator.init_operator_class(
                node["op_config"].op_type,
                node["op_config"].op_config,
                node["op_config"].op_asset,
            )
            node["operator"].node_uid = node_id
            if datasource_uid is not None:
                node["operator"].errors_file_path = get_op_errors_file_path(
                    workflow_config, node_id, datasource_uid
                )
    return G


def get_targets_workflow_config(
    workflow_config: WorkflowConfig, targets: List[OperatorId]
) -> WorkflowConfig:
    """Returns the minimal workflow_config needed to compute target_op_id"""
    workflow_dag = WorkflowDAG(workflow_config)
    G = workflow_dag.get_computation_subgraph(targets, [INPUT_NODE_ID])
    return {
        op_id: workflow_config[op_id] for op_id in nx.algorithms.dag.topological_sort(G)
    }


class WorkflowDAG:
    """Builds and executes workflows given a workflow_config."""

    def __init__(
        self,
        workflow_config: WorkflowConfig,
        data_schema: Optional[ColSchema] = None,
        datasource_uid: Optional[int] = None,
    ):
        """Instantiates a WorkflowDAG that will execute a workflow"""
        self.workflow_config = copy.deepcopy(workflow_config)
        self.G = build_workflow_dag(
            self.workflow_config, init_operators=True, datasource_uid=datasource_uid
        )

        if data_schema is None:
            # Passing None for data_schema doesn't perform schema validation, and the
            # output_schema won't be set correctly.
            data_schema = {}
        else:
            self.output_schema = infer_output_schema(data_schema, self.G)
        self.data_schema = data_schema

    @property
    def input_columns(self) -> List[str]:
        return list(self.data_schema.keys())

    def is_chain(self) -> bool:
        return all([len(x) <= 1 for x in nx.algorithms.dag.antichains(self.G)])

    @classmethod
    def from_dict(
        cls, data_schema: ColSchema, workflow_config_dict: Dict[Any, Any]
    ) -> "WorkflowDAG":
        """Convert a dictionary representation of the workflow config"""
        workflow_config: WorkflowConfig = {
            int(k): OperatorConfig(**v) for k, v in workflow_config_dict.items()
        }
        return cls(workflow_config, data_schema)

    def to_dict(self) -> Dict[str, Any]:
        """Return workflow config as a python dictionary."""
        return dict(
            data_schema=self.data_schema,
            workflow_config={k: v.dict() for k, v in self.workflow_config.items()},
        )

    @classmethod
    def from_processor_config(
        cls, data_schema: ColSchema, processor_config: List[Dict[str, Any]]
    ) -> "WorkflowDAG":
        """Convert a processor_config into a WorkflowDAG.

        The processor config may have the form [{"cls": <>, "kwargs": <>}, ...].
        """

        workflow_config = processor_to_workflow_config(processor_config)
        return cls(workflow_config, data_schema)

    def to_processor_config(self) -> List[Dict[str, Any]]:
        """Return workflow config as a processor configs, if it's a chain."""
        if not self.is_chain():
            raise ValueError(
                "WorkflowDAG must be a chain to convert to processor config sequence."
            )

        processor_config = []
        for op_id in nx.algorithms.dag.topological_sort(self.G):
            if op_id == INPUT_NODE_ID:
                continue
            op_config = self.G.nodes[op_id]["op_config"]
            processor_config.append(
                dict(cls=op_config.op_type, kwargs=op_config.op_config)
            )
        return processor_config

    def _get_op_id_to_output_op_ids(self) -> Dict[int, List[int]]:
        """Returns a mapping from each op_id (in workflow_config) to the operator ids
        it sends its output to. This is needed because OperatorConfig contains only
        input_ids.
        """
        op_id_to_output_op_ids = defaultdict(list)
        for op_id, op_config in self.workflow_config.items():
            for input_id in op_config.input_ids:
                op_id_to_output_op_ids[input_id].append(op_id)
        return op_id_to_output_op_ids

    def execute(
        self,
        sources: Union[dd.DataFrame, Dict[int, dd.DataFrame]],
        targets: Optional[List[OperatorId]] = None,
    ) -> Dict[str, dd.DataFrame]:
        """Executes workflow on dataframe and returns DataFrames of output nodes
        without caching them.

        Parameters
        ----------
        sources
            A starting assignment of dask dataframes to operator ids, or a single
            dataframe (which gets assigned to INPUT_NODE_ID).
        targets
            Optional list of computed dataframes to returns. Defaults to all dataframes
            for operators with is_output equal to True.
        Returns
        ----------
        Dict[str, dd.DataFrame]
            A dictionary mapping a key to a dataframe for each requested output.
        """
        # Initialize cache with the input data
        if isinstance(sources, dd.DataFrame):
            cache = {INPUT_NODE_ID: sources}
        else:
            cache = sources.copy()
        if INPUT_NODE_ID in cache:
            validate_df_schema(
                expected_schema=self.data_schema,
                received_schema=cache[INPUT_NODE_ID].dtypes.to_dict(),
                operator_name=self.__class__.__name__,
            )

        if targets is None:
            targets = get_workflow_output_ids(self.workflow_config)
        assert targets is not None  # For mypy.

        G = self.get_computation_subgraph(targets, list(cache))
        for op_id in nx.algorithms.dag.topological_sort(G):
            if op_id in cache:
                continue

            # Fetch operator as node attribute
            operator = G.nodes[op_id]["operator"]
            op_config = G.nodes[op_id]["op_config"]
            logger.info(
                f"Executing operator ({operator.__class__.__name__}) op_id={op_id} {op_config}"
            )

            # Fetch inputs
            input_ddfs = [
                # Use .copy() to avoid referencing other dataframes in cache
                cache[input_id].copy()
                for input_id in op_config.input_ids
            ]
            # Set operator secrets
            if isinstance(operator, SecretAccessMixin):
                operator.configure_secrets()

            # TODO(jhallard) - record the node's inputs+outputs to the
            # monitoring client

            # Apply operator
            try:
                output_ddf = operator.execute(input_ddfs)
            except SnorkelException as e:
                raise OperatorExecutionError(e.detail, e.user_friendly_message) from e
            except Exception:
                error_msg = f"Error running Operator {operator.__class__.__name__}"
                logger.exception(error_msg)
                raise Exception(error_msg)

            # Cache the operator output
            cache[op_id] = output_ddf

        # Return DataFrames for all output nodes
        return {
            f"{op_id}:{self.workflow_config[op_id].op_type}": cache[op_id]
            for op_id in targets
        }

    def get_computation_subgraph(
        self, targets: Collection[OperatorId], sources: Collection[OperatorId]
    ) -> nx.DiGraph:
        """Get subgraph of nodes to compute given source / target node ids.
        Given a list of targets op ids to compute, and a list of sources
        for which ddfs are already available, use backward search to determine
        the subgraph of ops that need to be computed plus sources.
        """
        to_visit = set(targets)
        visited = set()
        while to_visit:
            x = to_visit.pop()
            visited.add(x)
            if x in sources:
                continue
            for pre in self.G.predecessors(x):
                if pre not in visited:
                    to_visit.add(pre)
        return self.G.subgraph(visited)

    def _get_datapoint_instances(
        self, datapoint_instances: Optional[Union[DatapointType, DatapointTypes]] = None
    ) -> Tuple[DatapointTypes, OpToContextOp]:
        """returns [op_id_to_datapoint_instance, op_id_to_context_op_id]"""
        op_id_to_context_op_id: OpToContextOp = {}
        op_id_to_datapoint_instance: DatapointTypes = {
            # we always start with a doc datapoint
            INPUT_NODE_ID: DocDatapoint()
        }

        if datapoint_instances is None:
            pass
        elif isinstance(datapoint_instances, DatapointType):
            op_id_to_datapoint_instance[INPUT_NODE_ID] = datapoint_instances
        else:
            op_id_to_datapoint_instance.update(datapoint_instances)

        for op_id in nx.algorithms.dag.topological_sort(self.G):
            if op_id == INPUT_NODE_ID or op_id in op_id_to_datapoint_instance:
                continue
            operator = self.G.nodes[op_id]["operator"]

            input_datapoint_instances = [
                op_id_to_datapoint_instance[input_id]
                for input_id in self.G.nodes[op_id]["op_config"].input_ids
            ]
            op_id_to_datapoint_instance[op_id] = operator.get_datapoint_instance(
                input_datapoint_instances
            )

            # logic for calculating the context_datapoint_instance:
            # - If the datapoint instance has changed from before (doc => span),
            # treat the first previous datapoint as the context for this one.
            # - If the datapoint instance hasn't changed BUT it has for the
            # input, treat the context for the input as the current context
            # e.g. doc1       => doc2       => span1 => span2
            #      no context => no context => doc1  => doc1
            first_input_id = self.G.nodes[op_id]["op_config"].input_ids[0]
            if op_id_to_datapoint_instance[op_id] != input_datapoint_instances[0]:
                # datapoint instance has changed => treat first input as the context
                op_id_to_context_op_id[op_id] = first_input_id
            elif first_input_id in op_id_to_context_op_id:
                # treat previous context, if there is one, as current one as well
                op_id_to_context_op_id[op_id] = op_id_to_context_op_id[first_input_id]

        return op_id_to_datapoint_instance, op_id_to_context_op_id

    def op_ids_in_top_order(self) -> Iterator[OperatorId]:
        for op_id in nx.algorithms.dag.topological_sort(self.G):
            yield op_id

    def get_datapoint_instances(
        self, datapoint_instances: Optional[Union[DatapointType, DatapointTypes]] = None
    ) -> DatapointTypes:
        """
        Parameters
        ----------
        datapoint_instances
            A starting assignment of operator id to datapoint instances, or a single
            datapoint instance (which gets assigned to INPUT_NODE_ID).

        Returns
        -------
        Dict[str, DatapointType]
            A dictionary mapping a key to datapoint instances.
        """
        return self._get_datapoint_instances(datapoint_instances)[0]

    def get_col_to_op_id(self) -> Dict[str, int]:
        """Gets a mapping form column name to the op_id which last produced the column."""
        col_to_op_id: Dict[str, int] = {}
        for op_id in nx.algorithms.dag.topological_sort(self.G):
            if op_id == INPUT_NODE_ID:
                for col in self.input_columns:
                    col_to_op_id[col] = INPUT_NODE_ID
                continue
            operator = self.G.nodes[op_id]["operator"]
            if operator.output_schema:
                for col in operator.output_schema:
                    col_to_op_id[col] = op_id
            if operator.drop_schema:
                for col in operator.drop_schema:
                    if col in col_to_op_id:
                        del col_to_op_id[col]
        return col_to_op_id

    def get_col_to_docstring(self) -> Dict[str, str]:
        col_to_op_id = self.get_col_to_op_id()
        op_id_to_docs = {
            op_id: self.G.nodes[op_id]["operator"].column_docs()
            for op_id in self.G.nodes
            if op_id != INPUT_NODE_ID
        }
        return {
            col: "Input column"
            if op_id == INPUT_NODE_ID
            else op_id_to_docs[op_id].get(col, "")
            for col, op_id in col_to_op_id.items()
        }

    def get_col_to_type(self) -> Dict[str, Any]:
        # Get input node data types, ignore fields where we don't explicitly have type info
        input_col_type = {k: type(v) for k, v in self.data_schema.items() if v}

        col_to_op_id = self.get_col_to_op_id()
        # Get output data type by operator output schema, ignore fields where we don't explicitly have type info
        op_data_type = {
            col: self.G.nodes[op_id]["operator"].output_schema[col]
            for col, op_id in col_to_op_id.items()
            if op_id != -1 and self.G.nodes[op_id]["operator"].output_schema[col]
        }

        # Merge data input schema and operator output schema
        # If any col had their types changed inplace then this will reflect the updated type
        input_col_type.update(op_data_type)
        return input_col_type

    def get_col_to_datapoint_instance(
        self, datapoint_instances: Optional[Union[DatapointType, DatapointTypes]] = None
    ) -> Dict[str, DatapointType]:
        """Gets a mapping from column name to datapoint instance that the column came from.
        This means that if a column got written by multiple operators, it will be assigned
        the datapoint instance corresponding to the last of those operators.

        Parameters
        ----------
        datapoint_instances
            A starting assignment of operator id to datapoint instances, or a single
            datapoint instance (which gets assigned to INPUT_NODE_ID).

        Returns
        -------
        Dict[str, DatapointType]
            A dictionary mapping a column name to the datapoint instance it came from.
        """
        col_to_op_id = self.get_col_to_op_id()
        op_id_to_datapoint_instance = self.get_datapoint_instances(datapoint_instances)
        return {k: op_id_to_datapoint_instance[v] for k, v in col_to_op_id.items()}

    def get_op_id_to_context_op_id(
        self, datapoint_instances: Optional[Union[DatapointType, DatapointTypes]] = None
    ) -> OpToContextOp:
        """
        Parameters
        ----------
        datapoint_instances
            A starting assignment of operator id to datapoint instances, or a single
            datapoint instance (which gets assigned to INPUT_NODE_ID).

        Returns
        -------
        Dict[str, int]
            A dictionary mapping op_id to context op_id.
        """
        return self._get_datapoint_instances(datapoint_instances)[1]

    def get_operators(self) -> Dict[OperatorId, Operator]:
        G = self.get_computation_subgraph(
            get_workflow_output_ids(self.workflow_config), [INPUT_NODE_ID]
        )
        operators = {}
        for op_id in nx.algorithms.dag.topological_sort(G):
            if op_id != INPUT_NODE_ID:
                operators[op_id] = G.nodes[op_id]["operator"]
        return operators

    def preload_workflow_resources(self) -> None:
        """This is a helper method to preload all the models into the workflow model cache.
        This preloading is important because if the trained model is contained within the
        ModelFeaturizer, Dask tries to pickle this model everytime. See ENG-6290.
        A global cache holds all the models pre-loaded and the ModelFeaturizer
        only uses the global cache thereby avoiding any Cloudpickle slowdown by Dask.
        """
        logger.info("Preloading Models into workflow model cache")

        model_operators = [
            operator
            for _, operator in self.get_operators().items()
            if isinstance(operator, model_op.Model)
        ]
        for model_operator in model_operators:
            model_operator.preload_resources_into_workflow_cache()

    def get_op_ids_before_dp_change(self) -> List[int]:
        """Returns the operator ids before change of a datapoint instance"""
        op_ids_before_datapoint_change = []
        op_id_to_datapoint_instance = self.get_datapoint_instances()
        for op_id in nx.algorithms.dag.topological_sort(self.G):
            if op_id == INPUT_NODE_ID:
                continue
            input_op_id = self.G.nodes[op_id]["op_config"].input_ids[0]
            if (
                op_id_to_datapoint_instance[op_id]
                != op_id_to_datapoint_instance[input_op_id]
            ):
                op_ids_before_datapoint_change.append(input_op_id)
        return op_ids_before_datapoint_change

    def get_op_id_to_context_ds_uid(
        self, op_id_to_ds_uid: Dict[int, int], parent_datasource_uid: int
    ) -> Dict[int, int]:
        """Returns a mapping of op_id to context_ds_uid, where the context_ds_uid is the
        first ds_uid encountered when going upstream that corresponds to a change in index,
        or parent_datasource_uid if none.
        """
        op_id_to_context_ds_uid = {INPUT_NODE_ID: parent_datasource_uid}
        op_id_to_datapoint_instance = self.get_datapoint_instances()
        for op_id in nx.algorithms.dag.topological_sort(self.G):
            if op_id == INPUT_NODE_ID:
                continue
            input_op_id = self.G.nodes[op_id]["op_config"].input_ids[0]
            op_changed_datapoint_instance = (
                op_id_to_datapoint_instance[op_id]
                != op_id_to_datapoint_instance[input_op_id]
            )
            if input_op_id in op_id_to_ds_uid and op_changed_datapoint_instance:
                op_id_to_context_ds_uid[op_id] = op_id_to_ds_uid[input_op_id]
            elif op_changed_datapoint_instance and input_op_id != -1:
                raise ValueError(
                    f"Operator {input_op_id} changed the index, but wasn't included in `op_id_to_ds_uid`"
                )
            else:
                op_id_to_context_ds_uid[op_id] = op_id_to_context_ds_uid[input_op_id]

        return op_id_to_context_ds_uid

    def get_last_operator_of_type(
        self, operator_type: Type[Operator]
    ) -> Optional[Operator]:
        """NOTE: for hierarchial applications, this will arbirarily pick the last node in
        one of the branches.
        """
        last_operator_of_type = None
        for op_id in nx.algorithms.dag.topological_sort(self.G):
            operator = self.G.nodes[op_id]["operator"]
            if isinstance(operator, operator_type):
                last_operator_of_type = operator
        return last_operator_of_type
