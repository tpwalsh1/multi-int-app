from typing import Any, Dict, List, Optional, Tuple

import pandas as pd

from snorkelflow.extraction.span import SpanCols
from snorkelflow.operators.candidates import (
    SpanExtractor,
    SpanFeaturizer,
    SpanFeaturizerExtractor,
    get_span_field_value_hash,
)
from snorkelflow.operators.featurizer import Featurizer, OpProgressCallback
from snorkelflow.operators.operator import ColSchema, no_op_progress_callback
from snorkelflow.rich_docs import (
    BOTTOM,
    LEFT,
    LINE_ID,
    PAGE_ID,
    RIGHT,
    TEXT,
    TOP,
    RichDocCols,
    TextClusters,
)
from snorkelflow.rich_docs.rich_doc import HVLines, RichDocList
from snorkelflow.types.performance import Performance
from snorkelflow.utils.logging import get_logger

# VISUAL - CLUSTER REGION SPECIFIC
REGION_LEFT = "region_left"
REGION_TOP = "region_top"
REGION_RIGHT = "region_right"
REGION_BOTTOM = "region_bottom"
REGION_TEXT = "region_text"

logger = get_logger("HocrParser")


class TextClusterer(Featurizer):
    """
    Operator that clusters horizontally aligned words using word spacing.

    This operator clusters horizontally aligned word that stays within a predefined word spacing.
    Text Clusters are the group of words that are separated by a single space.
    The heuristics employed here relies on the fact that if the words are separated by
    width > the max_width in standard typography, then they are separate word clusters.
    The max_width = wordspacing_tolerance * vertical width between 2 previous words.

    Optionally Merges Word clusters vertically into regions using bounding horizontal lines.
    Needs LinesFeaturizer if merge_words_between_vertical_lines or
    merge_rows_between_horizontal_lines are set.

    Parameters
    ----------
    wordspacing_tolerance
        The ratio (relatively to the vertical width) to consider 2 words belong to a same cluster.
    merge_words_between_vertical_lines
        If True, and provided LinesFeaturizer, will cluster words between vertical lines together.
    merge_words_between_horizontal_lines
        If True, and provided LinesFeaturizer, will cluster words between horizontal lines together.
    pages_field
        The name of the column containing the page numbers on which to run the operator on. Defaults to RichDocCols.CONTEXT_PAGES.

    Returns
    -------
    {RichDocCols.TEXT_CLUSTERS}
        A serialized TextClusters class containing all the text clusters information.
    """

    operator_impl_version: int = 1

    def __init__(
        self,
        wordspacing_tolerance: float = 0.75,
        merge_words_between_vertical_lines: bool = False,
        merge_rows_between_horizontal_lines: bool = False,
        pages_field: Optional[str] = RichDocCols.CONTEXT_PAGES,
    ):
        self.merge_rows_between_horizontal_lines = merge_rows_between_horizontal_lines
        self.wordspacing_tolerance = wordspacing_tolerance
        self.need_visual_lines = (
            merge_words_between_vertical_lines or merge_rows_between_horizontal_lines
        )
        self.pages_field = pages_field

    @property
    def input_schema(self) -> ColSchema:
        # TODO: Should we use the docs list and create a list of clusters instead?
        return (
            {RichDocCols.PAGE_DOCS: RichDocList, RichDocCols.HV_LINES: None}
            if self.need_visual_lines
            else {RichDocCols.PAGE_DOCS: RichDocList}
        )

    @property
    def output_schema(self) -> ColSchema:
        return {RichDocCols.TEXT_CLUSTERS: None}

    def estimate_perf(self, df: pd.DataFrame) -> Performance:
        avg_words = (
            df[RichDocCols.PAGE_DOCS]
            .head()
            .apply(lambda x: sum([len(y.words) for y in x]))
            .mean()
        )
        total_words = avg_words * len(df)
        return Performance(
            compute_time_secs=total_words * 0.02, peak_memory_mb=total_words * 0.002
        )

    def _cluster_words(
        self, df: pd.DataFrame, cluster_id_offset: int
    ) -> Tuple[Dict[int, int], pd.DataFrame]:
        """
        https://docs.microsoft.com/en-us/typography/develop/character-design-standards/whitespace
        Text Clusters are the group of words that are separated by a single space.
        The heuristics employed here relies on the fact that if the words are separated by
        width > the max_width in standard typography, then they are separate word clusters.
        """
        df = df.sort_values([PAGE_ID, LINE_ID, LEFT])
        space_max_width = (df[BOTTOM] - df[TOP]) * self.wordspacing_tolerance
        new_line = df[LINE_ID] - df[LINE_ID].shift(1)
        far_apart = (df[LEFT] - df[RIGHT].shift(1)) > space_max_width.shift(1)
        # TODO: Add a new line if a vertical line is between the two words.
        new_cluster = far_apart | new_line
        cluster_id = new_cluster.cumsum()
        cluster_id = cluster_id + cluster_id_offset
        word_to_cluster = dict(cluster_id)
        df_clusters = (
            df.assign(**{RichDocCols.TEXT_CLUSTER_ID: cluster_id})
            .groupby([RichDocCols.TEXT_CLUSTER_ID])
            .agg(
                {
                    LEFT: min,
                    RIGHT: max,
                    TOP: min,
                    BOTTOM: max,
                    SpanCols.CHAR_START: min,
                    SpanCols.CHAR_END: max,
                    TEXT: " ".join,
                    LINE_ID: min,
                    PAGE_ID: min,
                }
            )
            .reset_index()
        )
        return word_to_cluster, df_clusters

    def _get_bounding_lines(
        self, text_cluster: pd.Series, h_df: pd.DataFrame
    ) -> Tuple[Dict[str, int], Dict[str, int]]:
        empty_dict: Dict[str, int] = dict()

        bottom_line_df = h_df[
            (h_df[TOP] >= (text_cluster[TOP] + text_cluster[BOTTOM]) / 2)
            & (h_df[LEFT] < text_cluster[RIGHT])
            & (h_df[RIGHT] > text_cluster[LEFT])
        ]
        if bottom_line_df.empty:
            return empty_dict, empty_dict

        top_line_df = h_df[
            (h_df[BOTTOM] <= (text_cluster[TOP] + text_cluster[BOTTOM]) / 2)
            & (h_df[LEFT] < text_cluster[RIGHT])
            & (h_df[RIGHT] > text_cluster[LEFT])
        ]
        if top_line_df.empty:
            return empty_dict, empty_dict

        return top_line_df.iloc[-1].to_dict(), bottom_line_df.iloc[0].to_dict()

    def _merge_rows_between_horizontal_lines(
        self, df_clusters: pd.DataFrame, hv_lines: HVLines, context_pages: List[str]
    ) -> pd.DataFrame:
        """
        Merges clusters into rows
        """
        df_clusters = df_clusters.sort_values([PAGE_ID, TOP])
        df_clusters[RichDocCols.TEXT_REGION_ID] = -1

        clustered_region_id = 0
        for index, text_cluster in df_clusters.iterrows():
            page_index = text_cluster[PAGE_ID]
            if context_pages is not None:
                page_index = context_pages.index(text_cluster[PAGE_ID])
            if df_clusters.at[index, RichDocCols.TEXT_REGION_ID] != -1:
                continue

            clustered_region_id += 1

            df_clusters.at[index, RichDocCols.TEXT_REGION_ID] = clustered_region_id

            top_line, bottom_line = self._get_bounding_lines(
                text_cluster, hv_lines.dfs_horz[page_index]
            )
            # Find the next horizontal line to this text_cluster

            if not top_line or not bottom_line:
                continue

            # Now get all the texts between the bounds
            texts = df_clusters[
                (df_clusters[TOP] >= top_line[TOP])
                & (df_clusters[BOTTOM] <= bottom_line[TOP])
                & (df_clusters[LEFT] < text_cluster[RIGHT])
                & (df_clusters[RIGHT] > text_cluster[LEFT])
                & (df_clusters[PAGE_ID] == text_cluster[PAGE_ID])
            ]

            df_clusters.loc[
                texts.index, RichDocCols.TEXT_REGION_ID
            ] = clustered_region_id

        region_df = (
            df_clusters.groupby(RichDocCols.TEXT_REGION_ID)
            .agg(
                {LEFT: "min", RIGHT: "max", TOP: "min", BOTTOM: "max", TEXT: "\n".join}
            )
            .rename(
                columns={
                    LEFT: REGION_LEFT,
                    RIGHT: REGION_RIGHT,
                    TOP: REGION_TOP,
                    BOTTOM: REGION_BOTTOM,
                    TEXT: REGION_TEXT,
                }
            )
        )
        return pd.merge(
            df_clusters, region_df, how="left", on=RichDocCols.TEXT_REGION_ID
        )

    def _rd_to_text_cluster(
        self,
        richdoc_list: RichDocList,
        context_pages: List[str],
        hv_lines: Optional[HVLines] = None,
    ) -> pd.Series:
        cluster_id_offset = 0

        word_to_cluster_id: Dict[int, int] = {}
        cluster_df_list: List[pd.DataFrame] = []

        if not len(richdoc_list.rich_docs):
            df_cluster_cols = [
                RichDocCols.TEXT_CLUSTER_ID,
                LEFT,
                RIGHT,
                TOP,
                BOTTOM,
                SpanCols.CHAR_START,
                SpanCols.CHAR_END,
                TEXT,
                LINE_ID,
                PAGE_ID,
            ]
            return pd.Series(
                {
                    RichDocCols.TEXT_CLUSTERS: TextClusters(
                        {}, pd.DataFrame(columns=df_cluster_cols)
                    )
                }
            )

        for rich_doc_page in richdoc_list.rich_docs:
            _word_to_cluster_id, _cluster_df = self._cluster_words(
                rich_doc_page.words, cluster_id_offset
            )
            cluster_id_offset = _cluster_df[RichDocCols.TEXT_CLUSTER_ID].max() + 1
            word_to_cluster_id.update(_word_to_cluster_id)
            cluster_df_list.append(_cluster_df)

        cluster_df = pd.concat(cluster_df_list).reset_index(drop=True)

        if self.merge_rows_between_horizontal_lines and hv_lines:
            cluster_df = self._merge_rows_between_horizontal_lines(
                cluster_df, hv_lines, context_pages=context_pages
            )

        return pd.Series(
            {RichDocCols.TEXT_CLUSTERS: TextClusters(word_to_cluster_id, cluster_df)}
        )

    def compute_text_cluster(self, row: Any) -> pd.Series:
        hv_lines = None
        if self.need_visual_lines:
            hv_lines = row[RichDocCols.HV_LINES]
        output_series = self._rd_to_text_cluster(
            row[RichDocCols.PAGE_DOCS],
            context_pages=row.get(self.pages_field) if self.pages_field else None,
            hv_lines=hv_lines,
        )
        return output_series

    def _compute_features(
        self,
        input_df: pd.DataFrame,
        callback: OpProgressCallback = no_op_progress_callback,
    ) -> pd.DataFrame:
        """Override base class method"""
        output_df = input_df.apply(self.compute_text_cluster, axis=1)
        return output_df


class TextClusterSpanFeaturizer(SpanFeaturizer):
    """
    Featurizer that creates list of spans with one span per horizontal text cluster.

    This operator considers all text clusters created by TextClusterer as individual spans.
    For each spans,
    Prerequisite: The DAG must contain the TextCluterer before TextClusterSpanFeaturizer.

    This operator utilizes existing RichDoc prepopulated columns (no input required), includes
    {{RichDocCols.TEXT_CLUSTERS}: None, {RichDocCols.TEXT_COL}: str}
    """

    def __init__(self) -> None:
        self.field = RichDocCols.TEXT_COL

    @property
    def input_schema(self) -> ColSchema:
        return {RichDocCols.TEXT_CLUSTERS: None, RichDocCols.TEXT_COL: str}

    @property
    def output_schema(self) -> ColSchema:
        parent_output_schema = super().output_schema
        added_output_schema = self.get_suffixed_dict(
            {
                RichDocCols.TEXT_CLUSTER_ID: object,  # Cluster idx.
                LEFT: object,
                RIGHT: object,
                TOP: object,
                BOTTOM: object,
                REGION_LEFT: object,
                REGION_RIGHT: object,
                REGION_TOP: object,
                REGION_BOTTOM: object,
                REGION_TEXT: object,
            }
        )
        if parent_output_schema is None or added_output_schema is None:
            raise ValueError("Output schema is found none")
        return {**parent_output_schema, **added_output_schema}

    def extract_span_list_from_row(
        self, datapoint_uid: str, row: pd.Series
    ) -> List[Dict[str, Any]]:
        spans: List[Dict[str, Any]] = []
        span_field_value_hash = get_span_field_value_hash(row[RichDocCols.TEXT_COL])
        df_clusters = row[RichDocCols.TEXT_CLUSTERS].df_clusters
        for idx, cluster_row in df_clusters.to_dict(orient="index").items():
            spans.append(
                {
                    RichDocCols.TEXT_CLUSTER_ID: idx,
                    SpanCols.SPAN_FIELD: RichDocCols.TEXT_COL,
                    SpanCols.SPAN_FIELD_VALUE_HASH: span_field_value_hash,
                    SpanCols.CHAR_START: cluster_row[SpanCols.CHAR_START],
                    SpanCols.CHAR_END: cluster_row[SpanCols.CHAR_END],
                    SpanCols.SPAN_TEXT: cluster_row[TEXT],
                    SpanCols.SPAN_ENTITY: None,
                    SpanCols.INITIAL_LABEL: -1,
                    LEFT: cluster_row[LEFT],
                    RIGHT: cluster_row[RIGHT],
                    TOP: cluster_row[TOP],
                    BOTTOM: cluster_row[BOTTOM],
                    REGION_LEFT: cluster_row.get(REGION_LEFT, 0),
                    REGION_RIGHT: cluster_row.get(REGION_RIGHT, 0),
                    REGION_TOP: cluster_row.get(REGION_TOP, 0),
                    REGION_BOTTOM: cluster_row.get(REGION_BOTTOM, 0),
                    REGION_TEXT: cluster_row.get(REGION_TEXT, ""),
                }
            )
        return spans


class TextClusterSpanExtractor(SpanFeaturizerExtractor, TextClusterSpanFeaturizer):
    """Extractor that creates one span per horizontal text cluster."""

    def __init__(self) -> None:
        TextClusterSpanFeaturizer.__init__(self)

    @property
    def input_schema(self) -> ColSchema:
        # get input_Schema from TextClusterSpanFeaturizer
        return {**super(SpanExtractor, self).input_schema}

    @property
    def output_schema(self) -> ColSchema:
        parent_output_schema = super().output_schema
        added_output_schema = self.get_suffixed_dict(
            {
                RichDocCols.TEXT_CLUSTER_ID: int,  # Cluster idx.
                LEFT: int,
                RIGHT: int,
                TOP: int,
                BOTTOM: int,
                REGION_LEFT: int,
                REGION_RIGHT: int,
                REGION_TOP: int,
                REGION_BOTTOM: int,
                REGION_TEXT: str,
            }
        )
        if parent_output_schema is None or added_output_schema is None:
            raise ValueError("Output schema is found none")
        return {**parent_output_schema, **added_output_schema}

    def extract_span_list_from_row(
        self, datapoint_uid: str, row: pd.Series
    ) -> List[Dict[str, Any]]:
        return TextClusterSpanFeaturizer.extract_span_list_from_row(
            self, datapoint_uid, row
        )
