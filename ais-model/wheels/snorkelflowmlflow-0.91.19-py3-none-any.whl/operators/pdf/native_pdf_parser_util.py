"""
MIT License

Copyright (c) 2018 HazyResearch

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
"""

import collections
import copy
import logging
import re
import string
import sys
from collections import Counter
from functools import cmp_to_key
from typing import Any, Dict, List, NamedTuple, Optional, Tuple, Union

import pdfplumber
from pdfminer.converter import PDFPageAggregator
from pdfminer.layout import (
    LAParams,
    LTAnno,
    LTChar,
    LTComponent,
    LTContainer,
    LTCurve,
    LTFigure,
    LTLayoutContainer,
    LTLine,
    LTPage,
    LTTextBox,
    LTTextContainer,
    LTTextLine,
)
from pdfminer.pdfinterp import PDFPageInterpreter, PDFResourceManager
from pdfminer.psparser import PSException
from pdfminer.utils import INF, apply_matrix_pt

from api_utils.exceptions import UserInputError
from snorkelflow.utils.logging import get_logger

logger = get_logger("NativePDFParser")

get_logger("pdfminer").setLevel(logging.ERROR)

# We assume a high quality image by default. We use a fixed size so
# the bounding boxes for all pdfs are comparable (needed to write e.g. meaningful
# numeric LFs over bbox coordinates).
DEFAULT_PIXELS_PER_INCH = 300

# These parameters control how lines/words/paragraphs are parsed in a PDF
DEFAULT_LA_PARAMS = {"char_margin": 1.0, "word_margin": 0.1, "all_texts": True}

# Parser version associated with the NativePDFParser.
# 0 : Legacy parser version
# 1 : Parser version that enforces word boundary checks and errors for malformed PDFs
LEGACY_PARSER_VERSION = 0
LATEST_PARSER_VERSION = 1


def _pts_to_pixels(pt: float, pixels_per_inch: int = DEFAULT_PIXELS_PER_INCH) -> int:
    """
    This is important as we convert the PDF Points to Pixel coordinates
    For now we floor the values. We can also ceil it (1 px difference and
    we should be fine)
    """
    # PDF uses Pts. There are 72 points in an inch.
    PTS_PER_INCH = 72
    return int(pt * pixels_per_inch / PTS_PER_INCH)


def _allowed_char(c: str) -> bool:
    """
    Returns whether the given unicode char is allowed in output
    """
    if c in "\n\t":
        return False
    o = ord(c)
    if o < 0:
        return False
    if o < 128:
        return c in string.printable
    # Genereally allow unicodes, TODO: check for unicode control characters
    # characters
    return True


def keep_allowed_chars(text: str) -> str:
    """
    Cleans the text for output
    """
    #     print ','.join(str(ord(c)) for c in text)
    return "".join(" " if c == "\n" else c for c in text.strip() if _allowed_char(c))


def normalize_bbox(coords: List[float], ymax: int, scaler: int = 2) -> List[float]:
    """
    scales all coordinates and flip y axis due to different
    origin coordinates (top left vs. bottom left)
    """
    return [
        coords[0] * scaler,
        ymax - (coords[3] * scaler),
        coords[2] * scaler,
        ymax - (coords[1] * scaler),
    ]


def _font_size_of(ch: "LTChar") -> int:
    return max(map(abs, ch.matrix[:4]))  # type: ignore


def _clean_textline(line: "LTTextLine") -> Optional["LTTextLine"]:
    clean_text = keep_allowed_chars(line.get_text()).strip()
    # Skip empty and invalid lines
    if clean_text:
        # TODO: add subscript detection and use latex underscore
        # or superscript
        line.clean_text = clean_text
        line.font_name, line.font_size = _font_of_line(line)
        return line
    else:
        return None


def _font_of_line(line: "LTTextLine") -> Tuple[Any, int]:
    """
    Returns the font type and size of the first alphanumeric
    char in the text or None if there isn't any.
    """
    for ch in line:
        if isinstance(ch, LTChar) and ch.get_text().isalnum():
            return (ch.fontname, _font_size_of(ch))
    return (None, 0)


def normalize_pts(
    pts: List[Tuple[float, float]], ymax: int, scaler: int = 2
) -> List[Tuple[float, float]]:
    """
    scales all coordinates and flip y axis due to different
    origin coordinates (top left vs. bottom left)
    """
    return [(x * scaler, ymax - (y * scaler)) for x, y in pts]


# Compact wrapper representation for the pdf
class PDFElems(NamedTuple):
    lines: List["LTTextLine"]
    pars: List["LTTextBox"]
    segments: List["LTLine"]
    curves: List["LTCurve"]
    figures: List["LTFigure"]
    layout: "LTPage"
    chars: List[Union["LTChar", "LTAnno"]]


class CustomPDFPageAggregator(PDFPageAggregator):
    """
    A custom version of the default pdf miner stateful draw call
    interpreter. Handles the creation of python object from pdf draw
    calls.
    Changes the way LTCurves are created - break up large polylines
    and rectangles into standard segments.
    """

    line_only_shape = re.compile("ml+h?")

    def paint_path(
        self, gstate: Any, stroke: bool, fill: bool, evenodd: bool, path: List[tuple]
    ) -> None:
        """
        Converting long paths to small segments each time we m=Move
        or h=ClosePath for polygon
        """
        shape = "".join(x[0] for x in path)
        prev_split = 0
        for i in range(len(shape)):
            if shape[i] == "m" and prev_split != i:
                self.paint_single_path(
                    gstate, stroke, fill, evenodd, path[prev_split:i]
                )
                prev_split = i
            if shape[i] == "h":
                self.paint_single_path(
                    gstate, stroke, fill, evenodd, path[prev_split : i + 1]
                )
                prev_split = i + 1

        # clean up remaining segments
        if prev_split < len(shape):
            self.paint_single_path(gstate, stroke, fill, evenodd, path[prev_split:])

    def paint_single_path(
        self, gstate: Any, stroke: bool, fill: bool, evenodd: bool, path: List[tuple]
    ) -> None:
        """
        Converting a single path draw command into lines and curves objects
        """
        if len(path) < 2:
            return
        shape = "".join(x[0] for x in path)

        pts = []
        for p in path:
            for i in range(1, len(p), 2):
                pts.append(apply_matrix_pt(self.ctm, (p[i], p[i + 1])))

        # Line mode
        if self.line_only_shape.match(shape):
            # check for sloped lines first
            has_slope = False
            for i in range(len(pts) - 1):
                if pts[i][0] != pts[i + 1][0] and pts[i][1] != pts[i + 1][1]:
                    has_slope = True
                    break
            if not has_slope:
                for i in range(len(pts) - 1):
                    self.cur_item.add(LTLine(gstate.linewidth, pts[i], pts[i + 1]))

                # Adding the closing line for a polygon, especially rectangles
                if shape.endswith("h"):
                    self.cur_item.add(LTLine(gstate.linewidth, pts[0], pts[-1]))
                return

        # Add the curve as an arbitrary polyline (belzier curve info is lost here)
        self.cur_item.add(LTCurve(gstate.linewidth, pts))

    def normalize_pdf(self, layout: LTPage, scaler: int) -> Tuple[PDFElems, Counter]:
        """
        Normalizes pdf object coordinates (bot left) to image
        conventions (top left origin).
        Returns the list of chars and average char size
        """
        chars = []
        lines: List[LTTextContainer] = []
        pars: List[LTTextBox] = []
        height = scaler * layout.height
        font_size_counter: Any = collections.Counter()
        # Lines longer than this are included in segments
        pts_thres = 2.0 * scaler
        segments = []
        curves = []
        figures = []
        container: LTContainer = None
        _font = None

        def processor(m: Any, parent: Any) -> None:
            """Convert pdfminer.six's LT* into pdftotree's PDFElems."""
            # Traverse
            if isinstance(m, LTContainer):
                for child in m:
                    processor(child, m)
            # Normalizes the coordinate system to be consistent with
            # image library conventions (top left as origin)
            if isinstance(m, LTComponent):
                m.set_bbox(normalize_bbox(m.bbox, height, scaler))
            # Assign LT* into PDFElems
            if isinstance(m, LTCurve):
                m.pts = normalize_pts(m.pts, height, scaler)
                # Only keep longer lines here
                if isinstance(m, LTLine) and max(m.width, m.height) > pts_thres:
                    segments.append(m)
                else:  # Here we exclude straight lines from curves
                    curves.append(m)
            elif isinstance(m, LTFigure):
                figures.append(m)
            elif isinstance(m, LTChar):
                if not isinstance(parent, LTTextLine):
                    # Construct LTTextContainer from LTChar(s) that are not
                    # children of LTTextLine, then group LTChar(s) into LTTextLine
                    nonlocal _font
                    nonlocal container
                    font = (m.fontname, m.size)
                    dummy_bbox = (+INF, +INF, -INF, -INF)
                    if font != _font:
                        if _font is not None:
                            layout_container = LTLayoutContainer(dummy_bbox)
                            dummy_text_lines = layout_container.group_objects(
                                self.laparams, container
                            )
                            dummy_text_boxes = layout_container.group_textlines(
                                self.laparams, dummy_text_lines
                            )
                            for textbox in dummy_text_boxes:
                                for textline in textbox:
                                    cleaned_textline = _clean_textline(textline)
                                    if cleaned_textline is not None:
                                        pars.append(textbox)
                                        lines.append(cleaned_textline)
                        container = LTContainer(dummy_bbox)
                        _font = font
                    container.add(m)
                # Collect chars for later stats analysis
                chars.append(m)
                # fonts could be rotated 90/270 degrees
                font_size = _font_size_of(m)
                font_size_counter[font_size] += 1
            elif isinstance(m, LTTextLine):
                cleaned_textline = _clean_textline(m)
                if cleaned_textline is not None:
                    pars.append(parent)
                    lines.append(cleaned_textline)
            elif isinstance(m, LTAnno):  # Also include non character annotations
                chars.append(m)
            return

        processor(layout, None)

        # Resets line y0 to the first y0 of alphanum character instead of
        # considering exotic unicode symbols and sub/superscripts to reflect
        # accurate alignment info
        for l in lines:
            alphanum_c = next((c for c in l if c.get_text().isalnum()), None)
            if alphanum_c:
                l.set_bbox((l.x0, alphanum_c.y0, l.x1, alphanum_c.y1))

        elems = PDFElems(lines, pars, segments, curves, figures, layout, chars)
        return elems, font_size_counter


def get_word_boundaries(line: "LTTextLine") -> List[Tuple[str, int, int, int, int]]:
    """Split a line of text into words.

    :param line: a line of text
    :return: a list of words
    """
    line_text = line.get_text()
    line_chars: List[Tuple[str, int, int, int, int]] = []
    for obj in line:
        if isinstance(obj, LTChar):
            left, top, right, bottom = obj.bbox
            line_chars.append(
                (
                    obj.get_text(),
                    _pts_to_pixels(top),
                    _pts_to_pixels(left),
                    _pts_to_pixels(bottom),
                    _pts_to_pixels(right),
                )
            )
    words: List[Tuple[str, int, int, int, int]] = []
    line_words: List[str] = line_text.split()  # word split by " " (space)
    char_idx = 0
    for word in line_words:
        curr_min_bbox_1 = sys.maxsize
        curr_min_bbox_2 = sys.maxsize
        curr_max_bbox_1 = -1
        curr_max_bbox_2 = -1
        len_idx = 0
        while len_idx < len(word):
            char: str = line_chars[char_idx][0]
            if char in [" ", "\xa0", "\t"]:
                char_idx += 1
                continue
            if word[len_idx : len_idx + len(char)] != char:
                logger.warning(f"Out of order ({word}, character={char})")

            curr_min_bbox_1 = min(curr_min_bbox_1, line_chars[char_idx][1])
            curr_min_bbox_2 = min(curr_min_bbox_2, line_chars[char_idx][2])
            curr_max_bbox_1 = max(curr_max_bbox_1, line_chars[char_idx][3])
            curr_max_bbox_2 = max(curr_max_bbox_2, line_chars[char_idx][4])
            len_idx += len(line_chars[char_idx][0])
            char_idx += 1
        words.append((word, curr_min_bbox_1, curr_min_bbox_2, curr_max_bbox_1, curr_max_bbox_2))  # type: ignore
    return words


def float_cmp(f1: float, f2: float) -> int:
    if f1 > f2:
        return 1
    elif f1 < f2:
        return -1
    else:
        return 0


def reading_order(e1: Any, e2: Any) -> int:
    """
    A comparator to sort bboxes from top to bottom, left to right.
    lines is the first item, pars is the second
    """
    l1 = e1[0]
    l2 = e2[0]
    if round(l1.y0) == round(l2.y0) or round(l1.y1) == round(l2.y1):
        return float_cmp(l1.x0, l2.x0)
    return float_cmp(l1.y0, l2.y0)


class NativePDFParser:
    def __init__(
        self,
        pdf_path: str,
        fp: Any,
        pdf_pages: Optional[List[int]],
        parser_version: int,
        extract_pars: Optional[bool] = False,
        la_params: Optional[Dict[str, Any]] = DEFAULT_LA_PARAMS,
    ):
        self.laparams = la_params
        self.fp = fp
        self.pdf_path = pdf_path
        self.pdf_pages = pdf_pages
        self.extract_pars = extract_pars
        self.rsrcmgr = PDFResourceManager()
        self.device = CustomPDFPageAggregator(
            self.rsrcmgr, laparams=LAParams(**self.laparams)
        )
        self.interpreter = PDFPageInterpreter(self.rsrcmgr, self.device)
        self.parser_version = parser_version

    def _get_pdf_pages(self) -> List[pdfplumber.page.Page]:
        try:
            pdf = pdfplumber.open(self.fp, laparams=self.laparams)
        except PSException:
            error_msg = f"Invalid pdf file: {self.pdf_path}"
            raise UserInputError(detail=error_msg, user_friendly_message=error_msg)

        try:
            return pdf.pages
        except KeyError as e:  # this e is about the missing key
            error_msg = f"Failed to parse pdf file: {self.pdf_path} due to missing key: {e.args[0]}"
            logger.exception(error_msg)
            raise UserInputError(detail=error_msg, user_friendly_message=error_msg)

    def _get_page_lines(
        self, page: pdfplumber.page.Page, page_id: int
    ) -> Tuple[List[LTTextLine], List[LTTextBox]]:
        # Gets lines and paras from the PDF page

        # Process the PDF to get page elements
        try:
            self.interpreter.process_page(page.page_obj)
        except OverflowError as oe:
            logger.exception(f"{oe}, skipping page {page_id} of {self.pdf_path}")
        layout = self.device.get_result()
        elems, _ = self.device.normalize_pdf(layout, scaler=1)

        # Extract lines and paras from the elems structure
        sorted_elems = sorted(
            zip(elems.lines, elems.pars), key=cmp_to_key(reading_order)
        )
        if sorted_elems:
            elem_lines, elem_pars = zip(*sorted_elems)
        else:
            elem_lines, elem_pars = [], []
        return elem_lines, elem_pars

    def _get_line_clusters(self, lines: List[LTTextLine]) -> List[List[LTTextLine]]:
        # Get lines that should be grouped together
        line_clusters: List[List[LTTextLine]] = []
        for line in lines:
            if line_clusters:
                prev_line = line_clusters[-1][-1]
                width = line.x0 - prev_line.x1
                prev_line_height = prev_line.y1 - prev_line.y0
                leading_space = (line.y1 - prev_line.y1) / (prev_line_height)

                if width >= 0 and (
                    (width <= prev_line_height and leading_space < 1.0)
                    or prev_line.y0 == line.y0
                    or prev_line.y1 == line.y1
                ):
                    line_clusters[-1].append(line)
                    continue
            line_clusters.append([line])
        return line_clusters

    def _process_page_lines(
        self,
        lines: List[LTTextLine],
        pars: List[LTTextBox],
        page_id: int,
        initial_line_id: int,
        initial_word_id: int,
        initial_par_id: int,
        page_bbox: Tuple[int, int, int, int],
    ) -> Tuple[List[Tuple[int, List]], List[Tuple], int, int]:
        line_clusters = self._get_line_clusters(lines)
        line_id = initial_line_id
        word_id = initial_word_id

        # Keeps track of area/par/line/word ids and bboxes
        line_words_lists: List[Tuple[int, List]] = []
        par_list: List[Tuple] = []

        # Global index used to track total lines/pars
        par_list_idx = 0
        max_par_id = int(initial_par_id)
        par_id_map: Dict[LTTextBox, int] = {}

        for line_cluster in line_clusters:
            line_words_lists.append((line_id, []))
            for line in line_cluster:
                if self.extract_pars:
                    # Adding paras for each line
                    line_par = pars[par_list_idx]
                    if line_par not in par_id_map:
                        # Creating a new par id
                        par_id = max_par_id + 1
                        max_par_id += 1
                        par_id_map[line_par] = par_id

                        # Adding bbox for para
                        left, top, right, bottom = line_par.bbox
                        line_par_bbox = (
                            _pts_to_pixels(left),
                            _pts_to_pixels(top),
                            _pts_to_pixels(right),
                            _pts_to_pixels(bottom),
                        )
                        par_list.append((par_id, *line_par_bbox))
                    else:
                        par_id = par_id_map[line_par]
                    par_list_idx += 1
                else:
                    par_id = int(page_id)

                # Adding new lines
                for text, top, left, bottom, right in get_word_boundaries(line):
                    line_words_lists[-1][1].append(
                        (
                            page_id,
                            par_id,
                            par_id,
                            line_id,
                            word_id,
                            left,
                            top,
                            right,
                            bottom,
                            text,
                        )
                    )
                    # Ensure that the word boundary box is within the page boundary box
                    if (
                        top < page_bbox[1]
                        or bottom > page_bbox[3]
                        or left < page_bbox[0]
                        or right > page_bbox[2]
                    ) and self.parser_version > LEGACY_PARSER_VERSION:
                        error_message = f"Word {text} is outside of the page boundary"
                        detailed_error_message = f"Word {text} with boundary box ({left}, {top}, {right}, {bottom}) is outside of the page boundary ({page_bbox})"
                        raise UserInputError(
                            user_friendly_message=error_message,
                            detail=detailed_error_message,
                        )
                    word_id += 1
            line_id += 1
        return line_words_lists, par_list, word_id, max_par_id

    def parse(
        self,
    ) -> Tuple[List[Tuple], List[Tuple], List[Tuple], List[Tuple], List[Tuple]]:
        pages: List[Tuple] = []
        pars: List[Tuple] = []
        lines: List[Tuple] = []
        line_words_lists: List[Tuple[int, List]] = []
        words: List[Tuple] = []

        word_id = 0
        par_id = -1
        page_id = -1

        pdf_pages_obj = self._get_pdf_pages()
        for page_id_unfiltered, page in enumerate(pdf_pages_obj):
            if self.pdf_pages is not None and page_id_unfiltered not in self.pdf_pages:
                continue
            page_id += 1
            page_bbox = (
                0,
                0,
                _pts_to_pixels(int(page.width)),
                _pts_to_pixels(int(page.height)),
            )
            pages.append((page_id, *page_bbox))
            elem_lines, elem_pars = self._get_page_lines(page, page_id)
            (
                page_line_words_lists,
                page_pars,
                word_id,
                par_id,
            ) = self._process_page_lines(
                elem_lines,
                elem_pars,
                page_id=page_id,
                initial_line_id=len(line_words_lists),
                initial_word_id=word_id,
                initial_par_id=par_id,
                page_bbox=page_bbox,
            )
            line_words_lists.extend(page_line_words_lists)
            if self.extract_pars:
                pars.extend(page_pars)
            else:
                pars.append((page_id, *page_bbox))

        for line_id, line_words in line_words_lists:
            line_top_px = min((word[6] for word in line_words))
            line_bottom_px = max((word[8] for word in line_words))
            line_left_px = min((word[5] for word in line_words))
            line_right_px = max((word[7] for word in line_words))
            line_bbox = (line_left_px, line_top_px, line_right_px, line_bottom_px)
            lines.append((line_id, line_bottom_px - line_top_px, *line_bbox))
            words.extend(line_words)
        # pars/areas are the same in this context
        areas = copy.deepcopy(pars)
        return (pages, areas, pars, lines, words)
