import html
import re
from typing import Any, Optional, Tuple

import pandas as pd
from bs4 import BeautifulSoup

from api_utils.exceptions import UserInputError
from snorkelflow.operators.base_rich_doc_parser import BaseRichDocParser
from snorkelflow.operators.featurizer import Featurizer, OpProgressCallback
from snorkelflow.operators.operator import ColSchema, no_op_progress_callback
from snorkelflow.rich_docs import (
    AreasType,
    LinesType,
    PagesType,
    ParsType,
    RichDoc,
    WordsType,
)
from snorkelflow.types.performance import Performance
from snorkelflow.utils.logging import get_logger

logger = get_logger("HocrParser")

BBOX_RGX = "bbox\s+(\d+\s+\d+\s+\d+\s+\d+)"
FONT_SIZE_RGX = "x_size\s+([\d\.]+)"
PAGE_RGX = """<[^>]*class=["']ocrx?_page['"][^>]*>"""
AREA_RGX = """<[^>]*class=['"]ocrx?_carea['"][^>]*>"""
PAR_RGX = """<[^>]*class=['"]ocrx?_par['"][^>]*>"""
LINE_RGX = """<[^>]*class=['"]ocrx?_(line|header|caption|textfloat)['"][^>]*>"""
WORD_RGX = """<[^>]*class=['"]ocrx?_word['"][^>]*>([^>]*)</(html:)?span>"""
DOC_WORDS_RGX = """<[^>]*class=['"]ocrx?_word['"][^>]*>([^>]*)</(html:)?span>"""
META_RGX = """<meta name=["']ocr-capabilities["'] content=["'](.*?)["']"""


def check_hocr_support(hocr: str, index: Any) -> None:
    # Check that available tags match the ones we expect.
    soup = BeautifulSoup(hocr, "lxml")
    capabilities = soup.find(name="meta", attrs={"name": "ocr-capabilities"})
    if capabilities is None:
        err_msg = f"hocr for {index} is missing ocr-capabilities header"
        raise UserInputError(detail=err_msg, user_friendly_message=err_msg)
    capabilities_content: str = capabilities.get("content", "")
    for tag in ["page", "carea", "par", "line", "word"]:
        if not re.search(f"ocrx?_{tag}", capabilities_content):
            err_msg = f"hocr for {index} is missing required {tag} tag"
            raise UserInputError(detail=err_msg, user_friendly_message=err_msg)


class HocrToRichDocParser(BaseRichDocParser):
    """
    Operator that parses hOCR and creates a RichDoc, a Snorkel-Flow-native representation of a pdf document with formatting preserved.

    This operator parses hOCR field to create a Snorkel-Flow-native representation
    of hOCR documents, including a richer text representation, spatial information,
    etc. with the original formatting preserved. RichDoc representation empowers
    in-depth tools with hOCR-formatted data.

    The output includes: a stripped raw text representation of the rich doc (rich_doc_text),
    a serialized RichDoc that corresponds to rich_doc_text (rich_doc_pkl),
    a serialized list of RichDoc objects, one per page (page_docs), and
    character offsets of text starting on each page (page_char_starts).

    Parameters
    ----------
    field
        The name of the column in the dataframe contains hOCR values
    drop_field
        A boolean to drop original hOCR text when True. This option is deprecated and a no-op. Please use ColumnDropper instead.

    Returns
    -------
    rich_doc_text: a stripped raw text representation of the rich doc
    rich_doc_pkl: a serialized RichDoc that corresponds to rich_doc_text
    page_docs: a serialized list of RichDoc objects, one per page
    page_char_starts: Character offsets of text starting on each page
    """

    bbox_rgx = re.compile(BBOX_RGX)
    font_size_rgx = re.compile(FONT_SIZE_RGX)
    operator_impl_version: int = 3

    def __init__(self, field: str, drop_field: bool = True):
        self.field = field
        if drop_field:
            logger.warning(
                f"drop_field is deprecated and a no-op. Please use ColumnDropper instead."
            )

    @property
    def input_schema(self) -> ColSchema:
        return {self.field: str}

    def estimate_perf(self, df: pd.DataFrame) -> Performance:
        hocr = df.head()[self.field]
        doc_words = len(
            re.findall(
                """<[^>]*class=['"]ocrx?_word['"][^>]*>([^>]*)</(html:)?span>""",
                hocr[0],
            )
        )
        total_words = len(df) * doc_words
        return Performance(
            compute_time_secs=total_words * 0.005, peak_memory_mb=len(df) * 0.2
        )

    def _get_bbox(self, string: str) -> Tuple[int, int, int, int]:
        bbox_match = self.bbox_rgx.search(string)
        if bbox_match:
            return tuple(int(x) for x in bbox_match.group(1).split())  # type: ignore
        else:
            return (-1, -1, -1, -1)

    def _parse_hocr(self, index: Any, hocr: str) -> pd.Series:
        check_hocr_support(hocr, index)

        # Normalize the hocr by unescaping html entities that can add noise to
        # the extracted text (e.g. &amp; or &#39;)
        hocr = self._unescape_html_entities(hocr)

        # Use regex to parse hocr into a tree of pages, areas, pars, lines and
        # words. Note that regex cannot be used to parse arbitrary html, but we
        # only need to i) look for 5 standard hocr tags ii) find the starting
        # tags only (the ending is implicit in the next start tag e.g. one page
        # ends when the next page begins.), which can be done with regex.
        page_it = re.finditer(re.compile(PAGE_RGX), hocr)
        area_it = re.finditer(re.compile(AREA_RGX), hocr)
        par_it = re.finditer(re.compile(PAR_RGX), hocr)
        line_it = re.finditer(re.compile(LINE_RGX), hocr)
        word_it = re.finditer(re.compile(WORD_RGX), hocr)
        pages: PagesType = []
        areas: AreasType = []
        pars: ParsType = []
        lines: LinesType = []
        words: WordsType = []
        next_page = next(page_it, None)
        next_area = next(area_it, None)
        next_par = next(par_it, None)
        next_line = next(line_it, None)

        # TODO: Instead of making bbox and font size part of the regex (forced),
        # just capture the whole xml object (upto >) and do a separate regex search
        # within that.
        for cur_word in word_it:
            while next_page is not None and next_page.start() < cur_word.start():
                bbox = self._get_bbox(next_page.group(0))
                pages.append((len(pages), *bbox))
                next_page = next(page_it, None)
            while next_area is not None and next_area.start() < cur_word.start():
                bbox = self._get_bbox(next_area.group(0))
                areas.append((len(areas), *bbox))
                next_area = next(area_it, None)
            while next_par is not None and next_par.start() < cur_word.start():
                bbox = self._get_bbox(next_par.group(0))
                pars.append((len(pars), *bbox))
                next_par = next(par_it, None)
            while next_line is not None and next_line.start() < cur_word.start():
                bbox = self._get_bbox(next_line.group(0))
                font_size_match = self.font_size_rgx.search(next_line.group(0))
                font_size = float(font_size_match.group(1)) if font_size_match else 0.0
                lines.append((len(lines), font_size, *bbox))
                next_line = next(line_it, None)

            bbox = self._get_bbox(cur_word.group(0))
            if -1 in bbox:
                err_msg = f"Error parsing hocr -  index:{index}, page no.: {len(pages)-1}, bounding box: {cur_word.group(0)}, text: {cur_word.group(1)}"
                raise UserInputError(
                    detail=err_msg,
                    user_friendly_message=err_msg,
                    how_to_fix="Ensure the hocr is properly formatted",
                )

            text = cur_word.group(1)
            words.append(
                (
                    # -1 because we append to the first four arrays before inserting
                    # into words.
                    len(pages) - 1,
                    len(areas) - 1,
                    len(pars) - 1,
                    len(lines) - 1,
                    len(words),
                    *bbox,
                    text,
                )
            )
        rich_doc = RichDoc.from_records(
            pages=pages, areas=areas, pars=pars, lines=lines, words=words
        )
        return self._rich_doc_to_columns(rich_doc)

    def _unescape_html_entities(self, text: str) -> str:
        return html.unescape(text)

    def _compute_features(
        self,
        input_df: pd.DataFrame,
        callback: OpProgressCallback = no_op_progress_callback,
    ) -> pd.DataFrame:
        """Override base class method"""
        return input_df.apply(
            lambda row: self._parse_hocr(index=row.name, hocr=row[self.field]), axis=1
        )


class TruncateHOCR(Featurizer):
    """
    Truncates a HOCR document to a certain # of pages.

    Truncates a given column of HOCR documents to a certain # of pages and write the truncated documents to a new column.

    Parameters
    ----------
    field : str
        The name of the column containing the HOCR documents.
    target_field : str, optional
        The name of the column to write the truncated HOCR documents to. If not provided, the truncated documents will be written to a column named <field>_truncated.
    pages : int, optional
        The number of pages to truncate the HOCR documents to. If not provided, the HOCR documents will be truncated to 5 pages.
    ignore_errors : bool, optional
        Whether to ignore errors when parsing the HOCR documents. If True, the original HOCR documents will be written to the target column even if there are errors during truncation.
    """

    def __init__(
        self,
        field: str,
        target_field: Optional[str] = None,
        pages: int = 5,
        ignore_errors: bool = False,
    ) -> None:
        self.field = field
        self.target_field = target_field or f"{field}_truncated"
        if pages <= 0:
            err_msg = f"Pages input in TruncateHOCR must be > 0, found {pages}"
            raise UserInputError(detail=err_msg, user_friendly_message=err_msg)
        self.pages = pages
        self.ignore_errors = ignore_errors

    @property
    def input_schema(self) -> ColSchema:
        return {self.field: str}

    @property
    def output_schema(self) -> ColSchema:
        return {self.target_field: str}

    def _truncate_hocr(self, hocr: str, index: Any) -> str:
        try:
            check_hocr_support(hocr, index)
            soup = BeautifulSoup(hocr, "lxml")
            pages = soup.find_all("div", "ocr_page")
            pages_to_decompose = pages[self.pages :]
            for page in pages_to_decompose:
                page.decompose()
            return soup.prettify()
        except Exception as e:
            if self.ignore_errors:
                logger.info(
                    "Error truncating hocr document, returning original document",
                    exc_info=True,
                )
                return hocr
            else:
                raise e

    def _compute_features(
        self, df: pd.DataFrame, callback: OpProgressCallback = no_op_progress_callback
    ) -> pd.DataFrame:
        """Override base class method"""
        df[self.target_field] = df.apply(
            lambda row: self._truncate_hocr(hocr=row[self.field], index=row.name),
            axis=1,
        )
        return df
