import json
import time
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

from api_utils.exceptions import OperatorExecutionError, UserInputError
from file_utils.core import open_file
from operators.pdf.native_pdf_parser_util import (
    DEFAULT_LA_PARAMS,
    LATEST_PARSER_VERSION,
    NativePDFParser,
)
from snorkelflow.operators.base_rich_doc_parser import BaseRichDocParser
from snorkelflow.operators.featurizer import OpProgressCallback
from snorkelflow.operators.operator import (
    ColSchema,
    no_op_progress_callback,
    write_skipped_datapoints,
)
from snorkelflow.rich_docs import (
    AREA_COLS,
    AREA_ID,
    BBOX_COLS,
    BOTTOM,
    LEFT,
    LINE_COLS,
    LINE_ID,
    PAGE_COLS,
    PAGE_ID,
    PAR_COLS,
    PAR_ID,
    TOP,
    WORD_COLS,
    WORD_ID,
    RichDoc,
)
from snorkelflow.rich_docs.rich_doc import RichDocCols, RichDocList
from snorkelflow.types.performance import Performance
from snorkelflow.utils.file import get_path_storage_options
from snorkelflow.utils.logging import get_logger

logger = get_logger("PDFToRichDocParser")


class PDFToRichDocParser(BaseRichDocParser):
    """
    Operator that parses a PDF into a RichDoc (see docs for details).

    This operator parses PDF to create a Snorkel-Flow-native representation
    of hOCR documents, including a richer text representation, spatial information,
    etc. with the original formatting preserved. RichDoc representation empowers
    in-depth tools with PDF-formatted data.

    The output includes: a stripped raw text representation of the rich doc (rich_doc_text),
    a serialized RichDoc that corresponds to rich_doc_text (rich_doc_pkl),
    a serialized list of RichDoc objects, one per page (page_docs), and
    character offsets of text starting on each page (page_char_starts).

    Parameters
    ----------
    field
        The name of the column in the dataframe contains PDF urls.
    remove_superscripts
        If true, remove the superscripts in the PDF (default to false)
    pages_field
        Field used to filter pages from the pdf
    extract_pars
        If true, extract paragraphs/areas from the PDF
    parser_params
        pdfminer parsing parameters that control text grouping
    ignore_errors
        If true, ignore errors during parsing
    parser_version
        The version of the parser used to parse the PDF.
        If not provided, the latest parser version is used.

    Returns
    -------
    rich_doc_text
        A stripped raw text representation of the rich doc
    rich_doc_pkl
        A serialized RichDoc that corresponds to rich_doc_text
    page_docs
        A serialized list of RichDoc objects, one per page
    page_char_starts
        A character offsets of text starting on each page
    """

    operator_impl_version: int = 5
    is_expensive = True

    def __init__(
        self,
        field: str,
        remove_superscripts: bool = False,
        pages_field: Optional[str] = None,
        extract_pars: bool = False,
        parser_params: str = json.dumps(DEFAULT_LA_PARAMS),
        ignore_errors: bool = False,
        parser_version: Optional[int] = LATEST_PARSER_VERSION,
    ):
        self.field = field
        self.remove_superscripts = remove_superscripts
        self.pages_field = pages_field
        self.extract_pars = extract_pars
        self.ignore_errors = ignore_errors
        self.native_pdf_parser_version = parser_version

        try:
            self.parser_params = json.loads(parser_params)
        except json.decoder.JSONDecodeError as e:
            err_msg = f"Provided parser_params {parser_params}. Failed to parse as a valid JSON dict."
            raise UserInputError(detail=str(e), user_friendly_message=err_msg)

    @property
    def input_schema(self) -> ColSchema:
        input_schema: ColSchema = {self.field: str}
        if self.pages_field:
            input_schema[self.pages_field] = None
        return input_schema

    def _remove_superscripts(self, df_words: pd.DataFrame) -> pd.DataFrame:
        df_words = df_words.sort_values(by=[PAGE_ID, LINE_ID, LEFT])
        # NOTE: This heuristics should work for most cases. However if a need arises, it should be made
        # a configurable option
        baseline_tolerance = 0.80
        superscript_height = 0.80
        height = df_words[BOTTOM] - df_words[TOP]

        supscript_baseline = df_words[TOP] + (height.shift(1) * baseline_tolerance)

        selector = ~(
            (df_words[LINE_ID] == df_words[LINE_ID].shift(1))
            & (df_words[PAGE_ID] == df_words[PAGE_ID].shift(1))
            & (height < (height.shift(1) * superscript_height))
            & (df_words[BOTTOM] < supscript_baseline)
        )

        df_words = df_words[selector]

        return df_words.reset_index()

    def _parse_pdf(
        self,
        index: Any,
        row_num: int,
        pdf_path: str,
        pdf_pages: Optional[List[int]],
        cache: Dict[int, pd.Series],
    ) -> pd.Series:
        # Create a PDF page aggregator object.
        pages: List[Tuple] = []
        areas: List[Tuple] = []
        pars: List[Tuple] = []
        lines: List[Tuple] = []
        words: List[Tuple] = []

        try:
            # users can specify storage options for the pdf_path
            pdf_path, storage_options = get_path_storage_options(pdf_path)
            with open_file(
                pdf_path, **(storage_options if storage_options else {})
            ) as f:
                start_time = time.time()
                logger.info(f"Parser version: {self.native_pdf_parser_version}")
                native_pdf_parser = NativePDFParser(
                    pdf_path,
                    f,
                    pdf_pages,
                    parser_version=self.native_pdf_parser_version
                    if self.native_pdf_parser_version is not None
                    else LATEST_PARSER_VERSION,
                    extract_pars=self.extract_pars,
                    la_params=self.parser_params,
                )
                logger.info(
                    f"Starting to parse {pdf_path}, ignore_error = {self.ignore_errors}"
                )
                pages, areas, pars, lines, words = native_pdf_parser.parse()
        except Exception as e:
            logger.error(f"Error parsing PDF file {pdf_path}", exc_info=True)
            if not self.ignore_errors:
                err_msg = f"Parser could not parse the PDF file {pdf_path}. Please fix the malformed PDF and try again, or set 'ignore_errors=True' for PDFToRichDocParser to skip this error."
                if isinstance(e, UserInputError):
                    raise OperatorExecutionError(
                        detail=e.detail,
                        user_friendly_message=err_msg + e.user_friendly_message
                        if e.user_friendly_message
                        else "",
                    )
                else:
                    raise OperatorExecutionError(
                        detail=err_msg, user_friendly_message=err_msg
                    )
            else:
                logger.error(f"Error parsing PDF file {pdf_path}", exc_info=True)
                write_skipped_datapoints([index], [str(e)], self.errors_file_path)
                # Returning an empty RichDoc
                return pd.Series(
                    {
                        RichDocCols.TEXT_COL: "",
                        RichDocCols.JSON_COL: "",
                        RichDocCols.PAGE_DOCS: RichDocList([]),
                        RichDocCols.PAGE_CHAR_STARTS: [],
                    }
                )

        logger.info(
            f"Parsing {pdf_path} with index={index} took {time.time() - start_time}s"
        )

        df_pages = pd.DataFrame.from_records(pages, columns=PAGE_COLS, index=PAGE_ID)
        df_areas = pd.DataFrame.from_records(areas, columns=AREA_COLS, index=AREA_ID)
        df_pars = pd.DataFrame.from_records(pars, columns=PAR_COLS, index=PAR_ID)
        df_lines = pd.DataFrame.from_records(lines, columns=LINE_COLS, index=LINE_ID)
        # Since our ints are always positive and small, save space by using smaller types.
        dtypes = {
            **{k: "uint16" for k in BBOX_COLS + [PAGE_ID, AREA_ID, PAR_ID, LINE_ID]},
            **{k: "uint32" for k in [WORD_ID]},
        }
        df_words = (
            pd.DataFrame.from_records(words, columns=WORD_COLS)
            .astype(dtypes)
            .set_index(WORD_ID)
        )

        if self.remove_superscripts:
            df_words = self._remove_superscripts(df_words)

        rd = RichDoc(df_pages, df_areas, df_pars, df_lines, df_words)
        ret_val = self._rich_doc_to_columns(rd)
        if row_num == 0:
            cache[index] = ret_val
        return ret_val

    def estimate_perf(self, df: pd.DataFrame) -> Performance:
        import pdfplumber

        pages = []
        for pdf_file in df.head()[self.field]:
            pdf = pdfplumber.open(pdf_file)
            pages.append(len(pdf.pages))
        avg_pages = np.mean(pages)
        total_pages = avg_pages * len(df)
        return Performance(
            compute_time_secs=total_pages * 1.1, peak_memory_mb=total_pages * 0.4
        )

    def _compute_features(
        self,
        input_df: pd.DataFrame,
        callback: OpProgressCallback = no_op_progress_callback,
    ) -> pd.DataFrame:
        """Override base class method"""
        input_df["row_num"] = np.arange(len(input_df))

        pandas_path_eval_cache: Dict[int, pd.Series] = {}
        ret_val = input_df.apply(
            lambda row: pandas_path_eval_cache[row.name]
            if row.name in pandas_path_eval_cache
            else self._parse_pdf(
                index=row.name,
                row_num=row.row_num,
                pdf_path=row[self.field],
                pdf_pages=row[self.pages_field] if self.pages_field else None,
                cache=pandas_path_eval_cache,
            ),
            axis=1,
        )
        return ret_val

    def get_featurizer_hash(self) -> str:
        return f"{type(self).__name__}_{self.operator_impl_version}_{self.remove_superscripts}_{self.pages_field}"
