from typing import List

import pandas as pd

from snorkelflow.operators.page_splitter import BasePageSplitter
from snorkelflow.rich_docs.rich_doc import RichDocCols
from snorkelflow.types.performance import Performance
from snorkelflow.utils.logging import get_logger

logger = get_logger("PageSplitter")


class PageSplitter(BasePageSplitter):
    """Split PDFs into pages for subsequent filtering and faster processing. Window size specifies the number of consecutive pages before/after the current page to use as a single document for development."""

    WINDOW_SIZE_LIMIT = 5

    def __init__(self, window_size: int = 0) -> None:
        # window_size specifies the size of the page window we fetch
        if not 0 <= window_size <= self.WINDOW_SIZE_LIMIT:
            logger.warning(
                f"The window_size {window_size} should be non-negative and at most {self.WINDOW_SIZE_LIMIT}."
            )

        self.window_size = window_size

    def estimate_perf(self, df: pd.DataFrame) -> Performance:
        avg_words = (
            df[RichDocCols.PAGE_DOCS]
            .head()
            .apply(lambda x: sum([len(y.words) for y in x]))
            .mean()
        )
        total_words = avg_words * len(df)
        return Performance(
            compute_time_secs=len(df) // 15 + total_words * 0.0002,
            peak_memory_mb=5 + total_words * 0.0002,
        )

    def _split_pages(self, row: pd.Series) -> List[List[int]]:
        page_docs = row[RichDocCols.PAGE_DOCS]
        page_nums = list(range(len(page_docs)))
        return [
            page_nums[i : i + self.window_size + 1]
            for i in range(0, len(page_nums), self.window_size + 1)
        ]
