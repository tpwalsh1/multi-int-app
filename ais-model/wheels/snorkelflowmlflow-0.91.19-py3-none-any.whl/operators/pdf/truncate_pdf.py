import os
import subprocess
import tempfile
import time
import uuid
from typing import Optional

import pandas as pd

from api_utils.exceptions import UserInputError
from file_utils.core import copy, open_file
from snorkelflow.operators.featurizer import Featurizer, OpProgressCallback
from snorkelflow.operators.operator import ColSchema, no_op_progress_callback
from snorkelflow.utils.file import get_path_storage_options, resolve_data_path
from snorkelflow.utils.logging import get_logger

logger = get_logger("TruncatePDF")


def truncate_pdf(pdf_path: str, dest_path: str, num_pages: int) -> None:
    """
    From a single pdf, truncates the pdf to a given number of pages.
    Due to NPEs with PDFBox, we restrict the functionality of PDFSplit exposed by this function.
    Using startPage + endPage + split leads to a NPE, but endPage + split does not.
    """
    if num_pages <= 0:
        raise ValueError("Number of pages must greater than 0")

    with tempfile.TemporaryDirectory() as temp_dir:
        local_path = os.path.join(temp_dir, "temp.pdf")
        pdf_path, storage_options = get_path_storage_options(pdf_path)
        with open_file(
            pdf_path, **(storage_options if storage_options else {})
        ) as read_file, open(local_path, "wb") as write_file:
            while True:
                chunk_size = 1024 * 1024  # 1MB
                chunk = read_file.read(chunk_size)
                if not chunk:
                    break
                write_file.write(chunk)
        command = [
            "java",
            "-Djava.awt.headless=true",
            "-jar",
            "/usr/local/bin/pdfbox.jar",
            "PDFSplit",
            local_path,
            "-endPage",
            str(num_pages),
            "-split",
            str(num_pages),
            "-outputPrefix",
            os.path.join(temp_dir, "truncated"),
        ]
        subprocess.run(command, check=True)

        truncated_pdf_path = os.path.join(temp_dir, "truncated-1.pdf")
        if not os.path.exists(truncated_pdf_path):
            raise ValueError("Unabled to truncate PDF, no output file found")
        os.makedirs(os.path.dirname(resolve_data_path(dest_path)), exist_ok=True)
        copy(truncated_pdf_path, dest_path)


class TruncatePDF(Featurizer):
    """
    Truncates a PDF to a certain # of pages.

    Truncates a given column of pdf urls to a certain # of pages and write the paths to the truncated pdfs to a new column.
    This will work for native and scanned PDFs.

    Parameters
    ----------
    field: str
        The field you want to truncate
    pdf_storage_dir: str
        The directory to store the truncated pdfs in
    target_field: str
        The field you want to write the truncated PDF paths to
    pages: int
        The number of pages to truncate to
    ignore_errors : bool, optional
        Whether to ignore errors when parsing the PDF documents. If True, the original PDF documents will be written to the target column even if there are errors during truncation.
    """

    def __init__(
        self,
        field: str,
        pdf_storage_dir: str,
        target_field: Optional[str] = None,
        pages: int = 5,
        ignore_errors: bool = False,
    ) -> None:
        self.field = field
        self.target_field = target_field or f"{field}_truncated"
        self.pdf_storage_dir = pdf_storage_dir
        if pages <= 0:
            err_msg = f"Pages input in TruncatePreprocessor must be > 0, found {pages}"
            raise UserInputError(detail=err_msg, user_friendly_message=err_msg)
        self.pages = pages
        self.ignore_errors = ignore_errors

    @property
    def input_schema(self) -> ColSchema:
        return {self.field: str}

    @property
    def output_schema(self) -> ColSchema:
        return {self.target_field: str}

    def _compute_features(
        self, df: pd.DataFrame, callback: OpProgressCallback = no_op_progress_callback
    ) -> pd.DataFrame:
        # go over each row in the dataframe and truncate the pdfs via pdfbox, write to new location
        truncated_pdfs = []
        for _, row in df.iterrows():
            pdf_path = row[self.field]
            pdf_file_name = os.path.basename(pdf_path)
            dest_path = os.path.join(
                self.pdf_storage_dir, str(uuid.uuid4()), f"truncated_{pdf_file_name}"
            )
            try:
                start_time = time.time()
                truncate_pdf(pdf_path, dest_path, self.pages)
                end_time = time.time()
                logger.info(f"Truncated pdf {pdf_path=} in {end_time - start_time}s")
                truncated_pdfs.append(dest_path)
            except Exception as e:
                if self.ignore_errors:
                    truncated_pdfs.append(pdf_path)
                    logger.warning(
                        f"Error truncating PDF {pdf_path}, returning original PDF",
                        exc_info=True,
                    )
                else:
                    raise e
        df[self.target_field] = truncated_pdfs
        return df
