import logging
import os
import shutil
import tempfile
import time
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

from file_utils.core import open_file
from snorkelflow.operators.featurizer import Featurizer, OpProgressCallback
from snorkelflow.operators.operator import ColSchema, no_op_progress_callback
from snorkelflow.rich_docs import BOTTOM, LEFT, RIGHT, TOP, HVLines, RichDocCols
from snorkelflow.rich_docs.rich_doc_utils import convert_pdf_to_image
from snorkelflow.types.performance import Performance
from snorkelflow.utils.file import get_path_storage_options
from snorkelflow.utils.logging import get_logger

logger = get_logger("HocrParser")


class LinesFeaturizer(Featurizer):
    """
    A featurizer that identifies horizontal and vertical lines in PDF documents.

    The operator uses Erosion + Dilation, one of the common techniques to identify
    horizontal / veritical lines in an image.

    Parameters
    ----------
    field
        The name of the column containing the PDF file paths.
    min_length_px
      The minimum length (in pixels) of a line to be considered valid. Defaults to 21.
    num_pages_per_batch
        The number of pages to process in each batch. Defaults to 100.
    pages_field
        The name of the column containing the page numbers on which to run the operator on. Defaults to RichDocCols.CONTEXT_PAGES.

    Returns
    -------
    {RichDocCols.HV_LINES}
        A HVLines object containing the horizontal and vertical lines.

    """

    # The operator uses Erosion + Dilation, one of the common techniques to identify
    # horizontal / veritical lines in an image.
    # Code from : https://github.com/Psarpei/Multi-Type-TD-TSR (MIT License)
    # And From Camelot : https://github.com/camelot-dev/camelot/blob/master/camelot/image_processing.py

    is_expensive = True

    def __init__(
        self,
        field: str,
        min_length_px: int = 21,
        num_pages_per_batch: int = 100,
        pages_field: Optional[str] = RichDocCols.CONTEXT_PAGES,
    ):
        # field currently means pdf path. If pdf to image conversion is too slow,
        # we could add another option to have field mean images path instead.
        self.field: str = field
        self.min_length_px: int = min_length_px
        self.num_pages_per_batch: int = num_pages_per_batch
        self.pages_field = pages_field

    @property
    def input_schema(self) -> ColSchema:
        return {self.field: str}

    @property
    def output_schema(self) -> ColSchema:
        return {RichDocCols.HV_LINES: None}

    def estimate_perf(self, df: pd.DataFrame) -> Performance:
        import pdfplumber

        pages = []
        for pdf_file in df.head()[self.field]:
            pdf = pdfplumber.open(pdf_file)
            pages.append(len(pdf.pages))
        avg_pages = np.mean(pages)
        total_pages = avg_pages * len(df)
        return Performance(
            compute_time_secs=total_pages * 3, peak_memory_mb=total_pages * 5
        )

    def _get_lines_from_image(
        self, image_bytes: np.ndarray
    ) -> Tuple[pd.DataFrame, pd.DataFrame]:
        # Inline import to avoid dependency when this operator is not being used.
        import cv2

        img = cv2.imdecode(image_bytes, cv2.IMREAD_GRAYSCALE)
        img_height, img_width = img.shape

        # Thresholding the image to a binary image
        img_bin = cv2.adaptiveThreshold(
            img, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 5, 5
        )

        # Inverting the image
        img_bin = 255 - img_bin

        kernel_len_ver = img_height // 50
        kernel_len_hor = img_width // 50

        # Defining a vertical kernel to detect all vertical lines of image
        ver_kernel = cv2.getStructuringElement(
            cv2.MORPH_RECT, (1, kernel_len_ver)
        )  # shape (kernel_len, 1) inverted! xD

        # Defining a horizontal kernel to detect all horizontal lines of image
        hor_kernel = cv2.getStructuringElement(
            cv2.MORPH_RECT, (kernel_len_hor, 1)
        )  # shape (1,kernel_ken) xD

        # Use vertical kernel to detect and save the vertical lines
        image_vertical = cv2.erode(img_bin, ver_kernel, iterations=1)
        vertical_lines = cv2.dilate(image_vertical, ver_kernel, iterations=1)
        # Use horizontal kernel to detect and save the horizontal lines
        image_horizontal = cv2.erode(img_bin, hor_kernel, iterations=1)
        horizontal_lines = cv2.dilate(image_horizontal, hor_kernel, iterations=1)

        contours, _ = cv2.findContours(
            horizontal_lines, cv2.RETR_CCOMP, cv2.CHAIN_APPROX_SIMPLE
        )

        horizontal_line_coords = []
        for c in contours:
            x, y, w, h = cv2.boundingRect(c)
            x1, x2 = x, x + w
            y1, y2 = y, y + h

            if x2 - x1 < self.min_length_px:
                continue
            horizontal_line_coords.append((x1, (y1 + y2) // 2, x2, (y1 + y2) // 2))
        df_horz = pd.DataFrame(
            horizontal_line_coords, columns=[LEFT, TOP, RIGHT, BOTTOM]
        ).sort_values(by=TOP)

        contours, _ = cv2.findContours(
            vertical_lines, cv2.RETR_CCOMP, cv2.CHAIN_APPROX_SIMPLE
        )
        vertical_line_coords = []
        for c in contours:
            x, y, w, h = cv2.boundingRect(c)
            x1, x2 = x, x + w
            y1, y2 = y, y + h

            if y2 - y1 < self.min_length_px:
                continue
            vertical_line_coords.append(((x1 + x2) // 2, y2, (x1 + x2) // 2, y1))

        df_vert = pd.DataFrame(
            vertical_line_coords, columns=[LEFT, TOP, RIGHT, BOTTOM]
        ).sort_values(by=LEFT)

        return df_horz, df_vert

    def _get_lines_from_pdf_pages(
        self, pdf_path: str, start_page: int, end_page: int
    ) -> Tuple[List[pd.DataFrame], List[pd.DataFrame]]:
        """
        Converts the given page number to image. It then identifies the
        Horizontal and vertical lines for that image
        """
        dfs_horz: List[pd.DataFrame] = []
        dfs_vert: List[pd.DataFrame] = []

        try:
            with convert_pdf_to_image(
                pdf_path,
                dpi=300,
                start_page=start_page,
                end_page=end_page,
                grayscale=True,
                format="png",
            ) as img_dir:
                for i in range(start_page, end_page + 1):
                    img_path = os.path.join(img_dir, f"{i}.png")
                    with open(img_path, "rb") as img_stream:
                        image = np.asarray(bytearray(img_stream.read()), dtype=np.uint8)
                        df_horz, df_vert = self._get_lines_from_image(image)
                        dfs_horz.append(df_horz)
                        dfs_vert.append(df_vert)

            return dfs_horz, dfs_vert
        except Exception as e:
            logging.error(str(e))
            # Add empty dataframes
            empty_df = pd.DataFrame([], columns=[LEFT, TOP, RIGHT, BOTTOM]) * (
                end_page - start_page + 1
            )
            return empty_df, empty_df

    def _get_batched_ranges(
        self, pages: List[int], batch_size: int
    ) -> List[List[Tuple[int, int]]]:
        def pages_to_ranges(pages: List[int]) -> List[Tuple[int, int]]:
            if not pages:
                return []

            sorted_pages = sorted(set(pages))
            start = sorted_pages[0]
            end = sorted_pages[0]
            ranges = []

            for page in sorted_pages[1:]:
                if page == end + 1:
                    end = page
                else:
                    ranges.append((start, end))
                    start = end = page
            ranges.append((start, end))

            return ranges

        ranges = pages_to_ranges(pages)

        batched = []
        current_batch = []
        current_batch_size = 0

        for r in ranges:
            start, end = r
            while start <= end:
                remaining_in_batch = batch_size - current_batch_size
                if (end - start) < remaining_in_batch:
                    current_end = end
                else:
                    current_end = start + remaining_in_batch - 1

                current_batch.append((start, current_end))
                current_batch_size += current_end - start + 1

                if current_batch_size == batch_size:
                    batched.append(current_batch)
                    current_batch = []
                    current_batch_size = 0

                start = current_end + 1

        if current_batch:
            batched.append(current_batch)

        return batched

    def _add_lines(
        self,
        pdf_path: str,
        index: Any,
        row_num: int,
        cache: Dict[int, pd.Series],
        pages: List[int],
    ) -> pd.Series:
        import pdfplumber

        # Note that we should use the same resolution (pixels per inch) for this operator and
        # parser so the lines can be matched up with word bboxes.
        dfs_horz: List[pd.DataFrame] = []
        dfs_vert: List[pd.DataFrame] = []
        start_time = time.time()
        # Copy the pdf file to the temporary file directory
        with tempfile.TemporaryDirectory() as tmp_dir:
            file_name = os.path.split(pdf_path)[-1]
            dest_file = os.path.join(tmp_dir, file_name)
            # Copy the file to tmpfs. We'll then use the copied file to convert to
            # image
            pdf_url, storage_options = get_path_storage_options(pdf_path)
            with open_file(
                pdf_url, "rb", **(storage_options if storage_options else {})
            ) as src_f, open(dest_file, "wb") as dest_f:
                shutil.copyfileobj(src_f, dest_f)
                pdf = pdfplumber.open(src_f)
                num_pages = len(pdf.pages)

            if pages is not None:
                batched_ranges = self._get_batched_ranges(
                    pages, self.num_pages_per_batch
                )
                for batch in batched_ranges:
                    for start_page, end_page in batch:
                        start_page += 1
                        end_page += 1
                        logger.info(
                            f"Detecting lines for pages {start_page} - {end_page}"
                        )
                        df_horz_batch, df_vert_batch = self._get_lines_from_pdf_pages(
                            pdf_path=dest_file, start_page=start_page, end_page=end_page
                        )
                        dfs_horz.extend(df_horz_batch)
                        dfs_vert.extend(df_vert_batch)

            else:
                for page_num in range(0, num_pages, self.num_pages_per_batch):
                    start_page = page_num + 1
                    end_page = min(num_pages, page_num + self.num_pages_per_batch)
                    logger.info(f"Detecting lines for pages {start_page} - {end_page}")
                    df_horz_batch, df_vert_batch = self._get_lines_from_pdf_pages(
                        pdf_path=dest_file, start_page=start_page, end_page=end_page
                    )
                    dfs_horz.extend(df_horz_batch)
                    dfs_vert.extend(df_vert_batch)

        hv_lines = HVLines(dfs_horz, dfs_vert)
        logger.info(
            f"LinesFeaturizer took {time.time() - start_time} for pdf={pdf_path}, index={index}"
        )
        ret_val = pd.Series({RichDocCols.HV_LINES: hv_lines})
        if row_num == 0:
            cache[index] = ret_val
        return ret_val

    def _compute_features(
        self,
        input_df: pd.DataFrame,
        callback: OpProgressCallback = no_op_progress_callback,
    ) -> pd.DataFrame:
        """Override base class method"""
        input_df["row_num"] = np.arange(len(input_df))
        pandas_path_eval_cache: Dict[int, pd.Series] = {}
        ret_val = input_df.apply(
            lambda row: pandas_path_eval_cache[row.name]
            if row.name in pandas_path_eval_cache
            else self._add_lines(
                pdf_path=row[self.field],
                index=row.name,
                row_num=row.row_num,
                cache=pandas_path_eval_cache,
                pages=row.get(self.pages_field) if self.pages_field else None,
            ),
            axis=1,
        )
        return ret_val


class LinesPageFilterFeaturizer(Featurizer):
    """Operator that filters horizontal and vertical lines to subset of pages."""

    def __init__(self, pages_field: str):
        self.pages_field = pages_field

    @property
    def input_schema(self) -> ColSchema:
        return {RichDocCols.HV_LINES: None, self.pages_field: None}

    @property
    def output_schema(self) -> ColSchema:
        return {RichDocCols.HV_LINES: None}

    def _per_row(self, row: pd.Series) -> HVLines:
        pages = row[self.pages_field]
        hv_lines = row[RichDocCols.HV_LINES]
        return HVLines(
            dfs_horz=[hv_lines.dfs_horz[i] for i in pages],
            dfs_vert=[hv_lines.dfs_vert[i] for i in pages],
        )

    def _compute_features(
        self,
        input_df: pd.DataFrame,
        callback: OpProgressCallback = no_op_progress_callback,
    ) -> pd.DataFrame:
        """Override base class method"""
        input_df[RichDocCols.HV_LINES] = input_df.apply(self._per_row, axis=1)
        return input_df
