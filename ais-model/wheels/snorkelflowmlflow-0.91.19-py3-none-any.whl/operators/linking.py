import itertools

import pandas as pd

from snorkelflow.operators.operator import ColSchema, Operator
from snorkelflow.utils.logging import get_logger

logger = get_logger("EntityLinkingCrossproductCandidateGenerator")


class EntityLinkingCrossproductCandidateGenerator(Operator):
    """Generates new records using the crossproduct of unique values found in two columns of a DataFrame."""

    def __init__(self, candidate_column_1: str, candidate_column_2: str) -> None:
        self.col_1 = candidate_column_1
        self.col_2 = candidate_column_2

    @property
    def input_schema(self) -> ColSchema:
        return {self.col_1: None, self.col_2: None}

    @property
    def output_schema(self) -> ColSchema:
        return {self.col_1: None, self.col_2: None}

    def _execute_pandas(self, input_df: pd.DataFrame) -> pd.DataFrame:
        uniq_candidates_1 = input_df[self.col_1].dropna().unique().tolist()
        uniq_candidates_2 = input_df[self.col_2].dropna().unique().tolist()
        return pd.DataFrame(
            itertools.product(uniq_candidates_1, uniq_candidates_2),
            columns=[self.col_1, self.col_2],
        )
