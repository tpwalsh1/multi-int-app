from typing import List

from dask import dataframe as dd

from snorkelflow.operators.operator import Operator
from snorkelflow.serialization.code_asset import deserialize_asset


class CodeProcessor(Operator):
    """Processor that runs a dilled function."""

    is_deprecated: bool = True
    input_schema = None
    output_schema = None

    def __init__(self, code_b64: str) -> None:
        self._postprocess_func = deserialize_asset(code_b64)

    def _execute(self, input_ddfs: List[dd.DataFrame]) -> dd.DataFrame:
        """Override base class method"""
        ddf = input_ddfs[0]
        return self._postprocess_func(ddf)
