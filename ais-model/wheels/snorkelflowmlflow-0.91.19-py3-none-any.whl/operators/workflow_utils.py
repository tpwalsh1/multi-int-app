import base64
import hashlib
import itertools
import os
import pickle
from collections import deque
from typing import Any, Dict, List, Optional
from uuid import uuid4

from dask import dataframe as dd

from file_utils.core import glob_fsspec_path
from snorkelflow.models.cls_model import TrainedClassificationModelV2
from snorkelflow.types.load import ARROW_META_FILENAME, PICKLE_META_FILENAME, SourceType
from snorkelflow.types.workflows import INPUT_NODE_ID, OperatorId, WorkflowConfig
from snorkelflow.utils.file import resolve_data_path
from snorkelflow.utils.logging import get_logger
from snorkelflow.utils.pickle import to_pickle
from snorkelflow.workflows.graph_utils import get_workflow_output_ids

# Initialize Logger
logger = get_logger("workflow_utils")

OpIdToPath = Dict[OperatorId, str]
OpIdToColTypes = Dict[OperatorId, Optional[Dict[str, str]]]

# This a cache used to preload and store the workflow exectuion resource
# This is currently only used in Workflow server
resources_cache: Dict[str, TrainedClassificationModelV2] = {}


def get_top_sorted_worklow_subgraph(
    workflow_config: WorkflowConfig,
    targets: List[OperatorId],
    sources: Optional[List[OperatorId]] = None,
    are_targets_leafs: bool = False,
) -> WorkflowConfig:
    """Given a list of targets op ids to compute, and a list of sources
    for which ddfs are already available, use backward search to determine
    the minimal workflow_config of ops that need to be computed plus sources.
    """
    if sources is None:
        sources = [INPUT_NODE_ID]
    to_visit = deque(targets)
    visited = {}  # dicts preserve insertion order, while sets don't
    while to_visit:
        x = to_visit.popleft()
        visited[x] = True
        if x in sources:
            continue
        for input_id in workflow_config[x].input_ids:
            if input_id not in visited:
                to_visit.append(input_id)
    if len(targets) > 1 and not are_targets_leafs:
        # Because targets could contain multiple operators ids, some of which are
        # ancestors of others, the topological order might not be correct if we just
        # use the order of visiting nodes.
        # Example: 1 => 2 => 3, targets=[3, 2]
        # To figure out the topological order, we do another doing another backwards search
        # starting from operators that aren't inputs to other operators in the subgraph.
        input_op_ids = itertools.chain(
            *[
                workflow_config[x].input_ids
                for x in visited.keys()
                if x in workflow_config
            ]
        )
        leaf_op_ids = [x for x in visited if x not in input_op_ids]
        return get_top_sorted_worklow_subgraph(
            workflow_config, leaf_op_ids, sources, are_targets_leafs=True
        )
    return {
        x: workflow_config[x] for x in reversed(visited.keys()) if x in workflow_config
    }


def get_ddf_storage_path(storage_dir: str) -> str:
    """Returns a path that's not currently used in the storage_dir"""
    resolved_dir = resolve_data_path(storage_dir)
    files_in_dir = glob_fsspec_path(f"{resolved_dir}/*")
    for _ in range(25):
        file_name = "".join(str(uuid4().int)[-12:])
        if not any(x.endswith(file_name) for x in files_in_dir):
            return os.path.join(storage_dir, file_name)
    raise ValueError("Failed to find available folder to store dataframe")


def get_workflow_hash(
    workflow_config: WorkflowConfig, op_id: Optional[OperatorId] = None
) -> str:
    """Returns a unique and deterministic hash for the workflow up to the op_id"""
    targets = get_workflow_output_ids(workflow_config) if op_id is None else [op_id]
    subgraph_workflow_config = get_top_sorted_worklow_subgraph(workflow_config, targets)
    workflow_id = ""
    for op_config in subgraph_workflow_config.values():
        workflow_id += op_config.op_type
        sorted_config = {k: v for k, v in sorted(op_config.op_config.items())}
        workflow_id += base64.b64encode(pickle.dumps(sorted_config)).decode()
        workflow_id += str(op_config.op_impl_version)
        workflow_id += str(len(op_config.input_ids))
    return hashlib.md5(workflow_id.encode("utf-8")).hexdigest()


def store_ddf_to_path(
    ddf: dd.DataFrame, path: str, source_type: SourceType
) -> List[Any]:
    if source_type == SourceType.PICKLE:
        return [to_pickle(ddf, path, compute=False)]
    else:
        # import here to avoid circular import due to data.core importing operators.loadprocess
        from snorkelflow.data.core import maybe_serialize_cols_and_save_ddf

        # shallow copy to prevent modifications (like adding column types)
        ddf = ddf.copy()
        return maybe_serialize_cols_and_save_ddf(
            ddf, source_type, path, coerce_object_as_category=True
        )


def get_ddf_storage_type(path: str) -> SourceType:
    # Intermediate dataframes are stored as pickle, while ddfs loaded from outside
    # the workflow are stored in parquet format. However, an output ddf can become
    # intermediate ddf (e.g. when we add a new operator to the DAG). Because of this,
    # we infer the stored ddf type.
    resolved_data_path = resolve_data_path(path)
    if resolved_data_path.endswith("/"):
        resolved_data_path = resolved_data_path[:-1]
    files_in_dir = glob_fsspec_path(f"{resolved_data_path}/*")
    if any(x.endswith(PICKLE_META_FILENAME) for x in files_in_dir):
        return SourceType.PICKLE
    if any(x.endswith(ARROW_META_FILENAME) for x in files_in_dir):
        return SourceType.ARROW_IPC
    elif any(x.endswith("_metadata") for x in files_in_dir):
        return SourceType.PARQUET
    else:
        raise ValueError(f"Failed to infer storage type for {resolved_data_path=}")
