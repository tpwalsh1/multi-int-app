import hashlib
import os
import pickle
from typing import Any, Dict, List, Optional
from uuid import uuid4

import pandas as pd
import scipy as sp
from sklearn.feature_extraction.text import (
    CountVectorizer,
    HashingVectorizer,
    TfidfVectorizer,
)

from snorkelflow.models.sklearn import is_text_series
from snorkelflow.operators.featurizer import Featurizer, OpProgressCallback
from snorkelflow.operators.operator import (
    ARTIFACTS_BASE_PATH,
    ColSchema,
    no_op_progress_callback,
)
from snorkelflow.utils.file import resolve_data_path
from snorkelflow.utils.logging import get_logger

logger = get_logger("Operator")


class SklearnTextFeaturizer(Featurizer):
    text_vectorizers_name_to_cls = {
        "CountVectorizer": CountVectorizer,
        "HashingVectorizer": HashingVectorizer,
        "TfidfVectorizer": TfidfVectorizer,
    }
    artifact_config_keys: List[str] = ["vectorizer_path"]
    operator_impl_version = 2

    def __init__(
        self,
        vectorizer_path: Optional[str],
        field: str,
        target_field: Optional[str] = None,
    ) -> None:
        self.vectorizer_path = vectorizer_path
        self.field = field
        self.target_field = target_field or f"{field}_vector"

    @classmethod
    def _fit(  # type: ignore
        cls,
        df: pd.DataFrame,
        vectorizer_cls: str,
        field: str,
        target_field: Optional[str] = None,
        vectorizer_kwargs: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        if vectorizer_cls not in cls.text_vectorizers_name_to_cls:
            raise ValueError(
                f"vectorizer_cls should be one of {cls.text_vectorizers_name_to_cls}"
            )

        if field not in df.columns:
            raise RuntimeError(
                f"Source column {field} not present in input dataframe columns {df.columns}"
            )

        if not is_text_series(df[field]):
            raise RuntimeError(f"Source column {field} is not a text column")

        if (
            vectorizer_kwargs
            and "ngram_range" in vectorizer_kwargs
            and not isinstance(vectorizer_kwargs["ngram_range"], tuple)
        ):
            # scikit-learn 1.2.0 requires ngram_range to be a tuple
            vectorizer_kwargs["ngram_range"] = tuple(vectorizer_kwargs["ngram_range"])
        vectorizer = cls.text_vectorizers_name_to_cls[vectorizer_cls](
            **(vectorizer_kwargs if vectorizer_kwargs is not None else {})
        )
        if vectorizer_kwargs and "ngram_range" in vectorizer_kwargs:
            vectorizer_kwargs["ngram_range"] = list(vectorizer_kwargs["ngram_range"])

        vectorizer_path: Optional[str] = None
        try:
            vectorizer = vectorizer.fit(df[field].fillna("nan"))
            vectorizer_path = resolve_data_path(
                os.path.join(ARTIFACTS_BASE_PATH, str(uuid4()))
            )
            assert vectorizer_path  # mypy
            os.makedirs(os.path.dirname(vectorizer_path), exist_ok=True)
            with open(vectorizer_path, "wb") as f:
                pickle.dump(vectorizer, f)
        except ValueError as e:
            if "empty vocabulary" in str(e):
                logger.warning(
                    f"Empty vocabulary for field {field}. Using constant vector."
                )
                vectorizer_path = None
            else:
                raise e
        return {
            "vectorizer_path": vectorizer_path,
            "field": field,
            "target_field": target_field,
        }

    @classmethod
    def _fit_input_schema(  # type: ignore
        cls,
        vectorizer_cls: str,
        field: str,
        target_field: Optional[str] = None,
        vectorizer_kwargs: Optional[Dict[str, Any]] = None,
    ) -> ColSchema:
        return {field: str}

    @property
    def input_schema(self) -> ColSchema:
        return {self.field: str}

    @property
    def output_schema(self) -> ColSchema:
        return {self.target_field: None}

    def _compute_features(
        self,
        input_df: pd.DataFrame,
        callback: OpProgressCallback = no_op_progress_callback,
    ) -> pd.DataFrame:
        """Override base class method"""
        if not is_text_series(input_df[self.field]):
            raise RuntimeError(f"Source column {self.field} is not a text column")
        if self.vectorizer_path is None:
            result = [sp.sparse.csr_matrix([1]) for _ in range(len(input_df))]
        else:
            with open(resolve_data_path(self.vectorizer_path), "rb") as f:
                self.vectorizer = pickle.load(f)
            result = self.vectorizer.transform(input_df[self.field].fillna("").values)
        return input_df.assign(**{self.target_field: list(result)})

    def get_featurizer_hash(self) -> str:
        hash_str = (
            type(self).__name__
            + str(self.operator_impl_version)
            + str(self.vectorizer_path)
        )
        hash = hashlib.md5(hash_str.encode("utf-8")).hexdigest()
        return hash
