# This is a top-level file for the operators package. To prevent circular top-level imports, this
# file imports from all files in operators/ but not vice-versa. We make it an explicit file instead of
# __init__.py because pytest doesn't execute the __init__.py by default.
import importlib
import json
import os
from abc import ABC, ABCMeta
from copy import deepcopy
from typing import Any, Dict, List, Optional

from docstring_parser import parse
from pydantic import BaseModel

from api_utils.exceptions import UserInputError
from operators.post_processors.model_post_processor import ModelPostProcessor
from operators.utils import get_field_configs_from_cls, get_fit_configs_from_cls
from snorkelflow.operators import featurizer, operator
from snorkelflow.operators.candidates import SpanExtractor, SpanNormalizer, SpanReducer
from snorkelflow.operators.fixed_datapoint import Filter
from snorkelflow.operators.udf import (
    UserDefinedOperator,
    get_udf_class,
    get_user_defined_operator,
    is_user_defined,
)
from snorkelflow.plugin_utils import find_all_modules
from snorkelflow.serialization.code_asset import deserialize_asset, recompile_operator
from snorkelflow.types.workflows import OperatorInitConfig
from snorkelflow.utils.logging import get_logger

logger = get_logger("Operators")

try:
    from psycopg2 import OperationalError
    from psycopg2.extensions import connection
except ModuleNotFoundError:
    # In testing
    logger.debug(
        "Cannot connect to database, user defined operator classes will not be available"
    )
    connection = None
    OperationalError = None


# Dynamically look for optional imports
try:
    from .candidates import rich_doc_features  # noqa: F401
except ImportError:
    logger.debug("Skipping rich_doc_features registration")

AUTHORIZATION_ON = True
try:
    from authorization.auth_types import AuthorizeStatus
    from authorization.authorization_common import check_user_authorization
    from authorization.authorization_context import get_authorization_context
    from operators.udf_class_store import fetch_operator_classes
except ImportError:
    AUTHORIZATION_ON = False
    logger.debug(
        "Skipping authorization. User defined operator classes will not be available"
    )


all_operator_modules = find_all_modules(os.path.dirname(__file__), "operators.")
for module in all_operator_modules:
    logger.debug(f"Importing module {module}")
    try:
        importlib.import_module(module)
    except ImportError as e:
        logger.debug(f"Skipping import for {module} due to error: {e}", exc_info=False)


class OperatorNotFoundException(ValueError):
    pass


class MissingOperatorParamException(ValueError):
    pass


class UserDefinedOperatorConfig(BaseModel):
    op_type: str
    op_config: Dict[str, Any]


def get_operator_class(
    cls_name: str, conn: Optional[connection] = None, cls_asset: Optional[str] = None
) -> Any:
    # When running in a deployment, we can't get the class from the database and will
    # instead deserialize it directly from the asset field
    # When running in the platform, the cls_asset field will be null and we will look for
    # the cls_name from the operator classes defined in the database
    if cls_asset is not None:
        # Deserialize the asset
        operator_cls = deserialize_asset(cls_asset)
        return operator_cls

    if cls_name in operator.operators_dict:
        return operator.operators_dict[cls_name]
    elif cls_name in operator.prediction_ops_dict:
        return operator.prediction_ops_dict[cls_name]
    if AUTHORIZATION_ON:
        try:
            # During inference, this will fail due to no database access
            # Prevent this AssertionError from raising and instead have this
            # be reported as an OperatorNotFoundError below
            auth_resp = check_user_authorization(conn)
        except Exception:
            logger.warn(
                (
                    f"Unable to find cls_name {cls_name} in operators dict {operator.operators_dict} or in prediction dict {operator.prediction_ops_dict} and no database connection "
                    f"available to look up user-defined operators"
                ),
                exc_info=True,
            )
            auth_resp = None
        if auth_resp and auth_resp.authorize_status == AuthorizeStatus.AUTHORIZED:
            auth_ctx = get_authorization_context()
            assert auth_ctx  # for mypy. if authorized, auth_ctx is set
            udf_classes = {}
            if auth_ctx.workspace_uid is None:
                logger.warn("workspace is not set. Not able to access UDF classes")
            else:
                udf_classes = fetch_operator_classes(auth_ctx.workspace_uid, conn)
            if (
                auth_ctx.workspace_uid not in udf_classes
                or cls_name not in udf_classes[auth_ctx.workspace_uid]
            ):
                raise OperatorNotFoundException(
                    f"Operator class not found: {cls_name}."
                )
            return udf_classes[auth_ctx.workspace_uid][cls_name]
        elif auth_resp and get_authorization_context() is None:
            import traceback

            stacktrace = traceback.format_exc()
            # log the stacktrace in case we miss some APIs where authorization is needed
            logger.warn(
                f"authorization failed. authorization context is not set. stacktrace: {stacktrace}"
            )
    # if auth not enabled or not authorized
    raise OperatorNotFoundException(
        f"Operator class not found: {cls_name}. If it is a built-in operator, ensure the definition is made available as a plugin."
        " If it is a custom operator, ensure you're running in an environment where a database connection is available."
    )


# workspace_uid starts at 1
BUILTIN_DICT_KEY = 0


# function used to fetch all and filtering
def get_operator_classes(
    conn: Optional[connection] = None, workspace_uid: Optional[int] = None
) -> Dict[int, Dict[str, Any]]:
    ret = {BUILTIN_DICT_KEY: deepcopy(operator.operators_dict)}
    if AUTHORIZATION_ON:
        udf_classes = fetch_operator_classes(workspace_uid=workspace_uid, conn=conn)
        ret.update(udf_classes)
    return ret


def _update_kwargs(cls_kwargs: Dict[str, Any], kwarg_param: str) -> Dict[str, Any]:
    # modify cls_kwargs to populate fields from kwargs. Create a copy before populating
    local_cls_kwargs = deepcopy(cls_kwargs)
    try:
        # convert dict wrapped in string to dict
        kwarg_dict = json.loads(local_cls_kwargs[kwarg_param])
    except Exception as e:
        error_msg = f"Error occurred while processing {kwarg_param} input. Expected valid dictionary, but found {local_cls_kwargs[kwarg_param]}."
        raise UserInputError(
            detail=error_msg + f" Error : {str(e)}", user_friendly_message=error_msg
        )
    local_cls_kwargs.update(kwarg_dict)
    # remove kwarg from local_cls_kwargs
    del local_cls_kwargs[kwarg_param]
    return local_cls_kwargs


def validate_and_init(
    operator_cls: ABCMeta, cls_kwargs: Optional[Dict[str, Any]] = None
) -> operator.Operator:
    if cls_kwargs is None:
        return operator_cls()

    inputs = get_field_configs_from_cls(operator_cls)
    required_fields = {item["input_name"] for item in inputs if not item["is_optional"]}
    kwarg_params = [item["input_name"] for item in inputs if item["is_kwarg"]]
    for required_field in required_fields:
        # when cls_kwargs is None or required_field not in cls_kwags
        # the potential error will be handled by the operator's constructor
        if required_field in cls_kwargs and cls_kwargs[required_field] is None:
            raise MissingOperatorParamException(f"{required_field} must be set.")

    if len(kwarg_params) > 0:
        assert len(kwarg_params) == 1  # mypy
        kwarg_param = kwarg_params[0]
        if kwarg_param in cls_kwargs:
            local_cls_kwargs = _update_kwargs(cls_kwargs, kwarg_param)
            return operator_cls(**local_cls_kwargs)

    return operator_cls(**cls_kwargs)


def init_operator_class(
    cls_name: str,
    cls_kwargs: Optional[Dict[str, Any]] = None,
    cls_asset: Optional[str] = None,
) -> operator.Operator:
    if is_user_defined(cls_name):
        if not cls_kwargs or "cls" not in cls_kwargs or "config" not in cls_kwargs:
            raise ValueError(
                f"{cls_name} operators must include cls, config. Found {cls_kwargs}"
            )
        op_config = cls_kwargs["config"]
        if "code" in cls_kwargs:
            # Make sure it is compilable but don't actually recompile it. Recompiling is done only when fetching one from DB.
            code = cls_kwargs["code"]
            recompile_operator(op_config, code)
        return get_user_defined_operator(cls_kwargs["cls"], op_config)

    else:
        operator_cls = get_operator_class(cls_name, cls_asset=cls_asset)
        return validate_and_init(operator_cls, cls_kwargs)


def init_operator_class_init_config(
    operator_init_config: OperatorInitConfig,
) -> operator.Operator:
    return init_operator_class(
        operator_init_config.op_type,
        operator_init_config.op_config,
        operator_init_config.op_asset,
    )


def init_featurizer_class(
    cls_name: str,
    cls_kwargs: Optional[Dict[str, Any]] = None,
    cls_asset: Optional[str] = None,
) -> featurizer.Featurizer:
    featurizer_instance = init_operator_class(cls_name, cls_kwargs, cls_asset)
    if not isinstance(featurizer_instance, featurizer.Featurizer):
        raise ValueError(f"{cls_name} is not a Featurizer")
    return featurizer_instance


def get_operator_or_udf(
    cls_name: Optional[str], config: Optional[UserDefinedOperatorConfig]
) -> Optional[operator.Operator]:
    if cls_name is not None:
        return init_operator_class(cls_name)
    elif config is not None:
        return get_user_defined_operator(config.op_type, config.op_config)
    return None


def is_extractor(cls_name: str, config: Optional[Dict[str, Any]]) -> bool:
    if is_user_defined(cls_name):
        if config is None or "cls" not in config:
            raise ValueError(f"UserDefinedOperator kwargs must have cls key")
        return issubclass(get_udf_class(config["cls"]), SpanExtractor)
    return issubclass(get_operator_class(cls_name), SpanExtractor)


def is_normalizer(cls_name: str, config: Optional[Dict[str, Any]]) -> bool:
    if is_user_defined(cls_name):
        if config is None or "cls" not in config:
            raise ValueError(f"UserDefinedOperator kwargs must have cls key")
        return issubclass(get_udf_class(config["cls"]), SpanNormalizer)
    return issubclass(get_operator_class(cls_name), SpanNormalizer)


def is_filter(cls_name: str) -> bool:
    return issubclass(get_operator_class(cls_name), Filter)


def is_model_post_processor(cls_name: str) -> bool:
    return issubclass(get_operator_class(cls_name), ModelPostProcessor)


def is_featurizer(cls_name: str, config: Optional[Dict[str, Any]]) -> bool:
    if is_user_defined(cls_name):
        if config is None or "cls" not in config:
            raise ValueError(f"UserDefinedOperator kwargs must have cls key")
        udf_class = get_udf_class(config["cls"])
        return (
            issubclass(udf_class, featurizer.Featurizer) and udf_class.is_featurizer()
        )
    operator_class = get_operator_class(cls_name)
    return (
        issubclass(operator_class, featurizer.Featurizer)
        and operator_class.is_featurizer()
    )


def is_model(cls_name: str) -> bool:
    from operators.model import Model

    return issubclass(get_operator_class(cls_name), Model)


def is_reducer(cls_name: str, config: Optional[Dict[str, Any]]) -> bool:
    if is_user_defined(cls_name):
        if config is None or "cls" not in config:
            raise ValueError(f"UserDefinedOperator kwargs must have cls key")
        return issubclass(get_udf_class(config["cls"]), SpanReducer)
    return issubclass(get_operator_class(cls_name), SpanReducer)


def _is_abstract_class(cls: Any) -> bool:
    # Check if this class inherits from ABC
    return (
        (ABC in cls.__bases__)
        or (cls.__name__ == "Filter")
        or (cls.__name__ == "FixedDatapointOperator")
        or (cls.__name__ == "ModelPostProcessor")
        or (cls.__name__ == "ChangeColumns")
        or (cls.__name__ == "ChangeRows")
        or (cls.__name__ == "Featurizer")
        or (cls.__name__ == "EmbeddingFeaturizerBase")
        or (cls.__name__ == "EmbeddingCandidateFeaturizerBase")
        or (cls.__name__ == "Operator")
        or (cls.__name__ == "ModelPostProcessor")
        or (cls.__name__ == "SpecialCharFilter")
        or (cls.__name__ == "_SpanMergeByConditionPostProcessorHelper")
        or (cls.__name__ == "SpanFeaturizerExtractor")
        or (cls.__name__ == "BaseRichDocParser")
    )


def is_deprecated(cls_name: str) -> bool:
    return get_operator_class(cls_name).is_deprecated  # type: ignore


def _is_deprecated_class(cls: Any) -> bool:
    return cls.is_deprecated  # type: ignore


def is_disabled_by_feature_flag(cls: Any) -> bool:
    return cls.is_disabled_by_feature_flag()  # type: ignore


def _is_user_defined_class(cls: Any) -> bool:
    return (
        # Client passes 'UserDefinedOperator' as operator name in processor configs.
        # It does NOT (as may be expected) pass the subclass's cls name.
        cls.__name__ == UserDefinedOperator.__name__
        or issubclass(cls, UserDefinedOperator)
    )


def get_expected_op_type(cls_name: str, cls_config: Optional[Dict[str, Any]]) -> str:
    # When the user passes in an operator via preprocessor_config we need to
    # find the root operator type to set as the expected_op_type
    if is_user_defined(cls_name):
        # the user submitted a UserDefinedOperator of type PandasOperator
        # which we are unable to disambiguate (could be a featurizer, filter, or other)
        # For purposes of the migration, most PandasOperators are featurizers or can be
        # treated as such.
        return cls_name
    elif is_filter(cls_name):
        return Filter.__name__
    elif is_extractor(cls_name, cls_config):
        return SpanExtractor.__name__
    elif is_featurizer(cls_name, cls_config):
        return featurizer.Featurizer.__name__
    elif is_reducer(cls_name, cls_config):
        return SpanReducer.__name__
    else:
        # This should cover all other cases like ColumnDropper, Model, RichDocPagePreprocessor, etc
        return cls_name


def get_operator_class_configs(
    base_cls_name: Optional[str] = None, workspace_uid: Optional[int] = None
) -> List[Dict[str, Any]]:
    """Fetches all operator classes that inherit from the base_cls."""
    operator_classes = get_operator_classes(workspace_uid=workspace_uid)
    base_cls_arr = (
        [
            op_cls
            for _, ops in operator_classes.items()
            for op_name, op_cls in ops.items()
            if op_name == base_cls_name
        ]
        if base_cls_name is not None
        else []
    )
    if base_cls_name is not None and not base_cls_arr:
        raise OperatorNotFoundException(
            f"Operator class not found: {base_cls_name}. Make sure the class file is imported above."
        )

    # If base_cls_name is None, pass by default
    inherits_from_base_cls = lambda x: (
        issubclass(x, base_cls_arr[0])  # type: ignore
        if base_cls_name is not None
        else True
    )

    ret = []
    for ws_uid, ops in operator_classes.items():
        for op_name, op_cls in ops.items():
            if (
                inherits_from_base_cls(op_cls)
                and not _is_user_defined_class(op_cls)
                and not _is_abstract_class(op_cls)
                and not _is_deprecated_class(op_cls)
                and not is_disabled_by_feature_flag(op_cls)
            ):
                examples = op_cls.examples()
                try:
                    expected_op_type = get_expected_op_type(
                        op_cls.__name__, cls_config=None
                    )
                except OperatorNotFoundException:
                    expected_op_type = op_cls.__name__
                # Use first line of docstring as description
                docstring = parse(op_cls.__doc__)
                short_description = docstring.short_description
                long_description = docstring.long_description

                if short_description:
                    description = short_description
                else:
                    description = (
                        op_cls.__doc__.split("\n")[0] if op_cls.__doc__ else None
                    )
                inputs = get_field_configs_from_cls(cls=op_cls)
                fit_inputs = get_fit_configs_from_cls(cls=op_cls)
                ret.append(
                    dict(
                        operator_name=op_name,
                        workspace_uid=ws_uid
                        if op_name not in operator.operators_dict
                        else None,
                        expected_op_type=expected_op_type,
                        long_description=long_description,
                        description=description,
                        inputs=inputs if inputs else None,
                        fit_inputs=fit_inputs if fit_inputs else None,
                        examples=examples,
                    )
                )

    return ret
