from collections import defaultdict
from typing import Any, Dict, List, Optional, Tuple

import pandas as pd

from api_utils.exceptions import UserInputError
from operators.utils import TOKEN_FIELD_PREFIX
from snorkelflow.operators.featurizer import Featurizer, OpProgressCallback
from snorkelflow.operators.operator import ColSchema, no_op_progress_callback
from snorkelflow.types.performance import Performance

SPACY_TOK_DEPRECATED_MESSAGE = """This `Tokens field` is now deprecated and default to 'tokenized_{your_text_field}'. Please specify `Tokens field = tokenized_{your_text_field}' to proceed.`"""


class BaseSpacyFeaturizer(Featurizer):
    """An abstract Featurizer subclass that utilizes spaCy.

    Featurizers which use spaCy should inherit from this class. This class
    handles importing the spaCy library (which may not be available ) and
    loading of a spaCy model.

    Parameters
    ----------
    model
        The model to load into spaCy (only supports models in strap).
    disable
        Optional list of pipeline steps to disable.
    spacy_kwargs
        Kwargs to forward to the spacy.load function.
    """

    def __init__(
        self,
        model: str = "en_core_web_sm",
        disable: Optional[List[str]] = None,
        **spacy_kwargs: Dict[str, Any],
    ):
        self.model = model
        self.disable = disable
        self.spacy_kwargs = spacy_kwargs
        self._nlp = None

    @property
    def nlp(self) -> Any:
        if self._nlp:
            return self._nlp

        try:
            import spacy

            self._nlp = spacy.load(
                self.model, disable=self.disable or [], **self.spacy_kwargs
            )
            return self._nlp
        except OSError:
            raise ValueError(
                f"spaCy model {self.model} is not available in this build of Snorkel Flow"
            )


class SpacyPreprocessor(BaseSpacyFeaturizer):
    """Preprocessor that parses document and adds json doc column.

    Used by Sequence Tagging applications to add additional document metadata.

    Parameters
    ----------
    field
        The field to parse with spacy.
    target_field
        The field in which to store the parsed doc object.
    model
        The model to load into spaCy (only supports models in strap).
    disable
        Optional list of pipeline steps to disable.
    spacy_kwargs
        Kwargs to forward to the spacy.load function.
    """

    operator_impl_version: int = 3

    def __init__(
        self,
        field: str,
        target_field: str = "doc",
        model: str = "en_core_web_sm",
        disable: Optional[List[str]] = None,
        **spacy_kwargs: Dict[str, Any],
    ):
        super().__init__(disable=disable, model=model, **spacy_kwargs)
        self.field = field
        self.target_field = target_field

    @property
    def input_schema(self) -> ColSchema:
        return {self.field: str}

    @property
    def output_schema(self) -> ColSchema:
        return {self.target_field: str}

    def _compute_features(
        self,
        input_df: pd.DataFrame,
        callback: OpProgressCallback = no_op_progress_callback,
    ) -> pd.DataFrame:
        """Override base class method"""
        input_df[self.target_field] = (
            input_df[self.field]
            .fillna("")
            .astype(str)
            .apply(lambda x: self.nlp(x).to_json())
        )
        return input_df

    def estimate_perf(self, df: pd.DataFrame) -> Performance:
        data_set_size = df[self.field].map(len).sum()
        return Performance(
            peak_memory_mb=data_set_size * 0.0007,
            compute_time_secs=data_set_size * 0.00005,
        )


class SpacyTokenizer(BaseSpacyFeaturizer):
    """Preprocessor that parses document and adds tokens json column.

    Used by Sequence Tagging applications to add additional document metadata.

    Parameters
    ----------
    text_field
        The field to parse with spacy.
    tokens_field
        The field in which to store the tokens list object.
    """

    operator_impl_version: int = 2
    operator_impl_version_to_ds_migration: Dict[int, bool] = defaultdict(
        lambda: False, {2: True}
    )
    # only op_implementation_version 2 is supported for ds migration. 1 requires reruning spacy.

    def __init__(self, text_field: str, tokens_field: Optional[str] = None):
        super().__init__(model="en_core_web_sm")
        self.text_field = text_field
        self.tokens_field = tokens_field or f"{TOKEN_FIELD_PREFIX}{text_field}"

        # Raise ValueError here as we want to standardize the output field to be
        # f"tokenized_{text_field}" while keeping the op input field structure the same.
        if self.tokens_field != f"{TOKEN_FIELD_PREFIX}{text_field}":
            raise UserInputError(
                detail=SPACY_TOK_DEPRECATED_MESSAGE,
                user_friendly_message=SPACY_TOK_DEPRECATED_MESSAGE,
            )

    @property
    def input_schema(self) -> ColSchema:
        return {self.text_field: str}

    @property
    def output_schema(self) -> ColSchema:
        return {self.tokens_field: List[Tuple[int, int]]}

    # TODO: Re-evaluate whether this should be serialized using JSON or
    # pickle, based on profiling of analysis page.
    def _compute_features(
        self,
        input_df: pd.DataFrame,
        callback: OpProgressCallback = no_op_progress_callback,
    ) -> pd.DataFrame:
        """Override base class method"""

        def _convert_tokens_dict_to_array(
            tokens: List[Dict[str, int]]
        ) -> List[Tuple[int, int]]:
            """Converts a list of tokens dicts to a list of token arrays"""
            return [(token["start"], token["end"]) for token in tokens]

        input_df[self.tokens_field] = (
            input_df[self.text_field]
            .fillna("")
            .astype(str)
            .apply(
                lambda x: _convert_tokens_dict_to_array(
                    self.nlp.tokenizer(x).to_json()["tokens"]
                )
            )
        )
        return input_df

    def estimate_perf(self, df: pd.DataFrame) -> Performance:
        data_set_size = df[self.text_field].map(len).sum()
        return Performance(
            peak_memory_mb=data_set_size * 0.0008,
            compute_time_secs=data_set_size * 0.00003,
        )


class NounChunkFeaturizer(BaseSpacyFeaturizer):
    """A Featurizer that yields all noun phrases according to spaCy.

    Used by the Seq Tagging application template as one of the base candidate
    generators for producing embeddings from.

    Parameters
    ----------
    field
        The field to parse into noun chunks.
    target_field
        The field in which to store the extracted noun chunk candidates.
    spacy_span_kwargs
        kwargs to pass to the spaCy model.
    """

    operator_impl_version: int = 1

    def __init__(
        self, field: str, target_field: Optional[str] = None, **spacy_span_kwargs: Any
    ):
        super().__init__(disable=["ner"], **spacy_span_kwargs)
        self.field = field
        self.target_field = target_field or field + "_noun_chunks"

    @property
    def input_schema(self) -> ColSchema:
        return {self.field: str}

    @property
    def output_schema(self) -> ColSchema:
        return {self.target_field: None}

    def _compute_features(
        self,
        input_df: pd.DataFrame,
        callback: OpProgressCallback = no_op_progress_callback,
    ) -> pd.DataFrame:
        """Override base class method"""
        input_df[self.target_field] = (
            input_df[self.field]
            .fillna("")
            .astype(str)
            .apply(
                lambda x: [
                    {"id": idx, "start": chunk.start_char, "end": chunk.end_char - 1}
                    for idx, chunk in enumerate(self.nlp(x).noun_chunks)
                ]
            )
        )
        return input_df


class VerbPhraseFeaturizer(BaseSpacyFeaturizer):
    """A Featurizer that yields all verb phrases according to a simple part-of-speech verb match.

    Used by the Seq Tagging application template as one of the base candidate
    generators for producing embeddings from.

    Parameters
    ----------
    field
        The field to parse into verb phrases.
    target_field
        The field in which to store the extracted verb phrase candidates.
    min_length
        The minimum number of tokens for extracted verb phrases. Used to avoid
        single token phrases. Default: 2.
    spacy_span_kwargs
        kwargs to pass to the spaCy model.
    """

    operator_impl_version: int = 1

    def __init__(
        self,
        field: str,
        target_field: Optional[str] = None,
        min_length: int = 2,
        **spacy_span_kwargs: Any,
    ):
        super().__init__(disable=["ner"], **spacy_span_kwargs)
        self.field = field
        self.target_field = target_field or field + "_verb_phrases"
        self.min_length = min_length
        patterns = [
            # Auxiliary verbs are separate from other verbs in spacy 3.x. see: https://spacy.io/usage/linguistic-features
            [
                {"POS": {"REGEX": "AUX|VERB"}, "OP": "?"},
                {"POS": "ADV", "OP": "*"},
                {"OP": "*"},  # additional wildcard - match any text in between
                {"POS": {"REGEX": "AUX|VERB"}, "OP": "+"},
            ]
        ]
        # Performs check for spacy being available
        nlp = self.nlp

        # Now can safely import because lib check was done above
        import spacy.matcher

        self._matcher = spacy.matcher.Matcher(nlp.vocab)
        self._matcher.add("verb-phrases", patterns)

    @property
    def input_schema(self) -> ColSchema:
        return {self.field: str}

    @property
    def output_schema(self) -> ColSchema:
        return {self.target_field: None}

    def _compute_features(
        self,
        input_df: pd.DataFrame,
        callback: OpProgressCallback = no_op_progress_callback,
    ) -> pd.DataFrame:
        """Override base class method"""

        def extract_matches(x: str) -> List[Dict[str, int]]:
            doc = self.nlp(x)
            token_matches = self._matcher(doc)
            spans = []
            for idx, chunk in enumerate(token_matches):
                if chunk[2] - chunk[1] < self.min_length:
                    continue

                start_token = doc[chunk[1]]
                end_token = doc[chunk[2] - 1]
                so = start_token.idx
                eo = end_token.idx + len(end_token)
                spans.append({"id": idx, "start": so, "end": eo})
            return spans

        input_df[self.target_field] = (
            input_df[self.field].fillna("").astype(str).apply(extract_matches)
        )
        return input_df


class SentenceFeaturizer(BaseSpacyFeaturizer):
    """A Featurizer that yields all sentences according to spaCy.

    Used by the Seq Tagging application template as one of the base candidate
    generators for producing embeddings from.

    Parameters
    ----------
    field
        The field to parse into sentences.
    target_field
        The field in which to store the extracted sentence candidates.
    spacy_span_kwargs
        kwargs to pass to the spaCy model.
    """

    operator_impl_version: int = 1

    def __init__(
        self, field: str, target_field: Optional[str] = None, **spacy_span_kwargs: Any
    ):
        super().__init__(disable=["ner"], **spacy_span_kwargs)
        self.field = field
        self.target_field = target_field or field + "_sentences"

    @property
    def input_schema(self) -> ColSchema:
        return {self.field: str}

    @property
    def output_schema(self) -> ColSchema:
        return {self.target_field: None}

    def _compute_features(
        self,
        input_df: pd.DataFrame,
        callback: OpProgressCallback = no_op_progress_callback,
    ) -> pd.DataFrame:
        """Override base class method"""

        def extract_matches(x: str) -> List[Dict[str, int]]:
            doc = self.nlp(x)
            spans = []
            for idx, chunk in enumerate(doc.sents):
                so = chunk.start_char
                eo = chunk.end_char - 1
                spans.append({"id": idx, "start": so, "end": eo})
            return spans

        input_df[self.target_field] = (
            input_df[self.field].fillna("").astype(str).apply(extract_matches)
        )
        return input_df
