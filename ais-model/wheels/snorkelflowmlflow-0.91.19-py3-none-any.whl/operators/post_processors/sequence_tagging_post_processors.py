from typing import Any, Dict, List, Tuple

import pandas as pd
import re2

from operators.post_processors.model_post_processor import ModelPostProcessor
from snorkelflow.operators.operator import ColSchema
from snorkelflow.types.model import ModelCols
from snorkelflow.utils.logging import get_logger

logger = get_logger("ModelPostProcessor")


class SpanFilterByLengthPostProcessor(ModelPostProcessor):
    """Filter positive spans with length <= the provided span_length"""

    def __init__(self, span_length: int):
        self.span_length = span_length

    def _per_row(self, row: pd.Series) -> pd.Series:
        doc_pred_int = row[ModelCols.PREDICTION_INT]
        doc_pred_probs = row[ModelCols.PREDICTION_PROBABILITY]
        updated_doc_pred_int: List[List[int]] = []
        updated_doc_pred_probs: List[List[Any]] = []

        for i in range(len(doc_pred_int)):
            span_start, span_end, span_label_class = doc_pred_int[i]
            _, _, span_label_probs = doc_pred_probs[i]
            span_length = span_end - span_start
            if span_label_class != 0 and span_length <= self.span_length:
                # Change this span to negative label
                span_label_probs = [
                    1.0 if i == 0 else 0.0 for i in range(len(span_label_probs))
                ]
                span_label_class = 0

            # check if we need to merge current span with previous
            if (
                len(updated_doc_pred_int) > 0
                and updated_doc_pred_int[-1][2] == span_label_class
                and span_label_class == 0
            ):
                updated_doc_pred_int[-1] = self._merge_pred_spans(
                    updated_doc_pred_int[-1], doc_pred_int[i]
                )
                updated_doc_pred_probs[-1] = self._merge_pred_spans(
                    updated_doc_pred_probs[-1], doc_pred_probs[i]
                )
            else:
                updated_doc_pred_int.append([span_start, span_end, span_label_class])
                updated_doc_pred_probs.append([span_start, span_end, span_label_probs])

        row[ModelCols.PREDICTION_INT] = updated_doc_pred_int
        row[ModelCols.PREDICTION_PROBABILITY] = updated_doc_pred_probs
        return row


class _SpanMergeByConditionPostProcessorHelper(ModelPostProcessor):
    def __init__(self) -> None:
        self.field = ""

    def _find_first_pos_spans(
        self, zip_doc_pred: List[Tuple[List[int], List[Any]]]
    ) -> int:
        output = -1
        for idx, doc_pred in enumerate(zip_doc_pred):
            if doc_pred[0][2] != 0:
                output = idx
                break
        return output

    def _merge_conditions(
        self,
        char_start: int,
        latest_pos_char_end: int,
        optional_conditions: Dict[str, Any],
    ) -> bool:
        pass

    def _per_row(self, row: pd.Series) -> pd.Series:
        doc_pred_int = row[ModelCols.PREDICTION_INT]
        doc_pred_probs = row[ModelCols.PREDICTION_PROBABILITY]
        updated_doc_pred_int: List[List[int]] = []
        updated_doc_pred_probs: List[List[Any]] = []

        # Special parameters depend on operators:
        if self.__class__.__name__ == "SpanMergeByRegexPatternPostProcessor":
            optional_params = dict(text=row[self.field])
        elif self.__class__.__name__ == "SpanMergeByNumberCharacterPostProcessor":
            optional_params = dict()
        else:
            raise NotImplementedError("New Merge Operator requires registration")

        zip_updated_doc_pred = self._merge_span_by_condition(
            doc_pred_int,
            doc_pred_probs,
            updated_doc_pred_int,
            updated_doc_pred_probs,
            optional_params,
        )

        row[ModelCols.PREDICTION_INT] = [
            zip_updated_span_pred[0] for zip_updated_span_pred in zip_updated_doc_pred
        ]
        row[ModelCols.PREDICTION_PROBABILITY] = [
            zip_updated_span_pred[1] for zip_updated_span_pred in zip_updated_doc_pred
        ]
        return row

    def _merge_pred_spans(self, span1: List, span2: List) -> List:
        char_start, _, span_property = span1
        _, char_end, _ = span2
        return [char_start, char_end, span_property]

    def _merge_span_by_condition(
        self,
        doc_pred_int: List[List[int]],
        doc_pred_probs: List[List[Any]],
        updated_doc_pred_int: List[List[int]],
        updated_doc_pred_probs: List[List[Any]],
        optional_params: Dict[str, Any],
    ) -> List[Tuple[List[int], List[Any]]]:
        """
        This function is to merge spans if the text in between them match the self.regex_pattern

        Steps:
        1. Zip doc_pred_int, doc_pred_probs (labels and probs) to process them together along the code
        2. Labels are unaffected until the 1st positive labels appear
        3. We start scanning from the 1st positive labels & we keep track of the latest positive labels
        to merge properly ONLY those are same labels and have ONLY NEGATIVE spans in between
        4. Merge
        4.1. If different positive label, append and continue
        4.2. If same positive label -> compute the self._merge_conditions for each type of operator
        4.2.1. If not meet condition, append and continue
        4.2.2. If meet condition, then we truncate the current predictions till the last positive labels
        where we will merge the new span to, and overwrite that span.

        Returns:
            List[Tuple[List[int], List[Any]]]: Updated zip contains both preds & probs
        """

        # Step 1: Zip
        zip_doc_pred = list(zip(doc_pred_int, doc_pred_probs))
        zip_updated_doc_pred = list(zip(updated_doc_pred_int, updated_doc_pred_probs))

        # Step 2: Find the 1st positive span
        latest_pos_idx = self._find_first_pos_spans(zip_doc_pred)
        if latest_pos_idx == -1:
            return zip_doc_pred

        # Step 3: We start scanning from the 1st positive labels & keep track of the latest positive labels
        zip_updated_doc_pred = zip_doc_pred[: latest_pos_idx + 1]

        _, latest_pos_char_end, latest_pos_label = zip_updated_doc_pred[-1][0]

        # Step 4: Merge (see above)
        for span in zip_doc_pred[latest_pos_idx + 1 :]:
            char_start, _, label = span[0]

            # Different label -> append and move on
            if label != latest_pos_label:
                zip_updated_doc_pred.append(span)
                if label != 0:
                    _, latest_pos_char_end, latest_pos_label = span[0]
                    latest_pos_idx = len(zip_updated_doc_pred) - 1

            # Same label -> compute condition and merge when applicable
            else:
                if self.__class__.__name__ == "SpanMergeByRegexPatternPostProcessor":
                    optional_params = dict(text=optional_params.get("text"))
                    condition = self._merge_conditions(
                        char_start, latest_pos_char_end, optional_params
                    )

                elif (
                    self.__class__.__name__ == "SpanMergeByNumberCharacterPostProcessor"
                ):
                    optional_params = dict()
                    condition = self._merge_conditions(
                        char_start, latest_pos_char_end, optional_params
                    )

                if condition:
                    zip_updated_doc_pred[latest_pos_idx] = (
                        self._merge_pred_spans(
                            zip_updated_doc_pred[latest_pos_idx][0], span[0]
                        ),
                        self._merge_pred_spans(
                            zip_updated_doc_pred[latest_pos_idx][1], span[1]
                        ),
                    )
                    zip_updated_doc_pred = zip_updated_doc_pred[: latest_pos_idx + 1]
                    _, latest_pos_char_end, latest_pos_label = zip_updated_doc_pred[
                        latest_pos_idx
                    ][0]

                else:
                    zip_updated_doc_pred.append(span)
                    _, latest_pos_char_end, latest_pos_label = span[0]
                    latest_pos_idx = len(zip_updated_doc_pred) - 1

        return zip_updated_doc_pred


class SpanMergeByRegexPatternPostProcessor(_SpanMergeByConditionPostProcessorHelper):
    """Merge same-label nearby spans if the negative-label text in between spans matches this regex pattern. For the Field, please select your document field.

    Parameters
    ----------
    field
        Your seq input field.
    regex_pattern
        Merge nearby spans with same labels if the negative-labeled text in between spans matches this regex pattern.
    """

    def __init__(self, regex_pattern: str, field: str):
        self.field = field
        self.regex_pattern = re2.compile(regex_pattern)

    @property
    def input_schema(self) -> ColSchema:
        return {
            ModelCols.PREDICTION_INT: None,
            ModelCols.PREDICTION_PROBABILITY: None,
            self.field: str,
        }

    def _merge_conditions(
        self,
        char_start: int,
        latest_pos_char_end: int,
        optional_conditions: Dict[str, Any],
    ) -> bool:
        "If the string between 2 positive spans match the regex -> Return True to match"
        text = optional_conditions["text"]
        in_between_text = text[latest_pos_char_end:char_start]
        return bool(self.regex_pattern.match(in_between_text))


class SpanMergeByNumberCharacterPostProcessor(_SpanMergeByConditionPostProcessorHelper):
    """Merge same-label nearby spans if the negative-label text in between spans is in [lower, upper] number of characters (inclusive)."""

    def __init__(
        self, lower_bound_number_character: int, upper_bound_number_character: int
    ):
        self.lower_bound_number_character = lower_bound_number_character
        self.upper_bound_number_character = upper_bound_number_character

    def _merge_conditions(
        self,
        char_start: int,
        latest_pos_char_end: int,
        optional_conditions: Dict[str, Any],
    ) -> bool:
        "If the string between 2 positive spans between the range [inclusive] -> Return True to match"
        in_between_distance = char_start - latest_pos_char_end
        return bool(
            self.lower_bound_number_character
            <= in_between_distance
            <= self.upper_bound_number_character
        )


class SpanRegexPostProcessor(ModelPostProcessor):
    """Post Porcessor that labels anything that matches the provided pattern with the provided label

    Parameters
    ----------
    regex_pattern
        The regex pattern that we should.
    field
        The field over which extraction was run
    predict_label
        What to label text that matches the provided pattern
    """

    def __init__(self, regex_pattern: str, predict_label: int, field: str):
        self.regex_pattern = re2.compile(regex_pattern)
        self.predict_label = predict_label
        self.field = field

    @property
    def input_schema(self) -> ColSchema:
        return {
            ModelCols.PREDICTION_INT: None,
            ModelCols.PREDICTION_PROBABILITY: None,
            self.field: str,
        }

    def _per_row(self, row: pd.Series) -> pd.Series:
        """
        This contains the core logic for updating the predictions.
        The steps are roughly as follows:
        1.  Iterate over each of the model predictions
        2.  Check if the prediction spans overlap at all with the matches
            from the provided regex
        3.  If there's overlap, update the bounds of the prediction to be non-overlapping
            with the match. In some cases this will mean splitting the span into two new spans
        4. Append all new spans along with the matches from the regex to the new pred column
        """
        doc_pred_int = row[ModelCols.PREDICTION_INT]
        doc_pred_probs = row[ModelCols.PREDICTION_PROBABILITY]
        updated_doc_pred_int: List[List[int]] = []
        updated_doc_pred_probs: List[List[Any]] = []
        doc_str = row[self.field]
        matches = list(self.regex_pattern.finditer(doc_str))
        default_probs = [0] * len(doc_pred_probs[0][2])
        default_probs[self.predict_label] = 1
        for (
            (pred_start, pred_end, pred_label),
            (  # type: ignore
                pred_prob_start,
                pred_prob_end,
                pred_prob,
            ),
        ) in zip(
            doc_pred_int, doc_pred_probs
        ):  # type: ignore
            no_split = True
            for match in matches:
                if match.start() < pred_start and match.end() > pred_end:
                    no_split = False
                    continue
                if (match.start() > pred_start and match.start() < pred_end) or (
                    match.end() > pred_start and match.end() < pred_end
                ):
                    no_split = False
                    if match.start() > pred_start and match.start() < pred_end:
                        updated_doc_pred_int.append(
                            [pred_start, match.start(), pred_label]
                        )
                        updated_doc_pred_probs.append(
                            [pred_start, match.start(), pred_prob]
                        )

                    if match.end() > pred_start and match.end() < pred_end:
                        updated_doc_pred_int.append([match.end(), pred_end, pred_label])
                        updated_doc_pred_probs.append(
                            [match.end(), pred_end, pred_prob]
                        )

            if no_split:
                updated_doc_pred_int.append([pred_start, pred_end, pred_label])
                updated_doc_pred_probs.append(
                    [pred_prob_start, pred_prob_end, pred_prob]
                )
        for match in matches:
            updated_doc_pred_int.append(
                [match.start(), match.end(), self.predict_label]
            )
            updated_doc_pred_probs.append([match.start(), match.end(), default_probs])
        row[ModelCols.PREDICTION_PROBABILITY] = updated_doc_pred_probs
        row[ModelCols.PREDICTION_INT] = updated_doc_pred_int
        return row


class SpanRemoveWhitespacePostProcessor(ModelPostProcessor):
    """Remove leading & trailing whitespace in positive spans. For the Field, please select your document field."""

    def __init__(self, field: str):
        self.field = field

    @property
    def input_schema(self) -> ColSchema:
        return {
            ModelCols.PREDICTION_INT: None,
            ModelCols.PREDICTION_PROBABILITY: None,
            self.field: str,
        }

    def _per_row(self, row: pd.Series) -> pd.Series:
        """
        For each POS span, we compute the span w/o the leading/trailing whitespaces (lstrip, rstrip).
        Then we shrink the POS spans to remove leading/trailing whitespaces.
        We shrink the POS spans + ignore the whitespaces because the whitespaces will be labeled as NEG anyway,
        which wouldn't affect any type of sequence metrics we compute.
        """
        doc_pred_ints = row[ModelCols.PREDICTION_INT]
        doc_pred_probs = row[ModelCols.PREDICTION_PROBABILITY]
        updated_doc_pred_int: List[List[int]] = []
        updated_doc_pred_probs: List[List[Any]] = []

        text = row[self.field]

        zip_doc_pred = list(zip(doc_pred_ints, doc_pred_probs))
        zip_updated_doc_pred = list(zip(updated_doc_pred_int, updated_doc_pred_probs))

        for zip_doc in zip_doc_pred:
            doc_pred_int, doc_pred_prob = zip_doc
            span_start, span_end, span_label_class = doc_pred_int

            # Ignore NEG spans
            if span_label_class == 0:
                zip_updated_doc_pred.append(zip_doc)
                continue

            current_span = text[span_start:span_end]
            current_length = span_end - span_start
            right_whitespace = current_length - len(current_span.rstrip())
            left_whitespace = current_length - len(current_span.lstrip())

            new_span_start = span_start + left_whitespace
            new_span_end = span_end - right_whitespace

            zip_updated_doc_pred.append(
                (
                    [new_span_start, new_span_end, span_label_class],
                    [new_span_start, new_span_end, doc_pred_prob[2]],
                )
            )

        row[ModelCols.PREDICTION_INT] = [
            zip_updated_span_pred[0] for zip_updated_span_pred in zip_updated_doc_pred
        ]
        row[ModelCols.PREDICTION_PROBABILITY] = [
            zip_updated_span_pred[1] for zip_updated_span_pred in zip_updated_doc_pred
        ]
        return row


class SubstringExpansionPostProcessor(ModelPostProcessor):
    """This postprocessor expands predictions to the token boundaries should a prediction boundary fall mid-token.

    Parameters
    ----------
    field
        The field over which the model has made predictions.
    tokens_field
        The field in which  the tokens list object is stored.

    """

    def __init__(self, field: str, tokenized_field: str) -> None:
        self._field = field
        self._tokenized_field = tokenized_field

    @property
    def input_schema(self) -> ColSchema:
        return {
            ModelCols.PREDICTION_INT: None,
            ModelCols.PREDICTION_PROBABILITY: None,
            self._field: str,
            self._tokenized_field: str,
        }

    def _per_row(self, row: pd.Series) -> pd.Series:
        updated_doc_pred_int, updated_doc_pred_probs = self._substring_expansion(row)
        row[ModelCols.PREDICTION_INT] = updated_doc_pred_int
        row[ModelCols.PREDICTION_PROBABILITY] = updated_doc_pred_probs
        return row

    def _get_unique_list_of_lists(self, list_of_lists: list) -> list:
        return [list(x) for x in {tuple(x) for x in list_of_lists}]

    def _substring_expansion(self, x: pd.Series) -> Tuple[Any, Any]:
        tokens_off = x[self._tokenized_field]
        pred_off = x[ModelCols.PREDICTION_INT]
        pred_probs = x[ModelCols.PREDICTION_PROBABILITY]
        doc_str = x[self._field]
        found_substring = False
        # if all spans are neg
        if all([label == 0 for _, _, label in pred_off]):
            return pred_off, pred_probs

        pos_tokens = []
        pos_tokens_probs = []
        # check if pos pred is a substring
        for (
            (pred_start, pred_end, pred_label),
            (  # type: ignore
                pred_prob_start,
                pred_prob_end,
                pred_prob,
            ),
        ) in zip(
            pred_off, pred_probs
        ):  # type: ignore
            if pred_label > 0:
                found_substring = False
                for tok in tokens_off:
                    tok_start = tok[0]
                    tok_end = tok[1]
                    # if the prediction offsets are within the token offset,
                    # select token offsets as prediction
                    if (pred_start > tok_start and pred_end <= tok_end) or (
                        pred_end < tok_end and pred_start >= tok_start
                    ):
                        pos_tokens.append([tok_start, tok_end, pred_label])
                        pos_tokens_probs.append([tok_start, tok_end, pred_prob])
                        found_substring = True
                        break
                # if no substrings found
                if found_substring is False:
                    pos_tokens.append([pred_start, pred_end, pred_label])
                    pos_tokens_probs.append([pred_prob_start, pred_prob_end, pred_prob])
            # Prev span had altered substring, must update start of following pred_prob start
            elif found_substring is True:
                pos_tokens_probs.append([tok_end, pred_prob_end, pred_prob])
            else:
                pos_tokens_probs.append([pred_prob_start, pred_prob_end, pred_prob])

        neg_spans = self._get_neg_spans(
            self._get_unique_list_of_lists(pos_tokens), len(doc_str)
        )
        all_spans = sorted(pos_tokens + neg_spans)
        return all_spans, pos_tokens_probs

    def _get_neg_spans(self, pos_spans: list, doc_len: int) -> list:
        spans = []  # type: ignore

        if len(pos_spans) == 1:
            pos_start, pos_end, _ = pos_spans[0]
            if pos_start == 0 and pos_end == doc_len:
                return spans
            elif pos_start == 0:
                neg_start = pos_end
                neg_end = doc_len
                spans.append([neg_start, neg_end, 0])
            elif pos_end == doc_len:
                neg_start = 0
                neg_end = pos_start
                spans.append([neg_start, neg_end, 0])
            else:
                spans.append([0, pos_start, 0])
                spans.append([pos_end, doc_len, 0])
            return spans

        else:
            prev_end = None
            for idx, (start, end, _) in enumerate(sorted(pos_spans)):
                # we skip the first and last POS GT
                if start == 0:
                    prev_end = end
                    continue

                if end == doc_len:
                    spans.append([prev_end, start, 0])
                    return spans

                else:
                    # add first negative span
                    if prev_end is None:
                        spans.append([0, start, 0])
                        prev_end = end

                    # add last negative span and span before
                    elif idx == len(pos_spans) - 1:
                        spans.append([prev_end, start, 0])
                        spans.append([end, doc_len, 0])

                    # all other spans
                    else:
                        spans.append([prev_end, start, 0])
                        prev_end = end
        if spans == []:
            return [[0, doc_len, 0]]
        return spans
