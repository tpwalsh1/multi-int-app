import traceback
from typing import List

import pandas as pd

from api_utils.exceptions import UserInputError
from snorkelflow.operators.featurizer import Featurizer, OpProgressCallback
from snorkelflow.operators.operator import ColSchema, no_op_progress_callback
from snorkelflow.types.model import ModelCols
from snorkelflow.utils.logging import get_logger

logger = get_logger("ModelPostProcessor")


class ModelPostProcessor(Featurizer):
    @property
    def input_schema(self) -> ColSchema:
        return {ModelCols.PREDICTION_INT: None, ModelCols.PREDICTION_PROBABILITY: None}

    @property
    def output_schema(self) -> ColSchema:
        return {ModelCols.PREDICTION_INT: None, ModelCols.PREDICTION_PROBABILITY: None}

    def _per_row(self, row: pd.Series) -> pd.Series:
        # Method to be overwritten in operators' code
        return row

    def _compute_features(
        self,
        input_df: pd.DataFrame,
        callback: OpProgressCallback = no_op_progress_callback,
    ) -> pd.DataFrame:
        try:
            return input_df.apply(self._per_row, 1)
        except (TypeError, IndexError):
            err_msg = (
                self.__class__.__name__
                + " should be used only for sequence tagging applications."
            )
            logger.error(f"{err_msg}\nStack Trace: {traceback.format_exc()}")
            raise UserInputError(detail=err_msg, user_friendly_message=err_msg)

    def _merge_pred_spans(self, span1: List, span2: List) -> List:
        char_start, _, span_property = span1
        _, char_end, _ = span2
        return [char_start, char_end, span_property]
