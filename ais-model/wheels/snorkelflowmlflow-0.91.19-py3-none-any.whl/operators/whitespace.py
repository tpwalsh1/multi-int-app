from typing import Any, List, Optional

import pandas as pd

from snorkelflow.operators.featurizer import Featurizer, OpProgressCallback
from snorkelflow.operators.operator import (
    ColSchema,
    OperatorExample,
    no_op_progress_callback,
)


class WhitespacePreprocessor(Featurizer):
    """
    Preprocessor that normalizes whitespace.

    This operator finds all of the different types of whitespace in a given text
    field and normalizes it to the regular space character (U+0020). By default,
    the following non-standard space characters with the regular space: U+00A0,
    U+2000 to U+200A, U+202F, U+205F, U+3000.
    See https://en.wikipedia.org/wiki/Whitespace_character for more details on what
    these UTF-8 code points mean.

    Parameters
    ----------
    fields
        The fields to apply whitespace pre-processing to.
    to_replace
        A string containing all characters to be replaced with a regular whitespace (U+0020).
    output_field_suffix:
        To avoid updating in place, optionally specify a suffix to add to specified fields.
    """

    def __init__(
        self,
        fields: List[str],
        to_replace: Optional[str] = None,
        output_field_suffix: Optional[str] = "",
    ) -> None:
        self.fields = fields
        self.output_field_suffix = output_field_suffix
        if to_replace is None:
            to_replace = (
                "\u00A0\u2000\u2001\u2002\u2003\u2004\u2005\u2006\u2007\u2008\u2009"
                "\u200A\u202F\u205F\u3000"
            )
        self.trans = {c: " " for c in to_replace}

    @property
    def input_schema(self) -> ColSchema:
        return {x: str for x in self.fields}

    @property
    def output_schema(self) -> ColSchema:
        return {self.output_field(x): str for x in self.fields}

    def output_field(self, field: str) -> str:
        return f"{field}{self.output_field_suffix}"

    @staticmethod
    def examples() -> List[OperatorExample]:
        return [
            OperatorExample(
                input_df=dict(
                    text=[
                        "This text\u00A0contains\u2001non-default\u2005whitespace\u2007characters"
                    ]
                ),
                kwargs=dict(fields=["text"], output_field_suffix="_normalized"),
            )
        ]

    def _compute_features(
        self,
        input_df: pd.DataFrame,
        callback: OpProgressCallback = no_op_progress_callback,
    ) -> pd.DataFrame:
        """Override base class method"""

        def normalize_whitespace(s: Any) -> Any:
            return str(s).translate(str.maketrans(self.trans))  # type: ignore

        for field in self.fields:
            input_df[self.output_field(field)] = input_df[field].apply(
                normalize_whitespace
            )

        return input_df
