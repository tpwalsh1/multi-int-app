from collections import defaultdict
from typing import Any, Dict, Optional

from postgres_utils.pool import connection, out_of_request_db_connection
from postgres_utils.query import fetchall
from snorkelflow.serialization.code_asset import deserialize_asset


# TODO: come up a more performant approach to manage operators cache. Currently there
# are not many UDFs so scan + deserialization is not very expensive.
# 1. add a state column(to track deleted operators) in dim_operators and track last
# updated time to prevent full db scan;
# 2. use a global cache shared by tdm workers and engine workers
def _fetch_operator_classes(
    conn: connection, workspace_uid: Optional[int]
) -> Dict[int, Dict[str, Any]]:
    with conn:
        class_operators = fetchall(
            conn,
            """
            SELECT name, op_config, workspace_uid
            FROM dim_operators
            WHERE is_class=True
            AND CASE
                WHEN %(workspace_uid)s IS NOT NULL
                THEN workspace_uid = %(workspace_uid)s
                ELSE TRUE
            END
            """,
            dict(workspace_uid=workspace_uid),
            use_dict_cur=True,
        )
        ret: Dict[int, Dict[str, Any]] = defaultdict(dict)
        for cls_op in class_operators:
            cls_asset = deserialize_asset(cls_op["op_config"]["f"])
            ret[cls_op["workspace_uid"]][cls_op["name"]] = cls_asset
        return ret


def fetch_operator_classes(
    workspace_uid: Optional[int], conn: Optional[connection]
) -> Dict[int, Dict[str, Any]]:
    if conn is None:
        with out_of_request_db_connection() as conn:
            return _fetch_operator_classes(conn, workspace_uid)
    else:
        return _fetch_operator_classes(conn, workspace_uid)
