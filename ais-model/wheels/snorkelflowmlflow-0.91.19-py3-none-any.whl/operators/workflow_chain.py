from sqlite3 import NotSupportedError

from snorkelflow.operators.operator import ColSchema, Operator


class WorkflowChain(Operator):
    is_deprecated: bool = True

    def __init__(self, data_schema: ColSchema, package_dir: str):
        raise NotSupportedError("WorkflowChain is no longer supported")
