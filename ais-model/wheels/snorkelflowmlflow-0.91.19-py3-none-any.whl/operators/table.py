from typing import Optional

import pandas as pd

from snorkelflow.operators.featurizer import Featurizer, OpProgressCallback
from snorkelflow.operators.operator import ColSchema
from snorkelflow.operators.table import Table


class TableConverter(Featurizer):
    """Feautizer that convert an array of dicts into a custom Table object

    Parameters
    ----------
    field
        A field of array of dicts to cast to a Table type
    output_field_suffix
        (Optional) To avoid updating in place.
    """

    def __init__(self, field: str, output_field_suffix: str = ""):
        self.field = field
        self.output_field_suffix = output_field_suffix
        self.output_field = f"{self.field}{self.output_field_suffix}"

    @property
    def input_schema(self) -> ColSchema:
        return {self.field: object}

    @property
    def output_schema(self) -> ColSchema:
        return {self.output_field: Table}

    def _compute_features(
        self, df: pd.DataFrame, callback: Optional[OpProgressCallback] = None
    ) -> pd.DataFrame:
        """Convert"""
        df[self.output_field] = df[self.field].apply(Table)
        return df
