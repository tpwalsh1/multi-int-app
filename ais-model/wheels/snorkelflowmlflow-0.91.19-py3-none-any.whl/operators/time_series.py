import json
import os
import pickle
from typing import Any, Dict, List, Optional, Union

import numpy as np
import pandas as pd
from sklearn.neural_network import MLPRegressor

from api_utils.exceptions import UserInputError
from file_utils.core import open_file
from snorkelflow.extraction.span import SpanCols
from snorkelflow.operators.candidates import SpanFeaturizer, SpanFeaturizerExtractor
from snorkelflow.operators.featurizer import Featurizer, OpProgressCallback
from snorkelflow.operators.operator import (
    ColSchema,
    get_operator_data_dir,
    no_op_progress_callback,
)
from snorkelflow.serialization.serializable import TimeSeriesValues
from snorkelflow.types.columns import TimeSeriesCols
from snorkelflow.utils.file import resolve_data_path

ts_feature_funcs = {
    "dayofyear": lambda x: x.dayofyear,
    "dayofweek": lambda x: x.dayofweek,
    "year": lambda x: x.year,
    "month": lambda x: x.month,
    "day": lambda x: x.day,
    "hour": lambda x: x.hour,
    "minute": lambda x: x.minute,
}


class TimeSeriesDifferencing(Featurizer):
    """Featurizer that calculates the 1st order difference of time-series. The beginning of the series will be zero-padded.

    Parameters
    ----------
    field
        A numeric field to calculate 1st order difference
    output_field_suffix
        (Optional) To avoid updating in place.
    """

    def __init__(
        self, field: str = TimeSeriesCols.VALUE_COL, output_field_suffix: str = ""
    ):
        self.field = field
        self.output_field = f"diff_1{output_field_suffix}"

    @property
    def input_schema(self) -> ColSchema:
        return {self.field: float}

    @property
    def output_schema(self) -> ColSchema:
        return {self.output_field: float}

    def _compute_features(
        self, df: pd.DataFrame, callback: Optional[OpProgressCallback] = None
    ) -> pd.DataFrame:
        """Calculate the (relative) difference between the current and the immediate past values."""
        # NOTE:
        # Assumes that the dataframe is sorted - fill 0 for nans
        diff_values = df.loc[:, self.field].diff()
        # Zero-pad the beginning of the series.
        diff_values[0] = 0
        df[self.output_field] = diff_values
        return df


class TimestampFeatureExtractor(Featurizer):
    """Feautizer that extracts the following time features from a timestamp: day of year, day of week, year, month, day, hour, and minute

    Parameters
    ----------
    field
        A timestamp field to extract features from
    output_field_suffix
        (Optional) To avoid updating in place.
    """

    def __init__(
        self, field: str = TimeSeriesCols.TIMESTAMP_COL, output_field_suffix: str = ""
    ):
        self.field = field
        self.output_field_suffix = output_field_suffix

    @property
    def input_schema(self) -> ColSchema:
        return {self.field: object}

    @property
    def output_schema(self) -> ColSchema:
        return {f"{feat}{self.output_field_suffix}": float for feat in ts_feature_funcs}

    def _compute_features(
        self, df: pd.DataFrame, callback: Optional[OpProgressCallback] = None
    ) -> pd.DataFrame:
        """Extracts features from a timestamp"""
        if not pd.core.dtypes.common.is_datetime_or_timedelta_dtype(df[self.field]):
            raise ValueError(
                f"Selected field: {self.field} is not a valid timestamp column"
            )
        for feat, feat_func in ts_feature_funcs.items():
            df[f"{feat}{self.output_field_suffix}"] = df[self.field].apply(feat_func)
        return df


class TimeSeriesSlidingWindow(Featurizer):
    """Featurizer that adds past values to the current data point. They are padded with NaN where past values do not exist.

    Parameters
    ----------
    field
        A numeric field to extract lag values
    pre_steps
        The number of past values to add
    output_field_suffix
        (Optional) To avoid updating in place.
    """

    def __init__(
        self,
        field: str = TimeSeriesCols.VALUE_COL,
        pre_steps: int = 10,
        output_field_suffix: str = "",
    ):
        if pre_steps < 0:
            err_msg = f"Pre steps input in TimeSeriesSlidingWindow must be >= 0, found {pre_steps}"
            raise UserInputError(detail=err_msg, user_friendly_message=err_msg)
        self.pre_steps = pre_steps
        self.field = field
        self.output_field_suffix = output_field_suffix

    @property
    def input_schema(self) -> ColSchema:
        return {
            self.field: float,
            TimeSeriesCols.ARRAY_IDX: int,
            TimeSeriesCols.DOC_ARRAY_COL: list,
        }

    @property
    def output_schema(self) -> ColSchema:
        return {
            **self._output_schema_lags,  # type: ignore
            TimeSeriesCols.ARRAY_IDX: int,
            TimeSeriesCols.DOC_ARRAY_COL: object,
        }

    @property
    def _output_schema_lags(self) -> ColSchema:
        # Sort column names in chronological order
        # Zero-pad the names so that they are sorted properly in the front-end
        n = len(str(self.pre_steps))
        return {
            f"lag_{str(self.pre_steps - k).zfill(n)}{self.output_field_suffix}": float
            for k in range(self.pre_steps)
        }

    def _compute_features(
        self, df: pd.DataFrame, callback: Optional[OpProgressCallback] = None
    ) -> pd.DataFrame:
        for col_name in self._output_schema_lags:
            shift_val = int(col_name.split("_")[1])
            df[col_name] = df.loc[:, self.field].shift(shift_val)
        # Discard the full time series to keep the Studio dataset small.
        # Note that any featurizer that uses it should be placed before this featurizer.
        df[TimeSeriesCols.DOC_ARRAY_COL] = [[]] * df.shape[0]
        return df


class TimeSeriesFeaturizer(SpanFeaturizer):
    """A SpanFeaturizer which maps a time series DataFrame into list of Span candidates."""

    @property
    def output_schema(self) -> Optional[ColSchema]:
        parent_output_schema = super().output_schema
        if parent_output_schema is None:
            raise ValueError("Parent output schema is found none")
        # HACK: Change the type of SPAN_TEXT to int because it holds a numerical value
        span_schema = self.get_suffixed_dict({SpanCols.SPAN_TEXT: float})
        parent_output_schema.update(span_schema)  # type: ignore
        added_output_schema = self.get_suffixed_dict(
            {
                TimeSeriesCols.TIMESTAMP: object,
                TimeSeriesCols.ARRAY_IDX: object,
                TimeSeriesCols.VALUE_COL: object,
            }
        )
        assert added_output_schema is not None  # mypy
        return {**parent_output_schema, **added_output_schema}

    def extract_span_list_from_row(
        self, datapoint_uid: str, row: pd.Series
    ) -> List[Dict[str, Any]]:
        """Return a list of time series Span candidates from the given row's fields"""
        spans = []
        content_array = TimeSeriesValues.deserialize(row[self.field])
        # Set the index for the current span in the json
        array_idx = 0
        char_position = 1
        for value_json in content_array:
            value = json.loads(value_json)
            timestamp = pd.Timestamp(value[TimeSeriesCols.TIMESTAMP_COL])
            spans.append(
                dict(
                    span_text=float(value[TimeSeriesCols.VALUE_COL]),
                    span_field=self.field,
                    span_field_value_hash=str(timestamp),
                    span_entity=None,
                    initial_label=value[TimeSeriesCols.LABEL_COL]
                    if TimeSeriesCols.LABEL_COL in value
                    else -1,
                    char_start=char_position,
                    char_end=char_position + len(value_json) - 1,
                    array_idx=array_idx,
                    timestamp=timestamp,
                    value=value[TimeSeriesCols.VALUE_COL],
                )
            )
            array_idx += 1
            char_position += len(value_json) + 2  # for comma + space
        return spans


class TimeSeriesExtractor(SpanFeaturizerExtractor, TimeSeriesFeaturizer):
    """A SpanExtractor which maps a time series DataFrame into Span candidates."""

    @property
    def output_schema(self) -> Optional[ColSchema]:
        parent_output_schema = super().output_schema
        if parent_output_schema is None:
            raise ValueError("Parent output schema is found none")
        # HACK: Change the type of SPAN_TEXT to int because it holds a numerical value
        span_schema = self.get_suffixed_dict({SpanCols.SPAN_TEXT: float})
        parent_output_schema.update(span_schema)  # type: ignore
        added_output_schema = self.get_suffixed_dict(
            {
                TimeSeriesCols.TIMESTAMP: object,
                TimeSeriesCols.ARRAY_IDX: int,
                TimeSeriesCols.VALUE_COL: float,
            }
        )
        assert added_output_schema is not None  # mypy
        return {**parent_output_schema, **added_output_schema}

    def extract_span_list_from_row(
        self, datapoint_uid: str, row: pd.Series
    ) -> List[Dict[str, Any]]:
        return TimeSeriesFeaturizer.extract_span_list_from_row(self, datapoint_uid, row)


class TimeSeriesSklearnAutoregressiveModel:
    """A model that predicts the next value in a time series based on the past values."""

    def __init__(
        self,
        num_past_values: int = 10,
        ignore_recent: int = 5,
        hidden_sizes: Optional[List[int]] = None,
        random_state: Union[int, None] = 0,
    ):
        self.num_past_values = num_past_values
        self.ignore_recent = ignore_recent
        self.hidden_sizes = hidden_sizes or (12, 12)
        self.model = MLPRegressor(
            hidden_layer_sizes=self.hidden_sizes,
            max_iter=1000,
            random_state=random_state,
        )

    def featurize_array(self, raw_time_series: np.ndarray) -> np.ndarray:
        """Featurize so each datapoint has num_past_values past
        values except for ignore_recent recent values.
        """
        k, c = self.num_past_values, self.ignore_recent
        raw_time_series = np.pad(raw_time_series, (k, 0), mode="edge")
        n = raw_time_series.shape[0]
        stride = 1
        data = np.zeros((n - k, (k - c) // stride))
        labels = np.zeros((n - k,))
        for i in range(0, n - k):
            data[i] = raw_time_series[i : i + k - c : stride]
            labels[i] = raw_time_series[i + k]
        return data, labels

    def fit(self, array: np.ndarray) -> None:
        """Fit the model to the given time series."""
        data, labels = self.featurize_array(array)
        self.model.fit(data, labels)

    def predict(self, array: np.ndarray) -> np.ndarray:
        """Predict the next value in the time series."""
        data, labels = self.featurize_array(array)
        preds = self.model.predict(data)
        return preds


def _get_file_name(k: int, c: int) -> str:
    return f"timeseries_self_supervised_{k}_{c}"


def _get_file_path(dirpath: str, k: int, c: int) -> str:
    return resolve_data_path(os.path.join(dirpath, f"{_get_file_name(k, c)}.pickle"))


class TimeSeriesSelfSupervisedForecasters(Featurizer):
    """
    A featurizer which uses many time series models to predict the next value in a time series.

    For fitting, field should refer to the field with time series values.
    """

    # TODO: eventually add option to perform fitting on just the dev set to reduce customer confusion.
    start_k: int = 5
    end_k: int = 400
    num_k: int = 3
    start_c: int = 1
    end_c: int = 20
    num_c: int = 3
    artifact_config_keys = ["dirpath"]

    def __init__(self, field: str, dirpath: str) -> None:
        self.field = field
        self.dirpath = dirpath
        if dirpath == "" or dirpath is None:
            err_msg = (
                "Dirpath input in TimeSeriesSelfSupervisedForecasters cannot be empty"
            )
            raise UserInputError(detail=err_msg, user_friendly_message=err_msg)
        self.dirpath = dirpath

    @classmethod
    def _fit(cls, df: pd.DataFrame, field: str) -> Dict[str, Any]:  # type: ignore
        time_series = df[field].fillna(method="ffill")
        dirpath = get_operator_data_dir()

        # TODO: restructure code so the for loops can be reused in the other functions.
        for k in np.geomspace(cls.start_k, cls.end_k, num=cls.num_k):
            for c in np.geomspace(cls.start_c, min(cls.end_c, k - 1), num=cls.num_c):
                k_int = int(k)
                c_int = int(c)

                model = TimeSeriesSklearnAutoregressiveModel(k_int, c_int)
                model.fit(time_series)

                predict_path = _get_file_path(dirpath, k_int, c_int)

                # create path if it doesn't exist
                os.makedirs(os.path.dirname(predict_path), exist_ok=True)

                with open(predict_path, "wb") as f:
                    pickle.dump(model, f)

        kwargs = {"field": field, "dirpath": dirpath}
        return kwargs

    @classmethod
    def _fit_input_schema(cls, field: str) -> ColSchema:  # type: ignore
        return {field: float}

    @property
    def input_schema(self) -> ColSchema:
        return {self.field: float}

    @property
    def output_schema(self) -> ColSchema:
        output_dict: Dict[str, Union[type, Any, None]] = {}
        for k in np.geomspace(self.start_k, self.end_k, num=self.num_k):
            for c in np.geomspace(self.start_c, min(self.end_c, k - 1), num=self.num_c):
                output_dict[_get_file_name(int(k), int(c))] = float
        return output_dict

    def _compute_features(
        self,
        input_df: pd.DataFrame,
        callback: OpProgressCallback = no_op_progress_callback,
    ) -> pd.DataFrame:
        """Override base class method"""
        time_series = input_df[self.field].fillna(method="ffill")
        for k in np.geomspace(self.start_k, self.end_k, num=self.num_k):
            for c in np.geomspace(self.start_c, min(self.end_c, k - 1), num=self.num_c):
                k_int = int(k)
                c_int = int(c)

                predict_path = _get_file_path(self.dirpath, k_int, c_int)
                with open_file(predict_path, "rb") as f:
                    model = pickle.load(f)

                preds = model.predict(time_series)
                input_df[_get_file_name(k_int, c_int)] = preds
        return input_df


class TimeSeriesMovingAverageFeaturizer(Featurizer):
    """A featurizer that adds a simple moving average (SMA) of the given number of past values

    Parameters
    ----------
    field
        A numeric field to calculate the simple moving average
    pre_steps
        The number of past values to include in the moving average
    """

    def __init__(
        self, field: str = TimeSeriesCols.VALUE_COL, pre_steps: int = 2
    ) -> None:
        self.field = TimeSeriesCols.VALUE_COL
        if pre_steps <= 0:
            err_msg = f"Pre steps input in TimeSeriesMovingAverageFeaturizer must be > 0, found {pre_steps}"
            raise UserInputError(detail=err_msg, user_friendly_message=err_msg)
        self.pre_steps = pre_steps
        self.field = field
        self.output_field = f"ma_{pre_steps}"

    @property
    def input_schema(self) -> ColSchema:
        return {self.field: float}

    @property
    def output_schema(self) -> ColSchema:
        return {self.output_field: float}

    def _compute_features(
        self, df: pd.DataFrame, callback: Optional[OpProgressCallback] = None
    ) -> pd.DataFrame:
        """Override base class method"""
        # Pad with 0 since there is no rolling average available for the first point
        padded_values = pd.Series([0]).append(df.loc[:, self.field])
        ma_values = (
            padded_values.fillna(0).rolling(self.pre_steps, min_periods=1).mean()
        )
        # Extract up to the last value for the MA values since it contain MA for the last point
        ma_values = ma_values.values[:-1]
        # Replace with 0 since there is no rolling average available for the first point
        ma_values[0] = 0
        df[self.output_field] = ma_values
        return df
