"""Built-in Operators.

Built-in operators are available in the full SDK and can be programmatically added to the DAG like below:

.. testcode::

    # Add the operator to the DAG
    sf.add_node(
        application=APP_NAME,
        input_node_uids=[123],
        output_node_uid=456,
        op_type="ColumnRenamer",
        op_config={"column_map": {"body": "email-body"}},
    )

Featurizers
===========

Text-based
**********

.. autosummary::
    :toctree: _autosummary
    :template: custom-class-template-operators.rst

    operators.truncate.TruncatePreprocessor
    operators.candidates.span_preview.SpanPreviewPreprocessor
    operators.whitespace.WhitespacePreprocessor
    operators.spacy.SpacyPreprocessor
    operators.spacy.SpacyTokenizer
    operators.spacy.NounChunkFeaturizer
    operators.spacy.VerbPhraseFeaturizer
    operators.spacy.SentenceFeaturizer
    operators.embedding.EmbeddingFeaturizer
    operators.embedding.EmbeddingCandidateFeaturizer
    operators.special_char.AsciiCharFilter
    operators.special_char.LatinCharFilter
    operators.candidates.context.ContextAggregator
    operators.candidates.extractor.EmptySpanFeaturizer
    operators.candidates.extractor.RegexSpanFeaturizer
    operators.candidates.extractor.DateSpanFeaturizer
    operators.candidates.extractor.ParagraphSpanFeaturizer
    operators.candidates.extractor.NumericSpanFeaturizer
    operators.candidates.extractor.EmailAddressSpanFeaturizer
    operators.candidates.extractor.USCurrencySpanFeaturizer
    operators.candidates.extractor.HardCodedSpanFeaturizer
    operators.candidates.extractor.SpansFileFeaturizer
    operators.candidates.extractor.EntityDictSpanFeaturizer
    operators.candidates.extractor.EntityDictRegexSpanFeaturizer
    operators.candidates.extractor.DocEntityDictSpanFeaturizer
    operators.candidates.extractor_spacy.TokenSpanFeaturizer
    operators.candidates.extractor_spacy.NounChunkSpanFeaturizer
    operators.candidates.extractor_spacy.TagSpanFeaturizer
    operators.candidates.extractor_spacy.SpacyNERSpanFeaturizer

PDF-based
*********

.. autosummary::
    :toctree: _autosummary
    :template: custom-class-template-operators.rst

    operators.pdf.parser.PDFToRichDocParser
    operators.candidates.rich_doc_page.RichDocPagePreprocessor
    operators.candidates.rich_doc_features.RichDocRegexNGramDetector
    operators.candidates.rich_doc_features.RichDocRegexPageFeaturizer
    operators.candidates.rich_doc_features.RichDocSpanBaseFeaturesPreprocessor
    operators.candidates.rich_doc_features.RichDocSpanRowFeaturesPreprocessor
    operators.candidates.rich_doc_features.RichDocSpanStructuralPreprocessor
    operators.candidates.rich_doc_features.RichDocSpanVisualPreprocessor
    operators.pdf.page_splitter.PageSplitter
    operators.document_layout.DocumentLayoutFeaturizer
    operators.row_filter.TableRowFilter
    operators.pdf.truncate_pdf.TruncatePDF
    operators.pdf.lines.LinesFeaturizer
    operators.pdf.lines.LinesPageFilterFeaturizer
    operators.pdf.hocr.HocrToRichDocParser
    operators.pdf.hocr.TruncateHOCR
    operators.pdf.text_cluster.TextClusterer
    operators.pdf.text_cluster.TextClusterSpanFeaturizer
    operators.pdf.text_cluster.TextClusterSpanExtractor

OCR
***

.. autosummary::
    :toctree: _autosummary
    :template: custom-class-template-operators.rst

    operators.ocr.tesseract_featurizer.TesseractFeaturizer
    operators.azure.azure_form_recognizer_parser.AzureFormRecognizerParser

Filters
=======

.. autosummary::
    :toctree: _autosummary
    :template: custom-class-template-operators.rst

    operators.filter.LabelIntFilter
    operators.filter.LabelFilter
    operators.row_filter.BooleanColumnBasedRowFilter
    operators.row_filter.PandasQueryFilter
    operators.row_filter.TextSizeFilter
    operators.row_filter.RegexRowFilter
    operators.candidates.filter.RegexSpanFilter
    operators.candidates.filter.ExtractedSpanFilter

Extractors
==========

.. autosummary::
    :toctree: _autosummary
    :template: custom-class-template-operators.rst

    operators.candidates.extractor.ListToRowsExploder
    operators.candidates.extractor.EmptySpanExtractor
    operators.candidates.extractor.RegexSpanExtractor
    operators.candidates.extractor.DateSpanExtractor
    operators.candidates.extractor.ParagraphSpanExtractor
    operators.candidates.extractor.NumericSpanExtractor
    operators.candidates.extractor.EmailAddressSpanExtractor
    operators.candidates.extractor.USCurrencySpanExtractor
    operators.candidates.extractor.HardCodedSpanExtractor
    operators.candidates.extractor.SpansFileExtractor
    operators.candidates.extractor.EntityDictSpanExtractor
    operators.candidates.extractor.EntityDictRegexSpanExtractor
    operators.candidates.extractor.DocEntityDictSpanExtractor
    operators.candidates.extractor_spacy.TokenSpanExtractor
    operators.candidates.extractor_spacy.NounChunkSpanExtractor
    operators.candidates.extractor_spacy.TagSpanExtractor
    operators.candidates.extractor_spacy.SpacyNERSpanExtractor

Normalizers/linkers
===================

.. autosummary::
    :toctree: _autosummary
    :template: custom-class-template-operators.rst

    operators.candidates.normalizer.DateSpanNormalizer
    operators.candidates.normalizer.USCurrencySpanNormalizer
    operators.candidates.normalizer.TextCasingSpanNormalizer
    operators.candidates.normalizer.OrdinalSpanNormalizer
    operators.candidates.normalizer.NumericalSpanNormalizer
    operators.candidates.normalizer.SpanEntityNormalizer
    operators.candidates.normalizer.IdentitySpanNormalizer
    operators.candidates.linker.EntityDictLinker

Model postprocessors
====================

.. autosummary::
    :toctree: _autosummary
    :template: custom-class-template-operators.rst

    operators.post_processors.sequence_tagging_post_processors.SpanFilterByLengthPostProcessor
    operators.post_processors.sequence_tagging_post_processors.SpanMergeByRegexPatternPostProcessor
    operators.post_processors.sequence_tagging_post_processors.SpanMergeByNumberCharacterPostProcessor
    operators.post_processors.sequence_tagging_post_processors.SpanRegexPostProcessor
    operators.post_processors.sequence_tagging_post_processors.SpanRemoveWhitespacePostProcessor
    operators.post_processors.sequence_tagging_post_processors.SubstringExpansionPostProcessor

Reducers
========

.. autosummary::
    :toctree: _autosummary
    :template: custom-class-template-operators.rst

    operators.candidates.reducer.IdentityReducer
    operators.candidates.reducer.DocumentFirstReducer
    operators.candidates.reducer.DocumentLastReducer
    operators.candidates.reducer.DocumentMostConfidentReducer
    operators.candidates.reducer.DocumentMostCommonReducer
    operators.candidates.reducer.EntityMeanPredictionReducer
    operators.candidates.reducer.EntityMostCommonReducer
    operators.candidates.reducer.EntityMostConfidentReducer
    operators.candidates.reducer.EntityFirstReducer
    operators.candidates.reducer.EntityLastReducer

Miscellaneous
=============

.. autosummary::
    :toctree: _autosummary
    :template: custom-class-template-operators.rst

    operators.rename.ColumnRenamer
    operators.drop.ColumnDropper
    operators.concat.ConcatRows
    operators.concat.ConcatColumns
    operators.change_datapoint.ChangeDatapoint
    operators.table.TableConverter
    operators.identity.IdentityOperator
    operators.scaler.StandardScaler
    operators.filler.ColumnFiller
"""
