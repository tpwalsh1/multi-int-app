from typing import Dict, List, Optional, Type

import dask.dataframe as dd
import pandas as pd

from api_utils.exceptions import UserInputError
from operators.types import DataframeMultiFieldType
from snorkelflow.operators.operator import (
    ColSchema,
    Operator,
    df_operator_error_wrapper,
)
from snorkelflow.types.load import DATAPOINT_UID_COL
from snorkelflow.utils.datapoint import (
    DATAPOINT_TYPES,
    DatapointType,
    get_datapoint_cls,
)


class ChangeDatapoint(Operator):
    """Preprocessor that changes the datapoint type/columns.

    Parameters
    ----------
    datapoint_type
        The new datapoint type.
    datapoint_cols
        The new datapoint columns.
    sorted
        Whether the dataframe will already be sorted after the change.
        Is overwritten to true if changing only the datapoint type.
    """

    def __init__(
        self,
        datapoint_type: str,
        datapoint_cols: Optional[DataframeMultiFieldType] = None,
        sorted: bool = False,
    ) -> None:
        self.datapoint_type = get_datapoint_cls(datapoint_type)
        # datapoint_cols = [] if no columns are selected
        self.datapoint_cols = datapoint_cols or None
        self.sorted = sorted

    @staticmethod
    def get_options() -> Dict[str, List[str]]:
        return dict(datapoint_type=list(DATAPOINT_TYPES.keys()))

    @property
    def input_schema(self) -> ColSchema:
        return {}

    @property
    def output_schema(self) -> ColSchema:
        return {}

    def get_datapoint_type(
        self, input_datapoint_types: List[Type[DatapointType]]
    ) -> Type[DatapointType]:
        return self.datapoint_type

    def get_datapoint_cols(self, input_datapoint_cols: List[List[str]]) -> List[str]:
        if self.datapoint_cols:
            return self.datapoint_cols
        return super().get_datapoint_cols(input_datapoint_cols)

    def _execute(self, input_ddfs: List[dd.DataFrame]) -> dd.DataFrame:
        ddf = input_ddfs[0]
        is_dask_set_index_avoided = self.datapoint_cols is None and all(
            x is not None for x in ddf.divisions
        )
        if self.datapoint_cols:
            for col in self.datapoint_cols:
                if col not in ddf.columns:
                    raise UserInputError(
                        f"{col} not found in dataframe but specified in datapoint_cols",
                        user_friendly_message=f"Missing column {col}",
                    )

        def map_fn(df: pd.DataFrame) -> pd.DataFrame:
            if df.empty:
                df = df.assign(DATAPOINT_UID_COL=None)
            elif not self.datapoint_cols:
                df[DATAPOINT_UID_COL] = [
                    _datapoint_uid_with_changed_type(x, self.datapoint_type)
                    for x in df.index
                ]
            else:
                datapoint_cols = self.datapoint_cols
                example_datapoint_uid = df.index[0]
                datapoint_type = (
                    self.datapoint_type
                    or DatapointType.get_datapoint_type(example_datapoint_uid)
                )
                datapoint_instance = datapoint_type(datapoint_cols)
                df[DATAPOINT_UID_COL] = datapoint_instance.get_datapoint_uid_col_pandas(
                    df
                )

            if is_dask_set_index_avoided:
                df = df.set_index(DATAPOINT_UID_COL)

            return df

        meta = (
            ddf
            if is_dask_set_index_avoided
            else {**ddf.dtypes.to_dict(), DATAPOINT_UID_COL: str}
        )
        output_ddf = dd.map_partitions(
            df_operator_error_wrapper(map_fn, self.__class__.__name__), ddf, meta=meta
        )

        # Set the index/divisions
        if is_dask_set_index_avoided:
            output_ddf.divisions = tuple(
                [
                    _datapoint_uid_with_changed_type(x, self.datapoint_type)
                    for x in output_ddf.divisions
                ]
            )
        else:
            # note that we could pass in divisions manually here only if we knew that
            # the old datapoint cols are prefix of the new ones. We can't know this
            # information without having a flag for that the user could set.
            output_ddf = output_ddf.set_index(DATAPOINT_UID_COL, sorted=self.sorted)

        return output_ddf


def _datapoint_uid_with_changed_type(
    datapoint_uid: str, datapoint_type: Type[DatapointType]
) -> str:
    return datapoint_type.name + "::" + datapoint_uid.split("::", 1)[1]
