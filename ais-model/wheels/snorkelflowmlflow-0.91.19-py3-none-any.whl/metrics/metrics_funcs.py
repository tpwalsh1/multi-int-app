from typing import Any, Callable, Dict, List, NamedTuple, Optional, Tuple

import numpy as np
import sklearn.metrics as skmetrics

from label_utils import filter_labels

from .utils import to_int_label_array

START = "start"
END = "end"
PRED_END_ACCEPTABLE = "end_pred"
TOL_AFTER = 3  # number of timesteps of lenience after the GT anomaly


class Metric(NamedTuple):
    """Specification for a metric and the subset of [golds, preds, probs] it expects."""

    func: Callable[..., float]
    inputs: List[str] = ["golds", "preds"]


def metric_score(
    golds: np.ndarray,
    preds: Optional[np.ndarray] = None,
    probs: Optional[np.ndarray] = None,
    metric: str = "accuracy",
    filter_dict: Optional[Dict[str, List[int]]] = None,
    **kwargs: Any,
) -> float:
    """Evaluate a standard metric on a set of predictions/probabilities.

    Parameters
    ----------
    golds
        An array of gold (int) labels
    preds
        An array of (int) predictions
    probs
        An [n_datapoints, n_classes] array of probabilistic (float) predictions
    metric
        The name of the metric to calculate
    filter_dict
        A mapping from label set name to the labels that should be filtered out for
        that label set

    Returns
    -------
    float
        The value of the requested metric

    Raises
    ------
    ValueError
        The requested metric is not currently supported
    ValueError
        The user attempted to calculate roc_auc score for a non-binary problem
    """
    if metric not in METRICS:
        msg = f"The metric you provided ({metric}) is not currently implemented."
        raise ValueError(msg)

    # Workaround for the fact that metrics does not support multi-label spaces
    # TODO: integrate label spaces here (https://snorkelai.atlassian.net/browse/ENG-14532)
    # We should be using an associated label space to retrieve abstain labels, filter, format target variables etc

    if golds.ndim == 1:
        # Print helpful error messages if golds or preds has invalid shape or type
        golds = to_int_label_array(golds) if golds is not None else None

        # Optionally filter out examples (e.g., abstain predictions or unknown labels), only including point-predictions
        # and associated filtering when the metric is not the full data log-likelihood.
        preds = (
            to_int_label_array(preds)
            if (preds is not None and metric != "log_likelihood")
            else None
        )

    label_dict = {"golds": golds, "preds": preds, "probs": probs}

    if filter_dict:
        if set(filter_dict.keys()).difference(set(label_dict.keys())):
            raise ValueError(
                "filter_dict must only include keys in ['golds', 'preds', 'probs']"
            )
        # mypy doesn't like assigning Dict[str, np.ndarray] to Dict[str, Optional[np.ndarray]]
        label_dict = filter_labels(label_dict, filter_dict)  # type: ignore

    # Confirm that required label sets are available
    func, label_names = METRICS[metric]
    for label_name in label_names:
        if label_dict[label_name] is None:
            raise ValueError(f"Metric {metric} requires access to {label_name}.")

    label_sets = [label_dict[label_name] for label_name in label_names]
    return func(*label_sets, **kwargs)


def _coverage_score(preds: np.ndarray) -> float:
    return np.sum(preds != -1) / len(preds)


def _roc_auc_score(golds: np.ndarray, probs: np.ndarray) -> float:
    if not probs.shape[1] == 2:
        raise ValueError(
            "Metric roc_auc is currently only defined for binary problems."
        )
    return skmetrics.roc_auc_score(golds, probs[:, 1])


def _f1_score(golds: np.ndarray, preds: np.ndarray) -> float:
    if golds.max() <= 1:
        return skmetrics.f1_score(golds, preds)
    else:
        raise ValueError(
            "f1 not supported for multiclass. Try f1_micro or f1_macro instead."
        )


def _recall_micro_score(golds: np.ndarray, preds: np.ndarray) -> float:
    return skmetrics.recall_score(golds, preds, average="micro")


def _recall_macro_score(golds: np.ndarray, preds: np.ndarray) -> float:
    return skmetrics.recall_score(golds, preds, average="macro")


def _f1_micro_score(golds: np.ndarray, preds: np.ndarray) -> float:
    return skmetrics.f1_score(golds, preds, average="micro")


def _f1_macro_score(golds: np.ndarray, preds: np.ndarray) -> float:
    return skmetrics.f1_score(golds, preds, average="macro")


def _precision_micro_score(golds: np.ndarray, preds: np.ndarray) -> float:
    return skmetrics.precision_score(golds, preds, average="micro")


def _precision_macro_score(golds: np.ndarray, preds: np.ndarray) -> float:
    return skmetrics.precision_score(golds, preds, average="macro")


def _top_k_accuracy_score(golds: np.ndarray, probs: np.ndarray, k: int = 2) -> float:
    """Top-k Accuracy classification score.

    This metric computes the number of times where the correct label is among
    the top k labels predicted (ranked by predicted scores). Note that the
    multilabel case isn't covered here.

    Source: https://github.com/scikit-learn/scikit-learn/blob/662cc647d93117d7a76b51fc5778147bc49cbf29/sklearn/metrics/_ranking.py#L1572

    Parameters
    ----------
    golds
        An array of gold (int) labels
    probs
        An [n_datapoints, n_classes] array of probabilistic (float) predictions

    Returns
    -------
    float
        The top-k accuracy score

    Raises
    ------
    ValueError
        Shape of 'golds' and 'probs' is inconsistent
    ValueError
        Number of classes in 'golds' is not equal to the number of classes in 'probs'
    """

    # Check inconsistent number of classes
    probs_classes = probs.shape[1]
    if max(golds) >= probs_classes:
        raise ValueError(
            f"Number of classes in 'golds' ({max(golds)}) is greater than the number of classes in 'probs' ({probs_classes})"
        )

    if probs_classes == 2:  # Binary classification
        if k == 1:  # Compute accuracy
            threshold = 0.5
            preds = (probs > threshold).astype(int)
            hits = preds == golds
        else:  # Top 2 accuracy for binary classification will result in a perfect score
            hits = np.ones_like(probs, dtype=np.bool_)
    else:  # Multiclass classification
        sorted_pred = np.argsort(probs, axis=1)[:, ::-1]
        hits = (golds == sorted_pred[:, :k].T).any(axis=0)
    return np.average(hits)


def _top_3_accuracy_score(golds: np.ndarray, probs: np.ndarray) -> float:
    return _top_k_accuracy_score(golds, probs, k=3)


def _log_likelihood_score(golds: np.ndarray, probs: np.ndarray) -> float:
    return -skmetrics.log_loss(golds, probs, labels=np.arange(probs.shape[1]))


def _get_windows_helper(golds: np.ndarray) -> List[Dict[str, int]]:
    """Construct a list of windows, each of which contains contigous GT positive examples."""
    # Adapted from https://github.com/iopsai/iops/blob/c54baf95b0252287dfab0f620ca9ea8f535482da/evaluation/evaluation.py
    windows: List[Dict[str, int]] = []
    if len(golds) == 0:
        return windows
    # Get a list of splits, each of which indicates when a label flips from one to another.
    # E.g., golds=[0,0,1,1,0] then splits=>[2,4]
    splits = np.where(golds[1:] != golds[:-1])[0] + 1
    is_anomaly = golds[0] == 1
    pos = 0

    # Construct a list of windows for positive examples
    for sp in splits:
        if is_anomaly:
            windows.append(
                {START: pos, END: sp, PRED_END_ACCEPTABLE: pos + TOL_AFTER + 1}
            )
        is_anomaly = not is_anomaly
        pos = sp
    sp = len(golds)

    # Anomaly in the end
    if is_anomaly:
        windows.append({START: pos, END: sp, PRED_END_ACCEPTABLE: sp})

    return windows


def _adjust_preds(golds: np.ndarray, preds: np.ndarray) -> np.ndarray:
    """Adjust predictions by treating positive preds as TPs within TOL_AFTER from the first positive example.

    This is based on H. Ren et al., “Time-Series Anomaly Detection Service at Microsoft,” doi: 10.1145/3292500.3330680.
    We adapted this to customer requirements:
    1. The tolerance is 3 (ie TOL_AFTER)
    2. Positive predictions outside the anomaly window (ie contigous GT positive examples) are also adjusted.
    """
    # Keep a list of windows, each of which is a 2-long list of indices in golds that
    # represent the start (inclusive) and end (exclusive) of a window.
    windows = _get_windows_helper(golds)
    anomaly_idx_arr = np.full(len(preds), -1)
    for idx, window in enumerate(windows):
        start, end = window[START], window[PRED_END_ACCEPTABLE]
        # Set valid range for predictions
        anomaly_idx_arr[start:end] = idx
    new_preds = np.copy(preds)

    # Go through the positive predictions, finding a matching window for each.
    # This runs in O(n) time, where n denotes the number of positive predictions.
    windows_handled = set()
    for i in np.where(preds == 1)[0]:
        window_idx = anomaly_idx_arr[i]
        # Within a valid range
        if window_idx >= 0 and window_idx not in windows_handled:
            curr_window = windows[window_idx]
            start = curr_window[START]
            pred_end = curr_window[PRED_END_ACCEPTABLE]
            end = curr_window[END]
            # If the prediction is outside the anomaly range but within the valid pred range then adjust those to be negative
            if pred_end > end:
                # Outside the valid range - need to reset pred as 0
                new_preds[end:pred_end] = 0
            new_preds[start:end] = 1
            windows_handled.add(window_idx)
    return new_preds


def _anomaly_recall_score(golds: np.ndarray, preds: np.ndarray) -> float:
    """
    Computes the time series recall score.

    Parameters
    ----------
    golds
        An array of gold (int) labels that represent ground truth.
    preds
        An array of integer predictions from the model.

    Returns
    -------
    float
        The time series recall score.
    """
    adjusted_preds = _adjust_preds(golds, preds)
    return skmetrics.recall_score(golds, adjusted_preds)


def _anomaly_precision_score(golds: np.ndarray, preds: np.ndarray) -> float:
    """
    Computes the time series precision score.

    Parameters
    ----------
    golds
        An array of gold (int) labels that represent ground truth.
    preds
        An array of integer predictions from the model.

    Returns
    -------
    float
        The time series precision score.
    """
    adjusted_preds = _adjust_preds(golds, preds)
    return skmetrics.precision_score(golds, adjusted_preds)


def _anomaly_f1_score(golds: np.ndarray, preds: np.ndarray) -> float:
    """
    Computes the time series F1 score.

    Parameters
    ----------
    golds
        An array of gold (int) labels that represent ground truth.
    preds
        An array of integer predictions from the model.

    Returns
    -------
    float
        The time series F1 score.
    """
    adjusted_preds = _adjust_preds(golds, preds)
    return skmetrics.f1_score(golds, adjusted_preds)


def _jaccard_with_abstains(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    """Jaccard score averaged across samples, accounting for abstains (ignoring them)

    Args:
        y_true (np.ndarray): N x M array of GT for N samples and M labels
        y_pred (np.ndarray): N x M array of predicted labels

    Returns:
        float: average Jaccard score
    """

    y_true_non_abstain = y_true != -1
    y_pred_non_abstain = y_pred != -1
    non_abstain = np.logical_and(y_true_non_abstain, y_pred_non_abstain)
    non_abstain_count = non_abstain.sum(axis=1)
    samples_non_abstain = non_abstain_count > 0

    samesies = np.logical_and(y_true == y_pred, non_abstain).sum(axis=1)
    J = (
        samesies[samples_non_abstain]
        / (2 * non_abstain_count[samples_non_abstain] - samesies[samples_non_abstain])
    ).mean()

    return J


def _anomaly_f1_score_lm(
    golds: np.ndarray, preds_and_probs: Tuple[np.ndarray]
) -> float:
    """
    Computes the time series F1 score - for usage in Sklearn GridSearchCV

    Parameters
    ----------
    golds
        An array of gold (int) labels that represent ground truth.
    preds_and_probs
        A tuple of 2 elements, the first elem is a 1D array of integer predictions from the model
        the second elem is a 2D probability array

    Returns
    -------
    float
        The time series F1 score.
    """
    preds = preds_and_probs[0]
    adjusted_preds = _adjust_preds(golds, preds)
    return skmetrics.f1_score(golds, adjusted_preds)


def log_likelihood_lm(
    golds: np.ndarray, preds_and_probs: Tuple[np.ndarray, np.ndarray]
) -> float:
    """
    Computes the log likelihood score - for usage in Sklearn GridSearchCV

    Parameters
    ----------
    golds
        An array of gold (int) labels that represent ground truth.
    preds_and_probs
        A tuple of 2 elements, the first elem is a 1D array of integer predictions from the model
        the second elem is a 2D probability array

    Returns
    -------
    float
        The log likelihood.
    """
    probs = preds_and_probs[1]
    return -skmetrics.log_loss(golds, probs)


def accuracy_lm(golds: np.ndarray, preds_and_probs: Tuple[np.ndarray]) -> float:
    """
    Computes the accuracy score - for usage in Sklearn GridSearchCV

    Parameters
    ----------
    golds
        An array of gold (int) labels that represent ground truth.
    preds_and_probs
        A tuple of 2 elements, the first elem is a 1D array of integer predictions from the model
        the second elem is a 2D probability array

    Returns
    -------
    float
        The accuracy score.
    """
    preds = preds_and_probs[0]
    return skmetrics.accuracy_score(golds, preds)


# See https://scikit-learn.org/stable/modules/classes.html#module-sklearn.metrics
# for details on the definitions and available kwargs for all metrics from scikit-learn
METRICS = {
    "accuracy": Metric(skmetrics.accuracy_score),
    "accuracy_balanced": Metric(skmetrics.balanced_accuracy_score),
    "top_3_accuracy": Metric(_top_3_accuracy_score, ["golds", "probs"]),
    "log_likelihood": Metric(_log_likelihood_score, ["golds", "probs"]),
    "coverage": Metric(_coverage_score, ["preds"]),
    "precision": Metric(skmetrics.precision_score),
    "precision_micro": Metric(_precision_micro_score, ["golds", "preds"]),
    "precision_macro": Metric(_precision_macro_score, ["golds", "preds"]),
    "recall": Metric(skmetrics.recall_score),
    "recall_micro": Metric(_recall_micro_score, ["golds", "preds"]),
    "recall_macro": Metric(_recall_macro_score, ["golds", "preds"]),
    "f1": Metric(_f1_score, ["golds", "preds"]),
    "f1_micro": Metric(_f1_micro_score, ["golds", "preds"]),
    "f1_macro": Metric(_f1_macro_score, ["golds", "preds"]),
    "fbeta": Metric(skmetrics.fbeta_score),
    "matthews_corrcoef": Metric(skmetrics.matthews_corrcoef),
    "roc_auc": Metric(_roc_auc_score, ["golds", "probs"]),
    "anomaly_precision": Metric(_anomaly_precision_score, ["golds", "preds"]),
    "anomaly_recall": Metric(_anomaly_recall_score, ["golds", "preds"]),
    "anomaly_f1": Metric(_anomaly_f1_score, ["golds", "preds"]),
    "jaccard_with_abstains": Metric(_jaccard_with_abstains, ["golds", "preds"]),
}

LM_TUNING_METRICS_FUNC = {
    "accuracy": accuracy_lm,
    "log_likelihood": log_likelihood_lm,
    "anomaly_f1": _anomaly_f1_score_lm,
}
