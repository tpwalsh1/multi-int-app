import numpy as np


def to_int_label_array(X: np.ndarray, flatten_vector: bool = True) -> np.ndarray:
    """Convert an array to a (possibly flattened) array of ints.
    Cast all values to ints and possibly flatten [n, 1] arrays to [n].
    This method is typically used to sanitize labels before use with analysis tools or
    metrics that expect 1D arrays as inputs.
    Parameters
    ----------
    X
        An array to possibly flatten and possibly cast to int
    flatten_vector
        If True, flatten array into a 1D array
    Returns
    -------
    np.ndarray
        The converted array
    Raises
    ------
    ValueError
        Provided input could not be converted to an np.ndarray
    """
    if np.any(np.not_equal(np.mod(X, 1), 0)):
        raise ValueError("Input contains at least one non-integer value.")
    X = X.astype(np.dtype(int))
    # Correct shape
    if flatten_vector:
        X = X.squeeze()
        if X.ndim == 0:
            X = np.expand_dims(X, 0)
        if X.ndim != 1:
            raise ValueError("Input could not be converted to 1d np.array")
    return X
