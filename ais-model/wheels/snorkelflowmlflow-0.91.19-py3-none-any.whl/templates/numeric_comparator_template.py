from typing import List

import pandas as pd
from pydantic import ValidationError, validator

from snorkelflow.utils.logging import get_logger
from templates.constants import (
    TEMPLATE_FIELD1_FIELD_NAME,
    TEMPLATE_FIELD2_FIELD_NAME,
    TEMPLATE_OPERATER_FIELD_NAME,
    TEMPLATE_SCALE_FIELD_NAME,
    TEMPLATE_VALUE_FIELD_NAME,
)
from templates.utils import TemplateSchema, normalize_numeric

from .template import BASE_URL, NUMERIC_BASED, Template, TemplateConfig

logger = get_logger("Studio NumericComparatorTemplate")

SCALE_UNIT_NAME = "unit"
SCALE_PCT_NAME = "percentage"
ABS_DEVIATION = "+/-"
POS_DEVIATION = "+"
NEG_DEVIATION = "-"


OPERATORS = {
    POS_DEVIATION: lambda x, y: x >= y,
    ABS_DEVIATION: lambda x, y: abs(x) >= y,
    NEG_DEVIATION: lambda x, y: x <= -y,
}


SCALES = {
    SCALE_UNIT_NAME: lambda base, value: value,
    SCALE_PCT_NAME: lambda base, value: base * (value / 100),
}


class NumericComparatorTemplateSchema(TemplateSchema):
    """Numeric Comparator template

    Parameters
    ----------
    field_1 : str
        Field 1
    field_2 : str
        Field 2
    value : float
        Value
    operator : {"+/-", "+", "-"}
        Operator
    scale : {"unit", "percentage"}
        Scale
    """

    field_1: str
    field_2: str
    operator: str
    value: float
    scale: str

    @validator(TEMPLATE_OPERATER_FIELD_NAME)
    def check_operator(cls, op: str) -> str:
        if op not in OPERATORS.keys():
            raise ValueError("Invalid operator {op}")
        return op


class NumericComparatorTemplate(Template):

    """LF Template based on numeric comparisons between two fields"""

    template_type = "numerical_comparator"
    abbreviation = "NCOMP"
    description = (
        "If [field1] deviates[operator] from [field2] by [value][scale], then label."
    )
    menu_type = {
        "name": "Numeric Comparator Builder",
        "value": template_type,
        "category": [NUMERIC_BASED],
    }
    docs_link = BASE_URL + "numeric-comparator-builder-numerical-lfs"
    template_schema = "NumericComparatorTemplateSchema"

    def __init__(self, template_config: TemplateConfig) -> None:
        """LF Template based on numeric comparisons.

        Heuristic:
        "If [field1] deviates[operator] from [field2] by [value][scale],
        return True"
        """

        self._field_1 = template_config[TEMPLATE_FIELD1_FIELD_NAME]
        self._field_2 = template_config[TEMPLATE_FIELD2_FIELD_NAME]
        op_str = template_config.get(TEMPLATE_OPERATER_FIELD_NAME, ABS_DEVIATION)
        self._op = OPERATORS[op_str]
        op_scale = template_config.get(TEMPLATE_SCALE_FIELD_NAME, SCALE_PCT_NAME)
        self._scale = SCALES[op_scale]
        self._value = template_config[TEMPLATE_VALUE_FIELD_NAME]

        logger.debug(
            f"Building {self.template_type} template on fields {self._field_1}, {self._field_2} with "
            f"operator {op_str}, scale {self._scale}, and value {self._value}."
        )

    @classmethod
    def name(
        cls,
        template_config: TemplateConfig,
        current_name: str,
        curr_lf_names: List[str],
    ) -> str:
        try:
            template_config = NumericComparatorTemplateSchema(**template_config).dict()
        except ValidationError:
            return current_name
        start_name = "_".join([str(template_config["value"]), template_config["scale"]])

        return cls.get_final_name(start_name, curr_lf_names)

    @classmethod
    def full_info(cls, template_config: TemplateConfig) -> str:
        try:
            template_config = NumericComparatorTemplateSchema(**template_config).dict()
        except ValidationError:
            return ""

        return " ".join(
            [
                template_config["field_1"],
                template_config["operator"],
                template_config["field_2"] + ",",
                str(template_config["value"]),
                template_config["scale"],
            ]
        )

    def check(self, x: pd.Series) -> bool:
        try:
            field_value_1 = x[self._field_1]
            field_value_1 = normalize_numeric(str(field_value_1))
            field_value_2 = x[self._field_2]
            field_value_2 = normalize_numeric(str(field_value_2))
            deviation = field_value_1 - field_value_2

            # Adjust the comparison value based on the scale
            comp_value = normalize_numeric(str(self._value))
            adj_comp_value = self._scale(field_value_2, comp_value)

        except ValueError:
            return False
        return self._op(float(deviation), adj_comp_value)
