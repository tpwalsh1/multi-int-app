from typing import Any, Dict, List

import pandas as pd
from PIL import Image
from pydantic import ValidationError, validator

from api_utils.exceptions import UnprocessableEntityError
from label_spaces.multi_label import (
    MULTILABEL_PRESENCE_USER_LABEL_DICT,
    MultiLabelSpace,
)
from snorkelflow.models.image import CLIPImageEncoder
from snorkelflow.utils import resolve_data_path
from snorkelflow.utils.logging import get_logger
from templates.keyword_location_template import OPERATORS
from templates.utils import TemplateSchema, get_model_from_cache

from .template import BASE_URL, IMAGE_BASED, LFCacheKeys, Template, TemplateConfig

logger = get_logger("Multipolar Image Image Comparator LF")

MULTIPOLAR_IMAGE_IMAGE_SIMILARITY_FIELD_NAME = "__image_image_similarity"


class MultipolarImageImageComparatorTemplateSchema(TemplateSchema):
    """Multipolar Image Image Comparator template

    Parameters
    ----------
    image_embedding_field : str
        Field containing the image embedding
    image_path : str
        Image path
    label : str
        Label
    pos_threshold : float, default 0.5
        Positive threshold similarity. Datapoints with similarity greater than or equal are voted positive
    neg_threshold : float, default -0.5
        Negative threshold similarity. Datapoints with similarity less than or equal are voted negative
    invert_votes : bool
        Whether to invert the votes.
    """

    image_embedding_field: str
    image_path: str
    label: str
    pos_threshold: float = 0.5
    neg_threshold: float = -0.5
    invert_votes: bool = False

    @staticmethod
    def artifact_config_keys() -> List[str]:
        return ["image_path"]

    @validator("pos_threshold")
    def check_pos_threshold(cls, pos_threshold: float) -> float:
        if pos_threshold > 1.0 or pos_threshold < -1.0:
            raise ValueError(
                f"Invalid positive similarity threshold '{pos_threshold}'. "
                "pos_threshold must be between -1.0 and 1.0."
            )
        return pos_threshold

    @validator("neg_threshold")
    def check_neg_threshold(cls, neg_threshold: float) -> float:
        if neg_threshold > 1.0 or neg_threshold < -1.0:
            raise ValueError(
                f"Invalid negative similarity threshold '{neg_threshold}'. "
                "neg_threshold must be between -1.0 and 1.0."
            )
        return neg_threshold

    @validator("image_path")
    def check_image_path(cls, image_path: str) -> str:
        try:
            Image.open(resolve_data_path(image_path.strip()))
        except Exception as e:
            raise ValueError(f"Invalid image path '{image_path}'.") from e
        return image_path


# TOOD(ENG-17936): Add performance tests
class MultipolarImageImageComparatorTemplate(Template):
    template_type = "multipolar_image_image_comparator"
    docs_link = BASE_URL + "multipolar-image-image-comparator"

    abbreviation = "MIMI"
    description = "Classifies images by similarity to provided image."
    menu_type = {
        "name": "Multipolar Image Image Comparator Builder",
        "value": template_type,
        "category": [IMAGE_BASED],
    }
    template_schema = "MultipolarImageImageComparatorTemplateSchema"
    similarity_field_name = MULTIPOLAR_IMAGE_IMAGE_SIMILARITY_FIELD_NAME

    def __init__(self, template_config: TemplateConfig) -> None:
        # TODO ENG-9850 Enable GPU support once one worker can use all GPU resources
        # instead of multiple workers trying to compete for GPU resources

        self.image_embedding_field = template_config["image_embedding_field"]
        self.label = template_config["label"]
        self.pos_threshold = template_config["pos_threshold"]
        self.neg_threshold = template_config["neg_threshold"]
        self.invert_votes = template_config["invert_votes"]
        self.image_path = template_config["image_path"].strip()

    def preprocess_configs(self) -> List[Dict[str, Any]]:
        """List of operator configs to run before applying LF."""

        def compute_reference_embeddings_fn() -> Any:
            image_encoder = get_model_from_cache(
                "CLIPImageEncoder", lambda: CLIPImageEncoder(device="cpu")
            )
            return image_encoder.featurize([self.image_path])

        return [
            dict(
                op_type="EmbeddingComparator",
                op_config=dict(
                    embedding_field=self.image_embedding_field,
                    compute_reference_embeddings_fn=compute_reference_embeddings_fn,
                    metric="cosine_similarity",
                    target_field=self.similarity_field_name,
                    device=None,
                ),
            )
        ]

    def check(self, x: pd.Series) -> Dict[str, str]:
        similarity = x[self.similarity_field_name]
        if similarity is None:
            raise ValueError(
                f"Empty similarity={similarity} provided probably resulting from empty embeddings. "
                "Double check input embeddings are present and correct."
            )

        try:
            result = {}
            if OPERATORS[">="](similarity, self.pos_threshold):
                result[self.label] = MULTILABEL_PRESENCE_USER_LABEL_DICT[
                    0 if self.invert_votes else 1
                ]
            elif OPERATORS[">="](self.neg_threshold, similarity):
                result[self.label] = MULTILABEL_PRESENCE_USER_LABEL_DICT[
                    1 if self.invert_votes else 0
                ]
            else:
                result[self.label] = MULTILABEL_PRESENCE_USER_LABEL_DICT[-1]
        except Exception as e:
            raise UnprocessableEntityError(
                detail=f"Similarity embeddings may not be formatted correctly. Expected embeddings to be of type List[List[float]]",
                how_to_fix="Please validate that the output of EmbeddingComparator matches the expected format of List[List[float]]",
            ) from e

        return result

    def compute_lf_votes_single_column(self, df: pd.Series, label: Any) -> pd.Series:
        def cmp(x: Any) -> Dict[str, int]:
            result = MultiLabelSpace.get_raw_unknown_label()
            if OPERATORS[">="](x, self.pos_threshold):
                result[label] = 0 if self.invert_votes else 1
            elif OPERATORS[">="](self.neg_threshold, x):
                result[label] = 1 if self.invert_votes else 0
            return result

        lf_votes = df.apply(cmp)
        return lf_votes

    @classmethod
    def name(
        cls,
        template_config: TemplateConfig,
        current_name: str,
        curr_lf_names: List[str],
    ) -> str:
        try:
            template_config = MultipolarImageImageComparatorTemplateSchema(
                **template_config
            ).dict()
        except ValidationError:
            return current_name
        start_name = template_config["image_path"].strip()[-8:]

        return cls.get_final_name(start_name, curr_lf_names)

    @property
    def cache_keys(self) -> Dict[str, str]:
        return {
            LFCacheKeys.PREPROCESSED_DF: f"CLIPImageEncoder_{self.image_path}",
            LFCacheKeys.LF_VOTES: f"{self.template_type}_{self.image_path}_{self.label}_{self.pos_threshold}_{self.neg_threshold}_{self.invert_votes}",
        }
