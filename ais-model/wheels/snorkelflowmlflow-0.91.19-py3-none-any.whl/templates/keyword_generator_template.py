from snorkelflow.utils.logging import get_logger

from .template import BASE_URL, GENERATORS, Template

logger = get_logger("Studio KeywordGeneratorTemplate")


class KeywordGeneratorTemplate(Template):
    template_type = "keyword_generator"
    abbreviation = "KEYG"
    description = "If [field] [equals, contains, etc.] any of [keywords/phrases], then label. Can generate multiple LFs that each contain a subset of the keywords/phrases."
    menu_type = {
        "name": "Keyword Generator",
        "value": template_type,
        "category": [GENERATORS],
    }
    docs_link = BASE_URL + "keyword-generator-pattern-based-lfs"
