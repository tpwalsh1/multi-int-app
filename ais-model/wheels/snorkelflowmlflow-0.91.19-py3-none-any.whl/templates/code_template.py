from typing import Any, Callable, Dict, Union

import pandas as pd

from snorkelflow.lfs.lfs import LabelingFunction
from snorkelflow.serialization.code_asset import deserialize_asset, recompile_lf
from snorkelflow.utils.logging import get_logger

from .template import BASE_URL, Template, TemplateConfig
from .utils import TemplateSchema

logger = get_logger("Studio CodeTemplate")


class CodeTemplateSchema(TemplateSchema):
    serialized_lf: str
    name: str
    label_str: str
    label_int: int
    abstain_str: str
    code: Union[Dict[str, Any], str]


# NOTE: This CodeTemplate for SingleLabelSpace is being deprecated,
# pending change to use BooleanCodeTemplate instead.
class CodeTemplate(Template):
    """LF Builder for arbitrary serialized code LFs

    Deserializes a serialized_lf back into a valid LabelingFunction.
    """

    template_type = "code"
    abbreviation = "COD"
    description = "Label according to the conditions of the code this LF is based on. When composing a code LF, the condition of the code (whether the LF votes or abstains) is used in determining the overall result of the composed LF."
    menu_type = {"name": "Code Template", "value": template_type, "category": []}
    docs_link = BASE_URL
    template_schema = "CodeTemplateSchema"

    def __init__(self, template_config: TemplateConfig) -> None:
        """Deserialize a serialized LF CodeAsset

        The user writes the LF to output the string labels used everywhere else in the
        frontend. We wrap that with a function that uses the label map to convert the
        string labels into their integer counterparts for when the LF is executed in
        the backend.
        """

        def map_labels(
            f: Callable, label_str: str, label_int: int, abstain_str: str
        ) -> Callable:
            partial_label_map = {label_str: label_int, abstain_str: -1}

            def wrapped_f(*args: Any, **kwargs: Any) -> int:
                label = f(*args, **kwargs)
                if not isinstance(label, str):
                    raise TypeError(
                        f"Expected LF output of type string, got {type(label)} instead."
                    )
                elif label not in partial_label_map:
                    raise ValueError(
                        f"LF output {label} is not in the label space for the given LF ({label_str}, {abstain_str})."
                    )
                return partial_label_map[label]

            return wrapped_f

        try:
            lf = recompile_lf(template_config)
        except Exception:
            try:
                lf = deserialize_asset(template_config["serialized_lf"])
            except Exception:
                lf_name = template_config["name"]
                raise ValueError(
                    f"Snorkel cannot use the code for LF {lf_name} as it is no longer compatible with the current version of Snorkel. Please re-upload the code for this LF to use it again."
                )
        # Map user-facing string labels into backend-facing integer labels
        f_new = map_labels(
            lf._f,
            template_config["label_str"],
            template_config["label_int"],
            template_config["abstain_str"],
        )

        # Create new LF with updated name and wrapped function
        # Name specified in frontend overrides name from source code
        self.lf_code = LabelingFunction(
            name=template_config["name"],
            f=f_new,
            resources=lf._resources,
        )

    def check(self, x: pd.Series) -> bool:
        lf_label = self.lf_code.__call__(x)
        return lf_label != -1

    @property
    def lf(self) -> LabelingFunction:
        return self.lf_code
