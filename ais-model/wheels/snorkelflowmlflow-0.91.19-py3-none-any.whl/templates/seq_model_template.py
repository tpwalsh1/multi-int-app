from typing import Any, Dict, List, Optional, Tuple

import pandas as pd
from pydantic import Field

from snorkelflow.types.performance import Performance
from snorkelflow.utils.logging import get_logger
from templates.utils import TemplateSchema

from .template import BASE_URL, SEQUENCE_PATTERN_BASED, SequenceTemplate, TemplateConfig

logger = get_logger("Studio SequenceModelTemplate")


class SequenceModelTemplateSchema(TemplateSchema):
    """Sequence Model template

    Parameters
    ----------
    field : str
        Field storing the output of a ModelFeaturizer
    label : str
        The label type to extract from the model output field.
    include_fields : List[str]
        The fields to include in the model featurization.
    model_type : str
        The specific model used, must be contained in:
            ["sdnet"]
    model_name : str
        A user specified string name given to the trained model.
    dirpath : str
        The path to the stored model in minio.
    unique_model_name : Optional[str] = None
        A unique name for the model, usually the same as dirpath.
    """

    field: str
    label: int
    include_fields: List[str] = Field(default_factory=list)
    model_type: str
    model_name: str
    dirpath: str
    unique_model_name: Optional[str] = None


class SequenceModelTemplate(SequenceTemplate):
    """LF Template to extract predictions from a sequence ModelBased featurizer
    output."""

    template_type = "sequence_model_based"
    abbreviation = "SMT"
    description = "Votes based on predictions from a ModelBased featurizer."
    menu_type = {
        "name": "Sequence Model Output Builder",
        "value": template_type,
        "category": [SEQUENCE_PATTERN_BASED],
    }
    docs_link = BASE_URL + "sequence-model-builder-span-based-lfs"
    template_schema = "SequenceModelTemplateSchema"

    def __init__(self, template_config: TemplateConfig) -> None:
        self._model_output_field = template_config["field"]
        self._label = template_config["label"]
        self._include_fields = template_config["include_fields"]
        self._model_type = template_config["model_type"]
        self._model_name = template_config["model_name"]
        self._dirpath = template_config["dirpath"]
        self.unique_model_name = template_config["unique_model_name"]

        logger.debug(
            f"Building {self.template_type} template with model output field {self._model_output_field}, "
            f"label {self._label}"
        )

    def preprocess_configs(self) -> List[Dict[str, Any]]:
        """Batch retrieve cached results for efficiency. NOTE this runs for
        every LF."""
        return [
            dict(
                op_type="ModelBasedFeaturizer",
                op_config=dict(
                    model_name=self._model_name,
                    model_type=self._model_type,
                    input_fields=self._include_fields,
                    dirpath=self._dirpath,
                    target_field=self._model_output_field,
                    load_from_cache_only=True,
                    unique_model_name=self.unique_model_name,
                ),
            )
        ]

    def check(self, x: pd.Series) -> List[Tuple[int, int]]:
        model_output_value: List[Tuple[int, int, int]] = x[self._model_output_field]
        if model_output_value is None:
            return []
        return [(r[0], r[1]) for r in model_output_value if r[2] == self._label]

    @property
    def input_schema(self) -> Dict[str, Any]:
        return {field: Any for field in self._include_fields}

    @property
    def output_schema(self) -> Dict[str, Any]:
        return {self._model_output_field: Any}

    def estimate_perf(self, df: pd.DataFrame) -> Performance:
        avg_data_size = df[self._model_output_field].map(len).mean()
        num_docs = len(df)

        return Performance(
            compute_time_secs=(num_docs * avg_data_size) / 600,
            peak_memory_mb=(num_docs * avg_data_size) / 200,
        )
