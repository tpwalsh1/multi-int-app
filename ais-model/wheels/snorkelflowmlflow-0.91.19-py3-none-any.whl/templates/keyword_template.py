from typing import Any, Dict, List, Optional, Pattern

import pandas as pd
import regex
from pydantic import ValidationError, validator

from regex_utils.selector import select_compiled_regex
from snorkelflow.types.performance import Performance
from snorkelflow.utils.logging import get_logger
from templates.utils import (
    NO_HIGHLIGHT,
    HighlightedSpan,
    TemplateSchema,
    find_matching_spans,
    tokenize_pattern,
)

from .template import BASE_URL, PATTERN_BASED, TemplateConfig, TextTemplate

logger = get_logger("Studio KeywordTemplate")

CASE_SENSITIVE_DEFAULT = False
TOKENIZE_DEFAULT = True


class KeywordTemplateSchema(TemplateSchema):
    """Keyword template

    Parameters
    ----------
    field : str
        Field
    keywords : List[str]
        List of keywords
    operator : {"CONTAINS", "CONTAINS LINE MATCHING", "EQUALS"}
        Operator
    case_sensitive : bool, default False
        Case sensitive or not
    tokenize : bool, default True
        Tokenize or not
    """

    operator: str
    keywords: List[str]
    field: str
    case_sensitive: Optional[bool] = CASE_SENSITIVE_DEFAULT
    tokenize: Optional[bool] = TOKENIZE_DEFAULT

    @validator("operator")
    def check_operator(cls, operator_name: str) -> str:
        if operator_name not in KeywordTemplate.OPERATOR_NAMES:
            raise ValueError(f"Invalid operator: {operator_name}")
        return operator_name


class KeywordTemplate(TextTemplate):
    """LF Template based on a single keyword-based rule.

    Heuristic:
    "If x[field] [CONTAINS/EQUALS] any of the keywords, return True"
    """

    CONTAINS = "CONTAINS"
    CONTAINS_LINE_MATCHING = "CONTAINS LINE MATCHING"
    EQUALS = "EQUALS"
    OPERATOR_NAMES = [CONTAINS, CONTAINS_LINE_MATCHING, EQUALS]

    template_type = "keyword"
    abbreviation = "KEY"
    description = (
        "If [field] [equals, contains, etc.] any of [keywords/phrases], then label."
    )
    menu_type = {
        "name": "Keyword Builder",
        "value": template_type,
        "category": [PATTERN_BASED],
    }
    docs_link = BASE_URL + "keyword-builder-pattern-based-lfs"
    template_schema = "KeywordTemplateSchema"

    def __init__(self, template_config: TemplateConfig) -> None:
        self._field = template_config["field"]
        self._op_str = template_config["operator"]
        self._keywords = list(set(template_config["keywords"]))
        # Use 'get' instead of indexing directly to maintain backwards compatibility
        self._case_sensitive = template_config.get(
            "case_sensitive", CASE_SENSITIVE_DEFAULT
        )
        self._tokenize = template_config.get("tokenize", TOKENIZE_DEFAULT)
        self._regex_union_keywords = self._compile_regex()

        logger.debug(
            f"Building {self.template_type} template on field {self._field} with "
            f"operator {self._op_str}, regex {self._regex_union_keywords}, "
            f"for keywords {self._keywords}."
        )

    def _compile_regex(self) -> Pattern:
        """Compiles keywords into a union regex. We are limited to 3 keywords
        at the time this was written (git grep "const MAX_KEYWORDS").
        """
        flags = 0
        s = r"|".join([regex.escape(kw) for kw in self._keywords])
        if not self._case_sensitive:
            flags = flags | regex.IGNORECASE
        if self._op_str == self.CONTAINS_LINE_MATCHING:
            flags = flags | regex.MULTILINE
            # We consider preceding/trailing spaces ok for line matching.
            s = rf"^\s*({s})\s*$"
        if self._op_str == self.EQUALS:
            s = rf"^({s})$"
        s = rf"(?P<highlight>{s})"
        if self._tokenize and self._op_str == self.CONTAINS:
            s = tokenize_pattern(s)
        return select_compiled_regex(s, flags=flags)

    def highlight(self, x: pd.Series, return_early: bool = False) -> HighlightedSpan:
        """Preprocesses the field value and returns the spans which should be
        highlighted as matches for this Template.
        """
        if not self._keywords:
            return NO_HIGHLIGHT
        field_value = str(x[self._field])
        return find_matching_spans(
            self._regex_union_keywords,
            field_value,
            self._field,
            return_early=return_early,
        )

    def estimate_perf(self, df: pd.DataFrame) -> Performance:
        total_len = df[self._field].map(str).map(len).sum()
        return Performance(
            compute_time_secs=total_len * 0.0000003, peak_memory_mb=total_len * 0.000003
        )

    @classmethod
    def name(
        cls,
        template_config: TemplateConfig,
        current_name: str,
        curr_lf_names: List[str],
    ) -> str:
        try:
            template_config = KeywordTemplateSchema(**template_config).dict()
        except ValidationError:
            return current_name
        start_name = (
            "-".join(template_config["keywords"]) + "-" + template_config["field"]
        )
        return cls.get_final_name(start_name, curr_lf_names)

    @classmethod
    def full_info(cls, template_config: TemplateConfig) -> str:
        try:
            template_config = KeywordTemplateSchema(**template_config).dict()
        except ValidationError:
            return ""

        return "-".join(template_config["keywords"])

    @property
    def input_schema(self) -> Optional[Dict[str, Any]]:
        return {self._field: Any}
