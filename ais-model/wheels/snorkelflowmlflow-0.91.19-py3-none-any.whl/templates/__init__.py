"""LF template schema

Template-based LFs can be written in notebook and added to the core platform like below:

.. testcode::
    :skipif: True  # KeywordTemplateSchema is dynamically imported

    from templates import KeywordTemplateSchema
    keyword_template = KeywordTemplateSchema(
        field = "text",
        keywords = ["keyword1", "keyword2"],
        operator = "CONTAINS",
    )

    from snorkelflow.lfs import LF
    lf = LF(name="my_lf", label=0, templates=[keyword_template.to_dict()])

    sf.add_lf(node, lf)

"""
import importlib
import inspect
import json
import logging
import os
from functools import lru_cache, wraps
from typing import Any, Callable, Dict, List, Optional, Type

from snorkelflow.utils.logging import get_logger

try:
    from psycopg2.extensions import connection
except ModuleNotFoundError:
    logging.debug(
        "Cannot connect to database, custom LF template classes will not be available"
    )
    connection = None

from snorkelflow.plugin_utils import find_all_modules
from templates.udf_class_store import (
    get_custom_lf_template,
    get_custom_lf_template_schema,
    get_custom_lf_template_schema_configs,
    get_custom_lf_templates,
)
from templates.utils import (  # noqa: F401
    BUILTIN_TEMPLATE_SCHEMA_CLS_MAPPING,
    TemplateSchema,
)

from .template import (
    BUILTIN_TEMPLATE_CLS_MAPPING,
    CONVERSATION_BASED,
    CUSTOM,
    CUSTOM_SVM_BASED,
    CUSTOM_SVM_SEQUENCE_BASED,
    DOCUMENT_BASED,
    EMBEDDING_NEAREST_NEIGHBOR_BASED,
    EXTERNAL_RESOURCES,
    FOUNDATION_MODEL_BASED,
    GENERATORS,
    IMAGE_BASED,
    NETWORK_BASED,
    NUMERIC_BASED,
    OTHER,
    PATTERN_BASED,
    RELATIONSHIP_BASED,
    RICH_DOC_BASED,
    SEQUENCE_PATTERN_BASED,
    SPAN_BASED,
    SQL_BASED,
    TABLE_BASED,
    TIMESERIES_BASED,
    Template,
    TemplateConfig,
)

logger = get_logger("Templates")
all_template_modules = find_all_modules(os.path.dirname(__file__), "templates.")
for module in all_template_modules:
    logger.debug(f"Importing module {module}")
    try:
        package = importlib.import_module(module)
        for name, v in package.__dict__.items():
            if inspect.isclass(v) and (
                issubclass(v, Template) or issubclass(v, TemplateSchema)
            ):
                globals()[name] = v
    except ImportError as e:
        logger.debug(f"Skipping import for {module} due to error: {e}", exc_info=False)

LF_ORDER = (
    "span_context",
    "span_location",
    "span_count",
    "span_content",
    "utterance_context",
    "utterance_content",
    "utterance_location",
    "utterance_similarity",
    "full_text",
    "regex",
    "keyword_context",
    "keyword",
    "keyword_location",
    "keyword_count",
    "fuzzy_keyword",
    "keyword_generator",
    "numeric",
    "numeric_generator",
    "numeric_2d",
    "field_length",
    "bounding_rectangle",
    "bounding_polygon",
    "dictionary",
    "dictionary_generator",
    "external_body",
    "crowdworker",
    "sequence_regex",
    "custom_svm",
    "custom_svm_sequence",
    "image_image_comparator",
    "image_text_comparator",
)

GROUPING_ORDER = (
    CONVERSATION_BASED,
    RICH_DOC_BASED,
    TABLE_BASED,
    SPAN_BASED,
    PATTERN_BASED,
    SEQUENCE_PATTERN_BASED,
    DOCUMENT_BASED,
    NUMERIC_BASED,
    TIMESERIES_BASED,
    SQL_BASED,
    OTHER,
    NETWORK_BASED,
    FOUNDATION_MODEL_BASED,
    EXTERNAL_RESOURCES,
    GENERATORS,
    CUSTOM_SVM_BASED,
    EMBEDDING_NEAREST_NEIGHBOR_BASED,
    RELATIONSHIP_BASED,
    IMAGE_BASED,
    CUSTOM,
    CUSTOM_SVM_SEQUENCE_BASED,
)


def hashable_lru(func: Callable) -> Callable:
    cache = lru_cache(maxsize=1)

    def deserialise(value: Any) -> Any:
        try:
            return json.loads(value)
        except Exception:
            return value

    def func_with_serialized_params(*args: Any, **kwargs: Any) -> Any:
        _args = tuple([deserialise(arg) for arg in args])
        _kwargs = {k: deserialise(v) for k, v in kwargs.items()}
        return func(*_args, **_kwargs)

    cached_function = cache(func_with_serialized_params)

    @wraps(func)
    def lru_decorator(*args: Any, **kwargs: Any) -> Callable:
        _args = tuple(
            [
                json.dumps(arg, sort_keys=True) if type(arg) in (list, dict) else arg
                for arg in args
            ]
        )
        _kwargs = {
            k: json.dumps(v, sort_keys=True) if type(v) in (list, dict) else v
            for k, v in kwargs.items()
        }
        return cached_function(*_args, **_kwargs)

    lru_decorator.cache_info = cached_function.cache_info  # type: ignore
    lru_decorator.cache_clear = cached_function.cache_clear  # type: ignore
    return lru_decorator


@hashable_lru
def get_template(template_config: TemplateConfig) -> Template:
    # For mocking and testing purposes.
    return _get_template(template_config)


def _get_template(template_config: TemplateConfig) -> Template:
    template_type = template_config.get("template_type")
    if not template_type:
        raise ValueError("Template config is missing field `template_type`")
    template = get_template_class(template_type)

    template_config = validate_template_config(template, template_config)
    return template(template_config)  # type: ignore


def get_template_class(template_type: str, conn: Optional[connection] = None) -> Any:
    if template_type in BUILTIN_TEMPLATE_CLS_MAPPING:
        return BUILTIN_TEMPLATE_CLS_MAPPING[template_type]  # type: ignore

    return get_custom_lf_template(template_type, conn)


def is_valid_template_type(
    template_type: str, conn: Optional[connection] = None
) -> bool:
    return (
        template_type in BUILTIN_TEMPLATE_CLS_MAPPING
        or template_type in get_custom_lf_templates(conn)
    )


def get_all_template_classes(conn: Optional[connection] = None) -> List[Type[Template]]:
    return list(get_all_template_cls_mapping(conn).values())


def validate_template_config(
    template_cls: Type[Template], template_config: TemplateConfig
) -> TemplateConfig:
    template_schema = get_template_schema_class(template_cls.template_schema)  # type: ignore
    return template_schema(**template_config).dict()


def get_template_schema_class(template_schema_name: str) -> Type[TemplateSchema]:
    if template_schema_name in BUILTIN_TEMPLATE_SCHEMA_CLS_MAPPING:
        return BUILTIN_TEMPLATE_SCHEMA_CLS_MAPPING[template_schema_name]
    return get_custom_lf_template_schema(template_schema_name)


# This is due to #16269, where the Dask workers will attempt to start a conn.
# This code is to prevent the Dask workers from pinging the database by preloading
#   relevant data in the parent and passing it to the workers.
def get_all_template_cls_mapping(
    conn: Optional[connection] = None,
) -> Dict[str, Type[Template]]:
    ret = get_custom_lf_templates(conn)
    ret.update(BUILTIN_TEMPLATE_CLS_MAPPING)  # type: ignore
    return ret


# this is a hacky way to set all template classes(including custom lf templates)
# when no db access is available. Used by searching over multiple processes
def set_all_template_cls_mapping(template_cls_mapping: Dict) -> None:
    global BUILTIN_TEMPLATE_CLS_MAPPING
    BUILTIN_TEMPLATE_CLS_MAPPING.update(template_cls_mapping)


# We want to run search over multiple processes, but they all need to access TEMPLATE_SCHEMA_CLS_MAPPING.
#   We can't serialize TEMPLATE_SCHEMA_CLS_MAPPING because Pydantic objects are not serializable.
#   Therefore, we serialize the jsons and populate the TEMPLATE_SCHEMA_CLS here in the worker process.
def get_custom_template_schema_cls_json_config_mapping(
    conn: Optional[connection] = None,
) -> Dict:
    return get_custom_lf_template_schema_configs(conn)


# this is a hacky way to set all template schema classes(including custom lf templates)
# when no db access is available. Used by searching over multiple processes
def parse_and_set_custom_template_schema_mapping(
    template_schema_cls_json_config_mapping: Dict[str, Dict]
) -> None:
    global BUILTIN_TEMPLATE_SCHEMA_CLS_MAPPING
    for cls_json in template_schema_cls_json_config_mapping.values():
        template_schema = TemplateSchema.from_json(cls_json)
        BUILTIN_TEMPLATE_SCHEMA_CLS_MAPPING[template_schema.__name__] = template_schema
