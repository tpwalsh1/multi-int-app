from typing import List

import pandas as pd
import regex
from pydantic import ValidationError, validator

from rich_doc_wrapper import (
    AFTER_ONLY,
    BEFORE_ONLY,
    BEFORE_OR_AFTER,
    CASE_SENSITIVE_DEFAULT,
    SCOPES,
    SEQ_DIRECTIONS,
    Direction,
    RichDocWrapper,
    Scope,
)
from snorkelflow.extraction.span import SpanCols
from snorkelflow.rich_docs import MissingRichDocException, RichDocCols
from snorkelflow.utils.logging import get_logger
from templates.utils import TemplateSchema

from .template import CLASSIC_STUDIO_URL, RICH_DOC_BASED, Template, TemplateConfig

logger = get_logger("Studio SpanRegexProximityTemplate")


class SpanRegexProximityTemplateSchema(TemplateSchema):
    regex_pattern: str
    window: int
    scope_unit: Scope
    direction: Direction = BEFORE_OR_AFTER
    case_sensitive: bool = CASE_SENSITIVE_DEFAULT

    @validator("regex_pattern")
    def check_regex_pattern(cls, regex_pattern: str) -> str:
        try:
            regex.compile(regex_pattern)
        except Exception:
            raise ValueError(f"Invalid regex_pattern {regex_pattern}")
        return regex_pattern

    @validator("window")
    def check_window(cls, window: int) -> int:
        if window < 0:
            raise ValueError(f"Invalid window {window}")
        return window

    @validator("scope_unit")
    def check_scope(cls, scope_unit: str) -> str:
        if scope_unit.lower().strip("(s)") not in SCOPES:
            raise ValueError(f"Invalid scope_unit {scope_unit}")
        return scope_unit

    @validator("direction")
    def check_direction(cls, direction: str) -> str:
        if direction.lower() not in SEQ_DIRECTIONS:
            raise ValueError(
                f"Invalid direction {direction} for options {SEQ_DIRECTIONS}"
            )
        return direction


class SpanRegexProximityTemplate(Template):
    """LF Template based on the proximity of an ngram to the given span a/t RichDoc.

    Heuristic:
    "If [regex_pattern] is up to [window] [scope_units] [direction] SPAN, return True.

    NOTE: Requires RichDoc column to function
    """

    template_type = "span_regex_proximity"
    abbreviation = "SRP"
    description = "If span is up to [window] [units] [direction] the [regex] pattern, then label. If window = 0, only the SPAN's own scope of the given type is searched."
    menu_type = {
        "name": "Span Regex Proximity Builder",
        "value": template_type,
        "category": [RICH_DOC_BASED],
    }
    docs_link = CLASSIC_STUDIO_URL + "span-regex-proximity-rich-doc-based-lfs"
    template_schema = "SpanRegexProximityTemplateSchema"

    def __init__(self, template_config: TemplateConfig) -> None:
        self._regex_pattern = template_config["regex_pattern"]
        self._window = template_config["window"]
        self._scope_unit = template_config["scope_unit"].lower().strip("(s)")
        self._direction = template_config["direction"].lower()
        self._case_sensitive = template_config["case_sensitive"]

        logger.debug(
            f"Building {self.template_type} template with config {template_config}"
        )

    def check(self, x: pd.Series) -> bool:
        char_start = x[SpanCols.CHAR_START]
        char_end = x[SpanCols.CHAR_END]
        rd = x.get(RichDocCols.DOC_COL)
        if rd is None:
            raise MissingRichDocException(
                "Could not find RichDoc columns in DataFrame. "
                "Make sure that these columns have been added via task processors."
            )
        # Have to invert direction since X scope after span is X scope before regex
        if self._direction == BEFORE_ONLY:
            regex_direction = AFTER_ONLY
        elif self._direction == AFTER_ONLY:
            regex_direction = BEFORE_ONLY
        else:
            regex_direction = BEFORE_OR_AFTER

        return RichDocWrapper(rd).is_regex_proximate(
            char_start=char_start,
            char_end=char_end,
            regex_pattern=self._regex_pattern,
            window=self._window,
            scope_unit=self._scope_unit,
            direction=regex_direction,
            case_sensitive=self._case_sensitive,
        )

    @classmethod
    def name(
        cls,
        template_config: TemplateConfig,
        current_name: str,
        curr_lf_names: List[str],
    ) -> str:
        try:
            template_config = SpanRegexProximityTemplateSchema(**template_config).dict()
        except ValidationError:
            return current_name
        start_name = (
            template_config["regex_pattern"][:4]
            + "_"
            + str(template_config["window"])
            + str(template_config["scope_unit"])[:3]
        )

        return cls.get_final_name(start_name, curr_lf_names)
