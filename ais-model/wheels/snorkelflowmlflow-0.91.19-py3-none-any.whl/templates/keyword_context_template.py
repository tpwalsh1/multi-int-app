from enum import Enum
from typing import List, Optional, Tuple

import pandas as pd
import re2
import regex
from pydantic import ValidationError, validator

from regex_utils.selector import select_compiled_regex
from snorkelflow.utils.logging import get_logger
from templates.utils import (
    NO_HIGHLIGHT,
    HighlightedSpan,
    TemplateSchema,
    compile_regex_for_span_builders,
    find_matching_spans,
)

from .template import BASE_URL, PATTERN_BASED, TemplateConfig, TextTemplate

CASE_SENSITIVE_DEFAULT = False
TOKENIZE_DEFAULT = True
IS_REGEX_DEFAULT = True

logger = get_logger("Studio KeywordContextTemplate")


class KeywordContextMatchDirection(str, Enum):
    LEFT = "left"
    RIGHT = "right"
    LEFT_OR_RIGHT = "left or right"


class KeywordContextWindowUnit(str, Enum):
    CHARACTER = "CHARACTERS"
    WORD = "WORDS"
    # SENTENCE = "SENTENCE", TODO: add support for sentence-sized search windows


WINDOW_UNIT_TO_REGEX_PATTERN = {
    KeywordContextWindowUnit.CHARACTER: ".",
    KeywordContextWindowUnit.WORD: "\s+?(\w+\s+)",
    # KeywordContextWindowUnit.SENTENCE: "\b[^.!?]+[.!?]+", TODO: add support for sentence-sized search windows
}


class KeywordContextTemplateSchema(TemplateSchema):
    """Keyword Context template

    Label data points if a pattern appears within the specified proximity of the other pattern in a specific data field.

    Parameters
    ----------
    field : str
        Field
    regex_pattern_1 : str
        Regex pattern
    regex_pattern_2 : str
        Other regex pattern
    window_size : int
        Window size
    window_unit : {"CHARACTERS", "WORDS"}
        Window unit
    match_direction : {"left", "right", "left or right"}
        Match direction
    case_sensitive : bool, default False
        Case sensitive or not
    tokenize : bool, default True
        Tokenize or not
    regex : bool, default True
        If True, patterns are treated as regex
    """

    regex_pattern_1: str
    regex_pattern_2: str
    field: str
    window_size: int
    window_unit: KeywordContextWindowUnit
    match_direction: KeywordContextMatchDirection

    case_sensitive: Optional[bool] = CASE_SENSITIVE_DEFAULT
    tokenize: Optional[bool] = TOKENIZE_DEFAULT
    regex: Optional[bool] = IS_REGEX_DEFAULT

    @validator("regex_pattern_1")
    def validate_regex_1(cls, v: str) -> str:
        try:
            select_compiled_regex(v)
        except Exception:
            raise ValueError(f"Invalid regex pattern {v}")
        return v

    @validator("regex_pattern_2")
    def validate_regex_2(cls, v: str) -> str:
        try:
            select_compiled_regex(v)
        except Exception:
            raise ValueError(f"Invalid regex pattern {v}")
        return v

    @validator("window_size")
    def check_window_size(cls, v: int) -> int:
        if v <= 0:
            raise ValueError(
                f"Invalid window size {v}. Must be positive integer value."
            )
        return v

    @validator("window_unit")
    def check_window_unit(cls, v: str) -> KeywordContextWindowUnit:
        return KeywordContextWindowUnit(v)

    @validator("match_direction")
    def check_match_direction(cls, v: str) -> KeywordContextMatchDirection:
        return KeywordContextMatchDirection(v)


class KeywordContextTemplate(TextTemplate):
    """LF Template for text-based regex interfaces."""

    template_type = "keyword_context"
    abbreviation = "RCX"
    description = "If [field] contains both the first regular expression [regex] and second regular expression within a certain window size then label. "
    menu_type = {
        "name": "Keyword Context Builder",
        "value": template_type,
        "category": [PATTERN_BASED],
    }
    docs_link = BASE_URL + "keyword-context-builder-pattern-based-lfs"
    template_schema = "KeywordContextTemplateSchema"

    def __init__(self, template_config: TemplateConfig) -> None:
        """Check a given field for the given regex"""

        self._field = template_config["field"]
        self._regex_pattern_1 = template_config["regex_pattern_1"]
        self._regex_pattern_2 = template_config["regex_pattern_2"]

        # we need to apply regex.escape() on each user-specified search pattern
        # (left and right search patterns that book-end the search window).
        # Otherwise, if we apply regex.escape on entire search pattern,
        # we'll also escape out the regex needed to match search window
        # (e.g. \s+(\w+\s+){,2} for "within two words")
        self._is_regex_value = template_config.get("regex", IS_REGEX_DEFAULT)

        if not self._is_regex_value:
            self._regex_pattern_1 = regex.escape(self._regex_pattern_1)
            self._regex_pattern_2 = regex.escape(self._regex_pattern_2)

        self._window_unit = KeywordContextWindowUnit(template_config["window_unit"])
        self._tokenize = template_config.get("tokenize", TOKENIZE_DEFAULT)

        # Because {window_unit} specifies max number of window units (characters/words) that
        # right pattern can appear, after left pattern
        self._max_num_window_units = template_config["window_size"] - 1
        self._match_direction = KeywordContextMatchDirection(
            template_config["match_direction"]
        )

        if self._match_direction == KeywordContextMatchDirection.LEFT:
            # If user wants search pattern to apply to tokens,
            # we have to tokenize regex's for left and right search patterns,
            # but in a way that doesn't conflict with window search pattern.
            # We can't simply call tokenize_pattern on final search string or each user-specified pattern,
            # because whitespace will be handled incorrectly.
            # Examples:
            #   E.g. INCORRECT (won't match "mary had a little lamb":
            #       tokenize_pattern on each user-specified search pattern:
            #           r"(?:\s|^)" + "mary" + "(?=\s|$)" + "\s+(\w+\s+){,2}" + r"(?:\s|^)" + "lamb" + "(?=\s|$)"
            #       tokenize_pattern on final search pattern (using characters as search window unit):
            #           r"(?:\s|^)" + "mary" + ".{,10}" + "lamb" + "(?=\s|$)"
            #   E.g. CORRECT (will match "mary had a little lamb"::
            #       r"(?:\s|^)" + "mary" + "(?=\s|$)" + "\s+(\w+\s+){,2}" + r"(?:\s|^)" + "lamb" + "(?=\s|$)"
            #       r"(?:\s|^)" + "mary" + "(?=\s|$)" + ".{10}" + r"(?:\s|^)" + "lamb" + "(?=\s|$)"

            left_pattern = self._regex_pattern_1
            right_pattern = self._regex_pattern_2
            if self._tokenize:
                left_pattern, right_pattern = self._tokenize_pattern(
                    left_pattern, right_pattern, self._window_unit
                )
            self._regex_pattern = (
                left_pattern
                + WINDOW_UNIT_TO_REGEX_PATTERN[self._window_unit]
                + f"{{,{self._max_num_window_units}}}"
                + right_pattern
            )
        elif self._match_direction == KeywordContextMatchDirection.RIGHT:
            left_pattern = self._regex_pattern_2
            right_pattern = self._regex_pattern_1
            if self._tokenize:
                left_pattern, right_pattern = self._tokenize_pattern(
                    left_pattern, right_pattern, self._window_unit
                )
            self._regex_pattern = (
                left_pattern
                + WINDOW_UNIT_TO_REGEX_PATTERN[self._window_unit]
                + f"{{,{self._max_num_window_units}}}"
                + right_pattern
            )
        else:
            left_pattern_1 = self._regex_pattern_1
            right_pattern_1 = self._regex_pattern_2

            left_pattern_2 = self._regex_pattern_2
            right_pattern_2 = self._regex_pattern_1
            if self._tokenize:
                left_pattern_1, right_pattern_1 = self._tokenize_pattern(
                    left_pattern_1, right_pattern_1, self._window_unit
                )
                left_pattern_2, right_pattern_2 = self._tokenize_pattern(
                    left_pattern_2, right_pattern_2, self._window_unit
                )

            self._regex_pattern = (
                "("
                + left_pattern_1
                + WINDOW_UNIT_TO_REGEX_PATTERN[self._window_unit]
                + f"{{,{self._max_num_window_units}}}"
                + right_pattern_1
                + ")|("
                + left_pattern_2
                + WINDOW_UNIT_TO_REGEX_PATTERN[self._window_unit]
                + f"{{,{self._max_num_window_units}}}"
                + right_pattern_2
                + ")"
            )

        self._is_regex_value = template_config.get("regex", IS_REGEX_DEFAULT)
        self._case_sensitive = template_config.get(
            "case_sensitive", CASE_SENSITIVE_DEFAULT
        )

        # We set {is_regex_value}=True, because if {self._is_regex_value} were False,
        # we would have applied regex.escape() to each of both left and right search patterns
        #
        # We set tokenize=False, because if {self._tokenize}=False, we would have already handled it,
        # by calling self.tokenize_pattern() on each of both left and right search patterns
        self._rx = compile_regex_for_span_builders(
            value=self._regex_pattern,
            operator=None,
            is_regex_value=True,
            tokenize=False,
            case_sensitive=self._case_sensitive,
        )
        logger.info(
            f"Building {self.template_type} template with pattern '{self._regex_pattern}'; self._is_regex_value={self._is_regex_value}; self._tokenize ={self._tokenize}; self._rx={self._rx}"
        )

    def _tokenize_pattern(
        cls,
        left_pattern: str,
        right_pattern: str,
        window_unit: KeywordContextWindowUnit,
    ) -> Tuple[str, str]:
        left_pattern = r"(?:\s|^)" + left_pattern
        right_pattern = right_pattern + r"(?=\s|$)"
        if window_unit == KeywordContextWindowUnit.CHARACTER:
            left_pattern += r"(?=\s|$)"
            right_pattern = r"(?:\s|^)" + right_pattern
        return left_pattern, right_pattern

    def highlight(self, x: pd.Series, return_early: bool = True) -> HighlightedSpan:
        if not self._regex_pattern_1 or not self._regex_pattern_2:
            return NO_HIGHLIGHT
        field_value = str(x[self._field])
        # Simplest case. No special span handling.
        return find_matching_spans(
            self._rx, field_value, self._field, return_early=return_early
        )

    @classmethod
    def name(
        cls,
        template_config: TemplateConfig,
        current_name: str,
        curr_lf_names: List[str],
    ) -> str:
        try:
            template_config = KeywordContextTemplateSchema(**template_config).dict()
        except ValidationError:
            return current_name
        start_name = "_".join(
            [
                re2.sub(r"[^\w]", "", template_config["regex_pattern_1"]),
                re2.sub(r"[^\w]", "", template_config["regex_pattern_2"]),
            ]
        )

        return cls.get_final_name(start_name, curr_lf_names)

    @classmethod
    def full_info(cls, template_config: TemplateConfig) -> str:
        try:
            template_config = KeywordContextTemplateSchema(**template_config).dict()
        except ValidationError:
            return ""

        return ", ".join(
            [
                re2.sub(r"[^\w]", "", template_config["regex_pattern_1"]),
                re2.sub(r"[^\w]", "", template_config["regex_pattern_2"]),
            ]
        )
