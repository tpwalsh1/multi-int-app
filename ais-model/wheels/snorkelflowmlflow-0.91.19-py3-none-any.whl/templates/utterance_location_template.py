import sys
from typing import List, Optional, Union

import pandas as pd
from pydantic import ValidationError, validator

from snorkelflow.types.columns import ConvCols
from snorkelflow.utils.logging import get_logger
from templates.utils import (
    CASE_SENSITIVE_DEFAULT,
    NO_HIGHLIGHT,
    REGEX_DEFAULT,
    TOKENIZE_DEFAULT,
    TRUTHY_NO_HIGHLIGHT_SPAN,
    HighlightedSpan,
    PatternMatchTemplateSchema,
    compile_regex_for_span_builders,
)

from .template import BASE_URL, CONVERSATION_BASED, TemplateConfig, TextTemplate

logger = get_logger("Studio Template")


class UtteranceLocationTemplateSchema(PatternMatchTemplateSchema):
    """Utterance Location template

    Parameters
    ----------
    value : str
        Pattern
    start : int, default 0
        Start index
    end : int, default sys.maxsize
        End index
    regex : bool, default False
        If True, the pattern is treated as a regex
    case_sensitive : bool, default False
        Case sensitive or not
    tokenize : bool, default False
        Tokenize or not
    """

    start: Optional[int] = 0
    # An empty end field is interpreted as a str
    end: Optional[Union[str, int]] = sys.maxsize

    @validator("end")
    def check_end(cls, op: Union[str, int]) -> int:
        # Set end back to max size if the field is left empty
        if isinstance(op, str):
            if op == "":
                return sys.maxsize
            else:
                try:
                    op = int(op)
                    return op
                except ValueError:
                    raise ValueError("End index must be an empty string or an integer.")
        else:
            return op


class UtteranceLocationTemplate(TextTemplate):
    """LF Template for matching pattern in a subset of utterances based on index number.

    Heuristic:
    "If [value] occurs [op] [frequency] times between user utterances [start] to [end],
     return True"

    Note that [start] and [end] can be negative, in which case they are
    counted from the end of the field, similar to slices in python.
    """

    template_type = "utterance_location"
    abbreviation = "ULC"
    description = "If the value occurs in [start] to [end] utterances (defaults: [0, max]), then label. Negative indexes work from the end of the field."
    menu_type = {
        "name": "Utterance Location Builder",
        "value": template_type,
        "category": [CONVERSATION_BASED],
    }
    docs_link = BASE_URL + "utterance-location-builder"
    template_schema = "UtteranceLocationTemplateSchema"

    def __init__(self, template_config: TemplateConfig) -> None:
        self._start = template_config["start"]
        self._end = template_config["end"]

        self._value = template_config["value"]
        self._is_regex_value = template_config.get("regex", REGEX_DEFAULT)
        self._case_sensitive = template_config.get(
            "case_sensitive", CASE_SENSITIVE_DEFAULT
        )
        self._tokenize = template_config.get("tokenize", TOKENIZE_DEFAULT)
        self._regex_value = compile_regex_for_span_builders(
            self._value,
            None,
            self._is_regex_value,
            self._tokenize,
            self._case_sensitive,
        )

        logger.debug(
            f"Building {self.template_type} template with range {self._start}-{self._end} (case-sensitive = {self._case_sensitive}) and value {self._regex_value}."
        )

    def highlight(self, x: pd.Series, return_early: bool = True) -> HighlightedSpan:
        """
        We don't support highlighting in document mode right now. This function returns if the LF should fire or not i.e. if the given value is matching appropriate number of times or not.
        """
        if not self._value:
            return NO_HIGHLIGHT

        conversation_json = x[
            ConvCols.CONV_COL
        ]  # we store entire conversation json with each datapoint
        utterances = conversation_json[ConvCols.UTTERANCES]
        curr_idx = x[ConvCols.IDX_COL]
        curr_speaker = utterances[curr_idx][ConvCols.SPEAKER]

        user_utterance_indices = []
        for idx, utterance in enumerate(utterances):
            if utterance[ConvCols.SPEAKER].lower() == curr_speaker.lower():
                user_utterance_indices.append(idx)

        shortlisted_utterance_indices = user_utterance_indices[self._start : self._end]

        if curr_idx in shortlisted_utterance_indices:  # TODO: improve perfs
            if self._regex_value.search(utterances[curr_idx][ConvCols.UTTERANCE]):
                return TRUTHY_NO_HIGHLIGHT_SPAN

        return NO_HIGHLIGHT

    @classmethod
    def name(
        cls,
        template_config: TemplateConfig,
        current_name: str,
        curr_lf_names: List[str],
    ) -> str:
        try:
            template_config = UtteranceLocationTemplateSchema(**template_config).dict()
        except ValidationError:
            return current_name
        start_name = template_config["value"][:8]
        return cls.get_final_name(start_name, curr_lf_names)
