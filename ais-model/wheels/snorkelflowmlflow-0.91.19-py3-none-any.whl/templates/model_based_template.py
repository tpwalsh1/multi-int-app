from typing import Any, Dict, List, Optional, Union

import numpy as np
import pandas as pd
from pydantic import Field

from label_spaces.multi_label import MultiLabelSpace
from snorkelflow.types.performance import Performance
from snorkelflow.utils.logging import get_logger
from templates.utils import TemplateSchema

from .template import BASE_URL, EXTERNAL_RESOURCES, Template, TemplateConfig

logger = get_logger("Studio ModelBasedTemplate")


class ModelBasedTemplateSchema(TemplateSchema):
    """Model Based template

    Parameters
    ----------
    include_fields : List[str]
        The fields to include in the model featurization.
    target_field : str
        The field containing the model predictions.
    model_type : str
        The specific model used, must be contained in:
            ["zsl_text_match", "zsl_entailment",  "masked_lm",
            "logistic_regression",  "one_class_svm", "tfidf_logreg", "setfit",
            "sdnet", "sequence_embedding"]
    model_name : str
        A user specified string name given to the trained model.
    value : int
        The class index this LF should vote for.
    dirpath : str
        The path to the stored model in minio.
    threshold : float
        The confidence threshold below which this LF should abstain.
    unique_model_name : Optional[str] = None
        A unique name for the model, usually the same as dirpath.
    is_multilabel : bool = False
        Whether or not the task this LF is being applied to is multi-label
    multilabel_absent_as_abstain : bool = True
        If this is a multi-label task, True if we should replace "absent" votes
        output by the model with "abstain" votes
    """

    include_fields: List[str] = Field(default_factory=list)
    target_field: str
    model_type: str
    model_name: str
    value: Union[int, Dict[str, int]]
    dirpath: str
    threshold: float = 0
    unique_model_name: Optional[str] = None
    is_multilabel: bool = False
    multilabel_absent_as_abstain: bool = True

    @staticmethod
    def artifact_config_keys() -> List[str]:
        return ["dirpath"]


class ModelBasedTemplate(Template):
    """Template for all model based LFs"""

    template_type = "model_based"
    abbreviation = "MB"
    description = "Cached votes based on predictions from a ModelBased featurizer."
    menu_type = {
        "name": "Model Based",
        "value": template_type,
        "category": [EXTERNAL_RESOURCES],
    }

    docs_link = BASE_URL
    template_schema = "ModelBasedTemplateSchema"
    template_schema_cls = ModelBasedTemplateSchema

    def __init__(self, template_config: TemplateConfig) -> None:
        self.include_fields = template_config["include_fields"]
        self.target_field = template_config["target_field"]
        self.model_type = template_config["model_type"]
        self.model_name = template_config["model_name"]
        self.value = template_config["value"]
        self.dirpath = template_config["dirpath"]
        self.unique_model_name = template_config["unique_model_name"]
        self.threshold = template_config["threshold"]
        self.is_multilabel = template_config["is_multilabel"]
        self.multilabel_absent_as_abstain = template_config[
            "multilabel_absent_as_abstain"
        ]

        logger.debug(
            f"Building {self.template_type} template from {template_config['dirpath']}"
        )

    @classmethod
    def full_info(cls, template_config: TemplateConfig) -> str:
        return f"LF using the {template_config['model_type']} method with a minimum confidence threshold of {template_config['threshold']}"

    @property
    def input_schema(self) -> Dict[str, Any]:
        return {field: Any for field in self.include_fields}

    def estimate_perf(self, df: pd.DataFrame) -> Performance:
        """
           num_docs  len_docs      time     memory  num_docs X len_docs  constant
        0    3200.0  100000.0  0.651186   2.618014         3.200000e+08       1.0
        1    3200.0    1000.0  0.136308   2.618014         3.200000e+06       1.0
        2   12800.0    1000.0  0.630972   8.784638         1.280000e+07       1.0
        3   12800.0  100000.0  2.752440   8.784638         1.280000e+09       1.0
        4    5000.0    2000.0  0.198670   3.565614         1.000000e+07       1.0
        5   50000.0     100.0  1.842953  35.758806         5.000000e+06       1.0

        solutions = np.linalg.lstsq(
            df[["num_docs", "len_docs", "num_docs X len_docs", "constant"]],
            df[["time", "memory"]]
        )[0]
        """
        num_docs = len(df)
        total_len = 0
        for field in self.include_fields:
            total_len += df[field].map(str).map(len).sum()
        avg_len = total_len / num_docs

        time_estimate = (
            num_docs * 3.60583751e-05
            + avg_len * -9.99457069e-07
            + total_len * 1.83003409e-09
            + 4.91090214e-02
        )
        memory_estimate = (
            num_docs * 7.13340955e-04
            + avg_len * 5.46680379e-06
            + total_len * -7.15863704e-10
            + 2.01433294e-02
        )
        safety_factor = 1.1
        return Performance(
            compute_time_secs=max(time_estimate * safety_factor, 0.01),
            peak_memory_mb=max(memory_estimate * safety_factor, 2),
        )

    def preprocess_configs(self) -> List[Dict[str, Any]]:
        """Batch retrieve cached results for efficiency. NOTE this runs for
        every LF."""
        return [
            dict(
                op_type="ModelBasedFeaturizer",
                op_config=dict(
                    model_name=self.model_name,
                    model_type=self.model_type,
                    input_fields=self.include_fields,
                    dirpath=self.dirpath,
                    target_field=self.target_field,
                    load_from_cache_only=True,
                    unique_model_name=self.unique_model_name,
                ),
            )
        ]

    def check(self, x: pd.Series) -> bool:
        pred = self.get_prediction(x)
        return pred == self.value

    def get_prediction(
        self, x: pd.Series, inv_label_map: Optional[Dict] = None
    ) -> Union[int, str, Dict]:
        prediction = x[self.target_field]
        logit_col = f"{self.target_field}_max_logit"

        if self.is_multilabel:
            if not isinstance(prediction, np.ndarray) and pd.isna(prediction):
                return MultiLabelSpace.get_user_unknown_label()
            if logit_col in x:
                prediction = (x[logit_col] > self.threshold).astype(int)
            if self.multilabel_absent_as_abstain:
                prediction[prediction == 0] = -1

            pred = MultiLabelSpace.dense_array_to_sparse_labels(
                prediction, inv_label_map
            )
            return pred

        elif pd.isna(prediction) or (logit_col in x and x[logit_col] <= self.threshold):
            prediction = -1

        return inv_label_map[prediction] if inv_label_map else prediction
