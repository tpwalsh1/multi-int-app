from typing import List

import pandas as pd
from pydantic import ValidationError, validator

from snorkelflow.utils.logging import get_logger
from templates.utils import TemplateSchema, normalize_numeric

from .template import BASE_URL, NUMERIC_BASED, Template, TemplateConfig

logger = get_logger("Studio TwoAttributeNumericTemplate")

OPERATORS = {
    "=": lambda x, y: x == y,
    "!=": lambda x, y: x != y,
    "<": lambda x, y: x < y,
    "<=": lambda x, y: x <= y,
    ">": lambda x, y: x > y,
    ">=": lambda x, y: x >= y,
}


class TwoAttributeNumericTemplateSchema(TemplateSchema):
    """Two Attribute Numeric template

    Parameters
    ----------
    field_1 : str
        Field 1
    field_2 : str
        Field 2
    coefficient_1 : float
        Coefficient for field 1
    coefficient_2 : float
        Coefficient for field 2
    operator : {"=", "!=", "<", "<=", ">", ">="}
        Operator
    value : float
        Value
    """

    field_1: str
    field_2: str
    coefficient_1: float
    coefficient_2: float
    operator: str
    value: float

    @validator("operator")
    def check_operator(cls, op: str) -> str:
        if op not in OPERATORS.keys():
            raise ValueError("Invalid operator {op}")
        return op


class TwoAttributeNumericTemplate(Template):

    """LF Template based on numerical comparisons"""

    template_type = "numeric_2d"
    abbreviation = "N2D"
    description = "If sum of [coefficients] * [fields] has a numeric value that is [>, =, etc.] [value], then label."
    menu_type = {
        "name": "Two Attribute Numeric Builder",
        "value": template_type,
        "category": [NUMERIC_BASED],
    }
    docs_link = BASE_URL + "two-attribute-numeric-builder-numerical-lfs"
    template_schema = "TwoAttributeNumericTemplateSchema"

    def __init__(self, template_config: TemplateConfig) -> None:
        """LF Template based on numeric comparisons.

        Heuristic:
        "If [coefficient1] * x[field1] + [coefficient2] * x[field2] [OPERATOR] [value],
        return True"
        """

        self._field_1 = template_config["field_1"]
        self._field_2 = template_config["field_2"]
        self._coefficient_1 = template_config["coefficient_1"]
        self._coefficient_2 = template_config["coefficient_2"]
        op_str = template_config["operator"]
        self._op = OPERATORS[op_str]
        self._value = template_config["value"]

        logger.debug(
            f"Building {self.template_type} template on fields {self._field_1}, {self._field_2} with "
            f"operator {op_str}, coefficients {self._coefficient_1}, {self._coefficient_2}, and value {self._value}."
        )

    @classmethod
    def name(
        cls,
        template_config: TemplateConfig,
        current_name: str,
        curr_lf_names: List[str],
    ) -> str:
        try:
            template_config = TwoAttributeNumericTemplateSchema(
                **template_config
            ).dict()
        except ValidationError:
            return current_name
        start_name = "_".join(
            [template_config["operator"], str(template_config["value"])]
        )

        return cls.get_final_name(start_name, curr_lf_names)

    @classmethod
    def full_info(cls, template_config: TemplateConfig) -> str:
        try:
            template_config = TwoAttributeNumericTemplateSchema(
                **template_config
            ).dict()
        except ValidationError:
            return ""

        return " ".join([template_config["operator"], str(template_config["value"])])

    def check(self, x: pd.Series) -> bool:
        try:
            field_value_1 = x[self._field_1]
            field_value_1 = normalize_numeric(str(field_value_1))
            field_value_2 = x[self._field_2]
            field_value_2 = normalize_numeric(str(field_value_2))
            weighted_field_sum = (self._coefficient_1 * field_value_1) + (
                self._coefficient_2 * field_value_2
            )
        except ValueError:
            return False
        return self._op(float(weighted_field_sum), self._value)
