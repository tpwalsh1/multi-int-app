import sys
from typing import Any, Dict, List, Optional, Tuple, Union

import pandas as pd
import regex
from pydantic import ValidationError, validator

from regex_utils.selector import select_compiled_regex
from snorkelflow.utils.logging import get_logger
from templates.utils import (
    HighlightedSpan,
    TemplateSchema,
    find_matching_spans,
    tokenize_pattern,
)

from .template import BASE_URL, PATTERN_BASED, TemplateConfig, TextTemplate

logger = get_logger("Studio")
TOKENIZE_DEFAULT = False


# Map from unit to (regex for splitting, token for joining).
UNITS = {
    "chars": None,
    "words": select_compiled_regex(r"(\W+)"),
    "lines": select_compiled_regex(r"\n"),
    "sentences": select_compiled_regex(r"[\.\?\!]\s+"),
    "paragraphs": select_compiled_regex(r"\n\n+"),
}

OPERATORS = {
    "=": lambda x, y: x == y,
    "!=": lambda x, y: x != y,
    "<": lambda x, y: x < y,
    "<=": lambda x, y: x <= y,
    ">": lambda x, y: x > y,
    ">=": lambda x, y: x >= y,
}


class KeywordLocationSchema(TemplateSchema):
    """Keyword Location template

    Parameters
    ----------
    field : str
        Field
    pattern : str
        Pattern
    unit : {"chars", "words", "lines", "sentences", "paragraphs"}
        Unit
    start : int, default 0
        Start index
    end : int, default sys.maxsize
        End index
    operator : str, default ">="
        Operator
    frequency : int, default 1
        Number of occurences
    case_sensitive : bool, default False
        Case sensitive or not
    regex : bool, default False
        If True, the pattern is treated as a regex
    tokenize : bool, default False
        Tokenize or not
    """

    field: str
    pattern: str
    operator: Optional[str] = ">="
    frequency: Optional[int] = 1
    unit: Optional[str] = "paragraphs"
    start: Optional[int] = 0
    # An empty end field is interpreted as a str
    end: Optional[Union[str, int]] = sys.maxsize
    case_sensitive: Optional[bool] = False
    regex: Optional[bool] = False
    tokenize: Optional[bool] = False

    @validator("unit")
    def check_unit(cls, unit: str) -> str:
        if unit not in UNITS.keys():
            raise ValueError(f"Invalid unit {unit}. Must be in {list(UNITS.keys())}.")
        return unit

    @validator("operator")
    def check_operator(cls, op: str) -> str:
        if op not in OPERATORS.keys():
            raise ValueError(
                f"Invalid operator {op}. Must be in {list(OPERATORS.keys())}."
            )
        return op

    @validator("pattern")
    def validate_pattern(cls, pattern: str) -> str:
        try:
            regex.compile(rf"{pattern}")
        except Exception as e:
            raise ValueError(f"Invalid pattern {pattern}: {str(e)}")
        return pattern


class KeywordLocationTemplate(TextTemplate):
    """LF Template based on regex checks in a sub-range of the document.

    Heuristic:
    "If (string or regular expression) [pattern] occurs [op] [frequency] times
    between [units] [start] to [end] of [field], return True"

    Note that [start] and [end] can be negative, in which case they are
    counted from the end of the field, similar to slices in python.
    """

    template_type = "keyword_location"
    abbreviation = "KWL"
    description = "If [field] contains [keyword/phrase] in [lines, sentences, etc.] [start] to [end] (defaults: [0, max]), then label. Negative indexes work from the end of the field."
    menu_type = {
        "name": "Keyword Location Builder",
        "value": template_type,
        "category": [PATTERN_BASED],
    }
    docs_link = BASE_URL + "keyword-location-builder-pattern-based-lfs"
    template_schema = "KeywordLocationSchema"

    def __init__(self, template_config: TemplateConfig) -> None:
        self._field = template_config["field"]
        op_str = template_config["operator"]
        self._op_fn = OPERATORS[op_str]
        self._frequency = template_config["frequency"]
        self._start = template_config["start"]
        self._end = template_config["end"]
        # Set end back to max size if the field is left empty
        if type(self._end) == str:
            if self._end == "":
                self._end = sys.maxsize
            else:
                try:
                    self._end = int(self._end)
                except ValueError:
                    raise ValueError("End index must be an empty string or an integer.")
        self._unit_str = template_config["unit"]
        self._unit = UNITS[self._unit_str]
        self._case_sensitive = template_config["case_sensitive"]
        self._regex = template_config["regex"]
        self._pattern = template_config["pattern"]

        logger.debug(
            f"Building {self.template_type} template on field {self._field} with "
            f"pattern {self._pattern}, operator {op_str}, frequency {self._frequency}, "
            f"unit {self._unit_str}, and range {self._start}-{self._end} (case-sensitive = "
            f"{self._case_sensitive})."
        )

        flags = 0  # The default value for flags

        if not self._regex:
            self._pattern = regex.escape(self._pattern)

        if not self._case_sensitive:
            flags = flags | regex.I

        self._tokenize = template_config.get("tokenize", TOKENIZE_DEFAULT)
        # When in regex mode we will override the tokenizer settings
        if self._regex:
            self._tokenize = None
        pattern_with_highlight = r"(?P<highlight>" + self._pattern + r")"
        if self._tokenize:
            pattern_with_highlight = tokenize_pattern(pattern_with_highlight)

        self._flags = flags

        # Re2 is buggy wrt superfluous grouping, so if users are writing their own expressions
        # lets be conservative and use regex.
        if self._regex:
            self._regex_pattern = regex.compile(
                pattern_with_highlight, flags=self._flags
            )
        else:
            self._regex_pattern = select_compiled_regex(
                pattern_with_highlight, flags=self._flags
            )

    def _find_relevant_char_span(self, field_value: str) -> Tuple[int, int]:
        """Convert the relevant text to chars in the field value."""
        if self._unit_str == "chars":
            return self._start, self._end
        units = [match.span() for match in self._unit.finditer(field_value)]  # type: ignore
        units.insert(0, (0, 0))  # We matched on separators so need to add a begin/end.
        units.append((len(field_value), len(field_value)))
        # adjust for negative index values
        start = units[self._start][0] if self._start >= 0 else units[self._start - 1][0]
        if self._end is None:
            end = len(field_value)
        elif self._end >= len(units):
            return start, len(field_value)
        else:
            end = units[self._end][1]
        return start, end

    def highlight(self, x: pd.Series, return_early: bool = False) -> HighlightedSpan:
        field_value = str(x[self._field])
        char_start, char_end = self._find_relevant_char_span(field_value)
        if char_start < 0:
            # Users can pass in negative values for start,
            # but need to convert these to their positive index form
            # since that it was char_offset below expects.
            char_start = len(field_value) + char_start

        matching_spans = find_matching_spans(
            self._regex_pattern,
            field_value[char_start:char_end],
            self._field,
            char_offset=char_start,
            return_early=False,
        )  # Do not return early, we need to know how many matches for this LF.
        if self._op_fn(len(matching_spans.get(self._field, [])), self._frequency):
            return matching_spans
        return dict()

    @classmethod
    def name(
        cls,
        template_config: TemplateConfig,
        current_name: str,
        curr_lf_names: List[str],
    ) -> str:
        try:
            template_config = KeywordLocationSchema(**template_config).dict()
        except ValidationError:
            return current_name
        start_name = "_".join(
            [
                template_config["pattern"],
                str(template_config["start"]),
                str(template_config["end"]),
                template_config["unit"],
            ]
        )

        return cls.get_final_name(start_name, curr_lf_names)

    @classmethod
    def full_info(cls, template_config: TemplateConfig) -> str:
        try:
            template_config = KeywordLocationSchema(**template_config).dict()
        except ValidationError:
            return ""

        return f'{template_config["pattern"]}, {str(template_config["start"])} to {str(template_config["end"])} {template_config["unit"]}'

    @property
    def input_schema(self) -> Optional[Dict[str, Any]]:
        return {self._field: Any}
