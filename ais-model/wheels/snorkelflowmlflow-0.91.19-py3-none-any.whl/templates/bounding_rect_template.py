from typing import List

import pandas as pd
from pydantic import ValidationError

from snorkelflow.utils.logging import get_logger
from templates.utils import TemplateSchema, normalize_numeric

from .template import BASE_URL, NUMERIC_BASED, Template, TemplateConfig

logger = get_logger("Studio BoundingRectangleTemplate")


class BoundingRectangleTemplateSchema(TemplateSchema):
    """Bounding Rectangle template

    Parameters
    ----------
    field_1 : str
        Field 1
    field_2 : str
        Field 2
    field_1_min : float
        Min for Field 1
    field_1_max : float
        Max for Field 1
    field_2_min : float
        Min for Field 2
    field_2_max : float
        Max for Field 2
    """

    field_1_min: float
    field_2_min: float
    field_1_max: float
    field_2_max: float
    field_1: str
    field_2: str


class BoundingRectangleTemplate(Template):

    """LF Template based on geometric relations."""

    template_type = "bounding_rectangle"
    abbreviation = "BDR"
    description = "If point (field_1, field_2) is in or on the rectangle defined by the specified coordinates, then label."
    menu_type = {
        "name": "Bounding Rectangle Builder",
        "value": template_type,
        "category": [NUMERIC_BASED],
    }
    docs_link = BASE_URL + "bounding-rectangle-builder-numerical-lfs"
    template_schema = "BoundingRectangleTemplateSchema"

    def __init__(self, template_config: TemplateConfig) -> None:
        """LF Template based on geometric relations..

        Heuristic:
        "If the point (x[field_1], x[field_2]) is in the rectangle
        defined by points (field_1_min, field_2_min), (field_1_max, field_2_max),
        then return True
        """
        self._field_1 = template_config["field_1"]
        self._field_2 = template_config["field_2"]
        field_1_min, field_2_min = (
            template_config["field_1_min"],
            template_config["field_2_min"],
        )
        field_1_max, field_2_max = (
            template_config["field_1_max"],
            template_config["field_2_max"],
        )

        logger.debug(
            f"Building {self.template_type} template on fields {self._field_1}, {self._field_2} with "
            f"corner one at {field_1_min}, {field_2_min}, and corner two at {field_1_max}, {field_2_max}."
        )

        self._min_x = min(field_1_min, field_1_max)
        self._max_x = max(field_1_min, field_1_max)
        self._min_y = min(field_2_min, field_2_max)
        self._max_y = max(field_2_min, field_2_max)

    @classmethod
    def name(
        cls,
        template_config: TemplateConfig,
        current_name: str,
        curr_lf_names: List[str],
    ) -> str:
        try:
            template_config = BoundingRectangleTemplateSchema(**template_config).dict()
        except ValidationError:
            return current_name
        start_name = "_".join(
            [
                str(template_config["field_1_min"]),
                str(template_config["field_2_min"]),
                str(template_config["field_1_max"]),
                str(template_config["field_2_max"]),
            ]
        )

        return cls.get_final_name(start_name, curr_lf_names)

    @classmethod
    def full_info(cls, template_config: TemplateConfig) -> str:
        try:
            template_config = BoundingRectangleTemplateSchema(**template_config).dict()
        except ValidationError:
            return ""

        return ", ".join(
            [
                str(template_config["field_1_min"]),
                str(template_config["field_2_min"]),
                str(template_config["field_1_max"]),
                str(template_config["field_2_max"]),
            ]
        )

    def check(self, x: pd.Series) -> bool:
        try:
            field_value_1 = x[self._field_1]
            field_value_1 = normalize_numeric(str(field_value_1))
            field_value_2 = x[self._field_2]
            field_value_2 = normalize_numeric(str(field_value_2))
            if (
                field_value_1 <= self._max_x
                and field_value_1 >= self._min_x
                and field_value_2 <= self._max_y
                and field_value_2 >= self._min_y
            ):
                return True
            return False
        except ValueError:
            return False
