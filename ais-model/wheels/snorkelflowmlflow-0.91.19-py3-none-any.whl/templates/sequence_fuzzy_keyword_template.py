from typing import List, Optional, Set, Tuple

import numpy as np
import pandas as pd
from pydantic import ValidationError, validator

from snorkelflow.types.performance import Performance
from snorkelflow.utils.logging import get_logger
from templates.utils import TemplateSchema

from .template import BASE_URL, SEQUENCE_PATTERN_BASED, SequenceTemplate, TemplateConfig

logger = get_logger("Studio SequenceFuzzyKeywordTemplate")

CASE_SENSITIVE_DEFAULT = False


class SequenceFuzzyKeywordTemplateSchema(TemplateSchema):
    """Sequence Fuzzy Keyword template

    Parameters
    ----------
    field : str
        Field
    keywords : List[str]
        List of keywords
    min_similarity_ratio : float
        Minimum similarity ratio
    case_sensitive : bool, default False
        Case sensitive or not
    """

    keywords: List[str]
    field: str
    min_similarity_ratio: float
    case_sensitive: Optional[bool] = CASE_SENSITIVE_DEFAULT

    @validator("min_similarity_ratio")
    def min_similarity_ratio_validate(cls, v: float) -> float:
        if not (0 <= v <= 100):
            raise ValueError("Min similarity not in range [0,100]")
        return v

    @validator("keywords")
    def check_keywords(cls, v: List[str]) -> List[str]:
        if len(v) > 3:
            raise ValueError(
                "Only 3 keywords are supported. Please enter at most 3 keywords."
            )
        return v


class SequenceFuzzyKeywordTemplate(SequenceTemplate):
    "LF Template for Sequence text-based regexes interfaces."

    template_type = "sequence_fuzzy_keyword"
    abbreviation = "SFK"
    description = "If tokens in tokenized field [field] matches [keyword/phrase] with minimum similarity ratio of [threshold], then label."
    menu_type = {
        "name": "Sequence Fuzzy Keyword Builder",
        "value": template_type,
        "category": [SEQUENCE_PATTERN_BASED],
    }
    # TODO: Link to documentation when completed
    docs_link = BASE_URL + "sequence-fuzzy-keyword-builder-lfs"
    template_schema = "SequenceFuzzyKeywordTemplateSchema"

    def __init__(self, template_config: TemplateConfig) -> None:
        # _field attribute set in SequenceTemplate init required for template to work with highlight method from SequenceTemplate
        super().__init__(template_config)

        self._keywords = template_config["keywords"]
        self._text_field = template_config["field"]
        self._tokenized_field = "tokenized_" + self._text_field
        self._min_similarity_ratio = template_config["min_similarity_ratio"]
        self._case_sensitive = template_config["case_sensitive"]

        logger.debug(
            f"Building {self.template_type} template with keywords {self._keywords},",
            f"tokenized field {self._tokenized_field}, and min similarity ratio {self._min_similarity_ratio}.",
        )

    @classmethod
    def name(
        cls,
        template_config: TemplateConfig,
        current_name: str,
        curr_lf_names: List[str],
    ) -> str:
        try:
            template_config = SequenceFuzzyKeywordTemplateSchema(
                **template_config
            ).dict()
        except ValidationError:
            return current_name

        start_name = "-".join(template_config["keywords"])[:5]
        start_name = start_name + "-" + str(template_config["min_similarity_ratio"])

        return cls.get_final_name(start_name[:8], curr_lf_names)

    def check(self, x: pd.Series) -> List[Tuple[int, int]]:
        from difflib import SequenceMatcher

        field_value = str(x[self._text_field])
        tokens = [(token[0], token[1]) for token in x[self._tokenized_field]]
        spans = []
        if not self._case_sensitive:
            field_value = field_value.lower()
        for kw in self._keywords:
            matches = SequenceMatcher(
                None, kw, field_value, autojunk=False
            ).get_matching_blocks()
            # Each match is a tuple (kw_match_start, file_value_match_start, len_of_match)
            # Extract (char_start, char_end) of matches in field_value
            match_spans = [(match[1], match[1] + match[2]) for match in matches]

            # convert matches to tokens and then compute similarity score between each matched token and keyword
            token_end_indexes = np.searchsorted(
                np.array([token[0] for token in tokens]),
                np.array([match[1] for match in match_spans]),
                side="right",
            )
            token_start_indexes = np.searchsorted(
                np.array([token[1] for token in tokens]),
                np.array([match[0] for match in match_spans]),
                side="left",
            )
            matched_token_indices: Set[int] = set()

            for token_start_idx, token_end_idx in zip(
                token_start_indexes, token_end_indexes
            ):
                matched_token_indices.update(range(token_start_idx, token_end_idx))
            for token_idx in matched_token_indices:
                cur_token = tokens[token_idx]
                cur_token_val = field_value[cur_token[0] : cur_token[1]]
                if (
                    SequenceMatcher(None, cur_token_val, kw, autojunk=False).ratio()
                    * 100
                    >= self._min_similarity_ratio
                ):
                    spans.append((cur_token[0], cur_token[1]))

        return spans

    def estimate_perf(self, df: pd.DataFrame) -> Performance:
        avg_num_of_tokens = df[self._tokenized_field].map(len).mean()
        num_input_keywords = len(self._keywords)
        total_keyword_size = sum(len(w) for w in self._keywords)
        total_data_size = df[self._text_field].map(len).sum()
        num_docs = len(df)
        return Performance(
            compute_time_secs=(avg_num_of_tokens * num_input_keywords * num_docs)
            / 900_000
            + (total_data_size * total_keyword_size) / 2_500_000,
            peak_memory_mb=(total_keyword_size * num_docs) / 100
            + (avg_num_of_tokens * num_docs) / 150_000,
        )
