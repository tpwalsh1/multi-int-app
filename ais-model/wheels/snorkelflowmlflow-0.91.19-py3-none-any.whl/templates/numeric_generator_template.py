from typing import List

from pydantic import BaseModel, Field, validator

from snorkelflow.utils.logging import get_logger

from .template import BASE_URL, GENERATORS, Template

logger = get_logger("Studio NumericGeneratorTemplate")

STRATEGIES = ["high_quality", "top_x"]


class NumericGeneratorTemplateSchema(BaseModel):
    strategy: str
    min_precision: float = 0.8
    min_coverage: float = 0.005
    max_lfs_per_class: int = 1
    exclude_fields: List[str] = Field(default_factory=list)

    @validator("strategy")
    def check_strategy(cls, v: str) -> str:
        if v not in STRATEGIES:
            raise ValueError(f"Invalid strategy {v}. Must be in {STRATEGIES}")
        return v

    @validator("min_precision")
    def check_min_precision(cls, v: float) -> float:
        if v < 0 or 1 < v:
            raise ValueError(f"Invalid min_precision {v}. Must be in [0, 1]")
        return v

    @validator("min_coverage")
    def check_min_coverage(cls, v: float) -> float:
        if v < 0 or 1 < v:
            raise ValueError(f"Invalid min_coverage {v}. Must be in [0, 1]")
        return v

    @validator("max_lfs_per_class")
    def check_max_lfs_per_class(cls, v: int) -> int:
        if v < 0 or 10 < v:
            raise ValueError(f"Invalid max_lfs_per_class {v}. Must be in [0, 10]")
        return v


class NumericGeneratorTemplate(Template):
    template_type = "numeric_generator"
    abbreviation = "NUMG"
    description = "Generate numeric LFs."
    menu_type = {
        "name": "Numeric Generator",
        "value": template_type,
        "category": [GENERATORS],
    }
    docs_link = BASE_URL + "numeric-generator-numerical-lfs"
