from collections import Counter
from typing import Any, Dict, List, Optional

import pandas as pd
from pydantic import ValidationError, validator

from api_utils.exceptions import UserInputError
from snorkelflow.utils.logging import get_logger
from templates.utils import TemplateSchema

from .template import (
    BASE_URL,
    PATTERN_BASED,
    RELATIONSHIP_BASED,
    Template,
    TemplateConfig,
)

logger = get_logger("Studio SpacyOverlapTemplate")

UNIQUE_VALUES_DEFAULT = True
LEMMATIZATION_DEFAULT = True
CASE_SENSITIVE_DEFAULT = False
SPACY_UNUSED_KEYS_SET = {"id", "start", "end", "text", "lemma"}

OPERATORS = {
    "=": lambda x, y: x == y,
    "!=": lambda x, y: x != y,
    "<": lambda x, y: x < y,
    "<=": lambda x, y: x <= y,
    ">": lambda x, y: x > y,
    ">=": lambda x, y: x >= y,
}


class SpacyOverlapTemplateSchema(TemplateSchema):
    """Spacy Overlap template

    Parameters
    ----------
    field_1 : str
        Field 1
    field_2 : str
        Field 2
    field_denominator : str
        Field denominator
    operator : {"=", "!=", "<", "<=", ">", ">="}
        Operator
    value : float
        Value
    case_sensitive : bool, default False
        Case sensitive or not
    lemmatization : bool, default True
        Lemmatize or not
    unique_values : bool, True
        Deduplicate words or not
    spacy_tag_include : List[str], default []
        List of spacy tags to include
    """

    field_1: str
    field_2: str
    field_denominator: str
    operator: str
    value: float
    case_sensitive: Optional[bool] = CASE_SENSITIVE_DEFAULT
    lemmatization: Optional[bool] = LEMMATIZATION_DEFAULT
    unique_values: Optional[bool] = UNIQUE_VALUES_DEFAULT
    spacy_tag_include: Optional[List] = []

    @validator("operator")
    def check_operator(cls, op: str) -> str:
        if op not in OPERATORS.keys():
            raise ValueError("Invalid operator {op}")
        return op

    @validator("value")
    def check_value(cls, v: float) -> float:
        if not ((v >= 0) and (v <= 1.0)):
            raise ValueError("Invalid value for overlap ratio threshold")
        return v

    @validator("field_denominator")
    def check_field_denominator(cls, v: str, values: Any) -> str:
        if v not in [values.get("field_1"), values.get("field_2")]:
            raise ValueError(
                "Denominator field must be in one of the fields to compare"
            )
        return v


class SpacyOverlapTemplate(Template):
    "LF Template for Spacy Overlap Template."

    template_type = "spacy_overlap"
    abbreviation = "SPO"
    description = "If [field_1] and [field_2] contains [operator] [overlap_threshold] of keywords filtered by Spacy properties, then label."
    menu_type = {
        "name": "Spacy Overlap Builder",
        "value": template_type,
        "category": [RELATIONSHIP_BASED, PATTERN_BASED],
    }
    # TODO: Link to documentation when completed + give them the full list of spacy tags in the documentation
    docs_link = BASE_URL + "spacy-overlap-builder-relationship-based-lfs"
    template_schema = "SpacyOverlapTemplateSchema"

    def __init__(self, template_config: TemplateConfig) -> None:
        self._field_1 = template_config["field_1"]
        self._field_2 = template_config["field_2"]
        self._field_denominator = template_config["field_denominator"]
        if self._field_1 == template_config["field_denominator"]:
            # To make field_2 always the denominator
            # The order of 2 fields do not matter, this is just for more convenient computing
            self._field_1, self._field_2 = self._field_2, self._field_1

        self._case_sensitive = template_config["case_sensitive"]
        self._lemmatization = template_config["lemmatization"]
        self._unique_values = template_config["unique_values"]
        self._spacy_tag_include = set(template_config["spacy_tag_include"])
        self._value = template_config["value"]

        op_str = template_config["operator"]
        self._op = OPERATORS[op_str]

        logger.debug(
            f"Building {self.template_type} template on field {self._field_1} and denominator"
            f"{self._field_2} with Spacy prop {self._spacy_tag_include},"
            f"lemmatize {self._lemmatization}, and unique_values {self._unique_values}."
        )

    @classmethod
    def name(
        cls,
        template_config: TemplateConfig,
        current_name: str,
        curr_lf_names: List[str],
    ) -> str:
        try:
            template_config = SpacyOverlapTemplateSchema(**template_config).dict()
        except ValidationError:
            return current_name

        value_str = str(int(template_config["value"] * 100))

        if template_config["spacy_tag_include"]:
            start_name = "-".join(template_config["spacy_tag_include"])[:8]
        else:
            start_name = "-".join(
                [template_config["field_1"][:4], template_config["field_2"][:4]]
            )

        start_name = start_name + "-" + value_str
        return cls.get_final_name(start_name, curr_lf_names)

    def _get_included_values(self, x: pd.Series, field: str) -> List:
        output = []
        try:
            for token in x[field]["tokens"]:
                for key, val in token.items():
                    if key not in SPACY_UNUSED_KEYS_SET:
                        # (not spacy_tag_include) -> case when there is no "filter" requirement
                        if (not self._spacy_tag_include) or (
                            val in self._spacy_tag_include
                        ):
                            if self._lemmatization:
                                cur_token = token["lemma"]
                            else:
                                cur_token = token["text"]

                            if not self._case_sensitive:
                                cur_token = cur_token.lower()

                            output.append(cur_token)
                            break
        except Exception as e:
            err_msg = f"Tokenized field is not selected correctly. Currently selected: {field}"
            raise UserInputError(
                detail=f"{err_msg}. Error: {str(e)}", user_friendly_message=err_msg
            )
        return output

    def check(self, x: pd.Series) -> bool:
        try:
            words_1 = self._get_included_values(x, self._field_1)
            words_2 = self._get_included_values(x, self._field_2)

            if self._unique_values:
                words_set_1 = set(words_1)
                words_set_2 = set(words_2)
                overlap = len(words_set_1.intersection(words_set_2)) / len(words_set_2)

            else:
                words_counter_1: Dict = Counter(words_1)
                words_counter_2: Dict = Counter(words_2)
                overlap_occurence = [
                    min(words_counter_1[val], words_counter_2[val])
                    for val in words_counter_2.keys()
                ]
                overlap = sum(overlap_occurence) / len(words_2)

            return self._op(float(overlap), self._value)
        except ZeroDivisionError:
            return False
