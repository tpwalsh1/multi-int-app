from typing import Any

from templates.code_template_v2_base import CodeTemplateV2Base


class BooleanCodeTemplate(CodeTemplateV2Base):
    """LF Builder for arbitrary serialized boolean code LFs

    Deserializes a serialized_lf back into a valid LabelingFunction.
    """

    template_type = "boolean_code"
    abbreviation = "BCOD"
    description = "Label according to the conditions of the code this LF is based on. When composing a code LF, the condition of the code (whether the LF votes or abstains) is used in determining the overall result of the composed LF."
    menu_type = {
        "name": "Boolean Code Template",
        "value": template_type,
        "category": [],
    }

    def _validate_output_label_type(self, label: Any) -> None:
        if not isinstance(label, bool):
            raise TypeError(
                f"Expected LF output of type bool, got {type(label)} instead."
            )
