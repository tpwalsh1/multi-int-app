from typing import Any

from templates.code_template_v2_base import CodeTemplateV2Base


class MultipolarCodeTemplate(CodeTemplateV2Base):
    """LF Builder for arbitrary serialized sequence code LFs

    Deserializes a serialized_lf back into a valid LabelingFunction.
    """

    template_type = "multipolar_code"
    abbreviation = "MCOD"
    description = (
        "Label according to the output labels of the code this LF is based on."
    )
    menu_type = {
        "name": "Multipolar Code Template",
        "value": template_type,
        "category": [],
    }

    def _validate_output_label_type(self, label: Any) -> None:
        # No typing checking required for this template
        # since it outputs user labels that are transformed in the
        # LFBuilder class
        return
