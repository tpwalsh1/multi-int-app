from string import punctuation
from typing import List

import pandas as pd
from pydantic import ValidationError, validator

from snorkelflow.types.columns import ConvCols
from snorkelflow.utils.logging import get_logger
from templates.utils import TemplateSchema

from .template import BASE_URL, CONVERSATION_BASED, Template, TemplateConfig

logger = get_logger("Studio Template")


class UtteranceSimilarityTemplateSchema(TemplateSchema):
    """Utterance Similarity template

    Parameters
    ----------
    keywords : List[str]
        List of keywords
    similarity_value : float
        Similarity
    """

    keywords: List[str]
    similarity_value: float

    @validator("similarity_value")
    def check_value(cls, v: float) -> float:
        if not ((v >= 0) and (v <= 1.0)):
            raise ValueError("Similarity value must be between 0 and 1")
        return v


class UtteranceSimilarityTemplate(Template):
    template_type = "utterance_similarity"
    abbreviation = "USM"
    description = "If the utterance contains any tokens with greater [similarity] (homophonic) Jaro distance with any [keywords], then label."
    menu_type = {
        "name": "Utterance Similarity Builder",
        "value": template_type,
        "category": [CONVERSATION_BASED],
    }
    docs_link = BASE_URL + "utterance-similarity-builder"
    template_schema = "UtteranceSimilarityTemplateSchema"

    def __init__(self, template_config: TemplateConfig) -> None:
        """LF Template based on surrounding utterances."""
        from nltk.metrics import distance

        try:
            from nltk.corpus import cmudict
        except LookupError:
            import nltk

            nltk.download("cmudict")
            from nltk.corpus import cmudict

        self._keywords = template_config["keywords"]
        self._similarity_value = template_config["similarity_value"]
        self._pronounce_dict = cmudict.dict()
        self._jaro_similarity = distance.jaro_similarity

        logger.debug(
            f"Building {self.template_type} template with keywords {self._keywords}"
            f"and similarity {self._similarity_value}."
        )

    @classmethod
    def name(
        cls,
        template_config: TemplateConfig,
        current_name: str,
        curr_lf_names: List[str],
    ) -> str:
        try:
            template_config = UtteranceSimilarityTemplateSchema(
                **template_config
            ).dict()
        except ValidationError:
            return current_name

        start_name = (
            "-".join(template_config["keywords"])[:6]
            + "-"
            + str(int(template_config["similarity_value"] * 100))
        )
        return cls.get_final_name(start_name, curr_lf_names)

    def _token2soundex(self, token: str) -> List[str]:
        """
        Function converting token -> List of possible pronunciation

        Example: "cent" -> ["SEH1NT"]
        """
        # To strip leading and trailing punctuations as these can pop up when we splitting by " "
        clean_token = token.strip(punctuation).lower()

        # The output is the list of potential pronunciations List[List]], hence, if not available, default to [[]]
        list_pronounce = self._pronounce_dict.get(clean_token, [[]])

        # list_pronounce: [['S', 'EH1', 'N', 'T']] -> ["SEH1NT"] for easier computing text distance
        return ["".join(pronounce) for pronounce in list_pronounce]

    def _compute_similarity(self, token: str, keyword: str) -> float:
        soundex_tokens = self._token2soundex(token)
        soundex_keywords = self._token2soundex(keyword)

        max_similarity = 0
        # Iterate through all possible pairwise pronunciation
        # Not expensive because the mean # of pronunciations is 1.08 and the max is 5.
        for soundex_token in soundex_tokens:
            for soundex_keyword in soundex_keywords:
                max_similarity = max(
                    max_similarity,
                    self._jaro_similarity(soundex_token, soundex_keyword),
                )

        return max_similarity

    def check(self, x: pd.Series) -> bool:
        token_list = x[ConvCols.UTTERANCE].split(" ")

        for token in token_list:
            for keyword in self._keywords:
                if self._compute_similarity(token, keyword) >= self._similarity_value:
                    return True
        return False
