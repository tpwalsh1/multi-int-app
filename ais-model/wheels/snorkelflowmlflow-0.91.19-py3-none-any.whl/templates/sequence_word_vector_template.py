from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd
from pydantic import ValidationError, validator
from scipy.spatial.distance import cdist

from api_utils.exceptions import UserInputError
from file_utils.core import get_filesystem_for_path, open_file
from regex_utils.selector import select_compiled_regex
from snorkelflow.types.performance import Performance
from snorkelflow.utils.file import resolve_data_path
from snorkelflow.utils.logging import get_logger
from templates.utils import TemplateSchema

from .template import BASE_URL, SEQUENCE_PATTERN_BASED, SequenceTemplate, TemplateConfig

logger = get_logger("Studio SequenceWordVectorTemplate")

CASE_SENSITIVE_DEFAULT = False
TOKENIZE_DEFAULT = True


class SequenceWordVectorSchema(TemplateSchema):
    """Sequence Word Vector template

    Parameters
    ----------
    field : str
        Field
    keywords : List[str]
        List of keywords
    cosine_similarity : float
        Cosine similarity
    word_vector_path : str
        Path to a file containing word embedding vectors
    case_sensitive : bool
        Case sensitive or not
    """

    keywords: List[str]
    field: str
    cosine_similarity: float
    word_vector_path: str
    case_sensitive: bool

    @staticmethod
    def artifact_config_keys() -> List[str]:
        return ["word_vector_path"]

    @validator("keywords")
    def check_keywords(cls, v: List[str]) -> List[str]:
        if len(v) > 3:
            raise ValueError(
                "Only 3 keywords are supported. Please enter at most 3 keywords."
            )
        return v


class SequenceWordVectorTemplate(SequenceTemplate):
    "LF Template for Sequence Word Vector."

    template_type = "sequence_word_vector"
    abbreviation = "SWVECT"
    description = "If [field] contains any [keywords/phrases] that have larger similarity than threshold, then label the matching character offsets."
    menu_type = {
        "name": "Sequence Word Vector Builder",
        "value": template_type,
        "category": [SEQUENCE_PATTERN_BASED],
    }
    # TODO: Link to documentation when completed
    docs_link = BASE_URL
    template_schema = "SequenceWordVectorSchema"

    def __init__(self, template_config: TemplateConfig) -> None:
        self._word_vector_path = template_config["word_vector_path"]
        self._field = template_config["field"]
        self._cosine_similarity = template_config["cosine_similarity"]
        self._keywords = template_config["keywords"]
        self._case_sensistive = template_config["case_sensitive"]
        self._regex_word_match = select_compiled_regex(r"\w+")
        self._word_vectors: Optional[Dict[str, np.ndarray]] = None

    def get_word_vectors(self) -> Dict[str, np.ndarray]:
        try:
            word_vector_path = resolve_data_path(self._word_vector_path)
            word_vectors = {}
            with open_file(word_vector_path, "r") as f:
                for row in f:
                    v = row.split()
                    word_vectors[v[0]] = np.asarray(v[1:], dtype="float32")
            return word_vectors
        except Exception as e:
            err_msg = f"Could not read file {self._word_vector_path}"
            detail = str(e)
            raise UserInputError(
                detail=detail,
                user_friendly_message=err_msg,
                how_to_fix="Please make sure file exists. Refer to the Labeling Function Builders Documentation for more details about file format",
            )

    @classmethod
    def name(
        cls,
        template_config: TemplateConfig,
        current_name: str,
        curr_lf_names: List[str],
    ) -> str:
        try:
            template_config = SequenceWordVectorSchema(**template_config).dict()
        except ValidationError:
            return current_name
        start_name = "-".join(template_config["keywords"])[:8]
        return cls.get_final_name(start_name, curr_lf_names)

    def estimate_perf(self, df: pd.DataFrame) -> Performance:
        total_data_size = df[self._field].map(len).sum()
        num_docs = len(df)
        num_input_keywords = len(self._keywords)
        word_vector_path = resolve_data_path(self._word_vector_path)
        fs = get_filesystem_for_path(word_vector_path)
        embedding_file_size = fs.du(word_vector_path)
        with open_file(word_vector_path, "r") as f:
            row = f.readline()
            v = row.split()
            embedding_dimension = len(v) - 1

        return Performance(
            compute_time_secs=(
                total_data_size * num_input_keywords * embedding_dimension
            )
            / 160_000_000
            + embedding_file_size / 40_000_000,
            peak_memory_mb=(total_data_size * num_input_keywords) / 8_000_000
            + (num_docs * num_input_keywords * embedding_dimension) / 6_000_000
            + (total_data_size * embedding_dimension) / 5_0000_000
            + embedding_file_size / 8_000_000,
        )

    def check(self, x: pd.Series) -> List[Tuple[int, int]]:
        "Sequence LFs vote with char offsets, not boolean values."
        field_value = x[self._field]
        token_spans = [
            (m.group(), m.span()) for m in self._regex_word_match.finditer(field_value)
        ]
        if self._word_vectors is None:
            self._word_vectors = self.get_word_vectors()

        keyword_vectors = []
        for word in self._keywords:
            if not self._case_sensistive:
                word = word.lower()
            if word in self._word_vectors.keys():
                keyword_vectors.append(self._word_vectors[word])

        if len(keyword_vectors) == 0:
            return []

        filtered_token_vectors = []
        filtered_spans = []
        for token, span in token_spans:
            if not self._case_sensistive:
                token = token.lower()
            if token in self._word_vectors.keys():
                filtered_token_vectors.append(self._word_vectors[token])
                filtered_spans.append(span)

        if len(filtered_spans) == 0:
            return []

        # similarities -> num_filtered_tokens X num_keywords
        similarities = cdist(filtered_token_vectors, keyword_vectors, metric="cosine")
        # Select tokens that has cosine similaty greate than threshold for at least one keyword
        return [
            filtered_spans[i]
            for i in np.where(
                np.any(similarities < 1 - self._cosine_similarity, axis=1)
            )[0]
        ]

    @property
    def input_schema(self) -> Dict[str, Any]:
        return {self._field: Any}
