from abc import ABC, abstractmethod
from typing import Any, Callable, Dict, List, Tuple, Union

import pandas as pd

from snorkelflow.lfs.lfs import LabelingFunction
from snorkelflow.serialization.code_asset import deserialize_asset, recompile_lf
from snorkelflow.utils.logging import get_logger

from .template import BASE_URL, Template, TemplateConfig
from .utils import TemplateSchema

logger = get_logger("Studio CodeTemplateV2")


class CodeTemplateSchemaV2(TemplateSchema):
    serialized_lf: str
    name: str
    code: Union[Dict[str, Any], str]


class CodeTemplateV2Base(Template, ABC, is_abstract=True):
    """LF Builder for serialized code LFs

    Deserializes a serialized_lf back into a valid LabelingFunction.
    """

    docs_link = BASE_URL
    template_schema = "CodeTemplateSchemaV2"

    @abstractmethod
    def _validate_output_label_type(self, label: Any) -> None:
        pass

    def __init__(self, template_config: TemplateConfig) -> None:
        """Abstract base class for serialized code LFs."""

        def validate_labels(f: Callable) -> Callable:
            def wrapped_f(*args: Any, **kwargs: Any) -> Any:
                label: Any = f(*args, **kwargs)
                self._validate_output_label_type(label)
                return label

            return wrapped_f

        try:
            lf = recompile_lf(template_config)
        except Exception:
            try:
                lf = deserialize_asset(template_config["serialized_lf"])
            except Exception:
                lf_name = template_config["name"]
                raise ValueError(
                    f"Snorkel cannot use the code for LF {lf_name} as it is no longer compatible with the current version of Snorkel. Please re-upload the code for this LF to use it again."
                )

        f_new = validate_labels(lf._f)

        # Create new LF with updated name and wrapped function
        # Name specified in frontend overrides name from source code
        self.lf_code = LabelingFunction(
            name=template_config["name"],
            f=f_new,
            resources=lf._resources,
        )

    def check(self, x: pd.Series) -> List[Tuple[int, int]]:
        lf_label = self.lf_code.__call__(x)
        return lf_label

    @property
    def lf(self) -> LabelingFunction:
        return self.lf_code
