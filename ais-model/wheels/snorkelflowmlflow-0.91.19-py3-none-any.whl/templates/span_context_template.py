from enum import Enum
from typing import List, Optional, Tuple

import pandas as pd
from pydantic import StrictInt, ValidationError, validator

from regex_utils.selector import select_compiled_regex
from snorkelflow.extraction.span import SpanCols
from snorkelflow.types.performance import Performance
from snorkelflow.utils.logging import get_logger
from templates.utils import (
    CASE_SENSITIVE_DEFAULT,
    NO_HIGHLIGHT,
    HighlightedSpan,
    PatternMatchTemplateSchema,
    Span,
    add_dicts,
    compile_regex_for_span_builders,
    find_matching_spans,
    get_span_positions_for_field,
    merge_spans,
)

from .template import BASE_URL, SPAN_BASED, TemplateConfig, TextTemplate

logger = get_logger("Studio SpanContextTemplate")

TOKENIZE_DEFAULT = False


class Operator(str, Enum):
    """Indicates whether the span is to the "LEFT" or "RIGHT" or
    "LEFT OR RIGHT" of the value we are searching for.
    """

    LEFT = "LEFT"
    RIGHT = "RIGHT"
    LEFT_OR_RIGHT = "LEFT OR RIGHT"


class SpanContextTemplateSchema(PatternMatchTemplateSchema):
    """Span Context template

    Parameters
    ----------
    operator : {"LEFT", "RIGHT", "LEFT OR RIGHT"}
        Operator
    value : str
        Value
    window : int
        The number of words within the span that we will search.
    regex : bool, default False
        If True, the pattern is treated as a regex
    case_sensitive : bool, default False
        Case sensitive or not
    tokenize : bool, default False
        Tokenize or not
    """

    operator: Operator
    window: StrictInt

    # Deprecated fields, all can be ignored.
    context_field: Optional[str] = None
    char_start_field: Optional[str] = None
    char_end_field: Optional[str] = None
    span_field: Optional[str] = None
    span_preview_field: Optional[str] = None
    span_preview_offset_field: Optional[str] = None

    @validator("window")
    def check_window(cls, v: int) -> int:
        if v < 0:
            raise ValueError(
                f"Invalid window value: {v}. Must be integer greater than 0."
            )
        return v


class SpanContextTemplate(TextTemplate):
    """LF Template based on span context, see .description below.

    Args:
        template_config (SpanContextTemplateSchema)

    Attributes:
        _operator (Operator): Indicates in which direction around `value` we should search.
        _value (str): The value we should be searching for somewhere in the span's context.
        _window (int): How many words the span's context should contain.
        _is_regex_value (bool): If this is True, `value` should be a RegEx Pattern.
        _case_sensitive (bool): Makes the match between `value` and context, case insensitive.
        _tokenize (bool): Only can be True if `regex` is False, we will search for an
            exact word match between value and span context and not match on substrings.

    """

    template_type = "span_context"
    abbreviation = "SCX"
    description = "If the span is within [window] words to the [left, right, etc.] of the [keyword/phrase], then label."
    menu_type = {
        "name": "Span Context Builder",
        "value": template_type,
        "category": [SPAN_BASED],
    }
    docs_link = BASE_URL + "span-context-builder-span-based-lfs"
    template_schema = "SpanContextTemplateSchema"

    def __init__(self, template_config: TemplateConfig) -> None:
        """LF Template based on context around span."""

        self._operator = template_config["operator"]
        self._is_regex_value = template_config.get("regex", False)
        # Use 'get' instead of indexing directly to maintain backwards compatibility
        self._case_sensitive = template_config.get(
            "case_sensitive", CASE_SENSITIVE_DEFAULT
        )
        self._tokenize = template_config.get("tokenize", TOKENIZE_DEFAULT)
        self._window = template_config["window"]
        self._value = template_config["value"]
        # When in regex mode we will override the tokenizer settings
        if self._is_regex_value:
            self._tokenize = None
        self._regex_value = compile_regex_for_span_builders(
            self._value,
            None,
            self._is_regex_value,
            self._tokenize,
            self._case_sensitive,
        )
        self._regex_word_match = select_compiled_regex(
            r"\w+"
        )  # used for matching word windows around the span.

        logger.debug(
            f"Building {self.template_type} template with operator {self._operator} "
            f"and value {self._regex_value} whis is {self._is_regex_value} a regex, within window {self._window}"
        )

    def _get_context_window_span(
        self, context: str, operator: Operator
    ) -> Tuple[int, int]:
        """This will return the starting and ending char idx for the span's context window.
        Note our convention for window is returning everything after the last word, but before the next word.
        e.g. window = 2 and text = "some some -! else", we return "some some -! else". See the test where
        value = "('very very much')".
        """

        word_idxs = []

        if "LEFT" in operator:
            # Search on RIGHT side onward
            for m in self._regex_word_match.finditer(context):
                word_idxs.append(m)
                if len(word_idxs) > self._window:
                    break

            if len(word_idxs) <= self._window:
                # Window is larger or equal than the number of words, return everything.
                return (0, len(context))

            # word_idxs[-1] is the first word NOT in the window
            return (0, word_idxs[-1].start())

        if "RIGHT" in operator:
            # Search on LEFT side onward
            # The _regex_word_match is r"\w+" - (0,+inf) word characters
            # Regex does not support reverse seaching
            # So we reverse the string to search better
            reversed_context = context[::-1]
            for m in self._regex_word_match.finditer(reversed_context):
                word_idxs.append(m)
                if len(word_idxs) > self._window:
                    break

            if len(word_idxs) <= self._window:
                # Window is larger or equal than the number of words, return everything.
                return (0, len(context))

            # word_idxs[-1] is the first word NOT in the window
            # len(context) - word_idxs[-1].start() + 1 is the simplified of
            # (len(context) - (word_idxs[-1].start() - 1)
            # We -1 from (word_idxs[-1].start() because regex.start is inclusion
            # & Python [x:y] start value (x) is inclusion
            # But we want exclusion -> -1
            return (len(context) - word_idxs[-1].start() + 1, len(context))
        raise ValueError("Only LEFT or RIGHT should be passed.")

    def highlight(self, x: pd.Series, return_early: bool = False) -> HighlightedSpan:
        """
        1b. RIGHT: Search left of text for n words, what is the starting span of this?
        1a. In that text returned is value in there? If so we return starting span + idx where value matches
        2a. LEFT: Search for n words right, what is the char_end, ending span (+ char end)?
        2b. In that n word text, is value in there, offset its span by char_end
        """
        if not self._value:
            return NO_HIGHLIGHT
        context_field = x.get(SpanCols.SPAN_FIELD)
        if not context_field:
            return NO_HIGHLIGHT
        context = x.get(context_field)
        if not context:
            return NO_HIGHLIGHT
        char_start, char_end = get_span_positions_for_field(x, context_field)
        # These are the full text contexts as oppose to just the preview context
        # which is found in SpanCols.LEFT/RIGHT_CONTEXT.
        context_left = context[:char_start]
        context_right = context[char_end:]
        spans = {}
        if "RIGHT" in self._operator:
            left_window_start, left_window_end = self._get_context_window_span(
                context_left, Operator.RIGHT
            )
            context_window = context_left[left_window_start:left_window_end]
            spans = find_matching_spans(
                self._regex_value,
                context_window,
                context_field,
                char_offset=left_window_start,
                return_early=return_early,
            )
        if "LEFT" in self._operator:
            right_window_start, right_window_end = self._get_context_window_span(
                context_right, Operator.LEFT
            )
            context_window = context_right[right_window_start:right_window_end]
            spans = add_dicts(
                [
                    spans,
                    find_matching_spans(
                        self._regex_value,
                        context_window,
                        context_field,
                        char_offset=right_window_start + char_end,
                        return_early=return_early,
                    ),
                ]
            )

        spans = merge_spans(spans)
        if return_early:
            return spans
        if not spans.get(context_field):
            return NO_HIGHLIGHT
        # Returned highlights are indexed on the span preview field.
        span_preview_offset = int(x[SpanCols.SPAN_PREVIEW_OFFSET])
        return {
            SpanCols.SPAN_PREVIEW: [
                Span(
                    max(0, int(span.char_start) - span_preview_offset),
                    max(0, int(span.char_end) - span_preview_offset),
                )
                for span in spans[context_field]
            ]
        }

    def estimate_perf(self, df: pd.DataFrame) -> Performance:
        return Performance(
            compute_time_secs=(self._window * len(df)) // 10_000,
            peak_memory_mb=len(df) / 250,
        )

    @classmethod
    def name(
        cls,
        template_config: TemplateConfig,
        current_name: str,
        curr_lf_names: List[str],
    ) -> str:
        try:
            template_config = SpanContextTemplateSchema(**template_config).dict()
        except ValidationError:
            return current_name
        start_name = template_config["value"][:8]

        return cls.get_final_name(start_name, curr_lf_names)

    @property
    def input_schema(self) -> None:
        """It's impossible to infer the schema beforehand because context_field is a per-row value.
        It doesn't apply to all rows.
        """
        return None
