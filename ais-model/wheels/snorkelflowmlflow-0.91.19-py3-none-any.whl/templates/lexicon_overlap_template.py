import json
import os
from typing import Any, List, Optional

import pandas as pd
import regex
from pydantic import ValidationError, validator

from file_utils.core import LocalReadFsspecPath
from regex_utils.selector import select_compiled_regex
from regex_utils.trie import Trie
from snorkelflow.utils.file import resolve_data_path
from snorkelflow.utils.logging import get_logger
from templates.utils import TemplateSchema, tokenize_pattern

from .template import (
    BASE_URL,
    PATTERN_BASED,
    RELATIONSHIP_BASED,
    Template,
    TemplateConfig,
)

logger = get_logger("Studio LexiconOverlapTemplate")

CASE_SENSITIVE_DEFAULT = False
TOKENIZE_DEFAULT = True

OPERATORS = {
    "=": lambda x, y: x == y,
    "!=": lambda x, y: x != y,
    "<": lambda x, y: x < y,
    "<=": lambda x, y: x <= y,
    ">": lambda x, y: x > y,
    ">=": lambda x, y: x >= y,
}


class LexiconOverlapTemplateSchema(TemplateSchema):
    """Lexicon Overlap template

    Parameters
    ----------
    field_1 : str
        Field 1
    field_2 : str
        Field 2
    denominator_field : str
        Denominator field
    operator : {"=", "!=", "<", "<=", ">", ">="}
        Operator
    value : float
        Value
    lexicon_dict_path : str
        Path to a file containing lexicons
    case_sensitive : bool, default False
        Case sensitive or not
    """

    field_1: str
    field_2: str
    denominator_field: str
    operator: str
    value: float
    lexicon_dict_path: str
    case_sensitive: Optional[bool] = CASE_SENSITIVE_DEFAULT

    @staticmethod
    def artifact_config_keys() -> List[str]:
        return ["lexicon_dict_path"]

    @validator("operator")
    def check_operator(cls, op: str) -> str:
        if op not in OPERATORS.keys():
            raise ValueError("Invalid operator {op}")
        return op

    @validator("value")
    def check_value(cls, v: float) -> float:
        if not ((v >= 0) and (v <= 1.0)):
            raise ValueError("Invalid value for overlap ratio threshold")
        return v

    @validator("lexicon_dict_path")
    def check_exists(cls, v: str) -> str:
        if v.startswith("minio") or v.startswith("s3"):
            v = resolve_data_path(v)
        if not os.path.exists(v):
            raise ValueError(f"Path {v} does not exist")
        return v

    @validator("denominator_field")
    def check_denominator_field(cls, v: str, values: Any) -> str:
        if v not in [values.get("field_1"), values.get("field_2")]:
            raise ValueError(
                "Denominator field must be in one of the fields to compare"
            )
        return v


class LexiconOverlapTemplate(Template):
    "LF Template for lexicon overlap between two fields interfaces."

    template_type = "lexicon_overlap"
    abbreviation = "LEO"
    description = "If [field_1] and [field_2] contains [operator] [value] of keywords defined in [lexicon_dict_path], then label."
    menu_type = {
        "name": "Lexicon Overlap Builder",
        "value": template_type,
        "category": [RELATIONSHIP_BASED, PATTERN_BASED],
    }
    # TODO: Link to documentation when completed
    docs_link = BASE_URL + "lexicon-overlap-builder-relationship-based-lfs"
    template_schema = "LexiconOverlapTemplateSchema"

    def __init__(self, template_config: TemplateConfig) -> None:
        self._lexicon_dict_path = template_config["lexicon_dict_path"]
        self._denominator_field = template_config[
            "denominator_field"
        ]  # get denominator
        self._another_field = (
            template_config["field_2"]
            if template_config["field_1"] == self._denominator_field
            else template_config["field_1"]
        )
        self._case_sensitive = template_config.get(
            "case_sensitive", CASE_SENSITIVE_DEFAULT
        )

        op_str = template_config["operator"]
        self._op = OPERATORS[op_str]
        self._value = template_config["value"]
        self.lexicon_lookup_table = {}
        flags = regex.IGNORECASE if not self._case_sensitive else 0
        lexicon_dict_path = resolve_data_path(self._lexicon_dict_path)
        trie = Trie()
        with LocalReadFsspecPath(lexicon_dict_path) as local_path:
            with open(local_path, "r") as f:
                lexicon_dict = json.load(f)
                for lexicon_id, common_entity_forms in lexicon_dict.items():
                    for value in common_entity_forms:
                        trie.add(value)
                        self.lexicon_lookup_table[value.lower()] = lexicon_id
        pattern = trie.pattern()
        regex_pattern = tokenize_pattern(pattern) if pattern else ""
        self._regex_pattern = select_compiled_regex(regex_pattern, flags=flags)

        logger.debug(
            f"Building {self.template_type} template on field {self._denominator_field} and {self._another_field}"
            f"with Lexicon Dict URL {self._lexicon_dict_path}"
            f"for regex {self._regex_pattern}."
        )

    @classmethod
    def name(
        cls,
        template_config: TemplateConfig,
        current_name: str,
        curr_lf_names: List[str],
    ) -> str:
        try:
            template_config = LexiconOverlapTemplateSchema(**template_config).dict()
        except ValidationError:
            return current_name
        start_name = "-".join([template_config["lexicon_dict_path"]])[:8]

        return cls.get_final_name(start_name, curr_lf_names)

    def _get_lexicon_ids(self, x: pd.Series, field: str) -> set:
        field_value = str(x[field])
        matches = self._regex_pattern.finditer(field_value)
        lexicon_id = {
            self.lexicon_lookup_table[m.group(0).lower()]
            for m in matches
            if m.group(0).lower() in self.lexicon_lookup_table
        }
        return lexicon_id

    def check(self, x: pd.Series) -> bool:
        try:
            lexicon_id_1 = self._get_lexicon_ids(x, self._denominator_field)
            lexicon_id_2 = self._get_lexicon_ids(x, self._another_field)
            overlap = len(lexicon_id_1.intersection(lexicon_id_2)) / len(lexicon_id_1)
            return self._op(float(overlap), self._value)
        except (
            ValueError
        ):  # it is possible that len(lexicon_id_1) == 0, which raises divideByZero error, in this case we return False
            return False
