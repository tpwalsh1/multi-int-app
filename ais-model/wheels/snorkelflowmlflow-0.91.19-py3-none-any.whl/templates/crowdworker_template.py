from typing import List

import pandas as pd
from pydantic import ValidationError, validator

from snorkelflow.types.load import TEMP_UID_COL
from snorkelflow.utils.logging import get_logger
from templates.utils import (
    TemplateSchema,
    load_list_from_csv_file,
    validate_load_list_from_csv_file,
)

from .template import BASE_URL, EXTERNAL_RESOURCES, Template, TemplateConfig

logger = get_logger("Studio CrowdWorkerTemplate")


class CrowdWorkerTemplateSchema(TemplateSchema):
    """Crowd Worker template

    Parameters
    ----------
    filepath : str
        Path to a file
    """

    filepath: str

    @staticmethod
    def artifact_config_keys() -> List[str]:
        return ["filepath"]

    @validator("filepath")
    def validate_filepath(cls, v: str) -> str:
        msg = validate_load_list_from_csv_file(v)
        if msg is not True:
            raise ValueError(f"Could not read {v}: {msg}")
        return v


# TODO: Add functionality for multiple crowdworkers
class CrowdWorkerTemplate(Template):

    """LF Template for labels from a single crowdworker."""

    template_type = "crowdworker"
    abbreviation = "CWD"
    description = "If the UID of an example is found in newline-delimited file at [filepath], then label. Filepath must be in a S3 bucket, MinIO, or the shared Snorkel Flow mount_directory."
    menu_type = {
        "name": "Crowdworker Builder",
        "value": template_type,
        "category": [EXTERNAL_RESOURCES],
    }
    docs_link = BASE_URL + "crowdworker-builder-external-resources-lfs"
    template_schema = "CrowdWorkerTemplateSchema"

    def __init__(self, template_config: TemplateConfig) -> None:
        filepath = template_config["filepath"]

        logger.info(f"Reading uid list from file at {filepath}.")

        self._labeled_uids = set(load_list_from_csv_file(filepath))

        logger.debug(
            f"Building {self.template_type} template from filepath {filepath}."
        )

    @classmethod
    def name(
        cls,
        template_config: TemplateConfig,
        current_name: str,
        curr_lf_names: List[str],
    ) -> str:
        try:
            template_config = CrowdWorkerTemplateSchema(**template_config).dict()
        except ValidationError:
            return current_name
        start_name = template_config["filepath"]

        return cls.get_final_name(start_name, curr_lf_names)

    @classmethod
    def full_info(cls, template_config: TemplateConfig) -> str:
        try:
            template_config = CrowdWorkerTemplateSchema(**template_config).dict()
        except ValidationError:
            return ""

        return template_config["filepath"]

    def check(self, x: pd.Series) -> bool:
        if TEMP_UID_COL in x and x[TEMP_UID_COL] in self._labeled_uids:
            return True

        elif str(x.name) in self._labeled_uids:
            return True

        else:
            return False
