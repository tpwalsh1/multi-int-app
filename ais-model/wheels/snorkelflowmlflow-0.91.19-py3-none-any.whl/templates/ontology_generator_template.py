from pydantic import BaseModel

from snorkelflow.utils.logging import get_logger

from .template import BASE_URL, GENERATORS, Template

logger = get_logger("Studio OntologyGeneratorTemplate")


class OntologyGeneratorTemplateSchema(BaseModel):
    ontology: str
    matching_strategy: str


class OntologyGeneratorTemplate(Template):
    template_type = "ontology_generator"
    abbreviation = "OTLG"
    description = "Ontology LF generator."
    menu_type = {
        "name": "Ontology Generator",
        "value": template_type,
        "category": [GENERATORS],
    }
    docs_link = BASE_URL  # Default docs link URL
