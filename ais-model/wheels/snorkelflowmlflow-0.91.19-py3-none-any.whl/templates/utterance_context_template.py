from enum import Enum
from typing import Any, Dict, List

import pandas as pd
from pydantic import StrictInt, ValidationError, validator

from snorkelflow.types.columns import ConvCols
from snorkelflow.types.performance import Performance
from snorkelflow.utils.logging import get_logger
from templates.utils import (
    CASE_SENSITIVE_DEFAULT,
    NO_HIGHLIGHT,
    REGEX_DEFAULT,
    TOKENIZE_DEFAULT,
    HighlightedSpan,
    PatternMatchTemplateSchema,
    compile_regex_for_span_builders,
    find_matching_spans,
)

from .template import BASE_URL, CONVERSATION_BASED, TemplateConfig, TextTemplate

logger = get_logger("Studio Template")


class Operator(str, Enum):
    """Indicates whether the current utterance is "BEFORE" or "AFTER" or
    "BEFORE OR AFTER" a given value.
    """

    BEFORE = "BEFORE"
    AFTER = "AFTER"
    BEFORE_OR_AFTER = "BEFORE OR AFTER"


class Speakers(str, Enum):
    """In addition to usernames, we allow a few default speaker values -
    ANY: all speakers are considered in the search
    CURRENT: Only the speaker for the current utterances is considered
    OTHER: All speakers except the current are considered
    """

    ANY = "any"
    CURRENT = "current"
    OTHER = "other"


class UtteranceContextTemplateSchema(PatternMatchTemplateSchema):
    """Utterance Context template

    LF Template specific to conversational use-case. Looks for keywords/regex pattern in
    specified number of previous or next utterances.

    Parameters
    ----------
    operator : {"BEFORE", "AFTER", "BEFORE OR AFTER"}
        Indicates whether to search before or after the current utterance.
    window : int, default 1
        How many utterances should we restrict the search window to.
    speakers : {"any", "current", "other", or speakername}
        List of speakers whose utterances will be considered for matching
    value : str
        The value we should be searching for.
    regex : bool, default False
        If this is True, `value` should be a RegEx Pattern.
    case_sensitive : bool, default False
        Case sensitive or not
    tokenize : bool, default False
        Only can be True if `regex` is False, we will search for an
        exact word match between value and span context and not match on substrings.
    """

    # this is similar to Span Context Builder
    operator: Operator
    window: StrictInt = 1  # The number of utterances surrounding the current utterance that we will search.

    # specific to conversational
    speakers: List[str] = [
        Speakers.ANY
    ]  # other possible values are list of usernames, 'current', 'other'

    @validator("window")
    def check_window(cls, v: int) -> int:
        if v < 0:
            raise ValueError(
                f"Invalid window value: {v}. Must be integer greater than 0."
            )
        return v


class UtteranceContextTemplate(TextTemplate):
    template_type = "utterance_context"
    abbreviation = "UCX"
    description = "If the value is included in [window] utterances [before, after, etc.] the current utterance, then label."
    menu_type = {
        "name": "Utterance Context Builder",
        "value": template_type,
        "category": [CONVERSATION_BASED],
    }
    docs_link = BASE_URL + "utterance-context-builder"
    template_schema = "UtteranceContextTemplateSchema"

    def __init__(self, template_config: TemplateConfig) -> None:
        """LF Template based on surrounding utterances."""

        self._operator = template_config["operator"]
        self._is_regex_value = template_config.get("regex", REGEX_DEFAULT)
        self._case_sensitive = template_config.get(
            "case_sensitive", CASE_SENSITIVE_DEFAULT
        )
        self._tokenize = template_config.get("tokenize", TOKENIZE_DEFAULT)
        self._window = template_config["window"]
        self._value = template_config["value"]
        self._regex_value = compile_regex_for_span_builders(
            self._value,
            None,
            self._is_regex_value,
            self._tokenize,
            self._case_sensitive,
        )

        self._speakers = set(template_config["speakers"])

        logger.debug(
            f"Building {self.template_type} template with operator {self._operator} "
            f"and value {self._regex_value} which is {self._is_regex_value} a regex, within window {self._window} "
            f"with utterances from speakers {self._speakers}"
        )

    def _get_shortlisted_speakers(
        self, speakers_to_include: set, all_speakers: Dict[str, Any], curr_speaker: str
    ) -> set:
        """Returns a set of speakers (in lowercase) whose utterances will be considered for matching.

        Args:
            speakers_to_include (set): Given input by the user
            all_speakers (Dict[str, Any]): All speakers that are present in the conversation
            curr_speaker (str): Speaker of the current utterance
        """
        curr_speaker = curr_speaker.lower()
        all_other_speakers_set = {
            k.lower() for k in all_speakers.keys() if k.lower() != curr_speaker
        }

        if Speakers.ANY in speakers_to_include:
            return all_other_speakers_set.union({curr_speaker})

        curr_set = set()

        for speaker in speakers_to_include:
            if speaker == Speakers.OTHER:
                curr_set.update(all_other_speakers_set)
            elif speaker == Speakers.CURRENT:
                curr_set.add(curr_speaker)
            else:
                curr_set.add(speaker.lower())

        return curr_set

    def highlight(self, x: pd.Series, return_early: bool = True) -> HighlightedSpan:
        """
        We don't support highlighting in document mode right now.
        This function returns if the LF should fire or not i.e. if any text is matching or not.
        Return_early is therefore default true.
        """
        if not self._value:
            return NO_HIGHLIGHT

        conversation_json = x[
            ConvCols.CONV_COL
        ]  # we store entire conversation json with each datapoint
        utterances = conversation_json[ConvCols.UTTERANCES]
        total_num_utterances = len(utterances)
        curr_idx = x[ConvCols.IDX_COL]
        curr_speaker = utterances[curr_idx][ConvCols.SPEAKER]
        speakers_set = self._get_shortlisted_speakers(
            self._speakers, x[ConvCols.CONV_COL][ConvCols.SPEAKERS], curr_speaker
        )

        before_idxs: List[int] = []
        if Operator.BEFORE in self._operator:
            temp_idx = curr_idx - 1
            while temp_idx >= 0 and len(before_idxs) < self._window:
                if utterances[temp_idx][ConvCols.SPEAKER].lower() in speakers_set:
                    before_idxs.append(temp_idx)
                temp_idx -= 1
        before_idxs.reverse()

        after_idxs: List[int] = []
        if Operator.AFTER in self._operator:
            temp_idx = curr_idx + 1
            while temp_idx < total_num_utterances and len(after_idxs) < self._window:
                if utterances[temp_idx][ConvCols.SPEAKER].lower() in speakers_set:
                    after_idxs.append(temp_idx)
                temp_idx += 1

        idxs = before_idxs + after_idxs

        spans = {}

        for idx in idxs:
            spans = find_matching_spans(
                self._regex_value,
                utterances[idx][ConvCols.UTTERANCE],
                "field",  # dummy value
                return_early=return_early,  # True always
            )

            if spans:
                # if a span is found, it should return from here because return_early is True
                return spans  # will return TRUTHY_NO_HIGHLIGHT

        if not spans:
            return NO_HIGHLIGHT

        # should not reach here
        return spans

    def estimate_perf(self, df: pd.DataFrame) -> Performance:
        # Should depend on window, num rows, utterance size.
        num_utterances = len(df) * self._window
        return Performance(
            compute_time_secs=num_utterances * 0.0002,
            peak_memory_mb=num_utterances * 0.0006,
        )

    @classmethod
    def name(
        cls,
        template_config: TemplateConfig,
        current_name: str,
        curr_lf_names: List[str],
    ) -> str:
        try:
            template_config = UtteranceContextTemplateSchema(**template_config).dict()
        except ValidationError:
            return current_name
        start_name = template_config["value"][:8]
        return cls.get_final_name(start_name, curr_lf_names)
