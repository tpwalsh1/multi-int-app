from typing import Any, Dict, List, Optional

import pandas as pd
import re2
import regex
from pydantic import ValidationError, validator

from snorkelflow.utils.logging import get_logger
from templates.utils import (
    NO_HIGHLIGHT,
    HighlightedSpan,
    TemplateSchema,
    find_matching_spans,
)

from .template import BASE_URL, PATTERN_BASED, TemplateConfig, TextTemplate

CASE_SENSITIVE_DEFAULT = False
DOT_MATCHES_DEFAULT = False
START_END_MATCH_DEFAULT = False
STRICT_LOCATION_MATCH_DEFAULT = True

logger = get_logger("Studio FullTextRegexTemplate")


class FullTextRegexTemplateSchema(TemplateSchema):
    """Full Text Regex template

    Parameters
    ----------
    columns : List[str]
        List of fields to search
    regex_pattern : str
        Regex pattern
    case_sensitive : bool, default False
        Case sensitive or not
    dot_matches_newline : bool, default False
        If True, make a dot `.` match any character at all, including a newline
    start_end_match_line : bool, default False
        If True, the character `^` and `$` match at the beginning of the string and at the end of the string, respectively.
    strict_location_match : bool, default True
        Strict location match or not
    """

    regex_pattern: str
    columns: List[str]
    case_sensitive: Optional[bool] = CASE_SENSITIVE_DEFAULT
    dot_matches_newline: Optional[bool] = DOT_MATCHES_DEFAULT
    start_end_match_line: Optional[bool] = START_END_MATCH_DEFAULT
    strict_location_match: Optional[bool] = STRICT_LOCATION_MATCH_DEFAULT

    @validator("regex_pattern")
    def validate_regex(cls, v: str) -> str:
        try:
            regex.compile(v)
        except Exception:
            raise ValueError(f"Invalid regex pattern {v}")
        return v


class FullTextRegexTemplate(TextTemplate):
    """LF Template for text-based regex interfaces."""

    template_type = "full_text"
    abbreviation = "FTR"
    description = "If [fields] contains the regular expression [regex] then label."
    menu_type = {
        "name": "Full Text Regex Builder",
        "value": template_type,
        "category": [PATTERN_BASED],
    }
    docs_link = BASE_URL + "full-text-regex-builder-pattern-based-lfs"
    template_schema = "FullTextRegexTemplateSchema"

    def __init__(self, template_config: TemplateConfig) -> None:
        """Check a given field for the given regex, opt. filling in {{span}} markers"""

        self._fields = template_config["columns"]
        self._flags = 0  # The default value for flags
        # Use 'get' instead of indexing directly to maintain backwards compatibility
        if not template_config.get("case_sensitive", CASE_SENSITIVE_DEFAULT):
            self._flags = self._flags | regex.I
        if template_config.get("dot_matches_newline", DOT_MATCHES_DEFAULT):
            self._flags = self._flags | regex.S
        if template_config.get("start_end_match_line", START_END_MATCH_DEFAULT):
            self._flags = self._flags | regex.M
        self._regex_pattern = template_config["regex_pattern"]

        self._strict_location_match = template_config.get(
            "strict_location_match", STRICT_LOCATION_MATCH_DEFAULT
        )
        self._rx = regex.compile(
            r"(?P<highlight>" + self._regex_pattern + r")", flags=self._flags
        )

        logger.debug(
            f"Building {self.template_type} template with pattern '{self._regex_pattern}'"
        )

    def highlight(self, x: pd.Series, return_early: bool = False) -> HighlightedSpan:
        if not self._regex_pattern:
            return NO_HIGHLIGHT

        all_highlights = {}
        for field in self._fields:
            field_value = str(x[field])
            sub_highlight = find_matching_spans(
                self._rx, field_value, field, return_early=return_early
            )
            all_highlights.update(sub_highlight)
        return all_highlights

    @classmethod
    def name(
        cls,
        template_config: TemplateConfig,
        current_name: str,
        curr_lf_names: List[str],
    ) -> str:
        try:
            template_config = FullTextRegexTemplateSchema(**template_config).dict()
        except ValidationError:
            return current_name
        start_name = re2.sub(r"[^\w]", "", template_config["regex_pattern"])

        return cls.get_final_name(start_name, curr_lf_names)

    @classmethod
    def full_info(cls, template_config: TemplateConfig) -> str:
        try:
            template_config = FullTextRegexTemplateSchema(**template_config).dict()
        except ValidationError:
            return ""

        return re2.sub(r"[^\w]", "", template_config["regex_pattern"])

    @property
    def input_schema(self) -> Dict[str, Any]:
        return {field: Any for field in self._fields}
