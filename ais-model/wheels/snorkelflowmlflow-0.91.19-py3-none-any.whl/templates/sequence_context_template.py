from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd
import regex
from pydantic import StrictInt, ValidationError, validator

from regex_utils.selector import select_compiled_regex
from snorkelflow.types.performance import Performance
from snorkelflow.utils.logging import get_logger
from templates.utils import (
    ContextOperator,
    PatternMatchTemplateSchema,
    compile_regex_for_span_builders,
)

from .template import BASE_URL, SEQUENCE_PATTERN_BASED, SequenceTemplate, TemplateConfig

logger = get_logger("Studio SequenceContextTemplate")

CASE_SENSITIVE_DEFAULT = False
TOKENIZE_DEFAULT = True
WORD_BOUNDARY_TOKENIZER_DEFAULT = True


class SequenceContextTemplateSchema(PatternMatchTemplateSchema):
    """Sequence Context template

    Parameters
    ----------
    field : str
        Field
    operator : {"LEFT", "RIGHT", "LEFT OR RIGHT"}
        Operator
    value : str
        Pattern
    case_sensitive : bool, default False
        Case sensitive or not
    token_len : int
        Length of a token
    case_sensitive : bool, default False
        Case sensitive or not
    tokenize : bool, default False
        Tokenize or not
    regex : bool, default False
        If True, patterns are treated as regex
    include_context : Optional[bool] = False
    word_boundary_tokenizer : Optional[bool] = True
    """

    operator: ContextOperator
    token_len: StrictInt
    field: str
    include_context: Optional[bool] = False
    word_boundary_tokenizer: Optional[bool] = True

    @validator("token_len")
    def check_token_len(cls, v: int) -> int:
        if v < 1:
            raise ValueError(f"Invalid token_len value: {v}. Must be integer >= 1.")
        return v


class SequenceContextTemplate(SequenceTemplate):
    "LF Template for Sequence context based interfaces."

    template_type = "sequence_context"
    abbreviation = "SCON"
    description = "If [field] contains any of [keywords/phrases], then label the matching character offsets."
    menu_type = {
        "name": "Sequence Context Builder",
        "value": template_type,
        "category": [SEQUENCE_PATTERN_BASED],
    }

    docs_link = BASE_URL + "sequence-context-builder"
    template_schema = "SequenceContextTemplateSchema"

    def __init__(self, template_config: TemplateConfig) -> None:
        self._operator = template_config["operator"]
        self._is_regex_value = template_config.get("regex", False)
        # Use 'get' instead of indexing directly to maintain backwards compatibility
        self._case_sensitive = template_config.get(
            "case_sensitive", CASE_SENSITIVE_DEFAULT
        )
        self._tokenize = template_config.get("tokenize", TOKENIZE_DEFAULT)
        self._token_length = template_config["token_len"]
        self._value = template_config["value"]
        self._field = template_config["field"]
        self._word_boundary_tokenizer = template_config.get(
            "word_boundary_tokenizer", WORD_BOUNDARY_TOKENIZER_DEFAULT
        )
        self._tokenized_field = "tokenized_" + self._field

        self._regex_value = compile_regex_for_span_builders(
            self._value,
            None,
            self._is_regex_value,
            self._tokenize,
            self._case_sensitive,
        )
        self._regex_word_match = select_compiled_regex(r"\S+")
        self._include_context = template_config["include_context"]

        logger.debug(
            f"Building {self.template_type} template with operator {self._operator} "
            f"and value {self._regex_value} for a sequence length of {self._token_length} tokens"
            f"with context included {self._include_context}"
        )

    def check(self, x: pd.Series) -> List[Tuple[int, int]]:
        # 1) Find char start, end of regex matches
        field_value = x[self._field]
        regex_matches = self._regex_value.finditer(field_value)

        # 2) Find token  idx start and end of matches
        match_token_bounds = []
        matches: List[Tuple[int, int]] = []

        if self._word_boundary_tokenizer:
            tokens = [m.span() for m in self._regex_word_match.finditer(field_value)]
        else:  # Using tokenized_field
            try:
                tokens = [(val[0], val[1]) for val in x[self._tokenized_field]]
            except KeyError:
                raise ValueError(
                    f"Please ensure the tokenized field: {self._tokenized_field} exists."
                )

        matched_spans = []
        for match in regex_matches:
            if "highlight" in match.groupdict():
                matched_spans.append(match.span("highlight"))

        span_start_indexes = np.searchsorted(
            [token[1] for token in tokens],
            [match[0] for match in matched_spans],
            side="left",
        )
        span_end_indexes = np.searchsorted(
            [token[1] for token in tokens],
            [match[1] for match in matched_spans],
            side="left",
        )

        for span_start_index, span_end_index in zip(
            span_start_indexes, span_end_indexes
        ):
            match_token_bounds.append((span_start_index, span_end_index))

        # 3) Apply max & min spans,
        if "RIGHT" in self._operator:
            for match_token_bound, matched_span in zip(
                match_token_bounds, matched_spans
            ):
                token_idx_start, token_idx_end = match_token_bound
                if self._include_context:
                    start = token_idx_start
                else:
                    start = token_idx_end + 1
                to_return_tokens = tokens[
                    start : token_idx_end + self._token_length + 1
                ]
                if to_return_tokens:
                    # Adjust char start to matched span if matching is not on tokens
                    if self._include_context and not self._tokenize:
                        char_start = matched_span[0]
                    else:
                        char_start = to_return_tokens[0][0]
                    char_end = to_return_tokens[-1][1]
                    matches.append((char_start, char_end))

        if "LEFT" in self._operator:
            for match_token_bound, matched_span in zip(
                match_token_bounds, matched_spans
            ):
                token_idx_start, token_idx_end = match_token_bound
                start = max(0, token_idx_start - self._token_length)
                if self._include_context:
                    end = token_idx_end + 1
                else:
                    end = token_idx_start
                to_return_tokens = tokens[start:end]
                if to_return_tokens:
                    char_start = to_return_tokens[0][0]
                    # Adjust char end to matched span if matching is not on tokens
                    if self._include_context and not self._tokenize:
                        char_end = matched_span[1]
                    else:
                        char_end = to_return_tokens[-1][1]
                    matches.append((char_start, char_end))

        if "LEFT OR RIGHT" in self._operator:
            sorted_spans = sorted(matches, key=lambda x: x[0])
            merged: List[List[int]] = []
            for start, end in sorted_spans:
                if merged and merged[-1][1] >= start:
                    merged[-1][1] = max(merged[-1][1], end)
                else:
                    merged.append([start, end])
            return [(start, end) for (start, end) in merged]

        return matches

    def estimate_perf(self, df: pd.DataFrame) -> Performance:
        num_docs = len(df)
        avg_row_size = df[self._field].map(len).mean()
        return Performance(
            compute_time_secs=(num_docs * avg_row_size * avg_row_size) / 1_200_000_000,
            peak_memory_mb=(num_docs * avg_row_size) / 24000,
        )

    @classmethod
    def name(
        cls,
        template_config: TemplateConfig,
        current_name: str,
        curr_lf_names: List[str],
    ) -> str:
        try:
            template_config = SequenceContextTemplateSchema(**template_config).dict()
        except ValidationError:
            return current_name
        start_name = regex.sub(r"[^\w]", "", template_config["value"])[:8]
        return cls.get_final_name(start_name, curr_lf_names)

    @property
    def input_schema(self) -> Dict[str, Any]:
        schema = {self._field: Any}

        if self._word_boundary_tokenizer:
            pass
        else:
            schema[self._tokenized_field] = Any

        return schema
