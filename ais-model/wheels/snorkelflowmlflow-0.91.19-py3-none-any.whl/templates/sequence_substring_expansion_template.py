from typing import List, Optional, Tuple

import pandas as pd
import regex
from pydantic import ValidationError, validator

from regex_utils.selector import select_compiled_regex
from snorkelflow.types.performance import Performance
from snorkelflow.utils.logging import get_logger
from templates.utils import (
    CASE_SENSITIVE_DEFAULT,
    SpanPatternMatchOperator,
    TemplateSchema,
    tokenize_pattern,
)

from .template import BASE_URL, SEQUENCE_PATTERN_BASED, SequenceTemplate, TemplateConfig

logger = get_logger("Studio SequenceSubstringExpansionTemplate")

REGEX_MATCH_STR = r"\w*"


class SequenceSubstringExpansionTemplateSchema(TemplateSchema):
    """Sequence Substring Expansion template

    Parameters
    ----------
    field : str
    operator : {"MATCHES", "CONTAINS", "STARTS", "ENDS"}
    value : str
    case_sensitive :bool, default False
    regex : bool, default False
    """

    field: str
    operator: SpanPatternMatchOperator
    value: str
    case_sensitive: Optional[bool] = CASE_SENSITIVE_DEFAULT
    regex: Optional[bool] = False

    @validator("value")
    def check_operator(cls, value: str) -> str:
        if len(value) == 0:
            raise ValueError("Invalid empty value")
        return value


class SequenceSubstringExpansionTemplate(SequenceTemplate):
    "LF Template for Sequence text-based interfaces."

    template_type = "sequence_substring_expansion"
    abbreviation = "SSE"
    description = "If token in [field] [operator] [value] then label the character offsets of the token."
    menu_type = {
        "name": "Sequence Substring Expansion Builder",
        "value": template_type,
        "category": [SEQUENCE_PATTERN_BASED],
    }
    # TODO: Link to documentation when completed
    docs_link = BASE_URL + "sequence-substring-expansion-builder"
    template_schema = "SequenceSubstringExpansionTemplateSchema"

    def __init__(self, template_config: TemplateConfig) -> None:
        self._field = template_config["field"]
        self._value = template_config["value"]
        self._is_regex_value = template_config["regex"]
        regex_str = self._value if self._is_regex_value else regex.escape(self._value)
        regex_str = rf"({regex_str})"

        self._operator = SpanPatternMatchOperator(template_config["operator"]).name
        if self._operator:
            if self._operator == SpanPatternMatchOperator.STARTS:
                regex_str = regex_str + REGEX_MATCH_STR
            elif self._operator == SpanPatternMatchOperator.CONTAINS:
                regex_str = REGEX_MATCH_STR + regex_str + REGEX_MATCH_STR
            elif self._operator == SpanPatternMatchOperator.ENDS:
                regex_str = REGEX_MATCH_STR + regex_str

        regex_str = tokenize_pattern(regex_str)

        self._case_sensitive = template_config["case_sensitive"]
        flags = 0
        if not self._case_sensitive:
            flags = flags | regex.IGNORECASE

        self._regex = select_compiled_regex(regex_str, flags=flags)
        logger.debug(
            f"Building {self.template_type} template with pattern '{regex_str}'"
        )

    @classmethod
    def name(
        cls,
        template_config: TemplateConfig,
        current_name: str,
        curr_lf_names: List[str],
    ) -> str:
        try:
            template_config = SequenceSubstringExpansionTemplateSchema(
                **template_config
            ).dict()
        except ValidationError:
            return current_name
        start_name = template_config["value"][:8]

        return cls.get_final_name(start_name, curr_lf_names)

    def check(self, x: pd.Series) -> List[Tuple[int, int]]:
        "Sequence LFs vote with char offsets, not boolean values."
        field_value = str(x[self._field])
        matches = self._regex.finditer(field_value)
        return [(m.start(0), m.end(0)) for m in matches]

    def estimate_perf(self, df: pd.DataFrame) -> Performance:
        total_data_size = df[self._field].map(len).sum()
        num_docs = len(df)
        return Performance(
            compute_time_secs=total_data_size / 8_000_000,
            peak_memory_mb=num_docs / 1400,
        )
