from typing import Dict, Union

import pandas as pd

from snorkelflow.utils.logging import get_logger
from templates.model_based_template import ModelBasedTemplate, ModelBasedTemplateSchema

from .template import BASE_URL, EXTERNAL_RESOURCES, TemplateConfig

logger = get_logger("Studio ModelBasedTemplate")


class MultiPolarModelBasedTemplateSchema(ModelBasedTemplateSchema):
    """Multipolar Model Based template

    Parameters
    ----------
    include_fields : List[str]
        The fields to include in the model featurization.
    target_field : str
        The field containing the model predictions.
    model_type : str
        The specific model used, must be contained in:
            ["zsl_text_match", "zsl_entailment",  "masked_lm",
            "logistic_regression",  "one_class_svm", "tfidf_logreg", "setfit",
            "sdnet", "sequence_embedding"]
    model_name : str
        A user specified string name given to the trained model.
    value : None
        Inherited from ModelBasedTemplateSchema, but not used.
    dirpath : str
        The path to the stored model in minio.
    threshold : float
        The confidence threshold below which this LF should abstain.
    unique_model_name : Optional[str] = None
        A unique name for the model, usually the same as dirpath.
    is_multilabel : bool = False
        Whether or not the task this LF is being applied to is multi-label
    multilabel_absent_as_abstain : bool = True
        If this is a multi-label task, True if we should replace "absent" votes
        output by the model with "abstain" votes
    inv_label_map : Dict[str, int]
        A mapping from the user's class labels to the LF's class labels.
    """

    value: None = None  # type: ignore
    inv_label_map: Dict[int, str]


class MultiPolarModelBasedTemplate(ModelBasedTemplate):
    """Template for all multipolar model based LFs"""

    template_type = "model_based_multipolar"
    abbreviation = "MBM"
    description = (
        "Cached multipolar votes based on predictions from a ModelBased featurizer."
    )
    menu_type = {
        "name": "Model Based (Multipolar)",
        "value": template_type,
        "category": [EXTERNAL_RESOURCES],
    }

    docs_link = BASE_URL
    template_schema = "MultiPolarModelBasedTemplateSchema"
    template_schema_cls = MultiPolarModelBasedTemplateSchema

    def __init__(self, template_config: TemplateConfig) -> None:
        super().__init__(template_config)
        self.inv_label_map = template_config["inv_label_map"]

    def check(self, x: pd.Series) -> Union[str, Dict]:  # type: ignore
        return self.get_prediction(x, self.inv_label_map)  # type: ignore
