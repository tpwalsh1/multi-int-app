from ipaddress import IPv4Network, IPv6Network, ip_network
from typing import List, Union

import pandas as pd
from pydantic import ValidationError, validator

from snorkelflow.utils.logging import get_logger
from templates.utils import TemplateSchema

from .template import BASE_URL, NETWORK_BASED, Template, TemplateConfig

logger = get_logger("Studio IpTemplate")


class IpAddressTemplateSchema(TemplateSchema):
    """IP Address template

    Parameters
    ----------
    field : str
        Field
    network : str
        Network (e.g., "2.0.0.0/31" and "64::1182:0/112")
    """

    field: str
    network: str

    @validator("network")
    def check_network(cls, network: str) -> str:
        try:
            ip_network(network)
        except Exception:
            raise ValueError(f"Invalid network {network}")
        return network


class IpAddressTemplate(Template):

    """LF Template based on IP address"""

    template_type = "ip_address"
    abbreviation = "IPA"
    description = (
        "If [field] has an IP address that is a subnet of [network], then label."
    )
    menu_type = {
        "name": "IP Address Builder",
        "value": template_type,
        "category": [NETWORK_BASED],
    }
    docs_link = BASE_URL + "ip-address-builder-network-lfs"
    template_schema = "IpAddressTemplateSchema"

    def __init__(self, template_config: TemplateConfig) -> None:
        """LF Template based on IP network.

        Heuristic:
        "If [field] has an IP address that is a subnet of [network], return True"
        """

        self._field = template_config["field"]
        self._network = ip_network(template_config["network"])

        logger.debug(
            f"Building {self.template_type} template on field {self._field} with "
            f"network {self._network}."
        )

    @classmethod
    def name(
        cls,
        template_config: TemplateConfig,
        current_name: str,
        curr_lf_names: List[str],
    ) -> str:
        try:
            template_config = IpAddressTemplateSchema(**template_config).dict()
        except ValidationError:
            return current_name
        start_name = template_config["network"]

        return cls.get_final_name(start_name, curr_lf_names)

    @classmethod
    def full_info(cls, template_config: TemplateConfig) -> str:
        try:
            template_config = IpAddressTemplateSchema(**template_config).dict()
        except ValidationError:
            return ""

        return template_config["network"]

    def check(self, x: pd.Series) -> bool:
        try:
            field_value = ip_network(x[self._field])
        except ValueError:
            return False
        return IpAddressTemplate.is_subnet_of(field_value, self._network)

    @classmethod
    def is_subnet_of(
        cls, a: Union[IPv4Network, IPv6Network], b: Union[IPv4Network, IPv6Network]
    ) -> bool:
        """Returns boolean: is `a` a subnet of `b`?

        This method is required for py36.
        """
        a_len = a.prefixlen
        b_len = b.prefixlen
        return a_len >= b_len and a.supernet(a_len - b_len) == b
