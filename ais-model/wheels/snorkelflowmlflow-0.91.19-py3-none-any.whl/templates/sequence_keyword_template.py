from typing import Any, Dict, List, Optional, Pattern, Tuple

import pandas as pd
import regex
from pydantic import ValidationError, validator

from regex_utils.selector import select_compiled_regex
from snorkelflow.types.performance import Performance
from snorkelflow.utils.logging import get_logger
from templates.utils import TemplateSchema, tokenize_pattern

from .template import BASE_URL, SEQUENCE_PATTERN_BASED, SequenceTemplate, TemplateConfig

logger = get_logger("Studio SequenceKeywordTemplate")

CASE_SENSITIVE_DEFAULT = False
TOKENIZE_DEFAULT = True


class SequenceKeywordTemplateSchema(TemplateSchema):
    """Sequence Keyword template

    Parameters
    ----------
    field : str
        Field
    keywords : List[str]
        List of keywords
    case_sensitive : bool, default False
        Case sensitive or not
    tokenize : bool, default True
        Tokenize or not
    """

    keywords: List[str]
    field: str
    case_sensitive: Optional[bool] = CASE_SENSITIVE_DEFAULT
    tokenize: Optional[bool] = TOKENIZE_DEFAULT

    @validator("keywords")
    def check_keywords(cls, v: List[str]) -> List[str]:
        if len(v) > 10:
            raise ValueError(
                "Only 10 keywords are supported. Please enter at most 10 keywords."
            )
        return v


class SequenceKeywordTemplate(SequenceTemplate):
    "LF Template for Sequence keyword-based interfaces."

    template_type = "sequence_keyword"
    abbreviation = "SKEY"
    description = "If [field] contains any of [keywords/phrases], then label the matching character offsets."
    menu_type = {
        "name": "Sequence Keyword Builder",
        "value": template_type,
        "category": [SEQUENCE_PATTERN_BASED],
    }
    # TODO: Link to documentation when completed
    docs_link = BASE_URL + "sequence-keyword-builder"
    template_schema = "SequenceKeywordTemplateSchema"

    def __init__(self, template_config: TemplateConfig) -> None:
        self._keywords = list(set(template_config["keywords"]))
        self._field = template_config["field"]
        self._flags = 0  # The default value for flags
        if not template_config.get("case_sensitive", CASE_SENSITIVE_DEFAULT):
            self._flags = self._flags | regex.I
        self._tokenize = template_config.get("tokenize", TOKENIZE_DEFAULT)
        self._group_idx = 1  # The default value for groups
        if not self._tokenize:
            self._group_idx = 0

        self._regex_union_keywords = self._compile_regex()

        logger.debug(
            f"Building {self.template_type} template on field {self._field} with "
            f"regex {self._regex_union_keywords}, "
            f"for keywords {self._keywords}."
        )

    def _compile_regex(self) -> Pattern:
        """Compiles keywords into a union regex. We are limited to 3 keywords
        at the time this was written (git grep "const MAX_KEYWORDS").
        """
        s = r"|".join([regex.escape(kw) for kw in self._keywords])
        s = rf"({s})"
        if self._tokenize:
            s = tokenize_pattern(s)
        return select_compiled_regex(s, flags=self._flags)

    @classmethod
    def name(
        cls,
        template_config: TemplateConfig,
        current_name: str,
        curr_lf_names: List[str],
    ) -> str:
        try:
            template_config = SequenceKeywordTemplateSchema(**template_config).dict()
        except ValidationError:
            return current_name
        start_name = "-".join(template_config["keywords"])[:8]

        return cls.get_final_name(start_name, curr_lf_names)

    def check(self, x: pd.Series) -> List[Tuple[int, int]]:
        "Sequence LFs vote with char offsets, not boolean values."
        field_value = str(x[self._field])
        matches = self._regex_union_keywords.finditer(field_value)
        return [(m.start(self._group_idx), m.end(self._group_idx)) for m in matches]

    @property
    def input_schema(self) -> Dict[str, Any]:
        return {self._field: Any}

    def estimate_perf(self, df: pd.DataFrame) -> Performance:
        total_data_size = df[self._field].map(len).sum()
        return Performance(
            compute_time_secs=(total_data_size) / 18_000_000,
            peak_memory_mb=(total_data_size) / 3_000_000,
        )
