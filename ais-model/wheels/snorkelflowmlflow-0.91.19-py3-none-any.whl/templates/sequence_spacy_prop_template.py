from typing import Any, Dict, List, Tuple

import pandas as pd
from pydantic import ValidationError

from api_utils.exceptions import UserInputError
from snorkelflow.types.performance import Performance
from snorkelflow.utils.logging import get_logger
from templates.utils import TemplateSchema, is_json

from .template import BASE_URL, SEQUENCE_PATTERN_BASED, SequenceTemplate, TemplateConfig

logger = get_logger("Studio SequenceSpacyPropTemplate")

SPACY_UNUSED_KEYS_SET = {"id", "start", "end", "text", "lemma"}

EXPECTED_FORMAT = "{'tokens': {'start': token_char_start_offset, 'end': token_char_end_offset, 'pos OR other desired properties': ...,}}"
# User can provide any spacy property from https://github.com/explosion/spaCy/blob/master/spacy/glossary.py through free text input
# This curated list is mostly used properties and to provide user some examples
CURATED_SPACY_GLOSSARY = [
    "ADJ",
    "ADV",
    "DET",
    "NOUN",
    "NUM",
    "PROPN",
    "SYM",
    "VERB",
    "csubj",
    "nmod",
    "root",
]


class SequenceSpacyPropTemplateSchema(TemplateSchema):
    """Sequence Spacy Property template

    Parameters
    ----------
    field : str
        Field
    keywords : List[str]
        List of keywords
    """

    keywords: List[str]
    field: str


class SequenceSpacyPropTemplate(SequenceTemplate):
    "LF Template for Sequence Spacy Properties-based interfaces."

    template_type = "sequence_spacy_prop"
    abbreviation = "SSPROP"
    description = "If spacy field [field] contains any of [keywords], then label the matching character offsets."
    menu_type = {
        "name": "Sequence Spacy Prop Builder",
        "value": template_type,
        "category": [SEQUENCE_PATTERN_BASED],
    }
    # TODO: Link to documentation when completed
    docs_link = BASE_URL + "sequence-spacy-prop-builder"
    template_schema = "SequenceSpacyPropTemplateSchema"

    def __init__(self, template_config: TemplateConfig) -> None:
        self._keywords = set(
            [keyword.lower() for keyword in template_config["keywords"]]
        )
        self._field = template_config["field"]
        logger.debug(
            f"Building {self.template_type} template on field {self._field}"
            f"using Spacy properties for keywords {self._keywords}."
        )

    @classmethod
    def name(
        cls,
        template_config: TemplateConfig,
        current_name: str,
        curr_lf_names: List[str],
    ) -> str:
        try:
            template_config = SequenceSpacyPropTemplateSchema(**template_config).dict()
        except ValidationError:
            return current_name
        start_name = "-".join(template_config["keywords"])[:8]

        return cls.get_final_name(start_name, curr_lf_names)

    def check(self, x: pd.Series) -> List[Tuple[int, int]]:
        "Sequence LFs vote with char offsets, not boolean values."

        matches = []
        try:
            tokens = x[self._field]["tokens"]
            spacy_keys = set()
            if tokens:
                spacy_keys = set(tokens[0].keys())
                spacy_keys -= SPACY_UNUSED_KEYS_SET
            for token in tokens:
                for k in spacy_keys:
                    if type(token[k]) is str and token[k].lower() in self._keywords:
                        matches.append((token["start"], token["end"]))
                        break  # Add early stopping once the token already matched

        except Exception as e:
            err_msg = f"Spacy field is not selected correctly or not formatted correctly. Expected {self._field} to be type of Dict with this format: {EXPECTED_FORMAT}"
            raise UserInputError(
                detail=f"{err_msg}. Error: {str(e)}",
                user_friendly_message=err_msg,
                how_to_fix="Please refresh the datasources for this node by navigating to the DAG view of this application and clicking on the refresh button next to this node"
                if is_json(x[self._field])
                else None,
            )
        return matches

    @property
    def input_schema(self) -> Dict[str, Any]:
        return {self._field: Any}

    def estimate_perf(self, df: pd.DataFrame) -> Performance:
        total_data_size = df["text"].map(len).sum()
        num_docs = len(df)
        num_input_keywords = len(self._keywords)
        return Performance(
            compute_time_secs=(total_data_size * num_input_keywords) / 16_000_000,
            peak_memory_mb=num_docs / 80,
        )
