from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field

from snorkelflow.utils.logging import get_logger

from .template import BASE_URL, GENERATORS, Template

logger = get_logger("Studio ModelGeneratorTemplate")


class ModelGeneratorTemplateSchema(BaseModel):
    include_fields: List[str] = Field(default_factory=list)
    model_type: str
    model_name: str
    model_init_args: Optional[Dict[str, Any]] = None
    post_lfs: bool = True
    activate_lfs: bool = True
    min_coverage_threshold: Optional[float] = None
    min_lf_precision_threshold: Optional[float] = None
    min_confidence_threshold: Optional[float] = None
    user_uid: Optional[str] = None
    use_multipolar_template: bool = True
    inference_splits: Optional[List[str]] = None


class ModelGeneratorTemplate(Template):
    template_type = "model_generator"
    abbreviation = "MDLG"
    description = "Generate model based LFs."
    menu_type = {
        "name": "Model Generator",
        "value": template_type,
        "category": [GENERATORS],
    }
    docs_link = BASE_URL + "model-generator-pattern-based-lfs-numerical-lfs"
