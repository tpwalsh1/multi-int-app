from typing import Any, Dict, List

import pandas as pd
from pydantic import ValidationError

from api_utils.exceptions import UnprocessableEntityError
from label_spaces.multi_label import (
    MULTILABEL_PRESENCE_USER_LABEL_DICT,
    MultiLabelSpace,
)
from snorkelflow.types.model import ModelCols
from snorkelflow.utils.logging import get_logger
from templates.keyword_location_template import OPERATORS
from templates.utils import TemplateSchema

from .template import BASE_URL, IMAGE_BASED, LFCacheKeys, Template, TemplateConfig

logger = get_logger("Studio MultipolarImageModelBasedTemplate")


class MultipolarImageModelBasedTemplateSchema(TemplateSchema):
    """Model Based template

    Parameters
    ----------
    model_name : str
        Model name
    model_label : str
        Model label
    label : str
        Label
    dirpath : str
        The path to the stored model in minio.
    label_map : Dict[str, int]
        The label map for the Node that this LF is being applied to
    pos_threshold : float, default 0.5
        Positive threshold for model decision function. Datapoints with decision function greater than or equal are voted positive
    neg_threshold : float, default -0.5
        Negative threshold for model decision function. Datapoints with decision function less than or equal are voted negative
    invert_votes : bool
        Whether to invert the votes.
    """

    model_name: str
    model_label: str
    label: str
    dirpath: str
    label_map: Dict[str, int]
    pos_threshold: float = 0
    neg_threshold: float = 0
    invert_votes: bool = False


class MultipolarImageModelBasedTemplate(Template):
    """Template for multipolar image model based LFs"""

    template_type = "multipolar_image_model_based"
    abbreviation = "MIMB"
    description = "Multipolar image model based LFs."
    menu_type = {
        "name": "Multipolar Image Model Based",
        "value": template_type,
        "category": [IMAGE_BASED],
    }

    docs_link = BASE_URL
    template_schema = "MultipolarImageModelBasedTemplateSchema"
    similarity_field_name = ModelCols.DECISION_FUNCTION

    def __init__(self, template_config: TemplateConfig) -> None:
        self.model_name = template_config["model_name"]
        self.model_label = template_config["model_label"]
        self.label = template_config["label"]
        self.dirpath = template_config["dirpath"]
        self.label_map = template_config["label_map"].copy()
        self.pos_threshold = template_config["pos_threshold"]
        self.neg_threshold = template_config["neg_threshold"]
        self.invert_votes = template_config["invert_votes"]

    @classmethod
    def full_info(cls, template_config: TemplateConfig) -> str:
        try:
            template_config = MultipolarImageModelBasedTemplateSchema(
                **template_config
            ).dict()
        except ValidationError:
            return ""

        return " ".join(map(str, template_config.values()))

    @classmethod
    def name(
        cls,
        template_config: TemplateConfig,
        current_name: str,
        curr_lf_names: List[str],
    ) -> str:
        try:
            template_config = MultipolarImageModelBasedTemplateSchema(
                **template_config
            ).dict()
        except ValidationError:
            return current_name

        start_name = "_".join(
            [str(template_config["model_name"]), str(template_config["model_label"])]
        )

        return cls.get_final_name(start_name, curr_lf_names)

    def preprocess_configs(self) -> List[Dict[str, Any]]:
        """Batch retrieve cached results for efficiency. NOTE this runs for
        every LF."""
        return [
            dict(
                op_type="DecisionFunctionFeaturizer",
                op_config=dict(
                    model_name=self.model_name,
                    dirpath=self.dirpath,
                    label_map=self.label_map,
                    label_space_config=dict(cls_name="MultiLabelSpace"),
                    embedding_field="__image_embedding",
                ),
            )
        ]

    def check(self, x: pd.Series) -> Dict[str, str]:
        val = x[ModelCols.DECISION_FUNCTION]

        if not val:
            raise ValueError(
                f"No decision function values found for model {self.model_name}. "
                "Double check your template inputs are correct."
            )

        try:
            result = {}
            val = val[self.label_map[self.model_label]] if len(val) > 1 else val[0]
            if OPERATORS[">="](val, self.pos_threshold):
                result[self.label] = MULTILABEL_PRESENCE_USER_LABEL_DICT[
                    0 if self.invert_votes else 1
                ]
            elif OPERATORS[">="](self.neg_threshold, val):
                result[self.label] = MULTILABEL_PRESENCE_USER_LABEL_DICT[
                    1 if self.invert_votes else 0
                ]
            else:
                result[self.label] = MULTILABEL_PRESENCE_USER_LABEL_DICT[-1]
        except Exception as e:
            raise UnprocessableEntityError(
                detail=f"Decision function values may not be formatted correctly. Expected values to be of type List[float]",
                how_to_fix="Please validate that the output of DecisionFunctionFeaturizer matches the expected format of List[float]",
            ) from e

        return result

    def compute_lf_votes_single_column(self, df: pd.Series, label: Any) -> pd.Series:
        def cmp(x: Any) -> Dict[str, int]:
            x = x[self.label_map[self.model_label]] if len(x) > 1 else x[0]

            result = MultiLabelSpace.get_raw_unknown_label()
            if OPERATORS[">="](x, self.pos_threshold):
                result[label] = 0 if self.invert_votes else 1
            elif OPERATORS[">="](self.neg_threshold, x):
                result[label] = 1 if self.invert_votes else 0
            return result

        lf_votes = df.apply(cmp)
        return lf_votes

    @property
    def cache_keys(self) -> Dict[str, str]:
        return {
            LFCacheKeys.PREPROCESSED_DF: f"{self.template_type}_{self.model_name}_{self.model_label}",
            LFCacheKeys.LF_VOTES: f"{self.template_type}_{self.model_name}_{self.model_label}_{self.label}_{self.dirpath}_{self.pos_threshold}_{self.neg_threshold}_{self.invert_votes}",
        }
