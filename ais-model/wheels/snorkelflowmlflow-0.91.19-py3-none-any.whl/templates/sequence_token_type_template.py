from typing import List, Optional, Tuple

import pandas as pd
from pydantic import ValidationError

from regex_utils.selector import select_compiled_regex
from snorkelflow.types.performance import Performance
from snorkelflow.utils.logging import get_logger
from templates.utils import TemplateSchema, tokenize_pattern

from .template import BASE_URL, SEQUENCE_PATTERN_BASED, SequenceTemplate, TemplateConfig

logger = get_logger("Studio SequenceTokenTypeTemplate")

TOKEN_TYPE_TO_REGEX = {
    "lowercase": "[a-z]+",
    "capitalized": "[A-Z][a-z]+",
    "uppercase": "[A-Z]+",
}

merged_token_regex = lambda x: rf"\b{x}\b(?:\s+\b{x}\b)*"

WORD_BOUNDARY_TOKENIZER_DEFAULT = True


class SequenceTokenTypeTemplateSchema(TemplateSchema):
    """Sequence Token Type template

    Parameters
    ----------
    field : str
        Field
    token_type : {"lowercase", "capitalized", "uppercase"}
        Token type
    word_boundary_tokenizer : bool, default True
        Tokenize or not
    merge_token : bool, default False to maintain backward compatability
        Merge nearby tokens or not
    """

    field: str
    token_type: str
    word_boundary_tokenizer: Optional[bool] = True
    merge_token: Optional[bool] = False


class SequenceTokenTypeTemplate(SequenceTemplate):
    "LF Template for Sequence text-based regexes interfaces."

    template_type = "sequence_token_type"
    abbreviation = "STK"
    description = "If [field] contains the regular expression [regex] then label the matching character offsets."
    menu_type = {
        "name": "Sequence Letter Case Builder",
        "value": template_type,
        "category": [SEQUENCE_PATTERN_BASED],
    }
    # TODO: Link to documentation when completed
    docs_link = BASE_URL + "sequence-token-type-builder"
    template_schema = "SequenceTokenTypeTemplateSchema"

    def __init__(self, template_config: TemplateConfig) -> None:
        self._regex_pattern = TOKEN_TYPE_TO_REGEX.get(template_config["token_type"], "")
        self._word_boundary_tokenizer = template_config.get(
            "word_boundary_tokenizer", WORD_BOUNDARY_TOKENIZER_DEFAULT
        )
        self._merge_token = template_config.get("merge_token", False)

        if self._word_boundary_tokenizer:
            if self._merge_token:
                self._regex_pattern = merged_token_regex(self._regex_pattern)
            else:
                self._regex_pattern = (
                    tokenize_pattern(self._regex_pattern) if self._regex_pattern else ""
                )
        else:
            self._regex_pattern = rf"^{self._regex_pattern}$"

        self._field = template_config["field"]
        self._tokenized_field = "tokenized_" + self._field
        self._regex_compiled = select_compiled_regex(self._regex_pattern)

        logger.debug(
            f"Building {self.template_type} template with pattern '{self._regex_pattern}'"
        )

    @classmethod
    def name(
        cls,
        template_config: TemplateConfig,
        current_name: str,
        curr_lf_names: List[str],
    ) -> str:
        try:
            template_config = SequenceTokenTypeTemplateSchema(**template_config).dict()
        except ValidationError:
            return current_name
        start_name = template_config["token_type"][:8]

        return cls.get_final_name(start_name, curr_lf_names)

    def check(self, x: pd.Series) -> List[Tuple[int, int]]:
        "Sequence LFs vote with char offsets, not boolean values."

        if self._word_boundary_tokenizer:
            field_value = str(x[self._field])
            matches = self._regex_compiled.finditer(field_value)
            return [(m.start(0), m.end(0)) for m in matches]
        else:
            field_value = str(x[self._field])
            tokens = x[self._tokenized_field]
            if self._merge_token:
                matched_token_ids = [
                    token_id
                    for token_id, token in enumerate(tokens)
                    if self._regex_compiled.match(field_value[token[0] : token[1]])
                ]
                spans = []
                if matched_token_ids:
                    prev_token_id = matched_token_ids[0]
                    spans = [[tokens[prev_token_id][0], tokens[prev_token_id][1]]]
                    for token_id in matched_token_ids[1:]:
                        token = tokens[token_id]
                        if token_id == prev_token_id + 1:
                            # if current id is right after prev_token_id, merge current token to last span
                            spans[-1][1] = token[1]
                        else:
                            # if token ids are not continuous, start a new span
                            spans.append([token[0], token[1]])
                        prev_token_id = token_id
                return [(span[0], span[1]) for span in spans]
            else:
                return [
                    (token[0], token[1])
                    for token in tokens
                    if self._regex_compiled.match(field_value[token[0] : token[1]])
                ]

    def estimate_perf(self, df: pd.DataFrame) -> Performance:
        total_data_size = df[self._field].map(len).sum()
        num_docs = len(df)
        return Performance(
            compute_time_secs=total_data_size / 4_000_000, peak_memory_mb=num_docs / 400
        )
