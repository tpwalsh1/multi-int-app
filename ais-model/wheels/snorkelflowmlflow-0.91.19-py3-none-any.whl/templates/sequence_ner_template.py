from typing import List, Tuple

import pandas as pd
from pydantic import ValidationError

from api_utils.exceptions import UserInputError
from snorkelflow.types.performance import Performance
from snorkelflow.utils.logging import get_logger
from templates.utils import TemplateSchema, is_json

from .template import BASE_URL, SEQUENCE_PATTERN_BASED, SequenceTemplate, TemplateConfig

logger = get_logger("Studio SequenceNERTemplate")

NER_UNUSED_KEYS_SET = {"start", "end"}
EXPECTED_FORMAT = "{'ents': {'start': token_char_start_offset, 'end': token_char_end_offset, 'NER OR other desired entities': ...,}}"


class SequenceNERTemplateSchema(TemplateSchema):
    """Sequence NER template

    Parameters
    ----------
    field : str
        Field
    keywords : List[str]
        List of keywords
    """

    keywords: List[str]
    field: str


class SequenceNERTemplate(SequenceTemplate):
    "LF Template for Sequence NER-based interfaces."

    template_type = "sequence_ner"
    abbreviation = "SNER"
    description = "If NER field [field] contains any of [NER properties], then label the matching character offsets."
    menu_type = {
        "name": "Sequence NER Builder",
        "value": template_type,
        "category": [SEQUENCE_PATTERN_BASED],
    }
    # TODO: Link to documentation when completed
    docs_link = BASE_URL + "sequence-ner-builder"
    template_schema = "SequenceNERTemplateSchema"

    def __init__(self, template_config: TemplateConfig) -> None:
        self._keywords = set(
            [keyword.lower() for keyword in template_config["keywords"]]
        )
        self._field = template_config["field"]
        logger.debug(
            f"Building {self.template_type} template on field {self._field}"
            f"using NER properties for keywords {self._keywords}."
        )

    @classmethod
    def name(
        cls,
        template_config: TemplateConfig,
        current_name: str,
        curr_lf_names: List[str],
    ) -> str:
        try:
            template_config = SequenceNERTemplateSchema(**template_config).dict()
        except ValidationError:
            return current_name
        start_name = "-".join(template_config["keywords"])[:8]

        return cls.get_final_name(start_name, curr_lf_names)

    def check(self, x: pd.Series) -> List[Tuple[int, int]]:
        "Sequence LFs vote with char offsets, not boolean values."

        matches = []
        try:
            tokens = x[self._field]["ents"]
            for token in tokens:
                for key, val in token.items():
                    if key in NER_UNUSED_KEYS_SET:
                        continue
                    if str(val).lower() in self._keywords:
                        matches.append((token["start"], token["end"]))
                        break  # Add early stopping once the token already matched
        except Exception as e:
            err_msg = f"NER field is not selected correctly or not formatted correctly. Expected {self._field} to be type of Dict with this format: {EXPECTED_FORMAT}"
            raise UserInputError(
                detail=f"{err_msg}. Error: {str(e)}",
                user_friendly_message=err_msg,
                how_to_fix="Please refresh the datasources for this node by navigating to the DAG view of this application and clicking on the refresh button next to this node"
                if is_json(x[self._field])
                else None,
            )
        return matches

    def estimate_perf(self, df: pd.DataFrame) -> Performance:
        total_data_size = df["text"].map(len).sum()
        num_docs = len(df)
        num_input_keywords = len(self._keywords)
        return Performance(
            compute_time_secs=(total_data_size * num_input_keywords) / 40_000_000,
            peak_memory_mb=num_docs / 300,
        )
