from typing import List, Optional

import pandas as pd
from pydantic import validator

from snorkelflow.utils.logging import get_logger
from templates.constants import (
    TEMPLATE_CASE_SENSITIVE_FIELD_NAME,
    TEMPLATE_ELEM_FIELD_NAME,
    TEMPLATE_FIELD_FIELD_NAME,
    TEMPLATE_OPERATER_FIELD_NAME,
    TEMPLATE_VALUES_FIELD_NAME,
)
from templates.utils import TemplateSchema

from .template import BASE_URL, TABLE_BASED, Template, TemplateConfig

logger = get_logger("Studio TableOneAttribute")

OPERATORS = {
    "ANY": lambda x, y: len(set(y).intersection(x)) > 0,
    "ALL": lambda x, y: len(set(y).intersection(x)) == len(x),
}

CASE_SENSITIVE_DEFAULT = False


class TableOneAttributeSchema(TemplateSchema):
    """Table One Attribute template

    Parameters
    ----------
    field : str
        Field
    elem_field : str
        Element field
    operator : {"ANY", "ALL"}
        Operator
    values : List[str]
        List of values
    case_sensitive : bool, default False
        Case sensitive or not
    """

    field: str
    elem_field: str
    operator: str
    values: List[str]
    case_sensitive: Optional[bool] = CASE_SENSITIVE_DEFAULT

    @validator("operator")
    def check_operator(cls, operator_name: str) -> str:
        if operator_name not in OPERATORS:
            raise ValueError(f"Invalid operator: {operator_name}")
        return operator_name


class TableOneAttribute(Template):
    """LF Template based on occurances of elements.

    Heuristic:
    "If x[field] has elements with elem field CONTAINING [ANY/ALL] of the values , return True"
    """

    template_type = "table_one_attribute"
    abbreviation = "T1A"
    description = "If [field] has elem with [elem_field] that contains [any, all] of [values], then label."
    menu_type = {
        "name": "Table One Attribute Builder",
        "value": template_type,
        "category": [TABLE_BASED],
    }
    docs_link = BASE_URL + "one-attribute-table-based-lfs"
    template_schema = "TableOneAttributeSchema"

    def __init__(self, template_config: TemplateConfig) -> None:
        self._field = template_config[TEMPLATE_FIELD_FIELD_NAME]
        self._elem_field = template_config[TEMPLATE_ELEM_FIELD_NAME]
        _op_str = template_config[TEMPLATE_OPERATER_FIELD_NAME]
        self._op = OPERATORS[_op_str]
        self._comp_values = template_config[TEMPLATE_VALUES_FIELD_NAME]
        self._case_sensitive = template_config[TEMPLATE_CASE_SENSITIVE_FIELD_NAME]

        logger.debug(
            f"Building {self.template_type} template on field {self._field} with "
            f"operator {_op_str}"
        )

    def check(self, x: pd.Series) -> bool:
        try:
            field_values = x[self._field]
            act_elem_values = [elem[self._elem_field] for elem in field_values]
            comp_values = self._comp_values
            if not self._case_sensitive:
                act_elem_values = [str(x).lower() for x in act_elem_values]
                comp_values = [str(x).lower() for x in comp_values]
            return self._op(comp_values, act_elem_values)
        except KeyError:
            return False
