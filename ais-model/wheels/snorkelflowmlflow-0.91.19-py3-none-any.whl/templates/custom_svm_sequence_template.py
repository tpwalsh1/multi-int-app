import pickle
from typing import List, Tuple

import pandas as pd
from pydantic import ValidationError, validator
from sklearn.svm import LinearSVC

from api_utils.exceptions import UserInputError
from file_utils.core import open_file, path_exists
from snorkelflow.types.performance import Performance
from snorkelflow.utils import resolve_data_path
from snorkelflow.utils.logging import get_logger
from templates.utils import TemplateSchema

from .template import (
    BASE_URL,
    CUSTOM_SVM_SEQUENCE_BASED,
    SequenceTemplate,
    TemplateConfig,
)

logger = get_logger("Studio Custom SVM Sequence")


class CustomSVMSequenceTemplateSchema(TemplateSchema):
    """Custom SMV Sequence Template

    Parameters
    ----------
    model_path : str
        Path to trained binary SVM model
    feature_field : str
        Field containing embeddings
    feature_span_field : str
        Field containing spans that map to embeddings
    min_distance : float
        Minimum distance
    model_name : str
        SVM model name
    """

    model_path: str
    feature_field: str
    feature_span_field: str
    min_distance = 0.0
    model_name: str = ""

    @staticmethod
    def artifact_config_keys() -> List[str]:
        return ["model_path"]

    @validator("model_path")
    def check_exists(cls, model_path: str) -> str:
        if not path_exists(model_path):
            raise ValueError(f"Path {model_path} does not exist")
        return model_path


class CustomSVMSequenceTemplate(SequenceTemplate):
    "LF Template for Custom SVM Sequence LF."

    template_type = "custom_svm_sequence"
    docs_link = BASE_URL + "custom-svm-sequence"

    abbreviation = "CSVMS"
    description = "Classifies spans using output from a custom SVM Model. Must be generated using external mechanism"
    menu_type = {
        "name": "Custom SVM Sequence Builder",
        "value": template_type,
        "category": [CUSTOM_SVM_SEQUENCE_BASED],
    }
    template_schema = "CustomSVMSequenceTemplateSchema"

    def __init__(self, template_config: TemplateConfig) -> None:
        model_path = template_config["model_path"]
        if model_path.startswith("minio"):
            model_path = resolve_data_path(model_path)

        with open_file(model_path, "rb") as f:
            self.model: LinearSVC = pickle.load(f)
        self.min_distance = template_config["min_distance"]
        self.feature_field = template_config["feature_field"]
        self.feature_span_field = template_config["feature_span_field"]
        self.model_name = template_config["model_name"]

    def check(self, x: pd.Series) -> List[Tuple[int, int]]:
        if len(x[self.feature_field]) == 0:
            return []
        try:
            return self._unroll_and_roll_row(x)
        except Exception:
            err_msg = "Feature or embedding field(s) are incorrectly formatted or model did not train."
            raise UserInputError(
                detail=err_msg,
                user_friendly_message=err_msg,
                how_to_fix="Ensure the following: candidate field is of the format List[Dict] per document with 'start' and 'end' keys; "
                "Embeddings are formatted as a List[List] per document with fixed-dimension numeric values.",
            )

    @classmethod
    def name(
        cls,
        template_config: TemplateConfig,
        current_name: str,
        curr_lf_names: List[str],
    ) -> str:
        try:
            template_config = CustomSVMSequenceTemplateSchema(**template_config).dict()
        except ValidationError:
            return current_name

        if template_config["model_name"]:
            start_name = template_config["model_name"]
        else:
            # Use start of the file name if no name available
            start_name = str(template_config["model_path"][:10])
        return cls.get_final_name(start_name, curr_lf_names)

    def _unroll_and_roll_row(self, row: pd.Series) -> List[Tuple[int, int]]:
        embeddings = row[self.feature_field]
        spans = row[self.feature_span_field]
        distances = self.model.decision_function(embeddings)
        pred_spans = []
        for distance, span in zip(distances, spans):
            if distance > self.min_distance:
                pred_spans.append((span["start"], span["end"] + 1))
        return pred_spans

    def estimate_perf(self, df: pd.DataFrame) -> Performance:
        embedding_data_size = df[self.feature_field].map(len).sum()
        num_docs = len(df)

        return Performance(
            compute_time_secs=(num_docs * embedding_data_size) / 10000,
            peak_memory_mb=(num_docs * embedding_data_size) / 1000,
        )
