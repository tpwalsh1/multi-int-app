from typing import List

from pydantic import ValidationError

from snorkelflow.utils.logging import get_logger

from .keyword_location_template import KeywordLocationSchema, KeywordLocationTemplate
from .template import BASE_URL, PATTERN_BASED, TemplateConfig

logger = get_logger("Studio")


class KeywordCountTemplate(KeywordLocationTemplate):
    """LF Template based on regex checks in a sub-range of the document.

    Heuristic:
    "If (string or regular expression) [pattern] occurs [op] [frequency] times
    between [units] [start] to [end] of [field], return True"

    Note that [start] and [end] can be negative, in which case they are
    counted from the end of the field, similar to slices in python.
    """

    template_type = "keyword_count"
    abbreviation = "KWC"
    description = (
        "If [field] contains [keyword/phrase] [>, =, etc.] [count] times, then label."
    )
    menu_type = {
        "name": "Keyword Count Builder",
        "value": template_type,
        "category": [PATTERN_BASED],
    }
    docs_link = BASE_URL + "keyword-count-builder-pattern-based-lfs"

    @classmethod
    def name(
        cls,
        template_config: TemplateConfig,
        current_name: str,
        curr_lf_names: List[str],
    ) -> str:
        try:
            template_config = KeywordLocationSchema(**template_config).dict()
        except ValidationError:
            return current_name
        start_name = "_".join(
            [template_config["pattern"], str(template_config["frequency"])]
        )

        return cls.get_final_name(start_name, curr_lf_names)

    @classmethod
    def full_info(cls, template_config: TemplateConfig) -> str:
        try:
            template_config = KeywordLocationSchema(**template_config).dict()
        except ValidationError:
            return ""

        return " ".join(
            [
                template_config["pattern"],
                template_config["operator"],
                str(template_config["frequency"]),
                "times",
            ]
        )
