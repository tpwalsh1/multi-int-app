import ast
import hashlib
import os
from itertools import product
from typing import Any, Dict, List

import pandas as pd
import re2
from pydantic import Field, ValidationError, root_validator, validator

from api_utils.exceptions import UserInputError
from rich_doc_wrapper import Ngram, RichDocWrapper
from snorkelflow.extraction.span import SpanCols
from snorkelflow.rich_docs import (
    MissingRichDocException,
    RichDoc,
    RichDocCols,
    TextClusters,
)
from snorkelflow.rich_docs.rich_doc import RichDocList
from snorkelflow.serialization.pandas import deserialize_series
from snorkelflow.serialization.serializable import B64PICKLE
from snorkelflow.types.performance import Performance
from snorkelflow.utils.logging import get_logger
from templates.utils import TemplateSchema

from .template import CLASSIC_STUDIO_URL, RICH_DOC_BASED, Template, TemplateConfig

logger = get_logger("Studio")


class RichDocExpressionTemplateSchema(TemplateSchema):
    regex_patterns: List[str] = Field(default_factory=list)
    expression: str
    search_all_combinations: bool = False
    validate_expression: bool = True
    case_sensitive: bool = False

    @validator("regex_patterns")
    def check_regex_pattern(cls, patterns: List[str]) -> List[str]:
        for pattern in patterns:
            try:
                re2.compile(pattern)
            except Exception:
                raise ValueError(f"Invalid regex_pattern {pattern}")
        return patterns

    @validator("expression")
    def check_expression(cls, expression: str) -> str:
        expression = expression.replace("\n", " ")
        try:
            ast.parse(expression)
        except Exception:
            raise ValueError(f"Invalid expression {expression}")
        return expression

    @root_validator(pre=False, skip_on_failure=True)
    def check_valid_expression(cls, values: Dict[str, Any]) -> Dict[str, Any]:
        if not values["validate_expression"]:
            return values
        # Supports the following fields
        #    ['bottom', 'char_end', 'char_start', 'context_uid',
        #    'left', 'page_char_starts', 'page_docs', 'region_bottom', 'region_left',
        #    'region_right', 'region_text', 'region_top', 'rich_doc',
        #    'rich_doc_font_size', 'rich_doc_json', 'rich_doc_pdf_url',
        #    'rich_doc_span_end_char_offset', 'rich_doc_span_end_word_id',
        #    'rich_doc_span_ngram', 'rich_doc_span_page_id',
        #    'rich_doc_span_start_char_offset', 'rich_doc_span_start_word_id',
        #    'rich_doc_text', 'right', 'span_entity', 'span_field',
        #    'span_field_value_hash', 'span_text', 'text_cluster_id',
        #    'text_clusters', 'top', 'rich_doc_row_id', 'rich_doc_row_text_before',
        #    'rich_doc_row_text_inline', 'rich_doc_row_text_after',
        #    'rich_doc_row_header', 'rich_doc_inferred_row_headers']
        cur_path = os.path.dirname(__file__)
        richdocs_df = pd.read_csv(
            os.path.join(cur_path, "resources/sample_richdocs_df.csv")
        )
        # Deserializing cols
        richdocs_df.page_char_starts = deserialize_series(
            richdocs_df.page_char_starts, B64PICKLE
        )
        richdocs_df.page_docs = deserialize_series(richdocs_df.page_docs, RichDocList)
        richdocs_df.rich_doc = deserialize_series(richdocs_df.rich_doc, RichDoc)
        richdocs_df.rich_doc_span_ngram = deserialize_series(
            richdocs_df.rich_doc_span_ngram, Ngram
        )
        richdocs_df.text_clusters = deserialize_series(
            richdocs_df.text_clusters, TextClusters
        )

        # Making sure expression evals properly with a sample Ngram
        ngram_dict = dict(richdocs_df.iloc[0])
        ngram_dict["SPAN"] = richdocs_df.rich_doc_span_ngram.iloc[0]
        for i in range(len(values.get("regex_patterns", []))):
            ngram_dict[f"PATTERN{i+1}"] = richdocs_df.rich_doc_span_ngram.iloc[0]
        try:
            eval(values.get("expression", None), {}, ngram_dict)
        except Exception as e:
            raise UserInputError(
                detail=str(e), user_friendly_message="Error with expression evaluation"
            )
        return values


class RichDocExpressionTemplate(Template):
    """LF Template based on arbirary expression on ngrams corresponding to regexes.

    Heuristic:
    "If [expression] evaluates to true using dataframe column names and special SPAN and PATTERNx variables, return True"

    NOTE: Requires RichDoc or PageDocs column to function
    """

    template_type = "rich_doc_expression"
    abbreviation = "REXP"
    description = "If the expression evaluates to true, using SPAN to represent the span and PATTERN1, PATTERN2, etc to represent the first match for each regex, then label."
    menu_type = {
        "name": "Rich Doc Expression Builder",
        "value": template_type,
        "category": [RICH_DOC_BASED],
    }
    docs_link = CLASSIC_STUDIO_URL + "rich-doc-expression-rich-doc-based-lfs"
    template_schema = "RichDocExpressionTemplateSchema"

    def __init__(self, template_config: TemplateConfig) -> None:
        self._regex_patterns = template_config["regex_patterns"]
        self._expression = template_config["expression"]
        self._search_all_combinations = template_config["search_all_combinations"]
        self._case_sensitive = template_config["case_sensitive"]

        self._ngrams_fields = [
            f"ngrams_{hashlib.md5(rgx.encode()).hexdigest()[:10]}"
            for rgx in self._regex_patterns
        ]

        logger.debug(
            f"Building {self.template_type} template with config {template_config}"
        )

    def estimate_perf(self, df: pd.DataFrame) -> Performance:
        total_spans = len(df)
        text = df[RichDocCols.TEXT_COL].iloc[0]
        flags = 0 if self._case_sensitive else re2.IGNORECASE
        # Total x-product between all regex matches
        x_product_matches = 1
        if self._search_all_combinations:
            total_matches = 0
            for pattern in self._regex_patterns:
                matches = len(re2.findall(pattern, text, flags=flags))
                total_matches += matches
                x_product_matches *= matches
        else:
            total_matches = len(self._regex_patterns)
        return Performance(
            compute_time_secs=total_spans * x_product_matches * 1e-3,
            peak_memory_mb=total_spans * total_matches / 625,
        )

    def preprocess_configs(self) -> List[Dict[str, Any]]:
        """List of operator configs to run before applying LF."""
        return [
            dict(
                op_type="RichDocRegexNGramDetector",
                op_config=dict(
                    regex=rgx, target_field=field, case_sensitive=self._case_sensitive
                ),
            )
            for rgx, field in zip(self._regex_patterns, self._ngrams_fields)
        ]

    def check(self, x: pd.Series) -> bool:
        rd = x.get(RichDocCols.DOC_COL)
        if rd is None:
            if RichDocCols.PAGE_DOCS not in x:
                raise MissingRichDocException(
                    "Could not find either rich_doc or page_docs column in DataFrame"
                    "Make sure that these columns have been added via task processors."
                )
            # PAGE_DOCS is singleton list with PageSplitter so no need for PAGE_IDX
            rd = RichDoc.from_page_docs(x.get(RichDocCols.PAGE_DOCS))
        rdw = RichDocWrapper(rd)
        locals_dict = dict(x)
        if SpanCols.CHAR_START in x and SpanCols.CHAR_END in x:
            locals_dict["SPAN"] = rdw.get_span_ngram(
                x[SpanCols.CHAR_START], x[SpanCols.CHAR_END]
            )
        pattern_ngrams_lists = [x[field] for field in self._ngrams_fields]
        if not self._search_all_combinations:
            pattern_ngrams_lists = [l[:1] for l in pattern_ngrams_lists]
        for ngrams_list in product(*pattern_ngrams_lists):
            for i, ngram in enumerate(ngrams_list):
                locals_dict[f"PATTERN{i+1}"] = ngram
            if eval(self._expression, {}, locals_dict):
                return True
        return False

    @classmethod
    def name(
        cls,
        template_config: TemplateConfig,
        current_name: str,
        curr_lf_names: List[str],
    ) -> str:
        try:
            template_config = RichDocExpressionTemplateSchema(**template_config).dict()
        except ValidationError:
            return current_name
        start_name = (
            str(template_config["expression"])[:3]
            + "_"
            + ",".join(template_config["regex_patterns"])[:5]
        )

        return cls.get_final_name(start_name, curr_lf_names)
