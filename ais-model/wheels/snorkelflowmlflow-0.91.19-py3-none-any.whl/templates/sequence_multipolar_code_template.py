from typing import Any

from templates.multipolar_code_template import MultipolarCodeTemplate
from templates.sequence_code_template import SequenceCodeTemplate


class SequenceMultipolarCodeTemplate(SequenceCodeTemplate, MultipolarCodeTemplate):
    """LF Builder for arbitrary serialized sequence code LFs

    Deserializes a serialized_lf back into a valid LabelingFunction.
    """

    template_type = "sequence_multipolar_code"
    abbreviation = "SMCOD"
    description = (
        "Label according to the output labels of the code this LF is based on."
    )
    menu_type = {
        "name": "Sequence Multipolar Code Template",
        "value": template_type,
        "category": [],
    }

    def _validate_output_label_type(self, label: Any) -> None:
        # No typing checking required for this template
        # since it outputs user labels that are transformed in the
        # LFBuilder class
        return
