from typing import Any, List

import pandas as pd
from pydantic import ValidationError, validator

from snorkelflow.utils.logging import get_logger
from templates.utils import TemplateSchema

from .template import BASE_URL, EXTERNAL_RESOURCES, Template, TemplateConfig

logger = get_logger("Studio ExternalModelTemplate")


def textblob_polarity(x: Any) -> float:
    from textblob import TextBlob

    return (TextBlob(str(x)).polarity + 1.0) / 2.0


def textblob_subjectivity(x: Any) -> float:
    from textblob import TextBlob

    return TextBlob(str(x)).subjectivity


def nltk_polarity(x: Any) -> float:
    from nltk.sentiment.vader import SentimentIntensityAnalyzer

    return (
        SentimentIntensityAnalyzer().polarity_scores(str(x))["compound"] + 1.0
    ) / 2.0


# MODELS must output values in range [0.0, 1.0]
MODELS = {
    "polarity_sentiment": textblob_polarity,
    "subjectivity_sentiment": textblob_subjectivity,
    "nltk_polarity": nltk_polarity,
}

OPERATORS = {
    ">": lambda x, y: x > y,
    "<": lambda x, y: x < y,
    "=": lambda x, y: x == y,
    "!=": lambda x, y: x != y,
    ">=": lambda x, y: x >= y,
    "<=": lambda x, y: x <= y,
}


class ExternalModelTemplateSchema(TemplateSchema):
    """External Model template

    Parameters
    ----------
    model_type : {"polarity_sentiment", "subjectivity_sentiment", "nltk_polarity"}
        Model type
    field : str
        Field
    operator : {">", "<", "=", "!=", ">=", "<="}
        Operator
    threshold : float
        Threshold
    """

    model_type: str
    field: str
    operator: str
    threshold: float

    @validator("model_type")
    def check_model_type(cls, v: str) -> str:
        if v not in MODELS.keys():
            raise ValueError("Invalid model")
        return v

    @validator("operator")
    def check_operator(cls, v: str) -> str:
        if v not in OPERATORS.keys():
            raise ValueError("Invalid operator")
        return v

    @validator("threshold")
    def check_threshold(cls, v: float) -> float:
        if not ((v >= 0) and (v <= 1.0)):
            raise ValueError("Invalid value for threshold")
        return v


class ExternalModelTemplate(Template):
    """LF Template based on model predictions."""

    template_type = "external_model"
    abbreviation = "MOD"
    description = "If [model] applied to [field] outputs a value (scaled to 0-1) that is [>, =, etc.] [threshold], then label."
    menu_type = {
        "name": "External Model Builder",
        "value": template_type,
        "category": [EXTERNAL_RESOURCES],
    }
    docs_link = BASE_URL + "external-model-builder-external-resources-lfs"
    template_schema = "ExternalModelTemplateSchema"

    def __init__(self, template_config: TemplateConfig) -> None:
        """Check model score on field."""

        model_type = template_config["model_type"]
        self._model = MODELS[model_type]
        self._model_field = template_config["field"]
        operator_name = template_config["operator"]
        self._operator = OPERATORS[operator_name]
        self._threshold = float(template_config["threshold"])

        logger.debug(
            f"Building {self.template_type} template on field {self._model_field} where model {model_type} {operator_name} {self._threshold}."
        )

    def check(self, x: pd.Series) -> bool:
        model_input = x[self._model_field]
        model_score = self._model(model_input)
        assert (
            model_score >= 0.0 and model_score <= 1.0
        ), "Model score must be between 0.0 and 1.0"
        return self._operator(model_score, self._threshold)

    @classmethod
    def name(
        cls,
        template_config: TemplateConfig,
        current_name: str,
        curr_lf_names: List[str],
    ) -> str:
        try:
            template_config = ExternalModelTemplateSchema(**template_config).dict()
        except ValidationError:
            return current_name
        start_name = "_".join(
            [template_config["model_type"], str(template_config["threshold"])]
        )

        return cls.get_final_name(start_name, curr_lf_names)

    @classmethod
    def full_info(cls, template_config: TemplateConfig) -> str:
        try:
            template_config = ExternalModelTemplateSchema(**template_config).dict()
        except ValidationError:
            return ""

        return f'{template_config["model_type"]} applied to {template_config["field"]} is {template_config["operator"]} {str(template_config["threshold"])}'
