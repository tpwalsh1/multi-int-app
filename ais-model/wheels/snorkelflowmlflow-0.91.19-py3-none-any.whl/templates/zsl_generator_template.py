from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field

from snorkelflow.utils.logging import get_logger

from .template import BASE_URL, GENERATORS, Template

logger = get_logger("Studio ZSLGeneratorTemplate")


class ZSLGeneratorTemplateSchema(BaseModel):
    include_fields: List[str] = Field(default_factory=list)
    model_name: str
    model_type: str
    hf_model_name: str
    prompt: str
    modified_label_targets: Optional[Dict[str, Any]] = None
    threshold: float = 0
    use_few_shots: Optional[bool] = False
    activate_lfs: bool = True
    use_multipolar_template: bool = True


class ZSLGeneratorTemplate(Template):
    template_type = "zsl_generator"
    abbreviation = "ZSLG"
    description = "Generate Zero/Few Shot LFs."
    menu_type = {
        "name": "ZSL Generator",
        "value": template_type,
        "category": [GENERATORS],
    }
    # Link needs to be modified with updated documentation
    docs_link = BASE_URL + "numeric-generator-numerical-lfs"
