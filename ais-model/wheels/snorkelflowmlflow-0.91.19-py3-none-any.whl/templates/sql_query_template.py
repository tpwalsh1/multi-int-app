import datetime
import re
from sqlite3.dbapi2 import Timestamp
from typing import Any

import numpy as np
import pandas as pd
from pydantic import validator

from snorkelflow.utils.logging import get_logger
from templates.utils import TemplateSchema

from .template import BASE_URL, SQL_BASED, Template, TemplateConfig

logger = get_logger("Studio SQLQueryTemplate")

# Listing known accepted (parent) types for SQL.
# If a value is not an instance of something from this list, we
# convert it into a string before being accessed by a query
KNOWN_ACCEPTED_SQL_TYPES = [
    str,
    int,
    float,
    np.int,
    np.float,
    datetime.date,
    datetime.time,
    datetime.datetime,
    Timestamp,
    type(None),
]


def sanitize_sql_type(value: Any) -> Any:
    """Helper function to return a sanitized version of value compatible with SQL"""
    for base_type in KNOWN_ACCEPTED_SQL_TYPES:
        # Accepted type, can return as is
        if isinstance(value, base_type):
            return value

    # If type never found, convert to string
    return str(value)


def df_query(sql_query: str, df: pd.DataFrame, df_name: str = "df") -> pd.DataFrame:
    """Returns a new DataFrame of results from a query in SQL format from [df]

    Args:
        sql_query (str): A SQL format query to apply to [df]
        df (pd.DataFrame): The DataFrame we are applying the query to
                           (as if it is a single table)
        df_name (str): The name that [df] is referred to as in the query

    Raises:
        PandaSQLException: If a column specified in the query does not exist,
                           or the query is malformed

    Returns:
        pd.DataFrame: A new DataFrame of the results from the query
    """
    # Expensive (ish, ~0.37 seconds) import, and this is the only place it's used
    from pandasql import PandaSQL
    from sqlalchemy.exc import InterfaceError

    def type_fix_fn(row: pd.Series) -> pd.Series:
        new_row = {}
        fields = list(row.keys())

        for field in fields:
            new_row[field] = sanitize_sql_type(row[field])

        return pd.Series(data=[new_row[f] for f in fields], index=fields)

    try:
        return PandaSQL()(sql_query, env={df_name: df})
    except InterfaceError:
        new_df = df.apply(type_fix_fn, axis=1)
        return PandaSQL()(sql_query, env={df_name: new_df})


class SQLQueryTemplateSchema(TemplateSchema):
    """SQL Query template

    Parameters
    ----------
    query : str
        SQL query
    """

    # TODO: Add uid_field as an argument when this gets converted to batch evaluation
    query: str

    @validator("query")
    def check_for_aggregations(cls, v: str) -> str:
        # Make sure no GROUP BY in query
        for expr in ["GROUP\s+BY"]:
            if re.search(expr, v):
                raise ValueError("GROUP BY expression currently not supported")

        return v


class SQLQueryTemplate(Template):
    """LF Template for allowing users to write a SQL query to select relevant datapoints.

    Heuristic:
    "If [query] result contains row, return True"

    Note: [query] is tehcnically just the WHERE clause of a query, so it acts
    as more of a boolean expression.
    """

    template_type = "sql_query"
    abbreviation = "SQL"
    description = "If [query] result contains the given row, then label."
    menu_type = {
        "name": "SQL Query Builder",
        "value": template_type,
        "category": [SQL_BASED],
    }
    docs_link = BASE_URL + "sql-query-builder-table-based-lfs"
    template_schema = "SQLQueryTemplateSchema"

    def __init__(self, template_config: TemplateConfig) -> None:
        """Check if current row satisfies query"""

        self.query = template_config["query"]

        logger.debug(
            f"Building {self.template_type} template with config {template_config}"
        )

    def check(self, x: pd.Series) -> bool:
        # Converting the current row into a DF for use with PandaSQL
        df = pd.DataFrame([x.to_dict()])
        query = f"SELECT * FROM df WHERE {self.query}"
        result_df = df_query(query, df)

        # If any results returned for our single row query, then label
        return len(result_df) > 0
