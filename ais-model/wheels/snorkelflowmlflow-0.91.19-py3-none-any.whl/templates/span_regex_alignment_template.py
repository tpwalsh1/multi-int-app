import hashlib
from typing import Any, Dict, List, Optional

import pandas as pd
import re2
from pydantic import ValidationError, validator

from rich_doc_wrapper import (
    DIRECTIONS,
    HORZ_DIRECTIONS,
    HORZ_LOCATIONS,
    LOCATIONS,
    SCOPES,
    THRESHOLD_UNITS,
    VERT_DIRECTIONS,
    VERT_LOCATIONS,
    Direction,
    Location,
    RichDocWrapper,
    Scope,
    Threshold,
    ThresholdUnit,
)
from snorkelflow.extraction.span import SpanCols
from snorkelflow.rich_docs import MissingRichDocException, RichDocCols
from snorkelflow.types.performance import Performance
from snorkelflow.utils.logging import get_logger
from templates.utils import TemplateSchema

from .template import CLASSIC_STUDIO_URL, RICH_DOC_BASED, Template, TemplateConfig

logger = get_logger("Studio SpanRegexAlignmentTemplate")


class SpanRegexAlignmentTemplateSchema(TemplateSchema):
    regex_pattern: str
    location: Location
    threshold: Threshold
    threshold_unit: ThresholdUnit
    threshold_dir: Optional[Direction]
    scope: Scope
    case_sensitive: Optional[bool] = False

    @validator("regex_pattern")
    def check_regex_pattern(cls, regex_pattern: str) -> str:
        try:
            re2.compile(regex_pattern)
        except Exception:
            raise ValueError(f"Invalid regex_pattern {regex_pattern}")
        return regex_pattern

    @validator("location")
    def check_location(cls, loc: str) -> str:
        if loc.lower() not in LOCATIONS:
            raise ValueError(f"Invalid location {loc}")
        return loc

    @validator("threshold_dir")
    def check_threshold_dir(cls, td: str, values: Dict[str, Any]) -> str:
        if td is not None:
            loc = values["location"]
            if td.lower() not in DIRECTIONS:
                raise ValueError(f"Invalid threshold_dir {td}")
            if td.lower() in VERT_DIRECTIONS and loc.lower() not in VERT_LOCATIONS:
                raise ValueError(f"Invalid threshold_dir {td} for location {loc}")
            if td.lower() in HORZ_DIRECTIONS and loc.lower() not in HORZ_LOCATIONS:
                raise ValueError(f"Invalid threshold_dir {td} for location {loc}")
        return td

    @validator("scope")
    def check_scope(cls, scope: str) -> str:
        if scope.lower() not in SCOPES:
            raise ValueError(f"Invalid scope {scope}")
        return scope

    @validator("threshold_unit")
    def check_threshold_unit(cls, threshold_unit: str) -> str:
        if threshold_unit.lower() not in THRESHOLD_UNITS:
            raise ValueError(f"Invalid threshold_unit {threshold_unit}")
        return threshold_unit


class SpanRegexAlignmentTemplate(Template):
    """LF Template based on regexes aligned with the span a/t RichDoc.

    Heuristic:
    "If SPAN is [location] aligned with [regex_pattern] in [scope] within [threshold]
    [threshold_units], return True"

    NOTE: Requires RichDoc column to function
    """

    template_type = "span_regex_alignment"
    abbreviation = "SRA"
    description = "If SPAN's [location] is aligned with [regex]'s [location] within [threshold] [threshold_units] (optionally limited to scope [scope]), then label. CENTER is between LEFT/RIGHT, MIDDLE is between TOP/BOTTOM."
    menu_type = {
        "name": "Span Regex Alignment Builder",
        "value": template_type,
        "category": [RICH_DOC_BASED],
    }

    docs_link = CLASSIC_STUDIO_URL + "span-regex-alignment-rich-doc-based-lfs"
    template_schema = "SpanRegexAlignmentTemplateSchema"

    def __init__(self, template_config: TemplateConfig) -> None:
        self._regex_pattern = template_config["regex_pattern"]
        self._location = template_config["location"].lower()
        self._threshold = template_config["threshold"]
        self._threshold_unit = template_config["threshold_unit"].lower()
        maybe_threshold_dir = template_config["threshold_dir"]
        self._threshold_dir = (
            maybe_threshold_dir.lower() if maybe_threshold_dir is not None else None
        )
        self._scope = template_config["scope"].lower()
        self._case_sensitive = template_config["case_sensitive"]

        regex_encoding = (self._regex_pattern + str(self._case_sensitive)).encode()
        self._ngrams_field = f"ngrams_{hashlib.md5(regex_encoding).hexdigest()[:10]}"

        logger.debug(
            f"Building {self.template_type} template with config {template_config}"
        )

    def estimate_perf(self, df: pd.DataFrame) -> Performance:
        total_spans = len(df)
        text = df[RichDocCols.TEXT_COL].iloc[0]
        num_matches = len(re2.findall(self._regex_pattern, text))
        return Performance(
            compute_time_secs=total_spans * num_matches * 1e-3,
            peak_memory_mb=total_spans * num_matches * 1e-3,
        )

    def preprocess_configs(self) -> List[Dict[str, Any]]:
        """Detecting regex n-gram as prepro step"""
        return [
            dict(
                op_type="RichDocRegexNGramDetector",
                op_config=dict(
                    regex=self._regex_pattern,
                    target_field=self._ngrams_field,
                    case_sensitive=self._case_sensitive,
                ),
            )
        ]

    def check(self, x: pd.Series) -> bool:
        rd = x.get(RichDocCols.DOC_COL)
        if rd is None:
            raise MissingRichDocException(
                "Could not find RichDoc columns in DataFrame. "
                "Make sure that these columns have been added via task processors."
            )
        return RichDocWrapper(rd).is_regex_aligned(
            char_start=x[SpanCols.CHAR_START],
            char_end=x[SpanCols.CHAR_END],
            ngrams=x[self._ngrams_field],
            location=self._location,
            threshold=self._threshold,
            threshold_unit=self._threshold_unit,
            threshold_dir=self._threshold_dir,
            scope=self._scope,
            case_sensitive=self._case_sensitive,
        )

    @classmethod
    def name(
        cls,
        template_config: TemplateConfig,
        current_name: str,
        curr_lf_names: List[str],
    ) -> str:
        try:
            template_config = SpanRegexAlignmentTemplateSchema(**template_config).dict()
        except ValidationError:
            return current_name
        start_name = (
            str(template_config["location"])[:3]
            + "_"
            + template_config["regex_pattern"][:5]
        )

        return cls.get_final_name(start_name, curr_lf_names)
