import json
import sys
from typing import Any, Dict, List, Optional, Pattern, Tuple

import pandas as pd
import regex
from pydantic import ValidationError, validator

from api_utils.exceptions import SnorkelException, UserInputError
from file_utils.core import LocalReadFsspecPath, path_exists
from regex_utils.selector import select_compiled_regex
from regex_utils.trie import Trie
from snorkelflow.types.performance import Performance
from snorkelflow.utils.file import resolve_data_path
from snorkelflow.utils.logging import get_logger
from templates.utils import TemplateSchema, tokenize_pattern

from .template import BASE_URL, SEQUENCE_PATTERN_BASED, SequenceTemplate, TemplateConfig

logger = get_logger("Studio SequenceSpacyPropTemplate")

CASE_SENSITIVE_DEFAULT = False

INVALID_FILE_FORMAT_ERROR_MESSAGE = "Provided file is not the expected format. Please refer to the Labeling Function Builders Documentation for more details."


def _validate_expected_json_format(v: str) -> Any:
    try:
        entity_dict_path = resolve_data_path(v)
        with LocalReadFsspecPath(entity_dict_path) as local_path:
            with open(local_path, "r") as f:
                entity_dict = json.load(f)
        for common_entity_forms in entity_dict.values():
            if not isinstance(common_entity_forms, list):
                return INVALID_FILE_FORMAT_ERROR_MESSAGE
    except Exception as e:
        return e


class SequenceEntityDictTemplateSchema(TemplateSchema):
    """Sequence Entity Dictionary template

    Parameters
    ----------
    field : str
        Field
    entity_dict_path : str
        Path to a file
    case_sensitive : bool, default False
        Case sensitive or not
    """

    field: str
    entity_dict_path: str
    case_sensitive: Optional[bool] = CASE_SENSITIVE_DEFAULT

    @staticmethod
    def artifact_config_keys() -> List[str]:
        return ["entity_dict_path"]

    @validator("entity_dict_path")
    def validate_entity_dict_path(cls, v: str) -> str:
        if not path_exists(v):
            err_msg = "Feature or embedding field(s) are incorrectly formatted or model did not train."
            raise UserInputError(
                detail=f"Path {v} does not exist",
                user_friendly_message=err_msg,
                how_to_fix="Please make sure file exists.",
            )

        err_msg = _validate_expected_json_format(v)
        if err_msg:
            raise SnorkelException(
                detail=INVALID_FILE_FORMAT_ERROR_MESSAGE,
                user_friendly_message=INVALID_FILE_FORMAT_ERROR_MESSAGE,
            )
        return v


class SequenceEntityDictTemplate(SequenceTemplate):
    "LF Template for Sequence Entity Dict-based interfaces."

    template_type = "sequence_entity_dict"
    abbreviation = "SED"
    description = "If [field] contains any of keywords in [entity_dict_path], then label the matching character offsets."
    menu_type = {
        "name": "Sequence Entity Dict Builder",
        "value": template_type,
        "category": [SEQUENCE_PATTERN_BASED],
    }
    # TODO: Link to documentation when completed
    docs_link = BASE_URL + "sequence-entity-dict-builder"
    template_schema = "SequenceEntityDictTemplateSchema"

    def __init__(self, template_config: TemplateConfig) -> None:
        self._entity_dict_path = template_config["entity_dict_path"]
        self._field = template_config["field"]
        self._case_sensitive = template_config["case_sensitive"]
        self._regex_pattern: Optional[Pattern] = None
        logger.debug(
            f"Building {self.template_type} template on field {self._field}"
            f"with Entity Dict URL {self._entity_dict_path}."
        )

    def _compile_regex(self) -> Pattern:
        self.entity_lookup_table = {}
        trie = Trie()
        entity_dict_path = resolve_data_path(self._entity_dict_path)
        with LocalReadFsspecPath(entity_dict_path) as local_path:
            with open(local_path, "r") as f:
                entity_dict = json.load(f)

                for entity_id, common_entity_forms in entity_dict.items():
                    for value in common_entity_forms:
                        trie.add(value)
                        self.entity_lookup_table[value.lower()] = entity_id

        pattern = trie.pattern()

        regex_pattern = tokenize_pattern(pattern) if pattern else ""
        flags = regex.IGNORECASE if not self._case_sensitive else 0
        return select_compiled_regex(regex_pattern, flags=flags)

    @classmethod
    def name(
        cls,
        template_config: TemplateConfig,
        current_name: str,
        curr_lf_names: List[str],
    ) -> str:
        try:
            template_config = SequenceEntityDictTemplateSchema(**template_config).dict()
        except ValidationError:
            return current_name
        start_name = "-".join([template_config["entity_dict_path"]])[:8]

        return cls.get_final_name(start_name, curr_lf_names)

    def check(self, x: pd.Series) -> List[Tuple[int, int]]:
        "Sequence LFs vote with char offsets, not boolean values."
        field_value = str(x[self._field])
        if self._regex_pattern is None:
            self._regex_pattern = self._compile_regex()
        matches = self._regex_pattern.finditer(field_value)
        return [(m.start(0), m.end(0)) for m in matches]

    @property
    def input_schema(self) -> Dict[str, Any]:
        return {self._field: Any}

    def estimate_perf(self, df: pd.DataFrame) -> Performance:
        total_data_size = df[self._field].map(len).sum()
        num_docs = len(df)
        regex_pattern = self._compile_regex()
        entity_regex_size = sys.getsizeof(regex_pattern)
        return Performance(
            compute_time_secs=(total_data_size * entity_regex_size) / 2_000_000_000,
            peak_memory_mb=(num_docs * entity_regex_size) / 120_000,
        )
