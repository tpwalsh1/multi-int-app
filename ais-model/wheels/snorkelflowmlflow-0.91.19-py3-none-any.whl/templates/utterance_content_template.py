from typing import List

from pydantic import ValidationError

from snorkelflow.extraction.span import SpanCols
from snorkelflow.types.columns import ConvCols
from templates.span_content_template import SpanContentTemplate
from templates.utils import PatternMatchTemplateSchema, SpanPatternMatchOperator

from .template import BASE_URL, CONVERSATION_BASED, TemplateConfig


class UtteranceContentTemplateSchema(PatternMatchTemplateSchema):
    """Utterance Content template

    Parameters
    ----------
    operator : {"MATCHES", "CONTAINS", "STARTS", "ENDS"}
        Operator
    value : str
        Pattern
    regex : bool, default False
        If True, the pattern is treated as a regex
    case_sensitive : bool, default False
        Case sensitive or not
    tokenize : bool, default False
        Tokenize or not
    """

    operator: SpanPatternMatchOperator


class UtteranceContentTemplate(SpanContentTemplate):

    """LF Template based on utterance content."""

    template_type = "utterance_content"
    abbreviation = "UCN"
    description = "If the utterance [contains, starts with, etc.] the [keyword/phrase], then label."
    menu_type = {
        "name": "Utterance Content Builder",
        "value": template_type,
        "category": [CONVERSATION_BASED],
    }
    docs_link = BASE_URL + "utterance-content-builder"
    template_schema = "UtteranceContentTemplateSchema"

    def __init__(self, template_config: TemplateConfig) -> None:
        template_config["span_field"] = ConvCols.TEXT_COL
        template_config["span_text_field"] = SpanCols.SPAN_TEXT
        super().__init__(template_config)

    @classmethod
    def name(
        cls,
        template_config: TemplateConfig,
        current_name: str,
        curr_lf_names: List[str],
    ) -> str:
        try:
            template_config = UtteranceContentTemplateSchema(**template_config).dict()
        except ValidationError:
            return current_name
        start_name = template_config["value"][:8]

        return cls.get_final_name(start_name, curr_lf_names)
