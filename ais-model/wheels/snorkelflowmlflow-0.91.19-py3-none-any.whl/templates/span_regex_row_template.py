from typing import List, Optional

import pandas as pd
import regex
from pydantic import ValidationError, validator

from rich_doc_wrapper import CASE_SENSITIVE_DEFAULT, SPAN_TOKEN, RichDocWrapper
from snorkelflow.extraction.span import SpanCols
from snorkelflow.rich_docs import MissingRichDocException, RichDocCols
from snorkelflow.utils.logging import get_logger
from templates.utils import TemplateSchema

from .template import CLASSIC_STUDIO_URL, RICH_DOC_BASED, Template, TemplateConfig

logger = get_logger("Studio SpanRegexRowTemplate")


class SpanRegexRowTemplateSchema(TemplateSchema):
    regex_pattern: str
    rows_before: Optional[int] = None
    rows_after: Optional[int] = None
    case_sensitive: bool = CASE_SENSITIVE_DEFAULT

    @validator("rows_before")
    def check_rows_before(cls, rows_before: Optional[int]) -> int:
        if rows_before is None:
            return 0
        if rows_before < 0:
            raise ValueError(f"rows_before value cannot be negative")
        return rows_before

    @validator("rows_after")
    def check_rows_after(cls, rows_after: Optional[int]) -> int:
        if rows_after is None:
            return 0
        if rows_after < 0:
            raise ValueError(f"rows_after value cannot be negative")
        return rows_after

    @validator("regex_pattern")
    def check_regex_pattern(cls, regex_pattern: str) -> str:
        try:
            regex.compile(regex_pattern)
        except Exception:
            raise ValueError(f"Invalid regex_pattern {regex_pattern}")
        return regex_pattern


class SpanRegexRowTemplate(Template):
    """LF Template based on the presence of a regex within a row range of the given span a/t RichDoc.

    Heuristic:
    "If [regex_pattern] is in the range [rows_before] to [rows_after] from the SPAN, return True.

    NOTE: Requires RichDoc column to function
    """

    template_type = "span_regex_row"
    abbreviation = "SRR"
    description = f"If SPAN is in text in the range [rows_before] to [rows_after] relative to the regex, then label. Use the range (0, 0) to look only in the regex's row. Use {SPAN_TOKEN} to express a regular expression that includes the span."
    menu_type = {
        "name": "Span Regex Row Builder",
        "value": template_type,
        "category": [RICH_DOC_BASED],
    }
    docs_link = CLASSIC_STUDIO_URL + "span-regex-row-rich-doc-based-lfs"
    template_schema = "SpanRegexRowTemplateSchema"

    def __init__(self, template_config: TemplateConfig) -> None:
        self._regex_pattern = template_config["regex_pattern"]
        self._rows_before = template_config["rows_before"]
        self._rows_after = template_config["rows_after"]
        self._case_sensitive = template_config["case_sensitive"]
        self._mask_span = SPAN_TOKEN in self._regex_pattern

        logger.debug(
            f"Building {self.template_type} template with config {template_config}"
        )

    def check(self, x: pd.Series) -> bool:
        char_start = x[SpanCols.CHAR_START]
        char_end = x[SpanCols.CHAR_END]
        rd = x.get(RichDocCols.DOC_COL)
        if rd is None:
            raise MissingRichDocException(
                "Could not find RichDoc columns in DataFrame. "
                "Make sure that these columns have been added via task processors."
            )
        row_text = RichDocWrapper(rd).get_span_row_text(
            char_start,
            char_end,
            # N rows after span = N rows before regex
            (-1 * self._rows_after, self._rows_before),
            mask_span=self._mask_span,
        )
        flags = 0 if self._case_sensitive else regex.IGNORECASE

        compiled_regex = regex.compile(self._regex_pattern, flags=flags)

        return bool(compiled_regex.search(row_text))

    @classmethod
    def name(
        cls,
        template_config: TemplateConfig,
        current_name: str,
        curr_lf_names: List[str],
    ) -> str:
        try:
            template_config = SpanRegexRowTemplateSchema(**template_config).dict()
        except ValidationError:
            return current_name
        start_name = (
            template_config["regex_pattern"][:4]
            + "_"
            + str(template_config["rows_before"])
            + "_"
            + str(template_config["rows_after"])
        )

        return cls.get_final_name(start_name, curr_lf_names)
