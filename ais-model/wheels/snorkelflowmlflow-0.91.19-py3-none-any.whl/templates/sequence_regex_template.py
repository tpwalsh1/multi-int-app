from re import Pattern
from typing import Any, Dict, List, Optional, Tuple

import pandas as pd
import regex
from pydantic import ValidationError, root_validator

from regex_utils.selector import select_compiled_regex
from snorkelflow.types.performance import Performance
from snorkelflow.utils.logging import get_logger
from templates.utils import TemplateSchema

from .template import BASE_URL, SEQUENCE_PATTERN_BASED, SequenceTemplate, TemplateConfig

logger = get_logger("Studio SequenceRegexTemplate")

CASE_SENSITIVE_DEFAULT = False


class SequenceRegexTemplateSchema(TemplateSchema):
    """Sequence Regex template

    Parameters
    ----------
    field : str
        Field
    regex_pattern : str
        Regex pattern
    case_sensitive : bool, default False
        Case sensitive or not
    group_idx : int, default 0
        Matched group index
    """

    regex_pattern: str
    field: str
    case_sensitive: Optional[bool] = CASE_SENSITIVE_DEFAULT
    group_idx: int = 0

    @root_validator
    def validate_regex(cls, values: Dict[str, Any]) -> Dict[str, Any]:
        regex_pattern = str(values["regex_pattern"])
        try:
            compiled_regex = select_compiled_regex(regex_pattern)
        except Exception:
            raise ValueError(f"Invalid regex pattern {regex_pattern}")
        group_index = int(values["group_idx"])
        if group_index < 0 or group_index > compiled_regex.groups:
            raise ValueError(f"group_idx must be in [0, {compiled_regex.groups}]")
        return values


class SequenceRegexTemplate(SequenceTemplate):
    "LF Template for Sequence text-based regexes interfaces."

    template_type = "sequence_regex"
    abbreviation = "SRGX"
    description = "If [field] contains the regular expression [regex] then label the matching character offsets."
    menu_type = {
        "name": "Sequence Regex Builder",
        "value": template_type,
        "category": [SEQUENCE_PATTERN_BASED],
    }
    # TODO: Link to documentation when completed
    docs_link = BASE_URL + "sequence-regex-builder"
    template_schema = "SequenceRegexTemplateSchema"

    def __init__(self, template_config: TemplateConfig) -> None:
        self._regex_pattern = template_config["regex_pattern"]
        self._field = template_config["field"]
        self._group_idx = template_config["group_idx"]
        self._flags = 0  # The default value for flags
        if not template_config.get("case_sensitive", CASE_SENSITIVE_DEFAULT):
            self._flags = self._flags | regex.I
        self._regex: Optional[Pattern] = None

    def _compile_regex(self) -> Pattern:
        return select_compiled_regex(self._regex_pattern, flags=self._flags)

    def estimate_perf(self, df: pd.DataFrame) -> Performance:
        total_len = df[self._field].map(len).sum()
        return Performance(
            compute_time_secs=total_len * 0.0000003, peak_memory_mb=total_len * 0.000003
        )

    @classmethod
    def name(
        cls,
        template_config: TemplateConfig,
        current_name: str,
        curr_lf_names: List[str],
    ) -> str:
        try:
            template_config = SequenceRegexTemplateSchema(**template_config).dict()
        except ValidationError:
            return current_name
        start_name = regex.sub(r"[^\w]", "", template_config["regex_pattern"])[:8]

        return cls.get_final_name(start_name, curr_lf_names)

    def check(self, x: pd.Series) -> List[Tuple[int, int]]:
        "Sequence LFs vote with char offsets, not boolean values."
        field_value = str(x[self._field])
        if self._regex is None:
            self._regex = self._compile_regex()
        matches = self._regex.finditer(field_value)
        return [(m.start(self._group_idx), m.end(self._group_idx)) for m in matches]

    @property
    def input_schema(self) -> Dict[str, Any]:
        return {self._field: Any}
