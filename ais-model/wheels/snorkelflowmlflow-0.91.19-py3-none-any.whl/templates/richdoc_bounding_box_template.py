from typing import List

import re2
from pydantic import ValidationError, validator

from snorkelflow.utils.logging import get_logger
from templates.rich_doc_expression_template import (
    RichDocExpressionTemplate,
    RichDocExpressionTemplateSchema,
)
from templates.utils import TemplateSchema

from .template import CLASSIC_STUDIO_URL, RICH_DOC_BASED, TemplateConfig

logger = get_logger("Studio")


def parse_coordinates(coordinates: str) -> List[float]:
    """
    Function to parse string from FE and return list of float coordinate values
    """
    return [
        float(item)
        for item in re2.split(",| |\[|\]|\{|\}|\(|\)", coordinates)
        if item is not None and item != ""
    ]


class RichDocBoundingBoxTemplateSchema(TemplateSchema):
    regex_pattern: str
    coordinates: str
    case_sensitive: bool = True

    @validator("coordinates")
    def check_coordinates(cls, coordinates: str) -> str:
        try:
            values = parse_coordinates(coordinates)
        except ValueError:
            raise ValueError(f"Invalid coordinate value {coordinates}")

        if len(values) != 4:
            raise ValueError(
                f"Invalid number of coordinates. Contains {len(coordinates)} values instead of 4 values"
            )

        return coordinates


class RichDocBoundingBoxTemplate(RichDocExpressionTemplate):
    """LF Template to check if an expression is within a specific bounding box
    Heuristic: If PATTERN is within the bounding box defined by (left, top, right, bottom), return True
    """

    template_type = "rich_doc_bounding_box"
    abbreviation = "RBBD"
    description = (
        "If the pattern lies within bounding box (left, top, right, bottom) then label."
    )
    menu_type = {
        "name": "Rich Doc Bounding Box Builder",
        "value": template_type,
        "category": [RICH_DOC_BASED],
    }
    docs_link = CLASSIC_STUDIO_URL + "rich-doc-bounding-box-rich-doc-based-lfs"
    template_schema = "RichDocBoundingBoxTemplateSchema"

    def __init__(self, template_config: TemplateConfig) -> None:
        logger.debug(
            f"Buiding up {self.template_type} template with config {template_config}"
        )
        values = parse_coordinates(template_config["coordinates"])
        left = min(values[0], values[2])
        right = max(values[0], values[2])
        top = min(values[1], values[3])
        bottom = max(values[1], values[3])
        expression = f"PATTERN1.left >= {left} and PATTERN1.top >= {top} and PATTERN1.right <= {right} and PATTERN1.bottom <= {bottom}"
        richdoc_expression_config = RichDocExpressionTemplateSchema(
            regex_patterns=[template_config["regex_pattern"]],
            expression=expression,
            search_all_combinations=True,
            case_sensitive=template_config["case_sensitive"],
        ).dict()
        super().__init__(richdoc_expression_config)

    @classmethod
    def name(
        cls,
        template_config: TemplateConfig,
        current_name: str,
        curr_lf_names: List[str],
    ) -> str:
        try:
            template_config = RichDocBoundingBoxTemplateSchema(**template_config).dict()
        except ValidationError:
            return current_name
        start_name = (
            str(template_config["regex_pattern"])[:3]
            + "_"
            + str(template_config["coordinates"])[:5]
        )
        return cls.get_final_name(start_name, curr_lf_names)
