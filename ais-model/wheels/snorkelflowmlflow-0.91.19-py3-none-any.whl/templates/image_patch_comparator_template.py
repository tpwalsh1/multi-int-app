from typing import Any, Dict, List

import pandas as pd
from pydantic import ValidationError, validator

from label_spaces.multi_label import MultiLabelSpace
from snorkelflow.models.image import CLIPPatchEncoder
from snorkelflow.utils.load_image import load_minio_image
from snorkelflow.utils.logging import get_logger
from templates.keyword_location_template import OPERATORS
from templates.utils import TemplateSchema, get_model_from_cache

from .template import BASE_URL, IMAGE_BASED, LFCacheKeys, Template, TemplateConfig

logger = get_logger("Image Patch Comparator LF")

IMAGE_PATCH_SIMILARITY_FIELD_NAME = "__image_patch_similarity"


class ImagePatchComparatorTemplateSchema(TemplateSchema):
    """Image Patch Comparator template

    Parameters
    ----------
    image_embedding_field : str
        Field containing the image embedding
    image_path : str
        Image path
    bbox : List[float]
        Bounding box
    operator : string, default >=
        Operator
    min_similarity : float, default 0.5
        Minimum similarity threshold
    """

    image_embedding_field: str
    image_path: str
    bbox: List[float]
    operator: str = ">="
    min_similarity: float = 0.5

    @staticmethod
    def artifact_config_keys() -> List[str]:
        return ["image_path"]

    @validator("image_path")
    def check_image_path(cls, image_path: str) -> str:
        try:
            load_minio_image(image_path.strip())
        except Exception as e:
            raise ValueError(f"Invalid image path '{image_path}'.") from e
        return image_path

    @validator("bbox")
    def check_bbox(cls, bbox: List[float], values: Dict[str, Any]) -> List[float]:
        if len(bbox) != 4:
            raise ValueError(f"Invalid bbox '{bbox}'. bbox must be a list of length 4.")
        try:
            image_path = values["image_path"]
            image = load_minio_image(image_path)
            width, height = image.size
        except Exception as e:
            raise ValueError(
                f"Invalid bbox '{bbox}'. Unable to parse bbox dimensions"
            ) from e

        if bbox[0] < 0 or bbox[1] < 0 or bbox[2] > width or bbox[3] > height:
            raise ValueError(
                f"Invalid bbox '{bbox}'. bbox must be within image dimensions."
            )
        return bbox

    @validator("operator")
    def check_operator(cls, op: str) -> str:
        if op not in OPERATORS.keys():
            raise ValueError(
                f"Invalid operator '{op}'. Must be in {list(OPERATORS.keys())}."
            )
        return op

    @validator("min_similarity")
    def check_min_similarity(cls, min_similarity: float) -> float:
        if min_similarity > 1.0 or min_similarity < -1.0:
            raise ValueError(
                f"Invalid similarity threshold '{min_similarity}'. "
                "min_similarity must be between -1.0 and 1.0."
            )
        return min_similarity


# TODO(ENG-18923): Deprecate non-multipolar image LFs.
class ImagePatchComparatorTemplate(Template):
    template_type = "image_patch_comparator"
    docs_link = BASE_URL + "image-patch-comparator"

    abbreviation = "IMP"
    description = "Classifies images by similarity to a patched image."
    menu_type = {
        "name": "Image Patch Comparator Builder",
        "value": template_type,
        "category": [IMAGE_BASED],
    }
    template_schema = "ImagePatchComparatorTemplateSchema"
    similarity_field_name = IMAGE_PATCH_SIMILARITY_FIELD_NAME

    def __init__(self, template_config: TemplateConfig) -> None:
        # TODO ENG-9850 Enable GPU support once one worker can use all GPU resources
        # instead of multiple workers trying to compete for GPU resources

        self.image_embedding_field = template_config["image_embedding_field"]
        self.image_path = template_config["image_path"].strip()
        self.bbox = template_config["bbox"]
        self.operator = template_config["operator"]
        self.min_similarity = template_config["min_similarity"]
        self._op_fn = OPERATORS[self.operator]

    def preprocess_configs(self) -> List[Dict[str, Any]]:
        """List of operator configs to run before applying LF."""

        def compute_reference_embeddings_fn() -> Any:
            image_encoder = get_model_from_cache(
                "CLIPPatchEncoder", lambda: CLIPPatchEncoder(device="cpu")
            )
            return image_encoder.featurize([self.image_path], [self.bbox])

        return [
            dict(
                op_type="EmbeddingComparator",
                op_config=dict(
                    embedding_field=self.image_embedding_field,
                    compute_reference_embeddings_fn=compute_reference_embeddings_fn,
                    metric="cosine_similarity",
                    target_field=self.similarity_field_name,
                    device=None,
                ),
            )
        ]

    def check(self, x: pd.Series) -> bool:
        print("asdf", x)
        similarity = x[self.similarity_field_name]
        if similarity is None:
            raise ValueError(
                f"Empty similarity={similarity} provided probably resulting from empty embeddings. "
                "Double check input embeddings are present and correct."
            )
        return self._op_fn(similarity, self.min_similarity)

    def compute_lf_votes_single_column(self, df: pd.Series, label: Any) -> pd.Series:
        cmp = lambda x: self._op_fn(x, self.min_similarity)
        unk = MultiLabelSpace.get_raw_unknown_label()
        _lf = lambda x: label if cmp(x) else unk

        lf_votes = df.apply(_lf)
        return lf_votes

    @classmethod
    def name(
        cls,
        template_config: TemplateConfig,
        current_name: str,
        curr_lf_names: List[str],
    ) -> str:
        try:
            template_config = ImagePatchComparatorTemplateSchema(
                **template_config
            ).dict()
        except ValidationError:
            return current_name

        image_path_name = template_config["image_path"].strip()[-8:]
        bbox_name = template_config["bbox"]
        start_name = f"{image_path_name}_{bbox_name}"

        return cls.get_final_name(start_name, curr_lf_names)

    @property
    def cache_keys(self) -> Dict[str, str]:
        return {
            LFCacheKeys.PREPROCESSED_DF: f"CLIPPatchEncoder_{self.image_path}_{self.bbox}",
            LFCacheKeys.LF_VOTES: f"{self.template_type}_{self.image_path}_{self.bbox}_{self.operator}_{self.min_similarity}",
        }
