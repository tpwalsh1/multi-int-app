import pickle
from typing import List, Tuple

import numpy as np
import pandas as pd
from pydantic import ValidationError, validator

from file_utils.core import open_file, path_exists
from snorkelflow.utils import resolve_data_path
from snorkelflow.utils.logging import get_logger
from templates.utils import TemplateSchema

from .template import (
    BASE_URL,
    EMBEDDING_NEAREST_NEIGHBOR_BASED,
    Template,
    TemplateConfig,
)

logger = get_logger("Studio Custom Embeddings Nearest Neighbor")


class EmbeddingNNTemplateSchema(TemplateSchema):
    """
    Template schema for EmbeddingsNearestNeighbor

    Parameters
    ----------
    class_embeddings_path : str
        Path to a file containing class embeddings
    feature_field : str
        Name of the field containing the feature / embeddings
    min_distance : float
        Minimum distance to be considered a match
    """

    class_embeddings_path: str
    min_distance = 0.8
    feature_field: str

    @staticmethod
    def artifact_config_keys() -> List[str]:
        return ["class_embeddings_path"]

    @validator("class_embeddings_path")
    def check_exists(cls, class_embeddings_path: str) -> str:
        if not path_exists(class_embeddings_path):
            raise ValueError(f"Path {class_embeddings_path} does not exist")
        return class_embeddings_path


class CustomEmbeddingsNearestNeighbor(Template):
    # This template is used to classify examples based on the nearest neighbor to the embedding of a class.
    # The is a multipolar template.
    template_type = "embeddings_nearest_neighbor"
    docs_link = BASE_URL + "embeddings-nn"

    abbreviation = "ENN"
    description = (
        "Classifies examples based on the nearest neighbor to the embedding of a class"
    )
    menu_type = {
        "name": "Multipolar Custom Embedding nearest neighbor",
        "value": template_type,
        "category": [EMBEDDING_NEAREST_NEIGHBOR_BASED],
    }
    template_schema = "EmbeddingNNTemplateSchema"

    def __init__(self, template_config: TemplateConfig) -> None:
        class_embeddings_path = template_config["class_embeddings_path"]
        if class_embeddings_path.startswith("minio"):
            class_embeddings_path = resolve_data_path(class_embeddings_path)

        with open_file(class_embeddings_path, "rb") as f:
            self.class_embeddings_path = pickle.load(f)
        self.min_distance = template_config["min_distance"]
        self.feature_field = template_config["feature_field"]

    def find_nearest_neighbor(self, np_embedding: np.ndarray) -> Tuple[float, str]:
        def _calculate_cosine_similarity(a: np.ndarray, b: np.ndarray) -> float:
            cosine_d = np.dot(a, b) / (np.linalg.norm(a, axis=1) * np.linalg.norm(b))
            return max(0, max(cosine_d))

        min_distance = 0.0
        classname = "UNKNOWN"
        for key, val in self.class_embeddings_path.items():
            distance = _calculate_cosine_similarity(val, np.squeeze(np_embedding))
            if distance > min_distance:
                min_distance = distance
                classname = key[0]
        return min_distance, classname

    def check(self, x: pd.Series) -> str:
        np_embedding = np.array(x[self.feature_field]).reshape(1, -1)
        distance, classname = self.find_nearest_neighbor(np_embedding)

        if distance > self.min_distance:
            return classname
        else:
            return "UNKNOWN"

    @classmethod
    def name(
        cls,
        template_config: TemplateConfig,
        current_name: str,
        curr_lf_names: List[str],
    ) -> str:
        try:
            template_config = EmbeddingNNTemplateSchema(**template_config).dict()
        except ValidationError:
            return current_name

        if template_config["class_embeddings_path"]:
            start_name = template_config["class_embeddings_path"]
        else:
            # Use start of the file name if no name available
            start_name = str(template_config["class_embeddings_path"][:10])
        return cls.get_final_name(start_name, curr_lf_names)
