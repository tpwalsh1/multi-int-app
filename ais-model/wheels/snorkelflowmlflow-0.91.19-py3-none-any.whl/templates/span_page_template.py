from typing import List

import pandas as pd
from pydantic import StrictInt, ValidationError, validator

from rich_doc_wrapper import RichDocWrapper
from snorkelflow.extraction.span import SpanCols
from snorkelflow.rich_docs import MissingRichDocException, RichDocCols
from snorkelflow.utils.logging import get_logger
from templates.utils import TemplateSchema

from .template import CLASSIC_STUDIO_URL, RICH_DOC_BASED, Template, TemplateConfig

logger = get_logger("Studio SpanPageTemplate")

OPERATORS = {
    "=": lambda x, y: x == y,
    "!=": lambda x, y: x != y,
    "<": lambda x, y: x < y,
    "<=": lambda x, y: x <= y,
    ">": lambda x, y: x > y,
    ">=": lambda x, y: x >= y,
}


class SpanPageTemplateSchema(TemplateSchema):
    operator: str
    value: StrictInt

    @validator("operator")
    def check_operator(cls, op: str) -> str:
        if op not in OPERATORS:
            raise ValueError(f"Invalid operator {op}")
        return op


class SpanPageTemplate(Template):
    """LF Template based on the 1-indexed page number of the given span a/t hOCR.

    Heuristic:
    "If SPAN's page number is [<, =, etc.] [value], return True"

    NOTE: Requires RichDoc column to function
    """

    template_type = "span_page_number"
    abbreviation = "SPG"
    description = (
        "If SPAN's (1-indexed) page number is [<, =, etc.] [value], then label."
    )
    menu_type = {
        "name": "Span Page Number Builder",
        "value": template_type,
        "category": [RICH_DOC_BASED],
    }
    docs_link = CLASSIC_STUDIO_URL + "span-page-rich-doc-based-lfs"
    template_schema = "SpanPageTemplateSchema"

    def __init__(self, template_config: TemplateConfig) -> None:
        operator = template_config["operator"]
        self._operator_fn = OPERATORS[operator]
        self._value = template_config["value"]

        logger.debug(
            f"Building {self.template_type} template with "
            f"operator {operator} and value {self._value}."
        )

    def check(self, x: pd.Series) -> bool:
        char_start = x[SpanCols.CHAR_START]
        char_end = x[SpanCols.CHAR_END]
        rd = x.get(RichDocCols.DOC_COL)
        if rd is None:
            raise MissingRichDocException(
                "Could not find RichDoc columns in DataFrame. "
                "Make sure that these columns have been added via task processors."
            )

        return self._operator_fn(
            RichDocWrapper(rd).get_page_num(char_start, char_end), self._value
        )

    @classmethod
    def name(
        cls,
        template_config: TemplateConfig,
        current_name: str,
        curr_lf_names: List[str],
    ) -> str:
        try:
            template_config = SpanPageTemplateSchema(**template_config).dict()
        except ValidationError:
            return current_name
        start_name = str(template_config["operator"]) + str(template_config["value"])

        return cls.get_final_name(start_name, curr_lf_names)
