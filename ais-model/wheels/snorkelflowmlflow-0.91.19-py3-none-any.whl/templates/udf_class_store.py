from collections import defaultdict
from copy import deepcopy
from datetime import datetime
from typing import Any, Dict, Optional, Type

import dill

from snorkelflow.serialization.code_asset import deserialize_asset
from snorkelflow.utils.logging import get_logger
from templates.template import Template
from templates.utils import TemplateSchema

logger = get_logger("templates_udf_class_store")
try:
    from postgres_utils.pool import connection, out_of_request_db_connection
    from postgres_utils.query import fetchall, fetchone
except ModuleNotFoundError:
    # templates_slim wouldn't have postgres_utils
    logger.debug(
        "Cannot connect to database, custom template classes will not be available"
    )
    connection = None

AUTHORIZATION_ON = True
try:
    from authorization.auth_types import AuthorizeStatus
    from authorization.authorization_common import check_user_authorization
    from authorization.authorization_context import get_authorization_context
except ImportError:
    # template_slim won't have authorization utils
    AUTHORIZATION_ON = False
    logger.debug(
        "Skipping authorization. custom LF template classes will not be available"
    )

READ_TIME = datetime.min
DONT_READ_IF_LAST_READ_IN_SECONDS = 100


# mapping from workspace_uid to template classes
_WORKSPACE_TEMPLATE_CLS: Dict[int, Dict[str, Type[Template]]] = defaultdict(dict)
# mapping from workspace_uid to template schema classes
_WORKSPACE_TEMPLATE_SCHEMA_CLS: Dict[
    int, Dict[str, Type[TemplateSchema]]
] = defaultdict(dict)
# mapping from workspace_uid to template schema class json configs
_WORKSPACE_TEMPLATE_SCHEMA_CLS_JSON_CONFIG: Dict[int, Dict[str, Dict]] = defaultdict(
    dict
)
# mapping from workspace_uid to template classes for each lf state (which are
# then used in Studio to construct the LF State Classes)
# use type Any for now to prevent circular imports
_WORKSPACE_LF_STATE_TO_TEMPLATE_CLS_MAPPING: Dict[int, Dict[str, Any]] = defaultdict(
    dict
)


def _get_lf_templates_modified_time(conn: connection) -> datetime:
    with conn:
        row = fetchone(
            conn,
            """
            SELECT time FROM dim_lf_templates_times
            """,
        )
        return row[0]


def add_custom_lf_template(workspace_uid: int, template_config: Dict[str, Any]) -> None:
    template_schema = TemplateSchema.from_json(template_config["template_schema_class"])
    _WORKSPACE_TEMPLATE_SCHEMA_CLS[workspace_uid][
        template_schema.__name__
    ] = template_schema
    _WORKSPACE_TEMPLATE_SCHEMA_CLS_JSON_CONFIG[workspace_uid][
        template_config["template_schema_class"]["class_name"]
    ] = template_config["template_schema_class"]
    template_cls: Type[Template] = deserialize_asset(template_config["template_class"])
    _WORKSPACE_TEMPLATE_CLS[workspace_uid][
        template_cls.template_type  # type: ignore
    ] = template_cls
    lf_state_cls = deserialize_asset(template_config["lf_state_class"])
    lf_state_cls.remove_from_builtin_mapping()  # type: ignore
    _WORKSPACE_LF_STATE_TO_TEMPLATE_CLS_MAPPING[workspace_uid][
        lf_state_cls.state
    ] = template_cls


def _clear_cached_templates() -> None:
    """Clear the cached templates before refreshing from a database read,
    this ensures we catch deletes without needing fancy tombstone logic"""
    _WORKSPACE_TEMPLATE_CLS.clear()
    _WORKSPACE_TEMPLATE_SCHEMA_CLS.clear()
    _WORKSPACE_TEMPLATE_SCHEMA_CLS_JSON_CONFIG.clear()
    _WORKSPACE_LF_STATE_TO_TEMPLATE_CLS_MAPPING.clear()


def _refresh_lf_templates_and_states(conn: connection) -> None:
    global READ_TIME
    with conn:
        last_updated_time = _get_lf_templates_modified_time(conn)
        if READ_TIME > last_updated_time:
            READ_TIME = datetime.now()
            return
        templates = fetchall(
            conn,
            """
            SELECT template_config, workspace_uid
            FROM dim_lf_templates
            """,
            use_dict_cur=True,
        )
    _clear_cached_templates()
    # This is required to solve the messup because of parallel cloudpickle import
    dill._dill._reverse_typemap["ClassType"] = type
    for template in templates:
        config = template["template_config"]
        workspace_uid = template["workspace_uid"]
        add_custom_lf_template(workspace_uid, config)
    READ_TIME = datetime.now()


def refresh_lf_templates_and_states(conn: Optional[connection] = None) -> None:
    seconds_after_last_read = (datetime.now() - READ_TIME).total_seconds()
    if seconds_after_last_read < DONT_READ_IF_LAST_READ_IN_SECONDS:
        return

    try:
        if not conn:
            with out_of_request_db_connection() as conn:
                _refresh_lf_templates_and_states(conn)
        else:
            _refresh_lf_templates_and_states(conn)
    except NameError:
        logger.warning(
            "Cannot connect to database. Custom LF templates are not available."
        )


def _get_custom_lf_templates_helper(
    cls_map: Dict[int, Dict[str, Any]], conn: Optional[connection] = None
) -> Dict[str, Any]:
    ret = {}
    if AUTHORIZATION_ON:
        auth_resp = check_user_authorization(conn)
        logger.debug(f"auth resp: {auth_resp.json()}")
        if auth_resp.authorize_status == AuthorizeStatus.AUTHORIZED:
            auth_ctx = get_authorization_context()
            assert auth_ctx  # for mypy. if authorized, auth_ctx is set
            if auth_ctx.workspace_uid is None:
                logger.warning(
                    "Trying to access custom lf templates from non workspace scoped context. Not able to access custom lf templates"
                )

            else:
                refresh_lf_templates_and_states(conn)
                # making a copy in case caller change it
                # MappingProxyType cannot be pickled so not used here
                ret = deepcopy(cls_map[auth_ctx.workspace_uid])
        elif get_authorization_context() is None:
            # log the stacktrace in case we miss some APIs where authorization is needed
            logger.warning(
                f"authorization failed. authorization context is not set.",
                # stack_info=True,
            )
    return ret


def get_custom_lf_template_schema_configs(
    conn: Optional[connection] = None,
) -> Dict[str, Dict]:
    return _get_custom_lf_templates_helper(
        _WORKSPACE_TEMPLATE_SCHEMA_CLS_JSON_CONFIG, conn
    )


def get_custom_lf_template_schemas(
    conn: Optional[connection] = None,
) -> Dict[str, Type[TemplateSchema]]:
    return _get_custom_lf_templates_helper(_WORKSPACE_TEMPLATE_SCHEMA_CLS, conn)


def get_custom_lf_template_schema(
    template_schema_name: str, conn: Optional[connection] = None
) -> Type[TemplateSchema]:
    lf_template_schemas = get_custom_lf_template_schemas(conn)
    if template_schema_name not in lf_template_schemas:
        raise ValueError(f"Unsupported template schema: {template_schema_name}")
    return lf_template_schemas[template_schema_name]


def get_custom_lf_templates(
    conn: Optional[connection] = None,
) -> Dict[str, Type[Template]]:
    if conn is None:
        with out_of_request_db_connection() as conn:
            return _get_custom_lf_templates_helper(_WORKSPACE_TEMPLATE_CLS, conn)
    else:
        return _get_custom_lf_templates_helper(_WORKSPACE_TEMPLATE_CLS, conn)


def get_custom_lf_template(
    template_type: str, conn: Optional[connection] = None
) -> Type[Template]:
    lf_templates = get_custom_lf_templates(conn)
    if template_type not in lf_templates:
        raise ValueError(f"Unsupported template type: {template_type}")
    return lf_templates[template_type]


def get_custom_lf_states_to_templates(
    conn: Optional[connection] = None,
) -> Dict[str, Any]:
    return _get_custom_lf_templates_helper(
        _WORKSPACE_LF_STATE_TO_TEMPLATE_CLS_MAPPING, conn
    )


def get_custom_lf_state_to_template(
    state: str, conn: Optional[connection] = None
) -> Any:
    lf_states = get_custom_lf_states_to_templates(conn)
    if state not in lf_states:
        raise ValueError(f"Unsupported lf state: {state}")
    return lf_states[state]


# Used by tests only
def get_latest_read_time() -> datetime:
    return READ_TIME
