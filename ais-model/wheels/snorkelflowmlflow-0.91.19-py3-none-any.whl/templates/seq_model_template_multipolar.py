from typing import Dict, List, Tuple

import pandas as pd

from snorkelflow.utils.logging import get_logger
from templates.seq_model_template import (
    SequenceModelTemplate,
    SequenceModelTemplateSchema,
)

from .template import BASE_URL, SEQUENCE_PATTERN_BASED, TemplateConfig

logger = get_logger("Studio SequenceModelTemplate")


class MultiPolarSequenceModelTemplateSchema(SequenceModelTemplateSchema):
    """Multipolar Sequence Model template

    Parameters
    ----------
    field : str
        Field storing the output of a ModelFeaturizer
    label : None
        Inherited from SequenceModelTemplateSchema, but not used.
    include_fields : List[str]
        The fields to include in the model featurization.
    model_type : str
        The specific model used, must be contained in:
            ["sdnet"]
    model_name : str
        A user specified string name given to the trained model.
    dirpath : str
        The path to the stored model in minio.
    unique_model_name : Optional[str] = None
        A unique name for the model, usually the same as dirpath.
    inv_label_map : Dict[str, int]
        A mapping from the user's class labels to the LF's class labels.
    """

    label: None = None  # type: ignore
    inv_label_map: Dict[int, str]


class MultiPolarSequenceModelTemplate(SequenceModelTemplate):
    """Multipolar LF Template to extract predictions from a sequence ModelBased featurizer
    output."""

    template_type = "sequence_model_based_multipolar"
    abbreviation = "SMTM"
    description = (
        "Cached multipolar votes based on predictions from a ModelBased featurizer."
    )
    menu_type = {
        "name": "Sequence Model Output Builder (Multipolar)",
        "value": template_type,
        "category": [SEQUENCE_PATTERN_BASED],
    }
    docs_link = BASE_URL + "sequence-model-builder-span-based-lfs"
    template_schema = "MultiPolarSequenceModelTemplateSchema"

    def __init__(self, template_config: TemplateConfig) -> None:
        super().__init__(template_config)
        self.inv_label_map = template_config["inv_label_map"]

    def check(self, x: pd.Series) -> List[Tuple[int, int, str]]:  # type: ignore
        model_output_value: List[Tuple[int, int, int]] = x[self._model_output_field]
        if model_output_value is None:
            return []
        return [(r[0], r[1], self.inv_label_map[r[2]]) for r in model_output_value]
