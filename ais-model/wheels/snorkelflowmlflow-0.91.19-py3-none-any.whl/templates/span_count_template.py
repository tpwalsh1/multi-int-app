from snorkelflow.utils.logging import get_logger

from .span_location_template import SpanLocationTemplate
from .template import BASE_URL, SPAN_BASED

logger = get_logger("Studio SpanLocationTemplate")


class SpanCountTemplate(SpanLocationTemplate):
    """LF Template based on regex checks for the span in a sub-range of the document.

    Heuristic:
    "If [span_text] occurs [op] [frequency] times between [units] [start] to [end] of
    [span_text_field], return True"

    Note that [start] and [end] can be negative, in which case they are
    counted from the end of the field, similar to slices in python.
    """

    template_type = "span_count"
    abbreviation = "SC"
    description = "If the span occurs [>, =, etc.] [count] times in [lines, sentences, etc.] [start] to [end] (defaults: [0, max]), then label. Negative indexes work from the end of the field."
    menu_type = {
        "name": "Span Count Builder",
        "value": template_type,
        "category": [SPAN_BASED],
    }
    docs_link = BASE_URL + "span-count-builder-span-based-lfs"
