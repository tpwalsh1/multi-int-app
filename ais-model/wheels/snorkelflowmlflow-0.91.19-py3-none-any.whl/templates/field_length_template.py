import re
from typing import List

import pandas as pd
from pydantic import ValidationError, validator

from snorkelflow.utils.logging import get_logger
from templates.utils import TemplateSchema

from .template import BASE_URL, NUMERIC_BASED, Template, TemplateConfig

logger = get_logger("Studio")

OPERATORS = {
    "=": lambda x, y: x == y,
    "!=": lambda x, y: x != y,
    "<": lambda x, y: x < y,
    "<=": lambda x, y: x <= y,
    ">": lambda x, y: x > y,
    ">=": lambda x, y: x >= y,
}

UNITS = {
    "chars": None,
    "words": "\s+",
    "lines": "\n",
    "sentences": "[\.\?\!]\s+",
    "paragraphs": "\n\n+",
}


class FieldLengthTemplateSchema(TemplateSchema):
    """Field Length template

    Parameters
    ----------
    field : str
        Field
    operator : {"=", "!=", "<", "<=", ">", ">="}
        Operator
    unit : {"chars", "words", "lines", "sentences", "paragraphs"}
        Unit
    value : int
        Value
    """

    field: str
    unit: str
    operator: str
    value: int

    @validator("operator")
    def check_operator(cls, v: str) -> str:
        if v not in OPERATORS.keys():
            raise ValueError(
                f"Invalid operator {v}. Must be in {list(OPERATORS.keys())}"
            )
        return v

    @validator("unit")
    def check_unit(cls, v: str) -> str:
        if v not in UNITS.keys():
            raise ValueError(f"Invalid unit {v}. Must be in {list(UNITS.keys())}")
        return v


class FieldLengthTemplate(Template):

    """LF Template based on field length comparisons"""

    template_type = "field_length"
    abbreviation = "LEN"
    description = "If number of [lines, sentences, etc.] in [field] is [>, =, etc.] [count], then label."
    menu_type = {
        "name": "Field Length Builder",
        "value": template_type,
        "category": [NUMERIC_BASED],
    }
    docs_link = BASE_URL + "field-length-builder-pattern-based-lfs-numerical-lfs"
    template_schema = "FieldLengthTemplateSchema"

    def __init__(self, template_config: TemplateConfig) -> None:
        """LF Template based on field length comparisons.

        Heuristic:
        "If x[field] has [OPERATOR] [value] [unit], return True"
        """

        self._field = template_config["field"]
        unit_str = template_config["unit"]
        self._unit_separator = UNITS[unit_str]
        op_str = template_config["operator"]
        self._op = OPERATORS[op_str]
        self._value = template_config["value"]

        logger.debug(
            f"Building {self.template_type} template on field {self._field} with "
            f"operator {op_str}, unit {unit_str}, and value {self._value}."
        )

    @classmethod
    def name(
        cls,
        template_config: TemplateConfig,
        current_name: str,
        curr_lf_names: List[str],
    ) -> str:
        try:
            template_config = FieldLengthTemplateSchema(**template_config).dict()
        except ValidationError:
            return current_name
        start_name = "_".join(
            [
                template_config["field"],
                str(template_config["value"]),
                template_config["unit"],
            ]
        )

        return cls.get_final_name(start_name, curr_lf_names)

    @classmethod
    def full_info(cls, template_config: TemplateConfig) -> str:
        try:
            template_config = FieldLengthTemplateSchema(**template_config).dict()
        except ValidationError:
            return ""

        return " ".join(
            [
                template_config["field"],
                template_config["operator"],
                str(template_config["value"]),
                template_config["unit"],
            ]
        )

    def check(self, x: pd.Series) -> bool:
        field_value = str(x[self._field]).strip()
        length = (
            len(field_value)
            if self._unit_separator is None
            else len(re.split(self._unit_separator, field_value))
        )
        return self._op(length, self._value)
