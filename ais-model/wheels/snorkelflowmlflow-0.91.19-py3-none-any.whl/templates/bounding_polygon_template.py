import json
from typing import List, Tuple

import numpy as np
import pandas as pd
from matplotlib.path import Path
from pydantic import ValidationError, validator

from snorkelflow.utils.logging import get_logger
from templates.utils import TemplateSchema, normalize_numeric

from .template import BASE_URL, NUMERIC_BASED, Template, TemplateConfig

logger = get_logger("Studio BoundingPolygonTemplate")


class BoundingPolygonTemplateSchema(TemplateSchema):
    """Bounding Polygon template

    Parameters
    ----------
    field_1 : str
        Field 1
    field_2 : str
        Field 2
    coordinates : str
        List of coordinates in a json string. E.g., "[[0, 0], [4, 0], [4, 4]]"
    """

    coordinates: str
    field_1: str
    field_2: str

    @validator("coordinates")
    def check_operator(cls, coordinates: str) -> str:
        try:
            if len(json.loads(coordinates)) < 3:
                raise ValueError("Invalid coordinates {coordinates}")
        except json.JSONDecodeError:
            raise ValueError("Invalid coordinates {coordinates}")
        if type(json.loads(coordinates)) != list:
            raise ValueError("Invalid coordinates {coordinates}")
        return coordinates


class BoundingPolygonTemplate(Template):

    """LF Template based on geometric relations."""

    template_type = "bounding_polygon"
    abbreviation = "BDP"
    description = "If the point (field1, field2) is in the polygon created by tracing the specified coordinates in the provided order, or one of the vertices of the polygon, then label. At least 3 coordinates must be provided."
    menu_type = {
        "name": "Bounding Polygon Builder",
        "value": template_type,
        "category": [NUMERIC_BASED],
    }
    docs_link = BASE_URL + "bounding-polygon-builder-numerical-lfs"
    template_schema = "BoundingPolygonTemplateSchema"

    def __init__(self, template_config: TemplateConfig) -> None:
        """LF Template based on geometric relations.

        Heuristic:
        "If the point (x[field_1], x[field_2]) is in the polygon defined by the
        coordinates, or a vertex of the polygon, then return True
        """
        self._field_1 = template_config["field_1"]
        self._field_2 = template_config["field_2"]
        self._coordinates = template_config["coordinates"]

        self._coordinates = json.loads(self._coordinates)
        if len(self._coordinates) < 3:
            raise ValueError(
                "Unable to create polygon. At least 3 points must be provided."
            )
        self._polygon = Path(np.array(self._coordinates))

        logger.debug(
            f"Building {self.template_type} template on fields {self._field_1}, {self._field_2} with "
            f"coordinates {self._coordinates}."
        )

    def _point_in_polygon(self, point: Tuple[float, float]) -> bool:
        point_contained = self._polygon.contains_point(point)

        # Check if point is on the vertex of the polygon
        if not point_contained and list(point) in self._coordinates:
            return True

        return point_contained

    @classmethod
    def name(
        cls,
        template_config: TemplateConfig,
        current_name: str,
        curr_lf_names: List[str],
    ) -> str:
        try:
            template_config = BoundingPolygonTemplateSchema(**template_config).dict()
        except ValidationError:
            return current_name
        start_name = template_config["coordinates"]

        return cls.get_final_name(start_name, curr_lf_names)

    @classmethod
    def full_info(cls, template_config: TemplateConfig) -> str:
        try:
            template_config = BoundingPolygonTemplateSchema(**template_config).dict()
        except ValidationError:
            return ""

        return ", ".join(
            [
                template_config["field_1"],
                template_config["field_2"],
                template_config["coordinates"],
            ]
        )

    def check(self, x: pd.Series) -> bool:
        try:
            field_value_1 = x[self._field_1]
            field_value_1 = normalize_numeric(str(field_value_1))
            field_value_2 = x[self._field_2]
            field_value_2 = normalize_numeric(str(field_value_2))
        except ValueError:
            return False
        return self._point_in_polygon((field_value_1, field_value_2))
