from typing import Any, Dict, List, Optional

import pandas as pd
import re2
import regex
from pydantic import ValidationError, validator

from snorkelflow.extraction.span import SpanCols
from snorkelflow.utils.logging import get_logger
from templates.utils import (
    NO_HIGHLIGHT,
    HighlightedSpan,
    TemplateSchema,
    find_matching_spans,
    get_span_positions_for_field,
)

from .template import BASE_URL, PATTERN_BASED, TemplateConfig, TextTemplate

SPAN_MARKER = r"{{span}}"
SPAN_MARKER_SAFE = "__SPAN_MARKER__"

CASE_SENSITIVE_DEFAULT = False
DOT_MATCHES_DEFAULT = False
START_END_MATCH_DEFAULT = False
STRICT_LOCATION_MATCH_DEFAULT = True

logger = get_logger("Studio RegexTemplate")


class RegexTemplateSchema(TemplateSchema):
    """Regex template

    Parameters
    ----------
    field : str
        Field
    span_text_field : str, default SpanCols.SPAN_TEXT
        Span field
    regex_pattern : str
        Regex pattern
    case_sensitive : bool, default False
        Case sensitive or not
    dot_matches_newline : bool, default False
        If True, make a dot `.` match any character at all, including a newline
    start_end_match_line : bool, default False
        If True, the character `^` and `$` match at the beginning of the string and at the end of the string, respectively.
    strict_location_match : bool, default True
        Strict location match or not
    """

    regex_pattern: str
    field: str
    span_text_field: Optional[str] = SpanCols.SPAN_TEXT
    case_sensitive: Optional[bool] = CASE_SENSITIVE_DEFAULT
    dot_matches_newline: Optional[bool] = DOT_MATCHES_DEFAULT
    start_end_match_line: Optional[bool] = START_END_MATCH_DEFAULT
    strict_location_match: Optional[bool] = STRICT_LOCATION_MATCH_DEFAULT

    @validator("regex_pattern")
    def validate_regex(cls, v: str) -> str:
        try:
            regex.compile(v.replace(SPAN_MARKER, SPAN_MARKER_SAFE))
        except Exception:
            raise ValueError(f"Invalid regex pattern {v}")
        return v


class RegexTemplate(TextTemplate):
    """LF Template for text-based regex interfaces."""

    template_type = "regex"
    abbreviation = "RGX"
    description = (
        "If [field] contains the regular expression [regex] then label. "
        "The special marker '{{span}}' will be replaced with each span's text when searching for the regular expression. "
        "If '{{span}}' is used and 'strict location' is True, match only the specific span instead of any match on the span's text."
    )
    menu_type = {
        "name": "Regex Builder",
        "value": template_type,
        "category": [PATTERN_BASED],
    }
    docs_link = BASE_URL + "regex-builder-pattern-based-lfs"
    template_schema = "RegexTemplateSchema"

    def __init__(self, template_config: TemplateConfig) -> None:
        """Check a given field for the given regex, opt. filling in {{span}} markers"""

        self._field = template_config["field"]
        self._span_text_field = template_config.get("span_text_field")
        self._flags = 0  # The default value for flags
        # Use 'get' instead of indexing directly to maintain backwards compatibility
        if not template_config.get("case_sensitive", CASE_SENSITIVE_DEFAULT):
            self._flags = self._flags | regex.I
        if template_config.get("dot_matches_newline", DOT_MATCHES_DEFAULT):
            self._flags = self._flags | regex.S
        if template_config.get("start_end_match_line", START_END_MATCH_DEFAULT):
            self._flags = self._flags | regex.M
        self._regex_pattern = template_config["regex_pattern"].replace(
            SPAN_MARKER, SPAN_MARKER_SAFE
        )

        self._strict_location_match = template_config.get(
            "strict_location_match", STRICT_LOCATION_MATCH_DEFAULT
        )
        self._rx = regex.compile(
            rf"(?P<highlight>{self._regex_pattern})", flags=self._flags
        )

        logger.debug(
            f"Building {self.template_type} template with pattern '{self._regex_pattern}'"
        )

    def highlight(self, x: pd.Series, return_early: bool = False) -> HighlightedSpan:
        if not self._regex_pattern:
            return NO_HIGHLIGHT
        field_value = str(x[self._field])
        # Simplest case. No special span handling.
        if SPAN_MARKER_SAFE not in self._regex_pattern or not self._span_text_field:
            return find_matching_spans(
                self._rx, field_value, self._field, return_early=return_early
            )
        # For strict location match, substitute span text with span marker prior to regex search.)
        span_text = x[self._span_text_field]
        if self._strict_location_match:
            start, end = get_span_positions_for_field(x, self._field)
            span_marker_safe_text = (
                field_value[:start] + SPAN_MARKER_SAFE + field_value[end + 1 :]
            )
            matching_spans = find_matching_spans(
                self._rx, span_marker_safe_text, self._field, return_early=return_early
            )
            if not matching_spans:
                matching_spans = NO_HIGHLIGHT

            else:
                for field in matching_spans:
                    for i in range(len(matching_spans[field])):
                        matching_spans[field][i] = matching_spans[field][i]._replace(
                            char_end=matching_spans[field][i].char_end
                            + len(span_text)
                            - len(SPAN_MARKER_SAFE)
                        )
        else:
            # Our data points are spans and the SPAN_MARKER was used, so we need to
            # perform a substitution
            substituted_rx = self._regex_pattern.replace(
                SPAN_MARKER_SAFE, regex.escape(span_text)
            )

            substituted_rx = regex.compile(
                rf"(?P<highlight>{substituted_rx})", flags=self._flags
            )
            # Match the span's string if it occurs anywhere in the field
            matching_spans = find_matching_spans(
                substituted_rx, field_value, self._field, return_early=return_early
            )

        return matching_spans

    @classmethod
    def name(
        cls,
        template_config: TemplateConfig,
        current_name: str,
        curr_lf_names: List[str],
    ) -> str:
        try:
            template_config = RegexTemplateSchema(**template_config).dict()
        except ValidationError:
            return current_name
        start_name = re2.sub(r"[^\w]", "", template_config["regex_pattern"])

        return cls.get_final_name(start_name, curr_lf_names)

    @classmethod
    def full_info(cls, template_config: TemplateConfig) -> str:
        try:
            template_config = RegexTemplateSchema(**template_config).dict()
        except ValidationError:
            return ""

        return re2.sub(r"[^\w]", "", template_config["regex_pattern"])

    @property
    def input_schema(self) -> Dict[str, Any]:
        schema: Dict[str, Any] = {}
        if not self._regex_pattern:
            return schema

        schema[self._field] = Any

        if SPAN_MARKER_SAFE not in self._regex_pattern or not self._span_text_field:
            return schema

        schema[self._span_text_field] = Any

        if self._strict_location_match:
            schema[SpanCols.CHAR_START] = Any
            schema[SpanCols.CHAR_END] = Any

            if self._field.startswith(SpanCols.SPAN_PREVIEW):
                suffix = self._field[len(SpanCols.SPAN_PREVIEW) :]
                schema[SpanCols.SPAN_PREVIEW_OFFSET + suffix] = Any

        return schema
