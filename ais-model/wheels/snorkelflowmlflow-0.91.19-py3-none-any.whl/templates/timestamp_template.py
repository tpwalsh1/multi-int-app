import calendar
import datetime
from typing import Any, Dict, Optional

import pandas as pd
from pydantic import root_validator, validator

from snorkelflow.utils.logging import get_logger

from .template import BASE_URL, TIMESERIES_BASED, Template, TemplateConfig
from .utils import TemplateSchema

logger = get_logger("Studio TimestampTemplate")

_DAY_OF_WEEK = {
    day.upper(): index + 1 for index, day in enumerate(calendar.day_name) if day
}

_MONTH_OF_YEAR = {
    month.upper(): index for index, month in enumerate(calendar.month_name) if month
}


class _TIMESCALES:
    TIME = "TIME"
    DAY = "DAY"
    MONTH = "MONTH"
    YEAR = "YEAR"


class TimestampTemplateSchema(TemplateSchema):
    """Timestamp template

    Parameters
    ----------
    field : str
        Field
    start_time : str
        Start time
    end_time : str
        End time
    start_dow : str
        Start day of week
    end_dow : str
        End day of week
    start_dom : int
        Start day of month
    end_dom : int
        End day of month
    start_month : str
        Start month
    end_month : str
        End month
    start_year : str
        Start year
    end_year : str
        End year
    """

    field: str
    start_time: str
    end_time: str
    start_dow: str
    end_dow: str
    start_dom: int
    end_dom: int
    start_month: str
    end_month: str
    start_year: str
    end_year: str

    @validator("start_time")
    def check_start_time(cls, start_time: str) -> str:
        datetime.datetime.strptime(start_time, "%H:%M:%S")  # may throw ValueError
        return start_time

    @validator("end_time")
    def check_end_time(cls, end_time: str) -> str:
        datetime.datetime.strptime(end_time, "%H:%M:%S")  # may throw ValueError
        return end_time

    @validator("start_dow")
    def check_start_dow(cls, start_dow: str) -> str:
        if start_dow.upper() not in _DAY_OF_WEEK:
            raise ValueError("Invalid start day {start_dow}")
        return start_dow

    @validator("end_dow")
    def check_end_dow(cls, end_dow: str) -> str:
        if end_dow.upper() not in _DAY_OF_WEEK:
            raise ValueError("Invalid end day of week {end_dow}")
        return end_dow

    @validator("start_dom")
    def check_start_dom(cls, start_dom: int) -> int:
        if start_dom > 31 or start_dom < 1:
            raise ValueError("Invalid start day of month {start_dom}")
        return start_dom

    @validator("end_dom")
    def check_end_dom(cls, end_dom: int) -> int:
        if end_dom > 31 or end_dom < 1:
            raise ValueError("Invalid end day of month {end_dom}")
        return end_dom

    @validator("start_month")
    def check_start_month(cls, start_month: str) -> str:
        if start_month.upper() not in _MONTH_OF_YEAR:
            raise ValueError("Invalid start month {start_month}")
        return start_month

    @validator("end_month")
    def check_end_month(cls, end_month: str) -> str:
        if end_month.upper() not in _MONTH_OF_YEAR:
            raise ValueError("Invalid end month {end_month}")
        return end_month

    @root_validator
    def check_years(cls, values: Dict[str, Any]) -> Dict[str, Any]:
        try:
            cur_start_year = int(values["start_year"]) if values["start_year"] else None
        except ValueError:
            raise ValueError("The start year must be an integer.")

        try:
            cur_end_year = int(values["end_year"]) if values["end_year"] else None
        except ValueError:
            raise ValueError("The end year must be an integer.")

        if (
            cur_start_year is not None
            and cur_end_year is not None
            and cur_end_year < cur_start_year
        ):
            raise ValueError(
                "End year {cur_end_year} must be larger than or equal to start year {cur_start_year}"
            )
        return values


class TimestampTemplate(Template):

    """LF Template based on timestamp comparisons"""

    template_type = "timestamp"
    abbreviation = "TME"
    description = "Votes if the timestamp provided meets the criteria described."
    menu_type = {
        "name": "Timestamp Builder",
        "value": template_type,
        "category": [TIMESERIES_BASED],
    }
    docs_link = BASE_URL + "timestamp-builder-time-series-lfs"
    template_schema = "TimestampTemplateSchema"

    def __init__(self, template_config: TemplateConfig) -> None:
        """LF Template based on numeric comparisons.

        Heuristic:
        "If timestamp falls within all the periodic ranges specified,
        return True"
        """

        self._field = template_config["field"]

        self._start_time, self._end_time = map(
            self._parse_time_of_day,
            (template_config["start_time"], template_config["end_time"]),
        )
        self._start_dow, self._end_dow = map(
            self._parse_day_of_week,
            (template_config["start_dow"], template_config["end_dow"]),
        )
        self._start_dom, self._end_dom = map(
            self._parse_day_of_month,
            (template_config["start_dom"], template_config["end_dom"]),
        )
        self._start_month, self._end_month = map(
            self._parse_month_of_year,
            (template_config["start_month"], template_config["end_month"]),
        )
        self._start_year, self._end_year = map(
            self._parse_year,
            (template_config["start_year"], template_config["end_year"]),
        )

        logger.debug(f"Building {self.template_type} template on field {self._field}.")

    def _parse_time_of_day(self, tod: str) -> int:
        """Parses the time of day from a string into the number
        of seconds elapsed since the start of the day.

        Parameters
        ----------
        tod
            The time of day as a HH:MM:SS string.

        Returns
        -------
        int
            Number of seconds elapsed since the start of the day.
        """
        res = datetime.datetime.strptime(tod, "%H:%M:%S")
        return int((res - res.replace(hour=0, minute=0, second=0)).total_seconds())

    def _parse_day_of_week(self, dow: str) -> int:
        return _DAY_OF_WEEK[dow.upper()]

    def _parse_day_of_month(self, dom: int) -> int:
        # Just an identity function
        return dom

    def _parse_month_of_year(self, moy: str) -> int:
        return _MONTH_OF_YEAR[moy.upper()]

    def _parse_year(self, y: str) -> Optional[int]:
        try:
            return int(y)
        except ValueError:
            return None

    def _in_circular_range(
        self, val: int, start: Optional[int], end: Optional[int]
    ) -> bool:
        """Checks if a value is within the circular range specified.

        Parameters
        ----------
        val
            The value to check.
        start
            The start of the range.
        end
            The end of the range.

        Returns
        -------
        bool
            True if val is within the circular range, False otherwise.
        """
        # Handle edge cases explicitly for clarity
        if start is None and end is None:
            return True
        elif start is None:
            assert isinstance(end, int)  # for mypy
            return val <= end
        elif end is None:
            assert isinstance(start, int)  # for mypy
            return val >= start

        return (
            start <= val and val <= end if start <= end else val <= end or start <= val
        )

    def check_time_within(self, target_str: str) -> bool:
        """Check whether the target time falls in the specified periodic range.

        Parameters
        ----------
        target_str
            The timestamp to check as a string.

        Returns
        -------
        bool
            Whether the timestmap falls in the specified time range.
        """
        target = pd.Timestamp(target_str)
        target_dt = target.to_pydatetime()

        # The following format of successive ands is efficient as short circuit
        # logic will prevent function calls from executing unnecessarily.
        # TODO: order these by increasing expected selectivity to further optimize.
        return (
            self._in_circular_range(
                int(
                    (
                        target_dt - target_dt.replace(hour=0, minute=0, second=0)
                    ).total_seconds()
                ),
                self._start_time,
                self._end_time,
            )
            and self._in_circular_range(
                target.weekday() + 1, self._start_dow, self._end_dow
            )
            and self._in_circular_range(target.day, self._start_dom, self._end_dom)
            and self._in_circular_range(
                target.month, self._start_month, self._end_month
            )
            and self._in_circular_range(target.year, self._start_year, self._end_year)
        )

    def check(self, x: pd.Series) -> bool:
        return self.check_time_within(x[self._field])
