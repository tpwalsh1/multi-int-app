from typing import List

import pandas as pd
from pydantic import ValidationError

from snorkelflow.extraction.span import SpanCols
from snorkelflow.utils.logging import get_logger
from templates.utils import TemplateSchema

from .template import BASE_URL, SPAN_BASED, Template, TemplateConfig

logger = get_logger("Studio SpanICD10Template")

LABELS = "labels"


class SpanICD10TemplateSchema(TemplateSchema):
    icd10_codes: List[str]


class SpanICD10Template(Template):
    """LF Template based on span content & ICD10 code."""

    template_type = "span_icd10"
    abbreviation = "SICD"
    description = "If the span is in the ICD10 list codes, then label."
    menu_type = {
        "name": "Span ICD10 Builder",
        "value": template_type,
        "category": [SPAN_BASED],
    }
    docs_link = BASE_URL + "span-icd10-builder-span-based-lfs"
    template_schema = "SpanICD10TemplateSchema"

    def __init__(self, template_config: TemplateConfig) -> None:
        """LF Template based on content of span.

        Heuristic:
        "If SPAN is in ICD content related to [value], return True"
        """

        import itertools
        import json
        import os

        cur_path = os.path.dirname(__file__)
        with open(os.path.join(cur_path, "resources/icd10_codes.json"), "r") as f:
            self.FULL_ICD_CODES = json.load(f)

        self._span_field = SpanCols.SPAN_TEXT
        self._icd_codes = template_config["icd10_codes"]
        self._icd_names: List = list(
            itertools.chain(
                *[
                    self.FULL_ICD_CODES.get(icd_code.upper(), {}).get(LABELS, [])
                    for icd_code in self._icd_codes
                ]
            )
        )
        self._icd_names = [item.lower() for item in self._icd_names]

        logger.debug(
            f"Building {self.template_type} template with icd_codes {self._icd_codes}"
        )

    def check(self, x: pd.Series) -> bool:
        span = x[self._span_field].lower()
        for icd_name in self._icd_names:
            if span in icd_name:
                return True
        return False

    @classmethod
    def name(
        cls,
        template_config: TemplateConfig,
        current_name: str,
        curr_lf_names: List[str],
    ) -> str:
        try:
            template_config = SpanICD10TemplateSchema(**template_config).dict()
        except ValidationError:
            return current_name
        start_name = "-".join(template_config["icd10_codes"])[:8]

        return cls.get_final_name(start_name, curr_lf_names)
