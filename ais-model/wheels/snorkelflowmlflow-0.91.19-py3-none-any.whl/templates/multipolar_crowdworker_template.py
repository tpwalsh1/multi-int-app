from typing import Any, Dict, List, Optional

import pandas as pd
from pydantic import ValidationError, validator

from file_utils.core import maybe_load_json
from snorkelflow.types.load import TEMP_UID_COL
from snorkelflow.utils.logging import get_logger
from templates.utils import (
    TemplateSchema,
    load_df_from_csv_file,
    load_headers_from_file,
)

from .template import BASE_URL, EXTERNAL_RESOURCES, Template, TemplateConfig

logger = get_logger("Studio MultipolarCrowdWorkerTemplate")


class MultipolarCrowdWorkerTemplateSchema(TemplateSchema):
    """Multipolar Crowd Worker template

    Parameters
    ----------
    filepath : str
        Path to a file
    uid_col : str
        UID column
    label_col : str
        Label column
    """

    filepath: str
    uid_col: str
    label_col: str

    @staticmethod
    def artifact_config_keys() -> List[str]:
        return ["filepath"]

    @validator("filepath")
    def validate_filepath(cls, v: str) -> str:
        # Attempt to load a single row
        try:
            load_df_from_csv_file(v, n_rows=1)
        except Exception as e:
            raise ValueError(f"Could not read {v}: {e}")
        return v

    @validator("uid_col", "label_col")
    def validate_cols(cls, v: str, values: Dict[str, Any], **kwargs: Any) -> str:
        if "filepath" not in values:
            return v
        filepath = values["filepath"]
        columns = load_headers_from_file(filepath)
        if v in columns:
            return v
        else:
            raise ValueError(f"Could not find column {v} in given file.")


class MultipolarCrowdWorkerTemplate(Template):
    """LF Template for labels from a single crowdworker."""

    template_type = "multipolar_crowdworker"
    abbreviation = "MPC"
    description = "Labels examples according to UID and labels defined at [filepath]. Filepath must be in a S3 bucket, MinIO, or the shared Snorkel Flow mount_directory."
    menu_type = {
        "name": "Multipolar Crowdworker Builder",
        "value": template_type,
        "category": [EXTERNAL_RESOURCES],
    }
    docs_link = BASE_URL
    template_schema = "MultipolarCrowdWorkerTemplateSchema"

    def __init__(self, template_config: TemplateConfig) -> None:
        filepath = template_config["filepath"]
        self._uid_col = template_config["uid_col"]
        self._label_col = template_config["label_col"]
        logger.info(
            f"Reading crowdworker labels from file at {filepath}, with label column {self._label_col} and uid column {self._uid_col}"
        )
        logger.debug(
            f"Building {self.template_type} template from filepath {filepath}."
        )
        cw_labels_df = load_df_from_csv_file(filepath)
        cw_labels_df[self._label_col] = cw_labels_df[self._label_col].apply(
            maybe_load_json
        )
        self.labels_dict = dict(
            zip(cw_labels_df[self._uid_col], cw_labels_df[self._label_col])
        )

    @classmethod
    def name(
        cls,
        template_config: TemplateConfig,
        current_name: str,
        curr_lf_names: List[str],
    ) -> str:
        try:
            template_config = MultipolarCrowdWorkerTemplateSchema(
                **template_config
            ).dict()
        except ValidationError:
            return current_name
        start_name = template_config["filepath"]

        return cls.get_final_name(start_name, curr_lf_names)

    @classmethod
    def full_info(cls, template_config: TemplateConfig) -> str:
        try:
            template_config = MultipolarCrowdWorkerTemplateSchema(
                **template_config
            ).dict()
        except ValidationError:
            return ""

        return template_config["filepath"]

    def check(self, x: pd.Series) -> Optional[str]:
        if TEMP_UID_COL in x and x[TEMP_UID_COL] in self.labels_dict:
            return self.labels_dict[x[TEMP_UID_COL]]
        elif str(x.name) in self.labels_dict:
            return self.labels_dict[x.name]
        else:
            # abstain from voting
            # since this LF template is label space agnostic, return None and handle later
            return None
