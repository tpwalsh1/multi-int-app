from typing import Any

from templates.code_template_v2_base import CodeTemplateV2Base
from templates.template import SequenceTemplate, TemplateConfig


class SequenceCodeTemplate(CodeTemplateV2Base, SequenceTemplate):
    """LF Builder for arbitrary serialized sequence code LFs

    Deserializes a serialized_lf back into a valid LabelingFunction.
    """

    template_type = "sequence_code"
    abbreviation = "SCOD"
    description = "Label according to the conditions of the code this LF is based on. When composing a code LF, the condition of the code (whether the LF votes or abstains) is used in determining the overall result of the composed LF."
    menu_type = {
        "name": "Sequence Code Template",
        "value": template_type,
        "category": [],
    }

    def __init__(self, template_config: TemplateConfig) -> None:
        super().__init__(template_config)

    def _validate_output_label_type(self, label: Any) -> None:
        if not isinstance(label, list):
            raise TypeError(
                f"Expected LF output of type List[Tuple[int, int]], got {type(label)} instead."
            )
