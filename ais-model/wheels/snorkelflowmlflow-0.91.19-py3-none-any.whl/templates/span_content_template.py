from typing import Any, Dict, List

import pandas as pd
from pydantic import ValidationError

from snorkelflow.extraction.span import SpanCols
from snorkelflow.utils.logging import get_logger
from templates.utils import (
    CASE_SENSITIVE_DEFAULT,
    HighlightedSpan,
    PatternMatchTemplateSchema,
    SpanPatternMatchOperator,
    compile_regex_for_span_builders,
    find_matching_spans,
)

from .template import BASE_URL, SPAN_BASED, TemplateConfig, TextTemplate

logger = get_logger("Studio SpanContentTemplate")

TOKENIZE_DEFAULT = False


class SpanContentTemplateSchema(PatternMatchTemplateSchema):
    """Span Content template

    Parameters
    ----------
    span_text_field : str
        Span field
    span_field : str
        Field from which spans are extracted
    operator : {"MATCHES", "CONTAINS", "STARTS", "ENDS"}
        Operator
    value : str
        Pattern
    regex : bool, default False
        If True, the pattern is treated as a regex
    case_sensitive : bool, default False
        Case sensitive or not
    tokenize : bool, default False
        Tokenize or not
    """

    span_text_field: str
    span_field: str
    operator: SpanPatternMatchOperator


class SpanContentTemplate(TextTemplate):

    """LF Template based on span content."""

    template_type = "span_content"
    abbreviation = "SCN"
    description = (
        "If the span [contains, starts with, etc.] the [keyword/phrase], then label."
    )
    menu_type = {
        "name": "Span Content Builder",
        "value": template_type,
        "category": [SPAN_BASED],
    }
    docs_link = BASE_URL + "span-content-builder-span-based-lfs"
    template_schema = "SpanContentTemplateSchema"

    def __init__(self, template_config: TemplateConfig) -> None:
        """LF Template based on content of span.

        Heuristic:
        "If SPAN [OPERATOR] [value], return True"
        """

        # Use 'get' instead of indexing directly to maintain backwards compatibility
        self._case_sensitive = template_config.get(
            "case_sensitive", CASE_SENSITIVE_DEFAULT
        )
        self._operator = SpanPatternMatchOperator(template_config["operator"]).name
        self._span_field = template_config["span_field"]

        self._value = template_config["value"]
        self._is_regex_value = template_config.get("regex", False)
        self._tokenize = template_config.get("tokenize", TOKENIZE_DEFAULT)
        # When in regex mode we will override the tokenizer settings
        if self._is_regex_value:
            self._tokenize = None
        self._span_text_field = template_config["span_text_field"]

        self._compiled_regex = compile_regex_for_span_builders(
            self._value,
            self._operator,
            self._is_regex_value,
            self._tokenize,
            self._case_sensitive,
        )

        logger.debug(
            f"Building {self.template_type} template with operator {self._operator} and value {self._value} and regex {self._is_regex_value}"
        )

    def highlight(self, x: pd.Series, return_early: bool = False) -> HighlightedSpan:
        span = x[self._span_text_field]
        return find_matching_spans(
            self._compiled_regex,
            span,
            self._span_field,
            char_offset=x[SpanCols.CHAR_START],
            return_early=return_early,
        )

    @classmethod
    def name(
        cls,
        template_config: TemplateConfig,
        current_name: str,
        curr_lf_names: List[str],
    ) -> str:
        try:
            template_config = SpanContentTemplateSchema(**template_config).dict()
        except ValidationError:
            return current_name
        start_name = template_config["value"][:8]

        return cls.get_final_name(start_name, curr_lf_names)

    @property
    def input_schema(self) -> Dict[str, Any]:
        return {self._span_text_field: Any, SpanCols.CHAR_START: Any}
