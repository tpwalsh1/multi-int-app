from typing import Any

import pandas as pd
from pydantic import validator

from snorkelflow.utils.logging import get_logger
from templates.constants import (
    TEMPLATE_COLUMN_FIELD_NAME,
    TEMPLATE_FIELD1_FIELD_NAME,
    TEMPLATE_FIELD2_FIELD_NAME,
    TEMPLATE_OPERATER1_FIELD_NAME,
    TEMPLATE_OPERATER2_FIELD_NAME,
    TEMPLATE_VALUE1_FIELD_NAME,
    TEMPLATE_VALUE2_FIELD_NAME,
)
from templates.utils import TemplateSchema

from .template import BASE_URL, TABLE_BASED, Template, TemplateConfig

logger = get_logger("Studio TableTwoAttribute")

OPERATORS = {
    "=": lambda x, y: x == y,
    "<": lambda x, y: x < y,
    "<=": lambda x, y: x <= y,
    ">": lambda x, y: x > y,
    ">=": lambda x, y: x >= y,
}


class TableTwoAttributeSchema(TemplateSchema):
    """Table Two Attribute template

    Parameters
    ----------
    column : str
        Column
    field_1 : str
        Field 1
    field_2 : str
        Field 2
    operator_1 : str
        Operator for field 1
    operator_2 : str
        Operator for field 2
    value_1 : str
        Value for field 1
    value_2 : str
        Value for field 2
    """

    column: str
    field_1: str
    field_2: str
    operator_1: str
    operator_2: str
    value_1: str
    value_2: str

    @validator(TEMPLATE_OPERATER1_FIELD_NAME, TEMPLATE_OPERATER1_FIELD_NAME)
    def check_operator(cls, op: str) -> str:
        if op not in OPERATORS.keys():
            raise ValueError("Invalid operator {op}")
        return op


class TableTwoAttribute(Template):

    """LF Template based on comparisons of an element's field value"""

    template_type = "table_two_attribute"
    abbreviation = "T2A"
    description = """
        If [column] has an element with [field_1] that is [>, =, etc.] [value_1] AND
        with [value_2] that is [>, =, etc.] [value] then label.
        """
    menu_type = {
        "name": "Table Two Attribute Builder",
        "value": template_type,
        "category": [TABLE_BASED],
    }
    docs_link = BASE_URL + "two-attribute-table-based-lfs"
    template_schema = "TableTwoAttributeSchema"

    def __init__(self, template_config: TemplateConfig) -> None:
        """LF Template based on comparisons of an element's field value

        Heuristic:
        "If x[column] has element[field_1] [operator_1] [field2] AND
        element[field_2] [operator_2] [field2] by [value][scale], return True"
        """

        self._column = template_config[TEMPLATE_COLUMN_FIELD_NAME]
        self._field_1 = template_config[TEMPLATE_FIELD1_FIELD_NAME]
        self._field_2 = template_config[TEMPLATE_FIELD2_FIELD_NAME]
        self._value_1 = template_config[TEMPLATE_VALUE1_FIELD_NAME]
        self._value_2 = template_config[TEMPLATE_VALUE2_FIELD_NAME]

        op_str1 = template_config[TEMPLATE_OPERATER1_FIELD_NAME]
        self._op_1 = OPERATORS[op_str1]
        op_str2 = template_config[TEMPLATE_OPERATER2_FIELD_NAME]
        self._op_2 = OPERATORS[op_str2]

        logger.debug(
            f"Building {self.template_type} template on column {self._column} elem fields {self._field_1}, {self._field_2} with "
            f"operators: {op_str1} & {op_str2}, and values: {self._value_1} & {self._value_2}."
        )

    def _comp_two_fields(self, act_val: Any, comp_value: Any, op: Any) -> bool:
        if act_val is None:
            return False
        if isinstance(act_val, str):
            return op(act_val, str(comp_value))
        elif isinstance(act_val, (float, int)):
            return op(act_val, float(comp_value))
        else:
            raise ValueError(f"Invalid type: {type(act_val)}")

    def check(self, x: pd.Series) -> bool:
        try:
            col_values = x[self._column]
            # Just need to make sure that at least 1 element matches the condition
            for val_dict in col_values:
                # No gurantees each element has those fields
                field_1 = val_dict.get(self._field_1)
                field_2 = val_dict.get(self._field_2)
                try:
                    if self._comp_two_fields(
                        field_1, self._value_1, self._op_1
                    ) and self._comp_two_fields(field_2, self._value_2, self._op_2):
                        return True
                # We continue verifying each element even if 1 element throws an error
                except ValueError:
                    continue

        except KeyError:
            return False
        return False
