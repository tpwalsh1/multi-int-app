import hashlib
from typing import Any, Dict, List, Optional

import pandas as pd
import regex
from pydantic import ValidationError, validator

from rich_doc_wrapper import (
    HORZ_LOCATIONS,
    SCOPES,
    VERT_LOCATIONS,
    Location,
    RichDocWrapper,
    Scope,
)
from snorkelflow.extraction.span import SpanCols
from snorkelflow.rich_docs import MissingRichDocException, RichDocCols
from snorkelflow.utils.logging import get_logger
from templates.utils import TemplateSchema

from .numeric_template import OPERATORS
from .template import CLASSIC_STUDIO_URL, OTHER, Template, TemplateConfig

logger = get_logger("Studio SpanRegexPositionTemplate")


HORZ_COMPARATOR_MAP = {
    "equal to": "=",
    "not equal to": "!=",
    "left of": "<",
    "left of or equal to": "<=",
    "right of": ">",
    "right of or equal to": ">=",
}

VERT_COMPARATOR_MAP = {
    "equal to": "=",
    "not equal to": "!=",
    "above": "<",
    "above or equal to": "<=",
    "below": ">",
    "below or equal to": ">=",
}

ENABLED_CONDITIONS = ["both", "first only", "second only"]


class SpanRegexPositionTemplateSchema(TemplateSchema):
    regex_pattern: str
    span_horz_location: Location
    span_vert_location: Location
    regex_horz_location: Location
    regex_vert_location: Location
    horz_operator: str
    vert_operator: str
    scope: Scope
    enabled_conds: str
    case_sensitive: Optional[bool] = False

    @validator("regex_pattern")
    def check_regex_pattern(cls, regex_pattern: str) -> str:
        try:
            regex.compile(regex_pattern)
        except Exception:
            raise ValueError(f"Invalid regex_pattern {regex_pattern}")
        return regex_pattern

    @validator("span_horz_location")
    def check_span_horz_location(cls, loc: str) -> str:
        if loc.lower() not in HORZ_LOCATIONS:
            raise ValueError(f"Invalid location {loc}")
        return loc

    @validator("span_vert_location")
    def check_span_vert_location(cls, loc: str) -> str:
        if loc.lower() not in VERT_LOCATIONS:
            raise ValueError(f"Invalid location {loc}")
        return loc

    @validator("regex_horz_location")
    def check_regex_horz_location(cls, loc: str) -> str:
        if loc.lower() not in HORZ_LOCATIONS:
            raise ValueError(f"Invalid location {loc}")
        return loc

    @validator("regex_vert_location")
    def check_regex_vert_location(cls, loc: str) -> str:
        if loc.lower() not in VERT_LOCATIONS:
            raise ValueError(f"Invalid location {loc}")
        return loc

    @validator("horz_operator")
    def check_horz_operator(cls, op: str) -> str:
        if op not in HORZ_COMPARATOR_MAP.keys():
            raise ValueError("Invalid operator {op}")
        return op

    @validator("vert_operator")
    def check_vert_operator(cls, op: str) -> str:
        if op not in VERT_COMPARATOR_MAP.keys():
            raise ValueError("Invalid operator {op}")
        return op

    @validator("scope")
    def check_scope(cls, scope: str) -> str:
        if scope.lower() not in SCOPES:
            raise ValueError(f"Invalid scope {scope}")
        return scope

    @validator("enabled_conds")
    def check_enabled_conds(cls, enabled_conds: str) -> str:
        if enabled_conds.lower() not in ENABLED_CONDITIONS:
            raise ValueError(f"Invalid condition {enabled_conds}")
        return enabled_conds


class SpanRegexPositionTemplate(Template):
    """LF Template based on regexes aligned with the span a/t RichDoc.

    Heuristic:
    "If SPAN is [location] aligned with [regex_pattern] in [scope] within [threshold]
    [threshold_units], return True"

    NOTE: Requires RichDoc column to function
    """

    template_type = "span_regex_position"
    abbreviation = "SRP"
    # TODO: update the description
    description = "If SPAN's [location] is >,<,= a [regex]'s [location] (optionally limited to scope [scope]), then label. CENTER is between LEFT/RIGHT, MIDDLE is between TOP/BOTTOM."
    menu_type = {
        "name": "Span Regex Position Builder",
        "value": template_type,
        "category": [OTHER],
    }
    docs_link = CLASSIC_STUDIO_URL + "span-regex-position-rich-doc-based-lfs"
    template_schema = "SpanRegexPositionTemplateSchema"

    def __init__(self, template_config: TemplateConfig) -> None:
        self._regex_pattern = template_config["regex_pattern"]
        self._span_horz_location = template_config["span_horz_location"].lower()
        self._span_vert_location = template_config["span_vert_location"].lower()
        self._regex_horz_location = template_config["regex_horz_location"].lower()
        self._regex_vert_location = template_config["regex_vert_location"].lower()
        horz_value_comp = HORZ_COMPARATOR_MAP[template_config["horz_operator"]]
        vert_value_comp = VERT_COMPARATOR_MAP[template_config["vert_operator"]]
        self._horz_op = OPERATORS[horz_value_comp]
        self._vert_op = OPERATORS[vert_value_comp]

        self._scope = template_config["scope"].lower()
        self._enabled_conds = template_config["enabled_conds"]
        self._case_sensitive = template_config["case_sensitive"]

        # Converting enabled conditions string to boolean values to horizontal/vertical operations
        if self._enabled_conds == "both":
            self._disable_horz = False
            self._disable_vert = False
        elif self._enabled_conds == "first only":
            self._disable_horz = False
            self._disable_vert = True
        else:
            self._disable_horz = True
            self._disable_vert = False

        regex_encoding = (self._regex_pattern + str(self._case_sensitive)).encode()
        self._ngrams_field = f"ngrams_{hashlib.md5(regex_encoding).hexdigest()[:10]}"

        logger.debug(
            f"Building {self.template_type} template with config {template_config}"
        )

    def preprocess_configs(self) -> List[Dict[str, Any]]:
        """List of operator configs to run before applying LF."""
        return [
            dict(
                op_type="RichDocRegexNGramDetector",
                op_config=dict(
                    regex=self._regex_pattern,
                    target_field=self._ngrams_field,
                    # Adding a case sensitive param here
                    case_sensitive=self._case_sensitive,
                ),
            )
        ]

    def check(self, x: pd.Series) -> bool:
        rd = x.get(RichDocCols.DOC_COL)
        if rd is None:
            raise MissingRichDocException(
                "Could not find RichDoc columns in DataFrame. "
                "Make sure that these columns have been added via task processors."
            )
        return RichDocWrapper(rd).is_regex_within_bounds(
            char_start=x[SpanCols.CHAR_START],
            char_end=x[SpanCols.CHAR_END],
            ngrams=x[self._ngrams_field],
            span_horz_location=self._span_horz_location,
            span_vert_location=self._span_vert_location,
            regex_horz_location=self._regex_horz_location,
            regex_vert_location=self._regex_vert_location,
            horz_op_func=self._horz_op,
            vert_op_func=self._vert_op,
            scope=self._scope,
            disable_horz=self._disable_horz,
            disable_vert=self._disable_vert,
        )

    @classmethod
    def name(
        cls,
        template_config: TemplateConfig,
        current_name: str,
        curr_lf_names: List[str],
    ) -> str:
        try:
            template_config = SpanRegexPositionTemplateSchema(**template_config).dict()
        except ValidationError:
            return current_name
        start_name = (
            str(template_config["regex_horz_location"])[:3]
            + "_"
            + template_config["regex_pattern"][:5]
        )

        return cls.get_final_name(start_name, curr_lf_names)
