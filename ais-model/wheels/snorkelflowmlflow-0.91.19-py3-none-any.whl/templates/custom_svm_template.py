import pickle
from typing import List

import numpy as np
import pandas as pd
from pydantic import ValidationError, validator
from sklearn.svm import LinearSVC

from file_utils.core import open_file, path_exists
from snorkelflow.utils import resolve_data_path
from snorkelflow.utils.logging import get_logger
from templates.utils import TemplateSchema

from .template import BASE_URL, CUSTOM_SVM_BASED, Template, TemplateConfig

logger = get_logger("Studio Custom SVM")


class CustomSVMTemplateSchema(TemplateSchema):
    model_path: str
    feature_field: str
    min_distance = 0.0
    model_name: str = ""

    @staticmethod
    def artifact_config_keys() -> List[str]:
        return ["model_path"]

    @validator("model_path")
    def check_exists(cls, model_path: str) -> str:
        if not path_exists(model_path):
            raise ValueError(f"Path {model_path} does not exist")
        return model_path


class CustomSVMTemplate(Template):
    # TODO: Name should be changed to a more generic name eventually
    template_type = "custom_svm"
    docs_link = BASE_URL + "custom-svm"

    abbreviation = "CSVM"
    description = "Classifies examples using output from a custom SVM Model. Must be generated using external mechanism"
    menu_type = {
        "name": "Custom SVM Builder",
        "value": template_type,
        "category": [CUSTOM_SVM_BASED],
    }
    template_schema = "CustomSVMTemplateSchema"

    def __init__(self, template_config: TemplateConfig) -> None:
        model_path = template_config["model_path"]
        if model_path.startswith("minio"):
            model_path = resolve_data_path(model_path)

        with open_file(model_path, "rb") as f:
            self.model: LinearSVC = pickle.load(f)
        self.min_distance = template_config["min_distance"]
        self.feature_field = template_config["feature_field"]
        self.model_name = template_config["model_name"]

    def check(self, x: pd.Series) -> bool:
        # TODO: if we can genericize the words "decision function" we can make it flexible beyond SVMs
        np_embedding = np.array(x[self.feature_field]).reshape(1, -1)
        distance = self.model.decision_function(np_embedding)

        if distance > self.min_distance:
            return True
        else:
            return False

    @classmethod
    def name(
        cls,
        template_config: TemplateConfig,
        current_name: str,
        curr_lf_names: List[str],
    ) -> str:
        try:
            template_config = CustomSVMTemplateSchema(**template_config).dict()
        except ValidationError:
            return current_name

        if template_config["model_name"]:
            start_name = template_config["model_name"]
        else:
            # Use start of the file name if no name available
            start_name = str(template_config["model_path"][:10])
        return cls.get_final_name(start_name, curr_lf_names)
