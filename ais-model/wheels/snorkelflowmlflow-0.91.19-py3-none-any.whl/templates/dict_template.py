from functools import partial
from typing import Any, Dict, List, Optional

import numpy as np
import pandas as pd
import regex
from pydantic import ValidationError, validator

from memory_utils.memory import get_process_memory
from regex_utils.selector import select_compiled_regex
from snorkelflow.utils.logging import get_logger
from templates.utils import (
    NO_HIGHLIGHT,
    HighlightedSpan,
    TemplateSchema,
    find_matching_spans,
    load_list_from_csv_file,
    tokenize_pattern,
    validate_load_list_from_csv_file,
)

from .template import BASE_URL, EXTERNAL_RESOURCES, Template, TemplateConfig


def _any_combiner(regex_pattern: Dict[str, Any], s: str) -> bool:
    return bool(regex_pattern["or"].search(s))


def _none_combiner(*args: Any) -> bool:
    return not _any_combiner(*args)


def _all_combiner(regex_pattern: Dict[str, Any], s: str) -> bool:
    hit = True
    i = 0
    pattern_num = len(regex_pattern["and"])
    while hit and (i < pattern_num):
        hit = regex_pattern["and"][i].search(s)
        i += 1

    return hit


COMBINERS = {"ANY": _any_combiner, "ALL": _all_combiner, "NONE": _none_combiner}

CASE_SENSITIVE_DEFAULT = False
TOKENIZE_DEFAULT = True

logger = get_logger("Studio DictTemplate")


class DictTemplateSchema(TemplateSchema):
    """Dictionary template

    Parameters
    ----------
    field : str
        Field
    combiner : {"ANY", "ALL", "NONE"}
        Combiner
    filepath : str
        Path to a file
    case_sensitive : bool, default False
        Case sensitive or not
    tokenize : bool, default True
        Tokenize or not
    remove_header : bool, default False
        If True, remove the first row
    class_index : int, default 0
        Index of the column containing keywords
    """

    combiner: str
    filepath: str
    field: str
    case_sensitive: Optional[bool] = CASE_SENSITIVE_DEFAULT
    tokenize: Optional[bool] = TOKENIZE_DEFAULT
    class_index: Optional[int] = 0
    remove_header: Optional[bool] = False

    @staticmethod
    def artifact_config_keys() -> List[str]:
        return ["filepath"]

    @validator("filepath")
    def validate_filepath(cls, v: str) -> str:
        msg = validate_load_list_from_csv_file(v)
        if msg is not True:
            raise ValueError(f"Could not read {v}: {msg}")
        return v

    @validator("combiner")
    def validate_combiner(cls, v: str) -> str:
        if v not in COMBINERS.keys():
            raise ValueError(f"Invalid combiner: {v}")
        return v


class DictTemplate(Template):

    """LF Template for dictionary template via external list of keywords."""

    template_type = "dictionary"
    abbreviation = "DIC"
    description = "If [field] contains any of the [keywords/phrases] in newline-delimited file at [filepath], then label. Filepath must be in a S3 bucket, MinIO, or the shared Snorkel Flow mount_directory."
    menu_type = {
        "name": "Dictionary Builder",
        "value": template_type,
        "category": [EXTERNAL_RESOURCES],
    }
    docs_link = BASE_URL + "dictionary-builder-external-resources-lfs"
    template_schema = "DictTemplateSchema"

    def __init__(self, template_config: TemplateConfig) -> None:
        self._combiner = template_config["combiner"]
        self._combiner_func = COMBINERS[self._combiner]

        self._field = template_config["field"]
        self._filepath = template_config["filepath"]
        self._class_index = template_config["class_index"]
        self._remove_header = template_config["remove_header"]
        self._case_sensitive = template_config.get(
            "case_sensitive", CASE_SENSITIVE_DEFAULT
        )
        self._tokenize = template_config.get("tokenize", TOKENIZE_DEFAULT)
        self._regex: Optional[Dict[str, Any]] = None

        logger.info(
            f"Initialized Dictionary template - filepath: {self._filepath}, {self._combiner_func}"
        )

    def _compile_regex(self, keywords: List[str]) -> Dict[str, Any]:
        flags = 0
        if not self._case_sensitive:
            flags = flags | regex.IGNORECASE

        keywords = [regex.escape(kw) for kw in keywords]
        s_or = r"|".join(keywords)
        s_or = rf"(?P<highlight>{s_or})"

        if self._tokenize:
            s_or = tokenize_pattern(s_or)
            keywords = list(map(tokenize_pattern, keywords))

        if self._combiner == "ALL":
            compiled_regex_and = list(
                map(partial(select_compiled_regex, flags=flags), keywords)
            )
            return {"and": compiled_regex_and}

        compiled_regex_or = select_compiled_regex(s_or, flags=flags)
        return {"or": compiled_regex_or}

    def _load_and_compile_keywords_regex(self) -> None:
        rss, vms = get_process_memory()
        logger.info(
            f"Loading and compiling keywords - {self._filepath}, {self._combiner_func}. (RSS): {rss/1000_000:2f} MB. (VMS): {vms/1000_000:2f} MB"
        )
        keywords = list(
            load_list_from_csv_file(
                self._filepath,
                column_idx=self._class_index,
                remove_header=self._remove_header,
            )
        )

        # Remove NaNs and convert to string
        keywords = [kw for kw in keywords if isinstance(kw, str) or not np.isnan(kw)]

        # Should make regex more efficient in cases where keywords present
        keywords = sorted(set(keywords), key=len)

        logger.info(
            f"Compiling Keywords - {len(keywords)}. (RSS): {rss/1000_000:2f} MB. (VMS): {vms/1000_000:2f} MB"
        )
        self._regex = self._compile_regex(keywords)
        logger.info(
            f"Successfully compiled regex - {len(keywords)}. (RSS): {rss/1000_000:2f} MB. (VMS): {vms/1000_000:2f} MB"
        )

    @classmethod
    def full_info(cls, template_config: TemplateConfig) -> str:
        try:
            template_config = DictTemplateSchema(**template_config).dict()
        except ValidationError:
            return ""

        return (
            f'contains {template_config["combiner"]} in {template_config["filepath"]}'
        )

    def check(self, x: pd.Series) -> bool:
        if self._regex is None:
            self._load_and_compile_keywords_regex()
        field_value = str(x[self._field])
        return self._combiner_func(self._regex, field_value)  # type: ignore

    @classmethod
    def name(
        cls,
        template_config: TemplateConfig,
        current_name: str,
        curr_lf_names: List[str],
    ) -> str:
        try:
            template_config = DictTemplateSchema(**template_config).dict()
        except ValidationError:
            return current_name
        start_name = "_".join(
            [template_config["combiner"], template_config["filepath"]]
        )

        return cls.get_final_name(start_name, curr_lf_names)

    def highlight(self, x: pd.Series, return_early: bool = False) -> HighlightedSpan:
        """Preprocesses the field value and returns the spans which should be
        highlighted as matches for this Template.
        """

        if self._combiner == "ALL":
            raise ValueError("Higlighting Dictionary LFs cannot have ALL combiner")

        if self._regex is None:
            self._load_and_compile_keywords_regex()

        if self._regex is None:
            return NO_HIGHLIGHT

        field_value = str(x[self._field])
        return find_matching_spans(
            self._regex["or"], field_value, self._field, return_early=return_early
        )
