from enum import Enum


class BuiltInTemplates(str, Enum):
    UtteranceContent = "utterance_content"
    UtteranceContext = "utterance_context"
    UtteranceLocation = "utterance_location"
    UtteranceSimilarity = "utterance_similarity"

    RichDocExpression = "rich_doc_expression"
    RichDocBoundingBox = "rich_doc_bounding_box"
    SpanRegexProximity = "span_regex_proximity"
    SpanRegexRow = "span_regex_row"
    SpanRegexPosition = "span_regex_position"

    FullTextRegex = "full_text"
    KeywordLocation = "keyword_location"
    KeywordContext = "keyword_context"
    Keyword = "keyword"
    Regex = "regex"

    SequenceRegex = "sequence_regex"

    BoundingPolygon = "bounding_polygon"
    BoundingRectangle = "bounding_rectangle"
    NumericComparator = "numerical_comparator"
    Numeric = "numeric"
    TwoAttributeNumeric = "numeric_2d"

    Timestamp = "timestamp"

    SQLQuery = "sql_query"

    ModelBased = "model_based"

    ImageTextComparator = "image_text_comparator"
    ImageImageComparator = "image_image_comparator"
