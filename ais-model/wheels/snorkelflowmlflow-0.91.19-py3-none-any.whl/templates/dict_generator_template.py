from snorkelflow.utils.logging import get_logger

from .template import BASE_URL, GENERATORS, Template

logger = get_logger("Studio DictGeneratorTemplate")


class DictGeneratorTemplate(Template):
    template_type = "dictionary_generator"
    abbreviation = "DICG"
    description = "If [field] contains any of the [keywords/phrases] in multicolumn CSV file at [filepath], then label class specified in file column header. Filepath must be in a S3 bucket, MinIO, or the shared Snorkel Flow mount_directory."
    menu_type = {
        "name": "Dictionary Generator",
        "value": template_type,
        "category": [GENERATORS],
    }
    docs_link = BASE_URL + "dictionary-generator-external-resources-lfs"
