from typing import Any, Dict, List

import pandas as pd
from pydantic import ValidationError, validator

from label_spaces.multi_label import MultiLabelSpace
from snorkelflow.types.model import ModelCols
from snorkelflow.utils.logging import get_logger
from templates.keyword_location_template import OPERATORS
from templates.utils import TemplateSchema

from .template import BASE_URL, IMAGE_BASED, LFCacheKeys, Template, TemplateConfig

logger = get_logger("Studio ImageModelBasedTemplate")


class ImageModelBasedTemplateSchema(TemplateSchema):
    """Model Based template

    Parameters
    ----------
    model_name : str
        Model name
    model_label : str
        Model label
    dirpath : str
        The path to the stored model in minio.
    label_map : Dict[str, int]
        The label map for the Node that this LF is being applied to
    operator : str
        Operator
    min_similarity : float, default 0
        Minimum similarity for model decision function.
    """

    model_name: str
    model_label: str
    dirpath: str
    label_map: Dict[str, int]
    operator: str = ">="
    min_similarity: float = 0

    @validator("operator")
    def check_operator(cls, op: str) -> str:
        if op not in OPERATORS.keys():
            raise ValueError(
                f"Invalid operator '{op}'. Must be in {list(OPERATORS.keys())}."
            )
        return op


# TODO(ENG-18923): Deprecate non-multipolar image LFs.
class ImageModelBasedTemplate(Template):
    """Template for image model based LFs"""

    template_type = "image_model_based"
    abbreviation = "IMB"
    description = "Image model based LFs."
    menu_type = {
        "name": "Image Model Based",
        "value": template_type,
        "category": [IMAGE_BASED],
    }

    docs_link = BASE_URL
    template_schema = "ImageModelBasedTemplateSchema"
    similarity_field_name = ModelCols.DECISION_FUNCTION

    def __init__(self, template_config: TemplateConfig) -> None:
        self.model_name = template_config["model_name"]
        self.model_label = template_config["model_label"]
        self.dirpath = template_config["dirpath"]
        self.label_map = template_config["label_map"].copy()
        self.operator = template_config["operator"]
        self.min_similarity = template_config["min_similarity"]
        self._op_fn = OPERATORS[self.operator]

    @classmethod
    def full_info(cls, template_config: TemplateConfig) -> str:
        try:
            template_config = ImageModelBasedTemplateSchema(**template_config).dict()
        except ValidationError:
            return ""

        return " ".join(map(str, template_config.values()))

    @classmethod
    def name(
        cls,
        template_config: TemplateConfig,
        current_name: str,
        curr_lf_names: List[str],
    ) -> str:
        try:
            template_config = ImageModelBasedTemplateSchema(**template_config).dict()
        except ValidationError:
            return current_name

        start_name = "_".join(
            [str(template_config["model_name"]), str(template_config["label"])]
        )

        return cls.get_final_name(start_name, curr_lf_names)

    def preprocess_configs(self) -> List[Dict[str, Any]]:
        """Batch retrieve cached results for efficiency. NOTE this runs for
        every LF."""
        return [
            dict(
                op_type="DecisionFunctionFeaturizer",
                op_config=dict(
                    model_name=self.model_name,
                    dirpath=self.dirpath,
                    label_map=self.label_map,
                    label_space_config=dict(cls_name="MultiLabelSpace"),
                    embedding_field="__image_embedding",
                ),
            )
        ]

    def check(self, x: pd.Series) -> bool:
        val = x[ModelCols.DECISION_FUNCTION]

        if not val:
            raise ValueError(
                f"No decision function values found for model {self.model_name}. "
                "Double check your template inputs are correct."
            )

        val = val[self.label_map[self.model_label]] if len(val) > 1 else val[0]
        return self._op_fn(val, self.min_similarity)

    def compute_lf_votes_single_column(self, df: pd.Series, label: Any) -> pd.Series:
        cmp = lambda x: self._op_fn(x, self.min_similarity)
        unk = MultiLabelSpace.get_raw_unknown_label()
        _lf = (
            lambda x: label
            if cmp(x[self.label_map[self.model_label]] if len(x) > 1 else x[0])
            else unk
        )

        lf_votes = df.apply(_lf)
        return lf_votes

    @property
    def cache_keys(self) -> Dict[str, str]:
        return {
            LFCacheKeys.PREPROCESSED_DF: f"{self.template_type}_{self.model_name}_{self.model_label}",
            LFCacheKeys.LF_VOTES: f"{self.template_type}_{self.model_name}_{self.model_label}_{self.dirpath}_{self.operator}_{self.min_similarity}",
        }
