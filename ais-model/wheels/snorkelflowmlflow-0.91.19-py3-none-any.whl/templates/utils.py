import collections
import copy
import itertools
import json
from collections import namedtuple
from enum import Enum
from typing import (
    Any,
    Callable,
    DefaultDict,
    Dict,
    List,
    Optional,
    Pattern,
    Tuple,
    Type,
    Union,
)

import fsspec
import pandas as pd
import regex
from pydantic import BaseModel, validator

from api_utils.config import get_env_var
from api_utils.exceptions import RequestTimeout
from snorkelflow.data_loaders import CSVDataLoader
from snorkelflow.extraction.span import SpanCols
from snorkelflow.serialization.code_asset import deserialize_asset, serialize_asset

CASE_SENSITIVE_DEFAULT = False
TOKENIZE_DEFAULT = False
REGEX_DEFAULT = False
BUILTIN_TEMPLATE_SCHEMA_CLS_MAPPING: Dict[str, Type["TemplateSchema"]] = {}
BUILTIN_TEMPLATE_SCHEMA_MAPPING: Dict = {}

# Escape hatch env var in case timeout is too low
# Remove this env var after this change is on every big text customer
REGEX_TIMEOUT_SEC = int(get_env_var("REGEX_TIMEOUT_SEC") or 60)


class TemplateSchema(BaseModel):
    def __init_subclass__(cls, is_abstract: bool = False, **kwargs: Any) -> None:
        """Define init subclass to register all subclasses in
        TEMPLATE_SCHEMA_CLS_MAPPING, a class with is_abstract attr will NOT be
        registered."""
        if is_abstract:
            return
        super(cls).__init_subclass__(**kwargs)  # type: ignore
        # only register built-in template schemas here
        if cls.__module__.startswith("templates"):
            BUILTIN_TEMPLATE_SCHEMA_CLS_MAPPING[cls.__name__] = cls

    @staticmethod
    def artifact_config_keys() -> List[str]:
        """The names of the fields in the template schema pydantic model that represent
        paths to files or directories that contain data which back the LF template.
        For example, paths to a dictionary on disk that's used within an LF."""
        return []

    @classmethod
    def from_json(cls, json_config: Dict[str, Any]) -> Type["TemplateSchema"]:
        expected_json_fields = [
            "field_types",
            "field_defaults",
            "validator_functions",
            "class_name",
        ]
        if any(key not in json_config for key in expected_json_fields):
            raise ValueError(
                f"Missing fields in json config of TemplateSchema. Expected {expected_json_fields}, but got {json_config.keys()}"
            )

        validators = {}
        for field_name, validator_func_str in json_config[
            "validator_functions"
        ].items():
            validator_func = deserialize_asset(validator_func_str)
            recreated_validator = validator(field_name, allow_reuse=True)(
                validator_func
            )
            validators[validator_func.__name__] = recreated_validator

        annotations = {}
        field_values = {}
        field_types = json_config["field_types"]
        field_defaults = json_config["field_defaults"]
        for field_name in field_types:
            annotations[field_name] = deserialize_asset(field_types[field_name])
            if field_name in field_defaults:
                field_values[field_name] = deserialize_asset(field_defaults[field_name])
            else:
                field_values[field_name] = ...
        cls_members = {"__annotations__": annotations}
        cls_members.update(validators)
        cls_members.update(field_values)
        template_schems_cls = type(
            json_config["class_name"], (TemplateSchema,), cls_members
        )
        if "doc_string" in json_config:
            template_schems_cls.__doc__ = json_config["doc_string"]
        return template_schems_cls

    @classmethod
    def to_json(cls) -> Dict[str, Any]:
        field_types = {}
        field_defaults = {}
        for name, field in cls.__fields__.items():
            field_types[name] = serialize_asset(field.type_)
            if not field.required:
                field_defaults[name] = serialize_asset(field.default)

        validators_json = {}
        for field_name, field_validator in cls.__validators__.items():
            validator_func = field_validator[0].func  # type: ignore
            validators_json[field_name] = serialize_asset(validator_func)

        return {
            "class_name": cls.__name__,
            "doc_string": cls.__doc__,
            "field_types": field_types,
            "field_defaults": field_defaults,
            "validator_functions": validators_json,
        }

    def to_dict(self) -> Dict[str, Any]:
        config = dict(self)
        config["template_type"] = BUILTIN_TEMPLATE_SCHEMA_MAPPING[
            self.__class__.__name__
        ].template_type
        return config


def load_headers_from_file(filepath: str) -> List[str]:
    if filepath.startswith("s3://"):
        # Need to initializate the fsspec s3 filesystem if we are going to load s3
        # files.
        s3 = fsspec.get_filesystem_class("s3")()
        # Also invalidate the filepath, just in case someone is updating the file.
        s3.invalidate_cache(filepath)
    data_loader = CSVDataLoader.from_config(
        {
            "path": filepath,
            "reader_kwargs": dict(sample=False, blocksize=None, dtype=str),
        }
    )
    ddf = data_loader.load()
    return ddf.columns.tolist()


def load_df_from_csv_file(
    filepath: str, n_rows: Optional[int] = None, infer_headers: bool = True
) -> pd.DataFrame:
    if filepath.startswith("s3://"):
        # Need to initializate the fsspec s3 filesystem if we are going to load s3
        # files.
        s3 = fsspec.get_filesystem_class("s3")()
        # Also invalidate the filepath, just in case someone is updating the file.
        s3.invalidate_cache(filepath)
    data_loader = CSVDataLoader.from_config(
        {
            "path": filepath,
            "reader_kwargs": dict(
                sample=False,
                blocksize=None,
                dtype=str,
                header="infer" if infer_headers else None,
            ),
        }
    )
    ddf = data_loader.load()
    df = ddf.head(n=n_rows) if n_rows else ddf.compute()
    return df


def load_list_from_csv_file(
    filepath: str,
    n_rows: Optional[int] = None,
    column_idx: Optional[int] = 0,
    remove_header: Optional[bool] = False,
) -> List[str]:
    df = load_df_from_csv_file(filepath, n_rows, infer_headers=False)
    if remove_header:
        return df[df.columns[column_idx]][1:].tolist()
    else:
        return df[df.columns[column_idx]].tolist()


def validate_load_list_from_csv_file(filepath: str) -> Any:
    try:
        load_list_from_csv_file(filepath, n_rows=1)
        return True
    except Exception as e:
        if str(e).startswith("Error tokenizing data"):
            return pd.errors.ParserError(
                "Data may contain unquoted/malformed data which cannot be converted to lists."
            )
        else:
            return e


def normalize_numeric(value: str) -> float:
    return float(value.replace("$", "").replace(",", ""))


Span = namedtuple("Span", ["char_start", "char_end"])
"""Represents spans of text."""

HighlightedSpan = Dict[Optional[str], List[Span]]
"""Represents spans of text which should be highlighted,
where string represents a field name and a list of spans
will indicate spans of text which should be highlighted
in that field.
"""

TRUTHY_NO_HIGHLIGHT_SPAN: HighlightedSpan = {None: [Span(0, 0)]}
"""This is used to indicate a positive match for a template
that is incapable of highlighting. We need this so that when
we aggregate highlights and need to check for Truthyness in
each Template's highlight, i.e. if any Tempalte returns a
False value, the LF will not vote, and nothing should be
highlighted. This is only useful for graph/aggregation
highlighting.
"""

NO_HIGHLIGHT: HighlightedSpan = dict()
"""Falsy condition where nothing in a doc should be highlighted,
and represents Abstaining from voting.
"""


def merge_spans(highlighted_spans: HighlightedSpan) -> HighlightedSpan:
    """Merges HighlightedSpans so that we do not return any overlapping HighlightedSpans."""
    all_merged_spans = dict()
    for field in highlighted_spans:
        # Iterate of each field, merging that field's highlighted spans.
        if not highlighted_spans[field]:
            continue
        sorted_spans = sorted(
            highlighted_spans[field], key=lambda span: span.char_start
        )
        merged_spans = [sorted_spans[0]]
        for current_span in sorted_spans:
            if current_span.char_start > merged_spans[-1].char_end:
                merged_spans.append(current_span)
            elif merged_spans[-1].char_end < current_span.char_end:
                # Modifying tuple here.
                merged_spans[-1] = merged_spans[-1]._replace(
                    char_end=current_span.char_end
                )
            elif (
                current_span.char_start == merged_spans[-1].char_end
                or current_span.char_end == merged_spans[-1].char_start
            ):
                pass  # Allow boundaries to overlap.
        all_merged_spans[field] = merged_spans
    return all_merged_spans


def add_dicts(dicts: List[Dict]) -> Dict:
    """Add a list of dicts together by adding the values of any common keys together."""
    if not dicts:
        return dict()
    if len(dicts) == 1:
        return dicts[0]
    a = dicts[0]
    for b in dicts[1:]:
        combined_dict: DefaultDict[str, list] = collections.defaultdict(list)
        for key, val in itertools.chain(a.items(), b.items()):
            combined_dict[key] += val
        a = copy.deepcopy(combined_dict)
    return dict(combined_dict)


class RegexTimeoutError(RequestTimeout):
    pass


def find_matching_spans(
    compiled_pattern: Union[Pattern, regex.Pattern],
    text: str,
    field_name: str,
    char_offset: int = 0,
    return_early: bool = False,
    timeout_sec: int = REGEX_TIMEOUT_SEC,
) -> HighlightedSpan:
    """Finds regex matches, applies a char_offset if necessary,
    and returns as merged Spans. Looks for the "highlight" named group.
    """
    try:
        return _find_matching_spans(
            compiled_pattern, text, field_name, char_offset, return_early, timeout_sec
        )
    except TimeoutError as e:
        if str(e) == "regex timed out":
            if len(text) > 100:
                text = text[:100] + "..."

            # We throw an error that defaults to HTTP code 400, but callers can catch this specific error and re-cast the HTTP code if desired.
            raise RegexTimeoutError(
                user_friendly_message="Regex timed out",
                detail=f"Regex '{compiled_pattern.pattern}' failed to process text '{text}' within {timeout_sec} second(s)",
            )
        else:
            raise


def _find_matching_spans(
    compiled_pattern: Union[Pattern, regex.Pattern],
    text: str,
    field_name: str,
    char_offset: int,
    return_early: bool,
    timeout_sec: int,
) -> HighlightedSpan:
    kwargs = {}
    if isinstance(compiled_pattern, regex.Pattern):
        # These kwargs only work for regex, but not re or re2
        kwargs = dict(timeout=timeout_sec, concurrent=True)
    if return_early:
        if compiled_pattern.search(text, **kwargs):
            return TRUTHY_NO_HIGHLIGHT_SPAN
        return NO_HIGHLIGHT
    return merge_spans(
        {
            field_name: [
                Span(
                    match.span("highlight")[0] + char_offset,
                    match.span("highlight")[1] + char_offset,
                )
                for match in compiled_pattern.finditer(text, **kwargs)
                if "highlight" in match.groupdict()
            ]
        }
    )


def get_span_positions_for_field(row: pd.Series, field: str) -> Tuple[int, int]:
    """Get char start and char end for span within a field."""
    if not field.startswith(SpanCols.SPAN_PREVIEW):
        return (row[SpanCols.CHAR_START], row[SpanCols.CHAR_END])
    suffix = field[len(SpanCols.SPAN_PREVIEW) :]
    offset = row[SpanCols.SPAN_PREVIEW_OFFSET + suffix]
    return (row[SpanCols.CHAR_START] - offset, row[SpanCols.CHAR_END] - offset)


class SpanPatternMatchOperator(str, Enum):
    MATCHES = "MATCHES"
    CONTAINS = "CONTAINS"
    STARTS = "STARTS"
    ENDS = "ENDS"


class ContextOperator(str, Enum):
    """Indicates whether the span is to the "LEFT" or "RIGHT" or
    "LEFT OR RIGHT" of the value we are searching for.
    """

    LEFT = "LEFT"
    RIGHT = "RIGHT"
    LEFT_OR_RIGHT = "LEFT OR RIGHT"


class PatternMatchTemplateSchema(TemplateSchema):
    regex: Optional[bool] = False
    value: str
    case_sensitive: Optional[bool] = CASE_SENSITIVE_DEFAULT
    tokenize: Optional[bool] = TOKENIZE_DEFAULT

    @validator("value")
    def validate_regex(cls, v: str, values: Dict[str, Any]) -> str:
        if not values.get("regex"):
            return v
        try:
            regex.compile(v)
        except Exception:
            raise ValueError(f"Invalid regex pattern {v}")
        return v


def compile_regex_for_span_builders(
    value: str,
    operator: Optional[str] = None,
    is_regex_value: bool = False,
    tokenize: bool = False,
    case_sensitive: bool = False,
) -> regex.Pattern:
    """
    Compiles the value into a regex.
    """
    flags = 0
    regex_str = value if is_regex_value else regex.escape(value)
    regex_str = rf"(?P<highlight>{regex_str})"
    if operator:
        if operator == SpanPatternMatchOperator.STARTS:
            regex_str = rf"^{regex_str}"
        elif operator == SpanPatternMatchOperator.MATCHES:
            regex_str = rf"^{regex_str}$"
        elif operator == SpanPatternMatchOperator.ENDS:
            regex_str = rf"{regex_str}$"

    if tokenize:
        regex_str = tokenize_pattern(regex_str)
    if not case_sensitive:
        flags = flags | regex.IGNORECASE
    return regex.compile(regex_str, flags=flags)


def add_special_separator(value: str) -> str:
    return "~" + "~".join(value.split(" ")) + "~"


def tokenize_pattern(pattern: str) -> str:
    """
    This is what we consider a token when looking for a pattern.
    """
    return rf"\b{pattern}\b"


def is_json(value: Any) -> bool:
    try:
        json.loads(value)
    except:  # noqa: E722
        return False
    return True


MODEL_CACHE: Dict[str, Any] = {}


def is_running_in_actor() -> bool:
    try:
        import ray.runtime_context

        ray.runtime_context.get_runtime_context().current_actor
        return True
    except Exception:
        return False


def get_model_from_cache(cache_key: str, fn: Callable) -> Any:
    if is_running_in_actor():
        global MODEL_CACHE

        if cache_key not in MODEL_CACHE:
            MODEL_CACHE[cache_key] = fn()

        return MODEL_CACHE.get(cache_key)

    else:
        return fn()
