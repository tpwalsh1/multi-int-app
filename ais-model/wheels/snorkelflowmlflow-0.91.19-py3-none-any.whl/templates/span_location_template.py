import re
import sys
from typing import Any, Dict, Optional, Union

import pandas as pd
from pydantic import validator

from snorkelflow.utils.logging import get_logger
from templates.utils import TemplateSchema

from .template import BASE_URL, SPAN_BASED, Template, TemplateConfig

logger = get_logger("Studio SpanLocationTemplate")


OPERATORS = {
    "=": lambda x, y: x == y,
    "!=": lambda x, y: x != y,
    "<": lambda x, y: x < y,
    "<=": lambda x, y: x <= y,
    ">": lambda x, y: x > y,
    ">=": lambda x, y: x >= y,
}

# Map from unit to (regex for splitting, token for joining).
UNITS = {
    "chars": (None, ""),
    "words": ("\s+", " "),
    "lines": ("\n", "\n"),
    "sentences": ("[\.\?\!]\s+", ". "),
    "paragraphs": ("\n\n+", "\n\n"),
}


class SpanLocationTemplateSchema(TemplateSchema):
    """Span Location template

    Parameters
    ----------
    span_text_field : str
        Span field
    span_field : str
        Field from which spans are extracted from
    operator : {"=", "!=", "<", "<=", ">", ">="}, default ">="
        Operator
    frequency : int, default 1
        Number of occurencens
    unit : {"chars", "words", "lines", "sentences", "paragraphs"}, default "paragraphs"
        Unit
    start : int, default 0
        Start index
    end : int, default sys.maxsize
        End index
    case_sensitive : bool, default False
        Case sensitive or not
    """

    span_text_field: str
    span_field: str
    operator: Optional[str] = ">="
    frequency: Optional[int] = 1
    unit: Optional[str] = "paragraphs"
    start: Optional[int] = 0
    # An empty end field is interpreted as a str
    end: Optional[Union[str, int]] = sys.maxsize
    case_sensitive: Optional[bool] = False

    @validator("unit")
    def check_unit(cls, unit: str) -> str:
        if unit not in UNITS.keys():
            raise ValueError(f"Invalid unit {unit}. Must be in {list(UNITS.keys())}.")
        return unit

    @validator("operator")
    def check_operator(cls, op: str) -> str:
        if op not in OPERATORS.keys():
            raise ValueError(
                f"Invalid operator {op}. Must be in {list(OPERATORS.keys())}."
            )
        return op


class SpanLocationTemplate(Template):
    """LF Template based on regex checks for the span in a sub-range of the document.

    Heuristic:
    "If [span_text] occurs [op] [frequency] times between [units] [start] to [end] of
    [span_text_field], return True"

    Note that [start] and [end] can be negative, in which case they are
    counted from the end of the field, similar to slices in python.
    """

    template_type = "span_location"
    abbreviation = "SLC"
    description = "If the span occurs [>, =, etc.] [count] times in [lines, sentences, etc.] [start] to [end] (defaults: [0, max]), then label. Negative indexes work from the end of the field."
    menu_type = {
        "name": "Span Location Builder",
        "value": template_type,
        "category": [SPAN_BASED],
    }
    docs_link = BASE_URL + "span-location-builder-span-based-lfs"
    template_schema = "SpanLocationTemplateSchema"

    def __init__(self, template_config: TemplateConfig) -> None:
        self._span_text_field = template_config["span_text_field"]
        op_str = template_config["operator"]
        self._op_fn = OPERATORS[op_str]
        self._frequency = template_config["frequency"]
        self._start = template_config["start"]
        self._end = template_config["end"]
        # Set end back to max size if the field is left empty
        if type(self._end) == str:
            if self._end == "":
                self._end = sys.maxsize
            else:
                try:
                    self._end = int(self._end)
                except ValueError:
                    raise ValueError("End index must be an empty string or an integer.")
        unit_str = template_config["unit"]
        self._separator, self._joiner = UNITS[unit_str]
        self._case_sensitive = template_config["case_sensitive"]
        self._span_field = template_config["span_field"]
        logger.debug(
            f"Building {self.template_type} template with operator {op_str}, frequency "
            f"{self._frequency}, unit {unit_str}, and range {self._start}-{self._end} (case-sensitive = "
            f"{self._case_sensitive})."
        )

    def check(self, x: pd.Series) -> bool:
        field_value = str(x[self._span_field])
        span_text = x[self._span_text_field]

        if self._separator is None:
            unit_range = field_value[self._start : self._end]
        else:
            unit_range = self._joiner.join(
                re.split(self._separator, field_value)[self._start : self._end]
            )

        if not self._case_sensitive:
            span_text = span_text.lower()
            unit_range = unit_range.lower()

        return self._op_fn(unit_range.count(span_text), self._frequency)

    @property
    def input_schema(self) -> Dict[str, Any]:
        return {self._span_field: Any, self._span_text_field: Any}
