from abc import abstractmethod
from typing import Any, Dict, List, Optional, Tuple, Type, Union

import pandas as pd

from snorkelflow.types.performance import Performance
from templates.utils import BUILTIN_TEMPLATE_SCHEMA_MAPPING, HighlightedSpan, Span

TemplateConfig = Dict[str, Any]
BUILTIN_TEMPLATE_CLS_MAPPING: Dict[str, Type["Template"]] = {}
BASE_URL = "/user_guide/new_studio/reference/studio/label/lf_builders.html#"
CLASSIC_STUDIO_URL = "/user_guide/classic_studio/reference/label/lf_builders.html#"

# Keep this consistent with src/node/flow-ui/src/types.ts
DOCUMENT_BASED = "document_based"
SPAN_BASED = "span_based"
EXTERNAL_RESOURCES = "external_resources"
FOUNDATION_MODEL_BASED = "foundation_model_based"
NUMERIC_BASED = "numeric_based"
TABLE_BASED = "table_based"
RICH_DOC_BASED = "rich_doc_based"
PATTERN_BASED = "pattern_based"
SEQUENCE_PATTERN_BASED = "sequence_pattern_based"
SQL_BASED = "sql_based"
GENERATORS = "generators"
CONVERSATION_BASED = "conversation_based"
TIMESERIES_BASED = "timeseries_based"
NETWORK_BASED = "network_based"
CUSTOM_SVM_BASED = "custom_svm_based"
CUSTOM_SVM_SEQUENCE_BASED = "custom_svm_sequence_based"
EMBEDDING_NEAREST_NEIGHBOR_BASED = "embedding_nearest_neighbor_based"
RELATIONSHIP_BASED = "relationship_based"
IMAGE_BASED = "image_based"
OTHER = "other"
# Use the CUSTOM category only for custom LF templates added by SDK
# CUSTOM should not be used by any predefined LF templates
CUSTOM = "custom"


class Template:
    def __init_subclass__(cls, is_abstract: bool = False, **kwargs: Any) -> None:
        """Define init subclass to register all subclasses in
        BUILTIN_TEMPLATE_CLS_MAPPING, a class with is_abstract attr will NOT be
        registered."""
        if is_abstract:
            return
        super(cls).__init_subclass__(**kwargs)  # type: ignore
        # only register built-in templates here
        if cls.__module__.startswith("templates"):
            BUILTIN_TEMPLATE_CLS_MAPPING[cls.template_type] = cls  # type: ignore
            BUILTIN_TEMPLATE_SCHEMA_MAPPING[cls.template_schema] = cls

    @abstractmethod
    def __init__(self, template_config: TemplateConfig) -> None:
        raise NotImplementedError

    @classmethod
    def get_final_name(
        cls,
        start_name: str,
        curr_lf_names: List[str],
    ) -> str:
        """Takes a starting name and returns a new name in the format
        [ABBREVIATION]-[START_NAME]-[NUMBER] or [ABBREVIATION]-[NUMBER] in a way that prevents duplicate LF
        names from being produced"""
        base_name = str(cls.abbreviation) + ("-" + start_name if start_name else "")
        if base_name not in curr_lf_names:
            return base_name
        same_lf_suffixes = [
            x.replace(base_name + "-", "")
            for x in curr_lf_names
            if x.startswith(base_name + "-")
        ]
        current_numbers = [int(x) for x in same_lf_suffixes if x.isdigit()]
        if len(current_numbers) > 0:
            next_number = max(current_numbers) + 1
        else:
            next_number = 1
        return base_name + "-" + str(next_number)

    def estimate_perf(self, df: pd.DataFrame) -> Performance:
        raise NotImplementedError

    def compute_lf_votes_single_column(self, df: pd.Series, label: Any) -> pd.Series:
        raise NotImplementedError

    @classmethod
    def name(
        cls,
        template_config: TemplateConfig,
        current_name: str,
        curr_lf_names: List[str],
    ) -> str:
        # if not an empty string use current_name
        current_name = current_name if current_name.strip() else "lf"
        return cls.get_final_name(current_name, curr_lf_names)

    @classmethod
    def full_info(cls, template_config: TemplateConfig) -> str:
        return ""

    @abstractmethod
    def check(self, x: pd.Series) -> Any:
        """Method determining whether the LF votes or abstains on a datapoint"""
        raise NotImplementedError

    @property
    @abstractmethod
    def template_type(self) -> str:
        """LF type name"""
        raise NotImplementedError

    @property
    @abstractmethod
    def abbreviation(self) -> str:
        """Three letter abbreviation for the LF builder name"""
        raise NotImplementedError

    @property
    @abstractmethod
    def description(self) -> str:
        """Description of the LF to be displayed to the user"""
        raise NotImplementedError

    @property
    @abstractmethod
    def docs_link(self) -> str:
        """Link to the docs for the LF"""
        raise NotImplementedError

    @property
    @abstractmethod
    def menu_type(self) -> Dict[str, Union[List[str], str]]:
        """LF menu details"""
        raise NotImplementedError

    def preprocess_configs(self) -> List[Dict[str, Any]]:
        """List of operator configs to run before applying LF."""
        return []

    @property
    @abstractmethod
    def template_schema(self) -> str:
        """Returns the template schema used by the LF template"""
        raise NotImplementedError

    @property
    @abstractmethod
    def input_schema(self) -> Optional[Dict[str, Any]]:
        """Returns the input schema used by the LF template.
        This is required:
            * For query optimization
            * So that Arrow knows which columns to pull for the LF

        This should return either:
            * None (pull all columns)
            * A Dict[str, Any] where key is the column name and value is the type of the column
        """
        return None


class TextTemplate(Template, is_abstract=True):
    """This Template should be used for any text-based LF. The key difference
    is that it requires supporting a `highlight` method, which will aid users
    in visually verifying LFs. Instead of writing the Template's matching
    logic in `check`, it should be written in `highlight` and `check` will
    simply check if any highlights were found. Doc: https://bit.ly/3qkOqkz.

    is_abstract attribute is simply to prevent registration of TextTemplate in
    BUILTIN_TEMPLATE_CLS_MAPPING.
    """

    @abstractmethod
    def highlight(self, x: pd.Series, return_early: bool = False) -> HighlightedSpan:
        """Return a field pointing to a List of Spans, where each list's
        idx 0 = start, and idx 1 = end, where this Template's condition will match.
        """
        raise NotImplementedError

    def check(self, x: pd.Series) -> bool:
        """Determines whether the LF votes or abstains on a datapoint,
        based on if any `highlight` was found. We return early if any
        highlights are found.
        """
        return bool(self.highlight(x, return_early=True))


class SequenceTemplate(Template, is_abstract=True):
    """This Template should be used for any sequence tagging LF. It requires
    both `highlight` and `check` methods. The key difference is that the `check`
    method returns a list of the spans and the `highlight` method returns
    a HighlightedSpan object for the /highlight endpoint.

    is_abstract attribute is used as in TextTemplate above
    """

    def __init__(self, template_config: TemplateConfig) -> None:
        self._field = template_config["field"]

    def highlight(self, x: pd.Series) -> HighlightedSpan:
        """Return a field pointing to a List of Spans, where each list's
        idx 0 = start, and idx 1 = end, where this Template's condition will match.
        """
        return self._transform_from_list_to_HighlightedSpan(self.check(x))

    @abstractmethod
    def check(self, x: pd.Series) -> List[Tuple[int, int]]:
        """Return a list of the spans that should be highlighted"""
        raise NotImplementedError

    def _transform_from_list_to_HighlightedSpan(
        self, spans: List[Tuple[int, int]]
    ) -> HighlightedSpan:
        field_name = str(self._field)
        return {field_name: [Span(span[0], span[1]) for span in spans]}


class LFCacheKeys:
    PREPROCESSED_DF = "preprocessed_df"
    LF_VOTES = "lf_votes"
