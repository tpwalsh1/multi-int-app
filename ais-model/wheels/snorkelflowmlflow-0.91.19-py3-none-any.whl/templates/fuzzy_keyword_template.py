from difflib import SequenceMatcher
from typing import Any, Dict, List, Optional

import pandas as pd
from pydantic import ValidationError, validator

from snorkelflow.utils.logging import get_logger
from templates.utils import (
    NO_HIGHLIGHT,
    HighlightedSpan,
    Span,
    TemplateSchema,
    merge_spans,
)

from .template import BASE_URL, PATTERN_BASED, TemplateConfig, TextTemplate

logger = get_logger("Studio FuzzyKeywordTemplate")

CASE_SENSITIVE_DEFAULT = False


class FuzzyKeywordTemplateSchema(TemplateSchema):
    """Fuzzy Keyword template

    Parameters
    ----------
    field : str
        Field
    keywords : List[str]
        List of keywords
    min_similarity_ratio : float
        Minimum similarity ratio
    case_sensitive : bool, False
        Case sensitive or not
    """

    keywords: List[str]
    field: str
    min_similarity_ratio: float
    case_sensitive: Optional[bool] = CASE_SENSITIVE_DEFAULT

    @validator("min_similarity_ratio")
    def min_similarity_ratio_in_range(cls, v: float) -> float:
        if not ((v >= 0.0) and (v <= 100.0)):
            raise ValueError("Min similarity not in range [0,100]")
        return v


class FuzzyKeywordTemplate(TextTemplate):
    """LF Template based on a single keyword-based rule."""

    template_type = "fuzzy_keyword"
    abbreviation = "FZW"
    description = "If [field] matches the [keyword/phrase] with minimum similarity ratio of [threshold], then label."
    menu_type = {
        "name": "Fuzzy Keyword Builder",
        "value": template_type,
        "category": [PATTERN_BASED],
    }
    docs_link = BASE_URL + "fuzzy-keyword-builder-pattern-based-lfs"
    template_schema = "FuzzyKeywordTemplateSchema"

    def __init__(self, template_config: TemplateConfig) -> None:
        """Check if keyword is a substring of the field with fuzzy matching."""

        self._field = template_config["field"]
        self._keywords = set(template_config["keywords"])
        self._min_similarity_ratio = float(template_config["min_similarity_ratio"])

        # Use 'get' instead of indexing directly to maintain backwards compatibility
        self._case_sensitive = template_config.get(
            "case_sensitive", CASE_SENSITIVE_DEFAULT
        )
        if not self._case_sensitive:
            self._keywords = {kw.lower() for kw in self._keywords}

        logger.debug(
            f"Building {self.template_type} template with keywords {self._keywords} and min similarity ratio {self._min_similarity_ratio}."
        )

    def highlight(self, x: pd.Series, return_early: bool = False) -> HighlightedSpan:
        """`return_early` is only used here to preserve the sig of the parent's highlight type."""

        def partial_ratio_highlight(s1: str, s2: str) -> List[Span]:
            """Return the ratio of the most similar substring as a number between 0 and 100.

            This correctly handles long strings, unlike the original fuzzywuzzy implementation.
            Adapted from fuzzywuzzy: https://github.com/seatgeek/fuzzywuzzy
            Inspired by: https://stackoverflow.com/a/39760350
            """

            shorter, longer = (s1, s2) if len(s1) <= len(s2) else (s2, s1)
            m = SequenceMatcher(None, shorter, longer, autojunk=False)
            blocks = m.get_matching_blocks()

            # each block represents a sequence of matching characters in a string
            # of the form (idx_1, idx_2, len)
            # the best partial match will block align with at least one of those blocks
            #   e.g. shorter = "abcd", longer = XXXbcdeEEE
            #   block = (1,3,3)
            #   best score === ratio("abcd", "Xbcd")
            highlight_spans = []
            for _, long_start, _ in blocks:
                long_end = long_start + len(shorter)
                long_substr = longer[long_start:long_end]

                m2 = SequenceMatcher(None, shorter, long_substr, autojunk=False)
                r = m2.ratio()
                if r * 100 >= self._min_similarity_ratio:
                    highlight_spans.append(Span(long_start, long_end))
            return highlight_spans

        field_value = str(x[self._field])
        if not self._case_sensitive:
            field_value = field_value.lower()
        highlight_spans = []
        for kw in self._keywords:
            highlight_spans += partial_ratio_highlight(kw, field_value)
        matching_spans = merge_spans({self._field: highlight_spans})
        if matching_spans.get(self._field):
            return matching_spans
        return NO_HIGHLIGHT

    @classmethod
    def name(
        cls,
        template_config: TemplateConfig,
        current_name: str,
        curr_lf_names: List[str],
    ) -> str:
        try:
            template_config = FuzzyKeywordTemplateSchema(**template_config).dict()
        except ValidationError:
            return current_name
        start_name = "-".join(template_config["keywords"])
        start_name = "_".join(
            [start_name, str(template_config["min_similarity_ratio"])]
        )

        return cls.get_final_name(start_name, curr_lf_names)

    @classmethod
    def full_info(cls, template_config: TemplateConfig) -> str:
        try:
            template_config = FuzzyKeywordTemplateSchema(**template_config).dict()
        except ValidationError:
            return ""

        return f'{"-".join(template_config["keywords"])}, min. similarity {str(template_config["min_similarity_ratio"])}'

    @property
    def input_schema(self) -> Dict[str, Any]:
        return {self._field: Any}
