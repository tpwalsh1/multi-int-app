from pydantic import BaseModel

from snorkelflow.utils.logging import get_logger

from .template import BASE_URL, GENERATORS, Template

logger = get_logger("Studio IpAddressGeneratorTemplate")


class IpAddressGeneratorTemplateSchema(BaseModel):
    field: str


class IpAddressGeneratorTemplate(Template):
    template_type = "ip_address_generator"
    abbreviation = "IPAG"
    description = "IP address-based LF Generator."
    menu_type = {
        "name": "IP Address Generator",
        "value": template_type,
        "category": [GENERATORS],
    }
    docs_link = BASE_URL + "ip-address-generator-network-lfs"
