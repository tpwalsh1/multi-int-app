"""
Functionality for writing operators and LFs over Rich Document objects.
"""

import base64
import pickle
from typing import Any, Callable, Dict, List, Optional, Tuple, Union

import numpy as np
import pandas as pd
import regex

from snorkelflow.extraction.span import SPAN_TOKEN, SpanCols
from snorkelflow.rich_docs import (
    AREA_COLS,
    AREA_ID,
    BBOX_COLS,
    BOTTOM,
    FONT_SIZE,
    LEFT,
    LINE_COLS,
    LINE_ID,
    PAGE_COLS,
    PAGE_ID,
    PAR_COLS,
    PAR_ID,
    RIGHT,
    ROW_ID,
    TEXT,
    TOP,
    WORD_COLS,
    WORD_ID,
    RichDoc,
    Serializable,
)

CHAR_START = SpanCols.CHAR_START
CHAR_END = SpanCols.CHAR_END

Axis = str
HORZ = "horz"
VERT = "vert"
AXES = [HORZ, VERT]

Direction = str
BEFORE_ONLY = "before"
AFTER_ONLY = "after"
BEFORE_OR_AFTER = "before or after"
SEQ_DIRECTIONS = [BEFORE_ONLY, AFTER_ONLY, BEFORE_OR_AFTER]
UP_ONLY = "up_only"
DOWN_ONLY = "down_only"
UP_OR_DOWN = "up_or_down"
VERT_DIRECTIONS = [UP_ONLY, DOWN_ONLY, UP_OR_DOWN]
LEFT_ONLY = "left_only"
RIGHT_ONLY = "right_only"
LEFT_OR_RIGHT = "left_or_right"
HORZ_DIRECTIONS = [LEFT_ONLY, RIGHT_ONLY, LEFT_OR_RIGHT]
DIRECTIONS = SEQ_DIRECTIONS + VERT_DIRECTIONS + HORZ_DIRECTIONS
VERT_AND_HORIZONTAL_DIRECTIONS = VERT_DIRECTIONS + HORZ_DIRECTIONS

# Note: Horz. locations are used to compare vertically aligned spans, and vice versa
Location = str
CENTER = "center"
HORZ_LOCATIONS = [LEFT, CENTER, RIGHT]
MIDDLE = "middle"
VERT_LOCATIONS = [TOP, MIDDLE, BOTTOM]
LOCATIONS = VERT_LOCATIONS + HORZ_LOCATIONS

Threshold = Union[float, int]
ThresholdUnit = str
ThresholdDir = str
PIXELS = "pixels"
PAGE_PERCENT = "page_percent"
THRESHOLD_UNITS = [PIXELS, PAGE_PERCENT]

DEFAULT_THRESHOLD = 10
DEFAULT_VERT_ALIGNED_FEATURE_THRESHOLD = 50
DEFAULT_THRESHOLD_UNIT = PIXELS

Scope = str
PAGE = "page"
AREA = "area"
PAR = "par"
LINE = "line"
WORD = "word"
SCOPES = [WORD, LINE, PAR, AREA, PAGE]

NGRAM_SLIM_COLS = BBOX_COLS + [CHAR_START, CHAR_END, TEXT]

SCOPE_TO_ID = {PAGE: PAGE_ID, AREA: AREA_ID, PAR: PAR_ID, LINE: LINE_ID, WORD: WORD_ID}
SCOPE_TO_DF = {PAGE: "pages", AREA: "areas", PAR: "pars", LINE: "lines", WORD: "words"}

EMPTY_HEADER = "[EMPTY_HEADER]"
CASE_SENSITIVE_DEFAULT = False
PAGE_START_MARKER = "[PAGE_START]"
PAGE_END_MARKER = "[PAGE_END]"
TEXT_DELIMITER = " | "


# TODO: Rename rich_doc_inferred_row_headers to rich_doc_row_headers_inferred so it
# shows up next to rich_doc_row_header by default. We leave it for now for backwards
# compatibility with existing LFs
class RichDocSpanFeatures:
    """Class that specifies RichDoc features."""

    FONT_SIZE = "rich_doc_font_size"
    ROW_ID = "rich_doc_row_id"
    ROW_HEADER = "rich_doc_row_header"
    INFERRED_ROW_HEADERS = "rich_doc_inferred_row_headers"
    ALIGNED_NGRAMS = "rich_doc_aligned_ngrams"
    VERT_ALIGNED_NGRAMS = "rich_doc_vert_aligned_ngrams"
    HORZ_ALIGNED_NGRAMS = "rich_doc_horz_aligned_ngrams"
    PROXIMATE_TEXT = "rich_doc_proximate_text"
    PROXIMATE_TEXT_BEFORE = "rich_doc_proximate_text_before"
    PROXIMATE_TEXT_AFTER = "rich_doc_proximate_text_after"
    ROW_TEXT_BEFORE = "rich_doc_row_text_before"
    ROW_TEXT_AFTER = "rich_doc_row_text_after"
    ROW_TEXT_INLINE = "rich_doc_row_text_inline"


DEFAULT_RICH_DOC_SPAN_FEATURES_CONFIG = {
    RichDocSpanFeatures.FONT_SIZE: {},
    RichDocSpanFeatures.ROW_ID: {},
    RichDocSpanFeatures.ROW_HEADER: {
        "scope": PAGE,
        "multi_row": True,
        "min_margin": 10,
        "max_gap": 20,
        "max_left_page_pct": 50,
    },
    RichDocSpanFeatures.ROW_TEXT_BEFORE: {"lines": 1},
    RichDocSpanFeatures.ROW_TEXT_AFTER: {"lines": 1},
    RichDocSpanFeatures.ROW_TEXT_INLINE: {},
    # These feature classes are expensive and not recommended for typical use cases
    # (preferring row_text_[before/inline/after] instead), so we do not include them in
    # the default features config.
    # RichDocSpanFeatures.HORZ_ALIGNED_NGRAMS: {
    #     "scope": PAGE,
    #     "location": MIDDLE,
    #     "threshold": DEFAULT_THRESHOLD,
    #     "threshold_unit": DEFAULT_THRESHOLD_UNIT,
    #     "threshold_dir": UP_OR_DOWN,
    #     "mask_span_ngrams": True,
    #     "ngram_range": (1, 2),
    # },
    # RichDocSpanFeatures.VERT_ALIGNED_NGRAMS: {
    #     "scope": PAGE,
    #     "location": CENTER,
    #     "threshold": DEFAULT_VERT_ALIGNED_FEATURE_THRESHOLD,
    #     "threshold_unit": DEFAULT_THRESHOLD_UNIT,
    #     "threshold_dir": LEFT_OR_RIGHT,
    #     "mask_span_ngrams": True,
    #     "ngram_range": (1, 2),
    # },
    # RichDocSpanFeatures.PROXIMATE_TEXT_BEFORE: {
    #     "scope": PAGE,
    #     "window": 1,
    #     "scope_unit": LINE,
    # },
    # RichDocSpanFeatures.PROXIMATE_TEXT_AFTER: {
    #     "scope": PAGE,
    #     "window": 1,
    #     "scope_unit": LINE,
    # },
}


class Ngram(Serializable):
    """A class that represents an ngram (one or more grouped words).

    Note: A list of ngrams is sometimes represented as rows in a DataFrame with
    the same fields, as a performance optimization.

    Parameters
    ----------
    words
        A DataFrame of words that represent the given ngram.
    """

    def __init__(self, words: pd.DataFrame):
        self.words = words
        self.dict: Dict[str, Any] = {}

    def serialize(self) -> str:
        """Serialize instance to string."""
        return base64.b64encode(pickle.dumps(dict(words=self.words))).decode("ascii")

    @classmethod
    def deserialize(cls, serialized: str) -> "Ngram":
        """Deserialize instance to string."""
        return cls(**pickle.loads(base64.b64decode(serialized)))

    def __repr__(self) -> str:
        return (
            f"Ngram("
            f'text="{self.text}", '
            f"bbox={(self.left, self.top, self.right, self.bottom)}"
            ")"
        )

    @property
    def word0(self) -> pd.Series:
        if "word0" not in self.dict:
            self.dict["word0"] = self.words.iloc[0]
        return self.dict["word0"]

    @property
    def page_id(self) -> int:
        if PAGE_ID not in self.dict:
            self.dict[PAGE_ID] = int(self.word0[PAGE_ID])
        return self.dict[PAGE_ID]

    @property
    def area_id(self) -> int:
        if AREA_ID not in self.dict:
            self.dict[AREA_ID] = int(self.word0[AREA_ID])
        return self.dict[AREA_ID]

    @property
    def par_id(self) -> int:
        if PAR_ID not in self.dict:
            self.dict[PAR_ID] = int(self.word0[PAR_ID])
        return self.dict[PAR_ID]

    @property
    def line_id(self) -> int:
        if LINE_ID not in self.dict:
            self.dict[LINE_ID] = int(self.word0[LINE_ID])
        return self.dict[LINE_ID]

    @property
    def word_id(self) -> int:
        if WORD_ID not in self.dict:
            self.dict[WORD_ID] = int(self.word0.name)
        return self.dict[WORD_ID]

    @property
    def row_id(self) -> int:
        if ROW_ID not in self.dict:
            self.dict[ROW_ID] = int(self.word0[ROW_ID])
        return self.dict[ROW_ID]

    def scope_id(self, scope: str) -> int:
        scope_id = SCOPE_TO_ID[scope]
        return self[scope_id]

    @property
    def left(self) -> int:
        if LEFT not in self.dict:
            self.dict[LEFT] = int(self.words[LEFT].min())
        return self.dict[LEFT]

    @property
    def top(self) -> int:
        if TOP not in self.dict:
            self.dict[TOP] = int(self.words[TOP].min())
        return self.dict[TOP]

    @property
    def right(self) -> int:
        if RIGHT not in self.dict:
            self.dict[RIGHT] = int(self.words[RIGHT].max())
        return self.dict[RIGHT]

    @property
    def bottom(self) -> int:
        if BOTTOM not in self.dict:
            self.dict[BOTTOM] = int(self.words[BOTTOM].max())
        return self.dict[BOTTOM]

    @property
    def center(self) -> int:
        if CENTER not in self.dict:
            self.dict[CENTER] = (self[LEFT] + self[RIGHT]) // 2
        return self.dict[CENTER]

    @property
    def middle(self) -> int:
        if MIDDLE not in self.dict:
            self.dict[MIDDLE] = (self[TOP] + self[BOTTOM]) // 2
        return self.dict[MIDDLE]

    @property
    def char_start(self) -> int:
        if CHAR_START not in self.dict:
            self.dict[CHAR_START] = int(self.words[CHAR_START].min())
        return self.dict[CHAR_START]

    @property
    def char_end(self) -> int:
        if CHAR_END not in self.dict:
            self.dict[CHAR_END] = int(self.words[CHAR_END].max())
        return self.dict[CHAR_END]

    @property
    def text(self) -> str:
        if TEXT not in self.dict:
            self.dict[TEXT] = " ".join(self.words[TEXT].values)
        return self.dict[TEXT]

    # Enable dict access along with property access, like pd.Series.
    def __getitem__(self, key: str) -> Any:
        return getattr(self, key)


class RichDocWrapper:
    """A class that wraps a RichDoc and calculates derivative values and properties.

    For more details on RichDoc, see the documentation for the RichDoc class.

    Definitions used in this object:

    * A `span` is a (char_start, char_end) that was produced by a SpanExtractor.
        * Most public methods are passed a span and calculate attributes w/r/t it.
        * NOTE: we expect (char_start, char_end) to be (inclusive, inclusive).
    * A `word` is a single row in a DataFrame that represents a single word.
        * Tokenization into words is performed by whatever tool was used to create the hOCR representation.
    * An `ngram` is a class that represents one or more words (usually from the same line)
        * It usually represented via the Ngram class, but may represented as a row in a DataFrame for efficiency when dealing with many ngrams
        * Attributes will reflect a "convex hull" (min char_start/left/top, max char_end/right/bottom) where possible and the values of the first word otherwise.
        * All words are ngrams but not all ngrams are words.

    Other Notes:

    * [0, 0] is in the top-left corner (so bottom > top and right > left)
    * By default, for spans that cross page boundaries, all visual alignment information will be based only on the words that occur on the same page as the first word of the span.
    * CENTER is the halfway point between LEFT and RIGHT, MIDDLE is the halfway point between TOP and BOTTOM

    Parameters
    ----------
    rd:
        A RichDoc object containing textual, structural, visual, and tabular data
        about a rich document (e.g. a PDF).
    text:
        The raw text corresponding to the RichDoc object `rd`, which is used for
        computing character alignments to the RichDoc object.
    """

    def __init__(self, rd: RichDoc) -> None:
        self.rd = rd

        for df_name, expected_columns in [
            ("pages", PAGE_COLS),
            ("areas", AREA_COLS),
            ("pars", PAR_COLS),
            ("lines", LINE_COLS),
            ("words", WORD_COLS + [ROW_ID]),
        ]:
            df = getattr(rd, df_name)
            actual_columns = df.columns.values.tolist() + [df.index.name]
            missing_columns = set(expected_columns).difference(set(actual_columns))
            if missing_columns:
                raise ValueError(
                    f"Missing required fields for RichDoc: {missing_columns}"
                )

        # Properties to be lazily computed
        self._text_by_row = None

    def __repr__(self) -> str:
        return self.rd.__repr__().replace("RichDoc", "RichDocWrapper")

    @property
    def text(self) -> str:
        return self.rd.text

    def _validate_scope(self, scope: Scope) -> None:
        if scope not in SCOPES:
            raise ValueError(f"Invalid scope: {scope}. Expected one of {SCOPES}.")

    def _validate_axis(self, axis: Axis) -> None:
        if axis not in AXES:
            raise ValueError(f"Invalid axis: {axis}. Expected one of {AXES}.")

    def _validate_direction(
        self, direction: Direction, options: List[Direction]
    ) -> None:
        if direction not in options:
            raise ValueError(
                f"Invalid direction: {direction}. Expected one of {options}."
            )

    def _validate_location(
        self, location: Location, axis: Optional[Axis] = None
    ) -> None:
        if axis is None and location not in LOCATIONS:
            raise ValueError(
                f"Invalid location: {location}. Expected one of {LOCATIONS}."
            )
        elif axis == HORZ and location not in VERT_LOCATIONS:
            raise ValueError(
                f"Invalid location for axis {axis}: {location}. Expected one of {VERT_LOCATIONS}."
            )
        elif axis == VERT and location not in HORZ_LOCATIONS:
            raise ValueError(
                f"Invalid location for axis {axis}: {location}. Expected one of {HORZ_LOCATIONS}."
            )

    def _validate_threshold(
        self,
        threshold: Threshold,
        threshold_unit: ThresholdUnit,
        threshold_dir: Optional[ThresholdDir],
        location: Optional[Location],
        page_id: Optional[int],
    ) -> None:
        if threshold_unit not in THRESHOLD_UNITS:
            raise ValueError(
                f"Invalid threshold_unit {threshold_unit}; expected one of {THRESHOLD_UNITS}."
            )
        if threshold_unit == PAGE_PERCENT:
            if location is None:
                raise ValueError(
                    f"If threshold_unit == {PAGE_PERCENT}, then location must not be None."
                )
            if threshold < 0 or threshold > 100:
                raise ValueError(
                    f"If threshold_unit == {PAGE_PERCENT}, then threshold must be in [0, 100]."
                )
        if threshold_dir is not None:
            if threshold_dir not in DIRECTIONS:
                raise ValueError(
                    f"Invalid threshold_dir {threshold_dir}; expected one of {DIRECTIONS}."
                )
            elif threshold_dir in VERT_DIRECTIONS and location not in VERT_LOCATIONS:
                raise ValueError(
                    f"Invalid threshold_dir {threshold_dir} for location {location}."
                )
            elif threshold_dir in HORZ_DIRECTIONS and location not in HORZ_LOCATIONS:
                raise ValueError(
                    f"Invalid threshold_dir {threshold_dir} for location {location}."
                )

    def get_span_ngram(
        self, char_start: int, char_end: int, one_page: bool = True
    ) -> Ngram:
        """Make an ngram corresponding to (char_start, char_end).

        Parameters
        ----------
        char_start
            The inclusive start index of the span in RichDoc.text.
        char_end
            The inclusive end index of the span in RichDoc.text.
        one_page
            If one_page == True, an ngram containing only those words
            occuring on the same page as the first word of the span will be
            returned. This allows us to make assumptions downstream about all
            words (and bbox coordinates) coming from the same page.
        """
        span_words = self.rd._get_span_words(char_start, char_end, one_page=one_page)
        return Ngram(span_words)

    def _get_scope(self, span_ngram: Ngram, scope: Scope) -> pd.Series:
        """Fetch the given scope for a given ngram.

        Parameters
        ----------
        span_ngram
            The ngram whose scope to fetch.
        scope
            The scope to fetch.
        """
        self._validate_scope(scope)
        df_name = SCOPE_TO_DF[scope]
        scope_id_name = SCOPE_TO_ID[scope]
        df = getattr(self.rd, df_name)
        return df.loc[span_ngram[scope_id_name]]

    def _get_scope_id(self, scope: Scope) -> str:
        """Get the ID column for the given scope for use in RichDoc dataframes.

        Parameters
        ----------
        scope
            The scope whose ID to get.
        """
        scope_id = SCOPE_TO_ID.get(scope)
        if scope_id is None:
            raise ValueError(f"Invalid scope: {scope}")
        return scope_id

    def _get_scope_words(self, span_ngram: Ngram, scope: str) -> pd.DataFrame:
        """Return the words that are within the specified scope of a given span.

        Parameters
        ----------
        span_ngram
            The ngram whose scope words to fetch.
        scope
            The scope of words to fetch.
        """
        if scope == WORD:
            raise ValueError("Invalid scope for _get_scope_words: {WORD}")
        scope_id = self._get_scope_id(scope)
        word_scopes = self.rd.words[scope_id].values
        scope_val = span_ngram[scope_id]
        return self.rd.words.iloc[
            np.searchsorted(word_scopes, scope_val) : np.searchsorted(
                word_scopes, scope_val + 1
            )
        ]

    def _get_threshold_match(
        self,
        span_value: float,
        other_value: float,
        threshold: float,
        threshold_unit: ThresholdUnit,
        threshold_dir: Optional[ThresholdDir],
        location: Optional[Location],
        page_id: Optional[int],
        validate: bool = True,
    ) -> bool:
        """Return whether two values are within a given threshold of one another.

        See _get_threshold_matches for more details.
        """
        return self._get_threshold_matches(
            span_value,
            np.array([other_value]),
            threshold,
            threshold_unit,
            threshold_dir,
            location,
            page_id,
            validate=validate,
        )[0]

    def _get_threshold_matches(
        self,
        span_value: float,
        other_values: np.ndarray,
        threshold: float,
        threshold_unit: ThresholdUnit,
        threshold_dir: Optional[ThresholdDir],
        location: Optional[Location],
        page_id: Optional[int],
        validate: bool = True,
    ) -> np.ndarray:
        """Returns a bool array where values are within a given threshold of the span value.

        Example:
        If span_value is 10, other_value is 15, and threshold_pixels is 8, then if
        threshold_dir is DOWN or RIGHT, then the other_value is within range (since
        both DOWN and RIGHT are direction of increasing magnitude for pixels).
        The other_value would _not_ be within range if threshold_dir is UP or LEFT.

        Parameters
        ----------
        span_value
            The position value for the span.
        other_values
            An array of position values to be compared against the span position value.
        threshold
            The distance threshold for comparison.
        threshold_unit
            The unit of the given threshold.
        threshold_dir
            The direction of the threshold. If None, threshold is valid in both
            directions. Computed with respect to span_value.
        location
            The location used to calculate the threshold if threshold_unit is
            PAGE_PERCENT.
        page_id
            The page_id used to calculate the threshold if threshold_unit.
            is PAGE_PERCENT.
        """
        if validate:
            self._validate_threshold(
                threshold, threshold_unit, threshold_dir, location, page_id
            )
        threshold_pixels = self._get_threshold_in_pixels(
            threshold, threshold_unit, location, page_id
        )
        # Note: bbox values are unsigned ints to save space, so we ensure that
        # before there is a potential for a negative value
        diffs = float(span_value) - other_values.astype(float)
        if threshold_dir is None or threshold_dir in [UP_OR_DOWN, LEFT_OR_RIGHT]:
            return abs(diffs) <= threshold_pixels
        elif threshold_dir in [UP_ONLY, LEFT_ONLY]:
            return np.logical_and(diffs >= 0, diffs <= threshold_pixels)
        else:  # threshold_dir in [DOWN_ONLY, RIGHT_ONLY]:
            return np.logical_and(diffs <= 0, diffs >= -threshold_pixels)

    def _get_threshold_in_pixels(
        self,
        threshold: Threshold,
        threshold_unit: ThresholdUnit,
        location: Optional[Location],
        page_id: Optional[int] = None,
    ) -> float:
        """Compute the threshold in pixel units.

        Parameters
        ----------
        threshold
            The distance threshold.
        threshold_unit
            The unit of the given threshold.
        location
            The location used to calculate the threshold if threshold_unit is
            PAGE_PERCENT.
        page_id
            The page_id used to calculate the threshold if threshold_unit.
            is PAGE_PERCENT.
        """
        if threshold_unit == PIXELS:
            threshold_pixels = threshold
        elif threshold_unit == PAGE_PERCENT:
            if page_id is None:
                page_id = self.rd.pages.iloc[0].page_id

            if location in VERT_LOCATIONS:
                threshold_pixels = self._pixel_threshold_from_page_percent(
                    threshold, axis=HORZ, page_id=page_id
                )
            elif location in HORZ_LOCATIONS:
                threshold_pixels = self._pixel_threshold_from_page_percent(
                    threshold, axis=VERT, page_id=page_id
                )
        return threshold_pixels

    def _pixel_threshold_from_page_percent(
        self, page_percent: float, axis: Axis, page_id: int
    ) -> float:
        """Convert percentage of page into a pixel count.

        Parameters
        ----------
        page_percent
            The percentage of the page to convert to pixels.
        axis
            The axis of the page on which to compute the percentage.
        page_id
            The page_id of the page whose bbox to use.
        """
        left, top, right, bottom = self._get_page_bbox(page_id)

        self._validate_axis(axis)
        if axis == "horz":
            threshold = page_percent / 100.0 * (right - left)
        else:  # axis == "vert":
            threshold = page_percent / 100.0 * (bottom - top)

        return threshold

    def _get_page_bbox(self, page_id: int) -> Tuple[int, int, int, int]:
        """Get the bbox of the page with the given page_id.

        Parameters
        ----------
        page_id
            The page id of the page whose bbox to get.
        """
        page = self.rd.pages.loc[page_id]
        return (page[LEFT], page[TOP], page[RIGHT], page[BOTTOM])

    def _create_slim_ngrams(self, words: pd.DataFrame, n: int) -> pd.DataFrame:
        """Create ngrams (one per row) from a DataFrame of words (one word per row)

        Note: All parts of an ngram must come from the same line.

        Parameters
        ----------
        words
            The DataFrame of words to convert into ngrams.
        n
            The number of words in each n-gram.
        """
        ngrams = (
            (
                words.groupby(SCOPE_TO_ID[LINE])
                .rolling(n)
                .agg(
                    {
                        LEFT: "min",
                        TOP: "min",
                        RIGHT: "max",
                        BOTTOM: "max",
                        CHAR_START: "min",
                        CHAR_END: "max",
                    },
                    raw=True,
                )
            )
            .dropna()
            .astype(int)
        )
        # We use df.rolling, which creates sliding windows for us but unfortunately
        # does not support aggregation over strings, so we restore this after the fact.
        if len(ngrams):
            offset = self.rd.page_char_starts[0]
            ngrams[TEXT] = ngrams.apply(
                lambda x: self.rd.text[
                    x[CHAR_START] - offset : x[CHAR_END] - offset + 1
                ],
                axis=1,
            )
        return ngrams

    def _get_anchor_aligned_ngrams(
        self,
        anchor_ngram: Ngram,
        ngrams: pd.DataFrame,
        location: Location,
        threshold: Threshold,
        threshold_unit: ThresholdUnit,
        threshold_dir: Optional[ThresholdDir],
    ) -> pd.DataFrame:
        """Returns a DataFrame of ngrams that are aligned with an anchor ngram.

        Parameters
        ----------
        anchor_ngram
            The ngram on which to compute alignment.
        ngrams
            A dataframe of ngrams to filter for alignment with the anchor_ngram.
        location
            The location of the bbox used to compare alignment.
        threshold
            The threshold for computing alignment.
        threshold_unit
            The unit of the threshold.
        threshold_dir
            The direction of the threshold for alignment. If None, the threshold
            applies in both directions.
        """
        aligned_ngrams = ngrams[
            self._get_threshold_matches(
                self._get_series_location(anchor_ngram, location),
                self._get_row_locations(ngrams, location),
                threshold,
                threshold_unit,
                threshold_dir,
                location,
                page_id=anchor_ngram[PAGE_ID],
            )
        ]
        return aligned_ngrams

    def get_page_num(self, char_start: int, char_end: int) -> int:
        """Get the 1-indexed page number of a span.

        Parameters
        ----------
        char_start
            The inclusive start index of the span in raw text rep of the whole doc.
        char_end
            The inclusive end index of the span in raw text rep of the whole doc.
        """
        return self.rd._get_span_page(char_start) + 1

    def _get_span_page_num(self, span_ngram: Ngram) -> int:
        return span_ngram.page_id + 1

    def get_font_size(self, char_start: int, char_end: int) -> int:
        """Get font size of a span, rounded to the nearest int.

        If there are multiple font sizes, we default to font size of the first word in
        the span.

        Parameters
        ----------
        char_start
            The inclusive start index of the span in raw text rep of the whole doc.
        char_end
            The inclusive end index of the span in raw text rep of the whole doc.
        """
        span_ngram = self.get_span_ngram(char_start, char_end)
        return self._get_span_font_size(span_ngram)

    def _get_span_font_size(self, span_ngram: Ngram) -> int:
        return int(round(self.rd.lines.at[span_ngram.line_id, FONT_SIZE]))

    def is_scope_aligned(
        self,
        char_start: int,
        char_end: int,
        scope: Scope,
        location: Location,
        threshold: Threshold = DEFAULT_THRESHOLD,
        threshold_unit: ThresholdUnit = DEFAULT_THRESHOLD_UNIT,
        threshold_dir: Optional[ThresholdDir] = None,
    ) -> bool:
        """Return whether the span is aligned w/r/t a given scope and location.

        Parameters
        ----------
        char_start
            The (inclusive) start character of the span.
        char_end
            The (inclusive) end character of the span.
        scope:
            The scope (line, page, etc.).
        pars:
            A DataFrame of paragraph objects.
        lines:
            A DataFrame of line objects.
        words:
            A DataFrame of word objects, with bounding boxes, parent obj. assignments, etc.


        Note: This uses the bbox for the given scope, which is generally just a convex
        hull of the words in the scope. The one expection is when scope = PAGE, for
        which the bbox is actually just the outside border of the page.
        """
        span_ngram = self.get_span_ngram(char_start, char_end)
        return self._is_span_scope_aligned(
            span_ngram, scope, location, threshold, threshold_unit, threshold_dir
        )

    def _is_span_scope_aligned(
        self,
        span_ngram: Ngram,
        scope: Scope,
        location: Location,
        threshold: Threshold = DEFAULT_THRESHOLD,
        threshold_unit: ThresholdUnit = DEFAULT_THRESHOLD_UNIT,
        threshold_dir: Optional[ThresholdDir] = None,
    ) -> bool:
        self._validate_scope(scope)
        self._validate_location(location)
        scope_series = self._get_scope(span_ngram, scope)
        return self._get_threshold_match(
            self._get_series_location(span_ngram, location),
            self._get_series_location(scope_series, location),
            threshold,
            threshold_unit,
            threshold_dir,
            location=location,
            page_id=span_ngram[PAGE_ID],
        )

    def _get_proximate_text(
        self,
        span_ngram: Ngram,
        window: int,
        scope_unit: Scope = LINE,
        direction: Direction = BEFORE_OR_AFTER,
    ) -> str:
        scope_id = self._get_scope_id(scope_unit)
        span_scope_id = span_ngram[scope_id]
        if direction == BEFORE_ONLY:
            valid_scope_ids = span_scope_id + np.arange(-window, 1)
        elif direction == AFTER_ONLY:
            valid_scope_ids = span_scope_id + np.arange(window + 1)
        else:  # direction == BEFORE_OR_AFTER
            valid_scope_ids = span_scope_id + np.arange(-window, window + 1)

        # Since the index WORD_ID isn't a column, we need to access it differently.
        if scope_id == WORD_ID:
            scope_ids = self.rd.words.index
        else:
            scope_ids = self.rd.words[scope_id]
        scope_words = self.rd.words[scope_ids.isin(valid_scope_ids)]
        return self._text_from_words(scope_words)

    def get_proximate_text(
        self,
        char_start: int,
        char_end: int,
        window: int,
        scope_unit: Scope = LINE,
        direction: Direction = BEFORE_OR_AFTER,
    ) -> str:
        """Returns text found near the given span.

        Parameters
        ----------
        char_start
            The (inclusive) start character of the span
        char_end
            The (inclusive) end character of the span
        window
            The number of scope_units from the given span to aggregate text.
        scope_unit
            The unit with which to define the window.
        direction
            The direction of the window from the given span aggregate text.
        """
        self._validate_direction(direction, SEQ_DIRECTIONS)
        span_ngram = self.get_span_ngram(char_start, char_end, one_page=True)
        return self._get_proximate_text(span_ngram, window, scope_unit, direction)

    def is_regex_proximate(
        self,
        char_start: int,
        char_end: int,
        regex_pattern: str,
        window: int,
        scope_unit: Scope = LINE,
        direction: Direction = BEFORE_OR_AFTER,
        case_sensitive: bool = CASE_SENSITIVE_DEFAULT,
    ) -> bool:
        """Returns whether or not the given regex is found near the given span.

        Parameters
        ----------
        char_start
            The (inclusive) start character of the span
        char_end
            The (inclusive) end character of the span
        regex_pattern
            The regex pattern to be matched near the span.
        window
            The number of scope_units from the given span to check for the given regex.
        scope_unit
            The unit with which to define the window.
        direction
            The direction of the window from the given span to check for the given regex.
        case_sensitive
            True for the regex match to be case sensitive, False otherwise.
        """
        scope_text = self.get_proximate_text(
            char_start, char_end, window, scope_unit, direction
        )
        flags = 0 if case_sensitive else regex.IGNORECASE
        regex_pattern_compiled = regex.compile(regex_pattern, flags=flags)
        return bool(regex_pattern_compiled.search(scope_text))

    def _text_from_words(self, words: pd.DataFrame) -> str:
        """Get the text representation corresponding to the given words

        This includes newlines in the right places and any necessary offset to account
        for when the RichDoc is a slice of a larger document.
        """
        # NOTE: This relies on the fact that scopes are always contiguous (e.g., no
        # words exist that don't also belong to lines.)
        offset = self.rd.page_char_starts[0]
        char_start = words[CHAR_START].min()
        char_end = words[CHAR_END].max()
        return self.rd.text[char_start - offset : char_end - offset + 1]

    def is_regex_aligned(
        self,
        char_start: int,
        char_end: int,
        ngrams: List[Ngram],
        scope: Scope,
        location: Location,
        threshold: Threshold = DEFAULT_THRESHOLD,
        threshold_unit: ThresholdUnit = DEFAULT_THRESHOLD_UNIT,
        threshold_dir: Optional[ThresholdDir] = None,
        case_sensitive: bool = CASE_SENSITIVE_DEFAULT,
    ) -> bool:
        """Returns whether or not regex_pattern is found in scope that aligns with the given span.

        Note: Alignment is assessed by comparing a given location (LEFT/CENTER/RIGHT/TOP/
        MIDDLE/BOTTOM) on both the span and any regex matches up to a given threshold
        (either in pixels or a percentage of the page).

        Parameters
        ----------
        char_start
            The (inclusive) start character of the span.
        char_end
            The (inclusive) end character of the span.
        ngrams
            The regex ngrams to check for alignment with the given span.
        scope
            The scope within which to check for the regex_pattern.
        location
            The location of the span/regex bboxes to compare alignment.
        threshold
            The threshold used for computing alignment.
        threshold_unit
            The unit of the threshold.
        threshold_dir
            The direction on which the threshold applies. If None, the threshold
            applies in both directions.
        case_sensitive
            True to use a case sensitive regex match, False otherwise.
        """
        span_ngram = self.get_span_ngram(char_start, char_end, one_page=True)
        page_id = span_ngram[PAGE_ID]
        self._validate_threshold(
            threshold, threshold_unit, threshold_dir, location, page_id
        )
        span_loc = self._get_series_location(span_ngram, location)
        for regex_ngram in ngrams:
            if regex_ngram.scope_id(scope) != regex_ngram.scope_id(scope):
                continue

            regex_loc = self._get_series_location(regex_ngram, location)
            if self._get_threshold_match(
                span_loc,
                regex_loc,
                threshold,
                threshold_unit,
                threshold_dir,
                location,
                page_id=page_id,
                validate=False,
            ):
                return True
        return False

    def is_regex_within_bounds(
        self,
        char_start: int,
        char_end: int,
        ngrams: List[Ngram],
        scope: Scope,
        span_horz_location: Location,
        span_vert_location: Location,
        regex_horz_location: Location,
        regex_vert_location: Location,
        horz_op_func: Callable,
        vert_op_func: Callable,
        disable_horz: bool = False,
        disable_vert: bool = False,
        case_sensitive: bool = CASE_SENSITIVE_DEFAULT,
    ) -> bool:
        """Returns whether or not given span has position relative to regex_pattern that meets the conditions.

        Note: Alignment is assessed by comparing a given location (LEFT/CENTER/RIGHT/TOP/
        MIDDLE/BOTTOM) on both the span and any regex matches.

        Parameters
        ----------
        char_start
            The (inclusive) start character of the of span.
        char_end
            The (inclusive) end character of the span.
        ngrams
            The ngrams to check for alignment with the given span.
        scope
            The scope within which to check for the regex_pattern.
        span_horz_location
            The horizontal location of the span bboxes to compare alignment.
        span_vert_location
            The vertical location of the span bboxes to compare alignment.
        regex_horz_location
            The horizontal location of the regex bboxes to compare alignment.
        regex_vert_location
            The vertical location of the regex bboxes to compare alignment.
        horz_op_func
            The operator to compare the horizontal span_location and regex_location
        vert_op_func
            The operator to compare the vertical span_location and regex_location
        case_sensitive
            True to use a case sensitive regex match, False otherwise.
        """
        span_ngram = self.get_span_ngram(char_start, char_end, one_page=True)
        matched = False
        for ngram in ngrams:
            if span_ngram.scope_id(scope) != ngram.scope_id(scope):
                continue
            span_horz_loc = span_ngram[span_horz_location]
            span_vert_loc = span_ngram[span_vert_location]
            match_horz_loc = ngram[regex_horz_location]
            match_vert_loc = ngram[regex_vert_location]
            if disable_horz and disable_vert:
                match_cond = True
            elif disable_horz:
                match_cond = vert_op_func(span_vert_loc, match_vert_loc)
            elif disable_vert:
                match_cond = horz_op_func(span_horz_loc, match_horz_loc)
            else:
                match_cond = horz_op_func(
                    span_horz_loc, match_horz_loc
                ) and vert_op_func(span_vert_loc, match_vert_loc)

            if match_cond:
                matched = True
                break
        return matched

    def get_aligned_ngrams(
        self,
        char_start: int,
        char_end: int,
        locations: List[Location],
        scope: Scope = PAGE,
        vert_threshold: Threshold = DEFAULT_THRESHOLD,
        vert_threshold_unit: ThresholdUnit = DEFAULT_THRESHOLD_UNIT,
        vert_threshold_dir: Optional[ThresholdDir] = None,
        horz_threshold: Threshold = DEFAULT_THRESHOLD,
        horz_threshold_unit: ThresholdUnit = DEFAULT_THRESHOLD_UNIT,
        horz_threshold_dir: Optional[ThresholdDir] = None,
        mask_span_ngrams: bool = True,
        ngram_range: Tuple[int, int] = (1, 1),
    ) -> Dict[str, List[str]]:
        """Return all ngrams that are aligned in the given scope/threshold by location

        Note that we can't say whether an ngram is aligned in any particular direction
        until we know what the ngram is, so we can't just identify the aligned words
        and then make ngrams after the fact (e.g., a date span may be aligned with only
        the word "the" in "the execution date")

        Parameters
        ----------
        char_start
            The (inclusive) start character of the span.
        char_end
            The (inclusive) end character of the span.
        locations
            The locations of the span/regex bboxes to use to compare alignments.
        scope
            The scope within which to look for aligned ngrams.
        vert_threshold
            The threshold used for comparing alignment vertically on the page.
        vert_threshold_unit
            The unit of the vertical threshold.
        vert_threshold_dir
            The direction on which the vertical threshold applies. If None,
            threshold applies in both directions.
        horz_threshold
            The threshold used for comparing alignment horizontally on the page.
        horz_threshold_unit
            The unit of the horizontal threshold
        horz_threshold_dir
            The direction on which the horizontal threshold applies. If None,
            threshold applies in both directions.
        mask_span_ngrams
            True to replace the anchor span with SPAN_TOKEN in ngrams. False otherwise.
        ngram_range
            The range of ngram lengths to return.
        """
        span_ngram = self.get_span_ngram(char_start, char_end, one_page=True)
        return self._get_aligned_ngrams(
            span_ngram=span_ngram,
            locations=locations,
            scope=scope,
            vert_threshold=vert_threshold,
            vert_threshold_unit=vert_threshold_unit,
            vert_threshold_dir=vert_threshold_dir,
            horz_threshold=horz_threshold,
            horz_threshold_unit=horz_threshold_unit,
            horz_threshold_dir=horz_threshold_dir,
            mask_span_ngrams=mask_span_ngrams,
            ngram_range=ngram_range,
        )

    def _get_aligned_ngrams(
        self,
        span_ngram: Ngram,
        locations: List[Location],
        scope: Scope = AREA,
        vert_threshold: Threshold = DEFAULT_THRESHOLD,
        vert_threshold_unit: ThresholdUnit = DEFAULT_THRESHOLD_UNIT,
        vert_threshold_dir: Optional[ThresholdDir] = None,
        horz_threshold: Threshold = DEFAULT_THRESHOLD,
        horz_threshold_unit: ThresholdUnit = DEFAULT_THRESHOLD_UNIT,
        horz_threshold_dir: Optional[ThresholdDir] = None,
        mask_span_ngrams: bool = True,
        ngram_range: Tuple[int, int] = (1, 1),
    ) -> Dict[str, List[str]]:
        self._validate_scope(scope)
        for location in locations:
            self._validate_location(location)

        # Restrict to appropriate scope
        scope_words = self._get_scope_words(span_ngram, scope)

        # Create candidate ngrams with a limited subset of attributes (limited to
        # those that are preserved in the _create_slim_ngrams() method).
        dfs_ngrams = []
        for n in range(ngram_range[0], ngram_range[1] + 1):
            if n == 1:
                df = scope_words[NGRAM_SLIM_COLS]
            else:
                df = self._create_slim_ngrams(scope_words, n=n)
            dfs_ngrams.append(df)
        scope_ngrams = pd.concat(dfs_ngrams, axis=0)

        # Discover which of the candidate ngrams are aligned
        aligned_ngrams_dict: Dict[str, List[str]]
        if len(scope_ngrams) == 0:
            aligned_ngrams_dict = {location: [] for location in locations}
        else:
            aligned_ngrams_dict = {}
            for location in locations:
                if location in VERT_LOCATIONS:
                    threshold = horz_threshold
                    threshold_unit = horz_threshold_unit
                    threshold_dir = horz_threshold_dir
                else:
                    threshold = vert_threshold
                    threshold_unit = vert_threshold_unit
                    threshold_dir = vert_threshold_dir

                aligned_ngrams = self._get_anchor_aligned_ngrams(
                    span_ngram,
                    scope_ngrams,
                    location,
                    threshold,
                    threshold_unit,
                    threshold_dir,
                )[TEXT].values

                # We intentionally replace all instances of the SPAN (not just the one
                # at (char_start, char_end), assuming that will be more informative for
                # the model.
                if mask_span_ngrams:
                    span_text = span_ngram[TEXT]
                    aligned_ngrams = [
                        x.replace(span_text, SPAN_TOKEN)
                        for x in aligned_ngrams
                        if x != span_text
                    ]

                aligned_ngrams_dict[location] = aligned_ngrams

        return aligned_ngrams_dict

    def get_row_headers(
        self,
        char_start: int,
        char_end: int,
        scope: Scope = PAGE,
        multi_row: bool = True,
        min_margin: int = 10,
        max_gap: int = 20,
        max_left_page_pct: int = 50,
    ) -> Dict[str, Union[str, List[str]]]:
        """Heuristically fetch row headers and (optionally) inferred headers

        The `horizontal header` is the phrase in scope that is furthest to the left of
        the span.
        The `inferred headers` are strings that are the first string above and to
        the left of a Span to be indented at a particular level.

        Example:
        For the span "$1.00", inferred headers will be ["Planes and other stuff",
        "Equipment", "Assets"] if multirow is True, and ["other stuff", "Equipment",
        "Assets"] otherwise.

        .. code-block:: text

            Assets
                Cash             $10.00
                Inventory         $5.00
                Equipment
                    Cars          $4.00
                    Planes and
                    other stuff   $1.00
            Liabilities

        Parameters
        ----------
        char_start
            The (inclusive) start character of the span.
        char_end
            The (inclusive) end character of the span.
        scope
            The scope within which to look for headers.
        min_margin
            The minimum margin (in pixels) to the left and above a word that is
            required for it be considered as a valid inferred header (i.e., not on the
            same horizontal line as or vertically aligned with the previous header).
        max_gap
            The maximum gap allowed between words on a line for them to be considered
            part of the same header.
        max_left_page_pct
            A percentage (0-100) of the page from the left boundary that all headers
            must have a left coordinate less than (e.g., if 25, then all row headers
            must be on the left quarter of the page).
        """

        def _prune_words(
            anchor_ngram: pd.Series,
            words: pd.DataFrame,
            margin: int,
            include_own_row: bool = False,
        ) -> pd.DataFrame:
            anchor_row = anchor_ngram.words[ROW_ID].values[0] + int(include_own_row)
            left_limit = anchor_ngram.words[LEFT].values[0] - margin
            words = words.iloc[: np.searchsorted(words[ROW_ID].values, anchor_row)]
            return words[words.left.values <= left_limit]

        def _extract_head_word(words: pd.DataFrame) -> pd.DataFrame:
            # The next head word is the lowest word in the remaining set of options,
            # And words is already sorted in ascending order so the highest BOTTOM
            # values will be at the end of the DataFrame.
            return words.tail(1)

        def _get_row_header_words(
            row_id: int, words: pd.DataFrame, max_gap: int
        ) -> pd.DataFrame:
            row_ids = words[ROW_ID].values
            # Can do this since words are sorted by row ids
            row_words = words.iloc[
                np.searchsorted(row_ids, row_id) : np.searchsorted(row_ids, row_id + 1)
            ]
            if len(row_words) == 1:
                header_words = row_words
            else:
                gaps = row_words[LEFT].values[1:] - row_words[RIGHT].values[:-1]
                row_break = int(np.argmax(np.insert(gaps, 0, 0) >= max_gap))
                if row_break == 0:
                    # All gaps were <= max_gap, so keep all words
                    header_words = row_words
                else:
                    # Only keep words up to the line-breaking gap
                    header_words = row_words[:row_break]
            return header_words

        def _extract_header(
            head: pd.DataFrame, words: pd.DataFrame, max_gap: int, multi_row: bool
        ) -> Ngram:
            # Given a head word, create the whole header, including all words to the
            # right until the first time that max_gap between words is exceeded.
            row_id = head[ROW_ID].values[0]
            header_words = _get_row_header_words(row_id, words, max_gap)

            # Attempt to capture multi-row headers, where a multi-row header is
            # defined as a header composed of more than one row of words where the
            # indentation size is constant or non-decreasing from top to bottom and all
            # rows besides the first start with a non-capital letter (lowercase
            # letter, digit, etc.)
            if multi_row:
                multi_row_header_words = [header_words]
                # Check the top row's first word's first letter's capitalization
                top_head_text = multi_row_header_words[0].text.values[0]
                top_head_left = multi_row_header_words[0].left.values[0]
                while not top_head_text[0].isupper() and row_id > 0:
                    header_words = _get_row_header_words(row_id - 1, words, max_gap)
                    # Include fudge factor of 5 pixels for non-decreasing indentation
                    if (not header_words.empty) and header_words.left.values[
                        0
                    ] <= top_head_left + 5:
                        multi_row_header_words = [header_words] + multi_row_header_words
                        top_head_text = multi_row_header_words[0].text.values[0]
                        top_head_left = multi_row_header_words[0].left.values[0]
                        row_id -= 1
                    else:
                        break
                if len(multi_row_header_words) > 1:
                    header_words = pd.concat(multi_row_header_words, axis=0)
                else:
                    header_words = multi_row_header_words[0]
            return Ngram(header_words)

        self._validate_scope(scope)
        if min_margin < 0:
            raise ValueError("min_margin must be a nonnegative integer")
        if max_gap < 0:
            raise ValueError("min_margin must be a nonnegative integer")
        if not (0 <= max_left_page_pct <= 100):
            raise ValueError("max_left_page_pct must be between 0 and 100")

        span_words = self.rd._get_span_words(char_start, char_end)
        span_ngram = Ngram(span_words)
        # Do not include span_ngram words in scope (you cannot be your own header)
        scope_words = self._get_scope_words(span_ngram, scope)
        scope_words = scope_words[~scope_words.index.isin(span_words.index)]
        # Head words are the first word of each line in the scope
        # Sort by bottom coordinate so that the next section header head can always be
        # popped off the bottom of the head_words df instead of searched for.
        # Reset the index so that line_id is available for usage by name later.
        scope_words = scope_words.sort_values(by=[ROW_ID, CHAR_START])
        scope_first_idx = np.unique(scope_words[ROW_ID].values, return_index=True)[1]
        head_words = scope_words.iloc[scope_first_idx]

        # Drop lines with no text (typically black divider lines on the page)
        empty_word_filter = np.char.strip(head_words.text.values.astype(str)) != ""
        head_words = head_words[empty_word_filter]

        # Drop head words that do not satisfy the max_left_page_pct
        page_right = self.rd.pages.at[span_ngram.page_id, RIGHT]
        page_left = self.rd.pages.at[span_ngram.page_id, LEFT]
        max_left = max_left_page_pct / 100 * (page_right - page_left)
        head_words = head_words[head_words[LEFT].values <= max_left]

        # We include words on the span_ngram's own line (excluding itself) for its first header
        head_words = _prune_words(
            span_ngram, head_words, min_margin, include_own_row=True
        )

        # Note whether the first header is in the same row as the span_ngram header
        is_first_header_aligned = (
            len(head_words) and head_words[ROW_ID].values[-1] == span_ngram.row_id
        )

        headers: List[str] = []
        while len(head_words):
            header_head_word = _extract_head_word(head_words)
            header_ngram = _extract_header(
                header_head_word, scope_words, max_gap, multi_row
            )
            headers.append(header_ngram.text)
            head_words = _prune_words(
                header_ngram, head_words, min_margin, include_own_row=False
            )
        row_header = (
            headers[0] if (len(headers) and is_first_header_aligned) else EMPTY_HEADER
        )

        return dict(row_header=row_header, row_headers_inferred=headers)

    def get_span_row_text(
        self,
        char_start: int,
        char_end: int,
        row_offsets: Tuple[int, int] = (0, 0),
        mask_span: bool = True,
        span_ngram: Optional[Ngram] = None,
    ) -> str:
        """Return the text from one or more rows in the vicinity of a span

        Parameters
        ----------
        char_start
            The (inclusive) start character of the span.
        char_end
            The (inclusive) end character of the span.
        row_offsets
            The inclusive range of rows to extract text from and concatenate
            If more than one row is included, a delimiter is used between rows
            The range (-2, 1) would return a string containing the text from four rows:
            Two before the span, the span's own row, and one after the span.
        """
        if span_ngram is None:
            span_ngram = self.get_span_ngram(char_start, char_end)
        span_row_id = span_ngram.row_id
        span_page_id = span_ngram.page_id

        row_ids = self.rd.text_by_row.index.get_level_values(1)

        # Exclude the -1 row_id that corresponds to empty words
        row_id_lb = 0
        row_id_ub = max(row_ids)

        row_texts = []
        for row_id in range(
            span_row_id + min(row_offsets), span_row_id + max(row_offsets) + 1
        ):
            if row_id < row_id_lb:
                row_texts.append(PAGE_START_MARKER)
            elif row_id > row_id_ub:
                row_texts.append(PAGE_END_MARKER)
            else:
                row_text = self.rd.get_row_text(span_page_id, row_id)
                if row_id == span_row_id and mask_span:
                    row_filter = self.rd.words[ROW_ID] == row_id
                    row_char_start = self.rd.words.char_start[row_filter].values[0]
                    row_text = (
                        row_text[: char_start - row_char_start]
                        + SPAN_TOKEN
                        + row_text[char_end - row_char_start + 1 :]
                    )
                row_texts.append(row_text)

        return TEXT_DELIMITER.join(row_texts)

    def get_span_features(
        self, char_start: int, char_end: int, config: Dict[str, Any]
    ) -> Dict[str, Union[int, str]]:
        """Get rich doc feature library for a given span."""

        def _format_ngrams(ngrams: List[str]) -> str:
            # The CountVectorizer downstream expects floats or strings, not lists of strings
            # Join all ngrams with spaces so they are one string, but replace spaces
            # within each ngram with underscores so they are treated as a single feature
            # by the CountVectorizer.
            ngram_str = " ".join(ngram.replace(" ", "_") for ngram in ngrams)
            return ngram_str

        features_dict: Dict[str, Union[int, str]] = {
            RichDocSpanFeatures.FONT_SIZE: -1,
            RichDocSpanFeatures.ROW_ID: -1,
            RichDocSpanFeatures.ROW_HEADER: "",
            RichDocSpanFeatures.INFERRED_ROW_HEADERS: "",
            RichDocSpanFeatures.VERT_ALIGNED_NGRAMS: "",
            RichDocSpanFeatures.HORZ_ALIGNED_NGRAMS: "",
            RichDocSpanFeatures.PROXIMATE_TEXT_BEFORE: "",
            RichDocSpanFeatures.PROXIMATE_TEXT_AFTER: "",
            RichDocSpanFeatures.ROW_TEXT_BEFORE: "",
            RichDocSpanFeatures.ROW_TEXT_AFTER: "",
            RichDocSpanFeatures.ROW_TEXT_INLINE: "",
        }

        # Compute the span_ngram once as a performance improvement
        span_ngram = self.get_span_ngram(char_start, char_end)

        for feature_name, feature_config in config.items():
            if feature_name == RichDocSpanFeatures.FONT_SIZE:
                features_dict[RichDocSpanFeatures.FONT_SIZE] = self._get_span_font_size(
                    span_ngram
                )
            elif feature_name == RichDocSpanFeatures.ROW_ID:
                features_dict[RichDocSpanFeatures.ROW_ID] = span_ngram.row_id
            elif feature_name == RichDocSpanFeatures.ROW_HEADER:
                # TODO: Consider replacing with private function that uses span_ngram
                # to improve performance
                row_headers_dict = self.get_row_headers(
                    char_start, char_end, **feature_config
                )
                features_dict[RichDocSpanFeatures.ROW_HEADER] = row_headers_dict[  # type: ignore
                    "row_header"
                ]
                features_dict[
                    RichDocSpanFeatures.INFERRED_ROW_HEADERS
                ] = TEXT_DELIMITER.join(row_headers_dict["row_headers_inferred"])
            elif feature_name == RichDocSpanFeatures.VERT_ALIGNED_NGRAMS:
                aligned_ngrams_dict = self._get_aligned_ngrams(
                    span_ngram,
                    locations=[feature_config["location"]],
                    scope=feature_config["scope"],
                    vert_threshold=feature_config["threshold"],
                    vert_threshold_unit=feature_config["threshold_unit"],
                    horz_threshold=feature_config["threshold"],
                    horz_threshold_unit=feature_config["threshold_unit"],
                    mask_span_ngrams=feature_config["mask_span_ngrams"],
                    ngram_range=feature_config["ngram_range"],
                )
                aligned_ngrams = aligned_ngrams_dict[feature_config["location"]]
                features_dict[RichDocSpanFeatures.VERT_ALIGNED_NGRAMS] = _format_ngrams(
                    aligned_ngrams
                )
            elif feature_name == RichDocSpanFeatures.HORZ_ALIGNED_NGRAMS:
                aligned_ngrams_dict = self._get_aligned_ngrams(
                    span_ngram,
                    locations=[feature_config["location"]],
                    scope=feature_config["scope"],
                    vert_threshold=feature_config["threshold"],
                    vert_threshold_unit=feature_config["threshold_unit"],
                    horz_threshold=feature_config["threshold"],
                    horz_threshold_unit=feature_config["threshold_unit"],
                    mask_span_ngrams=feature_config["mask_span_ngrams"],
                    ngram_range=feature_config["ngram_range"],
                )
                aligned_ngrams = aligned_ngrams_dict[feature_config["location"]]
                features_dict[RichDocSpanFeatures.HORZ_ALIGNED_NGRAMS] = _format_ngrams(
                    aligned_ngrams
                )
            elif feature_name == RichDocSpanFeatures.PROXIMATE_TEXT_BEFORE:
                features_dict[
                    RichDocSpanFeatures.PROXIMATE_TEXT_BEFORE
                ] = self._get_proximate_text(
                    span_ngram,
                    window=feature_config["window"],
                    scope_unit=feature_config["scope_unit"],
                    direction=BEFORE_ONLY,
                )
            elif feature_name == RichDocSpanFeatures.PROXIMATE_TEXT_AFTER:
                features_dict[
                    RichDocSpanFeatures.PROXIMATE_TEXT_AFTER
                ] = self._get_proximate_text(
                    span_ngram,
                    window=feature_config["window"],
                    scope_unit=feature_config["scope_unit"],
                    direction=AFTER_ONLY,
                )
            elif feature_name == RichDocSpanFeatures.ROW_TEXT_BEFORE:
                if feature_config["lines"] <= 0:
                    raise ValueError(
                        "Number of lines for rich_doc_row_text_before must be a positive integer"
                    )
                features_dict[
                    RichDocSpanFeatures.ROW_TEXT_BEFORE
                ] = self.get_span_row_text(
                    char_start, char_end, row_offsets=(feature_config["lines"] * -1, -1)
                )
            elif feature_name == RichDocSpanFeatures.ROW_TEXT_AFTER:
                if feature_config["lines"] <= 0:
                    raise ValueError(
                        "Number of lines for rich_doc_row_text_after must be a positive integer"
                    )
                features_dict[
                    RichDocSpanFeatures.ROW_TEXT_AFTER
                ] = self.get_span_row_text(
                    char_start, char_end, row_offsets=(1, feature_config["lines"])
                )
            elif feature_name == RichDocSpanFeatures.ROW_TEXT_INLINE:
                features_dict[
                    RichDocSpanFeatures.ROW_TEXT_INLINE
                ] = self.get_span_row_text(
                    char_start,
                    char_end,
                    row_offsets=(0, 0),
                    mask_span=feature_config.get("mask_span", True),
                )

        return features_dict

    # DataFrame location helpers
    def _get_df_left(self, ngrams: pd.DataFrame) -> float:
        """Get the furthest left bound of a DataFrame of ngrams."""
        return min(ngrams[LEFT].values)

    def _get_df_center(self, ngrams: pd.DataFrame) -> float:
        """Get the (left-to-right) center of a DataFrame of ngrams."""
        return (self._get_df_left(ngrams) + self._get_df_right(ngrams)) / 2

    def _get_df_right(self, ngrams: pd.DataFrame) -> float:
        """Get the furthest right bound of a DataFrame of ngrams."""
        return max(ngrams[RIGHT].values)

    def _get_df_top(self, ngrams: pd.DataFrame) -> float:
        """Get the furthest top bound of a DataFrame of ngrams."""
        return min(ngrams[TOP].values)

    def _get_df_middle(self, ngrams: pd.DataFrame) -> float:
        """Get the (top-to-bottom) middle of a DataFrame of ngrams."""
        return (self._get_df_top(ngrams) + self._get_df_bottom(ngrams)) / 2

    def _get_df_bottom(self, ngrams: pd.DataFrame) -> float:
        """Get the furthest bottom bound of a DataFrame of ngrams."""
        return max(ngrams[BOTTOM].values)

    def _get_df_location(self, ngrams: pd.DataFrame, location: Location) -> float:
        if location == LEFT:
            return self._get_df_left(ngrams)
        elif location == CENTER:
            return self._get_df_center(ngrams)
        elif location == RIGHT:
            return self._get_df_right(ngrams)
        elif location == TOP:
            return self._get_df_top(ngrams)
        elif location == MIDDLE:
            return self._get_df_middle(ngrams)
        elif location == BOTTOM:
            return self._get_df_bottom(ngrams)
        else:
            raise ValueError(f"Invalid location for _get_df_location: {location}")

    # Series location helpers
    def _get_series_left(self, ngram: pd.Series) -> float:
        """Get the furthest left bound of a Series containing an ngram."""
        return ngram[LEFT]

    def _get_series_center(self, ngram: pd.Series) -> float:
        """Get the (left-to-right) center of a Series containing an ngram."""
        return (ngram[LEFT] + ngram[RIGHT]) / 2

    def _get_series_right(self, ngram: pd.Series) -> float:
        """Get the furthest right bound of a Series containing an ngram."""
        return ngram[RIGHT]

    def _get_series_top(self, ngram: pd.Series) -> float:
        """Get the furthest top bound of a Series containing an ngram."""
        return ngram[TOP]

    def _get_series_middle(self, ngram: pd.Series) -> float:
        """Get the (top-to-bottom) middle of a Series containing an ngram."""
        return (ngram[TOP] + ngram[BOTTOM]) / 2

    def _get_series_bottom(self, ngram: pd.Series) -> float:
        """Get the furthest bottom bound of a Series containing an ngram."""
        return ngram[BOTTOM]

    def _get_series_location(self, ngram: pd.Series, location: Location) -> float:
        if location == LEFT:
            return self._get_series_left(ngram)
        elif location == CENTER:
            return self._get_series_center(ngram)
        elif location == RIGHT:
            return self._get_series_right(ngram)
        elif location == TOP:
            return self._get_series_top(ngram)
        elif location == MIDDLE:
            return self._get_series_middle(ngram)
        elif location == BOTTOM:
            return self._get_series_bottom(ngram)
        else:
            raise ValueError(f"Invalid location for _get_series_location: {location}")

    # Row location helpers
    def _get_row_lefts(self, ngrams: pd.DataFrame) -> np.ndarray:
        """Get the furthest left bound of the ngram in each row."""
        return ngrams[LEFT].values

    def _get_row_centers(self, ngrams: pd.DataFrame) -> np.ndarray:
        """Get the (left-to-right) center of the ngram in each row."""
        return (self._get_row_lefts(ngrams) + self._get_row_rights(ngrams)) / 2

    def _get_row_rights(self, ngrams: pd.DataFrame) -> np.ndarray:
        """Get the furthest right bound of the ngram in each row."""
        return ngrams[RIGHT].values

    def _get_row_tops(self, ngrams: pd.DataFrame) -> np.ndarray:
        """Get the furthest top bound of the ngram in each row."""
        return ngrams[TOP].values

    def _get_row_middles(self, ngrams: pd.DataFrame) -> np.ndarray:
        """Get the (top-to-bottom) middle of the ngram in each row."""
        return (self._get_row_tops(ngrams) + self._get_row_bottoms(ngrams)) / 2

    def _get_row_bottoms(self, ngrams: pd.DataFrame) -> np.ndarray:
        """Get the furthest bottom bound of the ngram in each row."""
        return ngrams[BOTTOM].values

    def _get_row_locations(
        self, ngrams: pd.DataFrame, location: Location
    ) -> np.ndarray:
        if location == LEFT:
            return self._get_row_lefts(ngrams)
        elif location == CENTER:
            return self._get_row_centers(ngrams)
        elif location == RIGHT:
            return self._get_row_rights(ngrams)
        elif location == TOP:
            return self._get_row_tops(ngrams)
        elif location == MIDDLE:
            return self._get_row_middles(ngrams)
        elif location == BOTTOM:
            return self._get_row_bottoms(ngrams)
        else:
            raise ValueError(f"Invalid location for _get_row_locations: {location}")
