import os
import uuid
from cProfile import Profile
from functools import wraps
from pstats import Stats, add_func_stats, func_std_string  # type: ignore
from typing import Any, Callable, Dict, Tuple

from line_profiler import LineProfiler

from snorkelflow.utils.file import resolve_data_path

DEFAULT_OUTPUT_DIR = "profiles/"


def _get_output_dir() -> str:
    output_dir = resolve_data_path(f"minio://{DEFAULT_OUTPUT_DIR}")
    os.makedirs(os.path.dirname(output_dir), exist_ok=True)
    return output_dir


def process_fn(lp: LineProfiler, p: Profile) -> None:
    # Generate a random id for each function call profile
    function_id = str(uuid.uuid4().hex.upper())[0:4]
    output_dir = _get_output_dir()
    filepath = f"{function_id}.prof"

    print(f"----- FUNCTION ID: {function_id} -----")
    lp.print_stats(output_unit=0.001)
    p.create_stats()

    stats = Stats(p)
    stats.stats = _trim_dirs(stats.stats)  # type:ignore
    stats.dump_stats(f"{output_dir}{filepath}")

    print(f"{output_dir}{filepath}")
    print(f"--------Flamegraph Profile ------------")
    print(
        f"To view a flamegraph with call stack details, run:\n\n./strap profile --id {function_id}"
    )
    print("\n---------------------------------------")


def profile(func: Callable) -> Callable:
    """Decorator that reports the execution time per line.
    Usage: @profile before any function definition. This will output to stdout (visible in logs)
    """

    # Using functools.wraps to get this to work with FastAPI routers
    @wraps(func)
    def wrap(*args: Any, **kwargs: Any) -> Any:
        lp = LineProfiler(func)
        p = Profile()
        with lp:
            p.enable()
            try:
                result = func(*args, **kwargs)
            finally:
                p.disable()
                process_fn(lp, p)
        return result

    return wrap


def _remove_before(prev: str, target: str) -> str:
    """Remove everything before the target string"""
    idx = prev.find(target)
    if idx != -1:
        return prev[idx + len(target) :]
    return prev


def _trim_binary_path(func_name: Tuple[str, int, str]) -> Tuple[str, int, str]:
    """This is a modified version of a function from pstat.py, that is tuned for
    strap / docker configurations specifically (where without this, we end up with a really
    long function definition in the output profile)
    """
    filename, line, name = func_name
    filename = _remove_before(filename, "src/python")
    filename = _remove_before(filename, "test/python")
    filename = _remove_before(filename, ".runfiles")

    return filename, line, name


def _trim_dirs(stats: Dict[Any, Any]) -> Dict[Any, Any]:
    """
    This is a modified function (based on strip_dirs()) from pstats.py. The
    goal here is to strip out the useless information while keeping the useful parts
    """
    oldstats = stats
    newstats: Dict[Any, Any] = {}
    max_name_len = 0
    for func, (cc, nc, tt, ct, callers) in oldstats.items():
        newfunc = _trim_binary_path(func)
        if len(func_std_string(newfunc)) > max_name_len:
            max_name_len = len(func_std_string(newfunc))
        newcallers = {}
        for func2, caller in callers.items():
            newcallers[_trim_binary_path(func2)] = caller

        if newfunc in newstats:
            newstats[newfunc] = add_func_stats(
                newstats[newfunc], (cc, nc, tt, ct, newcallers)
            )
        else:
            newstats[newfunc] = (cc, nc, tt, ct, newcallers)
    return newstats
