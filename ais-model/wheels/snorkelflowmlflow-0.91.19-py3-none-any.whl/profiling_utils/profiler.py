import contextlib
import datetime
import json
import os
import re
import sys
import threading
import time
import traceback
from enum import Enum
from pathlib import Path
from types import FrameType
from typing import Any, Dict, List, Optional, Tuple

import re2
import redis

from snorkelflow.config.constants import ServiceType
from snorkelflow.utils.logging import get_logger

_PROFILING_THREAD_NAME = "Profiling Thread"

REDIS_POLL_INTERVAL: float = 10.0
PROFILE_FLUSH_INTERVAL: float = 5.0

logger = get_logger("CPUProfiler")


class ProfileType(Enum):
    cpu = 1
    memory = 2


class PersistenceMode(str, Enum):
    disk = "disk"
    inmemory = "inmemory"


def get_service_profiler_key(service: str, profile_type: ProfileType) -> str:
    return f"{service}-{profile_type.name}-profile"


def get_persistence_key(service: str, profile_type: ProfileType) -> str:
    return f"persistence-mode-{service}-{profile_type.name}"


def get_profile_dir(data_path: Path, service: str, profile_type: ProfileType) -> Path:
    return Path(f"{data_path}/.profile/{profile_type.name}/{service}")


def get_profiling_status(
    cache: redis.Redis, service: str, profile_type: ProfileType
) -> str:
    """
    Returns if the profiling status is enabled or disabled
    """
    return (
        "disabled"
        if not cache.get(get_service_profiler_key(service, profile_type))
        else "enabled"
    )


def _find_frame(nodes: List[Dict[str, Any]], frame: str) -> Optional[Dict[str, Any]]:
    for node in nodes:
        if node["name"] == frame:
            return node
    return None


def _collapsed_stacktrace_to_tree(collapsed_stack_trace: str) -> Dict[str, Any]:
    backtraces = collapsed_stack_trace.split("\n")
    final_dict: Dict[str, Any] = {"name": "root", "value": 0, "children": []}
    for bt in backtraces:
        bt, c, _ = re.split(r"\s+(\d+$)", bt)
        count = int(c)
        frames = bt.split(";")
        parent = final_dict
        parent["value"] += count
        for frame in frames:
            node = _find_frame(parent["children"], frame)
            if not node:
                node = {"name": frame, "value": 0, "children": []}
                parent["children"].append(node)
            node["value"] += count
            parent = node
    return final_dict


def convert_collapsed_stacktrace_to_tree(
    collapsed_stacktraces_dict: Dict[str, str]
) -> Dict[str, Any]:
    return {
        key: _collapsed_stacktrace_to_tree(value)
        for key, value in collapsed_stacktraces_dict.items()
    }


def enable_profiling(
    cache: redis.Redis,
    service: str,
    profile_type: ProfileType,
    data_path: Optional[Path] = None,
    ttl_secs: int = 600,
    persistence_mode: Optional[PersistenceMode] = None,
) -> bool:
    """
    Enables the Statistical profiler for the given TTL seconds
    The default is 600 seconds
    """
    clear_profile_stacktrace(cache, service, profile_type, data_path)
    if persistence_mode and not bool(
        cache.set(
            get_persistence_key(service, profile_type),
            persistence_mode.name,
            ex=ttl_secs,
        )
    ):
        return False
    return bool(
        cache.set(
            get_service_profiler_key(service, profile_type), "enabled", ex=ttl_secs
        )
    )


def disable_profiling(
    cache: redis.Redis, service: str, profile_type: ProfileType
) -> bool:
    """
    Disable the statistical profiler
    """
    persistence_key = get_persistence_key(service, profile_type)
    if cache.exists(persistence_key) and not bool(cache.delete(persistence_key)):
        return False
    return bool(cache.delete(get_service_profiler_key(service, profile_type)))


def clear_profile_stacktrace(
    cache: redis.Redis,
    service: str,
    profile_type: ProfileType,
    data_path: Optional[Path] = None,
) -> bool:
    """
    Clear profiling stacktrace for a given service.
    """
    if data_path:
        profile_dir = get_profile_dir(
            data_path=data_path, service=service, profile_type=profile_type
        )
        for profile in profile_dir.glob("*"):
            try:
                os.unlink(profile)
            except FileNotFoundError:
                filename, _ = os.path.splitext(profile)
                with contextlib.suppress(FileNotFoundError):
                    os.unlink(f"{filename}.prof")
    cache.delete(f"{service}-{profile_type.name}-stacktrace")
    return True


def get_profile_stacktrace(
    cache: redis.Redis,
    service: str,
    profile_type: ProfileType,
    data_path: Optional[Path] = None,
) -> Dict[str, str]:
    """
    get_profile_stacktrace - Fetches the profile trace from the redis
    """
    # Lets try to fetch from disk first if the profile dir exists
    return_dict: Dict[str, Any] = dict()
    if data_path:
        profile_dir = get_profile_dir(
            data_path=data_path, service=service, profile_type=profile_type
        )
        if profile_dir.exists():
            for profile in profile_dir.glob("*.prof"):
                with open(profile) as f:
                    # File can contain multiple json objects.
                    if profile_type == ProfileType.memory:
                        for line in f:
                            service_profile = json.loads(line)
                            return_dict.update(service_profile)
                    else:
                        service_profile = json.load(f)
                        return_dict.update(service_profile)

    stacktrace_hash_key = f"{service}-{profile_type.name}-stacktrace"
    stacktraces = cache.hgetall(stacktrace_hash_key)
    if stacktraces:
        redis_dict = {k.decode(): v.decode() for k, v in stacktraces.items()}
        return_dict.update(redis_dict)
    return return_dict


def _get_thread_name(thread_id: int) -> str:
    """
    Returns the name of the thread given a thread identifier
    """
    thread_name = str(thread_id)
    for th in threading.enumerate():
        if th.ident == thread_id:
            thread_name = th.getName()
    return thread_name


def is_profiling_thread_running() -> bool:
    thread_names = [
        _get_thread_name(thread_id) for thread_id, _ in sys._current_frames().items()
    ]
    return _PROFILING_THREAD_NAME in thread_names


class PATH_TYPE(Enum):
    STRAP = 0
    PYPI = 1
    SYSTEM = 2


# according to the stacktraces, we mainly have 3 types of file paths
# 1. strap path: /app/src/python/{service path}/py_image.binary.runfiles/strap/...
# 2. pypi path: /app/src/python/{service path}/py_image.binary.runfiles/pypi__38__...
# 3. system path: /usr/lib/python3.8/...
# for 1, we print the path after strap
# for 2, we print the library name + version and paths after that
# for 3, we print the system path after the python directory and prepend a SYSTEM flag
# to indicate it is a system path
def _build_truncate_file_regexes(
    prefix: str = "/app/src/python", system_lib_prefix: str = "/usr/lib"
) -> Dict[PATH_TYPE, re2.Pattern]:
    escaped_prefix = re2.escape(prefix.rstrip("/"))
    escaped_system_lib_prefix = re2.escape(system_lib_prefix.rstrip("/"))
    return {
        PATH_TYPE.STRAP: re2.compile(
            f"{escaped_prefix}/.+/py_image\.binary\.runfiles/strap/"
        ),
        PATH_TYPE.PYPI: re2.compile(
            f"{escaped_prefix}/.+/py_image\.binary\.runfiles/pypi__\d+__"
        ),
        PATH_TYPE.SYSTEM: re2.compile(f"{escaped_system_lib_prefix}/python\d\.\d+/"),
    }


PATH_PATTERNS = _build_truncate_file_regexes()


def get_output_filepath(
    file_path: str, path_patterns: Dict[PATH_TYPE, re2.Pattern]
) -> str:
    for path_type, path_pattern in path_patterns.items():
        path_match = path_pattern.match(file_path)
        if path_match is not None:
            if path_type == PATH_TYPE.STRAP or path_type == PATH_TYPE.PYPI:
                return file_path[path_match.end() :]
            elif path_type == PATH_TYPE.SYSTEM:
                return f"SYSTEM::{file_path[path_match.end(): ]}"
    logger.debug(f"Cannot find a match with existing path types: {file_path}")
    return file_path


class CPUProfilerThread(threading.Thread):
    """
    A Statistical profiler thread. This thread periodically
    samples the backtrace of all the threads in the process.
    The sampled backtrace is then serialized, aggregated and periodically written to Redis.
    The overall operation is lightweight
    """

    def __init__(
        self,
        service: ServiceType,
        cache: redis.Redis,
        enabled: bool = True,
        data_path: Optional[Path] = None,
        profile_sampling_interval_secs: float = 0.1,
        redis_poll_interval_secs: Optional[float] = None,
        profile_flush_interval_secs: Optional[float] = None,
        profile_results_ttl_secs: float = 600,
        dask_clusters: Optional[List[Tuple[str, Any]]] = None,
    ) -> None:
        if dask_clusters is None:
            dask_clusters = []
        threading.Thread.__init__(self, name=_PROFILING_THREAD_NAME, daemon=True)
        logger.info("Initializing profiler thread")
        self.daemon = True
        self.enabled = enabled
        self.profile_sampling_interval_secs = profile_sampling_interval_secs
        self.thread_stacks_dict: Dict[str, List[List[str]]] = {}
        self.max_profile_stacks = 200  # We should be good with this
        self.cache = cache
        self.redis_poll_interval_secs = (
            redis_poll_interval_secs
            if redis_poll_interval_secs
            else REDIS_POLL_INTERVAL
        )
        self.service_profile_hash_key = get_service_profiler_key(
            service, ProfileType.cpu
        )
        self.stacktrace_hash_key = f"{service}-{ProfileType.cpu.name}-stacktrace"
        self.process_hash_key = f"{os.environ.get('POD_NAME', service)}-{os.getpid()}"
        self.flush_interval_secs = (
            profile_flush_interval_secs
            if profile_flush_interval_secs
            else PROFILE_FLUSH_INTERVAL
        )
        self.profile_results_ttl_secs = (
            600 if profile_results_ttl_secs <= 10 else profile_results_ttl_secs
        )

        self.dask_clusters = dask_clusters
        self.filter_idle_stacks = True
        self.profile_dir: Optional[Path] = None
        self.profile_filepath: Optional[Path] = None

        if data_path and data_path.exists():
            self.profile_dir = get_profile_dir(data_path, service, ProfileType.cpu)
            self.profile_dir.mkdir(parents=True, exist_ok=True)
            self.profile_filepath = Path(
                f"{self.profile_dir}/{self.process_hash_key}.prof"
            )

    def is_enabled(self) -> bool:
        return self.enabled

    def _get_collapsed_stack(self, thread_name: str, frame: Optional[FrameType]) -> str:
        """
        Returns the collapsed stack for a given frame.
        * Collapses recursion scenarios.
        * Limits the stacktrace to 100 frames
        * Eliminates idle worker stack frames by default
        """
        last_function = ""
        stack_list = []

        stacks = traceback.extract_stack(frame, limit=100)  # Limit the stacks to 100

        if self.filter_idle_stacks:
            _, _, function_name, _ = stacks[-1]
            # Filter out Idle stacks from the profile
            if (
                function_name == "_worker"
                or (thread_name == "MainThread" and function_name == "run")
                or (thread_name == "MainThread" and function_name == "select")
            ):
                return ""

        for filename_path, line_no, function_name, _ in stacks:
            fname = get_output_filepath(filename_path, PATH_PATTERNS)
            if function_name != last_function:
                stack_list.append(
                    f"{thread_name[:20]}::{function_name[:50]}::({fname}::{line_no})"
                )

            last_function = function_name

        return ";".join(stack_list)

    def sample_current_frames(self, current_thread_id: Optional[int]) -> None:
        """
        Samples the current frames of all the threads in the process.
        It ignores the current sampling thread id or threads with name - PROFILING_THREAD_NAME
        """
        stack_list: List[str] = []
        for thread_id, frame in sys._current_frames().items():
            if thread_id == current_thread_id:
                continue
            thread_name = _get_thread_name(thread_id)
            if thread_name == _PROFILING_THREAD_NAME:
                continue

            collapsed_stack = self._get_collapsed_stack(
                _get_thread_name(thread_id), frame
            )
            if collapsed_stack:
                stack_list.append(collapsed_stack)

        if self.process_hash_key not in self.thread_stacks_dict:
            self.thread_stacks_dict[self.process_hash_key] = []

        self.thread_stacks_dict[self.process_hash_key].append(stack_list)

    # Format: tuple of strings, each string is of the form
    # File [file], line [lineno], in [func_name]\n\t[line]
    def format_dask_call_stack_line(self, call_stack: str) -> Tuple[str, str, str]:
        filename_path, line_no, function_name = re.findall(
            '\s*File\s"(.+)", line (\d+), in (.+)', call_stack
        )[0]
        return (str(filename_path), str(line_no), str(function_name))

    def sample_dask_workers(self) -> None:
        for cluster_id, client in self.dask_clusters:
            # NOTE: client.profile() is broken for a variety of reasons,
            # namely off-by-one errors and incorrect merging of stacktraces.
            # Instead, we obtain client callstacks directly, and construct
            # flamegraph-ready profiles from them.
            cluster_id_key = f"{self.process_hash_key}_{cluster_id}"
            if not client.status == "running":
                continue

            call_stacks = client.call_stack()
            if not call_stacks:
                continue
            call_stacks = call_stacks[list(call_stacks.keys())[0]]

            # There may be multiple call stacks for each client, depending on
            # the processes mapped to it. We get all associated call stacks.
            overall_stack_list = []
            for key in call_stacks:
                key_call_stack_formatted = [
                    self.format_dask_call_stack_line(line) for line in call_stacks[key]
                ]

                stack_list = []
                last_function = ""
                for filename_path, line_no, function_name in key_call_stack_formatted:
                    fname = get_output_filepath(filename_path, PATH_PATTERNS)
                    if function_name != last_function:
                        stack_list.append(
                            f"{key[:20]}::{function_name[:50]}::({fname}::{line_no})"
                        )
                    last_function = function_name

                key_call_stack_collapsed = ";".join(stack_list)
                if key_call_stack_collapsed:
                    overall_stack_list.append(key_call_stack_collapsed)

            if cluster_id_key not in self.thread_stacks_dict:
                self.thread_stacks_dict[cluster_id_key] = []

            # Add this current sample's thread stack to thread_stack_dict[cluster_id]
            self.thread_stacks_dict[cluster_id_key].append(overall_stack_list)

    def flush_to_redis(self) -> None:
        """
        Flushes the aggregated stacks to Redis
        """
        aggregated_stacks = self.aggregate_stacks()
        if aggregated_stacks:
            self.cache.delete(self.stacktrace_hash_key)
            for k in aggregated_stacks:
                self.cache.hset(
                    self.stacktrace_hash_key, k, aggregated_stacks[k].encode()
                )
            self.cache.expire(
                self.stacktrace_hash_key, int(self.profile_results_ttl_secs)
            )

    def flush_to_disk(self) -> None:
        """
        Flushes the aggregated stacks to Filesystem
        """
        aggregated_stacks = self.aggregate_stacks()
        if self.profile_filepath:
            tmp_path = Path(f"{self.profile_filepath}_{int(time.time())}")
            with open(tmp_path, "w") as fp:
                json.dump(aggregated_stacks, fp)

            # Now rename to atomically replace the content.
            with contextlib.suppress(FileNotFoundError):
                os.rename(tmp_path, self.profile_filepath)

    def start(self) -> None:
        if self.enabled:
            logger.info(f"Starting Profiler thread for {self.service_profile_hash_key}")
            super().start()

    def flush(self) -> None:
        if self.profile_filepath:
            self.flush_to_disk()
        else:
            self.flush_to_redis()

    def _process(self, current_thread_id: Optional[int]) -> None:
        profile_status_enabled = self.cache.get(self.service_profile_hash_key)

        if profile_status_enabled:
            logger.info("Beginning CPU profile")
            next_flush_time = time.time() + self.flush_interval_secs
            self.thread_stacks_dict = {}

        # Start periodic sampling of backtrace
        while profile_status_enabled:
            self.sample_current_frames(current_thread_id)
            self.sample_dask_workers()

            for k in self.thread_stacks_dict:
                if len(self.thread_stacks_dict[k]) > self.max_profile_stacks:
                    self.thread_stacks_dict[k] = self.thread_stacks_dict[k][1:]

            time.sleep(self.profile_sampling_interval_secs)
            profile_status_enabled = self.cache.get(self.service_profile_hash_key)

            # Flush to redis if the profiling is disabled or we are past the
            # periodic flush interval.
            if not profile_status_enabled:
                logger.info("Ending CPU profile")
                break

            if time.time() > next_flush_time:
                self.flush()
                next_flush_time = time.time() + self.flush_interval_secs

    def run(self) -> None:
        current_thread_id = threading.current_thread().ident
        while True:
            time.sleep(self.redis_poll_interval_secs)
            self._process(current_thread_id)

    def _aggregate_stacks_helper(self, thread_stacks: List[List[str]]) -> str:
        stack_count_dict: Dict[str, int] = {}
        for stacks in thread_stacks:
            for stack in stacks:
                stack_count_dict[stack] = stack_count_dict.setdefault(stack, 0) + 1

        return "\n".join(
            ["{} {}".format(key, value) for key, value in stack_count_dict.items()]
        )

    def aggregate_stacks(self) -> Dict[str, str]:
        """
        Aggregates the collected backtrace and returns stack aggregation as string
        """
        return {
            f"{k}_{datetime.datetime.utcnow()}": self._aggregate_stacks_helper(v)
            for k, v in self.thread_stacks_dict.copy().items()
        }
