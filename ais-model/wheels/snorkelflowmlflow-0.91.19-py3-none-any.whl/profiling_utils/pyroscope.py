import contextlib
import os
from typing import Any, Dict, Iterator

import pyroscope

from api_utils.config import get_env_var, get_service_type
from snorkelflow.utils.logging import get_logger

logger = get_logger("pyroscope")
PYROSCOPE_SERVER_URL = get_env_var("PYROSCOPE_SERVER_URL")


def configure_pyroscope() -> None:
    if not PYROSCOPE_SERVER_URL:
        logger.warning(
            "Pyroscope server url not set. Skipping pyroscope configuration."
        )
        return

    service_type = get_service_type()
    service = service_type.value if service_type else "unknown"

    application_name, server_address = PYROSCOPE_SERVER_URL.split("@", 1)

    logger.info(f"Starting pyroscope with application name {application_name}")
    pyroscope.configure(
        application_name=application_name,
        # We currently do not bootstrap this in-cluster. Right now we use an external server, or a local server.
        # docker run -it -p 4040:4040 pyroscope/pyroscope:latest server
        server_address=server_address,
        detect_subprocesses=True,
        sample_rate=100,
        # Figure out why this crashes when set to True
        native=False,
        report_pid=True,
        # Figure out how to make it use our logger
        enable_logging=False,
        tags={"pod": os.environ.get("HOSTNAME", "n/a"), "service": service},
        # Ignore idle threads
        # This should actually be true, but due to a bug it's vice-versa
        # https://github.com/pyroscope-io/pyroscope-rs/issues/58
        oncpu=False,
        gil_only=False,
        # Too noisy for real usage
        report_thread_id=False,
        report_thread_name=False,
    )


# https://github.com/pyroscope-io/pyroscope-rs/issues/70
@contextlib.contextmanager
def pyroscope_tag_wrapper(tags: Dict[str, Any]) -> Iterator[None]:
    yield


def pyroscope_add_thread_tag(tag_key: str, tag_value: str) -> None:
    pass


def pyroscope_remove_thread_tag(tag_key: str, tag_value: str) -> None:
    pass
