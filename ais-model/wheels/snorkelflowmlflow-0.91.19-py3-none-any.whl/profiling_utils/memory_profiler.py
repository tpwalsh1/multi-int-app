import json
import linecache
import os
import threading
import time
import tracemalloc
from datetime import datetime
from pathlib import Path
from typing import List, Optional

from redis import Redis

from profiling_utils.profiler import (
    PersistenceMode,
    ProfileType,
    get_persistence_key,
    get_profile_dir,
    get_service_profiler_key,
)
from snorkelflow.utils.logging import get_logger

logger = get_logger("snorkelflow")

_MEMORY_PROFILING_THREAD_NAME = "Memory Profiling Thread"
REDIS_POLL_INTERVAL: float = 1.0
PROFILE_FLUSH_INTERVAL: float = 5.0


def get_tracemalloc_profile(top_k: int = 5, depth: int = 20) -> str:
    snapshot = tracemalloc.take_snapshot()
    snapshot = snapshot.filter_traces(
        (
            tracemalloc.Filter(False, "*profiler.py", all_frames=True),
            tracemalloc.Filter(
                False, "*<frozen importlib._bootstrap>*", all_frames=True
            ),
        )
    )
    top_stats = snapshot.statistics("traceback")[:top_k]
    results = [f"Time: {datetime.now()}"]
    for stat in top_stats:
        results.append(
            "\n".join(
                [
                    f"Size: {stat.size/1000000} MB",
                    f"Count: {stat.count}",
                    "Trace:",
                    "\n".join(format_traceback(stat.traceback)[:depth]),
                ]
            )
        )
    return "\n\n".join(results)


def format_traceback(t: tracemalloc.Traceback) -> List[str]:
    lines = []
    for frame in t:
        line = linecache.getline(frame.filename, frame.lineno).strip()
        lines.append(
            '  File "%s":line %s: %s'
            % (
                os.sep.join(frame.filename.split(os.sep)[-2:]),
                frame.lineno,
                line if line else "",
            )
        )
    return lines


class MemoryProfilerThread(threading.Thread):
    def __init__(
        self,
        service: str,
        cache: Redis,
        enabled: bool = True,
        data_path: Optional[Path] = None,
        profile_sampling_interval_secs: float = 1.0,
        redis_poll_interval_secs: Optional[float] = None,
        profile_flush_interval_secs: Optional[float] = None,
        profile_results_ttl_secs: float = 600,
        # Max profiles per process limited to 10MB.
        max_data_size: int = 1_000_000_0,
        # Max redis keys limited to 10000.
        # Each key denotes 50 samples, with sampling frequency 0.1s and flush frequency 5s.
        max_redis_keys: int = 1000,
    ) -> None:
        threading.Thread.__init__(self, name=_MEMORY_PROFILING_THREAD_NAME, daemon=True)
        logger.info("Initializing memory profiler thread")
        self.daemon = True
        self.enabled = enabled
        self.profile_sampling_interval_secs = profile_sampling_interval_secs
        self.mem_stacks: List[str] = []
        self.cache = cache
        self.redis_poll_interval_secs = (
            redis_poll_interval_secs
            if redis_poll_interval_secs
            else REDIS_POLL_INTERVAL
        )
        self.service_profile_hash_key = get_service_profiler_key(
            service, ProfileType.memory
        )
        self.persistence_mode_key = get_persistence_key(service, ProfileType.memory)
        self.stacktrace_hash_key = f"{service}-{ProfileType.memory.name}-stacktrace"
        self.process_hash_key = f"{os.environ.get('POD_NAME', service)}-{os.getpid()}"
        self.flush_interval_secs = (
            profile_flush_interval_secs
            if profile_flush_interval_secs
            else PROFILE_FLUSH_INTERVAL
        )
        self.profile_results_ttl_secs = (
            600 if profile_results_ttl_secs <= 10 else profile_results_ttl_secs
        )
        self.profile_dir: Optional[Path] = None
        self.profile_filepath: Optional[Path] = None

        if data_path and data_path.exists():
            self.profile_dir = get_profile_dir(data_path, service, ProfileType.memory)
            self.profile_dir.mkdir(parents=True, exist_ok=True)
            self.profile_filepath = Path(f"{self.profile_dir}/{self.process_hash_key}")
        self.max_data_size = max_data_size
        self.is_cancelled = False
        self.max_redis_keys = max_redis_keys
        logger.info(
            f"Initializing memory profiler thread flush_interval={self.flush_interval_secs} redis_poll_interval={self.redis_poll_interval_secs}"
        )

    def is_enabled(self) -> bool:
        return self.enabled

    def flush_to_redis(self) -> None:
        """
        Flushes the aggregated stacks to Redis
        """
        aggregated_stacks = self.aggregate_stacks()
        if (
            aggregated_stacks
            and self.cache.hlen(self.stacktrace_hash_key) < self.max_redis_keys
        ):
            self.cache.hset(
                self.stacktrace_hash_key,
                self.process_hash_key
                + "  "
                + datetime.now().strftime("%d/%m/%Y %H:%M:%S"),
                aggregated_stacks.encode(),
            )
            self.cache.expire(
                self.stacktrace_hash_key, int(self.profile_results_ttl_secs)
            )

    def flush_to_disk(self) -> None:
        """
        Flushes the aggregated stacks to Filesystem
        """
        if self.profile_filepath:
            filename = f"{self.profile_filepath}.prof"

            with open(filename, "a") as fp:
                if os.fstat(fp.fileno()).st_size >= self.max_data_size:
                    logger.warn(
                        "Appending memory profile to a file larger than max size. Skipping...."
                    )
                    return
                json.dump(
                    {
                        self.process_hash_key
                        + "  "
                        + datetime.now().strftime(
                            "%d/%m/%Y %H:%M:%S"
                        ): self.aggregate_stacks()
                    },
                    fp,
                )
                fp.write("\n")

    def start(self) -> None:
        if self.enabled:
            logger.info(
                f"Starting Memory Profiler thread for {self.service_profile_hash_key}"
            )
            super().start()

    def flush(self, persistence_mode: str) -> None:
        if not self.mem_stacks:
            logger.error("Zero stack size. Skip flushing...")
            return
        if self.profile_filepath and persistence_mode == PersistenceMode.disk.name:
            self.flush_to_disk()
        else:
            self.flush_to_redis()

    def sample_memory_trace(self) -> None:
        self.mem_stacks.append(get_tracemalloc_profile())

    def process(self) -> None:
        profile_status_enabled = self.cache.get(self.service_profile_hash_key)
        # Default to disk if no value provided
        persistence_mode = (
            self.cache.get(self.persistence_mode_key) or PersistenceMode.disk.name
        )

        if not profile_status_enabled:
            return
        next_flush_time = time.time() + self.flush_interval_secs

        tracemalloc.start(25)
        # Start periodic sampling of backtrace
        while profile_status_enabled:
            self.sample_memory_trace()
            time.sleep(self.profile_sampling_interval_secs)
            profile_status_enabled = self.cache.get(self.service_profile_hash_key)
            # Flush to redis if the profiling is disabled or we are past the
            # periodic flush interval.
            if (not profile_status_enabled) or time.time() > next_flush_time:
                self.flush(persistence_mode)
                self.mem_stacks.clear()
                next_flush_time = time.time() + self.flush_interval_secs

        tracemalloc.stop()

    def run(self) -> None:
        while True:
            time.sleep(self.redis_poll_interval_secs)
            self.process()
            if self.is_cancelled:
                break

    def aggregate_stacks(self) -> str:
        """
        Aggregates the collected backtrace and returns stack aggregation as string
        """
        result = "\n\n ----------------- \n\n".join(self.mem_stacks)
        return result
