import time
from typing import Any, Dict, List, Type

import pandas as pd

from embeddings.base import EmbeddingGenerator
from snorkelflow.models.image import CLIPImageEncoder
from snorkelflow.operators.featurizer import OpProgressCallback, no_op_progress_callback
from snorkelflow.utils.logging import get_logger

logger = get_logger("image embeddings")


class CLIPImageGenerator(EmbeddingGenerator):
    def __init__(self, model: CLIPImageEncoder) -> None:
        self.model = model

    @classmethod
    def from_config(cls, **kwargs: Any) -> "CLIPImageGenerator":
        model = CLIPImageEncoder()
        return CLIPImageGenerator(model)

    def evaluate(
        self, data: pd.Series, callback: OpProgressCallback = no_op_progress_callback
    ) -> List[List[float]]:
        start_time = time.time()
        embeddings = self.model.featurize(image_paths=data.tolist(), callback=callback)
        logger.info(
            f"CLIP text embeddings took {time.time() - start_time} s to process {len(data)} inputs"
        )
        return embeddings

    @classmethod
    def get_embedding_dims(cls, **kwargs: Any) -> int:
        return 512


def _compute_clip_embeddings(
    image_paths: pd.Series, callback: OpProgressCallback = no_op_progress_callback
) -> List[List[float]]:
    gene = CLIPImageGenerator.from_config()
    return gene.evaluate(image_paths, callback)


EMBEDDING_CLASSES: Dict[str, Type[EmbeddingGenerator]] = {"clip": CLIPImageGenerator}

EMBEDDING_FNS = {"clip": _compute_clip_embeddings}
