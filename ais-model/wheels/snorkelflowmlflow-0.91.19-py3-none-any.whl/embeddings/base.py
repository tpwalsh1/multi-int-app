from abc import ABC, abstractmethod
from typing import Any, Iterable

import numpy as np
import pandas as pd
import pyarrow as pa

from snorkelflow.operators.featurizer import OpProgressCallback, no_op_progress_callback


class EmbeddingGenerator(ABC):
    @classmethod
    @abstractmethod
    def from_config(cls, **kwargs: Any) -> "EmbeddingGenerator":
        pass

    @abstractmethod
    def evaluate(
        self, data: pd.Series, callback: OpProgressCallback = no_op_progress_callback
    ) -> Iterable:
        pass

    @classmethod
    @abstractmethod
    def get_embedding_dims(cls, **kwargs: Any) -> int:
        pass

    @classmethod
    def get_schema(cls, **kwargs: Any) -> pa.Schema:
        schema_df = pd.DataFrame.from_records(
            [(np.ones((1,), dtype=float),)],
            index=["doc::1"],
            columns=["embeddings"],
        )
        return pa.Schema.from_pandas(schema_df)

    @classmethod
    def generate_chunk(
        cls, embeddings: Iterable, sub_batch_df: pd.DataFrame, schema: pa.Schema
    ) -> pa.RecordBatch:
        return pa.record_batch(
            [
                pa.array(
                    embeddings,
                    type=schema.field("embeddings").type,
                ),
                pa.array(sub_batch_df.index, type=pa.string()),
            ],
            schema=schema,
        )
