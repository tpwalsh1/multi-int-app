import time
from typing import List, Optional, Union

import numpy as np

from snorkelflow.utils.logging import get_logger
from snorkelflow.utils.system import is_gpu_available

logger = get_logger("embedding similarity")


def _compute_cosine_similarity(
    embedding_1: Union[np.ndarray, List[List[float]]],
    embedding_2: Union[np.ndarray, List[List[float]]],
    device: Optional[str] = None,
) -> np.ndarray:
    import torch

    if device is None:
        device = "cuda" if is_gpu_available() else "cpu"

    with torch.no_grad():
        t1 = torch.Tensor(embedding_1)[:, None].to(device)
        t2 = torch.Tensor(embedding_2)[None, :].to(device)

        start_time = time.time()
        similarities: torch.Tensor = torch.nn.functional.cosine_similarity(
            t1, t2, dim=-1
        )
        logger.info(
            f"Cosine similarity comparator took {time.time() - start_time} s to process {len(embedding_1)}x{len(embedding_2)} features on device '{device}'"
        )
        result = similarities.cpu().numpy()

    return result


METRIC_FNS = {"cosine_similarity": _compute_cosine_similarity}
