from __future__ import annotations

import time
from functools import partial
from typing import TYPE_CHECKING, Any, Callable, Dict, Iterable, List, Tuple, Type

import pandas as pd
import pyarrow as pa
import torch
from filelock import FileLock, Timeout
from pydantic import BaseModel
from transformers import AutoModel, AutoTokenizer

from api_utils.exceptions import SnorkelException
from embeddings.base import EmbeddingGenerator
from snorkelflow.models.image import CLIPTextEncoder
from snorkelflow.models.model_configs import HFCacheSettings
from snorkelflow.operators.featurizer import OpProgressCallback, no_op_progress_callback
from snorkelflow.utils.logging import get_logger
from snorkelflow.utils.system import is_gpu_available

if TYPE_CHECKING:
    import spacy

logger = get_logger("TextEmbeddings")

NLP: Any = None
MODEL_LOCK = f"/tmp/hg-model-lock"
TOKENIZER_LOCK = f"/tmp/hg-tokenizer-lock"
LOCK_TIMEOUT = 60

RAG_EMBEDDINGS_FIELD = "__rag_embeddings"
RAG_CHAR_STARTS_FIELD = "__rag_char_starts"
RAG_LENGTHS_FIELD = "__rag_lengths"
RAG_EMBEDDINGS = "RAG embeddings"


def maybe_get_local_file(loading_func: Callable) -> Any:
    """
    Attempts to load a local file using the provided loading function.

    Parameters
    ----------
    loading_func : Callable
        A function that attempts to load a file, typically a model or tokenizer, with an argument to force local file loading.

    Returns
    -------
    Any
        The loaded local file if successful, otherwise None.
    """
    try:
        local_file = loading_func(local_files_only=True)
    except Exception:
        return None
    return local_file


def read_huggingface_asset(
    lock: str, timeout: int, loading_func: Callable, model_name: str
) -> Any:
    """
    Safely loads a Hugging Face asset, using a file lock to ensure that concurrent processes do not interfere with each other.

    Parameters
    ----------
    lock : str
        The file path used for locking.
    timeout : int
        The maximum time to wait for the lock before timing out.
    loading_func : Callable
        A function to load the asset, either from a local cache or by downloading.
    model_name : str
        The name of the model to load.

    Returns
    -------
    Any
        The loaded asset.

    Raises
    ------
    SnorkelException
        If the asset cannot be loaded within the timeout period.
    """
    local_file = maybe_get_local_file(loading_func)
    if local_file is None:
        try:
            with FileLock(lock, timeout=timeout):
                logger.info(f"Acuired FileLock for HuggingFace asset {model_name}")
                local_file = maybe_get_local_file(loading_func)
                if local_file is None:
                    logger.info(
                        f"Performing nonlocal load for HuggingFace asset {model_name}"
                    )
                    return loading_func()
        except Timeout:
            logger.info(f"lock '{lock}' has not been released")
            msg = (
                f"Fail to download pretrained model from huggingface.co due to Timeout."
                f" Please try again later. Model: {model_name}."
            )
            raise SnorkelException(detail=msg, user_friendly_message=msg)
    return local_file


class SimcseGenerator(EmbeddingGenerator):
    def __init__(
        self, tokenizer: AutoTokenizer, model: AutoModel, device: torch.device
    ) -> None:
        self.tokenizer = tokenizer
        self.model = model
        self.device = device

    @classmethod
    def from_config(
        cls,
        model_name: str = "princeton-nlp/unsup-simcse-bert-base-uncased",
        **kwargs: Any,
    ) -> "SimcseGenerator":
        model_device = torch.device("cuda" if is_gpu_available() else "cpu")
        tokenizer = read_huggingface_asset(
            TOKENIZER_LOCK,
            LOCK_TIMEOUT,
            partial(
                AutoTokenizer.from_pretrained,
                model_name,
                cache_dir=HFCacheSettings.PRETRAINED_CACHE_DIR,
                revision=HFCacheSettings.REVISIONS[model_name],
            ),
            model_name,
        )
        model = read_huggingface_asset(
            MODEL_LOCK,
            LOCK_TIMEOUT,
            partial(
                AutoModel.from_pretrained,
                model_name,
                cache_dir=HFCacheSettings.PRETRAINED_CACHE_DIR,
                revision=HFCacheSettings.REVISIONS[model_name],
            ),
            model_name,
        ).to(model_device)
        return SimcseGenerator(tokenizer, model, model_device)

    def evaluate(
        self, data: pd.Series, callback: OpProgressCallback = no_op_progress_callback
    ) -> List[List[float]]:
        import torch

        texts_list = [x or "" for x in data.tolist()]

        # encode only uses the first 512 chars of the string. We can make
        # this more sophisticated by processed 512-sied chunks and averging
        # their embeddings.
        embeddings: List[List[float]] = []
        batch_size = (
            16  # any larger, and we risk running out of memory on EC2 dev instances
        )
        for start in range(0, len(texts_list), batch_size):
            end = min(len(texts_list), start + batch_size)
            inputs = self.tokenizer(
                texts_list[start:end],
                padding=True,
                truncation=True,
                return_tensors="pt",
            )
            start_time = time.time()
            with torch.no_grad():
                inputs = inputs.to(self.device)
                batch_embeddings = self.model(
                    **inputs, output_hidden_states=True, return_dict=True
                ).pooler_output
                embeddings += batch_embeddings.cpu().detach().numpy().tolist()
            callback(end, len(texts_list))
            logger.info(
                f"EmbeddingFeaturizer took {time.time() - start_time} s to process {len(texts_list[start:end])} inputs"
            )
        return embeddings

    @classmethod
    def get_embedding_dims(cls, **kwargs: Any) -> int:
        return 768


def _compute_simcse_embeddings(
    texts: pd.Series, callback: OpProgressCallback = no_op_progress_callback
) -> List[List[float]]:
    gene = SimcseGenerator.from_config()
    return gene.evaluate(texts, callback)


class ChunkEmbedding(BaseModel):
    """
    A Pydantic model representing the embedding of a text chunk.

    Attributes
    ----------
    embedding : List[float]
        The embedding vector for the chunk of text.
    char_start : int
        The starting character index of this chunk in the original text.
    length : int
        The length of this chunk in characters.
    """

    embedding: List[float]
    char_start: int
    length: int


TextChunkEmbeddings = List[List[ChunkEmbedding]]


class Chunk(BaseModel):
    text: str
    char_start: int
    length: int

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, Chunk):
            return NotImplemented
        return self.char_start == other.char_start

    def __ne__(self, other: object) -> bool:
        if not isinstance(other, Chunk):
            return NotImplemented
        return self.char_start != other.char_start

    def __len__(self) -> int:
        return self.length


def mean_pooling(
    model_output: Tuple[torch.Tensor], attention_mask: torch.Tensor
) -> torch.Tensor:
    token_embeddings = model_output[
        0
    ]  # First element of model_output contains all token embeddings
    input_mask_expanded = (
        attention_mask.unsqueeze(-1).expand(token_embeddings.size()).float()
    )
    return torch.sum(token_embeddings * input_mask_expanded, 1) / torch.clamp(
        input_mask_expanded.sum(1), min=1e-9
    )


class RAGEmbeddingsGenerator(EmbeddingGenerator):
    def __init__(
        self, tokenizer: AutoTokenizer, model: AutoModel, device: torch.device
    ) -> None:
        self.tokenizer = tokenizer
        self.model = model
        self.device = device

    def evaluate(
        self,
        data: pd.Series,
        callback: OpProgressCallback = no_op_progress_callback,
        chunk_size_chars: int = 100,
    ) -> TextChunkEmbeddings:
        """embeds each chunk in the field separately"""
        import torch

        texts_list = [x or "" for x in data.tolist()]

        embeddings: TextChunkEmbeddings = []
        batch_chunk_size = (
            16  # can likely be increased for better performance, but requires testing
        )
        for idx, texts in enumerate(texts_list):
            chunks = self.get_chunks(texts, chunk_size_chars=chunk_size_chars)
            chunk_embeddings: List[ChunkEmbedding] = []
            for start in range(0, len(chunks), batch_chunk_size):
                end = min(len(chunks), start + batch_chunk_size)
                chunk_texts = [x.text for x in chunks[start:end]]
                inputs = self.tokenizer(
                    chunk_texts,
                    padding=True,
                    truncation=True,
                    return_tensors="pt",
                )
                with torch.no_grad():
                    inputs = inputs.to(self.device)
                    model_output = self.model(**inputs)
                    batch_embeddings = mean_pooling(
                        model_output, inputs["attention_mask"]
                    )
                    normalized_embedding = torch.nn.functional.normalize(
                        batch_embeddings, p=2, dim=1
                    )
                    raw_embeddings = (
                        normalized_embedding.cpu().detach().numpy().tolist()
                    )
                    for i, raw_embedding in enumerate(raw_embeddings):
                        chunk_embedding = ChunkEmbedding(
                            embedding=raw_embedding,
                            char_start=chunks[start + i].char_start,
                            length=chunks[start + i].length,
                        )
                        chunk_embeddings.append(chunk_embedding)

            embeddings.append(chunk_embeddings)
            callback(idx + 1, len(texts_list))
        return embeddings

    @staticmethod
    def get_chunks(text: str, chunk_size_chars: int = 100) -> List[Chunk]:
        """
        Splits the given text into fixed-size chunks without overlap.

        Parameters
        ----------
        text : str
            The text to be chunked.
        chunk_size_chars : int, optional
            The number of characters each chunk should contain. Defaults to 100.

        Returns
        -------
        List[Chunk]
            A list of `Chunk` objects, each representing a chunk of the original text.
            Each `Chunk` object has the attributes:
            - text (str): The text of the chunk.
            - char_start (int): The starting index of the chunk in the original text.
            - length (int): The length of the chunk in characters.

        Notes
        -----
        This method performs fixed-size chunking of a given text into chunks of `chunk_size_chars`
        characters each. If the text does not divide evenly into chunks of this size, the final chunk
        will contain the remaining characters. Each chunk is represented by a `Chunk` object,
        which includes the chunk's text, its starting character index in the original text, and its length.

        Examples
        --------
        >>> text = "Hello World! This is a test text."
        >>> chunks = ClassName.get_chunks(text, chunk_size_chars=10)
        >>> for chunk in chunks:
        ...     print(chunk.text, chunk.char_start, chunk.length)
        Hello Worl 0 10
        d! This is 10 10
        a test tex 20 10
        t. 30 2
        """
        chunks: List[Chunk] = []
        char_start = 0
        while char_start < len(text):
            chunk_text = text[char_start : char_start + chunk_size_chars]
            chunks.append(
                Chunk(text=chunk_text, char_start=char_start, length=len(chunk_text))
            )
            char_start += chunk_size_chars
        return chunks

    @classmethod
    def from_config(
        cls,
        model_name: str = "sentence-transformers/all-MiniLM-L6-v2",
        **kwargs: Any,
    ) -> "RAGEmbeddingsGenerator":
        model_device = torch.device("cuda" if is_gpu_available() else "cpu")
        tokenizer = read_huggingface_asset(
            TOKENIZER_LOCK,
            LOCK_TIMEOUT,
            partial(
                AutoTokenizer.from_pretrained,
                model_name,
                cache_dir=HFCacheSettings.PRETRAINED_CACHE_DIR,
                revision=HFCacheSettings.REVISIONS[model_name],
            ),
            model_name,
        )
        model = read_huggingface_asset(
            MODEL_LOCK,
            LOCK_TIMEOUT,
            partial(
                AutoModel.from_pretrained,
                model_name,
                cache_dir=HFCacheSettings.PRETRAINED_CACHE_DIR,
                revision=HFCacheSettings.REVISIONS[model_name],
            ),
            model_name,
        ).to(model_device)
        model.eval()
        return cls(tokenizer, model, model_device)

    @classmethod
    def get_schema(cls, **kwargs: Any) -> pa.Schema:
        example_chunk_embeddings = [[0.0]]
        example_char_starts = [0]
        example_lengths = [1]
        schema_df = pd.DataFrame.from_records(
            [(example_chunk_embeddings, example_char_starts, example_lengths)],
            index=["string"],
            columns=["embeddings", "char_starts", "lengths"],
        )
        return pa.Schema.from_pandas(schema_df)

    @classmethod
    def generate_chunk(
        cls, embeddings: Iterable, sub_batch_df: pd.DataFrame, schema: pa.Schema
    ) -> pa.RecordBatch:
        # extract chunk_embeddings, char_starts, length from embeddings
        chunk_embeddings = []
        char_starts = []
        lengths = []
        for doc_embeddings in embeddings:
            if not isinstance(doc_embeddings, list):
                raise TypeError("Expected embeddings to be a list of lists")
            doc_chunk_embeddings = []
            doc_char_starts = []
            doc_lengths = []
            for chunk_embedding in doc_embeddings:
                if not isinstance(chunk_embedding, ChunkEmbedding):
                    raise TypeError(
                        "Expected each innermost element of embeddings to be of type ChunkEmbedding"
                    )
                doc_chunk_embeddings.append(chunk_embedding.embedding)
                doc_char_starts.append(chunk_embedding.char_start)
                doc_lengths.append(chunk_embedding.length)
            chunk_embeddings.append(doc_chunk_embeddings)
            char_starts.append(doc_char_starts)
            lengths.append(doc_lengths)

        return pa.record_batch(
            [
                pa.array(
                    chunk_embeddings,
                    type=schema.field("embeddings").type,
                ),
                pa.array(
                    char_starts,
                    type=schema.field("char_starts").type,
                ),
                pa.array(
                    lengths,
                    type=schema.field("lengths").type,
                ),
                pa.array(
                    sub_batch_df.index,
                    type=pa.string(),
                ),
            ],
            schema=schema,
        )

    @classmethod
    def get_embedding_dims(cls, **kwargs: Any) -> int:
        return 384


def _compute_chunk_embeddings(
    texts: pd.Series, callback: OpProgressCallback = no_op_progress_callback
) -> TextChunkEmbeddings:
    gene = RAGEmbeddingsGenerator.from_config()
    return gene.evaluate(texts, callback)


class SpacyGenerator(EmbeddingGenerator):
    def __init__(self, nlp: spacy.Language, device: torch.device) -> None:
        self.nlp = nlp
        self.device = device

    @classmethod
    def from_config(cls, **kwargs: Any) -> "SpacyGenerator":
        global NLP
        import spacy
        import thinc.compat

        device_str = "cpu"
        if thinc.compat.has_gpu and is_gpu_available():
            device_str = "cuda"
            spacy.require_gpu()
        model_device = torch.device(device_str)

        logger.info(f"SpacyGenerator: Model device being used is {model_device}")

        if NLP is None:
            NLP = spacy.load("en_core_web_sm")

        spacy.require_cpu()

        return SpacyGenerator(NLP, device=model_device)

    def evaluate(
        self, data: pd.Series, callback: OpProgressCallback = no_op_progress_callback
    ) -> List[List[float]]:
        def _run_spacy_on_text(text: str) -> List[float]:
            if text is None or pd.isna(text) or text == "":
                return [0.0] * 96
            return self.nlp(text).vector.tolist()

        len_data = len(data)
        embs = []
        for i, x in enumerate(data):
            embs.append(_run_spacy_on_text(x))
            callback(i + 1, len_data)
        return embs

    @classmethod
    def get_embedding_dims(cls, **kwargs: Any) -> int:
        return 96


def _compute_spacy_embeddings(
    texts: pd.Series, callback: OpProgressCallback = no_op_progress_callback
) -> List[List[float]]:
    gene = SpacyGenerator.from_config()
    return gene.evaluate(texts, callback)


class CLIPTextGenerator(EmbeddingGenerator):
    def __init__(self, model: CLIPTextEncoder) -> None:
        self.model = model

    @classmethod
    def from_config(cls, **kwargs: Any) -> "CLIPTextGenerator":
        model = CLIPTextEncoder()
        return CLIPTextGenerator(model)

    def evaluate(
        self, data: pd.Series, callback: OpProgressCallback = no_op_progress_callback
    ) -> List[List[float]]:
        start_time = time.time()
        embeddings = self.model.featurize(texts=data.fillna("").tolist())
        logger.info(
            f"CLIP text embeddings took {time.time() - start_time} s to process {len(data)} inputs"
        )
        return embeddings

    @classmethod
    def get_embedding_dims(cls, **kwargs: Any) -> int:
        return 512


def _compute_clip_embeddings(
    texts: pd.Series, callback: OpProgressCallback = no_op_progress_callback
) -> List[List[float]]:
    gene = CLIPTextGenerator.from_config()
    return gene.evaluate(texts, callback)


EMBEDDING_CLASSES: Dict[str, Type[EmbeddingGenerator]] = {
    "simcse": SimcseGenerator,
    "spacy": SpacyGenerator,
    "clip": CLIPTextGenerator,
    RAG_EMBEDDINGS: RAGEmbeddingsGenerator,
}

EMBEDDING_FNS = {
    "simcse": _compute_simcse_embeddings,
    "spacy": _compute_spacy_embeddings,
    RAG_EMBEDDINGS: _compute_chunk_embeddings,
}
