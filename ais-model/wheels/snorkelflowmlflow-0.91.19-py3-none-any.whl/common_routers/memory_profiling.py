import tracemalloc
from pathlib import Path
from typing import Any, Dict, List, Optional

import redis
from fastapi import APIRouter, Depends
from pydantic import BaseModel

from api_utils.route import SnorkelApiRoute, no_content
from authorization.authorization_utils import auth_superadmin
from profiling_utils.profiler import (
    PersistenceMode,
    ProfileType,
    clear_profile_stacktrace,
    disable_profiling,
    enable_profiling,
    get_profile_stacktrace,
    get_profiling_status,
)
from redis_utils.connection import get_cache_connection
from snorkelflow.utils import file
from snorkelflow.utils.logging import get_logger

router = APIRouter(route_class=SnorkelApiRoute)
logger = get_logger("Debugging")


class StartTraceMalloc(BaseModel):
    nframe: int = 25


class MemoryProfilingParams(BaseModel):
    service: str
    persistence_mode: PersistenceMode = PersistenceMode.disk


class MemoryProfilingStatusResponse(BaseModel):
    service: str
    status: str


class MemoryProfile(BaseModel):
    timestamp: str
    profile: str


class MemoryProfilingTraceResponse(BaseModel):
    profiles: List[MemoryProfile]


@router.post("/tracemalloc/start", status_code=204, dependencies=[auth_superadmin()])
@no_content
def start_tracemalloc(params: StartTraceMalloc) -> None:
    logger.info("Starting tracemalloc")
    if not tracemalloc.is_tracing():
        tracemalloc.start(params.nframe)


@router.post("/tracemalloc/stop", status_code=204, dependencies=[auth_superadmin()])
@no_content
def stop_tracemalloc() -> None:
    logger.info("Stopping tracemalloc")
    if tracemalloc.is_tracing():
        tracemalloc.stop()


@router.get("/tracemalloc", response_model=str, dependencies=[auth_superadmin()])
def get_tracemalloc_profile(top_k: int = 5, depth: int = 5) -> str:
    snapshot = tracemalloc.take_snapshot()
    top_stats = snapshot.statistics("traceback")[:top_k]
    results = []
    for stat in top_stats:
        results.append(
            "\n".join(
                [
                    f"Size: {stat.size//1000} KB",
                    f"Count: {stat.count}",
                    "Trace:",
                    "\n".join(stat.traceback.format()[:depth]),
                ]
            )
        )
    return "\n\n".join(results)


@router.get(
    "/memory-profile",
    response_model=MemoryProfilingTraceResponse,
    dependencies=[auth_superadmin()],
)
def memory_profile(
    service: str,
    cache: redis.Redis = Depends(get_cache_connection),
    pid: Optional[str] = None,
    persistence_mode: PersistenceMode = PersistenceMode.disk,
) -> Dict[str, Any]:
    """
    Get the Profile backtrace from Redis/disk
    """
    result = get_profile_stacktrace(
        cache,
        service=service,
        profile_type=ProfileType.memory,
        data_path=Path(f"{file.CONTAINER_VOLUME_DATA_PATH}")
        if persistence_mode == PersistenceMode.disk
        else None,
    )
    memory_profiles = []
    for key, value in result.items():
        if pid and not key.startswith(f"{service}-{pid}"):
            continue
        memory_profiles.append(MemoryProfile(timestamp=key, profile=value))
    return {"profiles": memory_profiles}


@router.post(
    "/memory-profile/start",
    response_model=MemoryProfilingStatusResponse,
    dependencies=[auth_superadmin()],
)
def start_profiling(
    params: MemoryProfilingParams, cache: redis.Redis = Depends(get_cache_connection)
) -> Dict[str, Any]:
    """
    Start profiling
    """
    enable_profiling(
        cache,
        service=params.service,
        data_path=Path(f"{file.CONTAINER_VOLUME_DATA_PATH}"),
        profile_type=ProfileType.memory,
        persistence_mode=params.persistence_mode,
    )
    return {
        "status": get_profiling_status(
            cache, service=params.service, profile_type=ProfileType.memory
        ),
        "service": params.service,
    }


@router.post(
    "/memory-profile/stop",
    response_model=MemoryProfilingStatusResponse,
    dependencies=[auth_superadmin()],
)
def stop_profiling(
    params: MemoryProfilingParams, cache: redis.Redis = Depends(get_cache_connection)
) -> Dict[str, Any]:
    """
    Stop profiling
    """
    disable_profiling(cache, service=params.service, profile_type=ProfileType.memory)
    return {
        "status": get_profiling_status(
            cache, service=params.service, profile_type=ProfileType.memory
        ),
        "service": params.service,
    }


@router.post(
    "/memory-profile/clear",
    response_model=MemoryProfilingStatusResponse,
    dependencies=[auth_superadmin()],
)
def clear_profiling(
    params: MemoryProfilingParams, cache: redis.Redis = Depends(get_cache_connection)
) -> Dict[str, Any]:
    """
    Clear profiling clears the profiling stacktrace.
    The profiler will continue to profile if it is enabled.
    It has no impact on the profiler status.
    """
    clear_profile_stacktrace(
        cache,
        service=params.service,
        profile_type=ProfileType.memory,
        data_path=Path(f"{file.CONTAINER_VOLUME_DATA_PATH}")
        if params.persistence_mode == PersistenceMode.disk
        else None,
    )
    return {"status": "memory profile stacktraces cleared", "service": params.service}
