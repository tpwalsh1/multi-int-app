from pathlib import Path
from typing import Any, Dict

import redis
from fastapi import APIRouter, Depends
from pydantic import BaseModel

from api_utils.route import SnorkelApiRoute
from authorization.authorization_utils import auth_superadmin
from profiling_utils.profiler import (
    ProfileType,
    clear_profile_stacktrace,
    convert_collapsed_stacktrace_to_tree,
    disable_profiling,
    enable_profiling,
    get_profile_stacktrace,
    get_profiling_status,
)
from redis_utils.connection import get_cache_connection
from snorkelflow.utils import file
from snorkelflow.utils.logging import get_logger

router = APIRouter(route_class=SnorkelApiRoute)
logger = get_logger("Debugging")


class CPUProfilingParams(BaseModel):
    service: str


class CPUProfilingStatusResponse(BaseModel):
    service: str
    status: str


@router.get(
    "/cpu-profile", response_model=Dict[str, Any], dependencies=[auth_superadmin()]
)
def profile(
    service: str,
    output_as_tree: bool = False,
    cache: redis.Redis = Depends(get_cache_connection),
) -> Dict[str, Any]:
    """
    Get the Profile backtrace from the Redis
    """
    collapsed_stacktrace = get_profile_stacktrace(
        cache,
        service=service,
        profile_type=ProfileType.cpu,
        data_path=Path(f"{file.CONTAINER_VOLUME_DATA_PATH}"),
    )

    if not output_as_tree:
        return collapsed_stacktrace

    return convert_collapsed_stacktrace_to_tree(collapsed_stacktrace)


@router.post(
    "/cpu-profile/start",
    response_model=CPUProfilingStatusResponse,
    dependencies=[auth_superadmin()],
)
def start_profiling(
    params: CPUProfilingParams, cache: redis.Redis = Depends(get_cache_connection)
) -> Dict[str, Any]:
    """
    Start profiling
    """
    enable_profiling(
        cache,
        service=params.service,
        profile_type=ProfileType.cpu,
        data_path=Path(f"{file.CONTAINER_VOLUME_DATA_PATH}"),
    )
    return {
        "status": get_profiling_status(
            cache, service=params.service, profile_type=ProfileType.cpu
        ),
        "service": params.service,
    }


@router.post(
    "/cpu-profile/stop",
    response_model=CPUProfilingStatusResponse,
    dependencies=[auth_superadmin()],
)
def stop_profiling(
    params: CPUProfilingParams, cache: redis.Redis = Depends(get_cache_connection)
) -> Dict[str, Any]:
    """
    Stop profiling
    """
    disable_profiling(cache, service=params.service, profile_type=ProfileType.cpu)
    return {
        "status": get_profiling_status(
            cache, service=params.service, profile_type=ProfileType.cpu
        ),
        "service": params.service,
    }


@router.post(
    "/cpu-profile/clear",
    response_model=CPUProfilingStatusResponse,
    dependencies=[auth_superadmin()],
)
def clear_profiling(
    params: CPUProfilingParams, cache: redis.Redis = Depends(get_cache_connection)
) -> Dict[str, Any]:
    """
    Clear profiling clears the profiling stacktrace.
    The profiler will continue to profile if it is enabled.
    It has no impact on the profiler status.
    """
    clear_profile_stacktrace(
        cache,
        service=params.service,
        profile_type=ProfileType.cpu,
        data_path=Path(f"{file.CONTAINER_VOLUME_DATA_PATH}"),
    )
    return {"status": "cpu profile stacktraces cleared", "service": params.service}
