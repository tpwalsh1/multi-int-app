from typing import Optional

import redis
from fastapi import APIRouter, Depends, Request

from api_utils.exceptions import UnprocessableEntityError
from api_utils.route import SnorkelApiRoute, no_content
from authorization.auth_types import ResourceType
from authorization.authorization_utils import auth_all_roles, user_can_access_job
from data_models.user import User
from engine.client import (
    JobInfo,
    JobListResponse,
    JobSearchDirection,
    get_job_from_uid,
    get_jobs,
)
from postgres_utils.pool import connection, get_db_connection
from redis_utils.connection import get_cache_connection
from snorkelflow.types.jobs import JobState, JobType
from snorkelflow.utils.logging import get_logger

router = APIRouter(route_class=SnorkelApiRoute)
logger = get_logger("TDM API")


@router.get("/jobs", response_model=JobListResponse)
def list_jobs(
    request: Request,
    job_type: Optional[JobType] = None,
    dataset_id: Optional[int] = None,
    task_id: Optional[int] = None,
    workspace_id: Optional[int] = None,
    state: Optional[JobState] = None,
    start_time: Optional[float] = None,
    direction: str = JobSearchDirection.OLDER,
    limit: Optional[int] = None,
    details: bool = False,
    user_uid: Optional[int] = None,
    redis_conn: redis.Redis = Depends(get_cache_connection),
    conn: connection = Depends(get_db_connection),
) -> JobListResponse:
    user = User.from_request_with_auth(conn, request)
    if not JobSearchDirection.is_member(direction):
        err_msg = f"Unknown job search direction {direction}"
        raise UnprocessableEntityError(detail=err_msg, user_friendly_message=err_msg)
    jobs_response = get_jobs(
        conn,
        redis_conn,
        job_type=job_type,
        dataset_id=dataset_id,
        task_id=task_id,
        workspace_id=workspace_id,
        state=state,
        start_time=start_time,
        direction=JobSearchDirection(direction),
        limit=limit,
        details=details,
        user_uid=user_uid,
    )
    # filter job
    # only return jobs whose workspace the user is part of(workspace scoped jobs)
    # or the job's owner is the user(non workspace scoped jobs)
    # Note that labellers are specifically blocked from viewing jobs
    filtered_jobs = [
        job for job in jobs_response.jobs if user_can_access_job(conn, user, job)
    ]
    jobs_response.jobs = filtered_jobs
    return jobs_response


@router.get(
    "/jobs/{job_uid}",
    response_model=JobInfo,
    dependencies=[auth_all_roles(resources=[ResourceType.JOB])],
)
def get_job_for_uid(
    job_uid: str, redis_conn: redis.Redis = Depends(get_cache_connection)
) -> JobInfo:
    job = get_job_from_uid(job_uid, redis_conn)
    return job


@router.post(
    "/jobs/{job_uid}/cancel",
    status_code=204,
    dependencies=[auth_all_roles(resources=[ResourceType.JOB])],
)
@no_content
def cancel_job(
    job_uid: str, redis_conn: redis.Redis = Depends(get_cache_connection)
) -> None:
    job = get_job_from_uid(job_uid, redis_conn)
    job.send_cancel_request(redis_conn)


@router.post(
    "/jobs/{job_uid}/delete",
    status_code=204,
    dependencies=[auth_all_roles(resources=[ResourceType.JOB])],
)
@no_content
def delete_job(
    job_uid: str, redis_conn: redis.Redis = Depends(get_cache_connection)
) -> None:
    job = get_job_from_uid(job_uid, redis_conn)
    job.delete(redis_conn)
