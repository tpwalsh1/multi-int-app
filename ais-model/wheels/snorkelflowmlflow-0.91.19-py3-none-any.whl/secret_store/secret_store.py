from abc import ABC, abstractmethod
from typing import Any, Dict, List, Type

from pydantic import BaseModel


class BaseSecretConfig(BaseModel):
    store_name: str


secret_stores: Dict[str, Type["BaseSecretStore"]] = {}


class BaseSecretStore(ABC):
    conn_config: BaseSecretConfig

    def __init__(self, **kwargs: Any):
        pass

    def __init_subclass__(cls, **kwargs: Any):
        super(cls).__init_subclass__(**kwargs)  # type: ignore
        secret_stores[cls.conn_config.store_name] = cls

    @classmethod
    @abstractmethod
    def from_config(cls, **kwargs: Any) -> "BaseSecretStore":
        """Creates a secret store class from auth kwargs"""

    @abstractmethod
    def put_secret(self, key: str, value: str, workspace_uid: int) -> None:
        """Puts a secret in the secret store"""

    @abstractmethod
    def get_secret(self, key: str, workspace_uid: int) -> str:
        """Gets the secret from the secret store given the key"""

    @abstractmethod
    def delete_secret(self, key: str, workspace_uid: int) -> None:
        """Deletes a secret from the secret store given the key"""

    @abstractmethod
    def list_secret_keys(self, workspace_uid: int) -> List[str]:
        """Gets all secret keys for the given workspace"""
