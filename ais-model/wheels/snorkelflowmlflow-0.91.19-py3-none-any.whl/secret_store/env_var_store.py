import os
from typing import Any, List

import re2

from api_utils.exceptions import NotFoundError

from .secret_store import BaseSecretConfig, BaseSecretStore

ENV_VAR_PREFIX = "SF_STORE"


class EnvVarSecretConfig(BaseSecretConfig):
    store_name: str = "env_store"


class EnvVarSecretStore(BaseSecretStore):
    conn_config: EnvVarSecretConfig = EnvVarSecretConfig()

    @classmethod
    def from_config(cls, **kwargs: Any) -> "EnvVarSecretStore":
        """Creates a secret store class from auth kwargs"""
        return cls(**kwargs)

    def put_secret(self, key: str, value: str, workspace_uid: int) -> None:
        os.environ[self.env_var_name(key, workspace_uid)] = value

    def get_secret(self, key: str, workspace_uid: int) -> str:
        try:
            return os.environ[self.env_var_name(key, workspace_uid)]
        except KeyError:
            raise NotFoundError(
                f"Secret Key {key} not in Env Var Secret Store for Workspace {workspace_uid}"
            )

    def delete_secret(self, key: str, workspace_uid: int) -> None:
        try:
            os.environ.pop(self.env_var_name(key, workspace_uid))
        except KeyError:
            raise NotFoundError(
                f"Secret Key {key} not in Env Var Secret Store for Workspace {workspace_uid}"
            )

    def list_secret_keys(self, workspace_uid: int) -> List[str]:
        keys = []
        for env_var_name in os.environ:
            match = re2.search(
                f"^{ENV_VAR_PREFIX}::(.*)::{workspace_uid}$", env_var_name
            )
            if match:
                keys.append(match.group(1))

        return keys

    @staticmethod
    def env_var_name(key: str, workspace_uid: int) -> str:
        return f"{ENV_VAR_PREFIX}::{key}::{workspace_uid}"
