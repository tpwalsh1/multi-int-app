import importlib
import os
from typing import Any, Dict, Optional

from api_utils.config import get_service_type
from snorkelflow.config.constants import ServiceType
from snorkelflow.plugin_utils import find_all_modules
from snorkelflow.utils.logging import get_logger

from .secret_store import BaseSecretStore, secret_stores

logger = get_logger("Secret Store")

all_secret_store_modules = find_all_modules(os.path.dirname(__file__), "secret_store.")
for module in all_secret_store_modules:
    logger.debug(f"Importing module {module}")
    try:
        importlib.import_module(module)
    except ImportError as e:
        logger.warning(
            f"Skipping import for {module} due to error: {e}", exc_info=False
        )


class SecretStoreNotFoundError(ImportError):
    pass


def get_secret_store(secret_store: str, kwargs: Dict[str, Any]) -> BaseSecretStore:
    store_cls = secret_stores.get(secret_store)
    if not store_cls:
        raise SecretStoreNotFoundError(f"Cannot find the secret store {secret_store}")
    store = store_cls.from_config(**kwargs)
    return store


def try_get_secret(
    secret_store: str, kwargs: Dict[str, Any], workspace_uid: int, key: str
) -> Optional[str]:
    try:
        return get_secret_store(secret_store, kwargs).get_secret(key, workspace_uid)
    except Exception:
        logger.debug(
            f"Failed to get {key} from secret store {secret_store}", exc_info=True
        )
    return None


def get_default_secret_store_name() -> str:
    if get_service_type() == ServiceType.Notebook:
        return "env_store"
    else:
        return "local_store"
