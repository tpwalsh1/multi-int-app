import datetime
import os
import pathlib
import random
from typing import Dict, Optional, Union

import pandas as pd
from dask import dataframe as dd

from snorkelflow.data.core import serialize_series
from snorkelflow.extraction.span import SpanCols
from snorkelflow.types.model import ModelCols
from snorkelflow.utils.dask import dask_compute
from snorkelflow.utils.logging import get_logger


class MonitoringCols:
    INPUT_UID = "input_uid"
    REQUEST_TIMESTAMP = "request_timestamp"
    X_UID = "x_uid"


# This cannot be changed without breaking backcompat for already deployed
# applications as they will write to the value of this variable as it was
# during deployment while SF will read the value of this variable
# as it is during inference time. Ideally this would be renamed to
# "tmp-monitoring-data" to be more in-line with how we name directories in minio
MONITORING_DIRECTORY = "monitoring_data"

logger = get_logger("Monitoring Client")

# The monitoring client simply buffers data before writing it out,
# so it can accept either Dask or Pandas dataframes.
DataFrame = Union[dd.DataFrame, pd.DataFrame]


class MonitoringClientError(Exception):
    pass


class MonitoringClient:
    """
    Aggregates monitoring data in a buffer and emits this data out to the
    relevant clients
    """

    def __init__(self, deployment_uid: int, tdm_api_url: Optional[str] = None) -> None:
        self.deployment_uid = deployment_uid
        self.tdm_api_url = tdm_api_url
        self.inputs: Optional[DataFrame] = None
        self.outputs: Optional[pd.DataFrame] = None
        self.node_data: Dict[int, Dict] = {}

    def _generate_uuid(self) -> int:
        uuid = random.getrandbits(63)
        while uuid < 1000000:
            uuid = random.getrandbits(63)
        return uuid

    def serialize_columns(self, df: DataFrame) -> None:
        for col in df.columns:
            df[col] = serialize_series(df[col])

    def initialize_and_store_inputs(self, df: DataFrame) -> DataFrame:
        # The divisions are not known during testing but are known during prod so
        # this should generally only run during testing.
        if isinstance(df, dd.DataFrame) and not df.known_divisions:
            df = df.reset_index().set_index("index")

        df[MonitoringCols.REQUEST_TIMESTAMP] = datetime.datetime.utcnow().isoformat()

        if SpanCols.CONTEXT_UID not in df.columns:
            df[MonitoringCols.INPUT_UID] = pd.Series(
                [self._generate_uuid() for _ in range(len(df.index))], index=df.index
            )
            # TODO ENG-6639: Remove this line of setting context_uid to input_uid when context_uid is replaced by input_uid
            df[SpanCols.CONTEXT_UID] = df[MonitoringCols.INPUT_UID]
        else:
            df[MonitoringCols.INPUT_UID] = df[SpanCols.CONTEXT_UID]

        df_copy = df.copy()
        if self.inputs is None:
            self.inputs = df_copy
        else:
            self.inputs.concat(df_copy)
        logger.info(
            f"Stored monitoring inputs: {self.inputs.columns}, {self.inputs.index}"
        )
        return df

    def record_outputs(self, df: pd.DataFrame) -> None:
        """
        Only the furthest downstream model's predictions are stored
        as application outputs (prediction_int and probs). For now both of these columns
        are required to be present in order to record outputs, in the future we
        may be more flexible towards the output schema of the application.
        """
        if MonitoringCols.INPUT_UID not in df.columns:
            raise MonitoringClientError(
                f"Output DF is missing required {MonitoringCols.INPUT_UID}"
                " column for identifying inference request"
            )
        if MonitoringCols.REQUEST_TIMESTAMP not in df.columns:
            raise MonitoringClientError(
                f"Output DF is missing required {MonitoringCols.REQUEST_TIMESTAMP} column"
            )
        if MonitoringCols.X_UID not in df.columns:
            raise MonitoringClientError(
                f"Output DF is missing required {MonitoringCols.X_UID} column"
            )
        if not all(
            col in df.columns
            for col in [ModelCols.PREDICTION_PROBABILITY, ModelCols.PREDICTION_INT]
        ):
            raise MonitoringClientError(
                f"Output DF is missing required predictions ({ModelCols.PREDICTION_INT})"
                f" and probs ({ModelCols.PREDICTION_PROBABILITY}) columns"
            )
        df_copy = df.copy()
        self.outputs = df_copy[
            [
                MonitoringCols.INPUT_UID,
                MonitoringCols.REQUEST_TIMESTAMP,
                ModelCols.PREDICTION_INT,
                ModelCols.PREDICTION_PROBABILITY,
                MonitoringCols.X_UID,
            ]
        ]

    def record_node_inputs(self, node_uid: int, node_inputs: DataFrame) -> None:
        if node_uid not in self.node_data:
            self.node_data[node_uid] = dict()
        self.node_data[node_uid]["inputs"] = node_inputs.copy()

    def record_node_outputs(self, node_uid: int, node_outputs: DataFrame) -> None:
        if node_uid not in self.node_data:
            self.node_data[node_uid] = dict()
        self.node_data[node_uid]["outputs"] = node_outputs.copy()

    def flush_to_filesystem(self, output_dir: str) -> str:
        monitoring_dir = os.path.join(output_dir, MONITORING_DIRECTORY)
        pathlib.Path(monitoring_dir).mkdir(exist_ok=True)
        # Save the input data, the node data, and the output data
        logger.info(f"Flushing batched monitoring data to system")
        if self.inputs is not None:
            # Possible that our inputs have not yet been computed from Dask to Pandas,
            # do that before serializing
            if isinstance(self.inputs, dd.DataFrame):
                self.inputs = dask_compute(self.inputs)[0]
            self.serialize_columns(self.inputs)
            self.inputs.to_parquet(
                os.path.join(monitoring_dir, "raw_inputs.parquet"), engine="pyarrow"
            )
        if self.outputs is not None:
            self.serialize_columns(self.outputs)
            self.outputs.to_parquet(
                os.path.join(monitoring_dir, "outputs.parquet"), engine="pyarrow"
            )
        for node_uid, dfs in self.node_data.items():
            node_inputs = dfs.get("inputs")
            node_outputs = dfs.get("outputs")
            if node_inputs:
                self.serialize_columns(node_inputs)
                node_inputs.to_parquet(
                    os.path.join(monitoring_dir, f"node_{node_uid}_inputs.parquet"),
                    engine="pyarrow",
                )
            if node_outputs:
                self.serialize_columns(node_outputs)
                node_outputs.to_parquet(
                    os.path.join(monitoring_dir, f"node_{node_uid}_outputs.parquet"),
                    engine="pyarrow",
                )
        logger.info(
            f"Flushed inputs+outputs to {monitoring_dir}: {os.listdir(monitoring_dir)}"
        )
        return monitoring_dir

    def flush_to_tdm(self) -> None:
        if not self.tdm_api_url:
            raise ValueError(
                f"Unable to flush monitoring data buffer to TDM"
                " as $TDM_API_URL is undefined"
            )
        raise NotImplementedError

    @classmethod
    def from_config(cls, config_file: pathlib.Path) -> "MonitoringClient":
        """Given a path to a config file, initialize the client"""
        raise NotImplementedError(
            f"We do not currently supporting loading a MonitoringClient from a config file"
        )

    @classmethod
    def from_environment(cls, deployment_uid: int) -> "MonitoringClient":
        """Initialize a new MontioringClient from the local environment"""
        # TODO(jhallard) - $TDM_API_URL must be registered as an "allowed"
        # environment variable and must be retreived via api_utils.config.get_env_var()
        # Since we can't talk directly to TDM from engine right now this functionality
        # has been punted
        # tdm_api_url = os.env.get("TDM_API_URL", None)
        return cls(deployment_uid=deployment_uid, tdm_api_url=None)
