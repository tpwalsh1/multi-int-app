from label_spaces.base import LabelSpace


class InputSet(object):
    def __init__(self, label_space: LabelSpace):
        self.label_space = label_space
