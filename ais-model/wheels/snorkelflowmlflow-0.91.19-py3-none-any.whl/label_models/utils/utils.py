from itertools import product
from typing import Any, Dict, Iterator, Optional, Tuple, Union

import numpy as np
import sparse
from scipy.optimize import fminbound

from label_spaces.common.sparse_dense_utils import (
    densify,
    make_multilabel_target_sparse,
    make_singlelabel_target_dense,
)
from label_spaces.get_label_space import get_label_space

MIN_VALID_SAMPLES_FOR_TUNING = 50
MIN_PER_CLASS_SAMPLES_FOR_TUNING = 5

dtype_Mu = np.float32
dtype_Mu_abstain = np.float32


def get_kl_threshold(cardinality: int, phi: float = 0.25) -> float:
    """
    Returns a prediction threshold for maximum label probs that approximates
    how labels would be filtered if based on Shannon entropy
    Args:
        cardinality (int)
        phi (float, optional): Relative divergence from maximum entropy, 1 is highest.
        Defaults to 0.25.
    """

    def _thresh_err(theta: float, k: int, phi: float) -> float:
        theta1 = (1 - theta) / (k - 1)
        v0 = theta * np.log(theta) + (k - 1) * theta1 * np.log(theta1)
        v1 = -np.log(k) * (1 - phi)
        return np.square(v0 - v1)

    return fminbound(_thresh_err, 0, 1, args=(cardinality, phi))


def estimate_class_distribution(
    y: Union[sparse._coo.core.COO, np.ndarray],
    cardinality: int,
    alpha: float = 1,
    norm: bool = True,
) -> np.ndarray:
    """
    Estimates single-label class distributions with smoothing parameter alpha

    Args:
        Union[np.ndarray, sparse._coo.core.COO]: ground truth vector/tensor, either dense 1D with values indicating class or 2D binarized representation
        alpha (Optional[float], optional): smoothing parameter, with larger values resulting in more uniform estimates. Defaults to 1.
        norm (bool, optional): whether to return probabilities vs estimated counts. Defaults to True.

    Returns:
        np.ndarray: distribution
    """

    if y.ndim == 1:
        if not isinstance(y, np.ndarray):
            raise ValueError("y is sparse but only has 1 dimension")

        y = y.astype(int)

        class_distribution = np.bincount(y[y >= 0], minlength=cardinality)

    else:
        class_distribution = densify(y.sum(axis=0))

    class_distribution = class_distribution.astype("float") + alpha

    if norm:
        class_distribution /= class_distribution.sum()

    return class_distribution


def estimate_multilabel_probs(
    Y: np.ndarray,
    cardinality: int,
    prior_prob: Optional[float] = None,
    prior_conf: float = 10.0,
) -> np.ndarray:
    mls = get_label_space(
        "MultiLabelSpace", {"label_map": {str(i): i for i in range(cardinality)}}
    )
    Y = mls.to_dense_array(Y)  # type: ignore
    Y = make_multilabel_target_sparse(Y)

    multilabel_probs = densify(Y.sum(axis=0)).astype("float")
    if prior_prob is None:
        prior_prob = 1 / cardinality

    multilabel_probs[:, 0] += (1 - prior_prob) * prior_conf
    multilabel_probs[:, 1] += prior_prob * prior_conf

    multilabel_probs = multilabel_probs[:, 1] / multilabel_probs.sum(axis=1)

    return multilabel_probs


def dict_product(d: Dict[Any, Any]) -> Iterator[Dict[Any, Any]]:
    """
    Takes in a dictionary, applies a cartesian product over the keys and
    returns an iterator of dictionaries mapping the keys to each element of the cartesian product

    Parameters
    ----------
    d
     The dictionary we want to apply the product to

    Returns
    ----------
    Iterator[Dict[Any, Any]]
    """
    keys = d.keys()
    for element in product(*d.values()):
        yield dict(zip(keys, element))


def _use_valid_set_for_tuning(cardinality: int, Y_valid: Optional[np.ndarray]) -> bool:
    """
    Checks whether a valid set is usable for tuning.

    The following conditions are required:
    - The valid set must contain at least 5 examples for each class.
    - The valid set must contain at least 50 examples overall.
    """
    if Y_valid is None:
        return False
    Y = Y_valid

    if isinstance(Y, sparse._coo.core.COO):
        Y = make_singlelabel_target_dense(Y)

    _, counts = np.unique(Y, return_counts=True)
    if len(counts) < cardinality:
        # Missing ground truth for one or more classes
        return False
    if counts.min() < MIN_PER_CLASS_SAMPLES_FOR_TUNING:
        # Too few ground truth values for a class
        return False
    if counts.sum() < MIN_VALID_SAMPLES_FOR_TUNING:
        # Too few ground truth values overall.
        return False
    return True


def interpolation_lm_predict_proba(
    L: sparse._coo.COO, label_model_1: Any, label_model_2: Any, gt_interpolation: float
) -> np.ndarray:
    prob_1 = label_model_1.predict_proba(L) * gt_interpolation
    prob_2 = (1 - gt_interpolation) * label_model_2.predict_proba(L)
    return prob_1 + prob_2


def interpolation_lm_predict(
    L: sparse._coo.COO,
    label_model_1: Any,
    label_model_2: Any,
    use_multi_label: bool = False,
    gt_interpolation: float = 0.2,
    tie_break_policy: str = "abstain",
    filter_unlabeled: bool = True,
    filter_uncertain_labels: bool = True,
    return_probs: bool = True,
) -> Union[np.ndarray, Tuple[np.ndarray, np.ndarray]]:
    if use_multi_label:
        threshold_card = 2
        original_probabilities = interpolation_lm_predict_proba(
            L, label_model_1, label_model_2, gt_interpolation
        )
        original_abstains = label_model_2.input_set.label_space.compute_lf_abstains(L)
        (
            _,
            probs,
            abstains,
            _,
        ) = label_model_2.input_set.label_space._compute_probs_and_abstains_from_lm(
            [], original_probabilities, original_abstains, None
        )
        # Convert probs and abstains from List to np.ndarray to match return type
        probs = np.asarray(probs)
        abstains = np.asarray(abstains)

    else:
        threshold_card = label_model_2.parameter_set.cardinality
        probs = interpolation_lm_predict_proba(
            L, label_model_1, label_model_2, gt_interpolation
        )
        abstains = label_model_2.input_set.label_space.compute_lf_abstains(L, probs)

    filter_uncertain_labels_threshold = (
        get_kl_threshold(threshold_card) if filter_uncertain_labels else 0.0
    )
    preds = label_model_2.input_set.label_space.probs_to_preds_with_threshold(
        probs,
        abstains,
        tie_break_policy=tie_break_policy,
        filter_uncertain_labels_threshold=filter_uncertain_labels_threshold,
    )
    if return_probs:
        return preds, probs
    return preds
