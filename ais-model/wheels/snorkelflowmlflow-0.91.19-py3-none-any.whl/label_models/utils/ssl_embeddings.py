from typing import List

import numpy as np
from sklearn.metrics import pairwise


class Epoxy(object):
    def __init__(
        self,
        L_train: np.ndarray,
        train_embeddings: np.ndarray,
        lf_accuracies: List[float],
        metric: str = "cosine",
    ):
        self.L_train = np.copy(L_train)
        self.train_embeddings = train_embeddings
        self.metric = metric
        self.use_memory_efficent = False
        if self.L_train.shape[0] >= 30_000:
            self.use_memory_efficent = True

        self.accuracies = lf_accuracies

    def extend_matrix_vectorized(
        self,
        L_mat: np.ndarray,
        mat_embeddings: np.ndarray,
        similarity_threshold: float = 0.3,  # Similarity threshold between the embeddings
        vote_threshold: float = 0.2,  # How often the LF needs to vote
        accuracy_threshold: float = 0.5,  # How accurate the LF needs to be on GT data
    ) -> np.ndarray:
        L_mat_copy = np.copy(L_mat)
        if len(mat_embeddings) == 0:
            return L_mat_copy

        num_lfs = L_mat.shape[1]
        for lf in range(num_lfs):
            lf_abstain = np.where(L_mat[:, lf] == -1)[0]
            lf_not_abstain = np.where(self.L_train[:, lf] != -1)[0]
            lf_vote_frac = (L_mat[:, lf] != -1).sum() / L_mat.shape[0]
            # Check to make sure that there are examples for which that LF abstains
            # And examples in the train set for which it does not
            if (
                len(lf_abstain) > 0
                and len(lf_not_abstain) > 0
                and lf_vote_frac >= vote_threshold
                and self.accuracies[lf] >= accuracy_threshold
            ):
                if self.metric == "cosine":
                    relevant_embeddings = pairwise.cosine_similarity(
                        mat_embeddings[lf_abstain],
                        self.train_embeddings[lf_not_abstain],
                    )
                elif self.metric == "euclidean":
                    relevant_embeddings = 1 - pairwise.euclidean_distance(
                        mat_embeddings[lf_abstain],
                        self.train_embeddings[lf_not_abstain],
                    )
                else:
                    raise Exception(f"Metric {self.metric} is not currently supported")
                lf_to_pick = np.argmax(relevant_embeddings, axis=1)
                relevant_embeddings = relevant_embeddings[:, lf_to_pick]

                embedding_greater_than_threshold = (
                    relevant_embeddings >= similarity_threshold
                )
                embedding_greater_than_threshold = embedding_greater_than_threshold[0]

                lf_abstain = lf_abstain[embedding_greater_than_threshold]
                lf_to_pick = lf_to_pick[embedding_greater_than_threshold]
                # Because of indexing the lf_to_pick we get from doing the argmax does not correspond to the
                # exact LF we want
                lf_to_pick_adjusted = [lf_not_abstain[elem] for elem in lf_to_pick]

                for index, elem in enumerate(lf_abstain):
                    L_mat_copy[elem][lf] = self.L_train[lf_to_pick_adjusted[index]][lf]

        return L_mat_copy

    def extend_matrix_memory_efficient(
        self,
        L_mat: np.ndarray,
        mat_embeddings: np.ndarray,
        similarity_threshold: float = 0.3,  # Similarity threshold between the embeddings
        vote_threshold: float = 0.2,  # How often the LF needs to vote
        accuracy_threshold: float = 0.5,  # How accurate the LF needs to be on GT data
    ) -> np.ndarray:
        # This function does the same as the one above except rather than
        # computing all pairwise embedding similarities at once we do it
        # one at a time for memory sake. This however is slower

        L_mat_copy = np.copy(L_mat)
        if len(mat_embeddings) == 0:
            return L_mat_copy
        for index in range(len(L_mat)):
            L_mat_index = L_mat[index]
            L_mat_index_abstains = np.where(L_mat_index == -1)[0]
            if len(L_mat_index_abstains) > 0:
                for lf_index in L_mat_index_abstains:
                    lf_index_non_abstain = np.where(L_mat[:, lf_index] != -1)
                    if self.metric == "cosine":
                        embedding_similarities = pairwise.cosine_similarity(
                            mat_embeddings[index].reshape(1, -1),
                            self.train_embeddings[lf_index_non_abstain],
                        )[0]
                    elif self.metric == "euclidean":
                        embedding_similarities = 1 - pairwise.euclidean_distance(
                            mat_embeddings[index].reshape(1, -1),
                            self.train_embeddings[lf_index_non_abstain],
                        )
                    else:
                        raise Exception(
                            f"Metric {self.metric} is not currently supported"
                        )
                    argmax_similarity = np.argmax(embedding_similarities)
                    lf_vote_frac = (L_mat[:, lf_index] != -1).sum() / L_mat.shape[0]
                    if (
                        embedding_similarities[argmax_similarity]
                        >= similarity_threshold
                        and lf_vote_frac >= vote_threshold
                        and self.accuracies[lf_index] >= accuracy_threshold
                    ):
                        lf_to_pick = lf_index_non_abstain[0][argmax_similarity]
                        L_mat_copy[index][lf_index] = self.L_train[:, lf_index][
                            lf_to_pick
                        ]

        return L_mat_copy

    def extend_matrix(
        self,
        L_mat: np.ndarray,
        mat_embeddings: np.ndarray,
        similarity_threshold: float = 0.3,  # Similarity threshold between the embeddings
        vote_threshold: float = 0.2,  # How often the LF needs to vote
        accuracy_threshold: float = 0.5,  # How accurate the LF needs to be on GT data
    ) -> np.ndarray:
        # Determines whether to use the memory efficient method or not
        if self.use_memory_efficent:
            return self.extend_matrix_memory_efficient(
                L_mat,
                mat_embeddings,
                similarity_threshold,
                vote_threshold=vote_threshold,
                accuracy_threshold=accuracy_threshold,
            )
        else:
            return self.extend_matrix_vectorized(
                L_mat,
                mat_embeddings,
                similarity_threshold,
                vote_threshold=vote_threshold,
                accuracy_threshold=accuracy_threshold,
            )
