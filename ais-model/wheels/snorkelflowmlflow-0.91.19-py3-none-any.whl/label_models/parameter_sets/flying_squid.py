import logging
import random
from typing import Any, List, Optional, Tuple

import numpy as np
from pgmpy.factors.discrete import (  # type: ignore
    DiscreteFactor,
    JointProbabilityDistribution,
)
from pgmpy.models import MarkovModel  # type: ignore

from label_models.input_sets.input_set import InputSet
from label_models.parameter_sets.parameter_set import ParameterSet
from label_models.utils.utils import dict_product


class FlyingSquidParameterSet(ParameterSet):
    def __init__(
        self,
        input_set: InputSet,
        num_lfs: int = 1,
        v: int = 1,
        y_edges: Optional[List[Tuple[int, int]]] = None,
        lambda_y_edges: Optional[Any] = None,
        lambda_edges: Optional[Any] = None,
        allow_abstentions: bool = True,
        triplets: Optional[Any] = None,
        flip_negative: bool = True,
        triplet_seed: int = 0,
        clamp: bool = True,
        class_balance: Optional[List[float]] = None,
    ):
        super().__init__(input_set)

        if y_edges is None:
            y_edges = []

        if lambda_y_edges is None:
            lambda_y_edges = []

        if lambda_edges is None:
            lambda_edges = []

        if lambda_y_edges == []:
            lambda_y_edges = [(i, 0) for i in range(num_lfs)]

        G = MarkovModel()
        # Add LF nodes
        G.add_nodes_from(["lambda_{}".format(i) for i in range(num_lfs)])
        G.add_nodes_from(["Y_{}".format(i) for i in range(v)])

        # Add edges
        G.add_edges_from(
            [("Y_{}".format(start), "Y_{}".format(end)) for start, end in y_edges]
        )
        G.add_edges_from(
            [
                ("lambda_{}".format(start), "Y_{}".format(end))
                for start, end in lambda_y_edges
            ]
        )
        G.add_edges_from(
            [
                ("lambda_{}".format(start), "lambda_{}".format(end))
                for start, end in lambda_edges
            ]
        )

        self.fully_independent_case = lambda_edges == []

        self.num_lfs = num_lfs
        self.v = v
        self.G = G
        self.junction_tree = self.G.to_junction_tree()

        self.nodes = sorted(list(self.G.nodes))
        self.triplet_seed = triplet_seed
        if triplet_seed is not None:
            random.seed(triplet_seed)
            random.shuffle(self.nodes)

        self.separator_sets = {
            tuple(sorted(list((set(clique1).intersection(set(clique2))))))
            for clique1, clique2 in self.junction_tree.edges
        }

        self.allow_abstentions = allow_abstentions
        self.triplets = triplets
        self.flip_negative = flip_negative
        self.clamp = clamp
        self.class_balance = class_balance

    def enumerate_ys(self) -> Any:
        # order to output probabilities
        vals = {Y: (-1, 1) for Y in range(self.v)}
        Y_vecs = sorted(
            [[vec_dict[Y] for Y in range(self.v)] for vec_dict in dict_product(vals)]
        )

        return Y_vecs

    def num_Ys(self, nodes: Any) -> int:
        return len([node for node in nodes if "Y" in node])

    def num_lambdas(self, nodes: Any) -> int:
        return len([node for node in nodes if "lambda" in node])

    def estimatable_clique(self, clique: List[str]) -> bool:
        y_count = self.num_Ys(clique)
        lambda_count = self.num_lambdas(clique)

        return y_count <= 1 or lambda_count == 0

    def _lambda_pass(
        self,
        L_train: np.ndarray,
        lambda_marginals: Any,
        lambda_moment_vals: Any,
        lambda_equals_one: Any,
        lambda_zeros: Any,
        abstention_probabilities: Any,
        verbose: bool = False,
    ) -> Any:
        """
        Make the pass over L_train.

        In this pass, we need to:
        * Compute all the joint marginal distributions over multiple lambda's (lambda_marginals)
        * Compute the probabilities that some set of lambda's are all equal to zero (lambda_zeros)
        * Compute all the lambda moments, including conditional moments (lambda_moment_vals)
        * Compute the probability that the product of some lambdas is zero (abstention_probabilities)
        """

        # Do the fast cases first
        easy_marginals = {
            marginal: None for marginal in lambda_marginals if len(marginal) == 1
        }
        easy_moments = {
            moment: None
            for moment in lambda_moment_vals
            if type(moment[0]) != type(()) and len(moment) <= 2  # noqa: E721
        }
        easy_equals_one = {
            factor: None
            for factor in lambda_equals_one
            if type(factor[0]) != type(()) and len(factor) == 1  # noqa: E721
        }
        easy_zeros = {
            condition: None for condition in lambda_zeros if len(condition) == 1
        }
        easy_abstention_probs = {
            factor: None for factor in abstention_probabilities if len(factor) == 1
        }

        means = np.einsum("ij->j", L_train) / L_train.shape[0]
        covariance = np.einsum("ij,ik->jk", L_train, L_train) / L_train.shape[0]

        lf_cardinality = 3 if self.allow_abstentions else 2
        lf_values = (-1, 0, 1) if self.allow_abstentions else (-1, 1)
        for marginal in easy_marginals:
            idx = marginal[0]
            counts = [
                np.sum(L_train[:, idx] == val) / L_train.shape[0] for val in lf_values
            ]
            easy_marginals[marginal] = JointProbabilityDistribution(
                ["lambda_{}".format(idx)], [lf_cardinality], counts
            )

            if marginal in easy_equals_one:
                easy_equals_one[marginal] = counts[-1]
            if marginal in easy_zeros:
                easy_zeros[marginal] = counts[1]
            if marginal in easy_abstention_probs:
                easy_abstention_probs[marginal] = counts[1]
        for moment in easy_moments:
            if len(moment) == 1:
                easy_moments[moment] = means[moment[0]]
            else:
                easy_moments[moment] = covariance[moment[0]][moment[1]]
        for factor in easy_equals_one:
            if easy_equals_one[factor] is None:
                easy_equals_one[factor] = (
                    np.sum(L_train[:, factor[0]] == 1) / L_train.shape[0]
                )
        for condition in easy_zeros:
            if easy_zeros[condition] is None:
                idx = condition[0]
                easy_zeros[condition] = np.sum(L_train[:, idx] == 0) / L_train.shape[0]
        for factor in easy_abstention_probs:
            if easy_abstention_probs[factor] is None:
                idx = factor[0]
                easy_abstention_probs[factor] = (
                    np.sum(L_train[:, idx] == 0) / L_train.shape[0]
                )

        # Time for the remaining cases
        lambda_marginals = {
            key: lambda_marginals[key]
            for key in lambda_marginals
            if key not in easy_marginals
        }
        lambda_moment_vals = {
            key: lambda_moment_vals[key]
            for key in lambda_moment_vals
            if key not in easy_moments
        }
        lambda_equals_one = {
            key: lambda_equals_one[key]
            for key in lambda_equals_one
            if key not in easy_equals_one
        }
        lambda_zeros = {
            key: lambda_zeros[key] for key in lambda_zeros if key not in easy_zeros
        }
        abstention_probabilities = {
            key: abstention_probabilities[key]
            for key in abstention_probabilities
            if key not in easy_abstention_probs
        }

        # For the rest, loop through L_train
        if (
            len(lambda_marginals) > 0
            or len(lambda_moment_vals) > 0
            or len(lambda_equals_one) > 0
            or len(lambda_zeros) > 0
            or len(abstention_probabilities) > 0
        ):
            # Figure out which lambda states we need to keep track of
            lambda_marginal_counts = {}
            lambda_marginal_vecs = {}
            lf_values = (-1, 0, 1) if self.allow_abstentions else (-1, 1)
            for lambda_marginal in lambda_marginals:
                nodes = ["lambda_{}".format(idx) for idx in lambda_marginal]
                vals = {lf: lf_values for lf in nodes}
                lf_vecs = sorted(
                    [[vec_dict[lf] for lf in nodes] for vec_dict in dict_product(vals)]
                )
                counts = {tuple(lf_vec): 0 for lf_vec in lf_vecs}  # type: ignore
                lambda_marginal_vecs[lambda_marginal] = lf_vecs
                lambda_marginal_counts[lambda_marginal] = counts

            lambda_moment_counts = {moment: 0 for moment in lambda_moment_vals}
            lambda_moment_basis = {moment: 0 for moment in lambda_moment_vals}
            lambda_equals_one_counts = {factor: 0 for factor in lambda_equals_one}
            lambda_equals_one_basis = {factor: 0 for factor in lambda_equals_one}
            lambda_zero_counts = {condition: 0 for condition in lambda_zeros}
            abstention_probability_counts = {
                factor: 0 for factor in abstention_probabilities
            }

            for data_point in L_train:
                for marginal in lambda_marginals:
                    mask = [data_point[idx] for idx in marginal]
                    lambda_marginal_counts[marginal][tuple(mask)] += 1  # type: ignore
                for moment in lambda_moment_vals:
                    if type(moment[0]) == type(()):  # noqa: E721
                        pos_mask = [data_point[idx] for idx in moment[0]]
                        zero_mask = [data_point[idx] for idx in moment[1]]

                        if np.count_nonzero(zero_mask) == 0:
                            lambda_moment_basis[moment] += 1
                        lambda_moment_counts[moment] += int(np.prod(pos_mask))
                    else:
                        mask = [data_point[idx] for idx in moment]
                        lambda_moment_counts[moment] += int(np.prod(mask))
                        lambda_moment_basis[moment] += 1
                for factor in lambda_equals_one:
                    if type(factor[0]) == type(()):  # noqa: E721
                        pos_mask = [data_point[idx] for idx in factor[0]]
                        zero_mask = [data_point[idx] for idx in factor[1]]

                        if np.count_nonzero(zero_mask) == 0:
                            lambda_equals_one_basis[factor] += 1
                            if np.prod(pos_mask) == 1:
                                lambda_equals_one_counts[factor] += 1
                    else:
                        mask = [data_point[idx] for idx in factor]
                        if np.prod(mask) == 1:
                            lambda_equals_one_counts[factor] += 1
                        lambda_equals_one_basis[factor] += 1
                for zero_condition in lambda_zeros:
                    zero_mask = [data_point[idx] for idx in zero_condition]
                    if np.count_nonzero(zero_mask) == 0:
                        lambda_zero_counts[zero_condition] += 1
                for factor in abstention_probability_counts:
                    zero_mask = [data_point[idx] for idx in factor]
                    if np.prod(zero_mask) == 0:
                        abstention_probability_counts[factor] += 1

            lf_cardinality = 3 if self.allow_abstentions else 2
            for marginal in lambda_marginals:
                nodes = ["lambda_{}".format(idx) for idx in marginal]
                lf_vecs = lambda_marginal_vecs[marginal]
                counts = lambda_marginal_counts[marginal]

                lambda_marginals[marginal] = JointProbabilityDistribution(
                    nodes,
                    [lf_cardinality for node in nodes],
                    [float(counts[tuple(lf_vec)]) / len(L_train) for lf_vec in lf_vecs],  # type: ignore
                )

            for moment in lambda_moment_vals:
                if lambda_moment_basis[moment] == 0:
                    moment_val = 0
                else:
                    moment_val = (
                        lambda_moment_counts[moment] / lambda_moment_basis[moment]  # type: ignore
                    )
                lambda_moment_vals[moment] = moment_val

            for factor in lambda_equals_one:
                if lambda_equals_one_basis[factor] == 0:
                    prob = 0.0
                else:
                    prob = (
                        lambda_equals_one_counts[factor]
                        / lambda_equals_one_basis[factor]
                    )
                lambda_equals_one[factor] = prob

            for zero_condition in lambda_zeros:
                lambda_zeros[zero_condition] = lambda_zero_counts[zero_condition] / len(
                    L_train
                )

            for factor in abstention_probabilities:
                abstention_probabilities[factor] = abstention_probability_counts[
                    factor
                ] / len(L_train)

        # Update with the easy values
        lambda_marginals.update(easy_marginals)
        lambda_moment_vals.update(easy_moments)
        lambda_equals_one.update(easy_equals_one)
        lambda_zeros.update(easy_zeros)
        abstention_probabilities.update(easy_abstention_probs)

        return (
            lambda_marginals,
            lambda_moment_vals,
            lambda_equals_one,
            lambda_zeros,
            abstention_probabilities,
        )

    def _generate_r_vector(self, clique: List[str]) -> List[Tuple[int]]:
        """
        The r vector is the vector of probability values that needs to be on the RHS
        of the B_matrix * e_vector = r_vector to make e_vector have the right values.

        When there are abstentions, the mapping works as follows:
        * Each probability is some combination of
            P(A * B *  ... * C = 1, D = 0, E = 0, ..., F = 0)
        * The A, B, ..., C can include any LF, and the Y variable.
        * The D, E, ..., F can include any LF
        * Let the A, B, ..., C set be called the "equals one set"
        * Let the D, E, ..., F set be called the "equals zero set"
        * Then, for each entry in the e vector:
          * If there is a -1 in an LF spot, add the LF to the "equals zero set"
          * If there is a 0 in the LF spot, add the LF to the "equals one set"
          * If there is a -1 in the Y variable spot, add it to the "equals one set"

        When there are no abstentions, each probability is just defined by the
        "equals one set" (i.e., P(A * B * ... * C = 1)).
        * For each entry in the e vector:
          * If there is a -1 in any spot (LF spot or Y variable), add it to the
            "equals one set"
        """
        indices = [int(node.split("_")[1]) for node in clique]
        lf_indices = sorted(indices[:-1])
        Y_idx = indices[-1]
        Y_val = "Y_{}".format(Y_idx)

        e_vec = self._generate_e_vector(clique)

        r_vec = []
        for e_vec_tup in e_vec:
            # P(a * b * ... * c = 1) for everything in this array
            r_vec_entry_equal_one = []
            # P(a = 0, b = 0, ..., c = 0) for everything in this array
            r_vec_entry_equal_zero = []
            for e_vec_entry, lf_idx in zip(e_vec_tup, lf_indices):
                # If you have abstentions, -1 means add to equal zero, 0 means add to equal one
                if self.allow_abstentions:
                    if e_vec_entry == -1:
                        r_vec_entry_equal_zero.append("lambda_{}".format(lf_idx))
                    if e_vec_entry == 0:
                        r_vec_entry_equal_one.append("lambda_{}".format(lf_idx))
                # Otherwise, -1 means add to equal one
                else:
                    if e_vec_entry == -1:
                        r_vec_entry_equal_one.append("lambda_{}".format(lf_idx))
            if e_vec_tup[-1] == -1:
                r_vec_entry_equal_one.append(Y_val)

            entries_equal_one = (
                ("1",)
                if len(r_vec_entry_equal_one) == 0
                else tuple(r_vec_entry_equal_one)
            )
            entries_equal_zero = (
                ("0",)
                if len(r_vec_entry_equal_zero) == 0
                else tuple(r_vec_entry_equal_zero)
            )
            if self.allow_abstentions:
                r_vec.append((entries_equal_one, entries_equal_zero))
            else:
                if len(r_vec_entry_equal_zero) > 0:
                    logging.info("No abstentions allowed!")
                    exit(1)
                r_vec.append(entries_equal_one)  # type: ignore

        return r_vec  # type: ignore

    def setup_marginals(self) -> None:
        # Y marginals to compute
        self.Y_marginals = {}  # type: ignore

        # Lambda marginals to compute
        self.lambda_marginals = {}  # type: ignore

        # Marginals will eventually be returned here
        self.marginals = [
            (clique, None)
            for clique in sorted(list(self.junction_tree.nodes))
            + sorted(list(self.separator_sets))
        ]

        self.observable_cliques = []
        self.non_observable_cliques = []

        for i, (clique, _) in enumerate(self.marginals):
            if self.num_Ys(clique) == 0 or self.num_lambdas(clique) == 0:
                self.observable_cliques.append(i)
            else:
                self.non_observable_cliques.append(i)

        # Write down everything we need for the observable cliques
        for idx in self.observable_cliques:
            clique = self.marginals[idx][0]
            indices = tuple(sorted([int(node.split("_")[1]) for node in clique]))

            if "Y" in clique[0]:
                if indices not in self.Y_marginals:
                    self.Y_marginals[indices] = None
            else:
                if indices not in self.lambda_marginals:
                    self.lambda_marginals[indices] = None

    def calc_r_values(self) -> None:
        # For each marginal we need to estimate, write down the r vector that we need
        self.r_vecs = {}  # Mapping from clique index to the r vector
        self.r_vals: Any = (
            {}
        )  # Mapping from a value name (like Y_1 or tuple(lambda_1, Y_1)) to its value
        for idx in self.non_observable_cliques:
            clique = sorted(self.marginals[idx][0], reverse=True)
            self.r_vec = self._generate_r_vector(clique)
            self.r_vecs[idx] = self.r_vec
            for r_val in self.r_vec:
                if r_val not in self.r_vals:
                    self.r_vals[r_val] = None

    def write_expectations(self) -> None:
        # Write down all the sets of zero conditions
        self.lambda_zeros: Any = {}

        # Write down the moment values that we need to keep track of when we walk through the L matrix
        self.Y_equals_one: Any = {}
        self.lambda_equals_one: Any = {}

        # Write down which expectations we need to solve using the triplet method
        self.expectations_to_estimate = set()
        for r_val in self.r_vals:
            if not self.allow_abstentions or r_val[1] == ("0",):  # type:ignore
                equals_one_tup = (
                    r_val if not self.allow_abstentions else r_val[0]
                )  # type:ignore

                if equals_one_tup[0] == "1":  # type:ignore
                    # If the value is 1, the probability is just 1
                    self.r_vals[r_val] = 1
                elif (
                    self.num_Ys(equals_one_tup) != 0  # type:ignore
                    and self.num_lambdas(equals_one_tup) != 0  # type:ignore
                ):
                    # If this contains lambdas and Y's, we can't observe it
                    self.expectations_to_estimate.add(r_val)
                elif self.num_Ys(equals_one_tup) != 0:  # type:ignore
                    # We need to cache this moment
                    indices = tuple(
                        sorted(
                            [
                                int(node.split("_")[1])
                                for node in equals_one_tup  # type:ignore
                            ]  # type:ignore
                        )  # type:ignore
                    )
                    if indices not in self.Y_equals_one:
                        self.Y_equals_one[indices] = None
                elif self.num_lambdas(equals_one_tup) != 0:  # type:ignore
                    # If it contains just lambdas, go through L_train
                    indices = tuple(
                        sorted(
                            [
                                int(node.split("_")[1])
                                for node in equals_one_tup  # type:ignore
                            ]
                        )
                    )
                    if indices not in self.lambda_equals_one:
                        self.lambda_equals_one[indices] = None
            else:
                # We allow abstentions, and there are clauses that are equal to zero
                equals_one_tup = r_val[0]  # type:ignore
                equals_zero_tup = r_val[1]  # type:ignore
                if (
                    self.num_lambdas(equals_one_tup) > 0  # type:ignore
                    and self.num_Ys(equals_one_tup) > 0  # type:ignore
                ):
                    # We can't observe this
                    self.expectations_to_estimate.add(r_val)
                elif self.num_lambdas(equals_one_tup) > 0:  # type:ignore
                    # Compute probability some lambda's multiply to one, subject to some zeros
                    pos_indices = tuple(
                        sorted(
                            [
                                int(node.split("_")[1])
                                for node in equals_one_tup  # type:ignore
                            ]  # type:ignore
                        )
                    )
                    zero_indices = tuple(
                        sorted(
                            [int(node.split("_")[1]) for node in equals_zero_tup]
                        )  # type:ignore
                    )

                    tup = (pos_indices, zero_indices)
                    if tup not in self.lambda_equals_one:
                        self.lambda_equals_one[tup] = None
                    if zero_indices not in self.lambda_zeros:
                        self.lambda_zeros[zero_indices] = None
                else:
                    # Compute a Y equals one probability, and multiply it by probability of zeros
                    if equals_one_tup[0] != "1":  # type:ignore
                        pos_indices = tuple(
                            sorted(
                                [
                                    int(node.split("_")[1])
                                    for node in equals_one_tup  # type:ignore
                                ]
                            )
                        )
                        if pos_indices not in self.Y_equals_one:
                            self.Y_equals_one[pos_indices] = None
                    zero_indices = tuple(
                        sorted(
                            [int(node.split("_")[1]) for node in equals_zero_tup]
                        )  # type:ignore
                    )
                    if zero_indices not in self.lambda_zeros:
                        self.lambda_zeros[zero_indices] = None

    def _compute_class_balance(
        self, class_balance: Optional[np.ndarray] = None
    ) -> JointProbabilityDistribution:
        # Generate class balance of Ys
        Ys_ordered = ["Y_{}".format(i) for i in range(self.v)]
        cardinalities = [2 for i in range(self.v)]
        if class_balance is not None:
            class_balance = class_balance / sum(class_balance)
            cb = JointProbabilityDistribution(Ys_ordered, cardinalities, class_balance)
        else:
            num_combinations = 2**self.v
            cb = JointProbabilityDistribution(
                Ys_ordered,
                cardinalities,
                [1.0 / num_combinations for i in range(num_combinations)],
            )

        return cb

    def _compute_Y_marginals(self, Y_marginals: Any) -> Any:
        for marginal in Y_marginals:
            nodes = ["Y_{}".format(idx) for idx in marginal]
            Y_marginals[marginal] = self.cb.marginal_distribution(nodes, inplace=False)

        return Y_marginals

    def _compute_Y_equals_one(self, Y_equals_one: Any) -> Any:
        # Compute from class balance
        for factor in Y_equals_one:
            nodes = ["Y_{}".format(idx) for idx in factor]

            Y_marginal = self.cb.marginal_distribution(nodes, inplace=False)
            vals = {Y: (-1, 1) for Y in nodes}
            Y_vecs = sorted(
                [[vec_dict[Y] for Y in nodes] for vec_dict in dict_product(vals)]
            )

            # Add up the probabilities of all the vectors whose values multiply to +1
            total_prob = 0
            for Y_vec in Y_vecs:
                if np.prod(Y_vec) == 1:
                    vector_prob = Y_marginal.reduce(
                        [
                            (Y_i, Y_val if Y_val == 1 else 0)
                            for Y_i, Y_val in zip(nodes, Y_vec)
                        ],
                        inplace=False,
                    ).values
                    total_prob += vector_prob

            Y_equals_one[factor] = total_prob

        return Y_equals_one

    def compute_all_marginals(
        self,
        L_train: np.ndarray,
        abstention_probabilities: List[float],
        class_balance: Optional[List[float]] = None,
        verbose: bool = False,
    ) -> None:
        # Now time to compute all the Y marginals

        self.lambda_moment_vals: Any = {}
        for moment in self.new_moment_vals:  # type: ignore
            if moment not in self.lambda_moment_vals:
                self.lambda_moment_vals[moment] = None
        self.cb = self._compute_class_balance(class_balance)
        self.Y_marginals = self._compute_Y_marginals(self.Y_marginals)

        if verbose:
            logging.info("Y marginals computed")

        self.Y_equals_one = self._compute_Y_equals_one(self.Y_equals_one)

        if verbose:
            logging.info("Y equals one computed")

        # Now time to compute the lambda moments, marginals, zero conditions, and abstention probs
        (
            lambda_marginals,
            lambda_moment_vals,
            lambda_equals_one,
            lambda_zeros,
            abstention_probabilities,
        ) = self._lambda_pass(
            L_train,
            self.lambda_marginals,
            self.lambda_moment_vals,
            self.lambda_equals_one,
            self.lambda_zeros,
            abstention_probabilities,
            verbose=verbose,
        )

        if verbose:
            logging.info("lambda marginals, moments, conditions computed")

        self.lambda_marginals = lambda_marginals
        self.lambda_moment_vals = lambda_moment_vals
        self.lambda_equals_one = lambda_equals_one
        self.lambda_zeros = lambda_zeros
        self.abstention_probabilities = abstention_probabilities

    def update_observable_cliques(self) -> None:
        # Put observable cliques in the right place
        for idx in self.observable_cliques:
            clique = self.marginals[idx][0]
            indices = tuple(sorted([int(node.split("_")[1]) for node in clique]))

            if "Y" in clique[0]:
                marginal = self.Y_marginals[indices]
            else:
                marginal = self.lambda_marginals[indices]

            self.marginals[idx] = (clique, marginal)

    def update_marginals(self) -> None:
        # Put values into the R vectors
        for r_val in self.r_vals:
            if not self.allow_abstentions or r_val[1] == ("0",):  # type:ignore
                equals_one_tup = r_val if not self.allow_abstentions else r_val[0]

                if equals_one_tup[0] == "1":  # type:ignore
                    # If the value is 1, the probability is just 1
                    pass
                elif (
                    self.num_Ys(equals_one_tup) != 0  # type:ignore
                    and self.num_lambdas(equals_one_tup) != 0  # type:ignore
                ):
                    # If this contains lambdas and Y's, we can't observe it
                    self.r_vals[r_val] = self.probability_values[r_val]  # type: ignore
                elif self.num_Ys(equals_one_tup) != 0:  # type:ignore
                    # We need to cache this moment
                    indices = tuple(
                        sorted(
                            [
                                int(node.split("_")[1])
                                for node in equals_one_tup  # type:ignore
                            ]  # type:ignore
                        )
                    )
                    self.r_vals[r_val] = self.Y_equals_one[indices]
                elif self.num_lambdas(equals_one_tup) != 0:  # type:ignore
                    indices = tuple(
                        sorted(
                            [
                                int(node.split("_")[1])
                                for node in equals_one_tup  # type:ignore
                            ]  # type:ignore
                        )
                    )
                    self.r_vals[r_val] = self.lambda_equals_one[indices]
            else:
                # We allow abstentions, and there are clauses that are equal to zero
                equals_one_tup = r_val[0]
                equals_zero_tup = r_val[1]  # type:ignore
                if (
                    self.num_lambdas(equals_one_tup) > 0  # type:ignore
                    and self.num_Ys(equals_one_tup) > 0  # type:ignore
                ):  # type:ignore
                    # We can't observe this
                    self.r_vals[r_val] = self.probability_values[r_val]  # type: ignore
                elif self.num_lambdas(equals_one_tup) > 0:  # type:ignore
                    # Compute lambda moment, subject to some zeros
                    pos_indices = tuple(
                        sorted(
                            [
                                int(node.split("_")[1])
                                for node in equals_one_tup  # type:ignore
                            ]  # type:ignore
                        )  # type:ignore
                    )
                    zero_indices = tuple(
                        sorted(
                            [
                                int(node.split("_")[1]) for node in equals_zero_tup
                            ]  # type:ignore
                        )  # type:ignore
                    )

                    tup = (pos_indices, zero_indices)
                    self.r_vals[r_val] = self.lambda_equals_one[tup]
                else:
                    # Compute a Y moment, and multiply it by probability of zeros
                    if equals_one_tup[0] != "1":  # type:ignore
                        pos_indices = tuple(
                            sorted(
                                [
                                    int(node.split("_")[1])
                                    for node in equals_one_tup  # type:ignore
                                ]  # type:ignore
                            )  # type:ignore
                        )

                        pos_prob = self.Y_equals_one[pos_indices]
                    else:
                        pos_prob = 1.0
                    zero_indices = tuple(
                        sorted(
                            [int(node.split("_")[1]) for node in equals_zero_tup]
                        )  # type:ignore
                    )
                    zero_probs = self.lambda_zeros[zero_indices]

                    self.r_vals[r_val] = pos_prob * zero_probs

    def _generate_e_vector(self, clique: List[str]) -> List[Tuple[int]]:
        """
        The e vector is a vector of assignments for a particular marginal.

        For example, in a marginal with one LF and one Y variable, and no
        abstentions, the e vector entries are:
            [
                (1, 1),
                (1, -1),
                (-1, 1),
                (-1, -1)
            ]
        The first entry of each tuple is the value of the LF, the second
        entry is the value of the Y variagble.

        In a marginal with two LFs and one Y variable and no abstentions,
        the entries are:
            [
                (1, 1, 1),
                (1, 1, -1),
                (1, -1, 1),
                (1, -1, -1),
                (-1, 1, 1),
                (-1, 1, -1),
                (-1, -1, 1),
                (-1, -1, -1)
            ]

        In a marginal with one LF, one Y variable, and abstentions:
            [
                (1, 1),
                (0, 1),
                (-1, 1),
                (1, -1),
                (0, -1),
                (-1, -1)
            ]

        Two LFs, one Y variable, and abstentions:
            [
                (1, 1, 1),
                (0, 1, 1),
                (-1, 1, 1),
                (1, 0, 1),
                (0, 0, 1),
                (-1, 0, 1),
                (1, -1, 1),
                (0, -1, 1),
                (-1, -1, 1),
                (1, 1, -1),
                (0, 1, -1),
                (-1, 1, -1),
                (1, 0, -1),
                (0, 0, -1),
                (-1, 0, -1),
                (1, -1, -1),
                (0, -1, -1),
                (-1, -1, -1)
            ]
        """
        lambda_values = [1, 0, -1] if self.allow_abstentions else [1, -1]
        e_vec = [[1], [-1]]
        for i in range(len(clique) - 1):
            new_e_vec = []
            if not self.allow_abstentions:
                for new_val in lambda_values:
                    for e_val in e_vec:
                        new_e_vec.append(e_val + [new_val])
            else:
                for e_val in e_vec:
                    for new_val in lambda_values:
                        new_e_vec.append([new_val] + e_val)
            e_vec = new_e_vec
        e_vec = [tuple(e_val) for e_val in e_vec]  # type: ignore

        return e_vec  # type: ignore

    def _generate_b_matrix(self, clique: List[str]) -> np.ndarray:
        if not self.allow_abstentions:
            b_matrix_orig = np.array([[1, 1], [1, -1]])
            b_matrix = b_matrix_orig
            for i in range(len(clique) - 1):
                b_matrix = np.kron(b_matrix, b_matrix_orig)
            b_matrix[b_matrix < 0] = 0

            return b_matrix
        else:
            a_zero = np.array([[1, 1], [1, 0]])
            b_zero = np.array([[0, 0], [0, 1]])

            c_matrix = np.array([[1, 1, 1], [1, 0, 0], [0, 1, 0]])
            d_matrix = np.array([[0, 0, 0], [0, 0, 1], [0, 0, 0]])

            a_i = a_zero
            b_i = b_zero
            for i in range(len(clique) - 1):
                a_prev = a_i
                b_prev = b_i
                a_i = np.kron(a_prev, c_matrix) + np.kron(b_prev, d_matrix)
                b_i = np.kron(a_prev, d_matrix) + np.kron(b_prev, c_matrix)

            return a_i

    def solve_marginals(self) -> None:
        # Solve for marginal values
        for idx in self.non_observable_cliques:
            clique = sorted(self.marginals[idx][0], reverse=True)
            r_vec = self.r_vecs[idx]

            r_vec_vals = np.array([self.r_vals[exp] for exp in r_vec])

            # e_vec is the vector of marginal values
            e_vec = self._generate_e_vector(clique)

            b_matrix = self._generate_b_matrix(clique)

            e_vec_vals = np.linalg.inv(b_matrix) @ r_vec_vals

            e_vec_val_index = {tup: i for i, tup in enumerate(e_vec)}
            marginal_vals = np.array(
                [e_vec_vals[e_vec_val_index[tup]] for tup in sorted(e_vec)]
            )

            if self.flip_negative:
                marginal_vals[marginal_vals < 0] = marginal_vals[marginal_vals < 0] * -1
                marginal_vals /= sum(marginal_vals)
            elif self.clamp:
                marginal_vals[marginal_vals < 0] = 1e-8
                marginal_vals /= sum(marginal_vals)

            indices = [int(node.split("_")[1]) for node in clique]  # type:ignore
            lf_indices = sorted(indices[:-1])
            Y_idx = indices[-1]

            variables = ["lambda_{}".format(i) for i in lf_indices] + [
                "Y_{}".format(Y_idx)
            ]

            # Cardinality 3 for lambda variables if you allow abstentions, 2 for Y's
            cardinalities = [
                3 if self.allow_abstentions else 2 for i in range(len(lf_indices))
            ] + [2]

            marginal = DiscreteFactor(
                variables, cardinalities, marginal_vals
            ).normalize(inplace=False)

            self.marginals[idx] = (clique, marginal)

        self.clique_marginals = self.marginals[: len(self.junction_tree.nodes)]
        self.separator_marginals = self.marginals[len(self.junction_tree.nodes) :]
        separator_degrees = {sep: 0 for sep in self.separator_sets}
        for clique1, clique2 in self.junction_tree.edges:
            separator_degrees[
                tuple(sorted(list((set(clique1).intersection(set(clique2))))))
            ] += 1
        self.separator_degrees = separator_degrees

    def initialize_parameters(self) -> None:
        self.setup_marginals()
        self.calc_r_values()
        self.write_expectations()

    def pre_process(
        self, L_train: np.ndarray, abstention_probabilities: List[float]
    ) -> None:
        self.compute_all_marginals(
            L_train, abstention_probabilities, self.class_balance
        )
        self.update_observable_cliques()

    def post_process(self) -> None:
        self.update_marginals()
        self.solve_marginals()
