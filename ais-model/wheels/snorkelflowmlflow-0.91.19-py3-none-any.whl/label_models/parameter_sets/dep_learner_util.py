import logging
import warnings
from collections import defaultdict
from typing import Any, DefaultDict, List, Optional, Set, Tuple

import numpy as np
from networkx.utils.union_find import UnionFind


class DependencyLearner(object):
    """A model for learning LF dependencies.

    This class learns the dependencies among labeling functions.
    It is based on the approach in
    [Learning Dependency Structures for Weak Supervision Models]
    (https://arxiv.org/pdf/1903.05844.pdf), published in ICML'19.
    In this approach, we use a robust principal component analysis (rPCA)
    based algorithm to decompose the inverse covariance matrix into a sparse
    component that encodes the dependency structure and a low rank component
    due to marginalizing over the latent true label variable.

    Examples
    --------
    >>> dep_learner = DependencyLearner()
    >>> dep_learner = DependencyLearner(cardinality=3)

    Parameters
    ----------
    cardinality
        Number of classes, by default 2

    Attributes
    ----------
    cardinality
        Number of classes, by default 2
    """

    def __init__(self, cardinality: int = 2) -> None:
        self.cardinality = cardinality

    def _force_singleton(
        self,
        deps: List[Tuple[int, int]],
        m: int,
        edges_only: bool = True,
        J: Optional[np.ndarray] = None,
    ) -> List[Tuple[int, int]]:
        """Force singleton separator assumption given list of dependencies.

        This translates to converting chain dependencies to fully connected clusters of dependencies.

        More information on singleton separator assumption in [AAAI'19](https://arxiv.org/pdf/1810.02840.pdf) and [ICML'19](https://arxiv.org/pdf/1903.05844.pdf) papers.

        If edges_only is set, we only allow cliques of size 2, taking the biggest edge in each larger clique
        """
        uf = UnionFind(range(m))
        for dep in deps:
            uf.union(*dep)

        if len(list(uf.to_sets())) == 1:
            raise ValueError(
                "Dependency structure is fully connected. Rerun with higher thresh_mult."
            )

        groups: DefaultDict[Any, Set[int]] = defaultdict(set)
        for i in range(m):
            groups[uf[i]].add(i)

        all_deps = set()
        for group in uf.to_sets():  # Iterate over sets.
            biggest_edge, biggest_i, biggest_j = 0.0, 0, 0
            for i in group:
                for j in group:
                    if i < j:
                        if edges_only and J is not None:
                            if abs(J[i, j]) >= biggest_edge:
                                biggest_edge, biggest_i, biggest_j = abs(J[i, j]), i, j
                        else:
                            all_deps.add((i, j))
            if edges_only and biggest_i != biggest_j:
                all_deps.add((biggest_i, biggest_j))

        return list(all_deps)

    def _get_deps_from_inverse_sig(
        self, J: np.ndarray, thresh: float
    ) -> List[Tuple[int, int]]:
        """
        Select unique dependent LF indices using values greater than thresh in J.

        NOTE: Assumes J is symmetric and returns deps (i,j) s.t. i < j.
        """
        deps = []
        for j in range(J.shape[0]):
            for i in range(j):
                if abs(J[i, j]) > thresh:
                    deps.append((i, j))
        return deps

    @staticmethod
    def frobenius_norm(M: np.ndarray) -> float:
        return np.linalg.norm(M, ord="fro")

    @staticmethod
    def shrink(M: np.ndarray, tau: float) -> np.ndarray:
        return np.sign(M) * np.maximum((np.abs(M) - tau), np.zeros(M.shape))

    def svd_threshold(self, M: np.ndarray, tau: float) -> np.ndarray:
        U, S, V = np.linalg.svd(M, full_matrices=False)
        return np.dot(U, np.dot(np.diag(self.shrink(S, tau)), V))

    def fit(
        self,
        L: np.ndarray,
        thresh_mult: float = 0.5,
        mu: float = 0,
        lam: float = 0,
        tol: float = 0,
        max_iter: int = 1000,
        iter_print: int = 100,
        verbose: bool = False,
    ) -> List[Tuple[int, int]]:
        r"""Learn dependencies among LFs.

        Learn dependencies using robust PCA based method. In case of multi-class, the method considers log2(cardinality) splits to calculate agreements and disagreements. Solves the following problem

        (\hat{S}, \hat{L}) = argmin \mathcal{L}(S - L, \Sigma_O) + lam*(mu*||S||_1 + ||L||_*)

        s.t. S - L \succ 0, L \succeq 0

        Note: Best performance requires hyperparameter search over the thresh parameter.

        Parameters
        ----------
        L
            An [n,m] matrix with values in {-1,0,1,...,k-1}
        thresh_mult
            Threshold multiplier for selecting thresh_mult * max off-diagonal entry from sparse matrix
        mu
            Parameter in objective function related to sparsity (higher value weights sparsity more)
        lam
            Parameter in objective function related to sparsity and low rank (higher value weights sparsity and low-rank more)
        verbose
            Whether solver is verbose

        Raises
        ------
        ValueError
            If L has higher cardinality than passed in or solver fails

        Returns
        -------
        List[Tuple[int, int]]
            List of tuples denoting dependencies among LFs
        """

        N = float(np.shape(L)[0])
        m = np.shape(L)[1]
        O_all = np.zeros((m, m))

        if L.max() + 1 > self.cardinality:
            raise ValueError(
                f"Does not match DependencyLearner cardinality={self.cardinality}, L has cardinality {L.max()+1}"
            )

        # calculate agreement-disagreement rates based on random class splits
        L_shift = np.copy(L)
        class_permutations: Set[tuple] = set()
        num_class_permutations = len(class_permutations)
        num_permutations = 0

        while num_permutations <= np.log2(self.cardinality):
            ordering = np.random.permutation(self.cardinality)
            class_permutations.add(tuple(ordering))

            # check if same ordering chosen earlier
            if len(class_permutations) == num_class_permutations:
                continue
            else:
                ordering = list(ordering)
                num_class_permutations = len(class_permutations)
                num_permutations += 1

                split_idx = np.floor(self.cardinality / 2).astype(int)
                L_shift[L_shift == -1] = self.cardinality + 1
                for class_thresh in ordering[0:split_idx]:
                    L_shift[L_shift == class_thresh] = -1

                L_shift[L_shift == self.cardinality + 1] = 0
                for class_thresh in ordering[split_idx : self.cardinality]:
                    L_shift[L_shift == class_thresh] = 1

                O_all += (np.dot(L_shift.T, L_shift)) / (N - 1) - np.outer(
                    np.mean(L_shift, axis=0), np.mean(L_shift, axis=0)
                )
        sigma_O = O_all / float(len(class_permutations))
        pinv_sigma_O = np.linalg.pinv(sigma_O)

        S = np.zeros(pinv_sigma_O.shape)
        R = np.zeros(pinv_sigma_O.shape)

        # Set hyperparameters
        if mu == 0:
            mu = np.prod(pinv_sigma_O.shape) / (4 * self.frobenius_norm(pinv_sigma_O))
        mu_inv = 1 / mu
        if lam == 0:
            lam = 1 / np.sqrt(np.max(pinv_sigma_O.shape))

        # Train the model
        curr_iter = 0
        err = np.Inf
        Sk = S
        Yk = R
        Lk = np.zeros(pinv_sigma_O.shape)

        if tol == 0:
            tol = 1e-7 * self.frobenius_norm(pinv_sigma_O)

        while (err > tol) and curr_iter < max_iter:
            Lk = self.svd_threshold(pinv_sigma_O - Sk + mu_inv * Yk, mu_inv)
            Sk = self.shrink(pinv_sigma_O - Lk + (mu_inv * Yk), mu_inv * lam)
            Yk = Yk + mu * (pinv_sigma_O - Lk - Sk)
            err = self.frobenius_norm(pinv_sigma_O - Lk - Sk)
            curr_iter += 1
            if verbose and (
                (curr_iter % iter_print) == 0
                or curr_iter == 1
                or curr_iter > max_iter
                or err <= tol
            ):
                print("Iteration: {0}, error: {1}".format(curr_iter, err))

        # Find dependencies from sparse matrix
        J_hat = Sk
        if J_hat is None:
            raise ValueError(
                "There may be no dependencies among LFs. Otherwise, try different mu and lambda values."
            )
        off_diag = (np.abs(J_hat) - np.diag(np.diag(np.abs(J_hat)))).ravel()
        q1, q3 = np.percentile(np.sort(off_diag), [25, 75])
        outlier_bound = q3 + 2.0 * (q3 - q1)
        thresh = thresh_mult * np.max(off_diag)

        # add warning if no outliers present in off diagonal entries
        if np.max(off_diag) < outlier_bound:
            warnings.warn(
                "There may be no real dependencies among LFs, returned list contains extraneous dependencies. Include thresh_mult = 1.0 in parameter search."
            )

        # find dependencies
        deps_all = self._get_deps_from_inverse_sig(J_hat, thresh)
        deps = self._force_singleton(deps_all, m, edges_only=True, J=J_hat)
        logging.info(f"Deps found = {deps}")
        return deps
