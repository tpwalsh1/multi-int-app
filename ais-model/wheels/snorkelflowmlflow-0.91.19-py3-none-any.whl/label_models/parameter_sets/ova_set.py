from typing import List, Optional

import numpy as np
import torch

from label_models.input_sets.input_set import InputSet
from label_models.label_model_zoo.label_model_wrapper import LabelModelWrapper
from label_models.parameter_sets.covariance_completion import CovarianceCompletionSet


class OVASet(CovarianceCompletionSet):
    def __init__(
        self,
        input_set: InputSet,
        use_triplets: bool = False,
        class_balance: Optional[List[float]] = None,
    ):
        super().__init__(input_set)
        self.use_triplets = use_triplets
        self.class_balance = class_balance

    def update_parameters(
        self, binarized_models: List[LabelModelWrapper], dv: int, device: str = "cpu"
    ) -> None:
        pr_vote = torch.diag(self.O)
        with torch.no_grad():
            # We are updating a slice of a torch.Parameter(requires_grad=True) below.
            if self.use_triplets:
                ((_, cb1),) = binarized_models[
                    dv
                ].label_model.parameter_set.Y_equals_one.items()

                cb = [1.0 - cb1, cb1]

                if (
                    self.cardinality == 2
                ):  # Special case: we only need one triplets model
                    if dv == 1:
                        return
                    mu_vals = np.concatenate(
                        [
                            item[1].values[::2, :] / cb  # type: ignore
                            for item in binarized_models[
                                dv
                            ].label_model.parameter_set.clique_marginals
                        ]
                    )
                    self.mu = torch.nn.Parameter(  # type: ignore
                        torch.Tensor(mu_vals).to(device)
                    )
                    return

                else:
                    mu_vals = torch.tensor(
                        [
                            item[1].values[0][0] / (1.0 - cb1)  # type: ignore
                            for item in binarized_models[
                                dv
                            ].label_model.parameter_set.clique_marginals
                        ]
                    )

                    self.mu[dv :: self.cardinality, dv] = mu_vals
                    for j in range(self.cardinality):
                        if j != dv:
                            self.mu[dv :: self.cardinality, j] = (
                                pr_vote[dv :: self.cardinality] - mu_vals * self.p[dv]
                            ) / (1.0 - self.p[dv])
            else:
                self.mu[dv :: self.cardinality, dv] = binarized_models[dv].label_model.parameter_set.mu[  # type: ignore
                    ::2, 0
                ]
                for j in range(self.cardinality):
                    if j != dv:
                        self.mu[dv :: self.cardinality, j] = (
                            pr_vote[dv :: self.cardinality]
                            - binarized_models[dv].label_model.parameter_set.mu[::2, 0] * self.p[dv]  # type: ignore
                        ) / (1.0 - self.p[dv])
