from typing import Dict, Optional

import numpy as np
import torch

from label_models.parameter_sets.covariance_completion import CovarianceCompletionSet
from label_models.utils.graph_utils import _CliqueData


class CovarianceCompletionMultiVoteSet(CovarianceCompletionSet):
    def _generate_O(self, L: np.ndarray, device: Optional[str] = "cpu") -> None:  # type: ignore
        """Generate overlaps and conflicts matrix from label matrix.

        This requires some special functionality since we have multivotes
        Roughly, this means that we
        i) learn from the singleton votes
        ii) create probability distributions from the multivotes
        iii) generalize overlaps to overlapping distributions

        Parameters
        ----------
        L
            An [n,m] matrix containing lists of labels from {-1,0,1,...,k-1}
        """
        # Pull out singleton votes
        num_samples, num_lfs = L.shape
        self.singleton_prob = np.zeros((num_lfs, self.cardinality))
        for i in range(num_samples):
            for j in range(num_lfs):
                if len(L[i, j]) == 1 and L[i, j][0] > -1:
                    self.singleton_prob[j, L[i, j][0]] += 1
        singleton_votes: np.ndarray = self.singleton_prob.sum(axis=1)  # type: ignore
        singleton_votes[singleton_votes == 0] += 1

        # Build regularized singleton vote probabilities
        self.singleton_prob /= singleton_votes[:, None]
        self.singleton_prob = (
            self.singleton_prob * 0.9 + np.ones(self.cardinality) * 0.05
        )

        # Build distributions for multivote
        self.L_prob = np.zeros((num_samples, num_lfs * self.cardinality))

        for i in range(num_samples):
            for j in range(num_lfs):
                lf_votes = [
                    self.singleton_prob[j, val] if val in L[i, j] else 0
                    for val in range(self.cardinality)
                ]
                if np.sum(lf_votes) > 0:
                    self.L_prob[
                        i, j * self.cardinality : (j + 1) * self.cardinality
                    ] = lf_votes / np.sum(
                        lf_votes
                    )  # type: ignore

        self.d = self.L_prob.shape[1]
        self.O = (
            torch.from_numpy(self.L_prob.T @ self.L_prob / num_samples)
            .float()
            .to(device)
        )

    def _generate_c_data(self) -> None:
        """Generates the helper clique structure, now broken out for the multivote case"""
        self.c_data: Dict[int, _CliqueData] = {}
        for i in range(self.num_lfs):
            self.c_data[i] = _CliqueData(
                start_index=i * self.cardinality,
                end_index=(i + 1) * self.cardinality,
                max_cliques={
                    j
                    for j in self.c_tree.nodes()
                    if i in self.c_tree.nodes[j]["members"]
                },
            )

    def initialize_L_matrix(  # type: ignore
        self, L: np.ndarray, device: Optional[str] = "cpu"
    ) -> None:
        self._set_constants(L)
        self._set_class_balance(self.class_balance, device)
        self._create_tree()
        self._generate_c_data()
        self._generate_O(L, device=device)
        self._init_params()
