from collections import defaultdict
from itertools import chain
from typing import Any, DefaultDict, Dict, List, Optional, Union

import numpy as np
import sparse
import torch
import torch.nn as nn
from munkres import Munkres  # type: ignore

from label_models.input_sets.input_set import InputSet
from label_models.label_model_constants import (
    GT_ALPHA,
    GT_BETA,
    MAX_LM_CARDINALITY,
    MIN_LF_IMPORTANCE,
)
from label_models.parameter_sets.parameter_set import ParameterSet
from label_models.utils.graph_utils import _CliqueData, get_clique_tree
from label_spaces.common.sparse_dense_utils import densify, onehot
from lf_analysis_utils import LFAnalysis as LFAnalysisUtils


class CovarianceCompletionSet(nn.Module, ParameterSet):
    """
    ParameterSet corresponding to CovarianceCompletion model
    """

    def __init__(
        self,
        input_set: InputSet,
        class_balance: Optional[List[float]] = None,
        create_tree: bool = True,
    ) -> None:
        nn.Module.__init__(self)
        ParameterSet.__init__(self, input_set)
        self.needs_post_processing = True
        self.name = "CovarianceCompletionSet"
        self.class_balance = class_balance
        self.create_tree = create_tree

    def _set_constants(self, L: np.ndarray) -> None:
        self.num_samples, self.num_lfs = L.shape
        if self.num_lfs < 3:
            raise ValueError(f"L_train should have at least 3 labeling functions")

    def _create_L_ind(self, L: np.ndarray) -> np.ndarray:
        """Convert a label matrix with labels in 0...k to a one-hot format.

        Parameters
        ----------
        L
            An [n,m] label matrix with values in {0,1,...,k}

        Returns
        -------
        np.ndarray
            An [n,m*k] dense np.ndarray with values in {0,1}
        """
        L_ind = np.zeros((self.num_samples, self.num_lfs * self.cardinality))
        for y in range(1, self.cardinality + 1):
            # A[x::y] slices A starting at x at intervals of y
            # e.g., np.arange(9)[0::3] == np.array([0,3,6])
            L_ind[:, (y - 1) :: self.cardinality] = np.where(L == y, 1, 0)
        return L_ind

    def _get_augmented_label_matrix(
        self, L: np.ndarray, higher_order: bool = False
    ) -> np.ndarray:
        """Create augmented version of label matrix.

        In augmented version, each column is an indicator
        for whether a certain source or clique of sources voted in a certain
        pattern.

        Parameters
        ----------
        L
            An [n,m] label matrix with values in {0,1,...,k}
        higher_order
            Whether to include higher-order correlations (e.g. LF pairs) in matrix

        Returns
        -------
        np.ndarray
            An [n,m*k] dense matrix with values in {0,1}
        """
        # Create a helper data structure which maps cliques (as tuples of member
        # sources) --> {start_index, end_index, maximal_cliques}, where
        # the last value is a set of indices in this data structure
        self.c_data: Dict[int, _CliqueData] = {}
        for i in range(self.num_lfs):
            self.c_data[i] = _CliqueData(
                start_index=i * self.cardinality,
                end_index=(i + 1) * self.cardinality,
                max_cliques={
                    j
                    for j in self.c_tree.nodes()
                    if i in self.c_tree.nodes[j]["members"]
                },
            )

        L_ind = self._create_L_ind(L)

        # Get the higher-order clique statistics based on the clique tree
        # First, iterate over the maximal cliques (nodes of c_tree) and
        # separator sets (edges of c_tree)
        if higher_order:
            L_aug = np.copy(L_ind)
            for item in chain(self.c_tree.nodes(), self.c_tree.edges()):
                if isinstance(item, int):
                    C = self.c_tree.nodes[item]
                elif isinstance(item, tuple):
                    C = self.c_tree[item[0]][item[1]]
                else:
                    raise ValueError(item)
                members = list(C["members"])

                # With unary maximal clique, just store its existing index
                C["start_index"] = members[0] * self.cardinality
                C["end_index"] = (members[0] + 1) * self.cardinality
            return L_aug
        else:
            return L_ind

    def _generate_O(
        self, L: np.ndarray, higher_order: bool = False, device: Optional[str] = "cpu"
    ) -> None:
        """Generate overlaps and conflicts matrix from label matrix.

        Parameters
        ----------
        L
            An [n,m] label matrix with values in {0,1,...,k}
        higher_order
            Whether to include higher-order correlations (e.g. LF pairs) in matrix
        """
        L_aug = self._get_augmented_label_matrix(L, higher_order=higher_order)
        self.d = L_aug.shape[1]
        self.O = torch.from_numpy(L_aug.T @ L_aug / self.num_samples).float().to(device)

    def _init_params(self) -> None:
        r"""Initialize the learned params.

        - \mu is the primary learned parameter, where each row corresponds to
        the probability of a clique C emitting a specific combination of labels,
        conditioned on different values of Y (for each column); that is:

            self.mu[i*self.cardinality + j, y] = P(\lambda_i = j | Y = y)

        and similarly for higher-order cliques.

        Raises
        ------
        ValueError
            If prec_init shape does not match number of LFs
        """
        # Initialize mu so as to break basic reflective symmetry
        # Note that we are given either a single or per-LF initial precision
        # value, prec_i = P(Y=y|\lf=y), and use:
        #   mu_init = P(\lf=y|Y=y) = P(\lf=y) * prec_i / P(Y=y)

        # Handle single values
        if isinstance(self.train_config.prec_init, (int, float)):
            self._prec_init = self.train_config.prec_init * torch.ones(self.num_lfs)
        if self._prec_init.shape[0] != self.num_lfs:
            raise ValueError(f"prec_init must have shape {self.num_lfs}.")

        # Get the per-value labeling propensities
        # Note that self.O must have been computed already!
        lps = torch.diag(self.O).cpu().detach().numpy()

        # TODO: Update for higher-order cliques!
        self.mu_init = torch.zeros(self.d, self.cardinality)
        for i in range(self.num_lfs):
            for y in range(self.cardinality):
                idx = i * self.cardinality + y
                mu_init = torch.clamp(lps[idx] * self._prec_init[i] / self.p[y], 0, 1)
                self.mu_init[idx, y] += mu_init

        # Initialize based on self.mu_init
        self.mu = nn.Parameter(self.mu_init.clone()).float()  # type: ignore

        # Build the mask over O^{-1}
        self._build_mask()

    def _build_mask(self) -> None:
        """Build mask applied to O^{-1}, O for the matrix approx constraint."""
        self.mask = torch.ones(self.d, self.d).bool()
        for ci in self.c_data.values():
            si = ci.start_index
            ei = ci.end_index
            for cj in self.c_data.values():
                sj, ej = cj.start_index, cj.end_index

                # Check if ci and cj are part of the same maximal clique
                # If so, mask out their corresponding blocks in O^{-1}
                if len(ci.max_cliques.intersection(cj.max_cliques)) > 0:
                    self.mask[si:ei, sj:ej] = 0
                    self.mask[sj:ej, si:ei] = 0

        # These loss functions get all their data directly from the LabelModel

    # (for better or worse). The unused *args make these compatible with the
    # Classifer._train() method which expect loss functions to accept an input.
    def _loss_l2(self, l2: float = 0) -> torch.Tensor:
        r"""L2 loss centered around mu_init, scaled optionally per-source.

        In other words, diagonal Tikhonov regularization,
            ||D(\mu-\mu_{init})||_2^2
        where D is diagonal.

        Parameters
        ----------
        l2
            A float or np.array representing the per-source regularization
            strengths to use, by default 0

        Returns
        -------
        torch.Tensor
            L2 loss between learned mu and initial mu
        """
        if isinstance(l2, (int, float)):
            D = l2 * torch.eye(self.d)
        else:
            D = torch.diag(torch.from_numpy(l2)).type(torch.float32)
        D = D.to(self.train_config.device)
        # Note that mu is a matrix and this is the *Frobenius norm*
        return torch.norm(D @ (self.mu - self.mu_init)) ** 2

    def _loss_mu(self, l2: float = 0) -> torch.Tensor:
        r"""Overall mu loss.

        Parameters
        ----------
        l2
            A float or np.array representing the per-source regularization
                strengths to use, by default 0

        Returns
        -------
        torch.Tensor
            Overall mu loss between learned mu and initial mu
        """
        loss_1 = torch.norm((self.O - self.mu @ self.P @ self.mu.t())[self.mask]) ** 2
        loss_2 = torch.norm(torch.sum(self.mu @ self.P, 1) - torch.diag(self.O)) ** 2
        return loss_1 + loss_2 + self._loss_l2(l2=l2)

    def _set_class_balance(
        self,
        class_balance: Optional[Union[np.ndarray, List[float]]],
        device: Optional[str] = "cpu",
    ) -> None:
        """Set a prior for the class balance.

        In order of preference:
        1) Use user-provided class_balance
        2) Assume uniform class distribution
        """
        if class_balance is not None:
            self.p = np.array(class_balance)
            if len(self.p) != self.cardinality:
                raise ValueError(
                    f"class_balance has {len(self.p)} entries. Does not match LabelModel cardinality {self.cardinality}."
                )
        else:
            self.p = (1 / self.cardinality) * np.ones(self.cardinality)

        if np.any(self.p == 0):
            raise ValueError(
                f"Class balance prior is 0 for class(es) {np.where(self.p)[0]}."
            )
        self.P = torch.diag(torch.from_numpy(self.p)).float().to(device)

    def _create_tree(self) -> None:
        nodes = range(self.num_lfs)
        self.c_tree = get_clique_tree(nodes, [])

    def _clamp_params(self) -> None:
        """Clamp the values of the learned parameter vector.

        Clamp the entries of self.mu to be in [mu_eps, 1 - mu_eps], where mu_eps is
        either set by the user, or defaults to 1 / 10 ** np.ceil(np.log10(self.num_samples)).

        Note that if mu_eps is set too high, e.g. in sparse settings where LFs
        mostly abstain, this will result in learning conditional probabilities all
        equal to mu_eps (and/or 1 - mu_eps)!  See issue #1422.

        Note: Use user-provided value of mu_eps in train_config, else default to
            mu_eps = 1 / 10 ** np.ceil(np.log10(self.num_samples))
        this rounding is done to make it more obvious when the parameters have been
        clamped.
        """
        if self.train_config.mu_eps is not None:
            mu_eps = self.train_config.mu_eps
        else:
            mu_eps = min(0.01, 1 / 10 ** np.ceil(np.log10(self.num_samples)))
        self.mu.data = self.mu.clamp(mu_eps, 1 - mu_eps)  # type: ignore

    def _break_col_permutation_symmetry(self) -> None:
        r"""Heuristically choose amongst (possibly) several valid mu values.

        If there are several values of mu that equivalently satisfy the optimization
        objective, as there often are due to column permutation symmetries, then pick
        the solution that trusts the user-written LFs most.

        In more detail, suppose that mu satisfies (minimizes) the two loss objectives:
            1. O = mu @ P @ mu.T
            2. diag(O) = sum(mu @ P, axis=1)
        Then any column permutation matrix Z that commutes with P will also equivalently
        satisfy these objectives, and thus is an equally valid (symmetric) solution.
        Therefore, we select the solution that maximizes the summed probability of the
        LFs being accurate when not abstaining.

            \sum_lf \sum_{y=1}^{cardinality} P(\lf = y, Y = y)
        """
        mu = self.mu.cpu().detach().numpy()
        P = self.P.cpu().detach().numpy()
        d, k = mu.shape
        # We want to maximize the sum of diagonals of matrices for each LF. So
        # we start by computing the sum of conditional probabilities here.
        probs_sum = sum([mu[i : i + k] for i in range(0, self.num_lfs * k, k)]) @ P

        munkres_solver = Munkres()
        Z = np.zeros([k, k])

        # Compute groups of indicess with equal prior in P.
        groups: DefaultDict[float, List[int]] = defaultdict(list)
        for i, f in enumerate(P.diagonal()):
            groups[np.around(f, 3)].append(i)
        for group in groups.values():
            if len(group) == 1:
                Z[group[0], group[0]] = 1.0  # Identity permutation
                continue
            # Compute submatrix corresponding to the group.
            probs_proj = probs_sum[[[g] for g in group], group]
            # Use the Munkres algorithm to find the optimal permutation.
            # We use minus because we want to maximize diagonal sum, not minimize,
            # and transpose because we want to permute columns, not rows.
            permutation_pairs = munkres_solver.compute(-probs_proj.T)
            for i, j in permutation_pairs:
                Z[group[i], group[j]] = 1.0

        # Set mu according to permutation
        self.mu = nn.Parameter(  # type: ignore
            torch.Tensor(mu @ Z).to(self.train_config.device)  # type: ignore
        )

    def _get_conditional_probs(self, mu: np.ndarray) -> np.ndarray:
        r"""Return the estimated conditional probabilities table given parameters mu.

        Given a parameter vector mu, return the estimated conditional probabilites
        table cprobs, where cprobs is an (m, k+1, k)-dim np.ndarray with:

            cprobs[i, j, k] = P(\lf_i = j-1 | Y = k)

        where m is the number of LFs, k is the cardinality, and cprobs includes the
        conditional abstain probabilities P(\lf_i = -1 | Y = y).

        Parameters
        ----------
        mu
            An [m * k, k] np.ndarray with entries in [0, 1]

        Returns
        -------
        np.ndarray
            An [m, k + 1, k] np.ndarray conditional probabilities table.
        """
        cprobs = np.zeros((self.num_lfs, self.cardinality + 1, self.cardinality))
        for i in range(self.num_lfs):
            # si = self.c_data[(i,)]['start_index']
            # ei = self.c_data[(i,)]['end_index']
            # mu_i = mu[si:ei, :]
            mu_i = mu[i * self.cardinality : (i + 1) * self.cardinality, :]
            cprobs[i, 1:, :] = mu_i

            # The 0th row (corresponding to abstains) is the difference between
            # the sums of the other rows and one, by law of total probability
            cprobs[i, 0, :] = 1 - mu_i.sum(axis=0)
        return cprobs

    def get_conditional_probs(self) -> np.ndarray:
        r"""Return the estimated conditional probabilities table.

        Return the estimated conditional probabilites table cprobs, where cprobs is an
        (m, k+1, k)-dim np.ndarray with:

            cprobs[i, j, k] = P(\lf_i = j-1 | Y = k)

        where m is the number of LFs, k is the cardinality, and cprobs includes the
        conditional abstain probabilities P(\lf_i = -1 | Y = y).

        Returns
        -------
        np.ndarray
            An [m, k + 1, k] np.ndarray conditional probabilities table.
        """
        return self._get_conditional_probs(self.mu.cpu().detach().numpy())

    def get_lf_importances(self) -> np.ndarray:
        """Return the vector of learned LF weights for combining LFs.

        Returns
        -------
        np.ndarray
            [m,1] vector of learned LF weights for combining LFs.

        Example
        -------
        >>> L = np.array([[1, 1, 1], [1, 1, -1], [-1, 0, 0], [0, 0, 0]])
        >>> label_model = LabelModel(verbose=False)
        >>> label_model.fit(L, seed=123)
        >>> np.around(label_model.get_weights(), 2)  # doctest: +SKIP
        array([0.99, 0.99, 0.99])
        """
        accs = np.zeros(self.num_lfs)
        cprobs = self.get_conditional_probs()
        for i in range(self.num_lfs):
            accs[i] = np.diag(cprobs[i, 1:, :] @ self.P.cpu().detach().numpy()).sum()
        importances = accs / self.coverage
        # In the case of LFs with 0 coverage their accs / coverage would evaluate to np.inf
        # which would erroneously lead to them having importances of 1 so we replace the inf with 1e-6
        importances[np.where(importances == np.inf)] = MIN_LF_IMPORTANCE
        return np.clip(importances, MIN_LF_IMPORTANCE, 1.0)

    def initialize_L_matrix(
        self,
        L: np.ndarray,
        device: Optional[str] = "cpu",
        generate_O_matrix: bool = True,
    ) -> None:
        L = L + 1  # convert to {0, 1, ..., k}
        if L.max() > self.cardinality:
            raise ValueError(
                f"L_train has cardinality {L.max()}, cardinality={self.cardinality} passed in."
            )

        self._set_constants(L)
        self._set_class_balance(self.class_balance, device)

        if self.create_tree:
            self._create_tree()

        if generate_O_matrix:
            self._generate_O(L, device=device)
            self._init_params()

        lf_analysis = LFAnalysisUtils(L - 1)
        self.coverage = lf_analysis.lf_coverages()

    def inference_L_matrix(self, L: np.ndarray) -> None:
        self._set_constants(L)
        L_aug = self._get_augmented_label_matrix(L)
        return L_aug

    def move_model_to_device(self, device: Optional[str] = "cpu") -> None:
        self.mu_init = self.mu_init.to(device)

    def calc_loss(self, l2: torch.Tensor) -> torch.Tensor:
        return self._loss_mu(l2=l2)

    def post_process_parameters(self) -> None:
        self._clamp_params()
        self._break_col_permutation_symmetry()

    def return_parameters(self) -> None:
        return self.mu

    def update_train_config(self, train_config: Any) -> None:
        self.train_config = train_config

    def update_config(self, config: Any) -> None:
        self.config = config

    def update_coverage(self, coverage: np.ndarray) -> None:
        self.coverage = coverage

    def params_from_gt(
        self,
        L: np.ndarray,
        Y_ground_truth: np.ndarray,
        alpha: float = GT_ALPHA,
        beta: float = GT_BETA,
    ) -> None:
        """Estimate mu parameters using ground truth
        Parameters
        ----------
        L
            An [n,m,r] tensor with values in {-1,0,1,...,k-1}
        Y_ground_truth
            Ground truth labels to be integrated in LM. This can be the same or
            different from Y_dev (used only for class balance)
        """

        if Y_ground_truth.ndim == 1:
            gt_inds = Y_ground_truth > -1
            Y_ground_truth = onehot(Y_ground_truth[gt_inds], self.cardinality)
        else:
            gt_inds = Y_ground_truth.sum(axis=1) > 0
            Y_ground_truth = Y_ground_truth[gt_inds, :]

        vote_mask = L > -1

        n, m = L.shape

        rows, cols = np.where(vote_mask)

        L_sparse = sparse.COO(
            (rows, cols, L[rows, cols]), 1, shape=(n, m, self.cardinality)
        )

        # This variable addresses the multi-polar aspect of the LFs, which are used for non-high card.
        # This is not very satisfying but the best we can do without direct info about possible votes
        # for each LF. Assumption is that a class vote never triggered simply is not in scope for the LF.

        if self.cardinality < MAX_LM_CARDINALITY:
            legit_vote_mat = (L_sparse.sum(axis=0).todense() > 0)[:, :, np.newaxis]

        L_sparse = L_sparse[gt_inds]
        vote_mask = vote_mask[gt_inds]

        if self.cardinality < MAX_LM_CARDINALITY:
            # Here we estimate Mu as in other label models, as Pr(L|class), allowing for multipolarity

            # We regularize by adding in a prior joint distribution that divides out our phantom "incorrect" counts
            # evenly across classes using calculated class balance in self.p

            # Because the sparse lib exhibits random outputs with empty tensors, we'll avoid
            # edge cases with no gt by first constructing the prior mode and then adding any
            # counts from gt on top.

            # In order to preserve previous behavior, this makes default Mu = 0 everywhere when
            # there is no prior and no gt.

            beta_mat = (1 - np.eye(self.cardinality)) * self.p[:, np.newaxis]
            alpha_mat = np.diag(beta_mat.sum(axis=0)) * alpha
            beta_mat *= beta

            Z = np.full((self.cardinality,), alpha + beta).astype("float")

            joint = (
                alpha_mat[np.newaxis, :, :] + beta_mat[np.newaxis, :, :]
            ) * legit_vote_mat

            if gt_inds.sum() > 0:
                Z += Y_ground_truth.sum(axis=0)
                joint += densify(L_sparse.T.dot(Y_ground_truth)).swapaxes(1, 0)

            mu_gt = joint / Z[np.newaxis, np.newaxis, :].clip(1e-10)

            # Theoretically should not have to clip but let's just be safe.
            mu_gt = np.reshape(mu_gt, (m * self.cardinality, self.cardinality)).clip(
                0, 1
            )

            self.mu_gt = torch.nn.Parameter(  # type: ignore
                torch.Tensor(mu_gt).to(self.train_config.device)  # type: ignore
            )
        else:  # High-cardinality case, so we do not produce full m * card**2 mu matrix, instead
            # we simply estimate precisions Pr(class_i|L votes i)
            joint = densify(
                (L_sparse * Y_ground_truth[:, np.newaxis, :]).sum(axis=(0, 2))
            )
            mu_gt = (alpha + joint) / (
                alpha + beta + vote_mask.sum(axis=0).clip(min=1e-10)
            )

            self.mu_gt = torch.nn.Parameter(  # type: ignore
                torch.Tensor(mu_gt).to(self.train_config.device)  # type: ignore
            )

        self.mu = self.mu_gt

    def params_from_gt_multilabel(
        self,
        L: sparse._coo.COO,
        Y_ground_truth: sparse._coo.COO,
        alpha: float = GT_ALPHA,
        beta: float = GT_BETA,
    ) -> None:
        """Estimate mu parameters using ground truth
        Parameters
        ----------
        L
            A [num_examples, num_lfs, num_classes] matrix
        Y_ground_truth
            Ground truth labels to be integrated in LM.
        """
        joint = densify((Y_ground_truth[:, np.newaxis, :, :] * L).sum(axis=(0, 3)))
        Z = densify(L.sum(axis=(0, 3)))
        mu = (joint + alpha) / (Z + alpha + beta).clip(1e-3)

        self.mu = mu
