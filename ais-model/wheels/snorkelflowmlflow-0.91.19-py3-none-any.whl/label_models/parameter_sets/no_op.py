import numpy as np

from label_models.input_sets.input_set import InputSet
from label_models.label_model_constants import NO_OP_LF_ACCURACY
from label_models.parameter_sets.parameter_set import ParameterSet


class NoOpSet(ParameterSet):
    """
    ParameterSet with no parameters for parameter free models.
    """

    def __init__(self, input_set: InputSet) -> None:
        ParameterSet.__init__(self, input_set)
        self.name = "NoOpSet"
        self.parameters_solved = True

    def get_lf_importances(self) -> np.ndarray:
        return np.full((self.cardinality,), NO_OP_LF_ACCURACY)
