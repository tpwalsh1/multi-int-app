from typing import List, Optional

import numpy as np
import sparse

from label_models.input_sets.input_set import InputSet
from label_models.parameter_sets.parameter_set import ParameterSet
from label_spaces.common.sparse_dense_utils import densify


class BeamingSet(ParameterSet):
    def __init__(
        self,
        input_set: InputSet,
        prior_info_gain_params: Optional[List[float]] = None,
        prior_info_gain_conf: float = 10,
        class_balance: Optional[List[float]] = None,
    ) -> None:
        ParameterSet.__init__(self, input_set)
        self.name = "BeamingSet"
        self.class_balance = class_balance
        self.prior_info_gain_params = prior_info_gain_params
        self.prior_info_gain_conf = prior_info_gain_conf
        self.parameters_solved = False

    def get_lf_importances(self) -> np.ndarray:
        if isinstance(self.logMu, np.ndarray):  # type: ignore
            Pr_class_given_lf = np.exp(self.logMu[:, 1:, :])  # type: ignore

            if self.class_balance is not None:
                Pr_class_given_lf *= np.asarray(self.class_balance)[
                    np.newaxis, np.newaxis, :
                ]

        else:
            Pr_class_given_lf = sparse.elemwise(np.exp, self.logMu[:, 1:, :] + np.log(1e-10))  # type: ignore
            Pr_class_given_lf -= Pr_class_given_lf.fill_value

            if self.class_balance is not None:
                Pr_class_given_lf = Pr_class_given_lf * sparse.COO.from_numpy(
                    np.asarray(self.class_balance)[np.newaxis, np.newaxis, :]
                )

        Pr_class_given_lf /= Pr_class_given_lf.sum(axis=2)[:, :, np.newaxis].clip(1e-10)

        classinds = np.arange(self.cardinality)
        precisions = Pr_class_given_lf[:, classinds, classinds]

        lf_polarity = self.lf_polarity.astype("float")  # type: ignore
        if self.class_balance is not None:
            lf_polarity *= np.asarray(self.class_balance)[np.newaxis, :]

        precisions = densify((precisions * lf_polarity).sum(axis=1)) / lf_polarity.sum(
            axis=1
        )
        precisions_final = np.full((len(self.lf_legit),), None)  # type: ignore
        precisions_final[self.lf_legit] = precisions  # type: ignore

        return precisions_final
