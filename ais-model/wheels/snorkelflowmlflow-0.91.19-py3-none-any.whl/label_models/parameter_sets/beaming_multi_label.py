from typing import List, Optional

import numpy as np
import sparse

from label_models.input_sets.input_set import InputSet
from label_models.parameter_sets.parameter_set import ParameterSet
from label_spaces.common.sparse_dense_utils import densify


class BeamingMultiLabelSet(ParameterSet):
    def __init__(
        self,
        input_set: InputSet,
        prior_info_gain_params: Optional[List[float]] = None,
        prior_info_gain_conf: float = 10,
        class_balance: Optional[List[float]] = None,
    ) -> None:
        ParameterSet.__init__(self, input_set)
        self.name = "BeamingMultiLabelSet"
        self.class_balance = class_balance
        self.prior_info_gain_params = prior_info_gain_params
        self.prior_info_gain_conf = prior_info_gain_conf
        self.parameters_solved = False

    def get_lf_importances(self) -> np.ndarray:
        Pr_class_presence_given_lf = sparse.elemwise(np.exp, self.logMu[0] + np.log(1e-10))  # type: ignore
        Pr_class_presence_given_lf -= Pr_class_presence_given_lf.fill_value
        Pr_class_presence_given_lf *= sparse.COO(
            self.C[np.newaxis, np.newaxis, np.newaxis, :, :]  # type: ignore
        )

        Pr_class_presence_given_lf /= Pr_class_presence_given_lf.sum(axis=4)[
            :, :, :, :, np.newaxis
        ].clip(1e-10)

        precisions = sparse.diagonal(
            sparse.diagonal(Pr_class_presence_given_lf, axis1=1, axis2=3),
            axis1=1,
            axis2=2,
        )

        lf_polarity = self.lf_polarity.astype("float").todense()  # type: ignore
        lf_polarity *= self.C[np.newaxis, :, :]  # type: ignore

        precisions = densify(
            (precisions * lf_polarity).sum(axis=(1, 2))
        ) / lf_polarity.sum(axis=(1, 2))

        precisions_final = np.zeros((len(self.lf_legit),))  # type: ignore
        precisions_final[self.lf_legit] = precisions  # type: ignore

        return precisions_final
