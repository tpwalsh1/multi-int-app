import random
from itertools import chain, product
from typing import Any, List, Optional, Tuple

import numpy as np
import torch

from label_models.input_sets.input_set import InputSet
from label_models.parameter_sets.covariance_completion import CovarianceCompletionSet
from label_models.parameter_sets.dep_learner_util import DependencyLearner
from label_models.utils.graph_utils import _CliqueData, get_clique_tree
from lf_analysis_utils import LFAnalysis as LFAnalysisUtils


class DependencyAwareSet(CovarianceCompletionSet):
    def __init__(
        self,
        input_set: InputSet,
        learn_deps: bool = True,
        deps: Optional[List[Tuple[int, int]]] = None,
        thresh_mult: float = 0.5,
        mu: float = 0,
        lam: float = 0,
        class_balance: Optional[List[float]] = None,
    ) -> None:
        if deps is None:
            deps = []
        super().__init__(input_set)
        if deps is None:  # type: ignore
            deps = []
        self.name = "DependencyAwareSet"
        self.learn_deps = learn_deps
        self.deps = deps
        self.thresh_mult = thresh_mult
        self.mu = mu
        self.lam = lam
        self.class_balance = class_balance

    def _get_augmented_label_matrix(self, L: np.ndarray, higher_order: bool = False) -> np.ndarray:  # type: ignore
        """Create augmented version of label matrix.

        In augmented version, each column is an indicator
        for whether a certain source or clique of sources voted in a certain
        pattern.

        Parameters
        ----------
        L
            An [n,m] label matrix with values in {0,1,...,k}

        Returns
        -------
        np.ndarray
            An [n,m*k] dense matrix with values in {0,1}
        """
        L_ind = super()._get_augmented_label_matrix(L)

        # Get the higher-order clique statistics based on the clique tree
        # First, iterate over the maximal cliques (nodes of c_tree) and
        # separator sets (edges of c_tree)
        self.c_tree: Any
        if higher_order:
            L_aug = np.copy(L_ind)
            for item in chain(self.c_tree.nodes(), self.c_tree.edges()):
                if isinstance(item, int):
                    C = self.c_tree.nodes[item]
                    C_type = "node"
                elif isinstance(item, tuple):
                    C = self.c_tree[item[0]][item[1]]
                    C_type = "edge"
                else:
                    raise ValueError(item)
                members = list(C["members"])

                nc = len(members)

                # If a unary maximal clique, just store its existing index
                if nc == 1:
                    C["start_index"] = members[0] * self.cardinality
                    C["end_index"] = (members[0] + 1) * self.cardinality

                # Else add one column for each possible value
                else:
                    L_C = np.ones((self.num_samples, self.cardinality**nc))
                    for i, vals in enumerate(
                        product(range(self.cardinality), repeat=nc)
                    ):
                        for j, v in enumerate(vals):
                            L_C[:, i] *= L_ind[:, members[j] * self.cardinality + v]

                    # Add to L_aug and store the indices
                    if L_aug is not None:
                        C["start_index"] = L_aug.shape[1]
                        C["end_index"] = L_aug.shape[1] + L_C.shape[1]
                        L_aug = np.hstack([L_aug, L_C])
                    else:
                        C["start_index"] = 0
                        C["end_index"] = L_C.shape[1]
                        L_aug = L_C

                    # Add to self.c_data as well
                    id = tuple(members) if len(members) > 1 else members[0]
                    self.c_data[id] = _CliqueData(
                        start_index=C["start_index"],
                        end_index=C["end_index"],
                        max_cliques={item} if C_type == "node" else set(item),
                    )
            return L_aug
        else:
            return L_ind

    def _generate_O(
        self, L: np.ndarray, higher_order: bool = False, device: Optional[str] = "cpu"
    ) -> None:  # type: ignore
        """Generate overlaps and conflicts matrix from label matrix.

        Parameters
        ----------
        L
            An [n,m] label matrix with values in {0,1,...,k}
        """
        L_aug = self._get_augmented_label_matrix(L, higher_order=self.higher_order)
        self.L_aug = L_aug
        self.d = L_aug.shape[1]
        self.O = torch.from_numpy(L_aug.T @ L_aug / self.num_samples).float().to(device)

    def _set_structure(self) -> None:
        nodes = range(self.num_lfs)
        assert self.deps is not None
        self.c_tree = get_clique_tree(nodes, self.deps)  # type: ignore
        if self.deps is not None and len(self.deps) > 0:
            self.higher_order = True
        else:
            self.higher_order = False

    def inference_L_matrix(self, L: np.ndarray) -> np.ndarray:
        self._set_constants(L)
        L_aug = self._get_augmented_label_matrix(L, higher_order=self.higher_order)
        return L_aug

    def initialize_L_matrix(  # type: ignore
        self, L: np.ndarray, device: Optional[str] = "cpu"
    ) -> None:
        deps = self.deps
        if self.learn_deps:
            dep_learner = DependencyLearner(cardinality=self.cardinality)
            learned_deps = dep_learner.fit(L, self.thresh_mult, self.mu, self.lam)
            deps += learned_deps

        self.deps = deps
        self._set_constants(L)
        self._set_structure()

        random.seed(self.train_config.seed)
        np.random.seed(self.train_config.seed)
        torch.manual_seed(self.train_config.seed)

        L_shift = L + 1  # Convert to {0, 1, ..., k}
        if L_shift.max() > self.cardinality:
            raise ValueError(
                f"L has cardinality {L_shift.max()}, cardinality={self.cardinality} passed in."
            )

        self._set_class_balance(self.class_balance)
        lf_analysis = LFAnalysisUtils(L)
        self.coverage = lf_analysis.lf_coverages()

        self._generate_O(L_shift, device=device)
        self._init_params()
