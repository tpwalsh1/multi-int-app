import pickle
from abc import ABC

from label_models.input_sets.input_set import InputSet


class ParameterSet(ABC):
    def __init__(self, input_set: InputSet) -> None:
        self.input_set = input_set
        self.parameters_solved = False
        self.name = "ParameterSet"
        self.cardinality = input_set.label_space.cardinality

    def save(self, destination: str) -> None:
        """Save parameter set.

        Parameters
        ----------
        destination
            Filename for saving parameter set

        Example
        -------
        >>> parameter_set.save('./saved_parameter_set.pkl')  # doctest: +SKIP
        """
        f = open(destination, "wb")
        pickle.dump(self.__dict__, f)
        f.close()

    def load(self, source: str) -> None:
        """Load existing parameter set.

        Parameters
        ----------
        source
            Filename to load parameter set from

        Example
        -------
        Load parameters saved in ``saved_parameter_set``

        >>> label_model.load('./saved_parameter_set.pkl')  # doctest: +SKIP
        """
        f = open(source, "rb")
        tmp_dict = pickle.load(f)
        f.close()
        self.__dict__.update(tmp_dict)
