from typing import Any, List, Sequence, Tuple, Type, Union

import numpy as np
import sparse

from label_models.inference_engines.inference_engine import InferenceEngine
from label_models.input_sets.input_set import InputSet
from label_models.parameter_sets.parameter_set import ParameterSet
from label_models.utils.utils import (
    get_kl_threshold,
    interpolation_lm_predict,
    interpolation_lm_predict_proba,
)
from label_spaces.base import LabelSpace
from label_spaces.common.sparse_dense_utils import (
    make_multilabel_lfs_dense,
    make_multilabel_lfs_sparse,
    make_singlelabel_lfs_dense,
    make_singlelabel_lfs_sparse,
)


class BaseInferenceLabelModel:
    def __init__(
        self,
        input_set: InputSet,
        parameter_set: ParameterSet,
        inference_engine: InferenceEngine,
        sparse_predict: bool = True,
        sparse_fit: bool = True,
    ):
        self.input_set = input_set
        self.parameter_set = parameter_set
        self.inference_engine = inference_engine
        self.sparse_predict = sparse_predict
        self.sparse_fit = sparse_fit

    @classmethod
    def from_label_model(cls, label_model: Any) -> "BaseInferenceLabelModel":
        return cls(
            input_set=label_model.input_set,
            parameter_set=label_model.parameter_set,
            inference_engine=label_model.inference_engine,
            sparse_predict=label_model.sparse_predict,
            sparse_fit=label_model.sparse_fit,
        )

    @classmethod
    def from_lm_wrapper(cls, lm_wrapper: Any) -> "BaseInferenceLabelModel":
        return cls.from_label_model(lm_wrapper.label_model)

    def get_label_space(self) -> LabelSpace:
        return self.input_set.label_space

    def predict(
        self,
        L: sparse._coo.COO,
        tie_break_policy: str = "abstain",
        filter_uncertain_labels: bool = True,
        filter_unlabeled: bool = True,
        return_probs: bool = True,
    ) -> Union[np.ndarray, Tuple[np.ndarray, np.ndarray]]:
        probs = self.predict_proba(L)

        if filter_unlabeled:
            lf_abstains = self.input_set.label_space.compute_lf_abstains(L, probs)
        else:
            lf_abstains = np.full((L.shape[0],), False)

        filter_uncertain_labels_threshold = (
            get_kl_threshold(self.parameter_set.cardinality)
            if filter_uncertain_labels
            else 0.0
        )

        preds = self.input_set.label_space.probs_to_preds_with_threshold(
            probs,
            lf_abstains,
            tie_break_policy=tie_break_policy,
            filter_uncertain_labels_threshold=filter_uncertain_labels_threshold,
        )

        if return_probs:
            return preds, probs
        return preds

    def predict_proba(self, L: sparse._coo.COO) -> np.ndarray:
        L = self.format_L_matrix(L, method="predict")
        return self.inference_engine.predict_proba(
            L,
            parameter_set=self.parameter_set,
            cardinality=self.parameter_set.cardinality,
        )

    # Accounting for one or two LMs that use L matrices of different types (and are thus prob not even usable in-app)
    def format_L_matrix(
        self, L: Union[sparse._coo.core.COO, np.ndarray, List], method: str
    ) -> Union[sparse._coo.core.COO, np.ndarray]:
        if method not in {"fit", "predict"}:
            raise ValueError("format_L_matrix method is not 'fit' or 'predict'")

        if isinstance(L, List):
            L = np.asarray(L)

        if (self.sparse_fit and method == "fit") or (
            self.sparse_predict and method == "predict"
        ):
            if isinstance(L, sparse._coo.core.COO):
                return L
            else:
                return make_singlelabel_lfs_sparse(
                    L, self.input_set.label_space.cardinality
                )

        else:
            if isinstance(L, np.ndarray):
                return L
            else:
                return make_singlelabel_lfs_dense(L)


class InterpolationInferenceLabelModel(BaseInferenceLabelModel):
    def __init__(
        self,
        label_model_1: BaseInferenceLabelModel,
        label_model_2: BaseInferenceLabelModel,
        gt_interpolation: float = 0.2,
        use_multi_label: bool = False,
    ):
        super().__init__(
            input_set=label_model_1.input_set,
            parameter_set=label_model_1.parameter_set,
            inference_engine=label_model_1.inference_engine,
        )
        self.label_model_1 = label_model_1
        self.label_model_2 = label_model_2
        self.gt_interpolation = gt_interpolation
        self.use_multi_label = use_multi_label

    @classmethod
    def from_lm_wrapper(cls, lm_wrapper: Any) -> "InterpolationInferenceLabelModel":
        lm_1 = BaseInferenceLabelModel.from_label_model(
            lm_wrapper.label_model_1.label_model
        )
        lm_2 = BaseInferenceLabelModel.from_label_model(
            lm_wrapper.label_model_2.label_model
        )
        return cls(
            label_model_1=lm_1,
            label_model_2=lm_2,
            gt_interpolation=lm_wrapper.gt_interpolation,
            use_multi_label=lm_wrapper.use_multi_label,
        )

    def get_label_space(self) -> LabelSpace:
        return self.label_model_1.get_label_space()

    def predict_proba(self, L: sparse._coo.COO) -> np.ndarray:
        return interpolation_lm_predict_proba(
            L, self.label_model_1, self.label_model_2, self.gt_interpolation
        )

    def predict(
        self,
        L: sparse._coo.COO,
        tie_break_policy: str = "abstain",
        filter_uncertain_labels: bool = True,
        filter_unlabeled: bool = True,
        return_probs: bool = True,
    ) -> Union[np.ndarray, Tuple[np.ndarray, np.ndarray]]:
        return interpolation_lm_predict(
            L=L,
            label_model_1=self.label_model_1,
            label_model_2=self.label_model_2,
            use_multi_label=self.use_multi_label,
            gt_interpolation=self.gt_interpolation,
            tie_break_policy=tie_break_policy,
            filter_unlabeled=filter_unlabeled,
            filter_uncertain_labels=filter_uncertain_labels,
            return_probs=return_probs,
        )


# This is a native multi-label model the implementation assumes
class MultiLabelModelInferenceLabelModel(BaseInferenceLabelModel):
    def __init__(
        self,
        input_set: InputSet,
        parameter_set: ParameterSet,
        inference_engine: InferenceEngine,
        sparse_fit: bool = True,
        sparse_predict: bool = True,
    ):
        super().__init__(
            input_set=input_set,
            parameter_set=parameter_set,
            inference_engine=inference_engine,
            sparse_predict=sparse_predict,
            sparse_fit=sparse_fit,
        )

    def predict_proba(self, L: Union[np.ndarray, sparse._coo.COO]) -> np.ndarray:
        return self.inference_engine.predict_proba(
            self.format_L_matrix(L, "predict"),
            parameter_set=self.parameter_set,
            cardinality=self.parameter_set.cardinality,
        )

    def format_L_matrix(
        self, L: Union[sparse._coo.core.COO, np.ndarray, List], method: str
    ) -> Union[sparse._coo.core.COO, np.ndarray]:
        """Accounts for one or two LMs that use L matrices of different types (and are thus prob not even usable in-app)"""
        if method not in {"fit", "predict"}:
            raise ValueError("format_L_matrix method is not 'fit' or 'predict'")

        if isinstance(L, List):
            L = np.asarray(L)

        if (self.sparse_fit and method == "fit") or (
            self.sparse_predict and method == "predict"
        ):
            if isinstance(L, sparse._coo.core.COO):
                return L
            else:
                return make_multilabel_lfs_sparse(L)

        else:
            if isinstance(L, np.ndarray):
                return L
            else:
                return make_multilabel_lfs_dense(L)

    def predict(
        self,
        L: Union[np.ndarray, sparse._coo.COO],
        tie_break_policy: str = "abstain",
        filter_uncertain_labels: bool = True,
        filter_unlabeled: bool = True,
        return_probs: bool = True,
    ) -> Union[np.ndarray, Tuple[np.ndarray, np.ndarray]]:
        original_probabilities = self.predict_proba(L)

        if filter_unlabeled:
            original_abstains = self.input_set.label_space.compute_lf_abstains(L, original_probabilities)  # type: ignore
        else:
            original_abstains = np.full((L.shape[0],), False)

        filter_uncertain_labels_threshold = (
            get_kl_threshold(2) if filter_uncertain_labels else 0.0
        )

        (
            _,
            new_probabilities,
            new_abstains,
            _,
        ) = self.input_set.label_space._compute_probs_and_abstains_from_lm(
            [], original_probabilities, original_abstains, None
        )
        preds = self.input_set.label_space.probs_to_preds_with_threshold(
            new_probabilities,  # type: ignore
            new_abstains,  # type: ignore
            tie_break_policy=tie_break_policy,
            filter_uncertain_labels_threshold=filter_uncertain_labels_threshold,
        )

        if return_probs:
            # Convert probs from List to np.ndarray to match its return type
            return preds, np.asarray(new_probabilities)
        return preds


# This class are for label models that are not natively multi-label
# there is a separate label model per class
class LabelModelMultiLabelInferenceLabelModel(BaseInferenceLabelModel):
    def __init__(self, label_models: Sequence[Any], cardinality: int = 2):
        self.multilabel_models = label_models
        self.cardinality = cardinality

    @classmethod
    def from_lm_wrapper(
        cls, lm_wrapper: Any
    ) -> "LabelModelMultiLabelInferenceLabelModel":
        label_model_list = [
            BaseInferenceLabelModel.from_label_model(lm)
            for lm in lm_wrapper.label_model.multilabel_models
        ]
        return cls(
            label_models=label_model_list,
            cardinality=lm_wrapper.label_model.cardinality,
        )

    def predict_proba(self, L: np.ndarray) -> np.ndarray:
        """Return label probabilities P(Y | \lambda).

        Wrapper for the multilabel case, calls predict_proba for each model

        Parameters
        ----------
        L
            An [n,m,r] tensor containing lists of labels from {-1,0,1,...,k-1}

        Returns
        -------
        np.ndarray
            An [n,k,r] tensor of probabilistic labels
        """
        n, m, r = L.shape
        proba = np.zeros((n, self.cardinality, r))  # type: ignore

        for i in range(r):
            proba[:, :, i] = self.multilabel_models[i].predict_proba(L[:, :, i])

        return proba


def map_lm_wrapper_to_inference_lm(lm_wrapper: Any) -> Type[BaseInferenceLabelModel]:
    obj_names = {t.__name__ for t in type(lm_wrapper).__mro__}
    if "InterpolationLabelModel" in obj_names:
        return InterpolationInferenceLabelModel
    elif "CovarianceCompletionMultiLabelModel" in obj_names:
        return LabelModelMultiLabelInferenceLabelModel
    # Run this after since `MultiLabelModel` is a substring of CovarianceCompletionMultiLabelModel
    elif any(["MultiLabelModel" in name for name in obj_names]):
        return MultiLabelModelInferenceLabelModel
    return BaseInferenceLabelModel
