from __future__ import annotations

from typing import TYPE_CHECKING, List, Optional

import numpy as np
import sparse

from label_models.inference_engines.inference_engine import InferenceEngine
from label_spaces.common.sparse_dense_utils import (
    densify,
    slice_sparse_tensor,
    sparse_any,
)

if TYPE_CHECKING:
    from label_models.parameter_sets.parameter_set import ParameterSet


class SoftMajorityLabelVoterMultiLabel(InferenceEngine):

    """Soft majority vote label model."""

    def __init__(
        self,
        cardinality: int = 2,
        trusted_lf_indexes: Optional[List[int]] = None,
        use_sparse: bool = True,
    ) -> None:
        self.cardinality = cardinality
        self.trusted_lf_indexes = trusted_lf_indexes
        self.use_sparse = use_sparse
        super().__init__()

    def predict_proba(
        self,
        L: sparse._coo.COO,
        cardinality: int = 2,
        parameter_set: Optional[ParameterSet] = None,
    ) -> np.ndarray:
        """Predict probabilities using soft majority vote.

        Assign vote by calculating soft majority vote across all labeling functions.

        Parameters
        ----------
        L
            An [num_examples, num_lfs, num_classes, 2] tensor of labels

        Returns
        -------
        np.ndarray
            A [num_examples, num_classes] array of probabilistic labels

        """

        if self.trusted_lf_indexes is not None:
            lf_num = L.shape[1]
            non_trusted_lf_indexes = list(
                set(range(lf_num)) - set(self.trusted_lf_indexes)
            )

            L_trusted = slice_sparse_tensor(L, self.trusted_lf_indexes, axis=1)

            trusted_class_samples = sparse_any(
                L_trusted, axis=(1, 3), sparse_output=False
            )

            votes_trusted = (
                L_trusted * trusted_class_samples[:, np.newaxis, :, np.newaxis]
            ).sum(axis=1)

            L_non_trusted = slice_sparse_tensor(L, non_trusted_lf_indexes, axis=1)

            votes_non_trusted = (
                L_non_trusted
                * (1 - trusted_class_samples[:, np.newaxis, :, np.newaxis])
            ).sum(axis=1)
            votes = votes_trusted + votes_non_trusted
        else:
            votes = L.sum(axis=1)

        votes += (sparse_any(votes, axis=2, sparse_output=True) == 0)[:, :, np.newaxis]
        probas = densify(votes[:, :, 1] / (votes.sum(axis=2)))

        return probas
