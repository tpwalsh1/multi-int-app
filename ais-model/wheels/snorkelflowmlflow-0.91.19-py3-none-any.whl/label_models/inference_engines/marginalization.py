from typing import List, Optional

import numpy as np

from label_models.inference_engines.inference_engine import InferenceEngine
from label_models.parameter_sets.parameter_set import ParameterSet
from label_models.utils.utils import dict_product


class Marginalization(InferenceEngine):
    def __init__(self) -> None:
        super().__init__()

    def predict_proba(
        self,
        L: np.ndarray,
        cardinality: int = 2,
        parameter_set: Optional[ParameterSet] = None,
        trusted_lf_indexes: Optional[List[int]] = None,
    ) -> np.ndarray:
        """Predict the probabilities of the Y's given the outputs of the LF's.

        L: a m x |Y| matrix of of LF outputs. L[k][i] is the value of \lambda_i on item k.
            1 means positive, -1 means negative, 0 means abstain.

        Let C be the set of all cliques in the graphical model, and S the set of all separator sets.
        Let d(s) for s \in S be the number of maximal cliques that s separates.

        Then, we have the following formula for the joint probability:

          P(\lambda_1, ..., \lambda_m, Y_1, ..., Y_v) =
              \prod_{c \in C} \mu_c(c) / \prod_{s \in S} [\mu_s(s)]^(d(s) - 1)

        Where \mu_c and \mu_s are the marginal probabilities of a clique c or a separator s, respectively.
        We solved for these marginals during the fit function, so now we use them for inference!

        Outputs: a 2^v x |Y| matrix of probabilities. The probabilities for the combinations are
          sorted lexicographically.
        """
        L = np.array(L)

        Y_vecs = parameter_set.enumerate_ys()  # type: ignore
        numerator_vals_by_lambda_count = []
        max_lambda_count = max(
            [
                parameter_set.num_lambdas(clique)  # type: ignore
                for clique, marginal in parameter_set.clique_marginals  # type: ignore
            ]
        )

        # Compute all marginals that have lambda_count lambdas
        for lambda_count in range(1, max_lambda_count + 1):
            correct_lambda_cliques = [
                (clique, marginal)
                for clique, marginal in parameter_set.clique_marginals  # type: ignore
                if parameter_set.num_lambdas(clique) == lambda_count  # type: ignore
            ]
            if len(correct_lambda_cliques) == 0:
                continue
            lambda_options = (-1, 0, 1) if parameter_set.allow_abstentions else (-1, 1)  # type: ignore
            lambda_vals = {i: lambda_options for i in range(lambda_count)}
            lambda_vecs = sorted(
                [
                    [vec_dict[i] for i in range(lambda_count)]
                    for vec_dict in dict_product(lambda_vals)
                ]
            )

            # Index by Y_vec, clique, and lambda value
            A_lambda = np.zeros(
                (len(Y_vecs), len(correct_lambda_cliques), len(lambda_vecs))
            )

            for i, Y_vec in enumerate(Y_vecs):
                for j, (clique, marginal) in enumerate(correct_lambda_cliques):
                    lambda_marginal = marginal.reduce(  # type: ignore
                        [
                            ("Y_{}".format(Y_idx), y_val if y_val == 1 else 0)
                            for Y_idx, y_val in enumerate(Y_vec)
                            if "Y_{}".format(Y_idx) in clique
                        ],
                        inplace=False,
                    )
                    for k, lambda_vec in enumerate(lambda_vecs):
                        A_lambda[i, j, k] = lambda_marginal.reduce(
                            [
                                (clique_node, lambda_options.index(lambda_val))
                                for clique_node, lambda_val in zip(clique, lambda_vec)
                            ],
                            inplace=False,
                        ).values

            indexes = np.array(
                [
                    [
                        np.sum(
                            [
                                (
                                    (
                                        lambda_options.index(
                                            data_point[int(node.split("_")[1])]
                                        )
                                    )
                                    * ((len(lambda_options)) ** (lambda_count - i - 1))
                                )
                                for i, node in enumerate(clique[:-1])
                            ]
                        )
                        for clique, marginal in correct_lambda_cliques
                    ]
                    for data_point in L
                ]
            ).astype("int")

            clique_values = A_lambda[:, np.arange(indexes.shape[1]), indexes]

            numerator_values = np.prod(clique_values, axis=2)
            numerator_vals_by_lambda_count.append(numerator_values)

        # Compute all marginals that have zero lambdas
        zero_lambda_cliques = [
            (clique, marginal)
            for clique, marginal in parameter_set.clique_marginals  # type: ignore
            if parameter_set.num_lambdas(clique) == 0  # type: ignore
        ]
        if len(zero_lambda_cliques) > 0:
            A_y = np.zeros((len(Y_vecs), len(zero_lambda_cliques)))
            for i, Y_vec in enumerate(Y_vecs):
                for j, (clique, marginal) in enumerate(zero_lambda_cliques):
                    Y_marginal = marginal.reduce(  # type: ignore
                        [
                            ("Y_{}".format(Y_idx), y_val if y_val == 1 else 0)
                            for Y_idx, y_val in enumerate(Y_vec)
                            if "Y_{}".format(Y_idx) in clique
                        ],
                        inplace=False,
                    )
                    A_y[i, j] = Y_marginal.values

            y_probs = np.prod(A_y, axis=1)

            numerator_ys = np.array([y_probs] * L.shape[0]).T  # noqa: E231

        # Compute all separator marginals
        zero_lambda_separators = [
            (clique, marginal)
            for clique, marginal in parameter_set.separator_marginals  # type: ignore
            if parameter_set.num_lambdas(clique) == 0  # type: ignore
        ]

        A_y_sep = np.zeros((len(Y_vecs), len(zero_lambda_separators)))
        for i, Y_vec in enumerate(Y_vecs):
            for j, (clique, marginal) in enumerate(zero_lambda_separators):
                Y_marginal = marginal.reduce(  # type: ignore
                    [
                        ("Y_{}".format(Y_idx), y_val if y_val == 1 else 0)
                        for Y_idx, y_val in enumerate(Y_vec)
                        if "Y_{}".format(Y_idx) in clique
                    ],
                    inplace=False,
                )
                A_y_sep[i, j] = Y_marginal.values ** (
                    parameter_set.separator_degrees[clique] - 1  # type: ignore
                )

        y_probs_sep = np.prod(A_y_sep, axis=1)

        denominator_ys = np.array([y_probs_sep] * L.shape[0]).T  # noqa: E231

        predictions = numerator_vals_by_lambda_count[0]
        for lambda_numerator in numerator_vals_by_lambda_count[1:]:
            predictions = predictions * lambda_numerator
        if len(zero_lambda_cliques) > 0:
            predictions = predictions * numerator_ys
        predictions = predictions / denominator_ys

        normalized_preds = (
            predictions.T
            / np.array(([predictions.sum(axis=0)] * len(Y_vecs))).T  # noqa: E231
        )

        return normalized_preds
