from __future__ import annotations

from typing import TYPE_CHECKING, Any, List, Optional

import numpy as np

from label_models.inference_engines.inference_engine import InferenceEngine

if TYPE_CHECKING:
    from label_models.parameter_sets.parameter_set import ParameterSet


class NormalizationMultiVote(InferenceEngine):

    """Normalize Probabilities"""

    def __init__(self) -> None:
        super().__init__()
        self.VALID_PARAMETER_SETS = ["CovarianceCompletionSet"]

    def predict_proba(
        self,
        L: np.ndarray,
        cardinality: int = 2,
        parameter_set: Optional[ParameterSet] = None,
        trusted_lf_indexes: Optional[List[int]] = None,
    ) -> np.ndarray:
        """Return label probabilities P(Y | \lambda).
        Handles the case of multiple votes by weighting emission probs
        Parameters
        ----------
        L
            An [n,m] matrix containing lists of labels from {-1,0,1,...,k-1}
        Returns
        -------
        np.ndarray
            An [n,k] array of probabilistic labels
        """
        num_samples, num_lfs = L.shape
        mu = parameter_set.return_parameters().cpu().detach().numpy()  # type: ignore
        proba = np.zeros((num_samples, cardinality))

        for i in range(num_samples):
            for j in range(num_lfs):
                # Extract multivotes and weight by lf emission probability
                lf_votes = [
                    parameter_set.singleton_prob[j, val] if val in L[i, j] else 0  # type: ignore
                    for val in range(cardinality)
                ]
                if np.sum(lf_votes) > 0:
                    lf_votes /= np.sum(lf_votes)  # type: ignore
                else:
                    lf_votes = np.ones(cardinality) / cardinality

                # Standard inference step with multivote weighting
                proba[i, :] += np.log(
                    lf_votes @ mu[j * cardinality : (j + 1) * cardinality, :]  # type: ignore
                ) + np.log(
                    parameter_set.p  # type: ignore
                )
            proba[i, :] = np.exp(proba[i, :])
            proba[i, :] /= np.sum(proba[i, :])

        return proba

    def is_valid_parameter_set(self, parameter_set: Any) -> bool:
        return parameter_set.name in self.VALID_PARAMETER_SETS
