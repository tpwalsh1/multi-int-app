from __future__ import annotations

from typing import TYPE_CHECKING, List, Optional

import numpy as np
import torch
import torch.nn as nn

from label_models.inference_engines.inference_engine import InferenceEngine

if TYPE_CHECKING:
    from label_models.parameter_sets.parameter_set import ParameterSet


class NeuralNetInferenceEngine(InferenceEngine):
    def __init__(
        self, cardinality: int = 2, trusted_lf_indexes: Optional[List[int]] = None
    ) -> None:
        self.cardinality = cardinality
        self.trusted_lf_indexes = trusted_lf_indexes
        super().__init__()

    def predict_proba(
        self,
        L: np.ndarray,
        cardinality: int = 2,
        parameter_set: Optional[ParameterSet] = None,
    ) -> np.ndarray:
        # Code adapted from WeaSEL inference code https://github.com/autonlab/weasel/blob/main/weasel/models/downstream_models/base_model.py
        L_tensor = torch.Tensor(L)
        L_logits = parameter_set.eval()(L_tensor)  # type: ignore
        L_probs = nn.Softmax(dim=1)(L_logits)
        return L_probs.detach().numpy()
