from __future__ import annotations

from typing import TYPE_CHECKING, List, Optional

import numpy as np
import sparse

from label_models.inference_engines.inference_engine import InferenceEngine
from label_spaces.common.sparse_dense_utils import (
    densify,
    slice_sparse_tensor,
    sparse_any,
)

if TYPE_CHECKING:
    from label_models.parameter_sets.parameter_set import ParameterSet


class SoftMajorityLabelVoter(InferenceEngine):

    """Soft majority vote label model."""

    def __init__(
        self, cardinality: int = 2, trusted_lf_indexes: Optional[List[int]] = None
    ) -> None:
        self.cardinality = cardinality
        self.trusted_lf_indexes = trusted_lf_indexes
        super().__init__()

    def predict_proba(
        self,
        L: sparse._coo.core.COO,
        cardinality: int = 2,
        parameter_set: Optional[ParameterSet] = None,
    ) -> np.ndarray:
        """Predict probabilities using soft majority vote.

        Assign vote by calculating soft majority vote across all labeling functions.

        Parameters
        ----------
        L
            An [n, m, k] array of labels

        Returns
        -------
        np.ndarray
            A [n, k] array of probabilistic labels

        Example
        -------
        >>> L = np.array([[0, -1, -1, 0], [0, 0, 1, 1], [1, 1, 0, 1]])
        >>> soft_maj_voter = SoftMajorityLabelVoter()
        >>> soft_maj_voter.predict_proba(L)
        array([[1.0 , 0.5 ],
               [0.5, 0.5],
               [0.25, 0.75]])
        """

        # This needs to be refactored, very confusing to have both a kwarg and class attribute in insantiation that is irrelevant
        self.cardinality = cardinality
        sample_size = L.shape[0]
        Y_p = np.empty((sample_size, self.cardinality))

        all_abstain = densify(L.sum(axis=(1, 2)) == 0)
        Y_p[all_abstain, :] = 1 / self.cardinality

        remaining_indexes = ~all_abstain

        if self.trusted_lf_indexes is not None:
            L_trusted = slice_sparse_tensor(L, self.trusted_lf_indexes, axis=1)

            trusted_lf_samples = sparse_any(L_trusted, axis=(1, 2), sparse_output=False)

            L_trusted = slice_sparse_tensor(L_trusted, trusted_lf_samples, axis=0)

            Y_counts_trusted = densify(L_trusted.sum(axis=1))

            Y_p[trusted_lf_samples, :] = (
                Y_counts_trusted / Y_counts_trusted.sum(axis=1)[:, np.newaxis]
            )

            remaining_indexes = np.logical_and(remaining_indexes, ~trusted_lf_samples)

        Y_counts_remaining = densify(L[remaining_indexes].sum(axis=1))

        Y_p[remaining_indexes, :] = (
            Y_counts_remaining / Y_counts_remaining.sum(axis=1)[:, np.newaxis]
        )

        return Y_p
