from __future__ import annotations

from typing import TYPE_CHECKING, List, Optional

import numpy as np
import sparse

from label_models.inference_engines.inference_engine import InferenceEngine
from label_spaces.common.sparse_dense_utils import densify

if TYPE_CHECKING:
    from label_models.parameter_sets.parameter_set import ParameterSet


class HighCardinalityMultiLabelInference(InferenceEngine):

    """Normalize Probabilities"""

    def __init__(self, trusted_lf_indexes: Optional[List[int]] = None) -> None:
        super().__init__()
        self.trusted_lf_indexes = trusted_lf_indexes

    def predict_proba(
        self,
        L: sparse._coo.COO,
        cardinality: int = 2,
        parameter_set: Optional[ParameterSet] = None,
    ) -> np.ndarray:
        """Predict probabilities using soft majority vote.

        Assign vote by normalizing using learned label function accuracies

        Parameters
        ----------
        L
            A [num_examples, num_lfs, num_classes] matrix of labels

        Returns
        -------
        np.ndarray
            A [n, k] array of probabilistic labels

        """

        mu = parameter_set.return_parameters()  # type:ignore

        if self.trusted_lf_indexes is not None and len(self.trusted_lf_indexes) > 0:
            lf_num = L.shape[1]
            non_trusted_lf_indexes = list(
                set(range(lf_num)) - set(self.trusted_lf_indexes)
            )
            trusted_class_samples = (
                L[:, self.trusted_lf_indexes, :, :].sum(axis=(1, 3)) > 0
            )

            votes_trusted = (
                L[:, self.trusted_lf_indexes, :, :]
                * trusted_class_samples[:, np.newaxis, :, np.newaxis]
                * mu[np.newaxis, self.trusted_lf_indexes, :, np.newaxis]
            ).sum(axis=1)
            votes_non_trusted = (
                L[:, non_trusted_lf_indexes, :, :]
                * (1 - trusted_class_samples[:, np.newaxis, :, np.newaxis])
                * mu[np.newaxis, non_trusted_lf_indexes, :, np.newaxis]
            ).sum(axis=1)
            votes = votes_trusted + votes_non_trusted
        else:
            votes = (L * mu[np.newaxis, :, :, np.newaxis]).sum(axis=1)

        votes += (votes.sum(axis=2) == 0)[:, :, np.newaxis]
        probas = densify(votes[:, :, 1] / (votes.sum(axis=2)))

        return probas
