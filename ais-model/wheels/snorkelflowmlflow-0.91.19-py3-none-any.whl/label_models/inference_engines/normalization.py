from __future__ import annotations

from typing import TYPE_CHECKING, Any, List, Optional, cast

import numpy as np

from label_models.inference_engines.inference_engine import InferenceEngine
from label_models.inference_engines.majority_voter import SoftMajorityLabelVoter
from label_spaces.common.sparse_dense_utils import make_singlelabel_lfs_sparse

if TYPE_CHECKING:
    from label_models.parameter_sets.parameter_set import ParameterSet


class Normalization(InferenceEngine):

    """Normalize Probabilities"""

    def __init__(self, trusted_lf_indexes: Optional[List[int]] = None) -> None:
        super().__init__()
        self.VALID_PARAMETER_SETS = ["CovarianceCompletionSet", "DependencyAwareSet"]
        self.trusted_lf_indexes = trusted_lf_indexes

    def predict_proba(
        self,
        L: np.ndarray,
        cardinality: int = 2,
        parameter_set: Optional[ParameterSet] = None,
    ) -> np.ndarray:
        """Predict probabilities using soft majority vote.

        Assign vote by normalizing using

        Parameters
        ----------
        L
            An [n, m] matrix of labels

        Returns
        -------
        np.ndarray
            A [n, k] array of probabilistic labels

        """
        if not self.is_valid_parameter_set(parameter_set):
            raise ValueError("Parameter set given is not compatable")
        L_shift = L + 1  # convert to {0, 1, ..., k}

        new_parameter_set = cast(Any, parameter_set)

        L_aug = new_parameter_set.inference_L_matrix(L_shift)
        mu = new_parameter_set.return_parameters().cpu().detach().numpy()
        jtm = np.ones(L_aug.shape[1])

        # Note: We omit abstains, effectively assuming uniform distribution here
        X = np.exp(
            L_aug @ np.diag(jtm) @ np.log(mu + 1e-6) + np.log(new_parameter_set.p)
        )
        Z = np.tile(X.sum(axis=1).reshape(-1, 1), new_parameter_set.cardinality)
        # Setting elements where Z is 0 to 1e-6 to avoid NaN probabilities
        zero_indices = np.where(Z == 0)
        Z[zero_indices] = 1e-6

        proba = X / Z

        if self.trusted_lf_indexes is not None:
            trusted_proba_indices = (L[:, self.trusted_lf_indexes] > -1).sum(axis=1) > 0
            L_trusted_sparse = make_singlelabel_lfs_sparse(
                L[trusted_proba_indices], cardinality=cardinality
            )
            majority_vote_probabilities = SoftMajorityLabelVoter(
                cardinality, trusted_lf_indexes=self.trusted_lf_indexes
            ).predict_proba(L_trusted_sparse, cardinality=cardinality)
            proba[trusted_proba_indices] = majority_vote_probabilities

        uniform_proba_indices = np.where(
            np.min(proba, axis=1) == np.max(proba, axis=1)
        )[0]

        if uniform_proba_indices.shape[0] > 0:
            L_uniform_sparse = make_singlelabel_lfs_sparse(
                L[uniform_proba_indices], cardinality
            )
            majority_vote_probabilities = SoftMajorityLabelVoter(
                cardinality, trusted_lf_indexes=self.trusted_lf_indexes
            ).predict_proba(L_uniform_sparse, cardinality=cardinality)
            proba[uniform_proba_indices] = majority_vote_probabilities

        return proba

    def is_valid_parameter_set(self, parameter_set: Any) -> bool:
        return parameter_set.name in self.VALID_PARAMETER_SETS
