from __future__ import annotations

from typing import Any, List, Optional

import numpy as np
import sparse
from scipy.special import softmax

from label_models.inference_engines.inference_engine import InferenceEngine
from label_models.utils.utils import dtype_Mu
from label_spaces.common.sparse_dense_utils import (
    densify,
    slice_sparse_tensor,
    sparse_any,
)
from snorkelflow.utils.logging import get_logger
from snorkelflow.utils.performance_profiling import PerfTimeLog

logger = get_logger("Multilabel BEAM inference")


class BeamMultiLabelInference(InferenceEngine):
    def __init__(self, trusted_lf_indexes: Optional[List[int]] = None) -> None:
        self.trusted_lf_indexes = trusted_lf_indexes
        super().__init__()

    def predict_proba(
        self,
        L: sparse._coo.core.COO,
        cardinality: int = 2,
        parameter_set: Optional[Any] = None,
    ) -> np.ndarray:
        perf_time_log = PerfTimeLog("Multilabel BEAM inference")
        sample_size, _, label_num, _ = L.shape
        remaining_lf_samples = np.full((sample_size, label_num), True)
        Y_p = np.empty((sample_size, cardinality))

        logMu_vote, logMu_abstain = parameter_set.logMu  # type: ignore

        log_C = np.log(parameter_set.C, dtype=dtype_Mu)  # type: ignore

        perf_time_log.update("Prepare variables")

        if self.trusted_lf_indexes is not None:
            L_trusted = slice_sparse_tensor(L, self.trusted_lf_indexes, axis=1)

            trusted_lf_samples = sparse_any(L_trusted, axis=(1, 3), sparse_output=False)

            Y_counts_trusted = (
                L_trusted * trusted_lf_samples[:, np.newaxis, :, np.newaxis]
            ).sum(axis=1)

            trusted_probs = densify(
                Y_counts_trusted[:, :, 1] / Y_counts_trusted.sum(axis=2).clip(1)
            )

            Y_p[trusted_lf_samples] = trusted_probs[trusted_lf_samples]

            remaining_lf_samples = ~trusted_lf_samples

        if not parameter_set.lf_legit.any():  # type: ignore
            Y_p[remaining_lf_samples] = softmax(log_C, axis=1)[:, 1]

        else:
            L = slice_sparse_tensor(L, parameter_set.lf_legit, axis=1)  # type: ignore

            perf_time_log.update("Do trusted inference")

            L_non_abstain = sparse_any(L, axis=3, sparse_output=True)

            Y_logits_abstain = logMu_abstain.sum(axis=(0, 1))[
                np.newaxis, :, :
            ] - densify(
                sparse.tensordot(L_non_abstain, logMu_abstain, axes=((1, 2), (0, 1)))
            )

            perf_time_log.update("Inference from abstains")

            Y_logits_non_abstain = sparse.tensordot(
                L, logMu_vote, axes=((1, 2, 3), (0, 1, 2)), return_type=np.ndarray
            )

            perf_time_log.update("Inference from non-abstains")

            Y_logits = Y_logits_non_abstain + Y_logits_abstain
            Y_logits += log_C[np.newaxis, :, :]

            Y_p[remaining_lf_samples] = softmax(Y_logits, axis=2)[:, :, 1][
                remaining_lf_samples
            ]

        perf_time_log.update("Softmax")

        logger.debug(perf_time_log.pretty_summary())

        return Y_p
