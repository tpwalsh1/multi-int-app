from __future__ import annotations

from typing import Any, List, Optional

import numpy as np
import sparse
from scipy.special import softmax

from label_models.inference_engines.inference_engine import InferenceEngine
from label_spaces.common.sparse_dense_utils import (
    densify,
    slice_sparse_tensor,
    sparse_any,
)
from snorkelflow.utils.logging import get_logger
from snorkelflow.utils.performance_profiling import PerfTimeLog

logger = get_logger("BEAM inference")


class BeamInference(InferenceEngine):
    def __init__(self, trusted_lf_indexes: Optional[List[int]] = None) -> None:
        self.trusted_lf_indexes = trusted_lf_indexes
        super().__init__()

    def predict_proba(
        self,
        L: sparse._coo.core.COO,
        cardinality: int = 2,
        parameter_set: Optional[Any] = None,
    ) -> np.ndarray:
        # Set trusted LFs to be legit by default to enforce typical trusted LF behaviour

        perf_time_log = PerfTimeLog("BEAM inference")

        sample_size = L.shape[0]
        logMu = parameter_set.logMu  # type: ignore

        if parameter_set.class_balance is not None:  # type: ignore
            log_class_balance = np.log(np.asarray(parameter_set.class_balance))  # type: ignore
        else:
            log_class_balance = None

        Y_p = np.empty((sample_size, cardinality))

        remaining_indexes = np.full((sample_size,), True)

        perf_time_log.update("Prepare variables")

        # First calculate MV over trusted samples, and filter L for legit LFs *after*
        # in case those LFs had totally abstained during fitting
        if self.trusted_lf_indexes is not None:
            L_trusted = slice_sparse_tensor(L, self.trusted_lf_indexes, axis=1)

            trusted_lf_samples = sparse_any(L_trusted, axis=(1, 2), sparse_output=False)

            L_trusted = slice_sparse_tensor(L_trusted, trusted_lf_samples, axis=0)

            Y_counts_trusted = densify(L_trusted.sum(axis=1))

            Y_p[trusted_lf_samples, :] = (
                Y_counts_trusted / Y_counts_trusted.sum(axis=1)[:, np.newaxis]
            )

            remaining_indexes = ~trusted_lf_samples

        perf_time_log.update("Do trusted inference")

        if not parameter_set.lf_legit.any():  # type: ignore
            if log_class_balance is not None:
                Y_p_remaining = softmax(log_class_balance)
            else:
                Y_p_remaining = np.full((cardinality,), 1 / cardinality)

        else:
            L = slice_sparse_tensor(L, parameter_set.lf_legit, axis=1)  # type: ignore
            L = slice_sparse_tensor(L, remaining_indexes, axis=0)

            L_abstain = sparse_any(L, axis=2, sparse_output=False) == 0
            logMu_abstain = densify(logMu[:, 0, :])
            Y_logits_abstain = L_abstain.dot(logMu_abstain)

            perf_time_log.update("Inference from abstains")

            Y_logits_non_abstain = densify(sparse.tensordot(L, logMu[:, 1:, :]))

            perf_time_log.update("Inference from non-abstains")

            Y_logits_remaining = Y_logits_non_abstain + Y_logits_abstain

            if log_class_balance is not None:
                Y_logits_remaining += log_class_balance

            Y_p_remaining = softmax(Y_logits_remaining, axis=1)

        perf_time_log.update("Softmax")

        Y_p[remaining_indexes, :] = Y_p_remaining

        perf_time_log.update("Populate Y")

        logger.debug(perf_time_log.pretty_summary())

        return Y_p
