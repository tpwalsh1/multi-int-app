from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, Optional

import numpy as np
import sparse


class InferenceEngine(ABC):
    def __init__(self) -> None:
        pass

    @abstractmethod
    def predict_proba(
        self,
        L: sparse._coo.core.COO,
        cardinality: int = 2,
        parameter_set: Optional[Any] = None,
    ) -> np.ndarray:
        pass
