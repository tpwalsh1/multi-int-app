from __future__ import annotations

from typing import TYPE_CHECKING, Any, List, Optional

import numpy as np
import sparse

from label_models.inference_engines.inference_engine import InferenceEngine
from label_spaces.common.sparse_dense_utils import densify

if TYPE_CHECKING:
    from label_models.parameter_sets.parameter_set import ParameterSet


class HighCardinalityInference(InferenceEngine):

    """Normalize Probabilities"""

    def __init__(self, trusted_lf_indexes: Optional[List[int]] = None) -> None:
        super().__init__()
        self.VALID_PARAMETER_SETS = ["CovarianceCompletionSet"]
        self.trusted_lf_indexes = trusted_lf_indexes

    def predict_proba(
        self,
        L: sparse._coo.core.COO,
        cardinality: int = 2,
        parameter_set: Optional[ParameterSet] = None,
    ) -> np.ndarray:
        """Predict probabilities for high cardinality problems, single-label classification.

        Assign vote by normalizing using

        Parameters
        ----------
        L
            An [n, m, k] sparse tensor of labels

        Returns
        -------
        np.ndarray
            A [n, k] array of probabilistic labels

        """
        if not self.is_valid_parameter_set(parameter_set):
            raise ValueError("Parameter set given is not compatable")

        # If a labeling function is deemed to have 0% accuracy we set the L matrix to abstain for that LF
        mu = parameter_set.return_parameters().cpu().detach().numpy()  # type:ignore

        n, m, k = L.shape

        if k != cardinality:
            raise ValueError("L tensor dimensionality inconsistent with cardinality")

        Y_p_gt = np.empty((n, cardinality))

        all_abstain = densify(L.sum(axis=(1, 2)) == 0)
        Y_p_gt[all_abstain, :] = 1 / cardinality

        remaining_indexes = ~all_abstain

        if self.trusted_lf_indexes is not None:
            trusted_lf_samples = densify(
                L[:, self.trusted_lf_indexes, :].sum(axis=(1, 2)) > 0
            )

            Y_counts_trusted = densify(
                (
                    (
                        L[trusted_lf_samples]
                        * mu[np.newaxis, self.trusted_lf_indexes, np.newaxis]
                    ).sum(axis=1)
                )
            )

            Y_p_gt[trusted_lf_samples, :] = Y_counts_trusted / Y_counts_trusted.sum(
                axis=1
            )[:, np.newaxis].clip(min=1e-10)

            remaining_indexes = np.logical_and(remaining_indexes, ~trusted_lf_samples)

        Y_counts_remaining = densify(
            ((L[remaining_indexes] * mu[np.newaxis, :, np.newaxis]).sum(axis=1))
        )

        Y_p_gt[remaining_indexes, :] = Y_counts_remaining / Y_counts_remaining.sum(
            axis=1
        )[:, np.newaxis].clip(min=1e-10)

        return Y_p_gt

    def is_valid_parameter_set(self, parameter_set: Any) -> bool:
        return parameter_set.name in self.VALID_PARAMETER_SETS
