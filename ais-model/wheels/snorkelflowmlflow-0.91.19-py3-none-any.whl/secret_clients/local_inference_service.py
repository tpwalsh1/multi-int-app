from functools import wraps
from typing import Any, Callable, Dict, List

from api_utils.exceptions import UserInputError
from secret_clients import SecretClient
from secret_clients.request_utils import InferenceError, make_parallel_api_requests

LOCAL_INFERENCE_API_NAME = "Local Inference Service API"
LOCAL_INFERENCE_API_INPUT_FIELD = "prompt"


def handle_local_inference_service_errors(func: Callable) -> Callable:
    @wraps(func)
    def wrapper(*args: Any, **kwargs: Any) -> Any:
        try:
            return func(*args, **kwargs)

        except Exception as e:
            # Default error messages
            error_message = "Local Inference Service is encountering issues."
            error_detail = "We ran into a problem making that request to the Local Inference Service."
            how_to_fix = "Please try again later, or contact Snorkel"

            if isinstance(e, InferenceError) and "InvalidModel" in e.response_text:
                error_message = (
                    "Bad request. Invalid model passed into local inference service."
                )
                error_detail = f"We ran into a problem making that request to the Local Inference Service. Internal error message: {e.response_text}"
                how_to_fix = "Double check that the model loaded in local inference service matches the one that is currently selected."

            raise UserInputError(
                user_friendly_message=error_message,
                detail=error_detail,
                how_to_fix=how_to_fix,
            ) from e

    return wrapper


class LocalInferenceServiceAPIClient(SecretClient):
    def __init__(self) -> None:
        pass

    @handle_local_inference_service_errors
    def make_requests(
        self, url: str, headers: Dict[str, Any], json_payloads: List[Dict[str, Any]]
    ) -> List[Any]:
        """Wrapper around one or more requests to Snorkel's Local Inference Service

        This wrapper:
        - Logs the requests that we send (inside make_parallel_api_requests)
        - For multiple requests, runs them in parallel using n_threads=n_requests
        - Provides an exponential backoff loop around the group of requests
        """
        return make_parallel_api_requests(
            url, headers, json_payloads, api_service_name=LOCAL_INFERENCE_API_NAME
        )
