from functools import wraps
from typing import Any, Callable, Dict

import requests
from tenacity import (
    retry,
    retry_if_exception_type,
    stop_after_attempt,
    wait_exponential,
)

from api_utils.exceptions import UserInputError
from secret_clients import SecretClient
from secret_clients.request_utils import make_api_request

HF_API_NAME = "Huggingface Inference API"
HF_API_INPUT_FIELD = "inputs"


def handle_hf_errors(func: Callable) -> Callable:
    @wraps(func)
    def wrapper(*args: Any, **kwargs: Any) -> Any:
        try:
            return func(*args, **kwargs)

        except requests.exceptions.ConnectionError as e:
            raise UserInputError(
                user_friendly_message="HuggingFace connection failed.",
                detail=f"Failed to connect to the Huggingface Endpoint for this Foundation Model.",
                how_to_fix="Please check the Foundation Model endpoint was entered correctly with `sf.get_external_model_endpoints()` and that it's running at https://ui.endpoints.huggingface.co/.",
            ) from e

        except requests.exceptions.HTTPError as e:
            if e.response.status_code == 401:
                raise UserInputError(
                    user_friendly_message="HuggingFace connection unauthorized.",
                    detail="Unauthorized to run inference on HuggingFace for that model.",
                    how_to_fix="Please check the HuggingFace API token has been set correctly with sf.set_secret.",
                ) from e
            elif e.response.status_code == 429:
                raise UserInputError(
                    user_friendly_message="HuggingFace inference limit hit.",
                    detail="Invalid HuggingFace Inference API token provided, and non-paid account quota has been met.",
                    how_to_fix="Please check the HuggingFace API token has been set correctly with sf.set_secret and try again.",
                )
            else:
                raise UserInputError(
                    user_friendly_message="HuggingFace is encountering issues.",
                    detail="HuggingFace is returning a HTTP error for this request.",
                    how_to_fix="Please try again later, check https://status.huggingface.co/ for updates.",
                ) from e

        except UserInputError as e:
            raise e

        except Exception as e:
            raise UserInputError(
                user_friendly_message="HuggingFace is encountering issues.",
                detail="We ran into a problem making that request to HuggingFace.",
                how_to_fix="Please try again later, check https://status.huggingface.co/ for updates.",
            ) from e

    return wrapper


class HFInferenceAPIClient(SecretClient):
    def __init__(self, hf_api_token: str) -> None:
        self.hf_api_token = hf_api_token

    @handle_hf_errors
    @retry(
        retry=retry_if_exception_type(requests.exceptions.HTTPError),
        stop=stop_after_attempt(4),
        reraise=True,
        wait=wait_exponential(multiplier=1.5),
    )
    def make_request(
        self, url: str, headers: Dict[str, Any], json_payload: Dict[str, Any]
    ) -> Any:
        """Wrapper around requests to Huggingface API

        This wrapper:
        - Logs every call that we send (inside make_api_request)
        - Provides an exponential backoff loop around the request
        """
        return make_api_request(
            url,
            headers,
            json_payload,
            api_service_name=HF_API_NAME,
            input_field_name=HF_API_INPUT_FIELD,
            api_token=self.hf_api_token,
        )
