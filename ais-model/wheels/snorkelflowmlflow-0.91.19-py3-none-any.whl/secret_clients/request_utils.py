import json
from concurrent.futures import ThreadPoolExecutor, wait
from typing import Any, Dict, List, Optional

import requests

from snorkelflow.utils.logging import get_logger

logger = get_logger("Secret Client Utils")

PARALLEL_REQUEST_TIMEOUT_SECONDS = 300


class InferenceError(Exception):
    def __init__(
        self, response_text: str, inner_exception: requests.exceptions.HTTPError
    ):
        """Initialize RequestException with `request` and `response` objects."""
        self.response_text = response_text
        self.inner_exception = inner_exception


def make_api_request(
    url: str,
    headers: Dict[str, Any],
    json_payload: Dict[str, Any],
    api_service_name: str,
    input_field_name: str,
    api_token: Optional[str] = None,
) -> Any:
    input_field = json_payload.get(input_field_name, "")
    if type(input_field) is str:
        num_inputs = 1
    else:
        num_inputs = len(input_field)

    json_request = json.dumps(
        {"url": url, "headers": headers, "json_payload": json_payload}
    )
    logger.info(f"Making request to {api_service_name} w/ {num_inputs} inputs")
    logger.debug(f"Making request to {api_service_name}: {json_request}")

    if api_token is not None:
        headers = {**headers, "Authorization": f"Bearer {api_token}"}

    response = requests.post(url, headers=headers, json=json_payload)
    processed_response = process_response(response, api_service_name)
    logger.info(f"Response from {api_service_name} w/ {num_inputs} inputs")

    return processed_response


def make_parallel_api_requests(
    url: str,
    headers: Dict[str, Any],
    json_payloads: List[Dict[str, Any]],
    api_service_name: str,
    api_token: Optional[str] = None,
) -> List[Any]:
    json_requests = json.dumps(
        {"url": url, "headers": headers, "all_json_payloads": json_payloads}
    )
    logger.info(
        f"Making {len(json_payloads)} parallel requests to {api_service_name} w/ 1 input each"
    )
    logger.info(
        f"Making {len(json_payloads)} parallel requests to {api_service_name}: {json_requests}"
    )

    if api_token is not None:
        headers = {**headers, "Authorization": f"Bearer {api_token}"}

    with ThreadPoolExecutor(max_workers=len(json_payloads)) as executor:
        futures = [
            executor.submit(requests.post, url, headers=headers, json=json_payload)
            for json_payload in json_payloads
        ]
        wait(futures, timeout=PARALLEL_REQUEST_TIMEOUT_SECONDS)
        processed_responses = [
            process_response(future.result(), api_service_name) for future in futures
        ]

    logger.info(
        f"{len(processed_responses)} responses from {api_service_name} w/ 1 input each"
    )
    return processed_responses


def process_response(response: requests.Response, api_service_name: str) -> Any:
    try:
        response.raise_for_status()
    except requests.exceptions.HTTPError as e:
        logger.error(f"Error from {api_service_name}: {response.text}")
        raise InferenceError(response.text, e)

    response_json = response.json()
    logger.debug(f"{api_service_name} response: {json.dumps(response_json)}")

    return response_json
