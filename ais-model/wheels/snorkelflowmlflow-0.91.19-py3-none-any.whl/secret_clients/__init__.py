import importlib
import os
from abc import ABC, abstractmethod
from typing import Dict, List, Tuple, Type

from snorkelflow.config.constants import DEFAULT_WORKSPACE_UID
from snorkelflow.plugin_utils import find_all_modules
from snorkelflow.utils.logging import get_logger

from .base import SecretClient, secret_clients

logger = get_logger("Secret Clients")

all_secret_client_modules = find_all_modules(
    os.path.dirname(__file__), "secret_clients."
)
for module in all_secret_client_modules:
    logger.debug(f"Importing module {module}")
    try:
        importlib.import_module(module)
    except ImportError as e:
        logger.debug(f"Skipping import for {module} due to error: {e}", exc_info=False)


class SecretClientNotFoundError(ImportError):
    pass


# Registry acesss
def get_secret_client_cls(secret_client_name: str) -> Type[SecretClient]:
    client_cls = secret_clients.get(secret_client_name)
    if not client_cls:
        raise SecretClientNotFoundError(f"Cannot find the secret client: {client_cls}")
    return client_cls


class SecretAccessMixin(ABC):
    """
    Mixin class for ops/templates/LFs that need to access 3rd party secrets
    """

    @property
    @abstractmethod
    def secret_client_cls(self) -> List[str]:
        """What 3rd party service clients this op/template/LF needs to access"""

    @property
    @abstractmethod
    def secret_keys(self) -> List[Dict[str, Tuple[str, str]]]:
        """Contains a mapping from the secret parameter for each client to a tuple
        of (secret store key, secret store type)
        """

    @abstractmethod
    def set_secret_clients(self, clients: List[SecretClient]) -> None:
        """External caller uses this method to inject secret clients so
        that the asset can access 3rd-party secrets securely
        """

    def configure_secrets(self, workspace_uid: int = DEFAULT_WORKSPACE_UID) -> None:
        secret_clients: List[SecretClient] = []
        # Ignore if there are no secrets
        for secret_cls, client_secrets in zip(self.secret_client_cls, self.secret_keys):
            if secret_cls:
                # Get secret client from the registry
                client_cls = get_secret_client_cls(secret_cls)
                # Initialize secret client and add to list
                secret_clients.append(
                    client_cls.from_config(client_secrets, workspace_uid)
                )
        # Model can now use secrets
        self.set_secret_clients(secret_clients)
