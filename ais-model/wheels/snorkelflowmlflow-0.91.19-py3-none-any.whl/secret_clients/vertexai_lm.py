from typing import Any

from secret_clients import SecretClient


class VertexAILMClient(SecretClient):
    def __init__(
        self,
        vertexai_lm_project_id: str,
        vertexai_lm_location: str,
        vertexai_lm_credentials_json: str,
    ) -> None:
        self.vertexai_lm_project_id = vertexai_lm_project_id
        self.vertexai_lm_location = vertexai_lm_location
        self.vertexai_lm_credentials_json = vertexai_lm_credentials_json

    def create_gcp_credentials(self, module: Any) -> Any:
        return module(self.vertexai_lm_credentials_json)
