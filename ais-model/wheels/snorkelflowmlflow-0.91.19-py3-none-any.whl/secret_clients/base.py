from typing import Any, Dict, Tuple, Type

from secret_store import get_secret_store
from snorkelflow.utils.logging import get_logger

secret_clients: Dict[str, Type["SecretClient"]] = {}

logger = get_logger("Secret Client")


class SecretClient:
    def __init_subclass__(cls, **kwargs: Any) -> None:
        secret_clients[cls.__name__] = cls

    @classmethod
    def from_config(
        cls, secret_keys: Dict[str, Tuple[str, str]], workspace_uid: int
    ) -> "SecretClient":
        """Creates a SecretClient from the secret keys from a SecretAccessMixin's secret_keys property.
        Accesses the secret store to get the secrets and passes them to the SecretClient's constructor.

        Args:
            secret_keys (Dict[str, Tuple[str, str]]): See SecretAccessMixin.secret_keys
            workspace_uid (int): The workspace uid

        Returns:
            SecretClient: A secret client that can be used to connect to 3rd party services
        """
        params_dict = {}
        for secret_param, (secret_key, store_id) in secret_keys.items():
            secret_store = get_secret_store(store_id, {})
            params_dict[secret_param] = secret_store.get_secret(
                secret_key, workspace_uid
            )
        return cls(**params_dict)
