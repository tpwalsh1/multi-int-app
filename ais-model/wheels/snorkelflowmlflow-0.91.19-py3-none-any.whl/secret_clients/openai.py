from typing import Any

from secret_clients import SecretClient


class OpenAIClient(SecretClient):
    def __init__(self, openai_api_key: str) -> None:
        self.openai_api_key = openai_api_key

    def add_key_to_openai_module(self, module: Any) -> None:
        module.api_key = self.openai_api_key
