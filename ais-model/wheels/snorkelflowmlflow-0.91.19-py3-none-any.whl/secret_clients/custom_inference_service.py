from typing import Any

from secret_clients import SecretClient


class CustomInferenceServiceAPIClient(SecretClient):
    def __init__(self, custom_inference_api_key: str) -> None:
        self.custom_inference_api_key = custom_inference_api_key

    def add_key_to_openai_module(self, module: Any) -> None:
        module.api_key = self.custom_inference_api_key
