import threading
from typing import Any, Optional

from snorkelflow.utils.logging import get_logger

logger = get_logger("Threading")


class ThreadContextMgr(threading.Thread):
    """An utility to use threading with contextmgr.
    Usage:
    class ExampleThread(ThreadContextMgr):
        def __init__(self):
            ThreadContextMgr.__init__(self, name="ExampleThread")

    with ExampleThread() as e:
        do_something()
    """

    def __init__(self, name: str):
        threading.Thread.__init__(self, name=name)
        self.stop_ev = threading.Event()

    def run(self) -> None:
        raise NotImplementedError(
            f"No run implementation exists {self.__class__.__name__}"
        )

    def stop(self) -> None:
        self.stop_ev.set()

    def __enter__(self) -> "ThreadContextMgr":
        self.start()
        return self

    def __exit__(self, *args: Any, **kwargs: Any) -> None:
        self.stop()


class PeriodicTimer:
    """A utility class built using threading.Timer that
    calls the given callable periodically.
    """

    def __init__(
        self, interval: float, ignore_errors: bool = False, daemon: bool = False
    ):
        self._interval = interval
        self.ignore_errors = ignore_errors
        self._timer: Optional[threading.Timer] = None
        self._daemon = daemon
        if not daemon:
            # We should switch to default to true in the future, not much reason
            # for us to not be daemonic for periodic timers.
            logger.warning(
                f"Created a PeriodicTimer of class {self.__class__} with daemon=False"
            )

    def _run(self) -> None:
        raise NotImplementedError("No runtime implemented for timer")

    def start(self) -> None:
        self._timer = threading.Timer(self._interval, self.start)
        self._timer.daemon = self._daemon
        try:
            self._run()
        except Exception as e:
            if not self.ignore_errors:
                # the `from None` gets rid of this line from the stack trace
                raise e from None
            logger.exception(
                f"Ignoring exception from PeriodicTimer child class {self.__class__.__name__} and proceeding to next run"
            )
        self._timer.start()

    def __enter__(self) -> "PeriodicTimer":
        return self.start_running()

    def __exit__(self, *args: Any, **kwargs: Any) -> None:
        self.stop_running()

    def start_running(self) -> "PeriodicTimer":
        self._timer = threading.Timer(self._interval, self.start)
        self._timer.daemon = self._daemon
        self._timer.start()
        return self

    def stop_running(self) -> None:
        if self._timer:
            self._timer.cancel()

    def is_alive(self) -> bool:
        return self._timer.is_alive() if self._timer else False
