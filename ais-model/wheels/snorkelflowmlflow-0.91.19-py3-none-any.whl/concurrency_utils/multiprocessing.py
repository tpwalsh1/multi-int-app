import multiprocessing as mp
import os
import threading
import time
from concurrent.futures.process import ProcessPoolExecutor
from multiprocessing.util import Finalize
from typing import Any, Callable, Optional

import psutil
import setproctitle
from psutil import NoSuchProcess

from snorkelflow.utils.logging import get_logger

_DEFAULT_STOP_EVENT = threading.Event()

logger = get_logger("multiprocessing")


def _exit() -> None:
    logger.info("Setting default stop event due to process exit")
    _DEFAULT_STOP_EVENT.set()


def run_async_as_process(
    name: str,
    f: Callable,
    *args: Any,
    start: bool = True,
    stop_event: Optional[threading.Event] = None,
    **kwargs: Any,
) -> threading.Thread:
    """Runs a function as a process. Restarts the process if it dies

    IMPORTANT: If your function spins off additional processes, there is a possibility those processes will not be cleaned up.
    We do a best attempt to send SIGTERM to your function's child processes if your function exits without being able to clean up.

    Implementation notes:
    In the calling process, a thread is spun up.
    The thread will wrap the process the function with a nice human-friendly process name setter.
    While the function is running, the thread will periodically use psutil to check whether the function spun up child processes.
    If the function process exits, the thread will SIGTERM the child processes. This is because if the function exits from the OOMKiller, the child processes
        are not cleaned up properly.
    The thread will then start the function again.
    """
    # Multiprocessing uses this.
    # You can look at the atexit module - multiprocessing will run this when the parent process is ready to exit
    Finalize(None, callback=_exit, exitpriority=999)
    t = threading.Thread(
        name=f"{name}-nanny",
        target=_loop,
        args=[name, f, stop_event if stop_event else _DEFAULT_STOP_EVENT] + list(args),
        kwargs=kwargs,
        daemon=True,
    )
    if start:
        t.start()
    return t


def _loop(
    name: str, f: Callable, stop_event: threading.Event, *args: Any, **kwargs: Any
) -> None:
    subprocesses = []
    while not _should_stop(stop_event):
        p = mp.Process(name=name, target=_wrapper_f(name, f), args=args, kwargs=kwargs)
        p.start()
        pid = p.pid
        process = psutil.Process(pid)
        while not _should_stop(stop_event) and p.is_alive():
            try:
                subprocesses = process.children()
            except NoSuchProcess:
                # Process dead, don't update subprocess list
                pass
            except Exception:
                logger.warning("Unable to get function's subprocesses", exc_info=True)
            p.join(timeout=5)

        if _should_stop(stop_event):
            logger.info("Exiting due to stop event")
            # Send 2 SIGTERMs - RQ attempts to do a warm exit and wait for the job to finish with just
            # 1 SIGTERM
            p.terminate()
            p.join(timeout=5)
            p.terminate()
            p.join(timeout=5)

            # If process still refuses to terminate, time to kill
            p.kill()
            p.join()
            return
        # At this point, the process has exited, but the service doesn't want to exit. Restart process.
        logger.warning("Child process exited, restarting process after 5 seconds")

        # Do a best attempt at cleaning up orphaned processes
        for subprocess in subprocesses:
            try:
                # Child process could already be dead.
                if subprocess.is_running():
                    logger.warning(
                        f"Orphaned process {subprocess.pid} found, terminating"
                    )
                    subprocess.terminate()
            except NoSuchProcess:
                # Process already dead
                pass
            except Exception:
                logger.warning(
                    "Failed to kill orphaned process, ignoring", exc_info=True
                )
        time.sleep(5)  # empirical estimate of time required to kill subprocesses


def _should_stop(stop_event: threading.Event) -> bool:
    return stop_event.is_set()


def _wrapper_f(name: str, f: Callable) -> Callable:
    """Set process title before executing function"""

    def _f(*args: Any, **kwargs: Any) -> None:
        setproctitle.setproctitle(name)
        f(*args, **kwargs)

    return _f


def function_executor(*args: Any, **kwargs: Any) -> Any:
    fn = kwargs.pop("fn")
    setproctitle.setproctitle(fn.__name__)
    rv = fn(*args, **kwargs)
    return rv


def run_as_process(fn: Callable, *args: Any, **kwargs: Any) -> Any:
    executor = ProcessPoolExecutor(1, mp_context=mp.get_context("spawn"))
    kwargs["fn"] = fn
    try:
        rv = executor.submit(function_executor, *args, **kwargs).result()
    finally:
        executor.shutdown()
    return rv


class ProcessAsyncExecutor:
    def __init__(self, max_workers: int):
        self._executor = ProcessPoolExecutor(
            max_workers=max_workers, mp_context=mp.get_context("spawn")
        )

    def __enter__(self) -> "ProcessAsyncExecutor":
        return self

    def __exit__(self, *args: Any, **kwargs: Any) -> None:
        self._executor.shutdown()

    def run_as_process_async(self, fn: Callable, *args: Any, **kwargs: Any) -> Any:
        kwargs["fn"] = fn
        rv = self._executor.submit(function_executor, *args, **kwargs)
        return rv


def cleanup_child_processes() -> None:
    """We may end up with unreaped child processes. Especially,
    multiprocessing resource tracker - https://github.com/python/cpython/issues/88887
    Try and kill the process and manually reap it
    """
    parent = psutil.Process(os.getpid())
    for child in parent.children(recursive=True):
        child_pid = child.pid
        try:
            if child.is_running():
                child.kill()
                os.waitpid(child_pid, 0)
        except Exception:
            pass
