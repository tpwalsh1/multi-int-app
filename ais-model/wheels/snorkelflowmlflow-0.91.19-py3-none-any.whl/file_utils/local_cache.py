import gc
import sys
import threading
from _thread import RLock  # type: ignore
from collections import OrderedDict
from functools import wraps
from typing import Any, Callable, List

import pandas as pd
import psutil

from snorkelflow.utils.logging import get_logger

logger = get_logger("Cache")


def system_memory_limit() -> int:
    """Get the memory limit (in bytes) for this system.
    Takes the minimum value from the following locations:
    - Available system host memory
    - Cgroups limit (if set)
    - RSS rlimit (if set)
    """
    limit = psutil.virtual_memory().total

    # Check cgroups if available
    if sys.platform == "linux":
        try:
            with open("/sys/fs/cgroup/memory/memory.limit_in_bytes") as f:
                cgroups_limit = int(f.read())
            if cgroups_limit > 0:
                limit = min(limit, cgroups_limit)
        except Exception:
            pass

    # Check rlimit if available
    try:
        import resource

        hard_limit = resource.getrlimit(resource.RLIMIT_RSS)[1]
        if hard_limit > 0:
            limit = min(limit, hard_limit)
    except (ImportError, OSError):
        pass

    return limit


# Local cache for process to store objects that are expensive to serialize
class _LocalLRUCacheEntry:
    def __init__(self, obj: Any, memory: int):
        self.obj = obj
        self.memory = memory


def synchronize(f: Callable) -> Callable:
    @wraps(f)
    def decorated(self: Any, *args: Any, **kwargs: Any) -> Any:
        if not isinstance(getattr(self, "_rlock", None), RLock):
            raise ValueError(
                f"synchronize decorator requires a re-entrant lock at self._rlock"
            )
        self._rlock.acquire()
        try:
            return f(self, *args, **kwargs)
        finally:
            self._rlock.release()

    return decorated


class LocalLRUCache:
    """
    Key-value cache that uses local process memory to store objects, with
    memory limit (currently enforced ONLY for Pandas DataFrames), and limit
    on number of entries.
    """

    def __init__(
        self, memory_limit: int = sys.maxsize, max_num_entries: int = sys.maxsize
    ):
        self._cache: OrderedDict[str, Any] = OrderedDict()
        self._rlock = threading.RLock()
        self._memory_limit = memory_limit
        self._max_num_entries = max_num_entries
        self.total_memory = 0

    @synchronize
    def save(self, cache_key: str, obj: Any) -> None:
        if cache_key in self._cache:
            self.total_memory -= self._cache[cache_key].memory
        if isinstance(obj, pd.DataFrame):
            memory = obj.memory_usage(deep=True).sum()
        else:
            # We could potentially use len(cloudpickle.dumps(obj)) as proxy for
            # memory usage, but it'll increase the time cost of this function.
            memory = 0
            logger.warning(f"Ignoring memory limit for non DataFrame value")
        self._cache[cache_key] = _LocalLRUCacheEntry(obj, memory)
        self.total_memory += self._cache[cache_key].memory
        self._cache.move_to_end(cache_key)
        self._evict_entries()

    @synchronize
    def get(self, cache_key: str) -> Any:
        if cache_key not in self._cache:
            return None
        entry = self._cache[cache_key]
        self._cache.move_to_end(cache_key)
        return entry.obj

    @synchronize
    def delete(self, cache_key: str) -> Any:
        if cache_key in self._cache:
            self.total_memory -= self._cache[cache_key].memory
            del self._cache[cache_key]

    @synchronize
    def change_max_num_entries(self, max_num_entries: int) -> List[str]:
        self._max_num_entries = max_num_entries
        return self._evict_entries()

    @synchronize
    def change_memory_limit(self, memory_limit: int) -> List[str]:
        self._memory_limit = memory_limit
        return self._evict_entries()

    @synchronize
    def _evict_entries(self) -> List[str]:
        """Evict entries from cache till memory usage is under the limit."""
        to_delete = []
        num_entries = len(self._cache)
        # TODO: To prevent thrashing, consider not removing entries that are
        # very recent and not saving new entries if we can't make enough space.
        for cache_key, entry in self._cache.items():
            if (
                self.total_memory < self._memory_limit
                and num_entries <= self._max_num_entries
            ):
                break
            to_delete.append(cache_key)
            self.total_memory -= entry.memory
            num_entries -= 1
        for cache_key in to_delete:
            del self._cache[cache_key]
        if to_delete:
            gc.collect()
        return to_delete
