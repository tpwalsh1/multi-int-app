from typing import Optional

import pandas as pd
import pyarrow as pa
from redis import Redis


def serialize_and_cache_df(cache: Redis, cache_key: str, df: pd.DataFrame) -> None:
    df_bytestring = pa.ipc.serialize_pandas(df).to_pybytes()
    # Set expiration to 1 hour. Ideally, we implement a LRU cache.
    cache.set(cache_key, df_bytestring, ex=3600)


def fetch_df_from_cache(cache: Redis, cache_key: str) -> Optional[pd.DataFrame]:
    # Fetch df from cache and convert to ddf
    df_bytestring = cache.get(cache_key)
    return pa.ipc.deserialize_pandas(df_bytestring) if df_bytestring else None
