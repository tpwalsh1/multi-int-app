import contextlib
import json
import os
import random
import shutil
import string
import tempfile
import uuid
from pathlib import Path
from typing import IO, Any, Dict, Iterator, List, Optional, Union

import fsspec
from botocore.exceptions import NoCredentialsError
from fsspec import AbstractFileSystem, get_fs_token_paths
from fsspec.core import OpenFile
from fsspec.utils import infer_storage_options

from snorkelflow.utils.file import resolve_data_path
from snorkelflow.utils.logging import get_logger

COLON_SLASH_SLASH_PROTOCOLS = {"s3", "gs", "gcs", "http", "https"}
NO_AWS_CREDENTIALS_MESSAGE = "AWS credentials not configured. To use S3, set AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY, and AWS_REGION environment variables on boot."
logger = get_logger("Engine")


def get_fsspec_kwargs(protocol: str) -> Dict[str, Any]:
    kwargs: Dict[str, Any] = dict()
    if protocol == "s3":
        acl = dict(ACL="bucket-owner-full-control")
        kwargs = dict(s3_additional_kwargs=acl)
    # TODO: handle ACLs for GCS, Azure
    return kwargs


def get_storage_protocol(path: str) -> str:
    return infer_storage_options(path)["protocol"]


def get_filesystem_for_path(
    path: str, storage_options: Optional[Dict[str, Any]] = None
) -> AbstractFileSystem:
    protocol = get_storage_protocol(path)
    if storage_options:
        return fsspec.filesystem(protocol, **storage_options)
    return fsspec.filesystem(protocol)


def remove_path(path: str) -> None:
    fs = get_filesystem_for_path(path)
    try:
        fs.rm(path, recursive=True)
    except FileNotFoundError:
        pass


def disk_usage(path: str) -> int:
    """Return total disk footprint at path in bytes for all files under path."""
    logger.info(f"Get disk usage for {path=}")
    fs = get_filesystem_for_path(path)
    return fs.disk_usage(path)


def path_exists(path: str) -> bool:
    if not path.startswith("s3://"):
        return os.path.exists(resolve_data_path(path))
    fs = _load_s3fs()
    return fs.exists(path)


def list_dirs(path: str) -> List[str]:
    # Needs to be tested
    if not path.startswith("s3://"):
        output = os.listdir(resolve_data_path(path))
        return output
    fs = _load_s3fs()
    all_objects = fs.ls(path, detail=True)
    directories = []
    for obj in all_objects:
        if obj["type"] == "directory":
            if path.startswith("s3://"):
                path = path[len("s3://") :]
            dir_name = obj["name"].replace(path, "").strip("/")
            if dir_name:
                directories.append(dir_name)
    return directories


def makedirs(path: str) -> None:
    fs = get_filesystem_for_path(path)
    fs.makedirs(path)


def reconstruct_path(path: str, protocol: str) -> str:
    if protocol == "file":
        return path if path.startswith("/") else f"/{path}"
    if protocol in COLON_SLASH_SLASH_PROTOCOLS:
        return f"{protocol}://{path}"
    else:
        raise ValueError(f"Path reconstruction for {protocol} not implemented")


def glob_fsspec_path(path: str) -> List[str]:
    if "*" in path:
        assert path.count("*") == 1
        protocol = get_storage_protocol(path)
        _, _, paths = get_fs_token_paths(path)
        return [reconstruct_path(path, protocol) for path in paths]
    return [path]


@contextlib.contextmanager
def LocalReadFsspecPath(path: str) -> Iterator[str]:
    try:
        protocol = get_storage_protocol(path)
        if protocol == "file":
            fh, local_path = None, path
        else:
            ext = os.path.splitext(path)[1]
            fh = tempfile.NamedTemporaryFile(mode="wb", suffix=ext)
            local_path = fh.name
            # TODO: Make analogous calls for other filesystems when we start
            # supporting them.
            fsspec.get_filesystem_class("s3")().invalidate_cache(path)
            with open_file(path, mode="rb") as f_src:
                fh.write(f_src.read())
                fh.flush()
        yield local_path
    except NoCredentialsError:
        raise RuntimeError(NO_AWS_CREDENTIALS_MESSAGE)
    finally:
        if fh is not None:
            fh.close()


@contextlib.contextmanager
def LocalWriteFsspecPath(path: str) -> Iterator[str]:
    """Context manager to get a local version of an fsspec path.

    If file is local, gives original path. If file is remote, copies
    to a tempfile that gets deleted with the context manager is
    released.
    """
    try:
        protocol = get_storage_protocol(path)
        if protocol == "file":
            fh, local_path = None, path
        else:
            ext = os.path.splitext(path)[1]
            fh = tempfile.NamedTemporaryFile(mode="wb", suffix=ext)
            local_path = fh.name
        yield local_path
    except Exception as e:
        raise e
    finally:
        if local_path != path and fh is not None:
            try:
                with open(local_path, "rb") as f_local:
                    with open_file(path, mode="wb") as f:
                        f.write(f_local.read())
                        f.flush()
            except NoCredentialsError:
                raise RuntimeError(NO_AWS_CREDENTIALS_MESSAGE)
            finally:
                fh.close()


def _load_s3fs() -> fsspec.AbstractFileSystem:
    import s3fs

    fs = s3fs.S3FileSystem()
    fs.invalidate_cache()
    return fs


def _copy_local_to_local(source: str, target: str, hardlink: bool = False) -> None:
    source = resolve_data_path(source)
    target = resolve_data_path(target)
    if hardlink:
        if os.path.isdir(source):
            shutil.copytree(source, target, copy_function=os.link)
        else:
            os.link(source, target)
    else:
        if os.path.isdir(source):
            shutil.copytree(source, target)
        else:
            shutil.copy(source, target)


def _copy_s3_to_local(source: str, target: str) -> None:
    fs = _load_s3fs()
    if fs.isdir(source) and not source.endswith("/"):
        source += "/"
    fs.get(source, resolve_data_path(target), recursive=True)


def _copy_file_if_special_chars(file_path: str) -> str:
    # Check if the file contains "?-" in its name and copy it to a new location if it does
    # this is necessary because a bug in fs.put causes an infinite recursion otherwise
    if "?-" not in os.path.basename(file_path):
        return file_path

    new_file_name = os.path.basename(file_path).replace("?-", str(uuid.uuid4()))
    temp_dir = "/tmp"
    new_file_path = os.path.join(temp_dir, new_file_name)
    shutil.copy2(file_path, new_file_path)

    logger.info(f"Copied file {file_path} to: {new_file_path} because of `?-`")
    return new_file_path


def _copy_local_to_s3(source: str, target: str) -> None:
    fs = _load_s3fs()
    source = resolve_data_path(source)
    source = _copy_file_if_special_chars(source)
    fs.put(source, target, recursive=True)


def _copy_s3_to_s3(source: str, target: str) -> None:
    fs = _load_s3fs()
    if fs.isfile(source):
        fs.copy(source, target)
    else:
        for path in fs.glob(os.path.join(source, "**")):
            if fs.isfile(path):
                # 5 chars for s3:// minus one for trailing slash.
                path_suffix = path[len(source) - 4 :]
                fs.copy(path, os.path.join(target, path_suffix))


def copy(source: str, target: str, hardlink_local: bool = False) -> None:
    """Copy file/directory in the source path to the target path

    Parameters
    ----------
    source
        Path to the source file/directory
    target
        Path to the target file/directory
    hardlink_local
        Whether or not source is hard-linked to the target (True) or it is copied (False). Only supported when copying between the same local filesystem.
    """
    if source.startswith("s3://") and target.startswith("s3://"):
        _copy_s3_to_s3(source, target)
    elif source.startswith("s3://") and not target.startswith("s3://"):
        _copy_s3_to_local(source, target)
    elif not source.startswith("s3://") and target.startswith("s3://"):
        _copy_local_to_s3(source, target)
    else:
        _copy_local_to_local(source, target, hardlink_local)


def open_file(
    path: Union[str, bytes, os.PathLike], mode: str = "rb", **kwargs: Any
) -> OpenFile:
    # fsspec expands files with brackets when it shouldn't with the open api
    # open_files is able to handle this correctly and respects the expand kwarg
    # if a single file path is passed in opposed to a list, tuple, or set
    if isinstance(path, str):
        path = resolve_data_path(path)
    return fsspec.open_files(path, mode, expand=False, **kwargs)[0]


def maybe_load_json(label: str) -> Any:
    try:
        # All labels exported after v0.44 should be stored in JSON format
        parsed_label = json.loads(label)
        if type(parsed_label) == bool or type(parsed_label) == int:
            # Handle back compat edge case where strings names conflict with JSON booleans and integers
            # We should directly return as a string
            return label
        return parsed_label
    except (json.JSONDecodeError, TypeError):
        # If value is invalid JSON or not a string, it was exported before v0.44
        # Directly return its value as a string to support backwards compatibility
        return str(label)


def random_id(n_char: int) -> str:
    r = random.Random()
    return "".join(r.choices(string.ascii_letters + string.digits, k=n_char))


def get_tmp_path(parent_path: str) -> str:
    return os.path.join(parent_path, random_id(8))


@contextlib.contextmanager
def safe_write(final_path: Path) -> Iterator[IO]:
    """
    A helper function that guarantees that the final path will not be modified until the inner block
    exits with no error.

    Ex:
    # output.txt already exists with string "test"
    with safe_write("output.txt") as f:
        raise ValueError("whoops")

    # output.txt still contains "test", instead of becoming an empty file
    """
    tmp_file = get_tmp_path("/tmp")
    with open(tmp_file, "w") as f:
        yield f

    shutil.move(tmp_file, final_path)
