from .core import LabelingFunction, labeling_function  # noqa: F401
