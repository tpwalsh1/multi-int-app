import json
import os
import pathlib
from typing import Any, Dict, List, Optional, Union

import mlflow.pyfunc
import mock
import pandas as pd
from anyio import CapacityLimiter
from anyio.lowlevel import RunVar
from dask import dataframe as dd
from fastapi import Depends, FastAPI, Header, Request
from pydantic import BaseModel
from starlette.middleware.cors import CORSMiddleware

from api_utils.authentication import (
    BasicAPIKeyAuthenticationMiddleware,
    no_auth_required,
)
from api_utils.exceptions import SnorkelFlowAPIException, UserInputError
from api_utils.middleware import ORJSONResponse, log_ctx_middleware
from application_package import DataframeRecordsJSON
from operators.workflow_utils import store_ddf_to_path
from snorkelflow.config.constants import FASTAPI_THREADS_PER_CORE
from snorkelflow.data.core import INVALID_CSV_ERROR_MSG, is_improper_csv_format_error
from snorkelflow.serialization.get_serializable import get_serialization_types
from snorkelflow.serialization.pandas import serialize_dataframe
from snorkelflow.types.load import LoadConfig, SourceType
from snorkelflow.utils.dask import dask_compute
from snorkelflow.utils.datapoint import set_datapoint_index
from snorkelflow.utils.file import resolve_data_path
from snorkelflow.utils.logging import get_logger
from snorkelflow.utils.system import CPU_COUNT

logger = get_logger("MLFlow Server")


class BaseMLFlowServer:
    def __init__(
        self,
        model: mlflow.pyfunc.PyFuncModel,
        workflow_uid: Optional[int] = None,
        monitor: bool = True,
    ) -> None:
        self.model = model
        # These two are currently unused, here to keep the interface consistent
        # for future work
        self.workflow_uid = workflow_uid
        self.monitor = monitor

    @classmethod
    def from_package_dir(
        cls, workflow_dir: pathlib.Path, monitor: bool = True
    ) -> "BaseMLFlowServer":
        # Patch _add_code_from_conf_to_system_path not to add "/code" if exists to sys.path for backcompat.
        # This aligns with the design at #29730, where the sf code of the platform instead of the MLflow package should be used.
        # This patch is needed only for in-platform inference.
        with mock.patch("mlflow.pyfunc._add_code_from_conf_to_system_path"):
            model = mlflow.pyfunc.load_model(workflow_dir)
        return cls(model=model)


class MLFlowFileServer(BaseMLFlowServer):
    def execute(self, input_file_format: str, input_file: str, output_dir: str) -> None:
        if input_file_format == SourceType.CSV.name:
            try:
                df = pd.read_csv(resolve_data_path(input_file))
            except (ValueError, pd.errors.ParserError) as e:
                if is_improper_csv_format_error(e):
                    raise UserInputError(
                        detail=INVALID_CSV_ERROR_MSG,
                        user_friendly_message=INVALID_CSV_ERROR_MSG,
                    ) from None
                else:
                    raise e from None
        elif input_file_format == SourceType.PARQUET.name:
            df = pd.read_parquet(resolve_data_path(input_file))
        else:
            raise ValueError(f"Unknown file format: {input_file_format}")
        set_datapoint_index(df)

        results = self.model.predict(df)

        if not isinstance(results, pd.DataFrame):
            msg = f"All operator outputs must be Pandas DataFrames. Found {type(results)} for mlflow model"
            raise UserInputError(user_friendly_message=msg, detail=msg)

        results_ddf = dd.from_pandas(results, npartitions=1)
        pathlib.Path(output_dir).mkdir(exist_ok=True)

        if len(results_ddf) == 0:
            logger.warning(
                "No rows in the workflow dag output. Either the input is malformed or the workflow is not able to process this input"
            )
            return

        path = os.path.join(output_dir, "results")
        dask_compute(
            store_ddf_to_path(results_ddf, path=path, source_type=SourceType.PARQUET)
        )
        # save load config
        row = results_ddf.head(1).iloc[0]
        col_types = get_serialization_types(row)
        load_config = LoadConfig(
            path=path, col_types=col_types, type=SourceType.PARQUET
        )
        with open(os.path.join(output_dir, "results.json"), "w+") as f:
            json.dump(load_config.dict(exclude_defaults=True), f)


class MLflowAPIServer(BaseMLFlowServer):
    def server(self, max_content_length: int = 1_000_000_000) -> FastAPI:
        def valid_content_length(
            content_length: int = Header(..., lt=max_content_length)
        ) -> int:
            return content_length

        app = FastAPI(default_response_class=ORJSONResponse)

        app.add_middleware(
            CORSMiddleware,
            allow_origins=["*"],
            allow_credentials=True,
            allow_methods=["*"],
            allow_headers=["*"],
        )

        app.add_middleware(
            BasicAPIKeyAuthenticationMiddleware, api_key=os.environ.get("API_KEY")
        )

        @app.middleware("http")
        async def workflow_server_log_ctx_middleware(
            request: Request, call_next: Any
        ) -> Any:
            return await log_ctx_middleware(request, call_next)

        @app.exception_handler(SnorkelFlowAPIException)
        async def snorkel_flow_api_exception_handler(
            request: Request, exc: SnorkelFlowAPIException
        ) -> Any:
            return exc.construct_json_response()

        @app.on_event("startup")
        def startup_event() -> None:
            # Set number of starlette threadpool workers
            # https://github.com/tiangolo/fastapi/issues/4221
            num_workers = int(
                os.environ.get(
                    "WORKFLOW_API_NUM_THREADS", CPU_COUNT * FASTAPI_THREADS_PER_CORE
                )
            )
            logger.info(f"Setting max threadpool workers to {num_workers}")
            RunVar("_default_thread_limiter").set(CapacityLimiter(num_workers))  # type: ignore

        @no_auth_required(app)
        @app.get("/")
        def ping() -> Dict[str, str]:
            # The _WorkflowDAGWrapper class that provides the predict() entrypoint
            # is accessible under model._model_impl (it has the workflow_config defined)
            return {"workflow_config": str(self.model._model_impl.dag.workflow_config)}

        class ExecuteWorkflowParams(BaseModel):
            input_df_json: List[Dict[str, Any]]
            return_columns: Optional[List[str]] = None
            pickle_output: bool = False

        @app.post("/execute", dependencies=[Depends(valid_content_length)])
        def execute(
            params: ExecuteWorkflowParams,
        ) -> Union[Dict[str, DataframeRecordsJSON], Dict[str, str]]:
            logger.info(
                f"Executing workflow on input of length {len(params.input_df_json)}"
            )
            df = pd.DataFrame(params.input_df_json)
            set_datapoint_index(df)
            try:
                predictions_df = self.model.predict(df)
            except Exception as e:
                raise SnorkelFlowAPIException(
                    status_code=400, detail=f"Error executing workflow: {e}"
                )

            if params.pickle_output:
                output = serialize_dataframe(dict(results=predictions_df))
                return {"pickled_output": output}

            if params.return_columns:
                try:
                    predictions_df = predictions_df[params.return_columns]
                except KeyError:
                    raise SnorkelFlowAPIException(
                        status_code=400,
                        detail=(
                            f"Could not select columns {params.return_columns} "
                            f"from response dataframe with columns {predictions_df.columns}"
                        ),
                    )
            return ORJSONResponse(
                dict(results=predictions_df.to_dict(orient="records"))
            )

        return app


def create_app() -> FastAPI:
    """
    The MLflow API server is run via a CLI interface with gunicorn
    where parameters are passed in as environment variables (no way to thread
    argv through a gunicorn call)
    """
    if "MLFLOW_MODEL_DIR" not in os.environ:
        raise RuntimeError(f"Required envvar $MLFLOW_MODEL_DIR is undefined")
    kwargs = dict()
    max_content_length = os.environ.get("MAX_CONTENT_LENGTH")
    if max_content_length is not None:
        kwargs = {"max_content_length": int(max_content_length)}
    server = MLflowAPIServer.from_package_dir(
        pathlib.Path(os.environ["MLFLOW_MODEL_DIR"])
    )
    return server.server(**kwargs)  # type: ignore
