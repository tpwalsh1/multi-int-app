from snorkelflow.utils.logging import set_up_logging  # isort: skip

set_up_logging()

from typing import Dict, Type

from snorkelflow.types.application_package import (  # noqa: F401
    DataframeRecordsJSON,
    PackageType,
    WorkflowEnv,
)

from .core import (  # noqa: F401
    BaseWorkflowPackage,
    WorkflowPackageExecutionError,
    build_exception_contents,
    parse_exception_contents,
)
from .mlflow_utils import MLflowModel  # noqa: F401
from .snorkelflow_utils import (  # noqa: F401
    SnorkelFlowPackage,
    SnorkelFlowPackageHandler,
    WorkflowVersionError,
)
from .workflow import execute_workflow_ddf  # noqa: F401

PACKAGE_TYPES: Dict[PackageType, Type[BaseWorkflowPackage]] = {
    PackageType.MLflowModel: MLflowModel,
    PackageType.SnorkelFlowPackage: SnorkelFlowPackage,
}


def get_package_type(package_type: PackageType) -> Type[BaseWorkflowPackage]:
    PackageType = PACKAGE_TYPES.get(package_type)
    if PackageType is None:
        raise ValueError(
            f"Unknown package_type {package_type}. "
            f"Known package_types: {list(PACKAGE_TYPES.keys())}. "
            "Was package_type added to the PACKAGE_TYPES registry?"
        )
    else:
        return PackageType
