import copy
import glob
import json
import os
import pathlib
import shutil
import subprocess
import tempfile
import urllib.parse
import zipfile
from contextlib import contextmanager
from typing import Any, Dict, Generator, List, Optional, Set, Tuple, Union

import dask.dataframe as dd
import mlflow.entities.experiment
import mlflow.models
import mlflow.pyfunc
import mlflow.utils.environment
import packaging
import pandas as pd
import re2
import yaml
from mlflow.models.model import MLMODEL_FILE_NAME, Model, ModelInfo
from mlflow.models.signature import ModelSignature
from mlflow.store.artifact.models_artifact_repo import ModelsArtifactRepository
from mlflow.tracking.request_header.default_request_header_provider import (
    _USER_AGENT,
    DefaultRequestHeaderProvider,
)
from mlflow.tracking.request_header.registry import _request_header_provider_registry
from mlflow.types.schema import ColSpec, Schema
from mlflow.utils.proto_json_utils import NumpyEncoder

from application_package.snorkelflow_utils import WorkflowVersionError
from operators.get_operator import get_operator_class
from operators.workflows import WorkflowDAG
from snorkelflow.extraction.span import SpanCols
from snorkelflow.types.application_package import (
    DeploymentExternalRegistryStorageInfo,
    DeploymentFileStorageInfo,
    DeploymentInternalRegistryStorageInfo,
    DeploymentModelRegistryStorageInfo,
    DeploymentStorageInfo,
    ModelRegistryAccessInformation,
    WorkflowEnv,
)
from snorkelflow.types.workflows import INPUT_NODE_TYPE, WorkflowConfig
from snorkelflow.utils.constants import VENDOR_PRODUCT_NAME
from snorkelflow.utils.datapoint import set_datapoint_index
from snorkelflow.utils.file import resolve_data_path
from snorkelflow.utils.logging import get_logger

from .core import (
    WORKFLOW_FILENAME,
    BaseWorkflowPackage,
    WorkflowPackageExecutionError,
    get_workflow_file_contents,
    workflow_config_from_workflow_contents,
)


class SnorkelFlowRequestHeaderProvider(DefaultRequestHeaderProvider):
    """
    Provides our custom request headers for outgoing request.
    """

    def request_headers(self) -> Dict:
        return {
            _USER_AGENT: f"{VENDOR_PRODUCT_NAME}/{os.environ.get('SNORKEL_FLOW_VERSION', 'UNKNOWN')} (MLflow)"
        }


# Add a custom request header provider to append our custom uesr agent to the HTTP request header.
# Adding our specific user agent is a requirement for the Databricks partnership.
# Note that the current way of doing this is not through MLflow's public interface and is more vulnerable to a breaking change.
_request_header_provider_registry.register(SnorkelFlowRequestHeaderProvider)

logger = get_logger("MLflowModel")

V_0_64_0 = packaging.version.parse("0.64.0")


CondaEnvData = Dict[str, Union[str, List[str]]]


# We read and parse requirements from this file, rather than
# copying it directly.
REQUIREMENTS_PATH = pathlib.Path(__file__).parent.absolute() / "mlflow_requirements.in"
SNORKEL_FLOW_VERSION = os.environ.get("SNORKEL_FLOW_VERSION", "0.0.1")
wheels = glob.glob("/snorkelflowmlflow-*-py3-none-any.whl")
# No wheel is found during unit tests, fall back to the default wheel name
CODE_ARCHIVE_PATH = wheels[0] if wheels else "/snorkelflowmlflow-DNE-py3-none-any.whl"

# See https://pandas.pydata.org/docs/user_guide/basics.html#dtypes for the full list
DDF_TO_MLFLOW_TYPES = {
    # columns missing types are assumed to be strings
    None: "string",
    "bool": "boolean",
    "int": "integer",
    "int32": "integer",  # Int32Dtype
    "int64": "long",  # Int64Dtype
    "float": "float",
    "float32": "float",
    "float64": "double",
    "string": "string",  # StringDtype
    "object": "string",
    "category": "string",
    "datetime64[ns]": "datetime",
    "bytes": "binary",
    "dtype[str_]": "string",  # numpy/pandas
    "dtype[int64]": "long",  # numpy/pandas
    "dtype[object_]": "string",  # numpy/pandas
    "_GenericAlias": "string",  # typing
}

TYPE_HINTS_TO_MLFLOW_TYPES = {
    str: "string",
    int: "long",
    float: "double",
    bool: "boolean",
}


class MLFlowArtifactURI(urllib.parse.ParseResult):
    MLFLOWPKG_SCHEME = "mlflowpkg"

    def geturl_local(self, package_data_path: pathlib.Path) -> str:
        if self.scheme == self.MLFLOWPKG_SCHEME:
            # Need to trim leading slash if present, otherwise won't join with
            # package path
            path = self.path[1:] if self.path[0] == "/" else self.path
            return str(package_data_path / path)
        return self.geturl()

    @classmethod
    def parse(cls, uri: str) -> "MLFlowArtifactURI":
        uri_parsed = urllib.parse.urlparse(uri)
        if not uri_parsed.scheme:
            path = pathlib.Path(uri_parsed.path)
            if path.is_absolute():
                raise ValueError("Cannot parse MLFlowArtifactURI from absolute path")
            netloc = path.parts[0]
            uri_path = str(path.relative_to(netloc))
            uri_parsed = uri_parsed._replace(
                scheme=cls.MLFLOWPKG_SCHEME, netloc=netloc, path=uri_path
            )
        return cls(**uri_parsed._asdict())


class _MLflowModelWriter:
    def __init__(
        self,
        path: pathlib.Path,
        code_dirname: str = mlflow.pyfunc.CODE,
        data_dirname: str = mlflow.pyfunc.DATA,
        conda_env_filename: str = "conda.yaml",  # Databricks can only recognize conda.yaml (not yml extension)
        mlflow_signature: Optional[ModelSignature] = None,
    ) -> None:
        self.path = path
        self.code_dirname = code_dirname
        self.data_dirname = data_dirname
        self.conda_env_filename = conda_env_filename
        self.mlflow_signature = mlflow_signature
        self._add_code_directory()

    @property
    def code_dir_path(self) -> pathlib.Path:
        return self.path / self.code_dirname

    @property
    def data_dir_path(self) -> pathlib.Path:
        return self.path / self.data_dirname

    def _add_code_directory(self) -> None:
        self.path.mkdir(exist_ok=True)
        (self.code_dir_path).mkdir(exist_ok=True)

    def add_data_directory(self) -> None:
        # run this after code archive is created
        (self.data_dir_path).mkdir(exist_ok=True)

    def add_code_archive(self, archive_path: pathlib.Path) -> None:
        with zipfile.ZipFile(archive_path, "r") as z:
            z.extractall(self.code_dir_path)

        wheel_dir = self.path / "wheels"
        wheel_dir.mkdir(exist_ok=True)
        shutil.copy(archive_path, wheel_dir / pathlib.Path(CODE_ARCHIVE_PATH).name)

    def add_data_object(self, object_path: pathlib.Path) -> pathlib.Path:
        target_path = self.data_dir_path / object_path.name
        if target_path.exists():
            logger.warn(f"Data object {object_path.name} already exists for this model")
        if object_path.is_dir():
            shutil.copytree(str(object_path), str(target_path))
        else:
            shutil.copy2(str(object_path), str(target_path))
        return target_path.relative_to(self.path)

    def add_data_json(self, filename: str, contents: Dict[str, Any]) -> pathlib.Path:
        target_path = self.data_dir_path / filename
        if target_path.exists():
            logger.warn(f"Data object {filename} already exists for this model")
        with open(target_path, "w") as f:
            json.dump(contents, f)
        return target_path.relative_to(self.path)

    def _get_dependencies(
        self,
        override_deps: Optional[Dict[str, str]] = None,
        additional_op_model_deps: Optional[Set[str]] = None,
    ) -> List[str]:
        # NOTE: this should really be based on the workflow itself. Ideally, we
        # have a set of base requirements for the workflow package, and then each
        # operator should know its dependencies. However, punting for now as this
        # is technically not required to be correct (as long as the runtime
        # environment provides the right dependencies)
        with open(REQUIREMENTS_PATH) as f:
            additional_pip_deps = set()
            delimiter_pattern = re2.compile("<[=>]?|==|>=?")
            for line in f.readlines():
                if line.startswith("#"):
                    continue
                line = line.strip()
                lib_and_version = delimiter_pattern.split(line)
                if not lib_and_version:
                    logger.warning(
                        f"bad dependency line found in requirement file: {line}"
                    )
                    continue
                if override_deps and lib_and_version[0] in override_deps:
                    line = f"{lib_and_version[0]}=={override_deps[lib_and_version[0]]}"
                additional_pip_deps.add(line)
            # add wheel file as dependency
            additional_pip_deps.add(f"wheels/{pathlib.Path(CODE_ARCHIVE_PATH).name}")
            if additional_op_model_deps is not None:
                additional_pip_deps.update(additional_op_model_deps)
                logger.info(f"additional op deps: {additional_op_model_deps}")
            return list(additional_pip_deps)

    def add_conda_env(
        self,
        conda_env: Optional[Union[CondaEnvData, str]],
        override_deps: Optional[Dict[str, str]] = None,
        additional_deps: Optional[Set[str]] = None,
    ) -> pathlib.Path:
        target_path = self.path / self.conda_env_filename
        if target_path.exists():
            logger.warn(f"Conda env file already exists for this model")
        if conda_env is None:
            conda_env = mlflow.utils.environment._mlflow_conda_env(
                additional_pip_deps=self._get_dependencies(
                    override_deps, additional_deps
                ),
                # We are already including our specific version of mlflow in the conda.yaml
                # no need to add it twice
                install_mlflow=False,
            )
        elif not isinstance(conda_env, dict):
            with open(conda_env) as f:
                conda_env = yaml.safe_load(f)
        with open(target_path, "w") as f:
            yaml.safe_dump(conda_env, stream=f, default_flow_style=False)
        return target_path.relative_to(self.path)

    def save(self, mlflow_model: Optional[Model]) -> None:
        if mlflow_model is None:
            mlflow_model = Model()
        if self.mlflow_signature:
            mlflow_model.signature = self.mlflow_signature
        mlflow_model.add_flavor(
            mlflow.pyfunc.FLAVOR_NAME,
            data=self.data_dirname,
            env=self.conda_env_filename,
            loader_module=__name__,
        )
        mlflow_model.save(self.path / MLMODEL_FILE_NAME)


def _validate_workflow(workflow_dag: WorkflowDAG) -> None:
    operator_blocklist = {
        # LabelingFunctions is not supported but will be converted to
        # LabelingFunctionsExportable during package creation
        "LabelingFunctions"
    }
    for operator in workflow_dag.get_operators().values():
        op_name = type(operator).__name__
        if op_name in operator_blocklist:
            raise ValueError(f"{op_name} operators not allowed in MLflow packages")


def read_mapping_file() -> Dict[str, List[str]]:
    with open("src/python/application_package/dependency_mapping.json") as f:
        mapping = json.load(f)
    return mapping


class _WorkflowDAGWrapper(mlflow.pyfunc.PythonModel):
    def __init__(self, workflow_dag: WorkflowDAG) -> None:
        self.dag = workflow_dag

    def predict(self, model_input: pd.DataFrame) -> pd.DataFrame:
        set_datapoint_index(model_input)
        output_ddfs = self.dag.execute(dd.from_pandas(model_input, npartitions=1))
        if len(output_ddfs) != 1:
            raise ValueError(
                f"WorkflowDAG for {self.__class__.__name__} should produce 1 output, "
                f"but produced {len(output_ddfs)}"
            )
        output_ddf = list(output_ddfs.values())[0]
        # note: columms may be dropped that are included in the output_schema of the WorkflowDAG
        return _drop_nonserializable_columns(output_ddf.compute())


def _is_json_serializable(obj: Any) -> bool:
    try:
        # Attempt to serialize the object
        # borrowed from https://github.com/mlflow/mlflow/blob/master/mlflow/pyfunc/scoring_server/__init__.py#L242
        json.dumps(obj, cls=NumpyEncoder)
        return True
    except Exception:
        return False


def _drop_nonserializable_columns(df: pd.DataFrame) -> pd.DataFrame:
    if df.shape[0] == 0:
        return df
    json_serializable_cols = []
    for col, val in df.iloc[0].to_dict().items():
        if _is_json_serializable(val):
            json_serializable_cols.append(col)
    dropped_cols = set(df.columns) - set(json_serializable_cols)
    logger.info(f"Dropping non-serializable columns: {dropped_cols}")
    return df[json_serializable_cols]


def _update_workflow_config_paths(
    workflow_config: WorkflowConfig, data_path: pathlib.Path
) -> None:
    # Update artifact paths in config to point to absolute path on loading filesystem
    for op_id, cfg in workflow_config.items():
        if cfg.op_type == INPUT_NODE_TYPE:
            continue
        # For custom operator classes, the class is defined in the op_asset field
        OpType = get_operator_class(cfg.op_type, cls_asset=cfg.op_asset)
        for artifact_config_key in OpType.artifact_config_keys:  # type: ignore
            package_uri = MLFlowArtifactURI.parse(cfg.op_config[artifact_config_key])
            cfg.op_config[artifact_config_key] = package_uri.geturl_local(data_path)


def _load_pyfunc(data_path: str) -> _WorkflowDAGWrapper:
    # To prevent the memory leak (ENG-22039), run the Dask in a separate process.
    # Once we upgrade Dask to 2024.2.1, we could switch back to "threas" scheduler.
    import dask

    dask.config.set(scheduler="processes")

    with open(os.path.join(data_path, WORKFLOW_FILENAME)) as f:
        workflow = json.load(f)
    workflow_config = workflow_config_from_workflow_contents(workflow)
    _update_workflow_config_paths(workflow_config, pathlib.Path(data_path))
    input_columns = workflow["input_columns"]
    workflow_dag = WorkflowDAG(
        data_schema={col: None for col in input_columns},
        workflow_config=workflow_config,
    )
    return _WorkflowDAGWrapper(workflow_dag)


@contextmanager
def _mlflow_temporary_envvars(
    registry_access_info: ModelRegistryAccessInformation,
) -> Generator[None, None, None]:
    """
    NB: The *only* way that MLflow allows you to configure storage params or registry
    authentication is via environment variables, they're not configurable directly via the
    API. See https://www.mlflow.org/docs/latest/tracking.html#logging-to-a-tracking-server
    Use this context manager to temporarily set the respective envvars while interacting
    with the mlflow SDK

    TODO - take lock before running this to ensure that other workers in the same
    process space don't clobber our envvars
    """
    storage_config = registry_access_info.storage_credentials
    auth = registry_access_info.auth_credentials

    try:
        # Tell MLflow to not complain when it can't find a git environment
        os.environ["GIT_PYTHON_REFRESH"] = "quiet"
        # Set DATABRICKS_HOST in case it is Databricks (incl. Azure Databricks)
        os.environ["DATABRICKS_HOST"] = registry_access_info.tracking_server_uri

        if storage_config:
            logger.info(
                f"Configuring MLFlow external registry storage: {storage_config}"
            )
            if storage_config.mlflow_s3_endpoint_url:
                os.environ[
                    "MLFLOW_S3_ENDPOINT_URL"
                ] = storage_config.mlflow_s3_endpoint_url
            if storage_config.aws_access_key_id:
                os.environ["AWS_ACCESS_KEY_ID"] = storage_config.aws_access_key_id
            if storage_config.aws_secret_access_key:
                os.environ[
                    "AWS_SECRET_ACCESS_KEY"
                ] = storage_config.aws_secret_access_key

        if auth:
            logger.info(
                f"Configuring MLflow external registry authentication scheme: {auth}"
            )
            if auth.username:
                os.environ["MLFLOW_TRACKING_USERNAME"] = auth.username
                os.environ["DATABRICKS_USERNAME"] = auth.username
            if auth.password:
                os.environ["MLFLOW_TRACKING_PASSWORD"] = auth.password
                os.environ["DATABRICKS_PASSWORD"] = auth.password
            if auth.bearer_token:
                os.environ["MLFLOW_TRACKING_TOKEN"] = auth.bearer_token
                os.environ["DATABRICKS_TOKEN"] = auth.bearer_token

        yield

    finally:
        os.environ.pop("MLFLOW_S3_ENDPOINT_URL", None)
        os.environ.pop("AWS_ACCESS_KEY_ID", None)
        os.environ.pop("AWS_SECRET_ACCESS_KEY", None)
        os.environ.pop("MLFLOW_TRACKING_USERNAME", None)
        os.environ.pop("MLFLOW_TRACKING_PASSWORD", None)
        os.environ.pop("MLFLOW_TRACKING_TOKEN", None)
        os.environ.pop("GIT_PYTHON_REFRESH", None)
        os.environ.pop("DATABRICKS_HOST", None)
        os.environ.pop("DATABRICKS_USERNAME", None)
        os.environ.pop("DATABRICKS_PASSWORD", None)
        os.environ.pop("DATABRICKS_TOKEN", None)


class _MLflowModelUploader:
    def __init__(
        self,
        package_path: pathlib.Path,
        model_name: str,
        registry_access_info: ModelRegistryAccessInformation,
        experiment_name: Optional[str] = None,
        tags: Optional[Dict[str, Any]] = None,
    ) -> None:
        self.package_path = package_path
        self.model_name = model_name
        self.experiment_name = experiment_name or self.model_name
        self.registry_access_info = registry_access_info
        self.tags = tags

    def _load_pyfunc_flavor(self) -> Dict[str, Any]:
        """Dictionary describing the pyfunc 'flavor'"""
        with open(self.package_path / MLMODEL_FILE_NAME) as fh:
            model_metadata = yaml.safe_load(fh.read())
        return model_metadata["flavors"][mlflow.pyfunc.FLAVOR_NAME]

    def _load_environment(self) -> Dict:
        """Load the Conda environment definition from the MLflow package"""
        pyfunc_flavor = self._load_pyfunc_flavor()
        env = pyfunc_flavor.get(mlflow.pyfunc.ENV, "conda.yaml")
        with open(self.package_path / env) as fh:
            conda_env = yaml.safe_load(fh.read())
        return conda_env

    # Made into separate function for simplified mocking
    def _perform_model_export(
        self, data_path: pathlib.Path, loader_module: str, conda_env: Dict
    ) -> Tuple[
        mlflow.models.model.ModelInfo, str, mlflow.entities.experiment.Experiment
    ]:
        # If model name contains ".", this means users want to register a model to Unity Catalog. Set the registery URI accordingly.
        if "." in self.model_name:
            mlflow.set_registry_uri("databricks-uc")
        else:
            mlflow.set_registry_uri(None)
        mlflow.set_tracking_uri(self.registry_access_info.tracking_server_uri)

        experiment = mlflow.set_experiment(experiment_name=self.experiment_name)

        logger.info(
            f"Attempting to register model {self.model_name} to tracking server {self.registry_access_info}"
        )
        with mlflow.start_run() as run:
            # Register a new MLflow to the remote tracking server
            model_uri = f"runs:/{run.info.run_id}/{self.model_name}"

            # Since we can't upload the self.package_path folder itself as it contains `code` sub folder,
            # we unzip the zip file, add additional metadata, then upload them to the tracking server.
            workflow_zip_file = self.package_path.with_suffix(".zip")
            with tempfile.TemporaryDirectory() as tmpdirname:
                with zipfile.ZipFile(workflow_zip_file, "r") as z:
                    z.extractall(tmpdirname)
                # Add additional metadata that are only available after the model is registered
                with open(os.path.join(tmpdirname, MLMODEL_FILE_NAME), "a") as f:
                    f.write(f"run_id: {run.info.run_id}\n")
                    f.write(f"artifact_path: '{self.model_name}'\n")
                mlflow.log_artifacts(tmpdirname, artifact_path=self.model_name)

                # Grab some metadata about the model
                model_meta = Model.load(os.path.join(tmpdirname, MLMODEL_FILE_NAME))
                model = ModelInfo(
                    artifact_path=self.model_name,
                    flavors=model_meta.flavors,
                    model_uri=model_uri,
                    model_uuid=model_meta.model_uuid,
                    run_id=run.info.run_id,
                    saved_input_example_info=model_meta.saved_input_example_info,
                    signature_dict=model_meta.signature.to_dict()
                    if model_meta.signature
                    else None,
                    signature=model_meta.signature,
                    utc_time_created=model_meta.utc_time_created,
                    mlflow_version=model_meta.mlflow_version,
                    metadata=model_meta.metadata,
                )
            model_version = mlflow.register_model(model_uri, self.model_name)

        # TODO - for tag in tags: add_model_tag
        # https://www.mlflow.org/docs/latest/python_api/mlflow.tracking.html#mlflow.tracking.MlflowClient.set_model_version_tag
        # set_model_version_tag(registered_model_name, version, key, value)

        logger.info(
            f"Newly registered model returned from remote tracking server: {model}"
        )
        return model, model_version.version, experiment

    def _parse_model_metadata(self) -> Tuple:
        conda_env = self._load_environment()
        model_metadata = self._load_pyfunc_flavor()
        loader_module = model_metadata[mlflow.pyfunc.MAIN]
        data_path = self.package_path / model_metadata[mlflow.pyfunc.DATA]

        # Because of a quirk with re-logging models, we need to register
        # each top-level item with {package}/code instead of the code directory itself.
        # Without this, the new registered model would have {package}/code/code
        return loader_module, data_path, conda_env

    def upload(self) -> DeploymentStorageInfo:
        loader_module, data_path, conda_env = self._parse_model_metadata()

        with _mlflow_temporary_envvars(self.registry_access_info):
            try:
                # Register a new MLflow to the remote tracking server
                model, model_version, experiment = self._perform_model_export(
                    data_path, loader_module, conda_env
                )
                storage_info = dict(
                    workflow_package_dir=str(self.package_path),
                    model_uuid=model.model_uuid,
                    model_uri=model.model_uri,
                    model_version=model_version,
                    run_id=model.run_id,
                    artifact_path=model.artifact_path,
                    registered_model_name=self.model_name,
                    experiment_name=experiment.name,
                    experiment_id=experiment.experiment_id,
                )
                if self.registry_access_info.model_registry_uid is None:
                    return DeploymentInternalRegistryStorageInfo(**storage_info)
                else:
                    return DeploymentExternalRegistryStorageInfo(
                        model_registry_uid=self.registry_access_info.model_registry_uid,
                        **storage_info,
                    )
            except Exception as e:
                logger.exception(
                    f"Unable to upload MLflowModel deployment to external tracking server {self.registry_access_info}"
                )
                raise e from None


class MLflowModel(BaseWorkflowPackage):
    def _construct_package(
        self,
        path: pathlib.Path,
        conda_env: Optional[Union[CondaEnvData, str]] = None,
        mlflow_model: Optional[mlflow.models.Model] = None,
        override_deps: Optional[Dict[str, str]] = None,
        mlflow_signature: Optional[ModelSignature] = None,
    ) -> None:
        _validate_workflow(self.dag)
        if mlflow_signature:
            writer = _MLflowModelWriter(path, mlflow_signature=mlflow_signature)
        else:
            writer = _MLflowModelWriter(path)
        writer.add_code_archive(pathlib.Path(CODE_ARCHIVE_PATH))
        writer.add_data_directory()
        workflow_config = copy.deepcopy(self.dag.workflow_config)
        additional_op_deps = set()
        operator_mapping = read_mapping_file()
        for operator_id, operator in self.dag.get_operators().items():
            # Copy all artifacts into MLflow package and update config
            for config_key, artifact_path in operator.get_artifact_config().items():
                artifact_path = resolve_data_path(artifact_path)
                try:
                    object_rel_path = writer.add_data_object(
                        pathlib.Path(artifact_path)
                    )
                except FileNotFoundError:
                    raise ValueError(
                        f"Could not copy data artifact {artifact_path}, not a filesystem "
                        "reference. Is it on the filesystem?"
                    )
                package_uri = MLFlowArtifactURI.parse(str(object_rel_path))
                workflow_config[operator_id].op_config[
                    config_key
                ] = package_uri.geturl()
            # Get all the additional dependencies for the operator
            op_lookup_key = workflow_config[operator_id].op_type
            # If the operator is a model, we need to fetch the model class to get the correct dependencies
            if self.model_classes and operator_id in self.model_classes:
                op_lookup_key = self.model_classes[operator_id]
            if op_lookup_key in operator_mapping:
                additional_op_deps.update(operator_mapping[op_lookup_key])
            else:
                logger.info(
                    f"Skipping adding deps for {op_lookup_key}. Operator not found in dependency mapping"
                )
        workflow = get_workflow_file_contents(workflow_config, self.dag.input_columns)
        writer.add_data_json(WORKFLOW_FILENAME, workflow)
        writer.add_conda_env(conda_env, override_deps, additional_op_deps)
        writer.save(mlflow_model)

    @classmethod
    def get_mlflow_signature(cls, data_schema: Dict) -> ModelSignature:
        # Only the input_schema is defined. output_schema is set to None by default
        input_schema = Schema(
            [
                ColSpec(
                    DDF_TO_MLFLOW_TYPES[typ],
                    col,
                    optional=True if col == SpanCols.CONTEXT_UID else False,
                )
                for (col, typ) in data_schema["inputs"].items()
            ]
        )
        # Convert data types using DDF_TO_MLFLOW_TYPES first, then TYPE_HINTS_TO_MLFLOW_TYPES, finally fall back to "string"
        output_schema = Schema(
            [
                ColSpec(
                    DDF_TO_MLFLOW_TYPES[typ]
                    if typ in DDF_TO_MLFLOW_TYPES
                    else (
                        TYPE_HINTS_TO_MLFLOW_TYPES[typ]
                        if typ in TYPE_HINTS_TO_MLFLOW_TYPES
                        else "string"
                    ),
                    col,
                )
                for (col, typ) in data_schema["outputs"].items()
            ]
        )
        return ModelSignature(inputs=input_schema, outputs=output_schema)

    def _push_to_registry(
        self,
        package_path: pathlib.Path,
        model_name: str,
        registry_access_info: ModelRegistryAccessInformation,
        experiment_name: Optional[str] = None,
        tags: Optional[Dict[str, Any]] = None,
    ) -> DeploymentStorageInfo:
        uploader = _MLflowModelUploader(
            package_path=package_path,
            model_name=model_name,
            experiment_name=experiment_name,
            registry_access_info=registry_access_info,
            tags=tags,
        )
        return uploader.upload()

    def save(
        self,
        workflow_dir_name: str,
        workflow_env: WorkflowEnv,
        model_name: Optional[str] = None,
        registry_access_info: Optional[ModelRegistryAccessInformation] = None,
        tags: Optional[Dict[str, Any]] = None,
        override_deps: Optional[Dict[str, str]] = None,
        experiment_name: Optional[str] = None,
        mlflow_signature: Optional[ModelSignature] = None,
    ) -> DeploymentStorageInfo:
        """
        Given a workflow and environment definition, write a new model to the
        specified registry by first constructing the model structure locally,
        then uploading that model to the registry.
        """
        # Liskov substitution principle violation - MLflowModelRegistry packages
        # need strictly more information to be saved than SnorkelFlowPackages.
        # We have to make these args "optional" to pass type checks but they
        # aren't really optional. We don't call this method polymorphically, anyway
        if not model_name:
            raise ValueError(f"MLflowModel package can only be saved with a name")
        workflow_dir = pathlib.Path(workflow_dir_name)
        conda_env = None
        if workflow_env == WorkflowEnv.FULL:
            raise NotImplementedError(
                f"Workflow env {workflow_env.name} is not implemented yet"
            )

        self._construct_package(
            path=workflow_dir,
            conda_env=conda_env,
            override_deps=override_deps,
            mlflow_signature=mlflow_signature,
        )
        # For now, we leave the MLflow model file + archive in the data volume
        # as a disaster-recovery method should something go wrong with the model
        # registry. It also makes it easier to test that we've correctly constructed
        # the model, as we don't have the registry available during unit tests to
        # pull the model from and run tests against
        self.archive(workflow_dir_name=workflow_dir_name)

        # https://snorkelai.atlassian.net/browse/ENG-17537
        # MLflow has a CVE and we have to disable the registry
        # For now, on upload, simply save it locally so it can
        # be downloaded and used without needing the registry
        # To this end, registry_access_info can now be optional and None means "save locally"
        if registry_access_info is None:
            storage_info: DeploymentStorageInfo = DeploymentFileStorageInfo(
                workflow_package_dir=workflow_dir_name
            )
        else:
            storage_info = self._push_to_registry(
                package_path=workflow_dir,
                model_name=model_name,
                registry_access_info=registry_access_info,
                experiment_name=experiment_name,
            )

        return storage_info

    @classmethod
    def load(
        cls,
        storage_information: DeploymentModelRegistryStorageInfo,
        registry_access_info: ModelRegistryAccessInformation,
    ) -> mlflow.pyfunc.PyFuncModel:
        """
        Given a model_uri and registry access information, load the mlflow
        model from the registry and return the model handle
        """
        mlflow.set_tracking_uri(registry_access_info.tracking_server_uri)
        with _mlflow_temporary_envvars(registry_access_info):
            model = mlflow.pyfunc.load_model(storage_information.model_version_uri)
        return model

    @classmethod
    def download(
        cls,
        path: pathlib.Path,
        storage_information: DeploymentModelRegistryStorageInfo,
        registry_access_info: ModelRegistryAccessInformation,
        archive: bool = False,
    ) -> pathlib.Path:
        """
        Given a model in a model registry, download the model package to the
        given path.

        archive
            If true, zip the download to {path}.zip and return the path
        """
        logger.info(
            f"Downloading model {storage_information.model_version_uri} from {registry_access_info.tracking_server_uri} to {path}"
        )
        mlflow.set_tracking_uri(registry_access_info.tracking_server_uri)
        with _mlflow_temporary_envvars(registry_access_info):
            path_str = str(path)
            ModelsArtifactRepository(
                storage_information.model_version_uri
            ).download_artifacts(
                # artifact_path="" means download all artifacts from the root ( "/" + "")
                # dst_path is the local path the directory will be downloaded to
                artifact_path="",
                dst_path=path_str,
            )
        if archive:
            logger.info(f"Archiving downloaded model at path {path}")
            archive_path = shutil.make_archive(path_str, "zip", path_str)
            return pathlib.Path(archive_path)
        return path


class MLFlowPackageHandler:
    snorkelflow_version: Optional[packaging.version.Version]

    def __init__(
        self, workflow_dir: pathlib.Path, collecting_monitoring_data: bool = True
    ) -> None:
        self.workflow_dir = workflow_dir
        self.collecting_monitoring_data = collecting_monitoring_data
        model_metadata = MLFlowPackageHandler._load_pyfunc_flavor(workflow_dir)
        data_path = workflow_dir / model_metadata[mlflow.pyfunc.DATA]
        with open(data_path / WORKFLOW_FILENAME) as f:
            workflow = json.load(f)
        snorkelflow_version_str = workflow.get(
            "snorkelflow_version",
            # NB: older package versions had a typo
            workflow.get("snorkflow_version", ""),
        )
        # Certain deployments have spec-violating versions that
        # end in a '-{A..F}' postfix, strip that postfix here
        snorkelflow_version_str = snorkelflow_version_str.split("-")[0]
        self.snorkelflow_verstion_str = snorkelflow_version_str
        try:
            snorkelflow_version = packaging.version.parse(snorkelflow_version_str)
            if not isinstance(snorkelflow_version, packaging.version.Version):
                # Handle cases like bazel and UNKNOWN which parse as LegacyVersion
                self.snorkelflow_version = None
            else:
                self.snorkelflow_version = snorkelflow_version
        except packaging.version.InvalidVersion:
            self.snorkelflow_version = None

        # We need /code when running MLflow within SnorkelFlow
        code_dir_path = workflow_dir / mlflow.pyfunc.CODE
        if not code_dir_path.exists():
            code_dir_path.mkdir()
            wheel_file_path = list(
                (workflow_dir / "wheels").glob("snorkelflowmlflow-*-py3-none-any.whl")
            )[0]
            with zipfile.ZipFile(wheel_file_path, "r") as fz:
                fz.extractall(code_dir_path)

    @staticmethod
    def _load_pyfunc_flavor(package_path: pathlib.Path) -> Dict[str, Any]:
        """Dictionary describing the pyfunc 'flavor'"""
        with open(package_path / MLMODEL_FILE_NAME) as fh:
            model_metadata = yaml.safe_load(fh.read())
        return model_metadata["flavors"][mlflow.pyfunc.FLAVOR_NAME]

    def run_execute(
        self, input_file_format: str, input_file: str, output_dir: str
    ) -> None:
        if (
            self.snorkelflow_version and self.snorkelflow_version >= V_0_64_0
        ) or not self.snorkelflow_version:
            args = [
                "python",
                str(pathlib.Path(__file__).parent.absolute() / "mlflow_main.py"),
                "execute",
                "--mlflow-dir",
                str(self.workflow_dir),
                "--input-file-format",
                input_file_format,
                "--input-file",
                input_file,
                "--output-dir",
                output_dir,
            ]
            if self.collecting_monitoring_data:
                args.insert(2, "--monitor")
        else:
            raise WorkflowVersionError(
                "MLFlow execute not available for workflow package versions < 0.64.0"
            )
        try:
            # Note: To enable accessing a pdb inside the workflow, add an addition pdb
            # statement here, set capture_output to False, and step through next line.
            out = subprocess.run(
                args, check=True, universal_newlines=True, capture_output=True
            )
            logger.info(out.stdout)
        except subprocess.CalledProcessError as e:
            msg = f"Failed to run workflow, err: {e.stderr}"
            logger.exception(msg)
            raise WorkflowPackageExecutionError(msg, stderr=e.stderr)

    def run_serve(
        self,
        host: Optional[str] = None,
        port: Optional[int] = None,
        max_content_length: Optional[int] = None,
        server_ttl: Optional[int] = None,
        n_workers: Optional[int] = None,
    ) -> None:
        if (
            self.snorkelflow_version and self.snorkelflow_version >= V_0_64_0
        ) or not self.snorkelflow_version:
            try:
                args = [
                    "python",
                    str(
                        self.workflow_dir
                        / mlflow.pyfunc.CODE
                        / "application_package"
                        / "mlflow_main.py"
                    ),
                    "serve",
                    "--mlflow-dir",
                    str(self.workflow_dir),
                ]
                if host is not None:
                    args.extend(["--host", host])
                if port is not None:
                    args.extend(["--port", str(port)])
                if max_content_length is not None:
                    args.extend(["--max-content-length", str(max_content_length)])
                if n_workers is not None:
                    args.extend(["--n-workers", str(n_workers)])
                subprocess.run(
                    args,
                    check=True,
                    stderr=subprocess.PIPE,
                    universal_newlines=True,
                    timeout=server_ttl,
                )
            except subprocess.CalledProcessError as e:
                msg = f"Failed to run workflow server, err: {e.stderr}"
                logger.exception(msg)
                raise ValueError(msg)
        else:
            raise WorkflowVersionError(
                "Serving option not available for MLflow package versions < 0.64.0"
            )
