import json
import os
import pathlib
from typing import Any, Dict, List, Optional, Union

import pandas as pd
from anyio import CapacityLimiter
from anyio.lowlevel import RunVar
from dask import dataframe as dd
from fastapi import Depends, FastAPI, Header, Request
from pydantic import BaseModel
from starlette.middleware.cors import CORSMiddleware

from api_utils.authentication import (
    BasicAPIKeyAuthenticationMiddleware,
    no_auth_required,
)
from api_utils.exceptions import SnorkelFlowAPIException, UserInputError
from api_utils.middleware import ORJSONResponse, log_ctx_middleware
from application_package import DataframeRecordsJSON
from application_package.snorkelflow_utils import SnorkelFlowPackage
from common_routers import cpu_profiling, jobs
from engine.client import AsyncJobResponse, start_tdm_engine_job
from engine.common.type.queue import EngineQueue
from engine.common.type.workflows import ExecutePredictionAPIAsyncInferenceParams
from monitoring.client import MonitoringClient, MonitoringClientError, MonitoringCols
from operators.workflow_utils import store_ddf_to_path
from operators.workflows import WorkflowDAG
from profiling_utils.profiler import CPUProfilerThread
from redis_utils.connection import connect_to_instance_cache, init_redis
from snorkelflow.config.constants import (
    FASTAPI_THREADS_PER_CORE,
    REDIS_PASSWORD_ENV_VAR,
    REDIS_PORT_ENV_VAR,
    REDIS_SSL_ENABLED_ENV_VAR,
    REDIS_URL_ENV_VAR,
    ServiceType,
)
from snorkelflow.data.core import INVALID_CSV_ERROR_MSG, is_improper_csv_format_error
from snorkelflow.serialization.get_serializable import (
    cls_is_serializable,
    get_serialization_types,
)
from snorkelflow.serialization.pandas import serialize_dataframe
from snorkelflow.types.jobs import JobType
from snorkelflow.types.load import DATAPOINT_UID_COL, LoadConfig, SourceType
from snorkelflow.utils.dask import dask_compute
from snorkelflow.utils.datapoint import set_datapoint_index
from snorkelflow.utils.file import resolve_data_path
from snorkelflow.utils.logging import get_logger
from snorkelflow.utils.system import CPU_COUNT

logger = get_logger("Workflow Server")


class BaseWorkflowServer:
    def __init__(
        self,
        workflow_dag: WorkflowDAG,
        workflow_uid: Optional[int] = None,
        monitor: bool = True,
    ) -> None:
        self.workflow_dag = workflow_dag
        self.monitoring_client: Optional[MonitoringClient] = None
        self.workflow_uid = workflow_uid
        if monitor:
            if workflow_uid is None:
                logger.warning(
                    f"Client requested monitoring but unable to determine deployment ID"
                )
            else:
                self.monitoring_client = MonitoringClient.from_environment(
                    deployment_uid=workflow_uid
                )
                logger.info(
                    f"Initializing the monitoring client: {self.monitoring_client}"
                )

    @classmethod
    def from_package_dir(
        cls, workflow_dir: pathlib.Path, monitor: bool = True
    ) -> "BaseWorkflowServer":
        pkg = SnorkelFlowPackage.from_package_dir(workflow_dir)
        return cls(pkg.dag, pkg.workflow_uid, monitor=monitor)


# TODO: Make this a shared helper with maybe_serialize in engine.py
# NOTE - this helper does not turn {list, dict} into json while the
# maybe_serialize method in engine.py does. Our unit tests expect
# list/dict outputs to not be serialized as json (see
# test_workflow_package_backwards_compatibility.py for examples)
def _maybe_serialize_workflow(x: Any) -> Any:
    try:
        # TODO: Look up type instead of using try/except
        json.dumps(x)
        return x
    except TypeError:
        if cls_is_serializable(type(x)):
            return x.serialize()
        return str(x)


class WorkflowFileServer(BaseWorkflowServer):
    def execute(self, input_file_format: str, input_file: str, output_dir: str) -> None:
        if input_file_format == SourceType.CSV.name:
            try:
                df = pd.read_csv(resolve_data_path(input_file))
            except (ValueError, pd.errors.ParserError) as e:
                if is_improper_csv_format_error(e):
                    raise UserInputError(
                        detail=INVALID_CSV_ERROR_MSG,
                        user_friendly_message=INVALID_CSV_ERROR_MSG,
                    ) from None
                else:
                    raise e from None
        elif input_file_format == SourceType.PARQUET.name:
            df = pd.read_parquet(resolve_data_path(input_file))
        else:
            raise ValueError(f"Unknown file format: {input_file_format}")
        set_datapoint_index(df)
        ddf = dd.from_pandas(df, npartitions=1)

        if self.monitoring_client:
            try:
                ddf = self.monitoring_client.initialize_and_store_inputs(ddf)
            except Exception as e:
                # We normally try to avoid catch-alls like this but we want to ensure that errors
                # with the monitoring client never prevent us from returning inference results to the caller
                logger.exception(
                    f"Error while attempting to log inference data to monitoring client: {e}"
                )

        leaf_ddfs = self.workflow_dag.execute(ddf)

        pathlib.Path(output_dir).mkdir(exist_ok=True)
        for op_key, leaf_ddf in leaf_ddfs.items():
            if self.monitoring_client:
                # In practice, exported workflows only have a single leaf,
                # this is enforced during export (see /application/:id/exports)
                try:
                    df = dask_compute(leaf_ddf)[0]
                    df.reset_index(inplace=True)
                    df.rename(
                        columns={DATAPOINT_UID_COL: MonitoringCols.X_UID}, inplace=True
                    )
                    self.monitoring_client.record_outputs(df)
                    leaf_ddf = dd.from_pandas(df, npartitions=1)
                except MonitoringClientError as e:
                    # One of our known errors
                    logger.error(
                        f"Error while attempting to record inference outputs: {e}"
                    )
                except Exception as e:
                    # See above, catch-all is justified in this case
                    logger.error(
                        f"Error while attempting to log deployment outputs to monitoring client: {e}"
                    )

            if len(leaf_ddf) == 0:
                logger.warning(
                    "No rows in the workflow dag output. Either the input is malformed or the workflow is not able to process this input"
                )
                continue

            logger.info(f"Writing model {op_key}.parquet using parquet engine=pyarrow")
            dask_compute(
                store_ddf_to_path(
                    leaf_ddf,
                    path=os.path.join(output_dir, f"{op_key}"),
                    source_type=SourceType.PARQUET,
                )
            )
            # save load config
            row = leaf_ddf.head(1).iloc[0]
            col_types = get_serialization_types(row)
            load_config = LoadConfig(
                path=os.path.join(output_dir, f"{op_key}"),
                col_types=col_types,
                type=SourceType.PARQUET,
            )
            with open(os.path.join(output_dir, f"{op_key}.json"), "w+") as f:
                json.dump(load_config.dict(exclude_defaults=True), f)

        if self.monitoring_client:
            try:
                self.monitoring_client.flush_to_filesystem(output_dir)
            except Exception as e:
                logger.exception(f"Error while flushing monitoring data to system: {e}")


class WorkflowAPIServer(BaseWorkflowServer):
    def __init__(
        self,
        workflow_dag: WorkflowDAG,
        workflow_uid: Optional[int] = None,
        monitor: bool = True,
    ) -> None:
        super().__init__(
            workflow_dag=workflow_dag, workflow_uid=workflow_uid, monitor=monitor
        )
        # Preload the workflow resources
        self.workflow_dag.preload_workflow_resources()
        self.async_enabled = False

    def server(self, max_content_length: int = 1_000_000_000) -> FastAPI:
        def valid_content_length(
            content_length: int = Header(..., lt=max_content_length)
        ) -> int:
            return content_length

        app = FastAPI(default_response_class=ORJSONResponse)

        app.add_middleware(
            CORSMiddleware,
            allow_origins=["*"],
            allow_credentials=True,
            allow_methods=["*"],
            allow_headers=["*"],
        )

        app.add_middleware(
            BasicAPIKeyAuthenticationMiddleware, api_key=os.environ.get("API_KEY")
        )

        @app.middleware("http")
        async def workflow_server_log_ctx_middleware(
            request: Request, call_next: Any
        ) -> Any:
            return await log_ctx_middleware(request, call_next)

        @app.exception_handler(SnorkelFlowAPIException)
        async def snorkel_flow_api_exception_handler(
            request: Request, exc: SnorkelFlowAPIException
        ) -> Any:
            return exc.construct_json_response()

        @app.on_event("startup")
        def startup_event() -> None:
            # Set number of starlette threadpool workers
            # https://github.com/tiangolo/fastapi/issues/4221
            num_workers = int(
                os.environ.get(
                    "WORKFLOW_API_NUM_THREADS", CPU_COUNT * FASTAPI_THREADS_PER_CORE
                )
            )
            redis_url = os.environ.get(REDIS_URL_ENV_VAR, None)
            logger.info(f"Redis URL : {redis_url}")

            if redis_url:
                redis_ssl_enabled = bool(
                    os.environ.get(REDIS_SSL_ENABLED_ENV_VAR, False)
                )
                redis_password = os.environ.get(REDIS_PASSWORD_ENV_VAR, None)
                _port = os.environ.get(REDIS_PORT_ENV_VAR, None)
                redis_port = int(_port) if _port else None
                try:
                    init_redis(
                        redis_url,
                        redis_ssl_enabled,
                        redis_password,
                        redis_port=redis_port,
                    )
                except Exception as e:
                    logger.exception(
                        f"Fail to access Redis, Redis URL:{redis_url}, error: {e}"
                    )
            if redis_url:
                profiler_thread = CPUProfilerThread(
                    ServiceType.PredictionAPI, connect_to_instance_cache()
                )
                profiler_thread.start()

            logger.info(f"Setting max threadpool workers to {num_workers}")
            RunVar("_default_thread_limiter").set(CapacityLimiter(num_workers))  # type: ignore

        @no_auth_required(app)
        @app.get("/")
        def ping() -> Dict[str, str]:
            return {"workflow_config": str(self.workflow_dag.workflow_config)}

        class ExecuteWorkflowAsyncParams(BaseModel):
            input_df_json: List[Dict[str, Any]]
            return_columns: Optional[List[str]] = None

        @app.post("/execute-async")
        def execute_async(params: ExecuteWorkflowAsyncParams) -> AsyncJobResponse:
            try:
                logger.info(f"Attempting to launch identity async inference execution")
                job_id = start_tdm_engine_job(
                    "application_package.jobs.execute_async",
                    job_type=JobType.PREDICTION_API_ASYNC_INFERENCE,
                    engine_queue=EngineQueue.PREDICTION_API,
                    params=ExecutePredictionAPIAsyncInferenceParams(
                        workflow_config=self.workflow_dag.workflow_config,
                        input_df_json=params.input_df_json,
                        return_columns=params.return_columns,
                    ),
                    message=f"Running asynchronous inference job",
                )
                return AsyncJobResponse.for_rq_job_id(job_id)
            except RuntimeError as e:
                # RuntimeError is raised if redis_url is not defined (we lack a redis connection)
                if "Redis host not set yet" in str(e):
                    raise SnorkelFlowAPIException(
                        status_code=503,
                        detail=f"Asynchronous inference unavailable, Redis connection undefined",
                    )
                raise SnorkelFlowAPIException(status_code=400, detail=str(e))
            except Exception as e:
                logger.exception(f"Error while handling execution request")
                raise SnorkelFlowAPIException(status_code=400, detail=str(e))

        class ExecuteWorkflowParams(BaseModel):
            input_df_json: List[Dict[str, Any]]
            return_columns: Optional[List[str]] = None
            pickle_output: bool = False

        @app.post("/execute", dependencies=[Depends(valid_content_length)])
        def execute(
            params: ExecuteWorkflowParams,
        ) -> Union[Dict[str, DataframeRecordsJSON], Dict[str, str]]:
            logger.info(
                f"Executing workflow on input of length {len(params.input_df_json)}"
            )
            df = pd.DataFrame(params.input_df_json)
            set_datapoint_index(df)
            try:
                ddf = dd.from_pandas(df, npartitions=1)
            except Exception as e:
                raise SnorkelFlowAPIException(
                    status_code=400,
                    detail=f"Failed to parse input JSON as DataFrame: {e}",
                )
            try:
                leaf_ddfs = self.workflow_dag.execute(ddf)
            except Exception as e:
                raise SnorkelFlowAPIException(
                    status_code=400, detail=f"Error executing workflow: {e}"
                )
            output_jsons: Dict[str, DataframeRecordsJSON] = {}
            try:
                leaf_dfs = dask_compute(leaf_ddfs)[0]
            except Exception as e:
                raise SnorkelFlowAPIException(
                    status_code=400, detail=f"Error executing workflow: {e}"
                )

            if params.pickle_output:
                output = serialize_dataframe(leaf_dfs)
                return {"pickled_output": output}

            for op_key, df in leaf_dfs.items():
                if params.return_columns:
                    try:
                        df = df[params.return_columns]
                    except KeyError:
                        raise SnorkelFlowAPIException(
                            status_code=400,
                            detail=(
                                f"Could not select columns {params.return_columns} "
                                f"from operator {op_key} output with columns "
                                f"{df.columns}"
                            ),
                        )
                output_jsons[op_key] = df.to_dict(orient="records")
            return ORJSONResponse(output_jsons)

        app.include_router(jobs.router)
        app.include_router(cpu_profiling.router)
        return app


def create_app() -> FastAPI:
    """
    The workflow API server is run via a CLI interface with gunicorn
    where parameters are passed in as environment variables (no way to thread
    argv through a gunicorn call)
    """
    if "SNORKELFLOW_WORKFLOW_DIR" not in os.environ:
        raise RuntimeError(f"Required envvar $SNORKELFLOW_WORKFLOW_DIR is undefined")
    kwargs = dict()
    max_content_length = os.environ.get("MAX_CONTENT_LENGTH")
    if max_content_length is not None:
        kwargs = {"max_content_length": int(max_content_length)}
    server = WorkflowAPIServer.from_package_dir(
        pathlib.Path(os.environ["SNORKELFLOW_WORKFLOW_DIR"])
    )
    return server.server(**kwargs)  # type: ignore
