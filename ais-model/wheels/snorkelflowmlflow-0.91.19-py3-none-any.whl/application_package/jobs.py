import time
from typing import Any, Dict

import pandas as pd
from dask import dataframe as dd
from rq import get_current_job

from api_utils.exceptions import UserInputError
from application_package import DataframeRecordsJSON
from engine.common.type.workflows import ExecutePredictionAPIAsyncInferenceParams
from engine.jobs.engine import _log_exception_and_raise
from operators.workflows import WorkflowDAG
from rq_utils.common import update_job_meta
from snorkelflow.utils.dask import dask_compute
from snorkelflow.utils.datapoint import set_datapoint_index
from snorkelflow.utils.logging import get_logger

# Create logger and custom file
logger = get_logger("Engine")


def execute_async(params: ExecutePredictionAPIAsyncInferenceParams) -> None:
    logger.info(f"Running async inference for workflow")
    before = time.time()
    try:
        output_jsons = execute_workflow_config(params)
    except Exception as e:
        logger.exception(f"Exception while running async inference")
        raise e from None
    logger.info(f"Asynchronous inference request took: {time.time() - before} seconds")
    update_job_meta(
        job=get_current_job(),
        percent=100,
        message=f"Finished async execution of deployed workflow",
        detail=output_jsons,
    )


def execute_workflow_config(
    params: ExecutePredictionAPIAsyncInferenceParams,
) -> Dict[str, Any]:
    try:
        df = pd.DataFrame(params.input_df_json)
        set_datapoint_index(df)
        ddf = dd.from_pandas(df, npartitions=1)
    except Exception as e:
        _log_exception_and_raise(
            e, "Failed to parse base 64 encoded, pickled input object as dataframe."
        )
    workflow = WorkflowDAG(
        data_schema=ddf.dtypes.to_dict(), workflow_config=params.workflow_config
    )
    try:
        leaf_ddfs = workflow.execute(ddf)
    except Exception as e:
        raise UserInputError(
            f"Error occurred when executing supplied workflow graph on data: {str(e)}",
            user_friendly_message="Error occurred when executing supplied workflow graph on data",
        )

    output_jsons: Dict[str, DataframeRecordsJSON] = {}
    leaf_dfs = dask_compute(leaf_ddfs)[0]
    for op_key, df in leaf_dfs.items():
        if params.return_columns:
            try:
                df = df[params.return_columns]
            except KeyError:
                raise ValueError(
                    f"Could not select columns {params.return_columns} from operator {op_key} output with columns {df.columns}"
                )
        output_jsons[op_key] = df.to_dict(orient="records")

    return output_jsons
