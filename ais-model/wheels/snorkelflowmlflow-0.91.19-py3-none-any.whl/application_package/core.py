import abc
import json
import os
import pathlib
import traceback
import zipfile
from typing import Any, Dict, List, Optional, Union

from api_utils.exceptions import SnorkelException, UserInputError
from operators.workflows import WorkflowDAG
from snorkelflow.operators.udf import is_user_defined
from snorkelflow.serialization.code_asset import recompile_operator
from snorkelflow.types.application_package import DeploymentStorageInfo, WorkflowEnv
from snorkelflow.types.workflows import OperatorConfig, WorkflowConfig
from snorkelflow.utils.logging import get_logger

logger = get_logger("Workflow package")

WORKFLOW_FILENAME = "workflow.json"

# Prefix to the STDERR line containing exception information. Used so the caller
# can filter STDERR to just the line containing the relevant exception information
EXC_INFO_PREFIX = "__EXC__INFO__"


class WorkflowPackageExecutionError(ValueError):
    def __init__(self, message: str, stderr: str, **extra_args: Any) -> None:
        """
        message: contains a friendly log-like error message describing what went wrong
        stderr: contains the full STDERR output from the inference subprocess, to be parsed
                into a structured error message
        """
        super().__init__(message, **extra_args)
        self.message = message
        self.stderr = stderr


def get_workflow_file_contents(
    workflow_config: WorkflowConfig,
    input_columns: List[str],
    workflow_uid: Optional[int] = None,
) -> Dict[str, Union[str, Dict[int, Any], List[str], Optional[int]]]:
    # TODO(21376) - only export deployment_uid instead of workflow_uid
    # this is done for backcompat
    return {
        "snorkelflow_version": os.environ.get("SNORKEL_FLOW_VERSION", "UNKNOWN"),
        "config": {k: v.dict() for k, v in workflow_config.items()},
        "input_columns": input_columns,
        "workflow_uid": workflow_uid,
        "deployment_uid": workflow_uid,
    }


def workflow_config_from_workflow_contents(workflow: Dict[str, Any]) -> WorkflowConfig:
    if workflow.get("config"):
        # When workflow content is loaded from the file system
        workflow_config = {
            int(k): OperatorConfig(**v) for k, v in workflow["config"].items()
        }
    elif workflow.get("workflow_config"):
        # When the workflow content is queried from the database
        workflow_config = {
            int(k): OperatorConfig(**v) for k, v in workflow["workflow_config"].items()
        }
    else:
        logger.warning(
            f"No workflow contents provided for creating workflow config object: {workflow}"
        )
        workflow_config = dict()
    # Recompile
    for config in workflow_config.values():
        if is_user_defined(config.op_type) and "code" in config.op_config:
            op_config, code = config.op_config["config"], config.op_config["code"]
            # Decompile if needed for backcompat
            try:
                from snorkelflow.serialization.decompiler import decompile_operator

                new_code = decompile_operator(op_config, code)
            except ImportError:
                # Some library needed for decompiler is missing
                logger.warning(f"Skipping import of decompile_operator")
                new_code = code
            config.op_config["config"] = recompile_operator(op_config, new_code)
            config.op_config["code"] = new_code
    return workflow_config


def build_exception_contents(exc: Exception) -> str:
    """
    Since deployments are executed as subprocesses, If an exception occurs
    during inference, information about the error needs to be written to
    STDERR in JSON format to allow the caller can retrieve structured information
    about the error that occurred.
    This method takes any exception that occurred during inference and packages
    it in a format that the caller can interpret
    """
    exc_type_str = (
        exc.__class__.__name__  # type: ignore
        if hasattr(exc, "__class__") and hasattr(exc.__class__, "__name__")
        else "None"
    )

    # Display user friendly message to users if it is a SnorkelException
    user_friendly_message = (
        exc.user_friendly_message if isinstance(exc, SnorkelException) else ""
    )

    # Add exception detail in the detail metadata for developers to investigate
    if isinstance(exc, SnorkelException):
        detail = exc.detail
    else:
        detail = str(exc)

    # Set the traceback here to capture the stacktrace specific to the subprocess. This
    # will overwrite the traceback captured when the error is re-raised in the parent
    # process.
    metadata = dict(traceback=traceback.format_exc(limit=-10))

    error_payload = dict(
        _exc_type=exc_type_str,
        user_friendly_message=user_friendly_message,
        detail=detail,
        metadata=metadata,
    )

    return f"{EXC_INFO_PREFIX}{json.dumps(error_payload)}"


def parse_exception_contents(deployment_uid: int, stderr: str) -> UserInputError:
    """
    If a subprocess call to run inference on a deployment fails, this method will
    attempt to parse the stderr of that failling process into structured error
    information that can then be re-raised, providing useful error information
    to the caller. If we cannot parse stderr of the subprocess (due to some unforseen
    error), we will revert to old behavior of just attaching the entire stracktrace
    to the exception and raising that

    Note that we have to parse the structured error info from a specific single line
    that is prefixed with {EXC_INFO_PREFIX}. We can't just parse *all* of stderr since
    it's possible there was other data logged before the structured info was written.
    """

    user_friendly_message_prefix = (
        f"Error while executing inference on deployment {deployment_uid}"
    )
    try:
        # Split STDERR into individual lines and find the one containing the structured
        # error information by filtering on a sentinel prefix
        exc_line = [l for l in stderr.split("\n") if l.startswith(EXC_INFO_PREFIX)]
        if not len(exc_line) == 1:
            raise Exception(
                f"No lines found in STDERR containing {EXC_INFO_PREFIX} prefix"
            )
        error_payload = json.loads(exc_line[0].lstrip(EXC_INFO_PREFIX))
        user_friendly_message = error_payload["user_friendly_message"]
        detail = error_payload["detail"]
        metadata = error_payload["metadata"]
    except Exception:
        # The deployment did not write exception info to stderr as expected (possibly
        # due to it being an old deployment that didn't have the updated logic). Raise
        # a simple UserInputError without structured info (this places the entire stderr
        # output into the "details" field which can be overwhelming an unwieldy to a user)
        logger.exception(f"Unable to parse STDERR into structured error info")
        return UserInputError(
            user_friendly_message=user_friendly_message_prefix,
            detail=f"{user_friendly_message_prefix}: {stderr}",
        )
    else:
        full_message = (
            f"{user_friendly_message_prefix}: {user_friendly_message}"
            if user_friendly_message
            else user_friendly_message_prefix
        )
        return UserInputError(
            user_friendly_message=full_message, detail=detail, metadata=metadata
        )


class BaseWorkflowPackage(abc.ABC):
    def __init__(
        self,
        workflow_config: WorkflowConfig,
        input_columns: List[str],
        workflow_uid: Optional[int] = None,
        workflow_package_dir: Optional[pathlib.Path] = None,
        model_classes: Optional[Dict[int, str]] = None,
    ) -> None:
        self.workflow_config = workflow_config
        self.input_columns = input_columns
        self.workflow_uid = workflow_uid
        self.workflow_package_dir = workflow_package_dir
        self.dag = WorkflowDAG(
            data_schema={col: None for col in self.input_columns},
            workflow_config=self.workflow_config,
        )
        self.model_classes = model_classes

    @abc.abstractmethod
    def save(
        self, workflow_dir_name: str, workflow_env: WorkflowEnv
    ) -> DeploymentStorageInfo:
        pass

    @staticmethod
    def get_archive_path(workflow_dir: pathlib.Path) -> pathlib.Path:
        return workflow_dir.with_suffix(".zip")

    @staticmethod
    def archive(workflow_dir_name: str) -> str:
        """Make an archive of workflow directory for prediction API, will overwrite existing"""
        fname = workflow_dir_name + ".zip"
        with zipfile.ZipFile(fname, "w", zipfile.ZIP_DEFLATED) as zipf:
            for root, dirs, files in os.walk(workflow_dir_name):
                relative_path = os.path.relpath(root, workflow_dir_name)
                # exclude /code directory
                if "code" in dirs:
                    dirs.remove("code")
                for file in files:
                    file_path = os.path.join(root, file)
                    zipf.write(file_path, os.path.join(relative_path, file))
        return fname
