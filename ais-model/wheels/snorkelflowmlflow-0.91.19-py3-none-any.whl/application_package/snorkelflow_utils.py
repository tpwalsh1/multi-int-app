import json
import os
import pathlib
import shutil
import subprocess
from typing import Any, Dict, Optional

import packaging.version
import pandas as pd
import pyarrow.parquet as pq
from dask import dataframe as dd

from snorkelflow.types.application_package import (
    DeploymentFileStorageInfo,
    DeploymentStorageInfo,
    WorkflowEnv,
)
from snorkelflow.types.workflows import WorkflowConfig
from snorkelflow.utils.logging import get_logger

from .core import (
    WORKFLOW_FILENAME,
    BaseWorkflowPackage,
    WorkflowPackageExecutionError,
    get_workflow_file_contents,
    workflow_config_from_workflow_contents,
)

logger = get_logger("SnorkelFlowPackage")

V_0_22_0 = packaging.version.parse("0.22.0")
V_0_23_0 = packaging.version.parse("0.23.0")
V_0_46_0 = packaging.version.parse("0.46.0")
V_0_47_0 = packaging.version.parse("0.47.0")
V_0_53_0 = packaging.version.parse("0.53.0")
V_0_54_0 = packaging.version.parse("0.54.0")
V_0_56_0 = packaging.version.parse("0.56.0")
V_0_57_0 = packaging.version.parse("0.57.0")

WHEEL_PATH = "/snorkelflowengine-0.0.1-py3-none-any.whl"


class WorkflowVersionError(Exception):
    pass


def read_parquet_pyarrow(parquet_path: pathlib.Path) -> pd.DataFrame:
    return pq.read_table(parquet_path).to_pandas(integer_object_nulls=True)


def load_parquet_files(output_dir: str, engine: str) -> Dict[str, dd.DataFrame]:
    logger.info(f"Using engine {engine} to load the parquet file")
    output_ddfs: Dict[str, dd.DataFrame] = {}
    if not os.path.exists(output_dir):
        return output_ddfs
    for child in pathlib.Path(output_dir).iterdir():
        if child.name.endswith(".parquet"):
            op_key = child.name[: -len(".parquet")]
        else:
            continue
        # FastParquet does not deduplicate memory when reading from a parquet file
        # PyArrow is smart enough to use the reference for large repeating objects
        # instead of duplicating them.
        # in other words
        # PyArrow:
        #   if ddf.at[0,'large_col'] == ddf.at[1, 'large_col'] then id(ddf.at[0,'large_col']) == id(ddf.at[1, 'large_col'])
        # FastParquet:
        #   if ddf.at[0,'large_col'] == ddf.at[1, 'large_col'] then id(ddf.at[0,'large_col']) != id(ddf.at[1, 'large_col'])
        # Because of this the memory footprint is high for fastparquet
        # Also note we cannot do lazy read because the parquet file is in a temporary inference directory
        # that gets deleted when the caller returns
        if engine == "pyarrow":
            df = read_parquet_pyarrow(child)
            df.index.name = "index"
        else:
            df = pd.read_parquet(child, engine=engine)
        output_ddfs[op_key] = dd.from_pandas(df, npartitions=1)
    return output_ddfs


class SnorkelFlowPackage(BaseWorkflowPackage):
    @classmethod
    def read_workflow_file(cls, workflow_dir: pathlib.Path) -> Dict[str, Any]:
        with open(workflow_dir / WORKFLOW_FILENAME) as f:
            return json.load(f)

    @classmethod
    def read_config(cls, workflow_dir: pathlib.Path) -> WorkflowConfig:
        workflow = cls.read_workflow_file(workflow_dir)
        return workflow_config_from_workflow_contents(workflow)

    @classmethod
    def workflow_uid_from_dir(cls, workflow_dir: pathlib.Path) -> Optional[int]:
        # From v0.46.0 onward the `workflow_uid` was included in the workflow.json
        # file, prior to that it needed to be parsed from the exported directory name
        try:
            return int(workflow_dir.name.split("_")[1])
        except (ValueError, IndexError):
            return None

    @classmethod
    def from_package_dir(cls, workflow_dir: pathlib.Path) -> "SnorkelFlowPackage":
        workflow = cls.read_workflow_file(workflow_dir)
        workflow_uid = workflow.get("workflow_uid")
        if workflow_uid is None:
            workflow_uid = cls.workflow_uid_from_dir(workflow_dir)
            if workflow_uid is None:
                # Should be exported as workflow_{uid}.zip, possible that client renamed
                logger.warning(f"Could not find workflow_uid from dir: {workflow_dir}")
        workflow_config = workflow_config_from_workflow_contents(workflow)
        input_columns = workflow["input_columns"]
        return cls(
            workflow_config=workflow_config,
            input_columns=input_columns,
            workflow_uid=workflow_uid,
            workflow_package_dir=workflow_dir,
        )

    def _save_workflow_env(
        self, workflow_dir: pathlib.Path, workflow_env: WorkflowEnv
    ) -> None:
        # Separated out for easier mocking in unit tests
        if workflow_env == WorkflowEnv.NONE:
            pass
        elif workflow_env == WorkflowEnv.FIRST_PARTY:
            shutil.copy(WHEEL_PATH, workflow_dir / "workflow_env.zip")
        elif workflow_env == WorkflowEnv.FULL:
            raise NotImplementedError(
                f"Workflow env {workflow_env.name} is not implemented yet"
            )
        else:
            raise ValueError(f"Unknown workflow env {workflow_env.name}")

    def save(
        self, workflow_dir_name: str, workflow_env: WorkflowEnv
    ) -> DeploymentStorageInfo:
        workflow_dir = pathlib.Path(workflow_dir_name)
        workflow_dir.mkdir(exist_ok=True)
        workflow = get_workflow_file_contents(self.workflow_config, self.input_columns)
        with open(workflow_dir / WORKFLOW_FILENAME, "w") as f:
            json.dump(workflow, f)
        self._save_workflow_env(workflow_dir, workflow_env)
        shutil.copy(
            pathlib.Path(__file__).parent.absolute() / "workflow_main.py", workflow_dir
        )
        return DeploymentFileStorageInfo(workflow_package_dir=workflow_dir_name)


class SnorkelFlowPackageHandler:
    snorkelflow_version: Optional[packaging.version.Version]

    def __init__(
        self, workflow_dir: pathlib.Path, collecting_monitoring_data: bool = True
    ) -> None:
        self.workflow_dir = workflow_dir
        self.collecting_monitoring_data = collecting_monitoring_data
        with open(workflow_dir / WORKFLOW_FILENAME) as f:
            workflow = json.load(f)
        snorkelflow_version_str = workflow.get(
            "snorkelflow_version",
            # NB: older package versions had a typo
            workflow.get("snorkflow_version", ""),
        )
        # Certain deployments have spec-violating versions that
        # end in a '-{A..F}' postfix, strip that postfix here
        snorkelflow_version_str = snorkelflow_version_str.split("-")[0]
        self.snorkelflow_verstion_str = snorkelflow_version_str
        try:
            snorkelflow_version = packaging.version.parse(snorkelflow_version_str)
            if not isinstance(snorkelflow_version, packaging.version.Version):
                # Handle cases like bazel and UNKNOWN which parse as LegacyVersion
                self.snorkelflow_version = None
            else:
                self.snorkelflow_version = snorkelflow_version
        except packaging.version.InvalidVersion:
            self.snorkelflow_version = None

    def run_execute(
        self, input_file_format: str, input_file: str, output_dir: str
    ) -> None:
        args = [
            "python",
            str(pathlib.Path(__file__).parent.absolute() / "workflow_main.py"),
            "execute",
            "--workflow-dir",
            str(self.workflow_dir),
            "--input-file-format",
            input_file_format,
            "--input-file",
            input_file,
            "--output-dir",
            output_dir,
        ]
        if self.collecting_monitoring_data:
            if self.snorkelflow_version and self.snorkelflow_version < V_0_46_0:
                # Monitoring not supported in 'execute' mode before 0.46.0
                pass
            else:
                # Args common to 'execute' and 'serve` must go before either command
                args.insert(2, "--monitor")
        try:
            # Note: To enable accessing a pdb inside the workflow, add an addition pdb
            # statement here, set capture_output to False, and step through next line.
            out = subprocess.run(
                args, check=True, universal_newlines=True, capture_output=True
            )
            logger.info(out.stdout)
        except subprocess.CalledProcessError as e:
            msg = f"Failed to run workflow, err: {e.stderr}"
            logger.exception(msg)
            raise WorkflowPackageExecutionError(msg, stderr=e.stderr)

    def run_serve(
        self,
        host: Optional[str] = None,
        port: Optional[int] = None,
        max_content_length: Optional[int] = None,
        server_ttl: Optional[int] = None,
        n_workers: Optional[int] = None,
    ) -> None:
        if self.snorkelflow_version and self.snorkelflow_version < V_0_22_0:
            raise WorkflowVersionError(
                "server mode not available for workflow package versions < 0.22.0"
            )
        if (
            max_content_length is not None
            and self.snorkelflow_version
            and self.snorkelflow_version < V_0_23_0
        ):
            raise WorkflowVersionError(
                "max-content-length option not available for workflow package versions < 0.23.0"
            )
        if (
            n_workers is not None
            and self.snorkelflow_version
            and self.snorkelflow_version < V_0_56_0
        ):
            raise WorkflowVersionError(
                "n_workers option not available for workflow package versions < 0.56.0"
            )
        try:
            args = [
                "python",
                str(pathlib.Path(__file__).parent.absolute() / "workflow_main.py"),
                "serve",
                "--workflow-dir",
                str(self.workflow_dir),
            ]
            if host is not None:
                args.extend(["--host", host])
            if port is not None:
                args.extend(["--port", str(port)])
            if max_content_length is not None:
                args.extend(["--max-content-length", str(max_content_length)])
            if n_workers is not None:
                args.extend(["--n-workers", str(n_workers)])
            subprocess.run(
                args,
                check=True,
                stderr=subprocess.PIPE,
                universal_newlines=True,
                timeout=server_ttl,
            )
        except subprocess.CalledProcessError as e:
            msg = f"Failed to run workflow server, err: {e.stderr}"
            logger.exception(msg)
            raise ValueError(msg)

    def run_worker(
        self,
        data_dir: str,
        server_ttl: Optional[int] = None,
        n_workers: Optional[int] = None,
    ) -> None:
        if self.snorkelflow_version and self.snorkelflow_version < V_0_57_0:
            raise WorkflowVersionError(
                "worker mode not available for workflow package versions < 0.57.0"
            )

        try:
            args = [
                "python",
                str(self.workflow_dir / "workflow_main.py"),
                "work",
                "--data-dir",
                data_dir,
            ]
            if n_workers is not None:
                args.extend(["--n-workers", str(n_workers)])
            subprocess.run(
                args,
                check=True,
                stderr=subprocess.PIPE,
                universal_newlines=True,
                timeout=server_ttl,
            )
        except subprocess.CalledProcessError as e:
            msg = f"Failed to run workflow async worker, err: {e.stderr}"
            logger.exception(msg)
            raise ValueError(msg)
