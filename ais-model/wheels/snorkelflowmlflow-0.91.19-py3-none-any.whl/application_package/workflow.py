import json
import os
import pathlib
import re
import tempfile
from typing import Any, Dict, Tuple, Union

import packaging
import pandas as pd
import pyarrow.parquet as pq
from dask import dataframe as dd

from api_utils.exceptions import NotSupportedException
from application_package.mlflow_utils import MLFlowPackageHandler
from application_package.snorkelflow_utils import SnorkelFlowPackageHandler
from monitoring.client import MONITORING_DIRECTORY
from snorkelflow.data.core import load_dataframe_from_config
from snorkelflow.serialization import serializable
from snorkelflow.types.application_package import PackageType
from snorkelflow.types.load import LoadConfig, SourceType
from snorkelflow.utils.logging import get_logger

logger = get_logger("SnorkelFlowPackage")

V_0_22_0 = packaging.version.parse("0.22.0")
V_0_23_0 = packaging.version.parse("0.23.0")
V_0_46_0 = packaging.version.parse("0.46.0")
V_0_47_0 = packaging.version.parse("0.47.0")
V_0_53_0 = packaging.version.parse("0.53.0")
V_0_54_0 = packaging.version.parse("0.54.0")
V_0_56_0 = packaging.version.parse("0.56.0")
V_0_57_0 = packaging.version.parse("0.57.0")
V_0_69_0 = packaging.version.parse("0.69.0")


def read_parquet_pyarrow(parquet_path: pathlib.Path) -> pd.DataFrame:
    return pq.read_table(parquet_path).to_pandas(integer_object_nulls=True)


def load_parquet_files(output_dir: str, engine: str) -> Dict[str, dd.DataFrame]:
    logger.info(f"Using engine {engine} to load the parquet file")
    output_ddfs: Dict[str, dd.DataFrame] = {}
    if not os.path.exists(output_dir):
        return output_ddfs
    for child in pathlib.Path(output_dir).iterdir():
        if child.name.endswith(".parquet"):
            op_key = child.name[: -len(".parquet")]
        else:
            continue
        # FastParquet does not deduplicate memory when reading from a parquet file
        # PyArrow is smart enough to use the reference for large repeating objects
        # instead of duplicating them.
        # in other words
        # PyArrow:
        #   if ddf.at[0,'large_col'] == ddf.at[1, 'large_col'] then id(ddf.at[0,'large_col']) == id(ddf.at[1, 'large_col'])
        # FastParquet:
        #   if ddf.at[0,'large_col'] == ddf.at[1, 'large_col'] then id(ddf.at[0,'large_col']) != id(ddf.at[1, 'large_col'])
        # Because of this the memory footprint is high for fastparquet
        # Also note we cannot do lazy read because the parquet file is in a temporary inference directory
        # that gets deleted when the caller returns
        if engine == "pyarrow":
            df = read_parquet_pyarrow(child)
            df.index.name = "index"
        else:
            df = pd.read_parquet(child, engine=engine)
        output_ddfs[op_key] = dd.from_pandas(df, npartitions=1)
    return output_ddfs


def _deserialize_ddfs(
    ddf_dict: Dict[str, dd.DataFrame], use_b64_deserialization: bool = False
) -> Dict[str, dd.DataFrame]:
    """A helper function to deserialize the serialized columns. For
       workflows only 'probs' column is serialized/deserialized.
       Starting v0.54, we have moved away from JSON based deserialization to
       b64 based deserialization

    Args:
        ddf_dict (Dict[str, dd.DataFrame]): Dictionary of all the loaded dataframes

    Returns:
        Dict[str, dd.DataFrame]: Dictionary with deserialized dataframe
    """

    def _deserialize_probs(x: Any) -> Any:
        if use_b64_deserialization:
            try:
                return serializable.B64PICKLE.deserialize(x)
            except Exception as e:
                logger.info(f"{e}")
                pass

        try:
            return json.loads(x)
        except Exception:
            return x

    for key, ddf in ddf_dict.items():
        if "probs" in ddf.columns:
            ddf["probs"] = ddf["probs"].apply(
                _deserialize_probs, 1, meta=(None, "object")
            )
            ddf.compute()
        ddf_dict[key] = ddf
    return ddf_dict


def _is_version_bazel_or_sha_or_unknown(version_str_lower: str) -> bool:
    return (
        version_str_lower == "bazel"
        or version_str_lower == "unknown"
        or bool(re.match(r"\b[0-9a-f]{5,40}\b", version_str_lower))
    )


# NB: This function loads the entire result dataframes in memory.
def execute_workflow_ddf(
    workflow_package_dir: str,
    input_ddf: dd.DataFrame,
    package_type: PackageType,
    collect_monitoring_data: bool = True,
) -> Tuple[Dict[str, dd.DataFrame], Dict[str, dd.DataFrame]]:
    with tempfile.TemporaryDirectory() as tmp:
        input_file = os.path.join(tmp, "input.parquet")
        input_ddf.to_parquet(input_file, engine="pyarrow")

        output_dir = os.path.join(tmp, "output")

        handler: Union[SnorkelFlowPackageHandler, MLFlowPackageHandler]

        if package_type == PackageType.SnorkelFlowPackage:
            handler = SnorkelFlowPackageHandler(
                pathlib.Path(workflow_package_dir), collect_monitoring_data
            )
        elif package_type == PackageType.MLflowModel:
            handler = MLFlowPackageHandler(
                pathlib.Path(workflow_package_dir), collect_monitoring_data
            )
        else:
            raise NotSupportedException(
                f"Invalid package_type {package_type} to perform inference requests"
            )

        handler.run_execute(SourceType.PARQUET.name, input_file, output_dir)

        # Need to read into a pandas dataframe because the tmp file only exists
        # within this function.
        output_ddfs: Dict[str, dd.DataFrame] = {}

        for child in pathlib.Path(output_dir).iterdir():
            if child.name.endswith(".json"):
                op_key = child.name[: -len(".json")]
                with open(os.path.join(output_dir, f"{op_key}.json"), "r") as f:
                    load_config = LoadConfig(
                        **{"type": SourceType.PARQUET, **json.load(f)}
                    )
                output_ddfs[op_key] = load_dataframe_from_config(
                    load_config=load_config, set_uid=False
                )
                # we need to compute the ddf otherwise it fails because temporary directory will be deleted
                output_df = output_ddfs[op_key].compute()
                output_ddfs[op_key] = dd.from_pandas(output_df, npartitions=1)

        monitoring_ddfs: Dict[str, dd.DataFrame] = dict()
        if collect_monitoring_data:
            monitoring_dir = os.path.join(output_dir, MONITORING_DIRECTORY)
            monitoring_ddfs = load_parquet_files(monitoring_dir, engine="pyarrow")
        return output_ddfs, monitoring_ddfs
