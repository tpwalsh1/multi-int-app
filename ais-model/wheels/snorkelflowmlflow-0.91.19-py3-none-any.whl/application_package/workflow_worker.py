import json
import sys
from typing import Optional

import engine.jobs as engine
from engine.common.type.queue import EngineQueue
from engine.common.type.rq import ENGINE_JOB_STATE_REDIS_PREFIX
from redis_utils.connection import init_redis
from rq_utils.manager import RQWorkerConfig, RQWorkerManager
from snorkelflow.config.constants import ServiceType
from snorkelflow.utils.logging import get_logger

logger = get_logger("RQ Worker")


def run_workflow_worker_mode(
    *,
    data_dir: str,
    n_workers: int,
    redis_url: str,
    redis_ssl_enabled: bool,
    redis_port: Optional[int] = None,
    redis_password: Optional[str] = None,
) -> None:
    engine.config["data_dir"] = data_dir
    engine.config["routine_analyze"] = False

    logger.info(f"Initializing redis: {redis_url}")

    init_redis(redis_url, redis_ssl_enabled, redis_password, redis_port=redis_port)

    cluster_config = [
        RQWorkerConfig(
            name="prediction-api",
            queues=[EngineQueue.PREDICTION_API.value],
            num_workers=n_workers,
        )
    ]

    logger.info(
        f"Bulding RQWorkerManager, sys.path: {json.dumps(sys.path, indent=True)}"
    )

    # We'll pass ourselves off as the engine service for now to inherit
    # all of its capabilities.
    # TODO - consider defining the prediction API as it's own service
    rq_cluster = RQWorkerManager(
        cluster_config,
        service_type=ServiceType.Engine,
        data_dir=engine.config["data_dir"],
        redis_metric_prefix=ENGINE_JOB_STATE_REDIS_PREFIX,
        init_worker=None,
        enable_job_maintainers=False,
    )
    logger.info(f"Starting RQWorkerManager, queues: {cluster_config}")

    rq_cluster.start()

    rq_cluster.wait_for_exit()

    sys.exit(0)
