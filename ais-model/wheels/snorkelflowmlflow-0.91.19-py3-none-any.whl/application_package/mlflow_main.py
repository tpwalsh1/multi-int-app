import argparse
import logging
import os
import pathlib
import sys
from typing import Optional

from gunicorn.app.wsgiapp import run

logging.basicConfig(stream=sys.stdout, level=logging.INFO)
logger = logging.getLogger(__name__)


def launch_workflow_server(
    mlflow_dir: pathlib.Path,
    port: int,
    host: str,
    workers: int,
    max_content_length: Optional[int] = None,
) -> None:
    # --chdir is needed for gunicorn to find ./application_package/mlflow_server.py:app
    args = [
        "gunicorn",
        "-e",
        f"MLFLOW_MODEL_DIR={mlflow_dir}",
        "--chdir",
        str(mlflow_dir),
        "--bind",
        f"{host}:{port}",
        "--workers",
        str(workers),
        "--log-level",
        "debug",
        "--timeout",
        str(30),
        "--keep-alive",
        str(30),
        "--worker-class",
        "uvicorn.workers.UvicornWorker",
    ]
    if max_content_length:
        args += ["-e", f"MAX_CONTENT_LENGTH={max_content_length}"]
    sys.argv = args + ["application_package.mlflow_server:create_app()"]
    run()


def default_n_proc_workers() -> int:
    # importing snorkelflow has to happen after we modify the path to find the right one
    from snorkelflow.utils.system import CPU_COUNT

    return max(CPU_COUNT, 1)


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="mlflow_main",
        description="mlflow runner",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    parser.add_argument(
        "--monitor",
        action="store_true",
        help="Collect monitoring data on inference requests",
    )

    subparsers = parser.add_subparsers(dest="command")

    execute_parser = subparsers.add_parser("execute", help="Execute workflow on file")
    execute_parser.add_argument(
        "--mlflow-dir",
        type=str,
        required=True,
        help="Absolute path to the directory defining the MLflow model",
    )
    execute_parser.add_argument(
        "--input-file-format",
        type=str,
        default="PARQUET",
        choices=["PARQUET", "CSV"],
        help="file format for input and output, choose: PARQUET or CSV",
    )
    execute_parser.add_argument(
        "--input-file",
        type=str,
        required=True,
        help="read input dataframe from this file",
    )
    execute_parser.add_argument(
        "--output-dir",
        type=str,
        required=True,
        help="write output dataframe(s) as parquet files inside this directory",
    )

    serve_parser = subparsers.add_parser("serve", help="Serve MLFlow model as an API")
    serve_parser.add_argument(
        "--mlflow-dir",
        type=str,
        required=True,
        help="the directory of the mlflow package",
    )
    serve_parser.add_argument(
        "--host",
        type=str,
        default="0.0.0.0",
        help="Host to serve the MLflow model API on",
    )
    serve_parser.add_argument(
        "--port", type=int, default=8080, help="Port to serve the MLflow model API on"
    )
    serve_parser.add_argument(
        "--max-content-length", type=int, help="Maximum content-length for requests"
    )
    serve_parser.add_argument(
        "--n-workers",
        type=int,
        help="Number of Gunicorn workers used to handle requests",
        default=default_n_proc_workers(),
    )

    args, _ = parser.parse_known_args()

    os.chdir(args.mlflow_dir)

    # import snorkelflow has to happen after we modify the path to find the right `snorkelflow` folder
    from application_package import build_exception_contents
    from snorkelflow.utils.logging import set_up_logging

    set_up_logging()

    logger.info(f"Loading mlflow package from {args.mlflow_dir}")

    if args.command == "execute":
        from application_package.mlflow_server import MLFlowFileServer

        logger.info(f"Executing workflow for input {args.input_file}")
        server = MLFlowFileServer.from_package_dir(args.mlflow_dir, args.monitor)
        try:
            server.execute(args.input_file_format, args.input_file, args.output_dir)  # type: ignore
        except Exception as e:
            # Write structured error information to stderr so the calling process
            # can parse it
            print(build_exception_contents(e), file=sys.stderr, flush=True)
            raise e from None
    elif args.command == "serve":
        logger.info(f"Running workflow server at {args.host}:{args.port}")
        launch_workflow_server(
            args.mlflow_dir,
            args.port,
            args.host,
            args.n_workers,
            args.max_content_length,
        )
    else:
        raise ValueError(f"Unknown command {args.cmd}")


if __name__ == "__main__":
    main()
